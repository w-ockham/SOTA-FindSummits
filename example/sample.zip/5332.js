function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.5371222222e+01,
lng: 1.3354633333e+02,
cert : true,
content:'Name = Daisen (Kengamine)(JA/TT-001) peak = 1725.699951 pos = 35.3712,133.5463 diff = 1725.699951'
});
data_saddle.push({
lat: 3.5998000000e+01,
lng: 1.3306500000e+02,
content:'Saddle = 0.000000 pos = 35.9980,133.0650 diff = 1725.699951'
});
data_peak.push({
lat: 3.5566000000e+01,
lng: 1.3316311111e+02,
cert : false,
content:' Peak = 171.399994 pos = 35.5660,133.1631 diff = 168.299988'
});
data_saddle.push({
lat: 3.5562111111e+01,
lng: 1.3316188889e+02,
content:'Saddle = 3.100000 pos = 35.5621,133.1619 diff = 168.299988'
});
data_peak.push({
lat: 3.5662888889e+01,
lng: 1.3469044444e+02,
cert : false,
content:' Peak = 221.899994 pos = 35.6629,134.6904 diff = 216.799988'
});
data_saddle.push({
lat: 3.5655888889e+01,
lng: 1.3468777778e+02,
content:'Saddle = 5.100000 pos = 35.6559,134.6878 diff = 216.799988'
});
data_peak.push({
lat: 3.5541555556e+01,
lng: 1.3310311111e+02,
cert : true,
content:'Name = JA/SN-084(JA/SN-084) peak = 535.500000 pos = 35.5416,133.1031 diff = 530.200012'
});
data_saddle.push({
lat: 3.5488333334e+01,
lng: 1.3301077778e+02,
content:'Saddle = 5.300000 pos = 35.4883,133.0108 diff = 530.200012'
});
data_peak.push({
lat: 3.5486666667e+01,
lng: 1.3310755556e+02,
cert : true,
content:'Name = Dakesan(JA/SN-128) peak = 330.899994 pos = 35.4867,133.1076 diff = 296.500000'
});
data_saddle.push({
lat: 3.5509555556e+01,
lng: 1.3310688889e+02,
content:'Saddle = 34.400002 pos = 35.5096,133.1069 diff = 296.500000'
});
data_peak.push({
lat: 3.5560000000e+01,
lng: 1.3323955556e+02,
cert : true,
content:'Name = JA/SN-129(JA/SN-129) peak = 330.100006 pos = 35.5600,133.2396 diff = 293.000000'
});
data_saddle.push({
lat: 3.5543333334e+01,
lng: 1.3316400000e+02,
content:'Saddle = 37.099998 pos = 35.5433,133.1640 diff = 293.000000'
});
data_peak.push({
lat: 3.5566222222e+01,
lng: 1.3327177778e+02,
cert : false,
content:' Peak = 261.600006 pos = 35.5662,133.2718 diff = 204.300003'
});
data_saddle.push({
lat: 3.5556888889e+01,
lng: 1.3325688889e+02,
content:'Saddle = 57.299999 pos = 35.5569,133.2569 diff = 204.300003'
});
data_peak.push({
lat: 3.5515111111e+01,
lng: 1.3306833333e+02,
cert : false,
content:' Peak = 295.799988 pos = 35.5151,133.0683 diff = 153.899994'
});
data_saddle.push({
lat: 3.5519555556e+01,
lng: 1.3306855556e+02,
content:'Saddle = 141.899994 pos = 35.5196,133.0686 diff = 153.899994'
});
data_peak.push({
lat: 3.5653555556e+01,
lng: 1.3483411111e+02,
cert : false,
content:' Peak = 158.500000 pos = 35.6536,134.8341 diff = 151.100006'
});
data_saddle.push({
lat: 3.5654333333e+01,
lng: 1.3482744444e+02,
content:'Saddle = 7.400000 pos = 35.6543,134.8274 diff = 151.100006'
});
data_peak.push({
lat: 3.5585888889e+01,
lng: 1.3431366667e+02,
cert : false,
content:' Peak = 201.899994 pos = 35.5859,134.3137 diff = 193.199997'
});
data_saddle.push({
lat: 3.5570000000e+01,
lng: 1.3431711111e+02,
content:'Saddle = 8.700000 pos = 35.5700,134.3171 diff = 193.199997'
});
data_peak.push({
lat: 3.5612888889e+01,
lng: 1.3491111111e+02,
cert : false,
content:' Peak = 191.000000 pos = 35.6129,134.9111 diff = 181.899994'
});
data_saddle.push({
lat: 3.5618888889e+01,
lng: 1.3491700000e+02,
content:'Saddle = 9.100000 pos = 35.6189,134.9170 diff = 181.899994'
});
data_peak.push({
lat: 3.5412666667e+01,
lng: 1.3275255556e+02,
cert : true,
content:'Name = Hanatakasen(JA/SN-085) peak = 535.000000 pos = 35.4127,132.7526 diff = 525.500000'
});
data_saddle.push({
lat: 3.5400333334e+01,
lng: 1.3278488889e+02,
content:'Saddle = 9.500000 pos = 35.4003,132.7849 diff = 525.500000'
});
data_peak.push({
lat: 3.5471777778e+01,
lng: 1.3278722222e+02,
cert : true,
content:'Name = JA/SN-116(JA/SN-116) peak = 420.799988 pos = 35.4718,132.7872 diff = 383.399994'
});
data_saddle.push({
lat: 3.5443111111e+01,
lng: 1.3276488889e+02,
content:'Saddle = 37.400002 pos = 35.4431,132.7649 diff = 383.399994'
});
data_peak.push({
lat: 3.5507888889e+01,
lng: 1.3297633333e+02,
cert : true,
content:'Name = Asahiyama(JA/SN-126) peak = 342.600006 pos = 35.5079,132.9763 diff = 245.700012'
});
data_saddle.push({
lat: 3.5511333334e+01,
lng: 1.3294200000e+02,
content:'Saddle = 96.900002 pos = 35.5113,132.9420 diff = 245.700012'
});
data_peak.push({
lat: 3.5484555556e+01,
lng: 1.3285644444e+02,
cert : false,
content:' Peak = 356.100006 pos = 35.4846,132.8564 diff = 217.500000'
});
data_saddle.push({
lat: 3.5483444445e+01,
lng: 1.3282544444e+02,
content:'Saddle = 138.600006 pos = 35.4834,132.8254 diff = 217.500000'
});
data_peak.push({
lat: 3.5425777778e+01,
lng: 1.3265477778e+02,
cert : false,
content:' Peak = 356.399994 pos = 35.4258,132.6548 diff = 155.199997'
});
data_saddle.push({
lat: 3.5417222222e+01,
lng: 1.3266388889e+02,
content:'Saddle = 201.199997 pos = 35.4172,132.6639 diff = 155.199997'
});
data_peak.push({
lat: 3.5490333334e+01,
lng: 1.3390711111e+02,
cert : false,
content:' Peak = 185.899994 pos = 35.4903,133.9071 diff = 171.599991'
});
data_saddle.push({
lat: 3.5490000000e+01,
lng: 1.3392422222e+02,
content:'Saddle = 14.300000 pos = 35.4900,133.9242 diff = 171.599991'
});
data_peak.push({
lat: 3.5436111111e+01,
lng: 1.3309400000e+02,
cert : false,
content:' Peak = 170.800003 pos = 35.4361,133.0940 diff = 152.100006'
});
data_saddle.push({
lat: 3.5433888889e+01,
lng: 1.3308966667e+02,
content:'Saddle = 18.700001 pos = 35.4339,133.0897 diff = 152.100006'
});
data_peak.push({
lat: 3.5452333334e+01,
lng: 1.3382066667e+02,
cert : false,
content:' Peak = 196.899994 pos = 35.4523,133.8207 diff = 177.199997'
});
data_saddle.push({
lat: 3.5446555556e+01,
lng: 1.3380366667e+02,
content:'Saddle = 19.700001 pos = 35.4466,133.8037 diff = 177.199997'
});
data_peak.push({
lat: 3.5009888889e+01,
lng: 1.3226755556e+02,
cert : false,
content:' Peak = 250.699997 pos = 35.0099,132.2676 diff = 229.599991'
});
data_saddle.push({
lat: 3.5037000000e+01,
lng: 1.3229455556e+02,
content:'Saddle = 21.100000 pos = 35.0370,132.2946 diff = 229.599991'
});
data_peak.push({
lat: 3.5026222223e+01,
lng: 1.3226277778e+02,
cert : false,
content:' Peak = 244.600006 pos = 35.0262,132.2628 diff = 196.700012'
});
data_saddle.push({
lat: 3.5021333334e+01,
lng: 1.3226488889e+02,
content:'Saddle = 47.900002 pos = 35.0213,132.2649 diff = 196.700012'
});
data_peak.push({
lat: 3.5619444445e+01,
lng: 1.3493344444e+02,
cert : false,
content:' Peak = 193.800003 pos = 35.6194,134.9334 diff = 167.600006'
});
data_saddle.push({
lat: 3.5599111111e+01,
lng: 1.3494722222e+02,
content:'Saddle = 26.200001 pos = 35.5991,134.9472 diff = 167.600006'
});
data_peak.push({
lat: 3.5633333333e+01,
lng: 1.3446211111e+02,
cert : false,
content:' Peak = 243.800003 pos = 35.6333,134.4621 diff = 217.500000'
});
data_saddle.push({
lat: 3.5638777778e+01,
lng: 1.3447766667e+02,
content:'Saddle = 26.299999 pos = 35.6388,134.4777 diff = 217.500000'
});
data_peak.push({
lat: 3.5631444445e+01,
lng: 1.3443722222e+02,
cert : false,
content:' Peak = 187.899994 pos = 35.6314,134.4372 diff = 150.099991'
});
data_saddle.push({
lat: 3.5623888889e+01,
lng: 1.3444055556e+02,
content:'Saddle = 37.799999 pos = 35.6239,134.4406 diff = 150.099991'
});
data_peak.push({
lat: 3.5679000000e+01,
lng: 1.3499333333e+02,
cert : true,
content:'Name = JA/KT-101(JA/KT-101) peak = 314.600006 pos = 35.6790,134.9933 diff = 260.200012'
});
data_saddle.push({
lat: 3.5658777778e+01,
lng: 1.3499988889e+02,
content:'Saddle = 54.400002 pos = 35.6588,134.9999 diff = 260.200012'
});
data_peak.push({
lat: 3.5666222222e+01,
lng: 1.3499988889e+02,
cert : false,
content:' Peak = 290.500000 pos = 35.6662,134.9999 diff = 169.600006'
});
data_saddle.push({
lat: 3.5670111111e+01,
lng: 1.3499988889e+02,
content:'Saddle = 120.900002 pos = 35.6701,134.9999 diff = 169.600006'
});
data_peak.push({
lat: 3.5331555556e+01,
lng: 1.3278411111e+02,
cert : false,
content:' Peak = 235.800003 pos = 35.3316,132.7841 diff = 179.100006'
});
data_saddle.push({
lat: 3.5325222222e+01,
lng: 1.3279444444e+02,
content:'Saddle = 56.700001 pos = 35.3252,132.7944 diff = 179.100006'
});
data_peak.push({
lat: 3.5526000000e+01,
lng: 1.3429333333e+02,
cert : false,
content:' Peak = 240.399994 pos = 35.5260,134.2933 diff = 173.599991'
});
data_saddle.push({
lat: 3.5515222222e+01,
lng: 1.3429755556e+02,
content:'Saddle = 66.800003 pos = 35.5152,134.2976 diff = 173.599991'
});
data_peak.push({
lat: 3.5567111111e+01,
lng: 1.3428266667e+02,
cert : true,
content:'Name = JA/TT-050(JA/TT-050) peak = 313.600006 pos = 35.5671,134.2827 diff = 246.300003'
});
data_saddle.push({
lat: 3.5565444445e+01,
lng: 1.3428944444e+02,
content:'Saddle = 67.300003 pos = 35.5654,134.2894 diff = 246.300003'
});
data_peak.push({
lat: 3.5428444445e+01,
lng: 1.3424266667e+02,
cert : true,
content:'Name = JA/TT-048(JA/TT-048) peak = 335.399994 pos = 35.4284,134.2427 diff = 266.299988'
});
data_saddle.push({
lat: 3.5427777778e+01,
lng: 1.3426044444e+02,
content:'Saddle = 69.099998 pos = 35.4278,134.2604 diff = 266.299988'
});
data_peak.push({
lat: 3.5623111111e+01,
lng: 1.3483166667e+02,
cert : false,
content:' Peak = 261.799988 pos = 35.6231,134.8317 diff = 188.099991'
});
data_saddle.push({
lat: 3.5610444445e+01,
lng: 1.3483533333e+02,
content:'Saddle = 73.699997 pos = 35.6104,134.8353 diff = 188.099991'
});
data_peak.push({
lat: 3.5358111111e+01,
lng: 1.3283022222e+02,
cert : true,
content:'Name = JA/SN-120(JA/SN-120) peak = 364.700012 pos = 35.3581,132.8302 diff = 286.500000'
});
data_saddle.push({
lat: 3.5368888889e+01,
lng: 1.3290266667e+02,
content:'Saddle = 78.199997 pos = 35.3689,132.9027 diff = 286.500000'
});
data_peak.push({
lat: 3.5351777778e+01,
lng: 1.3286266667e+02,
cert : false,
content:' Peak = 316.000000 pos = 35.3518,132.8627 diff = 178.000000'
});
data_saddle.push({
lat: 3.5360000000e+01,
lng: 1.3284833333e+02,
content:'Saddle = 138.000000 pos = 35.3600,132.8483 diff = 178.000000'
});
data_peak.push({
lat: 3.5387888889e+01,
lng: 1.3330366667e+02,
cert : false,
content:' Peak = 256.500000 pos = 35.3879,133.3037 diff = 178.199997'
});
data_saddle.push({
lat: 3.5385555556e+01,
lng: 1.3331433333e+02,
content:'Saddle = 78.300003 pos = 35.3856,133.3143 diff = 178.199997'
});
data_peak.push({
lat: 3.5381888889e+01,
lng: 1.3331933333e+02,
cert : true,
content:'Name = Yougaisan(JA/TT-051) peak = 280.799988 pos = 35.3819,133.3193 diff = 192.999985'
});
data_saddle.push({
lat: 3.5346222222e+01,
lng: 1.3329533333e+02,
content:'Saddle = 87.800003 pos = 35.3462,133.2953 diff = 192.999985'
});
data_peak.push({
lat: 3.5354888889e+01,
lng: 1.3334833333e+02,
cert : true,
content:'Name = JA/TT-049(JA/TT-049) peak = 331.000000 pos = 35.3549,133.3483 diff = 242.100006'
});
data_saddle.push({
lat: 3.5329888889e+01,
lng: 1.3336666667e+02,
content:'Saddle = 88.900002 pos = 35.3299,133.3667 diff = 242.100006'
});
data_peak.push({
lat: 3.5635888889e+01,
lng: 1.3449222222e+02,
cert : true,
content:'Name = JA/HG-191(JA/HG-191) peak = 281.600006 pos = 35.6359,134.4922 diff = 183.200012'
});
data_saddle.push({
lat: 3.5639111111e+01,
lng: 1.3449133333e+02,
content:'Saddle = 98.400002 pos = 35.6391,134.4913 diff = 183.200012'
});
data_peak.push({
lat: 3.5378666667e+01,
lng: 1.3479855556e+02,
cert : false,
content:' Peak = 372.500000 pos = 35.3787,134.7986 diff = 273.700012'
});
data_saddle.push({
lat: 3.5369333334e+01,
lng: 1.3479855556e+02,
content:'Saddle = 98.800003 pos = 35.3693,134.7986 diff = 273.700012'
});
data_peak.push({
lat: 3.5523000000e+01,
lng: 1.3497100000e+02,
cert : true,
content:'Name = JA/HG-064(JA/HG-064) peak = 691.799988 pos = 35.5230,134.9710 diff = 592.000000'
});
data_saddle.push({
lat: 3.5487000000e+01,
lng: 1.3499988889e+02,
content:'Saddle = 99.800003 pos = 35.4870,134.9999 diff = 592.000000'
});
data_peak.push({
lat: 3.5632222222e+01,
lng: 1.3487066667e+02,
cert : true,
content:'Name = JA/KT-094(JA/KT-094) peak = 335.299988 pos = 35.6322,134.8707 diff = 208.199982'
});
data_saddle.push({
lat: 3.5619000000e+01,
lng: 1.3487266667e+02,
content:'Saddle = 127.099998 pos = 35.6190,134.8727 diff = 208.199982'
});
data_peak.push({
lat: 3.5455555556e+01,
lng: 1.3487800000e+02,
cert : false,
content:' Peak = 321.299988 pos = 35.4556,134.8780 diff = 181.599991'
});
data_saddle.push({
lat: 3.5459000000e+01,
lng: 1.3489477778e+02,
content:'Saddle = 139.699997 pos = 35.4590,134.8948 diff = 181.599991'
});
data_peak.push({
lat: 3.5622222222e+01,
lng: 1.3499988889e+02,
cert : false,
content:' Peak = 403.600006 pos = 35.6222,134.9999 diff = 251.300003'
});
data_saddle.push({
lat: 3.5576111111e+01,
lng: 1.3499988889e+02,
content:'Saddle = 152.300003 pos = 35.5761,134.9999 diff = 251.300003'
});
data_peak.push({
lat: 3.5580222222e+01,
lng: 1.3499988889e+02,
cert : false,
content:' Peak = 350.500000 pos = 35.5802,134.9999 diff = 174.500000'
});
data_saddle.push({
lat: 3.5586111111e+01,
lng: 1.3499977778e+02,
content:'Saddle = 176.000000 pos = 35.5861,134.9998 diff = 174.500000'
});
data_peak.push({
lat: 3.5586444445e+01,
lng: 1.3484855556e+02,
cert : false,
content:' Peak = 452.799988 pos = 35.5864,134.8486 diff = 274.399994'
});
data_saddle.push({
lat: 3.5585333333e+01,
lng: 1.3486233333e+02,
content:'Saddle = 178.399994 pos = 35.5853,134.8623 diff = 274.399994'
});
data_peak.push({
lat: 3.5480888889e+01,
lng: 1.3493966667e+02,
cert : true,
content:'Name = JA/HG-167(JA/HG-167) peak = 390.600006 pos = 35.4809,134.9397 diff = 172.600006'
});
data_saddle.push({
lat: 3.5491888889e+01,
lng: 1.3493977778e+02,
content:'Saddle = 218.000000 pos = 35.4919,134.9398 diff = 172.600006'
});
data_peak.push({
lat: 3.5558333334e+01,
lng: 1.3499988889e+02,
cert : false,
content:' Peak = 398.700012 pos = 35.5583,134.9999 diff = 157.900009'
});
data_saddle.push({
lat: 3.5546333334e+01,
lng: 1.3499988889e+02,
content:'Saddle = 240.800003 pos = 35.5463,134.9999 diff = 157.900009'
});
data_peak.push({
lat: 3.5551222222e+01,
lng: 1.3495422222e+02,
cert : false,
content:' Peak = 441.600006 pos = 35.5512,134.9542 diff = 163.100006'
});
data_saddle.push({
lat: 3.5541555556e+01,
lng: 1.3496377778e+02,
content:'Saddle = 278.500000 pos = 35.5416,134.9638 diff = 163.100006'
});
data_peak.push({
lat: 3.5479666667e+01,
lng: 1.3490411111e+02,
cert : false,
content:' Peak = 473.399994 pos = 35.4797,134.9041 diff = 190.199982'
});
data_saddle.push({
lat: 3.5490333334e+01,
lng: 1.3490500000e+02,
content:'Saddle = 283.200012 pos = 35.4903,134.9050 diff = 190.199982'
});
data_peak.push({
lat: 3.5512555556e+01,
lng: 1.3492677778e+02,
cert : true,
content:'Name = JA/HG-079(JA/HG-079) peak = 640.500000 pos = 35.5126,134.9268 diff = 187.000000'
});
data_saddle.push({
lat: 3.5516111111e+01,
lng: 1.3495366667e+02,
content:'Saddle = 453.500000 pos = 35.5161,134.9537 diff = 187.000000'
});
data_peak.push({
lat: 3.5532555556e+01,
lng: 1.3427000000e+02,
cert : true,
content:'Name = JA/TT-047(JA/TT-047) peak = 356.000000 pos = 35.5326,134.2700 diff = 248.199997'
});
data_saddle.push({
lat: 3.5514333334e+01,
lng: 1.3428066667e+02,
content:'Saddle = 107.800003 pos = 35.5143,134.2807 diff = 248.199997'
});
data_peak.push({
lat: 3.5646000000e+01,
lng: 1.3457100000e+02,
cert : false,
content:' Peak = 283.100006 pos = 35.6460,134.5710 diff = 166.100006'
});
data_saddle.push({
lat: 3.5646444445e+01,
lng: 1.3458144444e+02,
content:'Saddle = 117.000000 pos = 35.6464,134.5814 diff = 166.100006'
});
data_peak.push({
lat: 3.5475444445e+01,
lng: 1.3497800000e+02,
cert : true,
content:'Name = JA/HG-071(JA/HG-071) peak = 664.000000 pos = 35.4754,134.9780 diff = 538.000000'
});
data_saddle.push({
lat: 3.5437555556e+01,
lng: 1.3499988889e+02,
content:'Saddle = 126.000000 pos = 35.4376,134.9999 diff = 538.000000'
});
data_peak.push({
lat: 3.5459444445e+01,
lng: 1.3499988889e+02,
cert : false,
content:' Peak = 541.200012 pos = 35.4594,134.9999 diff = 218.600006'
});
data_saddle.push({
lat: 3.5470444445e+01,
lng: 1.3499011111e+02,
content:'Saddle = 322.600006 pos = 35.4704,134.9901 diff = 218.600006'
});
data_peak.push({
lat: 3.5514555556e+01,
lng: 1.3476244444e+02,
cert : false,
content:' Peak = 288.299988 pos = 35.5146,134.7624 diff = 161.699982'
});
data_saddle.push({
lat: 3.5500222222e+01,
lng: 1.3474100000e+02,
content:'Saddle = 126.599998 pos = 35.5002,134.7410 diff = 161.699982'
});
data_peak.push({
lat: 3.4962777778e+01,
lng: 1.3219877778e+02,
cert : false,
content:' Peak = 280.500000 pos = 34.9628,132.1988 diff = 152.500000'
});
data_saddle.push({
lat: 3.4964777778e+01,
lng: 1.3221633333e+02,
content:'Saddle = 128.000000 pos = 34.9648,132.2163 diff = 152.500000'
});
data_peak.push({
lat: 3.5642555556e+01,
lng: 1.3467422222e+02,
cert : true,
content:'Name = JA/HG-173(JA/HG-173) peak = 364.600006 pos = 35.6426,134.6742 diff = 231.500000'
});
data_saddle.push({
lat: 3.5637444445e+01,
lng: 1.3467022222e+02,
content:'Saddle = 133.100006 pos = 35.6374,134.6702 diff = 231.500000'
});
data_peak.push({
lat: 3.5319222222e+01,
lng: 1.3487088889e+02,
cert : true,
content:'Name = JA/HG-178(JA/HG-178) peak = 351.399994 pos = 35.3192,134.8709 diff = 214.500000'
});
data_saddle.push({
lat: 3.5307777778e+01,
lng: 1.3486755556e+02,
content:'Saddle = 136.899994 pos = 35.3078,134.8676 diff = 214.500000'
});
data_peak.push({
lat: 3.5457111111e+01,
lng: 1.3495033333e+02,
cert : false,
content:' Peak = 290.100006 pos = 35.4571,134.9503 diff = 152.900009'
});
data_saddle.push({
lat: 3.5453555556e+01,
lng: 1.3495422222e+02,
content:'Saddle = 137.199997 pos = 35.4536,134.9542 diff = 152.900009'
});
data_peak.push({
lat: 3.5450888889e+01,
lng: 1.3480544444e+02,
cert : true,
content:'Name = JA/HG-147(JA/HG-147) peak = 447.399994 pos = 35.4509,134.8054 diff = 309.700012'
});
data_saddle.push({
lat: 3.5443111111e+01,
lng: 1.3481833333e+02,
content:'Saddle = 137.699997 pos = 35.4431,134.8183 diff = 309.700012'
});
data_peak.push({
lat: 3.5348333334e+01,
lng: 1.3485822222e+02,
cert : true,
content:'Name = JA/HG-179(JA/HG-179) peak = 342.399994 pos = 35.3483,134.8582 diff = 195.899994'
});
data_saddle.push({
lat: 3.5352888889e+01,
lng: 1.3485788889e+02,
content:'Saddle = 146.500000 pos = 35.3529,134.8579 diff = 195.899994'
});
data_peak.push({
lat: 3.5302555556e+01,
lng: 1.3278011111e+02,
cert : true,
content:'Name = JA/SN-122(JA/SN-122) peak = 358.399994 pos = 35.3026,132.7801 diff = 207.399994'
});
data_saddle.push({
lat: 3.5296333334e+01,
lng: 1.3278611111e+02,
content:'Saddle = 151.000000 pos = 35.2963,132.7861 diff = 207.399994'
});
data_peak.push({
lat: 3.5390000000e+01,
lng: 1.3477866667e+02,
cert : false,
content:' Peak = 326.799988 pos = 35.3900,134.7787 diff = 170.299988'
});
data_saddle.push({
lat: 3.5385777778e+01,
lng: 1.3476855556e+02,
content:'Saddle = 156.500000 pos = 35.3858,134.7686 diff = 170.299988'
});
data_peak.push({
lat: 3.5320666667e+01,
lng: 1.3328844444e+02,
cert : true,
content:'Name = JA/SN-123(JA/SN-123) peak = 360.399994 pos = 35.3207,133.2884 diff = 202.699997'
});
data_saddle.push({
lat: 3.5311444445e+01,
lng: 1.3329900000e+02,
content:'Saddle = 157.699997 pos = 35.3114,133.2990 diff = 202.699997'
});
data_peak.push({
lat: 3.5544666667e+01,
lng: 1.3430688889e+02,
cert : true,
content:'Name = JA/TT-046(JA/TT-046) peak = 391.500000 pos = 35.5447,134.3069 diff = 229.300003'
});
data_saddle.push({
lat: 3.5522333334e+01,
lng: 1.3432688889e+02,
content:'Saddle = 162.199997 pos = 35.5223,134.3269 diff = 229.300003'
});
data_peak.push({
lat: 3.5089666667e+01,
lng: 1.3237788889e+02,
cert : false,
content:' Peak = 336.399994 pos = 35.0897,132.3779 diff = 168.799988'
});
data_saddle.push({
lat: 3.5086222223e+01,
lng: 1.3238222222e+02,
content:'Saddle = 167.600006 pos = 35.0862,132.3822 diff = 168.799988'
});
data_peak.push({
lat: 3.5480222222e+01,
lng: 1.3474400000e+02,
cert : true,
content:'Name = JA/HG-182(JA/HG-182) peak = 331.399994 pos = 35.4802,134.7440 diff = 163.599991'
});
data_saddle.push({
lat: 3.5479666667e+01,
lng: 1.3472066667e+02,
content:'Saddle = 167.800003 pos = 35.4797,134.7207 diff = 163.599991'
});
data_peak.push({
lat: 3.5543222222e+01,
lng: 1.3435700000e+02,
cert : false,
content:' Peak = 327.000000 pos = 35.5432,134.3570 diff = 158.699997'
});
data_saddle.push({
lat: 3.5531333334e+01,
lng: 1.3436644444e+02,
content:'Saddle = 168.300003 pos = 35.5313,134.3664 diff = 158.699997'
});
data_peak.push({
lat: 3.4982333334e+01,
lng: 1.3228766667e+02,
cert : false,
content:' Peak = 351.899994 pos = 34.9823,132.2877 diff = 164.699997'
});
data_saddle.push({
lat: 3.4977000000e+01,
lng: 1.3228644444e+02,
content:'Saddle = 187.199997 pos = 34.9770,132.2864 diff = 164.699997'
});
data_peak.push({
lat: 3.5407444445e+01,
lng: 1.3490288889e+02,
cert : true,
content:'Name = JA/HG-038(JA/HG-038) peak = 842.599976 pos = 35.4074,134.9029 diff = 649.399963'
});
data_saddle.push({
lat: 3.5333111111e+01,
lng: 1.3492833333e+02,
content:'Saddle = 193.199997 pos = 35.3331,134.9283 diff = 649.399963'
});
data_peak.push({
lat: 3.5335000000e+01,
lng: 1.3489233333e+02,
cert : true,
content:'Name = JA/HG-128(JA/HG-128) peak = 500.500000 pos = 35.3350,134.8923 diff = 291.600006'
});
data_saddle.push({
lat: 3.5338666667e+01,
lng: 1.3491466667e+02,
content:'Saddle = 208.899994 pos = 35.3387,134.9147 diff = 291.600006'
});
data_peak.push({
lat: 3.5379888889e+01,
lng: 1.3485533333e+02,
cert : false,
content:' Peak = 532.400024 pos = 35.3799,134.8553 diff = 185.000031'
});
data_saddle.push({
lat: 3.5389333334e+01,
lng: 1.3487722222e+02,
content:'Saddle = 347.399994 pos = 35.3893,134.8772 diff = 185.000031'
});
data_peak.push({
lat: 3.5399888889e+01,
lng: 1.3496333333e+02,
cert : true,
content:'Name = JA/KT-015(JA/KT-015) peak = 783.400024 pos = 35.3999,134.9633 diff = 426.100037'
});
data_saddle.push({
lat: 3.5409444445e+01,
lng: 1.3495177778e+02,
content:'Saddle = 357.299988 pos = 35.4094,134.9518 diff = 426.100037'
});
data_peak.push({
lat: 3.5373555556e+01,
lng: 1.3499222222e+02,
cert : true,
content:'Name = JA/KT-021(JA/KT-021) peak = 730.000000 pos = 35.3736,134.9922 diff = 341.600006'
});
data_saddle.push({
lat: 3.5393444445e+01,
lng: 1.3498811111e+02,
content:'Saddle = 388.399994 pos = 35.3934,134.9881 diff = 341.600006'
});
data_peak.push({
lat: 3.5399666667e+01,
lng: 1.3482066667e+02,
cert : false,
content:' Peak = 553.400024 pos = 35.3997,134.8207 diff = 191.200012'
});
data_saddle.push({
lat: 3.5410222222e+01,
lng: 1.3482822222e+02,
content:'Saddle = 362.200012 pos = 35.4102,134.8282 diff = 191.200012'
});
data_peak.push({
lat: 3.5419777778e+01,
lng: 1.3484088889e+02,
cert : true,
content:'Name = JA/HG-116(JA/HG-116) peak = 531.799988 pos = 35.4198,134.8409 diff = 165.099976'
});
data_saddle.push({
lat: 3.5408555556e+01,
lng: 1.3485077778e+02,
content:'Saddle = 366.700012 pos = 35.4086,134.8508 diff = 165.099976'
});
data_peak.push({
lat: 3.5405000000e+01,
lng: 1.3485633333e+02,
cert : false,
content:' Peak = 560.500000 pos = 35.4050,134.8563 diff = 193.200012'
});
data_saddle.push({
lat: 3.5403888889e+01,
lng: 1.3487822222e+02,
content:'Saddle = 367.299988 pos = 35.4039,134.8782 diff = 193.200012'
});
data_peak.push({
lat: 3.4690111112e+01,
lng: 1.3219666667e+02,
cert : true,
content:'Name = Garyuuzan(JA/HS-009) peak = 1221.400024 pos = 34.6901,132.1967 diff = 1026.400024'
});
data_saddle.push({
lat: 3.4666777778e+01,
lng: 1.3271733333e+02,
content:'Saddle = 195.000000 pos = 34.6668,132.7173 diff = 1026.400024'
});
data_peak.push({
lat: 3.4955888889e+01,
lng: 1.3247722222e+02,
cert : true,
content:'Name = JA/SN-108(JA/SN-108) peak = 445.100006 pos = 34.9559,132.4772 diff = 248.200012'
});
data_saddle.push({
lat: 3.4958666667e+01,
lng: 1.3248411111e+02,
content:'Saddle = 196.899994 pos = 34.9587,132.4841 diff = 248.200012'
});
data_peak.push({
lat: 3.4923000000e+01,
lng: 1.3229033333e+02,
cert : false,
content:' Peak = 370.500000 pos = 34.9230,132.2903 diff = 163.000000'
});
data_saddle.push({
lat: 3.4922333334e+01,
lng: 1.3227000000e+02,
content:'Saddle = 207.500000 pos = 34.9223,132.2700 diff = 163.000000'
});
data_peak.push({
lat: 3.4921000000e+01,
lng: 1.3219700000e+02,
cert : true,
content:'Name = JA/SN-115(JA/SN-115) peak = 416.500000 pos = 34.9210,132.1970 diff = 199.600006'
});
data_saddle.push({
lat: 3.4911444445e+01,
lng: 1.3220522222e+02,
content:'Saddle = 216.899994 pos = 34.9114,132.2052 diff = 199.600006'
});
data_peak.push({
lat: 3.4878777778e+01,
lng: 1.3213755556e+02,
cert : true,
content:'Name = JA/SN-114(JA/SN-114) peak = 413.799988 pos = 34.8788,132.1376 diff = 196.099991'
});
data_saddle.push({
lat: 3.4871111112e+01,
lng: 1.3215588889e+02,
content:'Saddle = 217.699997 pos = 34.8711,132.1559 diff = 196.099991'
});
data_peak.push({
lat: 3.4960000000e+01,
lng: 1.3227733333e+02,
cert : true,
content:'Name = JA/SN-094(JA/SN-094) peak = 505.000000 pos = 34.9600,132.2773 diff = 280.600006'
});
data_saddle.push({
lat: 3.4904555556e+01,
lng: 1.3223211111e+02,
content:'Saddle = 224.399994 pos = 34.9046,132.2321 diff = 280.600006'
});
data_peak.push({
lat: 3.4919444445e+01,
lng: 1.3225088889e+02,
cert : true,
content:'Name = JA/SN-099(JA/SN-099) peak = 470.299988 pos = 34.9194,132.2509 diff = 213.399994'
});
data_saddle.push({
lat: 3.4935111112e+01,
lng: 1.3225266667e+02,
content:'Saddle = 256.899994 pos = 34.9351,132.2527 diff = 213.399994'
});
data_peak.push({
lat: 3.4984111112e+01,
lng: 1.3223733333e+02,
cert : true,
content:'Name = JA/SN-102(JA/SN-102) peak = 470.000000 pos = 34.9841,132.2373 diff = 212.299988'
});
data_saddle.push({
lat: 3.4969111112e+01,
lng: 1.3225200000e+02,
content:'Saddle = 257.700012 pos = 34.9691,132.2520 diff = 212.299988'
});
data_peak.push({
lat: 3.4951111112e+01,
lng: 1.3228600000e+02,
cert : false,
content:' Peak = 500.299988 pos = 34.9511,132.2860 diff = 152.099976'
});
data_saddle.push({
lat: 3.4953666667e+01,
lng: 1.3228066667e+02,
content:'Saddle = 348.200012 pos = 34.9537,132.2807 diff = 152.099976'
});
data_peak.push({
lat: 3.4850777778e+01,
lng: 1.3269377778e+02,
cert : true,
content:'Name = JA/SN-107(JA/SN-107) peak = 447.100006 pos = 34.8508,132.6938 diff = 200.600006'
});
data_saddle.push({
lat: 3.4851333334e+01,
lng: 1.3267933333e+02,
content:'Saddle = 246.500000 pos = 34.8513,132.6793 diff = 200.600006'
});
data_peak.push({
lat: 3.4952222223e+01,
lng: 1.3235866667e+02,
cert : true,
content:'Name = JA/SN-111(JA/SN-111) peak = 431.500000 pos = 34.9522,132.3587 diff = 169.200012'
});
data_saddle.push({
lat: 3.4949888889e+01,
lng: 1.3236666667e+02,
content:'Saddle = 262.299988 pos = 34.9499,132.3667 diff = 169.200012'
});
data_peak.push({
lat: 3.4878222223e+01,
lng: 1.3264044444e+02,
cert : true,
content:'Name = JA/SN-095(JA/SN-095) peak = 496.899994 pos = 34.8782,132.6404 diff = 230.100006'
});
data_saddle.push({
lat: 3.4888444445e+01,
lng: 1.3261811111e+02,
content:'Saddle = 266.799988 pos = 34.8884,132.6181 diff = 230.100006'
});
data_peak.push({
lat: 3.4837777778e+01,
lng: 1.3208166667e+02,
cert : true,
content:'Name = JA/SN-092(JA/SN-092) peak = 513.500000 pos = 34.8378,132.0817 diff = 241.000000'
});
data_saddle.push({
lat: 3.4837333334e+01,
lng: 1.3210722222e+02,
content:'Saddle = 272.500000 pos = 34.8373,132.1072 diff = 241.000000'
});
data_peak.push({
lat: 3.4794333334e+01,
lng: 1.3282044444e+02,
cert : true,
content:'Name = JA/HS-174(JA/HS-174) peak = 490.500000 pos = 34.7943,132.8204 diff = 215.700012'
});
data_saddle.push({
lat: 3.4743222223e+01,
lng: 1.3269966667e+02,
content:'Saddle = 274.799988 pos = 34.7432,132.6997 diff = 215.700012'
});
data_peak.push({
lat: 3.4873888889e+01,
lng: 1.3228766667e+02,
cert : true,
content:'Name = JA/SN-104(JA/SN-104) peak = 461.399994 pos = 34.8739,132.2877 diff = 183.899994'
});
data_saddle.push({
lat: 3.4867222223e+01,
lng: 1.3229188889e+02,
content:'Saddle = 277.500000 pos = 34.8672,132.2919 diff = 183.899994'
});
data_peak.push({
lat: 3.4845444445e+01,
lng: 1.3266544444e+02,
cert : false,
content:' Peak = 440.899994 pos = 34.8454,132.6654 diff = 153.399994'
});
data_saddle.push({
lat: 3.4845444445e+01,
lng: 1.3266100000e+02,
content:'Saddle = 287.500000 pos = 34.8454,132.6610 diff = 153.399994'
});
data_peak.push({
lat: 3.4916444445e+01,
lng: 1.3230655556e+02,
cert : true,
content:'Name = JA/SN-105(JA/SN-105) peak = 453.100006 pos = 34.9164,132.3066 diff = 165.000000'
});
data_saddle.push({
lat: 3.4910444445e+01,
lng: 1.3231111111e+02,
content:'Saddle = 288.100006 pos = 34.9104,132.3111 diff = 165.000000'
});
data_peak.push({
lat: 3.4797222223e+01,
lng: 1.3272722222e+02,
cert : true,
content:'Name = JA/HS-177(JA/HS-177) peak = 486.100006 pos = 34.7972,132.7272 diff = 187.300018'
});
data_saddle.push({
lat: 3.4784111112e+01,
lng: 1.3271344444e+02,
content:'Saddle = 298.799988 pos = 34.7841,132.7134 diff = 187.300018'
});
data_peak.push({
lat: 3.5021888889e+01,
lng: 1.3257100000e+02,
cert : true,
content:'Name = JA/SN-086(JA/SN-086) peak = 526.400024 pos = 35.0219,132.5710 diff = 219.000031'
});
data_saddle.push({
lat: 3.5018888889e+01,
lng: 1.3257933333e+02,
content:'Saddle = 307.399994 pos = 35.0189,132.5793 diff = 219.000031'
});
data_peak.push({
lat: 3.4821777778e+01,
lng: 1.3200688889e+02,
cert : true,
content:'Name = JA/SN-064(JA/SN-064) peak = 598.500000 pos = 34.8218,132.0069 diff = 290.299988'
});
data_saddle.push({
lat: 3.4811111112e+01,
lng: 1.3204588889e+02,
content:'Saddle = 308.200012 pos = 34.8111,132.0459 diff = 290.299988'
});
data_peak.push({
lat: 3.4948555556e+01,
lng: 1.3262711111e+02,
cert : false,
content:' Peak = 491.799988 pos = 34.9486,132.6271 diff = 179.500000'
});
data_saddle.push({
lat: 3.4960555556e+01,
lng: 1.3259266667e+02,
content:'Saddle = 312.299988 pos = 34.9606,132.5927 diff = 179.500000'
});
data_peak.push({
lat: 3.4672333334e+01,
lng: 1.3265455556e+02,
cert : false,
content:' Peak = 528.299988 pos = 34.6723,132.6546 diff = 213.099976'
});
data_saddle.push({
lat: 3.4666777778e+01,
lng: 1.3263700000e+02,
content:'Saddle = 315.200012 pos = 34.6668,132.6370 diff = 213.099976'
});
data_peak.push({
lat: 3.4917555556e+01,
lng: 1.3250177778e+02,
cert : true,
content:'Name = Kanzan(JA/SN-025) peak = 862.400024 pos = 34.9176,132.5018 diff = 534.200012'
});
data_saddle.push({
lat: 3.4889555556e+01,
lng: 1.3253433333e+02,
content:'Saddle = 328.200012 pos = 34.8896,132.5343 diff = 534.200012'
});
data_peak.push({
lat: 3.4996444445e+01,
lng: 1.3255111111e+02,
cert : true,
content:'Name = JA/SN-058(JA/SN-058) peak = 631.599976 pos = 34.9964,132.5511 diff = 283.799988'
});
data_saddle.push({
lat: 3.4971222223e+01,
lng: 1.3256288889e+02,
content:'Saddle = 347.799988 pos = 34.9712,132.5629 diff = 283.799988'
});
data_peak.push({
lat: 3.4983444445e+01,
lng: 1.3257188889e+02,
cert : true,
content:'Name = JA/SN-078(JA/SN-078) peak = 563.500000 pos = 34.9834,132.5719 diff = 195.899994'
});
data_saddle.push({
lat: 3.4984555556e+01,
lng: 1.3256477778e+02,
content:'Saddle = 367.600006 pos = 34.9846,132.5648 diff = 195.899994'
});
data_peak.push({
lat: 3.5015000000e+01,
lng: 1.3260133333e+02,
cert : true,
content:'Name = JA/SN-060(JA/SN-060) peak = 627.299988 pos = 35.0150,132.6013 diff = 258.299988'
});
data_saddle.push({
lat: 3.4998888889e+01,
lng: 1.3256700000e+02,
content:'Saddle = 369.000000 pos = 34.9989,132.5670 diff = 258.299988'
});
data_peak.push({
lat: 3.4919444445e+01,
lng: 1.3258288889e+02,
cert : true,
content:'Name = JA/SN-057(JA/SN-057) peak = 643.900024 pos = 34.9194,132.5829 diff = 285.800018'
});
data_saddle.push({
lat: 3.4926777778e+01,
lng: 1.3255333333e+02,
content:'Saddle = 358.100006 pos = 34.9268,132.5533 diff = 285.800018'
});
data_peak.push({
lat: 3.4932222223e+01,
lng: 1.3256000000e+02,
cert : false,
content:' Peak = 540.500000 pos = 34.9322,132.5600 diff = 152.200012'
});
data_saddle.push({
lat: 3.4923555556e+01,
lng: 1.3255855556e+02,
content:'Saddle = 388.299988 pos = 34.9236,132.5586 diff = 152.200012'
});
data_peak.push({
lat: 3.4966222223e+01,
lng: 1.3257733333e+02,
cert : true,
content:'Name = Karataniyama(JA/SN-056) peak = 654.700012 pos = 34.9662,132.5773 diff = 287.200012'
});
data_saddle.push({
lat: 3.4953333334e+01,
lng: 1.3255011111e+02,
content:'Saddle = 367.500000 pos = 34.9533,132.5501 diff = 287.200012'
});
data_peak.push({
lat: 3.4956222223e+01,
lng: 1.3252000000e+02,
cert : true,
content:'Name = JA/SN-044(JA/SN-044) peak = 714.000000 pos = 34.9562,132.5200 diff = 216.100006'
});
data_saddle.push({
lat: 3.4937777778e+01,
lng: 1.3250744444e+02,
content:'Saddle = 497.899994 pos = 34.9378,132.5074 diff = 216.100006'
});
data_peak.push({
lat: 3.4878222223e+01,
lng: 1.3247322222e+02,
cert : false,
content:' Peak = 523.299988 pos = 34.8782,132.4732 diff = 176.599976'
});
data_saddle.push({
lat: 3.4871444445e+01,
lng: 1.3247044444e+02,
content:'Saddle = 346.700012 pos = 34.8714,132.4704 diff = 176.599976'
});
data_peak.push({
lat: 3.4700222223e+01,
lng: 1.3268244444e+02,
cert : true,
content:'Name = JA/HS-155(JA/HS-155) peak = 555.200012 pos = 34.7002,132.6824 diff = 207.700012'
});
data_saddle.push({
lat: 3.4706888889e+01,
lng: 1.3265800000e+02,
content:'Saddle = 347.500000 pos = 34.7069,132.6580 diff = 207.700012'
});
data_peak.push({
lat: 3.4866000000e+01,
lng: 1.3251800000e+02,
cert : false,
content:' Peak = 530.299988 pos = 34.8660,132.5180 diff = 173.000000'
});
data_saddle.push({
lat: 3.4858888889e+01,
lng: 1.3251755556e+02,
content:'Saddle = 357.299988 pos = 34.8589,132.5176 diff = 173.000000'
});
data_peak.push({
lat: 3.4880444445e+01,
lng: 1.3254588889e+02,
cert : true,
content:'Name = JA/SN-091(JA/SN-091) peak = 523.599976 pos = 34.8804,132.5459 diff = 156.999969'
});
data_saddle.push({
lat: 3.4872000000e+01,
lng: 1.3252877778e+02,
content:'Saddle = 366.600006 pos = 34.8720,132.5288 diff = 156.999969'
});
data_peak.push({
lat: 3.4927222223e+01,
lng: 1.3235877778e+02,
cert : true,
content:'Name = JA/SN-067(JA/SN-067) peak = 590.900024 pos = 34.9272,132.3588 diff = 233.600037'
});
data_saddle.push({
lat: 3.4923666667e+01,
lng: 1.3239344444e+02,
content:'Saddle = 357.299988 pos = 34.9237,132.3934 diff = 233.600037'
});
data_peak.push({
lat: 3.4935666667e+01,
lng: 1.3238488889e+02,
cert : true,
content:'Name = JA/SN-071(JA/SN-071) peak = 580.200012 pos = 34.9357,132.3849 diff = 222.600006'
});
data_saddle.push({
lat: 3.4935333334e+01,
lng: 1.3237955556e+02,
content:'Saddle = 357.600006 pos = 34.9353,132.3796 diff = 222.600006'
});
data_peak.push({
lat: 3.4831000000e+01,
lng: 1.3214711111e+02,
cert : true,
content:'Name = JA/SN-051(JA/SN-051) peak = 665.500000 pos = 34.8310,132.1471 diff = 298.799988'
});
data_saddle.push({
lat: 3.4821777778e+01,
lng: 1.3215511111e+02,
content:'Saddle = 366.700012 pos = 34.8218,132.1551 diff = 298.799988'
});
data_peak.push({
lat: 3.4907000000e+01,
lng: 1.3241366667e+02,
cert : true,
content:'Name = JA/SN-028(JA/SN-028) peak = 824.500000 pos = 34.9070,132.4137 diff = 455.600006'
});
data_saddle.push({
lat: 3.4877222223e+01,
lng: 1.3239977778e+02,
content:'Saddle = 368.899994 pos = 34.8772,132.3998 diff = 455.600006'
});
data_peak.push({
lat: 3.4903000000e+01,
lng: 1.3235455556e+02,
cert : true,
content:'Name = JA/SN-046(JA/SN-046) peak = 715.000000 pos = 34.9030,132.3546 diff = 307.700012'
});
data_saddle.push({
lat: 3.4903111112e+01,
lng: 1.3237411111e+02,
content:'Saddle = 407.299988 pos = 34.9031,132.3741 diff = 307.700012'
});
data_peak.push({
lat: 3.4928888889e+01,
lng: 1.3245888889e+02,
cert : false,
content:' Peak = 590.700012 pos = 34.9289,132.4589 diff = 163.600006'
});
data_saddle.push({
lat: 3.4929555556e+01,
lng: 1.3245400000e+02,
content:'Saddle = 427.100006 pos = 34.9296,132.4540 diff = 163.600006'
});
data_peak.push({
lat: 3.4918555556e+01,
lng: 1.3243044444e+02,
cert : false,
content:' Peak = 793.099976 pos = 34.9186,132.4304 diff = 276.299988'
});
data_saddle.push({
lat: 3.4914000000e+01,
lng: 1.3242088889e+02,
content:'Saddle = 516.799988 pos = 34.9140,132.4209 diff = 276.299988'
});
data_peak.push({
lat: 3.4790888889e+01,
lng: 1.3265566667e+02,
cert : true,
content:'Name = JA/HS-151(JA/HS-151) peak = 561.900024 pos = 34.7909,132.6557 diff = 173.600037'
});
data_saddle.push({
lat: 3.4784111112e+01,
lng: 1.3264222222e+02,
content:'Saddle = 388.299988 pos = 34.7841,132.6422 diff = 173.600037'
});
data_peak.push({
lat: 3.4749444445e+01,
lng: 1.3263666667e+02,
cert : true,
content:'Name = JA/HS-140(JA/HS-140) peak = 594.400024 pos = 34.7494,132.6367 diff = 187.400024'
});
data_saddle.push({
lat: 3.4744777778e+01,
lng: 1.3261155556e+02,
content:'Saddle = 407.000000 pos = 34.7448,132.6116 diff = 187.400024'
});
data_peak.push({
lat: 3.4796777778e+01,
lng: 1.3208122222e+02,
cert : true,
content:'Name = JA/SN-047(JA/SN-047) peak = 713.200012 pos = 34.7968,132.0812 diff = 296.400024'
});
data_saddle.push({
lat: 3.4804222223e+01,
lng: 1.3211677778e+02,
content:'Saddle = 416.799988 pos = 34.8042,132.1168 diff = 296.400024'
});
data_peak.push({
lat: 3.4848333334e+01,
lng: 1.3258155556e+02,
cert : true,
content:'Name = JA/SN-052(JA/SN-052) peak = 664.000000 pos = 34.8483,132.5816 diff = 227.799988'
});
data_saddle.push({
lat: 3.4830777778e+01,
lng: 1.3256922222e+02,
content:'Saddle = 436.200012 pos = 34.8308,132.5692 diff = 227.799988'
});
data_peak.push({
lat: 3.4692777778e+01,
lng: 1.3260888889e+02,
cert : true,
content:'Name = JA/HS-104(JA/HS-104) peak = 706.700012 pos = 34.6928,132.6089 diff = 269.600006'
});
data_saddle.push({
lat: 3.4691000001e+01,
lng: 1.3258844444e+02,
content:'Saddle = 437.100006 pos = 34.6910,132.5884 diff = 269.600006'
});
data_peak.push({
lat: 3.4863555556e+01,
lng: 1.3233866667e+02,
cert : false,
content:' Peak = 620.299988 pos = 34.8636,132.3387 diff = 177.199982'
});
data_saddle.push({
lat: 3.4860777778e+01,
lng: 1.3234344444e+02,
content:'Saddle = 443.100006 pos = 34.8608,132.3434 diff = 177.199982'
});
data_peak.push({
lat: 3.4866000000e+01,
lng: 1.3250044444e+02,
cert : false,
content:' Peak = 621.000000 pos = 34.8660,132.5004 diff = 174.799988'
});
data_saddle.push({
lat: 3.4859777778e+01,
lng: 1.3246133333e+02,
content:'Saddle = 446.200012 pos = 34.8598,132.4613 diff = 174.799988'
});
data_peak.push({
lat: 3.4832222223e+01,
lng: 1.3219088889e+02,
cert : true,
content:'Name = Kanagiyama(JA/SN-043) peak = 719.200012 pos = 34.8322,132.1909 diff = 271.100006'
});
data_saddle.push({
lat: 3.4826222223e+01,
lng: 1.3221611111e+02,
content:'Saddle = 448.100006 pos = 34.8262,132.2161 diff = 271.100006'
});
data_peak.push({
lat: 3.4819666667e+01,
lng: 1.3217122222e+02,
cert : false,
content:' Peak = 623.299988 pos = 34.8197,132.1712 diff = 161.199982'
});
data_saddle.push({
lat: 3.4824333334e+01,
lng: 1.3218011111e+02,
content:'Saddle = 462.100006 pos = 34.8243,132.1801 diff = 161.199982'
});
data_peak.push({
lat: 3.4834666667e+01,
lng: 1.3227644444e+02,
cert : true,
content:'Name = JA/SN-049(JA/SN-049) peak = 704.500000 pos = 34.8347,132.2764 diff = 228.100006'
});
data_saddle.push({
lat: 3.4833000000e+01,
lng: 1.3225855556e+02,
content:'Saddle = 476.399994 pos = 34.8330,132.2586 diff = 228.100006'
});
data_peak.push({
lat: 3.4755777778e+01,
lng: 1.3251877778e+02,
cert : true,
content:'Name = JA/HS-120(JA/HS-120) peak = 654.700012 pos = 34.7558,132.5188 diff = 177.900024'
});
data_saddle.push({
lat: 3.4765666667e+01,
lng: 1.3252777778e+02,
content:'Saddle = 476.799988 pos = 34.7657,132.5278 diff = 177.900024'
});
data_peak.push({
lat: 3.4721555556e+01,
lng: 1.3259322222e+02,
cert : true,
content:'Name = JA/HS-099(JA/HS-099) peak = 715.200012 pos = 34.7216,132.5932 diff = 236.700012'
});
data_saddle.push({
lat: 3.4745333334e+01,
lng: 1.3258033333e+02,
content:'Saddle = 478.500000 pos = 34.7453,132.5803 diff = 236.700012'
});
data_peak.push({
lat: 3.4746111112e+01,
lng: 1.3259022222e+02,
cert : false,
content:' Peak = 632.900024 pos = 34.7461,132.5902 diff = 150.200012'
});
data_saddle.push({
lat: 3.4728777778e+01,
lng: 1.3258944444e+02,
content:'Saddle = 482.700012 pos = 34.7288,132.5894 diff = 150.200012'
});
data_peak.push({
lat: 3.4735333334e+01,
lng: 1.3248688889e+02,
cert : true,
content:'Name = JA/HS-105(JA/HS-105) peak = 705.200012 pos = 34.7353,132.4869 diff = 217.200012'
});
data_saddle.push({
lat: 3.4738222223e+01,
lng: 1.3247211111e+02,
content:'Saddle = 488.000000 pos = 34.7382,132.4721 diff = 217.200012'
});
data_peak.push({
lat: 3.4862444445e+01,
lng: 1.3241066667e+02,
cert : true,
content:'Name = JA/SN-024(JA/SN-024) peak = 886.799988 pos = 34.8624,132.4107 diff = 398.599976'
});
data_saddle.push({
lat: 3.4832111112e+01,
lng: 1.3244155556e+02,
content:'Saddle = 488.200012 pos = 34.8321,132.4416 diff = 398.599976'
});
data_peak.push({
lat: 3.4839888889e+01,
lng: 1.3241466667e+02,
cert : false,
content:' Peak = 693.500000 pos = 34.8399,132.4147 diff = 150.900024'
});
data_saddle.push({
lat: 3.4846444445e+01,
lng: 1.3242122222e+02,
content:'Saddle = 542.599976 pos = 34.8464,132.4212 diff = 150.900024'
});
data_peak.push({
lat: 3.4861000000e+01,
lng: 1.3237355556e+02,
cert : false,
content:' Peak = 804.000000 pos = 34.8610,132.3736 diff = 242.299988'
});
data_saddle.push({
lat: 3.4860111112e+01,
lng: 1.3238755556e+02,
content:'Saddle = 561.700012 pos = 34.8601,132.3876 diff = 242.299988'
});
data_peak.push({
lat: 3.4859444445e+01,
lng: 1.3223755556e+02,
cert : false,
content:' Peak = 663.599976 pos = 34.8594,132.2376 diff = 150.899963'
});
data_saddle.push({
lat: 3.4846444445e+01,
lng: 1.3224400000e+02,
content:'Saddle = 512.700012 pos = 34.8464,132.2440 diff = 150.899963'
});
data_peak.push({
lat: 3.4668333334e+01,
lng: 1.3243800000e+02,
cert : false,
content:' Peak = 900.000000 pos = 34.6683,132.4380 diff = 387.000000'
});
data_saddle.push({
lat: 3.4691444445e+01,
lng: 1.3242266667e+02,
content:'Saddle = 513.000000 pos = 34.6914,132.4227 diff = 387.000000'
});
data_peak.push({
lat: 3.4692333334e+01,
lng: 1.3243777778e+02,
cert : true,
content:'Name = JA/HS-058(JA/HS-058) peak = 842.400024 pos = 34.6923,132.4378 diff = 291.300049'
});
data_saddle.push({
lat: 3.4666777778e+01,
lng: 1.3246222222e+02,
content:'Saddle = 551.099976 pos = 34.6668,132.4622 diff = 291.300049'
});
data_peak.push({
lat: 3.4670555556e+01,
lng: 1.3247077778e+02,
cert : true,
content:'Name = JA/HS-059(JA/HS-059) peak = 841.900024 pos = 34.6706,132.4708 diff = 204.500000'
});
data_saddle.push({
lat: 3.4675444445e+01,
lng: 1.3246944444e+02,
content:'Saddle = 637.400024 pos = 34.6754,132.4694 diff = 204.500000'
});
data_peak.push({
lat: 3.4791444445e+01,
lng: 1.3253755556e+02,
cert : false,
content:' Peak = 891.099976 pos = 34.7914,132.5376 diff = 374.399963'
});
data_saddle.push({
lat: 3.4797222223e+01,
lng: 1.3248500000e+02,
content:'Saddle = 516.700012 pos = 34.7972,132.4850 diff = 374.399963'
});
data_peak.push({
lat: 3.4806000000e+01,
lng: 1.3261455556e+02,
cert : true,
content:'Name = JA/HS-075(JA/HS-075) peak = 791.099976 pos = 34.8060,132.6146 diff = 228.500000'
});
data_saddle.push({
lat: 3.4799666667e+01,
lng: 1.3257922222e+02,
content:'Saddle = 562.599976 pos = 34.7997,132.5792 diff = 228.500000'
});
data_peak.push({
lat: 3.4796111112e+01,
lng: 1.3250488889e+02,
cert : true,
content:'Name = JA/HS-069(JA/HS-069) peak = 812.200012 pos = 34.7961,132.5049 diff = 170.200012'
});
data_saddle.push({
lat: 3.4800555556e+01,
lng: 1.3252488889e+02,
content:'Saddle = 642.000000 pos = 34.8006,132.5249 diff = 170.200012'
});
data_peak.push({
lat: 3.4745777778e+01,
lng: 1.3246733333e+02,
cert : true,
content:'Name = JA/HS-086(JA/HS-086) peak = 752.200012 pos = 34.7458,132.4673 diff = 235.100037'
});
data_saddle.push({
lat: 3.4732333334e+01,
lng: 1.3243211111e+02,
content:'Saddle = 517.099976 pos = 34.7323,132.4321 diff = 235.100037'
});
data_peak.push({
lat: 3.4793555556e+01,
lng: 1.3245644444e+02,
cert : true,
content:'Name = JA/HS-063(JA/HS-063) peak = 825.500000 pos = 34.7936,132.4564 diff = 267.000000'
});
data_saddle.push({
lat: 3.4812666667e+01,
lng: 1.3243388889e+02,
content:'Saddle = 558.500000 pos = 34.8127,132.4339 diff = 267.000000'
});
data_peak.push({
lat: 3.4691444445e+01,
lng: 1.3240422222e+02,
cert : true,
content:'Name = JA/HS-038(JA/HS-038) peak = 952.900024 pos = 34.6914,132.4042 diff = 304.800049'
});
data_saddle.push({
lat: 3.4701111112e+01,
lng: 1.3239933333e+02,
content:'Saddle = 648.099976 pos = 34.7011,132.3993 diff = 304.800049'
});
data_peak.push({
lat: 3.4794777778e+01,
lng: 1.3238300000e+02,
cert : false,
content:' Peak = 1216.400024 pos = 34.7948,132.3830 diff = 538.000000'
});
data_saddle.push({
lat: 3.4782333334e+01,
lng: 1.3228266667e+02,
content:'Saddle = 678.400024 pos = 34.7823,132.2827 diff = 538.000000'
});
data_peak.push({
lat: 3.4681777778e+01,
lng: 1.3235344444e+02,
cert : true,
content:'Name = JA/HS-044(JA/HS-044) peak = 922.200012 pos = 34.6818,132.3534 diff = 215.400024'
});
data_saddle.push({
lat: 3.4697000001e+01,
lng: 1.3235844444e+02,
content:'Saddle = 706.799988 pos = 34.6970,132.3584 diff = 215.400024'
});
data_peak.push({
lat: 3.4724777778e+01,
lng: 1.3236344444e+02,
cert : true,
content:'Name = JA/HS-050(JA/HS-050) peak = 891.200012 pos = 34.7248,132.3634 diff = 183.600037'
});
data_saddle.push({
lat: 3.4732555556e+01,
lng: 1.3237644444e+02,
content:'Saddle = 707.599976 pos = 34.7326,132.3764 diff = 183.600037'
});
data_peak.push({
lat: 3.4720666667e+01,
lng: 1.3240555556e+02,
cert : true,
content:'Name = JA/HS-033(JA/HS-033) peak = 1001.500000 pos = 34.7207,132.4056 diff = 256.700012'
});
data_saddle.push({
lat: 3.4761000000e+01,
lng: 1.3237988889e+02,
content:'Saddle = 744.799988 pos = 34.7610,132.3799 diff = 256.700012'
});
data_peak.push({
lat: 3.4749888889e+01,
lng: 1.3239977778e+02,
cert : true,
content:'Name = JA/HS-037(JA/HS-037) peak = 965.500000 pos = 34.7499,132.3998 diff = 168.500000'
});
data_saddle.push({
lat: 3.4735777778e+01,
lng: 1.3240133333e+02,
content:'Saddle = 797.000000 pos = 34.7358,132.4013 diff = 168.500000'
});
data_peak.push({
lat: 3.4761333334e+01,
lng: 1.3229488889e+02,
cert : false,
content:' Peak = 910.799988 pos = 34.7613,132.2949 diff = 163.000000'
});
data_saddle.push({
lat: 3.4758666667e+01,
lng: 1.3229955556e+02,
content:'Saddle = 747.799988 pos = 34.7587,132.2996 diff = 163.000000'
});
data_peak.push({
lat: 3.4777111112e+01,
lng: 1.3229866667e+02,
cert : true,
content:'Name = JA/HS-032(JA/HS-032) peak = 1001.799988 pos = 34.7771,132.2987 diff = 203.599976'
});
data_saddle.push({
lat: 3.4793666667e+01,
lng: 1.3232333333e+02,
content:'Saddle = 798.200012 pos = 34.7937,132.3233 diff = 203.599976'
});
data_peak.push({
lat: 3.4734333334e+01,
lng: 1.3225722222e+02,
cert : true,
content:'Name = JA/HS-056(JA/HS-056) peak = 840.500000 pos = 34.7343,132.2572 diff = 161.599976'
});
data_saddle.push({
lat: 3.4745000001e+01,
lng: 1.3225255556e+02,
content:'Saddle = 678.900024 pos = 34.7450,132.2526 diff = 161.599976'
});
data_peak.push({
lat: 3.4764333334e+01,
lng: 1.3222622222e+02,
cert : true,
content:'Name = JA/HS-034(JA/HS-034) peak = 995.000000 pos = 34.7643,132.2262 diff = 288.099976'
});
data_saddle.push({
lat: 3.4748000001e+01,
lng: 1.3221977778e+02,
content:'Saddle = 706.900024 pos = 34.7480,132.2198 diff = 288.099976'
});
data_peak.push({
lat: 3.4802111112e+01,
lng: 1.3223866667e+02,
cert : true,
content:'Name = Ungetsuyama(JA/SN-021) peak = 910.799988 pos = 34.8021,132.2387 diff = 202.500000'
});
data_saddle.push({
lat: 3.4790111112e+01,
lng: 1.3224277778e+02,
content:'Saddle = 708.299988 pos = 34.7901,132.2428 diff = 202.500000'
});
data_peak.push({
lat: 3.4696888889e+01,
lng: 1.3209600000e+02,
cert : true,
content:'Name = JA/SN-020(JA/SN-020) peak = 920.900024 pos = 34.6969,132.0960 diff = 158.900024'
});
data_saddle.push({
lat: 3.4700777778e+01,
lng: 1.3209666667e+02,
content:'Saddle = 762.000000 pos = 34.7008,132.0967 diff = 158.900024'
});
data_peak.push({
lat: 3.4680444445e+01,
lng: 1.3222611111e+02,
cert : false,
content:' Peak = 981.799988 pos = 34.6804,132.2261 diff = 217.299988'
});
data_saddle.push({
lat: 3.4666777778e+01,
lng: 1.3220422222e+02,
content:'Saddle = 764.500000 pos = 34.6668,132.2042 diff = 217.299988'
});
data_peak.push({
lat: 3.4711444445e+01,
lng: 1.3211644444e+02,
cert : true,
content:'Name = JA/SN-009(JA/SN-009) peak = 1062.099976 pos = 34.7114,132.1164 diff = 265.399963'
});
data_saddle.push({
lat: 3.4714222223e+01,
lng: 1.3216488889e+02,
content:'Saddle = 796.700012 pos = 34.7142,132.1649 diff = 265.399963'
});
data_peak.push({
lat: 3.4674888889e+01,
lng: 1.3212366667e+02,
cert : true,
content:'Name = JA/SN-014(JA/SN-014) peak = 1010.900024 pos = 34.6749,132.1237 diff = 212.500000'
});
data_saddle.push({
lat: 3.4711111112e+01,
lng: 1.3212888889e+02,
content:'Saddle = 798.400024 pos = 34.7111,132.1289 diff = 212.500000'
});
data_peak.push({
lat: 3.4747666667e+01,
lng: 1.3220111111e+02,
cert : true,
content:'Name = Oosayama(JA/HS-022) peak = 1066.599976 pos = 34.7477,132.2011 diff = 196.899963'
});
data_saddle.push({
lat: 3.4722000001e+01,
lng: 1.3220777778e+02,
content:'Saddle = 869.700012 pos = 34.7220,132.2078 diff = 196.899963'
});
data_peak.push({
lat: 3.4673111112e+01,
lng: 1.3272722222e+02,
cert : false,
content:' Peak = 430.799988 pos = 34.6731,132.7272 diff = 235.699982'
});
data_saddle.push({
lat: 3.4666777778e+01,
lng: 1.3274433333e+02,
content:'Saddle = 195.100006 pos = 34.6668,132.7443 diff = 235.699982'
});
data_peak.push({
lat: 3.5297666667e+01,
lng: 1.3484944444e+02,
cert : true,
content:'Name = JA/HG-137(JA/HG-137) peak = 463.600006 pos = 35.2977,134.8494 diff = 265.100006'
});
data_saddle.push({
lat: 3.5290333334e+01,
lng: 1.3485533333e+02,
content:'Saddle = 198.500000 pos = 35.2903,134.8553 diff = 265.100006'
});
data_peak.push({
lat: 3.5344666667e+01,
lng: 1.3318277778e+02,
cert : false,
content:' Peak = 364.000000 pos = 35.3447,133.1828 diff = 157.000000'
});
data_saddle.push({
lat: 3.5340555556e+01,
lng: 1.3319855556e+02,
content:'Saddle = 207.000000 pos = 35.3406,133.1986 diff = 157.000000'
});
data_peak.push({
lat: 3.5324444445e+01,
lng: 1.3318477778e+02,
cert : false,
content:' Peak = 394.899994 pos = 35.3244,133.1848 diff = 186.899994'
});
data_saddle.push({
lat: 3.5335333334e+01,
lng: 1.3320877778e+02,
content:'Saddle = 208.000000 pos = 35.3353,133.2088 diff = 186.899994'
});
data_peak.push({
lat: 3.5371555556e+01,
lng: 1.3295900000e+02,
cert : true,
content:'Name = JA/SN-117(JA/SN-117) peak = 410.399994 pos = 35.3716,132.9590 diff = 202.399994'
});
data_saddle.push({
lat: 3.5370444445e+01,
lng: 1.3297966667e+02,
content:'Saddle = 208.000000 pos = 35.3704,132.9797 diff = 202.399994'
});
data_peak.push({
lat: 3.5059555556e+01,
lng: 1.3254400000e+02,
cert : true,
content:'Name = JA/SN-110(JA/SN-110) peak = 436.899994 pos = 35.0596,132.5440 diff = 220.199997'
});
data_saddle.push({
lat: 3.5067777778e+01,
lng: 1.3252055556e+02,
content:'Saddle = 216.699997 pos = 35.0678,132.5206 diff = 220.199997'
});
data_peak.push({
lat: 3.5053111111e+01,
lng: 1.3253644444e+02,
cert : false,
content:' Peak = 420.700012 pos = 35.0531,132.5364 diff = 172.800018'
});
data_saddle.push({
lat: 3.5057000000e+01,
lng: 1.3253911111e+02,
content:'Saddle = 247.899994 pos = 35.0570,132.5391 diff = 172.800018'
});
data_peak.push({
lat: 3.5063777778e+01,
lng: 1.3257288889e+02,
cert : false,
content:' Peak = 420.299988 pos = 35.0638,132.5729 diff = 166.999985'
});
data_saddle.push({
lat: 3.5064555556e+01,
lng: 1.3256588889e+02,
content:'Saddle = 253.300003 pos = 35.0646,132.5659 diff = 166.999985'
});
data_peak.push({
lat: 3.5428555556e+01,
lng: 1.3390888889e+02,
cert : true,
content:'Name = JA/TT-041(JA/TT-041) peak = 517.400024 pos = 35.4286,133.9089 diff = 300.100037'
});
data_saddle.push({
lat: 3.5427222222e+01,
lng: 1.3392233333e+02,
content:'Saddle = 217.300003 pos = 35.4272,133.9223 diff = 300.100037'
});
data_peak.push({
lat: 3.5368000000e+01,
lng: 1.3300822222e+02,
cert : true,
content:'Name = JA/SN-101(JA/SN-101) peak = 471.799988 pos = 35.3680,133.0082 diff = 253.099991'
});
data_saddle.push({
lat: 3.5343333334e+01,
lng: 1.3305144444e+02,
content:'Saddle = 218.699997 pos = 35.3433,133.0514 diff = 253.099991'
});
data_peak.push({
lat: 3.5364777778e+01,
lng: 1.3304955556e+02,
cert : false,
content:' Peak = 423.299988 pos = 35.3648,133.0496 diff = 165.299988'
});
data_saddle.push({
lat: 3.5377444445e+01,
lng: 1.3303033333e+02,
content:'Saddle = 258.000000 pos = 35.3774,133.0303 diff = 165.299988'
});
data_peak.push({
lat: 3.5652777778e+01,
lng: 1.3480544444e+02,
cert : true,
content:'Name = JA/HG-159(JA/HG-159) peak = 425.100006 pos = 35.6528,134.8054 diff = 201.900009'
});
data_saddle.push({
lat: 3.5630222222e+01,
lng: 1.3477822222e+02,
content:'Saddle = 223.199997 pos = 35.6302,134.7782 diff = 201.900009'
});
data_peak.push({
lat: 3.4975777778e+01,
lng: 1.3245211111e+02,
cert : true,
content:'Name = JA/SN-118(JA/SN-118) peak = 402.700012 pos = 34.9758,132.4521 diff = 179.400009'
});
data_saddle.push({
lat: 3.4979777778e+01,
lng: 1.3241844444e+02,
content:'Saddle = 223.300003 pos = 34.9798,132.4184 diff = 179.400009'
});
data_peak.push({
lat: 3.5063888889e+01,
lng: 1.3242855556e+02,
cert : true,
content:'Name = Ooetakayama(JA/SN-030) peak = 802.500000 pos = 35.0639,132.4286 diff = 576.200012'
});
data_saddle.push({
lat: 3.5103555556e+01,
lng: 1.3252422222e+02,
content:'Saddle = 226.300003 pos = 35.1036,132.5242 diff = 576.200012'
});
data_peak.push({
lat: 3.4988333334e+01,
lng: 1.3237433333e+02,
cert : false,
content:' Peak = 441.600006 pos = 34.9883,132.3743 diff = 172.200012'
});
data_saddle.push({
lat: 3.4994777778e+01,
lng: 1.3237477778e+02,
content:'Saddle = 269.399994 pos = 34.9948,132.3748 diff = 172.200012'
});
data_peak.push({
lat: 3.5033333334e+01,
lng: 1.3236977778e+02,
cert : false,
content:' Peak = 444.000000 pos = 35.0333,132.3698 diff = 167.600006'
});
data_saddle.push({
lat: 3.5035000000e+01,
lng: 1.3238133333e+02,
content:'Saddle = 276.399994 pos = 35.0350,132.3813 diff = 167.600006'
});
data_peak.push({
lat: 3.4964555556e+01,
lng: 1.3241644444e+02,
cert : true,
content:'Name = JA/SN-089(JA/SN-089) peak = 521.900024 pos = 34.9646,132.4164 diff = 245.000031'
});
data_saddle.push({
lat: 3.4997555556e+01,
lng: 1.3239988889e+02,
content:'Saddle = 276.899994 pos = 34.9976,132.3999 diff = 245.000031'
});
data_peak.push({
lat: 3.4980666667e+01,
lng: 1.3240644444e+02,
cert : true,
content:'Name = JA/SN-098(JA/SN-098) peak = 480.000000 pos = 34.9807,132.4064 diff = 189.700012'
});
data_saddle.push({
lat: 3.4981666667e+01,
lng: 1.3240122222e+02,
content:'Saddle = 290.299988 pos = 34.9817,132.4012 diff = 189.700012'
});
data_peak.push({
lat: 3.4977333334e+01,
lng: 1.3238722222e+02,
cert : false,
content:' Peak = 492.100006 pos = 34.9773,132.3872 diff = 178.800018'
});
data_saddle.push({
lat: 3.4971444445e+01,
lng: 1.3239277778e+02,
content:'Saddle = 313.299988 pos = 34.9714,132.3928 diff = 178.800018'
});
data_peak.push({
lat: 3.5007666667e+01,
lng: 1.3236844444e+02,
cert : true,
content:'Name = JA/SN-068(JA/SN-068) peak = 592.099976 pos = 35.0077,132.3684 diff = 313.699982'
});
data_saddle.push({
lat: 3.5032000000e+01,
lng: 1.3240244444e+02,
content:'Saddle = 278.399994 pos = 35.0320,132.4024 diff = 313.699982'
});
data_peak.push({
lat: 3.4992777778e+01,
lng: 1.3233511111e+02,
cert : true,
content:'Name = JA/SN-087(JA/SN-087) peak = 525.700012 pos = 34.9928,132.3351 diff = 198.000000'
});
data_saddle.push({
lat: 3.5000222223e+01,
lng: 1.3234888889e+02,
content:'Saddle = 327.700012 pos = 35.0002,132.3489 diff = 198.000000'
});
data_peak.push({
lat: 3.5066555556e+01,
lng: 1.3237433333e+02,
cert : false,
content:' Peak = 444.700012 pos = 35.0666,132.3743 diff = 160.600006'
});
data_saddle.push({
lat: 3.5070666667e+01,
lng: 1.3238244444e+02,
content:'Saddle = 284.100006 pos = 35.0707,132.3824 diff = 160.600006'
});
data_peak.push({
lat: 3.5067555556e+01,
lng: 1.3239122222e+02,
cert : true,
content:'Name = JA/SN-070(JA/SN-070) peak = 583.400024 pos = 35.0676,132.3912 diff = 239.400024'
});
data_saddle.push({
lat: 3.5067666667e+01,
lng: 1.3239944444e+02,
content:'Saddle = 344.000000 pos = 35.0677,132.3994 diff = 239.400024'
});
data_peak.push({
lat: 3.5079555556e+01,
lng: 1.3239100000e+02,
cert : false,
content:' Peak = 546.400024 pos = 35.0796,132.3910 diff = 175.900024'
});
data_saddle.push({
lat: 3.5072777778e+01,
lng: 1.3239133333e+02,
content:'Saddle = 370.500000 pos = 35.0728,132.3913 diff = 175.900024'
});
data_peak.push({
lat: 3.5096222223e+01,
lng: 1.3243766667e+02,
cert : false,
content:' Peak = 536.200012 pos = 35.0962,132.4377 diff = 165.100006'
});
data_saddle.push({
lat: 3.5091444445e+01,
lng: 1.3243166667e+02,
content:'Saddle = 371.100006 pos = 35.0914,132.4317 diff = 165.100006'
});
data_peak.push({
lat: 3.5085000000e+01,
lng: 1.3241677778e+02,
cert : true,
content:'Name = JA/SN-059(JA/SN-059) peak = 633.299988 pos = 35.0850,132.4168 diff = 206.299988'
});
data_saddle.push({
lat: 3.5078777778e+01,
lng: 1.3242155556e+02,
content:'Saddle = 427.000000 pos = 35.0788,132.4216 diff = 206.299988'
});
data_peak.push({
lat: 3.5068222223e+01,
lng: 1.3240744444e+02,
cert : false,
content:' Peak = 634.200012 pos = 35.0682,132.4074 diff = 182.500000'
});
data_saddle.push({
lat: 3.5067666667e+01,
lng: 1.3241255556e+02,
content:'Saddle = 451.700012 pos = 35.0677,132.4126 diff = 182.500000'
});
data_peak.push({
lat: 3.5068444445e+01,
lng: 1.3242155556e+02,
cert : false,
content:' Peak = 721.000000 pos = 35.0684,132.4216 diff = 159.299988'
});
data_saddle.push({
lat: 3.5065222223e+01,
lng: 1.3242366667e+02,
content:'Saddle = 561.700012 pos = 35.0652,132.4237 diff = 159.299988'
});
data_peak.push({
lat: 3.5420222222e+01,
lng: 1.3412244444e+02,
cert : true,
content:'Name = JA/TT-043(JA/TT-043) peak = 506.000000 pos = 35.4202,134.1224 diff = 278.200012'
});
data_saddle.push({
lat: 3.5414222222e+01,
lng: 1.3411133333e+02,
content:'Saddle = 227.800003 pos = 35.4142,134.1113 diff = 278.200012'
});
data_peak.push({
lat: 3.5346888889e+01,
lng: 1.3418500000e+02,
cert : true,
content:'Name = JA/TT-045(JA/TT-045) peak = 402.299988 pos = 35.3469,134.1850 diff = 170.799988'
});
data_saddle.push({
lat: 3.5352444445e+01,
lng: 1.3417688889e+02,
content:'Saddle = 231.500000 pos = 35.3524,134.1769 diff = 170.799988'
});
data_peak.push({
lat: 3.4835222223e+01,
lng: 1.3281355556e+02,
cert : true,
content:'Name = JA/HS-197(JA/HS-197) peak = 433.899994 pos = 34.8352,132.8136 diff = 201.899994'
});
data_saddle.push({
lat: 3.4853777778e+01,
lng: 1.3284900000e+02,
content:'Saddle = 232.000000 pos = 34.8538,132.8490 diff = 201.899994'
});
data_peak.push({
lat: 3.5616444445e+01,
lng: 1.3471411111e+02,
cert : true,
content:'Name = JA/HG-155(JA/HG-155) peak = 434.200012 pos = 35.6164,134.7141 diff = 196.000015'
});
data_saddle.push({
lat: 3.5586111111e+01,
lng: 1.3469611111e+02,
content:'Saddle = 238.199997 pos = 35.5861,134.6961 diff = 196.000015'
});
data_peak.push({
lat: 3.5612000000e+01,
lng: 1.3478544444e+02,
cert : true,
content:'Name = Kuruhidake(JA/HG-098) peak = 565.400024 pos = 35.6120,134.7854 diff = 317.100037'
});
data_saddle.push({
lat: 3.5529888889e+01,
lng: 1.3471866667e+02,
content:'Saddle = 248.300003 pos = 35.5299,134.7187 diff = 317.100037'
});
data_peak.push({
lat: 3.5550777778e+01,
lng: 1.3473877778e+02,
cert : true,
content:'Name = JA/HG-097(JA/HG-097) peak = 563.799988 pos = 35.5508,134.7388 diff = 311.099976'
});
data_saddle.push({
lat: 3.5597777778e+01,
lng: 1.3476866667e+02,
content:'Saddle = 252.699997 pos = 35.5978,134.7687 diff = 311.099976'
});
data_peak.push({
lat: 3.5590777778e+01,
lng: 1.3452488889e+02,
cert : false,
content:' Peak = 412.399994 pos = 35.5908,134.5249 diff = 162.000000'
});
data_saddle.push({
lat: 3.5585000000e+01,
lng: 1.3453833333e+02,
content:'Saddle = 250.399994 pos = 35.5850,134.5383 diff = 162.000000'
});
data_peak.push({
lat: 3.5417444445e+01,
lng: 1.3477311111e+02,
cert : false,
content:' Peak = 406.899994 pos = 35.4174,134.7731 diff = 154.000000'
});
data_saddle.push({
lat: 3.5411666667e+01,
lng: 1.3476088889e+02,
content:'Saddle = 252.899994 pos = 35.4117,134.7609 diff = 154.000000'
});
data_peak.push({
lat: 3.5352666667e+01,
lng: 1.3479633333e+02,
cert : true,
content:'Name = JA/HG-111(JA/HG-111) peak = 535.599976 pos = 35.3527,134.7963 diff = 279.299988'
});
data_saddle.push({
lat: 3.5343444445e+01,
lng: 1.3479811111e+02,
content:'Saddle = 256.299988 pos = 35.3434,134.7981 diff = 279.299988'
});
data_peak.push({
lat: 3.4824222223e+01,
lng: 1.3289733333e+02,
cert : true,
content:'Name = JA/HS-182(JA/HS-182) peak = 460.899994 pos = 34.8242,132.8973 diff = 199.699982'
});
data_saddle.push({
lat: 3.4855666667e+01,
lng: 1.3300188889e+02,
content:'Saddle = 261.200012 pos = 34.8557,133.0019 diff = 199.699982'
});
data_peak.push({
lat: 3.4866333334e+01,
lng: 1.3294033333e+02,
cert : false,
content:' Peak = 444.100006 pos = 34.8663,132.9403 diff = 167.500000'
});
data_saddle.push({
lat: 3.4833555556e+01,
lng: 1.3292511111e+02,
content:'Saddle = 276.600006 pos = 34.8336,132.9251 diff = 167.500000'
});
data_peak.push({
lat: 3.4699666667e+01,
lng: 1.3293211111e+02,
cert : true,
content:'Name = JA/HS-125(JA/HS-125) peak = 640.599976 pos = 34.6997,132.9321 diff = 378.899963'
});
data_saddle.push({
lat: 3.4667000001e+01,
lng: 1.3296377778e+02,
content:'Saddle = 261.700012 pos = 34.6670,132.9638 diff = 378.899963'
});
data_peak.push({
lat: 3.4666777778e+01,
lng: 1.3279544444e+02,
cert : false,
content:' Peak = 550.000000 pos = 34.6668,132.7954 diff = 266.299988'
});
data_saddle.push({
lat: 3.4666777778e+01,
lng: 1.3285766667e+02,
content:'Saddle = 283.700012 pos = 34.6668,132.8577 diff = 266.299988'
});
data_peak.push({
lat: 3.4719888889e+01,
lng: 1.3286944444e+02,
cert : false,
content:' Peak = 522.400024 pos = 34.7199,132.8694 diff = 214.100037'
});
data_saddle.push({
lat: 3.4691777778e+01,
lng: 1.3284733333e+02,
content:'Saddle = 308.299988 pos = 34.6918,132.8473 diff = 214.100037'
});
data_peak.push({
lat: 3.4674777778e+01,
lng: 1.3277222222e+02,
cert : false,
content:' Peak = 502.899994 pos = 34.6748,132.7722 diff = 165.500000'
});
data_saddle.push({
lat: 3.4666888889e+01,
lng: 1.3278188889e+02,
content:'Saddle = 337.399994 pos = 34.6669,132.7819 diff = 165.500000'
});
data_peak.push({
lat: 3.4674000001e+01,
lng: 1.3291366667e+02,
cert : false,
content:' Peak = 591.400024 pos = 34.6740,132.9137 diff = 170.700012'
});
data_saddle.push({
lat: 3.4677333334e+01,
lng: 1.3290622222e+02,
content:'Saddle = 420.700012 pos = 34.6773,132.9062 diff = 170.700012'
});
data_peak.push({
lat: 3.4695666667e+01,
lng: 1.3288377778e+02,
cert : true,
content:'Name = JA/HS-143(JA/HS-143) peak = 581.799988 pos = 34.6957,132.8838 diff = 151.000000'
});
data_saddle.push({
lat: 3.4686444445e+01,
lng: 1.3291811111e+02,
content:'Saddle = 430.799988 pos = 34.6864,132.9181 diff = 151.000000'
});
data_peak.push({
lat: 3.5404333334e+01,
lng: 1.3416866667e+02,
cert : false,
content:' Peak = 415.000000 pos = 35.4043,134.1687 diff = 151.799988'
});
data_saddle.push({
lat: 3.5398222222e+01,
lng: 1.3414611111e+02,
content:'Saddle = 263.200012 pos = 35.3982,134.1461 diff = 151.799988'
});
data_peak.push({
lat: 3.5644666667e+01,
lng: 1.3452544444e+02,
cert : true,
content:'Name = JA/HG-105(JA/HG-105) peak = 550.400024 pos = 35.6447,134.5254 diff = 282.200012'
});
data_saddle.push({
lat: 3.5632333333e+01,
lng: 1.3452766667e+02,
content:'Saddle = 268.200012 pos = 35.6323,134.5277 diff = 282.200012'
});
data_peak.push({
lat: 3.5375111111e+01,
lng: 1.3475288889e+02,
cert : true,
content:'Name = JA/HG-101(JA/HG-101) peak = 554.599976 pos = 35.3751,134.7529 diff = 276.499969'
});
data_saddle.push({
lat: 3.5375333334e+01,
lng: 1.3470533333e+02,
content:'Saddle = 278.100006 pos = 35.3753,134.7053 diff = 276.499969'
});
data_peak.push({
lat: 3.5536000000e+01,
lng: 1.3447977778e+02,
cert : true,
content:'Name = JA/HG-122(JA/HG-122) peak = 515.200012 pos = 35.5360,134.4798 diff = 235.700012'
});
data_saddle.push({
lat: 3.5529555556e+01,
lng: 1.3448666667e+02,
content:'Saddle = 279.500000 pos = 35.5296,134.4867 diff = 235.700012'
});
data_peak.push({
lat: 3.5289111111e+01,
lng: 1.3499266667e+02,
cert : false,
content:' Peak = 512.200012 pos = 35.2891,134.9927 diff = 231.500000'
});
data_saddle.push({
lat: 3.5302777778e+01,
lng: 1.3495166667e+02,
content:'Saddle = 280.700012 pos = 35.3028,134.9517 diff = 231.500000'
});
data_peak.push({
lat: 3.4871444445e+01,
lng: 1.3292333333e+02,
cert : false,
content:' Peak = 455.700012 pos = 34.8714,132.9233 diff = 172.000000'
});
data_saddle.push({
lat: 3.4881444445e+01,
lng: 1.3292566667e+02,
content:'Saddle = 283.700012 pos = 34.8814,132.9257 diff = 172.000000'
});
data_peak.push({
lat: 3.5387222222e+01,
lng: 1.3316411111e+02,
cert : true,
content:'Name = Kyouragisan(JA/SN-100) peak = 472.500000 pos = 35.3872,133.1641 diff = 180.399994'
});
data_saddle.push({
lat: 3.5362333334e+01,
lng: 1.3312288889e+02,
content:'Saddle = 292.100006 pos = 35.3623,133.1229 diff = 180.399994'
});
data_peak.push({
lat: 3.5308555556e+01,
lng: 1.3338055556e+02,
cert : true,
content:'Name = JA/TT-044(JA/TT-044) peak = 480.399994 pos = 35.3086,133.3806 diff = 183.600006'
});
data_saddle.push({
lat: 3.5302777778e+01,
lng: 1.3338188889e+02,
content:'Saddle = 296.799988 pos = 35.3028,133.3819 diff = 183.600006'
});
data_peak.push({
lat: 3.4667444445e+01,
lng: 1.3297777778e+02,
cert : false,
content:' Peak = 500.799988 pos = 34.6674,132.9778 diff = 188.599976'
});
data_saddle.push({
lat: 3.4666777778e+01,
lng: 1.3298955556e+02,
content:'Saddle = 312.200012 pos = 34.6668,132.9896 diff = 188.599976'
});
data_peak.push({
lat: 3.4884888889e+01,
lng: 1.3272377778e+02,
cert : true,
content:'Name = JA/HS-168(JA/HS-168) peak = 510.799988 pos = 34.8849,132.7238 diff = 193.299988'
});
data_saddle.push({
lat: 3.4907666667e+01,
lng: 1.3272711111e+02,
content:'Saddle = 317.500000 pos = 34.9077,132.7271 diff = 193.299988'
});
data_peak.push({
lat: 3.4889444445e+01,
lng: 1.3286155556e+02,
cert : true,
content:'Name = JA/HS-169(JA/HS-169) peak = 506.399994 pos = 34.8894,132.8616 diff = 188.500000'
});
data_saddle.push({
lat: 3.4906666667e+01,
lng: 1.3287611111e+02,
content:'Saddle = 317.899994 pos = 34.9067,132.8761 diff = 188.500000'
});
data_peak.push({
lat: 3.5588888889e+01,
lng: 1.3445011111e+02,
cert : true,
content:'Name = JA/HG-112(JA/HG-112) peak = 534.000000 pos = 35.5889,134.4501 diff = 211.600006'
});
data_saddle.push({
lat: 3.5569666667e+01,
lng: 1.3443711111e+02,
content:'Saddle = 322.399994 pos = 35.5697,134.4371 diff = 211.600006'
});
data_peak.push({
lat: 3.5144777778e+01,
lng: 1.3488377778e+02,
cert : true,
content:'Name = Sengamine(JA/HG-022) peak = 1001.500000 pos = 35.1448,134.8838 diff = 674.900024'
});
data_saddle.push({
lat: 3.5170111111e+01,
lng: 1.3479111111e+02,
content:'Saddle = 326.600006 pos = 35.1701,134.7911 diff = 674.900024'
});
data_peak.push({
lat: 3.5094111111e+01,
lng: 1.3494544444e+02,
cert : false,
content:' Peak = 541.900024 pos = 35.0941,134.9454 diff = 200.600037'
});
data_saddle.push({
lat: 3.5103555556e+01,
lng: 1.3493388889e+02,
content:'Saddle = 341.299988 pos = 35.1036,134.9339 diff = 200.600037'
});
data_peak.push({
lat: 3.5092222223e+01,
lng: 1.3491466667e+02,
cert : true,
content:'Name = JA/HG-065(JA/HG-065) peak = 693.900024 pos = 35.0922,134.9147 diff = 351.800018'
});
data_saddle.push({
lat: 3.5106111111e+01,
lng: 1.3492533333e+02,
content:'Saddle = 342.100006 pos = 35.1061,134.9253 diff = 351.800018'
});
data_peak.push({
lat: 3.5033000000e+01,
lng: 1.3480677778e+02,
cert : false,
content:' Peak = 560.799988 pos = 35.0330,134.8068 diff = 208.699982'
});
data_saddle.push({
lat: 3.5037777778e+01,
lng: 1.3480677778e+02,
content:'Saddle = 352.100006 pos = 35.0378,134.8068 diff = 208.699982'
});
data_peak.push({
lat: 3.5262111111e+01,
lng: 1.3498311111e+02,
cert : false,
content:' Peak = 621.200012 pos = 35.2621,134.9831 diff = 259.000000'
});
data_saddle.push({
lat: 3.5267111111e+01,
lng: 1.3497933333e+02,
content:'Saddle = 362.200012 pos = 35.2671,134.9793 diff = 259.000000'
});
data_peak.push({
lat: 3.5108111111e+01,
lng: 1.3476066667e+02,
cert : true,
content:'Name = JA/HG-042(JA/HG-042) peak = 824.700012 pos = 35.1081,134.7607 diff = 456.900024'
});
data_saddle.push({
lat: 3.5143666667e+01,
lng: 1.3479488889e+02,
content:'Saddle = 367.799988 pos = 35.1437,134.7949 diff = 456.900024'
});
data_peak.push({
lat: 3.5309111111e+01,
lng: 1.3494077778e+02,
cert : false,
content:' Peak = 590.799988 pos = 35.3091,134.9408 diff = 213.699982'
});
data_saddle.push({
lat: 3.5303111111e+01,
lng: 1.3493877778e+02,
content:'Saddle = 377.100006 pos = 35.3031,134.9388 diff = 213.699982'
});
data_peak.push({
lat: 3.5147777778e+01,
lng: 1.3496111111e+02,
cert : true,
content:'Name = JA/HG-039(JA/HG-039) peak = 824.099976 pos = 35.1478,134.9611 diff = 446.899963'
});
data_saddle.push({
lat: 3.5213777778e+01,
lng: 1.3494777778e+02,
content:'Saddle = 377.200012 pos = 35.2138,134.9478 diff = 446.899963'
});
data_peak.push({
lat: 3.5219000000e+01,
lng: 1.3496966667e+02,
cert : true,
content:'Name = JA/HG-053(JA/HG-053) peak = 743.500000 pos = 35.2190,134.9697 diff = 200.400024'
});
data_saddle.push({
lat: 3.5201222223e+01,
lng: 1.3495122222e+02,
content:'Saddle = 543.099976 pos = 35.2012,134.9512 diff = 200.400024'
});
data_peak.push({
lat: 3.5190555556e+01,
lng: 1.3495744444e+02,
cert : false,
content:' Peak = 750.500000 pos = 35.1906,134.9574 diff = 152.799988'
});
data_saddle.push({
lat: 3.5183333334e+01,
lng: 1.3495211111e+02,
content:'Saddle = 597.700012 pos = 35.1833,134.9521 diff = 152.799988'
});
data_peak.push({
lat: 3.5171000000e+01,
lng: 1.3494922222e+02,
cert : false,
content:' Peak = 811.099976 pos = 35.1710,134.9492 diff = 188.399963'
});
data_saddle.push({
lat: 3.5163222223e+01,
lng: 1.3495044444e+02,
content:'Saddle = 622.700012 pos = 35.1632,134.9504 diff = 188.399963'
});
data_peak.push({
lat: 3.5154666667e+01,
lng: 1.3494311111e+02,
cert : false,
content:' Peak = 790.500000 pos = 35.1547,134.9431 diff = 158.299988'
});
data_saddle.push({
lat: 3.5153555556e+01,
lng: 1.3495455556e+02,
content:'Saddle = 632.200012 pos = 35.1536,134.9546 diff = 158.299988'
});
data_peak.push({
lat: 3.5037444445e+01,
lng: 1.3479411111e+02,
cert : false,
content:' Peak = 572.099976 pos = 35.0374,134.7941 diff = 174.499969'
});
data_saddle.push({
lat: 3.5041111111e+01,
lng: 1.3479911111e+02,
content:'Saddle = 397.600006 pos = 35.0411,134.7991 diff = 174.499969'
});
data_peak.push({
lat: 3.5276666667e+01,
lng: 1.3484477778e+02,
cert : true,
content:'Name = JA/HG-051(JA/HG-051) peak = 755.400024 pos = 35.2767,134.8448 diff = 357.300018'
});
data_saddle.push({
lat: 3.5268000000e+01,
lng: 1.3486022222e+02,
content:'Saddle = 398.100006 pos = 35.2680,134.8602 diff = 357.300018'
});
data_peak.push({
lat: 3.5125444445e+01,
lng: 1.3490477778e+02,
cert : false,
content:' Peak = 650.799988 pos = 35.1254,134.9048 diff = 188.299988'
});
data_saddle.push({
lat: 3.5128666667e+01,
lng: 1.3489400000e+02,
content:'Saddle = 462.500000 pos = 35.1287,134.8940 diff = 188.299988'
});
data_peak.push({
lat: 3.5064222223e+01,
lng: 1.3483466667e+02,
cert : true,
content:'Name = Kasagatayama(JA/HG-028) peak = 938.700012 pos = 35.0642,134.8347 diff = 430.300018'
});
data_saddle.push({
lat: 3.5093111111e+01,
lng: 1.3485344444e+02,
content:'Saddle = 508.399994 pos = 35.0931,134.8534 diff = 430.300018'
});
data_peak.push({
lat: 3.5222222223e+01,
lng: 1.3494288889e+02,
cert : false,
content:' Peak = 681.299988 pos = 35.2222,134.9429 diff = 160.000000'
});
data_saddle.push({
lat: 3.5217000000e+01,
lng: 1.3493577778e+02,
content:'Saddle = 521.299988 pos = 35.2170,134.9358 diff = 160.000000'
});
data_peak.push({
lat: 3.5272777778e+01,
lng: 1.3491544444e+02,
cert : true,
content:'Name = Awagayama(JA/HG-027) peak = 961.500000 pos = 35.2728,134.9154 diff = 403.299988'
});
data_saddle.push({
lat: 3.5226777778e+01,
lng: 1.3489877778e+02,
content:'Saddle = 558.200012 pos = 35.2268,134.8988 diff = 403.299988'
});
data_peak.push({
lat: 3.5242000000e+01,
lng: 1.3489933333e+02,
cert : true,
content:'Name = JA/HG-034(JA/HG-034) peak = 873.599976 pos = 35.2420,134.8993 diff = 301.500000'
});
data_saddle.push({
lat: 3.5257777778e+01,
lng: 1.3490577778e+02,
content:'Saddle = 572.099976 pos = 35.2578,134.9058 diff = 301.500000'
});
data_peak.push({
lat: 3.5225333334e+01,
lng: 1.3486711111e+02,
cert : true,
content:'Name = JA/HG-041(JA/HG-041) peak = 823.000000 pos = 35.2253,134.8671 diff = 241.099976'
});
data_saddle.push({
lat: 3.5231222223e+01,
lng: 1.3487088889e+02,
content:'Saddle = 581.900024 pos = 35.2312,134.8709 diff = 241.099976'
});
data_peak.push({
lat: 3.5203777778e+01,
lng: 1.3482733333e+02,
cert : true,
content:'Name = JA/HG-045(JA/HG-045) peak = 801.500000 pos = 35.2038,134.8273 diff = 160.000000'
});
data_saddle.push({
lat: 3.5213444445e+01,
lng: 1.3483855556e+02,
content:'Saddle = 641.500000 pos = 35.2134,134.8386 diff = 160.000000'
});
data_peak.push({
lat: 3.5253666667e+01,
lng: 1.3487044444e+02,
cert : false,
content:' Peak = 812.099976 pos = 35.2537,134.8704 diff = 150.599976'
});
data_saddle.push({
lat: 3.5257888889e+01,
lng: 1.3488900000e+02,
content:'Saddle = 661.500000 pos = 35.2579,134.8890 diff = 150.599976'
});
data_peak.push({
lat: 3.5143888889e+01,
lng: 1.3481700000e+02,
cert : true,
content:'Name = JA/HG-023(JA/HG-023) peak = 981.700012 pos = 35.1439,134.8170 diff = 343.500000'
});
data_saddle.push({
lat: 3.5159000000e+01,
lng: 1.3484511111e+02,
content:'Saddle = 638.200012 pos = 35.1590,134.8451 diff = 343.500000'
});
data_peak.push({
lat: 3.5109333334e+01,
lng: 1.3480855556e+02,
cert : true,
content:'Name = JA/HG-033(JA/HG-033) peak = 881.799988 pos = 35.1093,134.8086 diff = 229.899963'
});
data_saddle.push({
lat: 3.5119444445e+01,
lng: 1.3481733333e+02,
content:'Saddle = 651.900024 pos = 35.1194,134.8173 diff = 229.899963'
});
data_peak.push({
lat: 3.5212111111e+01,
lng: 1.3491844444e+02,
cert : false,
content:' Peak = 853.099976 pos = 35.2121,134.9184 diff = 160.799988'
});
data_saddle.push({
lat: 3.5191333334e+01,
lng: 1.3490566667e+02,
content:'Saddle = 692.299988 pos = 35.1913,134.9057 diff = 160.799988'
});
data_peak.push({
lat: 3.5111222223e+01,
lng: 1.3485333333e+02,
cert : false,
content:' Peak = 901.500000 pos = 35.1112,134.8533 diff = 193.200012'
});
data_saddle.push({
lat: 3.5121666667e+01,
lng: 1.3486688889e+02,
content:'Saddle = 708.299988 pos = 35.1217,134.8669 diff = 193.200012'
});
data_peak.push({
lat: 3.5164777778e+01,
lng: 1.3490233333e+02,
cert : true,
content:'Name = JA/HG-030(JA/HG-030) peak = 924.099976 pos = 35.1648,134.9023 diff = 162.500000'
});
data_saddle.push({
lat: 3.5155777778e+01,
lng: 1.3489666667e+02,
content:'Saddle = 761.599976 pos = 35.1558,134.8967 diff = 162.500000'
});
data_peak.push({
lat: 3.5020222223e+01,
lng: 1.3367855556e+02,
cert : true,
content:'Name = JA/OY-081(JA/OY-081) peak = 572.000000 pos = 35.0202,133.6786 diff = 245.299988'
});
data_saddle.push({
lat: 3.5026555556e+01,
lng: 1.3366200000e+02,
content:'Saddle = 326.700012 pos = 35.0266,133.6620 diff = 245.299988'
});
data_peak.push({
lat: 3.5040333334e+01,
lng: 1.3372800000e+02,
cert : false,
content:' Peak = 522.900024 pos = 35.0403,133.7280 diff = 155.800018'
});
data_saddle.push({
lat: 3.5041000000e+01,
lng: 1.3372222222e+02,
content:'Saddle = 367.100006 pos = 35.0410,133.7222 diff = 155.800018'
});
data_peak.push({
lat: 3.5331444445e+01,
lng: 1.3345755556e+02,
cert : false,
content:' Peak = 511.100006 pos = 35.3314,133.4576 diff = 184.100006'
});
data_saddle.push({
lat: 3.5336111111e+01,
lng: 1.3346122222e+02,
content:'Saddle = 327.000000 pos = 35.3361,133.4612 diff = 184.100006'
});
data_peak.push({
lat: 3.5249777778e+01,
lng: 1.3273200000e+02,
cert : true,
content:'Name = JA/SN-088(JA/SN-088) peak = 524.799988 pos = 35.2498,132.7320 diff = 196.199982'
});
data_saddle.push({
lat: 3.5251333334e+01,
lng: 1.3274333333e+02,
content:'Saddle = 328.600006 pos = 35.2513,132.7433 diff = 196.199982'
});
data_peak.push({
lat: 3.5234111111e+01,
lng: 1.3269833333e+02,
cert : false,
content:' Peak = 488.000000 pos = 35.2341,132.6983 diff = 156.600006'
});
data_saddle.push({
lat: 3.5223333334e+01,
lng: 1.3269455556e+02,
content:'Saddle = 331.399994 pos = 35.2233,132.6946 diff = 156.600006'
});
data_peak.push({
lat: 3.5116333334e+01,
lng: 1.3431222222e+02,
cert : true,
content:'Name = JA/OY-080(JA/OY-080) peak = 580.000000 pos = 35.1163,134.3122 diff = 248.299988'
});
data_saddle.push({
lat: 3.5128222223e+01,
lng: 1.3430911111e+02,
content:'Saddle = 331.700012 pos = 35.1282,134.3091 diff = 248.299988'
});
data_peak.push({
lat: 3.5456111111e+01,
lng: 1.3394800000e+02,
cert : true,
content:'Name = JA/TT-042(JA/TT-042) peak = 512.900024 pos = 35.4561,133.9480 diff = 176.500031'
});
data_saddle.push({
lat: 3.5444888889e+01,
lng: 1.3394966667e+02,
content:'Saddle = 336.399994 pos = 35.4449,133.9497 diff = 176.500031'
});
data_peak.push({
lat: 3.5075888889e+01,
lng: 1.3365222222e+02,
cert : false,
content:' Peak = 490.200012 pos = 35.0759,133.6522 diff = 153.400024'
});
data_saddle.push({
lat: 3.5092000000e+01,
lng: 1.3365711111e+02,
content:'Saddle = 336.799988 pos = 35.0920,133.6571 diff = 153.400024'
});
data_peak.push({
lat: 3.4998222223e+01,
lng: 1.3263400000e+02,
cert : true,
content:'Name = JA/SN-081(JA/SN-081) peak = 554.099976 pos = 34.9982,132.6340 diff = 213.299988'
});
data_saddle.push({
lat: 3.5001666667e+01,
lng: 1.3264266667e+02,
content:'Saddle = 340.799988 pos = 35.0017,132.6427 diff = 213.299988'
});
data_peak.push({
lat: 3.5004222223e+01,
lng: 1.3458388889e+02,
cert : false,
content:' Peak = 516.599976 pos = 35.0042,134.5839 diff = 175.499969'
});
data_saddle.push({
lat: 3.5009222223e+01,
lng: 1.3458600000e+02,
content:'Saddle = 341.100006 pos = 35.0092,134.5860 diff = 175.499969'
});
data_peak.push({
lat: 3.4760111112e+01,
lng: 1.3351977778e+02,
cert : true,
content:'Name = JA/OY-085(JA/OY-085) peak = 541.099976 pos = 34.7601,133.5198 diff = 194.699982'
});
data_saddle.push({
lat: 3.4686333334e+01,
lng: 1.3348900000e+02,
content:'Saddle = 346.399994 pos = 34.6863,133.4890 diff = 194.699982'
});
data_peak.push({
lat: 3.4680222223e+01,
lng: 1.3357088889e+02,
cert : false,
content:' Peak = 522.099976 pos = 34.6802,133.5709 diff = 165.699982'
});
data_saddle.push({
lat: 3.4706777778e+01,
lng: 1.3354177778e+02,
content:'Saddle = 356.399994 pos = 34.7068,133.5418 diff = 165.699982'
});
data_peak.push({
lat: 3.5018111112e+01,
lng: 1.3351733333e+02,
cert : true,
content:'Name = JA/OY-087(JA/OY-087) peak = 535.500000 pos = 35.0181,133.5173 diff = 187.700012'
});
data_saddle.push({
lat: 3.5023666667e+01,
lng: 1.3352400000e+02,
content:'Saddle = 347.799988 pos = 35.0237,133.5240 diff = 187.700012'
});
data_peak.push({
lat: 3.4982666667e+01,
lng: 1.3357000000e+02,
cert : true,
content:'Name = JA/OY-062(JA/OY-062) peak = 685.599976 pos = 34.9827,133.5700 diff = 333.799988'
});
data_saddle.push({
lat: 3.5027888889e+01,
lng: 1.3358888889e+02,
content:'Saddle = 351.799988 pos = 35.0279,133.5889 diff = 333.799988'
});
data_peak.push({
lat: 3.4909777778e+01,
lng: 1.3355388889e+02,
cert : true,
content:'Name = JA/OY-089(JA/OY-089) peak = 525.799988 pos = 34.9098,133.5539 diff = 173.500000'
});
data_saddle.push({
lat: 3.4914444445e+01,
lng: 1.3354677778e+02,
content:'Saddle = 352.299988 pos = 34.9144,133.5468 diff = 173.500000'
});
data_peak.push({
lat: 3.5005666667e+01,
lng: 1.3364622222e+02,
cert : true,
content:'Name = JA/OY-070(JA/OY-070) peak = 645.599976 pos = 35.0057,133.6462 diff = 208.399963'
});
data_saddle.push({
lat: 3.5019555556e+01,
lng: 1.3360966667e+02,
content:'Saddle = 437.200012 pos = 35.0196,133.6097 diff = 208.399963'
});
data_peak.push({
lat: 3.5005888889e+01,
lng: 1.3461688889e+02,
cert : false,
content:' Peak = 511.000000 pos = 35.0059,134.6169 diff = 157.299988'
});
data_saddle.push({
lat: 3.5016444445e+01,
lng: 1.3463688889e+02,
content:'Saddle = 353.700012 pos = 35.0164,134.6369 diff = 157.299988'
});
data_peak.push({
lat: 3.5044222223e+01,
lng: 1.3452811111e+02,
cert : true,
content:'Name = JA/HG-092(JA/HG-092) peak = 581.900024 pos = 35.0442,134.5281 diff = 228.200012'
});
data_saddle.push({
lat: 3.5054555556e+01,
lng: 1.3453500000e+02,
content:'Saddle = 353.700012 pos = 35.0546,134.5350 diff = 228.200012'
});
data_peak.push({
lat: 3.5327444445e+01,
lng: 1.3481266667e+02,
cert : true,
content:'Name = JA/HG-066(JA/HG-066) peak = 691.000000 pos = 35.3274,134.8127 diff = 334.299988'
});
data_saddle.push({
lat: 3.5318111111e+01,
lng: 1.3480722222e+02,
content:'Saddle = 356.700012 pos = 35.3181,134.8072 diff = 334.299988'
});
data_peak.push({
lat: 3.5478000000e+01,
lng: 1.3435044444e+02,
cert : true,
content:'Name = JA/TT-040(JA/TT-040) peak = 534.599976 pos = 35.4780,134.3504 diff = 177.699982'
});
data_saddle.push({
lat: 3.5487000000e+01,
lng: 1.3436355556e+02,
content:'Saddle = 356.899994 pos = 35.4870,134.3636 diff = 177.699982'
});
data_peak.push({
lat: 3.5260555556e+01,
lng: 1.3275388889e+02,
cert : true,
content:'Name = JA/SN-077(JA/SN-077) peak = 573.799988 pos = 35.2606,132.7539 diff = 216.399994'
});
data_saddle.push({
lat: 3.5259666667e+01,
lng: 1.3277200000e+02,
content:'Saddle = 357.399994 pos = 35.2597,132.7720 diff = 216.399994'
});
data_peak.push({
lat: 3.5218222223e+01,
lng: 1.3302311111e+02,
cert : true,
content:'Name = JA/SN-072(JA/SN-072) peak = 576.200012 pos = 35.2182,133.0231 diff = 218.700012'
});
data_saddle.push({
lat: 3.5226666667e+01,
lng: 1.3302711111e+02,
content:'Saddle = 357.500000 pos = 35.2267,133.0271 diff = 218.700012'
});
data_peak.push({
lat: 3.5554888889e+01,
lng: 1.3443433333e+02,
cert : true,
content:'Name = JA/HG-059(JA/HG-059) peak = 713.799988 pos = 35.5549,134.4343 diff = 355.099976'
});
data_saddle.push({
lat: 3.5518555556e+01,
lng: 1.3441411111e+02,
content:'Saddle = 358.700012 pos = 35.5186,134.4141 diff = 355.099976'
});
data_peak.push({
lat: 3.5269222223e+01,
lng: 1.3349744444e+02,
cert : true,
content:'Name = JA/TT-039(JA/TT-039) peak = 550.500000 pos = 35.2692,133.4974 diff = 189.000000'
});
data_saddle.push({
lat: 3.5275888889e+01,
lng: 1.3350622222e+02,
content:'Saddle = 361.500000 pos = 35.2759,133.5062 diff = 189.000000'
});
data_peak.push({
lat: 3.5199666667e+01,
lng: 1.3305711111e+02,
cert : false,
content:' Peak = 551.200012 pos = 35.1997,133.0571 diff = 184.200012'
});
data_saddle.push({
lat: 3.5200222223e+01,
lng: 1.3306711111e+02,
content:'Saddle = 367.000000 pos = 35.2002,133.0671 diff = 184.200012'
});
data_peak.push({
lat: 3.5525222222e+01,
lng: 1.3454088889e+02,
cert : true,
content:'Name = JA/HG-100(JA/HG-100) peak = 560.599976 pos = 35.5252,134.5409 diff = 193.499969'
});
data_saddle.push({
lat: 3.5519444445e+01,
lng: 1.3453833333e+02,
content:'Saddle = 367.100006 pos = 35.5194,134.5383 diff = 193.499969'
});
data_peak.push({
lat: 3.5201777778e+01,
lng: 1.3407022222e+02,
cert : false,
content:' Peak = 592.299988 pos = 35.2018,134.0702 diff = 224.399994'
});
data_saddle.push({
lat: 3.5203888889e+01,
lng: 1.3407444444e+02,
content:'Saddle = 367.899994 pos = 35.2039,134.0744 diff = 224.399994'
});
data_peak.push({
lat: 3.5001222223e+01,
lng: 1.3465300000e+02,
cert : true,
content:'Name = JA/HG-070(JA/HG-070) peak = 663.700012 pos = 35.0012,134.6530 diff = 292.900024'
});
data_saddle.push({
lat: 3.5033000000e+01,
lng: 1.3464844444e+02,
content:'Saddle = 370.799988 pos = 35.0330,134.6484 diff = 292.900024'
});
data_peak.push({
lat: 3.5267111111e+01,
lng: 1.3316322222e+02,
cert : true,
content:'Name = JA/SN-066(JA/SN-066) peak = 594.200012 pos = 35.2671,133.1632 diff = 222.400024'
});
data_saddle.push({
lat: 3.5250111111e+01,
lng: 1.3317577778e+02,
content:'Saddle = 371.799988 pos = 35.2501,133.1758 diff = 222.400024'
});
data_peak.push({
lat: 3.4997111112e+01,
lng: 1.3353055556e+02,
cert : false,
content:' Peak = 653.299988 pos = 34.9971,133.5306 diff = 276.699982'
});
data_saddle.push({
lat: 3.5040333334e+01,
lng: 1.3354555556e+02,
content:'Saddle = 376.600006 pos = 35.0403,133.5456 diff = 276.699982'
});
data_peak.push({
lat: 3.4996555556e+01,
lng: 1.3348788889e+02,
cert : true,
content:'Name = JA/OY-069(JA/OY-069) peak = 646.599976 pos = 34.9966,133.4879 diff = 204.699982'
});
data_saddle.push({
lat: 3.4991111112e+01,
lng: 1.3351011111e+02,
content:'Saddle = 441.899994 pos = 34.9911,133.5101 diff = 204.699982'
});
data_peak.push({
lat: 3.5037888889e+01,
lng: 1.3263733333e+02,
cert : false,
content:' Peak = 548.299988 pos = 35.0379,132.6373 diff = 171.199982'
});
data_saddle.push({
lat: 3.5041555556e+01,
lng: 1.3265066667e+02,
content:'Saddle = 377.100006 pos = 35.0416,132.6507 diff = 171.199982'
});
data_peak.push({
lat: 3.5619000000e+01,
lng: 1.3457144444e+02,
cert : true,
content:'Name = JA/HG-069(JA/HG-069) peak = 670.299988 pos = 35.6190,134.5714 diff = 293.199982'
});
data_saddle.push({
lat: 3.5549888889e+01,
lng: 1.3453622222e+02,
content:'Saddle = 377.100006 pos = 35.5499,134.5362 diff = 293.199982'
});
data_peak.push({
lat: 3.5567444445e+01,
lng: 1.3456755556e+02,
cert : true,
content:'Name = JA/HG-085(JA/HG-085) peak = 600.299988 pos = 35.5674,134.5676 diff = 218.699982'
});
data_saddle.push({
lat: 3.5575555556e+01,
lng: 1.3457822222e+02,
content:'Saddle = 381.600006 pos = 35.5756,134.5782 diff = 218.699982'
});
data_peak.push({
lat: 3.5437666667e+01,
lng: 1.3347922222e+02,
cert : true,
content:'Name = Kōreizan(JA/TT-028) peak = 750.799988 pos = 35.4377,133.4792 diff = 373.000000'
});
data_saddle.push({
lat: 3.5415777778e+01,
lng: 1.3349522222e+02,
content:'Saddle = 377.799988 pos = 35.4158,133.4952 diff = 373.000000'
});
data_peak.push({
lat: 3.5426000000e+01,
lng: 1.3348777778e+02,
cert : true,
content:'Name = JA/TT-038(JA/TT-038) peak = 604.099976 pos = 35.4260,133.4878 diff = 225.699982'
});
data_saddle.push({
lat: 3.5430777778e+01,
lng: 1.3348333333e+02,
content:'Saddle = 378.399994 pos = 35.4308,133.4833 diff = 225.699982'
});
data_peak.push({
lat: 3.5323666667e+01,
lng: 1.3476744444e+02,
cert : true,
content:'Name = JA/HG-036(JA/HG-036) peak = 856.700012 pos = 35.3237,134.7674 diff = 478.200012'
});
data_saddle.push({
lat: 3.5272555556e+01,
lng: 1.3477844444e+02,
content:'Saddle = 378.500000 pos = 35.2726,134.7784 diff = 478.200012'
});
data_peak.push({
lat: 3.5284777778e+01,
lng: 1.3479433333e+02,
cert : true,
content:'Name = JA/HG-061(JA/HG-061) peak = 704.599976 pos = 35.2848,134.7943 diff = 182.399963'
});
data_saddle.push({
lat: 3.5299333334e+01,
lng: 1.3479322222e+02,
content:'Saddle = 522.200012 pos = 35.2993,134.7932 diff = 182.399963'
});
data_peak.push({
lat: 3.5013000000e+01,
lng: 1.3472100000e+02,
cert : true,
content:'Name = JA/HG-093(JA/HG-093) peak = 573.299988 pos = 35.0130,134.7210 diff = 192.099976'
});
data_saddle.push({
lat: 3.5018666667e+01,
lng: 1.3471066667e+02,
content:'Saddle = 381.200012 pos = 35.0187,134.7107 diff = 192.099976'
});
data_peak.push({
lat: 3.5249333334e+01,
lng: 1.3307255556e+02,
cert : true,
content:'Name = JA/SN-031(JA/SN-031) peak = 804.299988 pos = 35.2493,133.0726 diff = 417.699982'
});
data_saddle.push({
lat: 3.5230777778e+01,
lng: 1.3310377778e+02,
content:'Saddle = 386.600006 pos = 35.2308,133.1038 diff = 417.699982'
});
data_peak.push({
lat: 3.5305666667e+01,
lng: 1.3306133333e+02,
cert : true,
content:'Name = JA/SN-054(JA/SN-054) peak = 664.599976 pos = 35.3057,133.0613 diff = 276.199982'
});
data_saddle.push({
lat: 3.5273666667e+01,
lng: 1.3307022222e+02,
content:'Saddle = 388.399994 pos = 35.2737,133.0702 diff = 276.199982'
});
data_peak.push({
lat: 3.5275444445e+01,
lng: 1.3300566667e+02,
cert : false,
content:' Peak = 606.700012 pos = 35.2754,133.0057 diff = 189.100006'
});
data_saddle.push({
lat: 3.5283000000e+01,
lng: 1.3305666667e+02,
content:'Saddle = 417.600006 pos = 35.2830,133.0567 diff = 189.100006'
});
data_peak.push({
lat: 3.5289444445e+01,
lng: 1.3310866667e+02,
cert : false,
content:' Peak = 573.099976 pos = 35.2894,133.1087 diff = 168.099976'
});
data_saddle.push({
lat: 3.5284000000e+01,
lng: 1.3309888889e+02,
content:'Saddle = 405.000000 pos = 35.2840,133.0989 diff = 168.099976'
});
data_peak.push({
lat: 3.5243777778e+01,
lng: 1.3278455556e+02,
cert : true,
content:'Name = JA/SN-076(JA/SN-076) peak = 568.299988 pos = 35.2438,132.7846 diff = 181.500000'
});
data_saddle.push({
lat: 3.5220111111e+01,
lng: 1.3275822222e+02,
content:'Saddle = 386.799988 pos = 35.2201,132.7582 diff = 181.500000'
});
data_peak.push({
lat: 3.5042000000e+01,
lng: 1.3358522222e+02,
cert : true,
content:'Name = JA/OY-076(JA/OY-076) peak = 585.299988 pos = 35.0420,133.5852 diff = 198.199982'
});
data_saddle.push({
lat: 3.5083222223e+01,
lng: 1.3358544444e+02,
content:'Saddle = 387.100006 pos = 35.0832,133.5854 diff = 198.199982'
});
data_peak.push({
lat: 3.5287444445e+01,
lng: 1.3328855556e+02,
cert : false,
content:' Peak = 540.400024 pos = 35.2874,133.2886 diff = 153.200012'
});
data_saddle.push({
lat: 3.5281666667e+01,
lng: 1.3329855556e+02,
content:'Saddle = 387.200012 pos = 35.2817,133.2986 diff = 153.200012'
});
data_peak.push({
lat: 3.4668666667e+01,
lng: 1.3303366667e+02,
cert : true,
content:'Name = JA/HS-123(JA/HS-123) peak = 647.400024 pos = 34.6687,133.0337 diff = 259.100037'
});
data_saddle.push({
lat: 3.4693777778e+01,
lng: 1.3312255556e+02,
content:'Saddle = 388.299988 pos = 34.6938,133.1226 diff = 259.100037'
});
data_peak.push({
lat: 3.4716666667e+01,
lng: 1.3303733333e+02,
cert : true,
content:'Name = JA/HS-145(JA/HS-145) peak = 574.400024 pos = 34.7167,133.0373 diff = 167.500031'
});
data_saddle.push({
lat: 3.4707777778e+01,
lng: 1.3302933333e+02,
content:'Saddle = 406.899994 pos = 34.7078,133.0293 diff = 167.500031'
});
data_peak.push({
lat: 3.4701888889e+01,
lng: 1.3309677778e+02,
cert : false,
content:' Peak = 583.500000 pos = 34.7019,133.0968 diff = 174.500000'
});
data_saddle.push({
lat: 3.4666777778e+01,
lng: 1.3307811111e+02,
content:'Saddle = 409.000000 pos = 34.6668,133.0781 diff = 174.500000'
});
data_peak.push({
lat: 3.4666888889e+01,
lng: 1.3301300000e+02,
cert : false,
content:' Peak = 600.599976 pos = 34.6669,133.0130 diff = 153.899963'
});
data_saddle.push({
lat: 3.4666777778e+01,
lng: 1.3302666667e+02,
content:'Saddle = 446.700012 pos = 34.6668,133.0267 diff = 153.899963'
});
data_peak.push({
lat: 3.4857555556e+01,
lng: 1.3342888889e+02,
cert : true,
content:'Name = Tenjinyama(JA/OY-048) peak = 776.000000 pos = 34.8576,133.4289 diff = 386.700012'
});
data_saddle.push({
lat: 3.4907000000e+01,
lng: 1.3330055556e+02,
content:'Saddle = 389.299988 pos = 34.9070,133.3006 diff = 386.700012'
});
data_peak.push({
lat: 3.4889000000e+01,
lng: 1.3330611111e+02,
cert : true,
content:'Name = JA/OY-082(JA/OY-082) peak = 568.500000 pos = 34.8890,133.3061 diff = 151.799988'
});
data_saddle.push({
lat: 3.4904555556e+01,
lng: 1.3332933333e+02,
content:'Saddle = 416.700012 pos = 34.9046,133.3293 diff = 151.799988'
});
data_peak.push({
lat: 3.4933111112e+01,
lng: 1.3337244444e+02,
cert : true,
content:'Name = Aratoyama(JA/OY-053) peak = 761.000000 pos = 34.9331,133.3724 diff = 273.200012'
});
data_saddle.push({
lat: 3.4871444445e+01,
lng: 1.3338388889e+02,
content:'Saddle = 487.799988 pos = 34.8714,133.3839 diff = 273.200012'
});
data_peak.push({
lat: 3.4844777778e+01,
lng: 1.3333544444e+02,
cert : true,
content:'Name = JA/OY-054(JA/OY-054) peak = 730.700012 pos = 34.8448,133.3354 diff = 202.900024'
});
data_saddle.push({
lat: 3.4905666667e+01,
lng: 1.3334833333e+02,
content:'Saddle = 527.799988 pos = 34.9057,133.3483 diff = 202.900024'
});
data_peak.push({
lat: 3.4874666667e+01,
lng: 1.3341244444e+02,
cert : true,
content:'Name = JA/OY-050(JA/OY-050) peak = 772.500000 pos = 34.8747,133.4124 diff = 209.799988'
});
data_saddle.push({
lat: 3.4858222223e+01,
lng: 1.3341900000e+02,
content:'Saddle = 562.700012 pos = 34.8582,133.4190 diff = 209.799988'
});
data_peak.push({
lat: 3.5546222222e+01,
lng: 1.3452755556e+02,
cert : true,
content:'Name = JA/HG-094(JA/HG-094) peak = 573.500000 pos = 35.5462,134.5276 diff = 182.000000'
});
data_saddle.push({
lat: 3.5521888889e+01,
lng: 1.3452911111e+02,
content:'Saddle = 391.500000 pos = 35.5219,134.5291 diff = 182.000000'
});
data_peak.push({
lat: 3.5389666667e+01,
lng: 1.3434044444e+02,
cert : true,
content:'Name = JA/TT-037(JA/TT-037) peak = 654.099976 pos = 35.3897,134.3404 diff = 262.599976'
});
data_saddle.push({
lat: 3.5376444445e+01,
lng: 1.3434477778e+02,
content:'Saddle = 391.500000 pos = 35.3764,134.3448 diff = 262.599976'
});
data_peak.push({
lat: 3.5166555556e+01,
lng: 1.3294444444e+02,
cert : false,
content:' Peak = 551.099976 pos = 35.1666,132.9444 diff = 155.099976'
});
data_saddle.push({
lat: 3.5146111111e+01,
lng: 1.3293200000e+02,
content:'Saddle = 396.000000 pos = 35.1461,132.9320 diff = 155.099976'
});
data_peak.push({
lat: 3.5204333334e+01,
lng: 1.3464122222e+02,
cert : false,
content:' Peak = 553.400024 pos = 35.2043,134.6412 diff = 155.700012'
});
data_saddle.push({
lat: 3.5222000000e+01,
lng: 1.3464177778e+02,
content:'Saddle = 397.700012 pos = 35.2220,134.6418 diff = 155.700012'
});
data_peak.push({
lat: 3.5323777778e+01,
lng: 1.3470088889e+02,
cert : true,
content:'Name = JA/HG-050(JA/HG-050) peak = 770.500000 pos = 35.3238,134.7009 diff = 372.700012'
});
data_saddle.push({
lat: 3.5314222222e+01,
lng: 1.3471233333e+02,
content:'Saddle = 397.799988 pos = 35.3142,134.7123 diff = 372.700012'
});
data_peak.push({
lat: 3.5106444445e+01,
lng: 1.3426822222e+02,
cert : true,
content:'Name = JA/OY-078(JA/OY-078) peak = 583.200012 pos = 35.1064,134.2682 diff = 184.700012'
});
data_saddle.push({
lat: 3.5139666667e+01,
lng: 1.3428855556e+02,
content:'Saddle = 398.500000 pos = 35.1397,134.2886 diff = 184.700012'
});
data_peak.push({
lat: 3.5085555556e+01,
lng: 1.3441866667e+02,
cert : true,
content:'Name = JA/HG-095(JA/HG-095) peak = 574.299988 pos = 35.0856,134.4187 diff = 173.500000'
});
data_saddle.push({
lat: 3.5100444445e+01,
lng: 1.3441244444e+02,
content:'Saddle = 400.799988 pos = 35.1004,134.4124 diff = 173.500000'
});
data_peak.push({
lat: 3.5051555556e+01,
lng: 1.3455366667e+02,
cert : true,
content:'Name = JA/HG-078(JA/HG-078) peak = 644.599976 pos = 35.0516,134.5537 diff = 243.299988'
});
data_saddle.push({
lat: 3.5061777778e+01,
lng: 1.3454944444e+02,
content:'Saddle = 401.299988 pos = 35.0618,134.5494 diff = 243.299988'
});
data_peak.push({
lat: 3.4786222223e+01,
lng: 1.3343644444e+02,
cert : false,
content:' Peak = 567.400024 pos = 34.7862,133.4364 diff = 164.400024'
});
data_saddle.push({
lat: 3.4762333334e+01,
lng: 1.3343244444e+02,
content:'Saddle = 403.000000 pos = 34.7623,133.4324 diff = 164.400024'
});
data_peak.push({
lat: 3.4878555556e+01,
lng: 1.3276177778e+02,
cert : true,
content:'Name = JA/HS-134(JA/HS-134) peak = 613.099976 pos = 34.8786,132.7618 diff = 205.999969'
});
data_saddle.push({
lat: 3.4885333334e+01,
lng: 1.3276366667e+02,
content:'Saddle = 407.100006 pos = 34.8853,132.7637 diff = 205.999969'
});
data_peak.push({
lat: 3.4842222223e+01,
lng: 1.3275566667e+02,
cert : false,
content:' Peak = 612.000000 pos = 34.8422,132.7557 diff = 165.100006'
});
data_saddle.push({
lat: 3.4867666667e+01,
lng: 1.3274288889e+02,
content:'Saddle = 446.899994 pos = 34.8677,132.7429 diff = 165.100006'
});
data_peak.push({
lat: 3.4912000000e+01,
lng: 1.3324555556e+02,
cert : false,
content:' Peak = 557.700012 pos = 34.9120,133.2456 diff = 150.200012'
});
data_saddle.push({
lat: 3.4909555556e+01,
lng: 1.3323700000e+02,
content:'Saddle = 407.500000 pos = 34.9096,133.2370 diff = 150.200012'
});
data_peak.push({
lat: 3.5176333334e+01,
lng: 1.3284944444e+02,
cert : true,
content:'Name = JA/SN-053(JA/SN-053) peak = 662.799988 pos = 35.1763,132.8494 diff = 255.099976'
});
data_saddle.push({
lat: 3.5157666667e+01,
lng: 1.3287666667e+02,
content:'Saddle = 407.700012 pos = 35.1577,132.8767 diff = 255.099976'
});
data_peak.push({
lat: 3.5001777778e+01,
lng: 1.3342222222e+02,
cert : false,
content:' Peak = 573.900024 pos = 35.0018,133.4222 diff = 165.800018'
});
data_saddle.push({
lat: 3.5013333334e+01,
lng: 1.3341511111e+02,
content:'Saddle = 408.100006 pos = 35.0133,133.4151 diff = 165.800018'
});
data_peak.push({
lat: 3.5148444445e+01,
lng: 1.3291777778e+02,
cert : false,
content:' Peak = 572.500000 pos = 35.1484,132.9178 diff = 164.299988'
});
data_saddle.push({
lat: 3.5144000000e+01,
lng: 1.3291622222e+02,
content:'Saddle = 408.200012 pos = 35.1440,132.9162 diff = 164.299988'
});
data_peak.push({
lat: 3.5511777778e+01,
lng: 1.3471444444e+02,
cert : true,
content:'Name = JA/HG-073(JA/HG-073) peak = 661.900024 pos = 35.5118,134.7144 diff = 253.400024'
});
data_saddle.push({
lat: 3.5517222222e+01,
lng: 1.3468588889e+02,
content:'Saddle = 408.500000 pos = 35.5172,134.6859 diff = 253.400024'
});
data_peak.push({
lat: 3.4891111112e+01,
lng: 1.3276488889e+02,
cert : false,
content:' Peak = 561.900024 pos = 34.8911,132.7649 diff = 150.900024'
});
data_saddle.push({
lat: 3.4899222223e+01,
lng: 1.3276488889e+02,
content:'Saddle = 411.000000 pos = 34.8992,132.7649 diff = 150.900024'
});
data_peak.push({
lat: 3.5140555556e+01,
lng: 1.3262144444e+02,
cert : true,
content:'Name = Sanbesan (Osanbesan)(JA/SN-004) peak = 1124.500000 pos = 35.1406,132.6214 diff = 708.200012'
});
data_saddle.push({
lat: 3.5076888889e+01,
lng: 1.3267333333e+02,
content:'Saddle = 416.299988 pos = 35.0769,132.6733 diff = 708.200012'
});
data_peak.push({
lat: 3.4905000000e+01,
lng: 1.3305722222e+02,
cert : true,
content:'Name = JA/HS-132(JA/HS-132) peak = 621.000000 pos = 34.9050,133.0572 diff = 202.200012'
});
data_saddle.push({
lat: 3.4915000000e+01,
lng: 1.3305900000e+02,
content:'Saddle = 418.799988 pos = 34.9150,133.0590 diff = 202.200012'
});
data_peak.push({
lat: 3.5072666667e+01,
lng: 1.3268688889e+02,
cert : true,
content:'Name = JA/SN-050(JA/SN-050) peak = 681.099976 pos = 35.0727,132.6869 diff = 257.799988'
});
data_saddle.push({
lat: 3.5054222223e+01,
lng: 1.3271800000e+02,
content:'Saddle = 423.299988 pos = 35.0542,132.7180 diff = 257.799988'
});
data_peak.push({
lat: 3.5491888889e+01,
lng: 1.3437322222e+02,
cert : true,
content:'Name = JA/TT-036(JA/TT-036) peak = 662.900024 pos = 35.4919,134.3732 diff = 235.700012'
});
data_saddle.push({
lat: 3.5499000000e+01,
lng: 1.3438688889e+02,
content:'Saddle = 427.200012 pos = 35.4990,134.3869 diff = 235.700012'
});
data_peak.push({
lat: 3.4853444445e+01,
lng: 1.3327700000e+02,
cert : true,
content:'Name = JA/HS-137(JA/HS-137) peak = 605.799988 pos = 34.8534,133.2770 diff = 177.299988'
});
data_saddle.push({
lat: 3.4858111112e+01,
lng: 1.3324811111e+02,
content:'Saddle = 428.500000 pos = 34.8581,133.2481 diff = 177.299988'
});
data_peak.push({
lat: 3.5423111111e+01,
lng: 1.3472777778e+02,
cert : false,
content:' Peak = 582.599976 pos = 35.4231,134.7278 diff = 150.199982'
});
data_saddle.push({
lat: 3.5424777778e+01,
lng: 1.3471700000e+02,
content:'Saddle = 432.399994 pos = 35.4248,134.7170 diff = 150.199982'
});
data_peak.push({
lat: 3.5145666667e+01,
lng: 1.3476677778e+02,
cert : true,
content:'Name = JA/HG-062(JA/HG-062) peak = 691.599976 pos = 35.1457,134.7668 diff = 254.899963'
});
data_saddle.push({
lat: 3.5165000000e+01,
lng: 1.3477844444e+02,
content:'Saddle = 436.700012 pos = 35.1650,134.7784 diff = 254.899963'
});
data_peak.push({
lat: 3.5257111111e+01,
lng: 1.3477422222e+02,
cert : true,
content:'Name = JA/HG-054(JA/HG-054) peak = 742.799988 pos = 35.2571,134.7742 diff = 301.000000'
});
data_saddle.push({
lat: 3.5277666667e+01,
lng: 1.3474666667e+02,
content:'Saddle = 441.799988 pos = 35.2777,134.7467 diff = 301.000000'
});
data_peak.push({
lat: 3.5025666667e+01,
lng: 1.3268777778e+02,
cert : true,
content:'Name = JA/SN-038(JA/SN-038) peak = 741.299988 pos = 35.0257,132.6878 diff = 298.299988'
});
data_saddle.push({
lat: 3.5008666667e+01,
lng: 1.3270700000e+02,
content:'Saddle = 443.000000 pos = 35.0087,132.7070 diff = 298.299988'
});
data_peak.push({
lat: 3.5410666667e+01,
lng: 1.3464388889e+02,
cert : true,
content:'Name = Myoukenyama(JA/HG-011) peak = 1138.199951 pos = 35.4107,134.6439 diff = 691.899963'
});
data_saddle.push({
lat: 3.5387333334e+01,
lng: 1.3459111111e+02,
content:'Saddle = 446.299988 pos = 35.3873,134.5911 diff = 691.899963'
});
data_peak.push({
lat: 3.5379888889e+01,
lng: 1.3461588889e+02,
cert : true,
content:'Name = JA/HG-046(JA/HG-046) peak = 802.400024 pos = 35.3799,134.6159 diff = 295.300018'
});
data_saddle.push({
lat: 3.5400222222e+01,
lng: 1.3461077778e+02,
content:'Saddle = 507.100006 pos = 35.4002,134.6108 diff = 295.300018'
});
data_peak.push({
lat: 3.5537222222e+01,
lng: 1.3463688889e+02,
cert : true,
content:'Name = JA/HG-032(JA/HG-032) peak = 916.200012 pos = 35.5372,134.6369 diff = 263.799988'
});
data_saddle.push({
lat: 3.5524888889e+01,
lng: 1.3463300000e+02,
content:'Saddle = 652.400024 pos = 35.5249,134.6330 diff = 263.799988'
});
data_peak.push({
lat: 3.5470777778e+01,
lng: 1.3463788889e+02,
cert : true,
content:'Name = Sobugatake(JA/HG-016) peak = 1073.599976 pos = 35.4708,134.6379 diff = 310.699951'
});
data_saddle.push({
lat: 3.5444000000e+01,
lng: 1.3463144444e+02,
content:'Saddle = 762.900024 pos = 35.4440,134.6314 diff = 310.699951'
});
data_peak.push({
lat: 3.5272222223e+01,
lng: 1.3344500000e+02,
cert : false,
content:' Peak = 771.599976 pos = 35.2722,133.4450 diff = 324.599976'
});
data_saddle.push({
lat: 3.5257111111e+01,
lng: 1.3341811111e+02,
content:'Saddle = 447.000000 pos = 35.2571,133.4181 diff = 324.599976'
});
data_peak.push({
lat: 3.5261888889e+01,
lng: 1.3342833333e+02,
cert : false,
content:' Peak = 671.700012 pos = 35.2619,133.4283 diff = 184.300018'
});
data_saddle.push({
lat: 3.5267444445e+01,
lng: 1.3343544444e+02,
content:'Saddle = 487.399994 pos = 35.2674,133.4354 diff = 184.300018'
});
data_peak.push({
lat: 3.5015888889e+01,
lng: 1.3470366667e+02,
cert : true,
content:'Name = JA/HG-067(JA/HG-067) peak = 680.400024 pos = 35.0159,134.7037 diff = 232.400024'
});
data_saddle.push({
lat: 3.5032555556e+01,
lng: 1.3471133333e+02,
content:'Saddle = 448.000000 pos = 35.0326,134.7113 diff = 232.400024'
});
data_peak.push({
lat: 3.5245000000e+01,
lng: 1.3337477778e+02,
cert : false,
content:' Peak = 733.099976 pos = 35.2450,133.3748 diff = 285.099976'
});
data_saddle.push({
lat: 3.5237777778e+01,
lng: 1.3333544444e+02,
content:'Saddle = 448.000000 pos = 35.2378,133.3354 diff = 285.099976'
});
data_peak.push({
lat: 3.5240111111e+01,
lng: 1.3339966667e+02,
cert : true,
content:'Name = JA/TT-032(JA/TT-032) peak = 726.000000 pos = 35.2401,133.3997 diff = 247.000000'
});
data_saddle.push({
lat: 3.5236666667e+01,
lng: 1.3338677778e+02,
content:'Saddle = 479.000000 pos = 35.2367,133.3868 diff = 247.000000'
});
data_peak.push({
lat: 3.5219444445e+01,
lng: 1.3336011111e+02,
cert : false,
content:' Peak = 712.900024 pos = 35.2194,133.3601 diff = 210.300018'
});
data_saddle.push({
lat: 3.5229888889e+01,
lng: 1.3336055556e+02,
content:'Saddle = 502.600006 pos = 35.2299,133.3606 diff = 210.300018'
});
data_peak.push({
lat: 3.5147222223e+01,
lng: 1.3274211111e+02,
cert : true,
content:'Name = JA/SN-061(JA/SN-061) peak = 622.099976 pos = 35.1472,132.7421 diff = 169.799988'
});
data_saddle.push({
lat: 3.5146666667e+01,
lng: 1.3275000000e+02,
content:'Saddle = 452.299988 pos = 35.1467,132.7500 diff = 169.799988'
});
data_peak.push({
lat: 3.5161444445e+01,
lng: 1.3271000000e+02,
cert : true,
content:'Name = JA/SN-055(JA/SN-055) peak = 657.000000 pos = 35.1614,132.7100 diff = 200.100006'
});
data_saddle.push({
lat: 3.5138777778e+01,
lng: 1.3272033333e+02,
content:'Saddle = 456.899994 pos = 35.1388,132.7203 diff = 200.100006'
});
data_peak.push({
lat: 3.5258333334e+01,
lng: 1.3327300000e+02,
cert : true,
content:'Name = JA/TT-034(JA/TT-034) peak = 705.299988 pos = 35.2583,133.2730 diff = 247.000000'
});
data_saddle.push({
lat: 3.5246222223e+01,
lng: 1.3323200000e+02,
content:'Saddle = 458.299988 pos = 35.2462,133.2320 diff = 247.000000'
});
data_peak.push({
lat: 3.5255777778e+01,
lng: 1.3332233333e+02,
cert : false,
content:' Peak = 673.299988 pos = 35.2558,133.3223 diff = 184.399994'
});
data_saddle.push({
lat: 3.5261555556e+01,
lng: 1.3328466667e+02,
content:'Saddle = 488.899994 pos = 35.2616,133.2847 diff = 184.399994'
});
data_peak.push({
lat: 3.5314333334e+01,
lng: 1.3421811111e+02,
cert : true,
content:'Name = JA/TT-030(JA/TT-030) peak = 742.599976 pos = 35.3143,134.2181 diff = 279.999969'
});
data_saddle.push({
lat: 3.5294777778e+01,
lng: 1.3423733333e+02,
content:'Saddle = 462.600006 pos = 35.2948,134.2373 diff = 279.999969'
});
data_peak.push({
lat: 3.5329000000e+01,
lng: 1.3422033333e+02,
cert : false,
content:' Peak = 645.599976 pos = 35.3290,134.2203 diff = 182.699982'
});
data_saddle.push({
lat: 3.5323111111e+01,
lng: 1.3421955556e+02,
content:'Saddle = 462.899994 pos = 35.3231,134.2196 diff = 182.699982'
});
data_peak.push({
lat: 3.5128222223e+01,
lng: 1.3272366667e+02,
cert : true,
content:'Name = JA/SN-041(JA/SN-041) peak = 721.700012 pos = 35.1282,132.7237 diff = 255.400024'
});
data_saddle.push({
lat: 3.5121888889e+01,
lng: 1.3274544444e+02,
content:'Saddle = 466.299988 pos = 35.1219,132.7454 diff = 255.400024'
});
data_peak.push({
lat: 3.5202555556e+01,
lng: 1.3405444444e+02,
cert : true,
content:'Name = JA/OY-065(JA/OY-065) peak = 681.400024 pos = 35.2026,134.0544 diff = 205.800018'
});
data_saddle.push({
lat: 3.5211000000e+01,
lng: 1.3405555556e+02,
content:'Saddle = 475.600006 pos = 35.2110,134.0556 diff = 205.800018'
});
data_peak.push({
lat: 3.5224111111e+01,
lng: 1.3368688889e+02,
cert : true,
content:'Name = JA/OY-064(JA/OY-064) peak = 681.799988 pos = 35.2241,133.6869 diff = 205.000000'
});
data_saddle.push({
lat: 3.5227888889e+01,
lng: 1.3366544444e+02,
content:'Saddle = 476.799988 pos = 35.2279,133.6654 diff = 205.000000'
});
data_peak.push({
lat: 3.5224333334e+01,
lng: 1.3476955556e+02,
cert : false,
content:' Peak = 660.799988 pos = 35.2243,134.7696 diff = 183.500000'
});
data_saddle.push({
lat: 3.5230000000e+01,
lng: 1.3475533333e+02,
content:'Saddle = 477.299988 pos = 35.2300,134.7553 diff = 183.500000'
});
data_peak.push({
lat: 3.5108444445e+01,
lng: 1.3459144444e+02,
cert : false,
content:' Peak = 630.500000 pos = 35.1084,134.5914 diff = 151.299988'
});
data_saddle.push({
lat: 3.5122444445e+01,
lng: 1.3460033333e+02,
content:'Saddle = 479.200012 pos = 35.1224,134.6003 diff = 151.299988'
});
data_peak.push({
lat: 3.4683222223e+01,
lng: 1.3317277778e+02,
cert : true,
content:'Name = JA/HS-096(JA/HS-096) peak = 726.900024 pos = 34.6832,133.1728 diff = 242.200012'
});
data_saddle.push({
lat: 3.4666777778e+01,
lng: 1.3320877778e+02,
content:'Saddle = 484.700012 pos = 34.6668,133.2088 diff = 242.200012'
});
data_peak.push({
lat: 3.5149222223e+01,
lng: 1.3378744444e+02,
cert : false,
content:' Peak = 642.299988 pos = 35.1492,133.7874 diff = 156.099976'
});
data_saddle.push({
lat: 3.5152777778e+01,
lng: 1.3378588889e+02,
content:'Saddle = 486.200012 pos = 35.1528,133.7859 diff = 156.099976'
});
data_peak.push({
lat: 3.4776000000e+01,
lng: 1.3333022222e+02,
cert : true,
content:'Name = JA/HS-118(JA/HS-118) peak = 660.900024 pos = 34.7760,133.3302 diff = 172.900024'
});
data_saddle.push({
lat: 3.4774666667e+01,
lng: 1.3333788889e+02,
content:'Saddle = 488.000000 pos = 34.7747,133.3379 diff = 172.900024'
});
data_peak.push({
lat: 3.4994888889e+01,
lng: 1.3269311111e+02,
cert : false,
content:' Peak = 685.700012 pos = 34.9949,132.6931 diff = 197.100006'
});
data_saddle.push({
lat: 3.4988666667e+01,
lng: 1.3270566667e+02,
content:'Saddle = 488.600006 pos = 34.9887,132.7057 diff = 197.100006'
});
data_peak.push({
lat: 3.4748222223e+01,
lng: 1.3322166667e+02,
cert : true,
content:'Name = Hoshinokoyama(JA/HS-061) peak = 834.099976 pos = 34.7482,133.2217 diff = 338.199982'
});
data_saddle.push({
lat: 3.4775888889e+01,
lng: 1.3317466667e+02,
content:'Saddle = 495.899994 pos = 34.7759,133.1747 diff = 338.199982'
});
data_peak.push({
lat: 3.4811444445e+01,
lng: 1.3337566667e+02,
cert : true,
content:'Name = JA/OY-068(JA/OY-068) peak = 653.799988 pos = 34.8114,133.3757 diff = 156.699982'
});
data_saddle.push({
lat: 3.4801555556e+01,
lng: 1.3337811111e+02,
content:'Saddle = 497.100006 pos = 34.8016,133.3781 diff = 156.699982'
});
data_peak.push({
lat: 3.4768777778e+01,
lng: 1.3327722222e+02,
cert : false,
content:' Peak = 677.000000 pos = 34.7688,133.2772 diff = 169.200012'
});
data_saddle.push({
lat: 3.4764333334e+01,
lng: 1.3328000000e+02,
content:'Saddle = 507.799988 pos = 34.7643,133.2800 diff = 169.200012'
});
data_peak.push({
lat: 3.4742666667e+01,
lng: 1.3330411111e+02,
cert : true,
content:'Name = JA/HS-087(JA/HS-087) peak = 741.700012 pos = 34.7427,133.3041 diff = 204.200012'
});
data_saddle.push({
lat: 3.4730333334e+01,
lng: 1.3328955556e+02,
content:'Saddle = 537.500000 pos = 34.7303,133.2896 diff = 204.200012'
});
data_peak.push({
lat: 3.4753444445e+01,
lng: 1.3329100000e+02,
cert : false,
content:' Peak = 708.500000 pos = 34.7534,133.2910 diff = 154.000000'
});
data_saddle.push({
lat: 3.4746555556e+01,
lng: 1.3329433333e+02,
content:'Saddle = 554.500000 pos = 34.7466,133.2943 diff = 154.000000'
});
data_peak.push({
lat: 3.4752666667e+01,
lng: 1.3316577778e+02,
cert : true,
content:'Name = JA/HS-082(JA/HS-082) peak = 767.099976 pos = 34.7527,133.1658 diff = 224.000000'
});
data_saddle.push({
lat: 3.4729333334e+01,
lng: 1.3315955556e+02,
content:'Saddle = 543.099976 pos = 34.7293,133.1596 diff = 224.000000'
});
data_peak.push({
lat: 3.4727777778e+01,
lng: 1.3324966667e+02,
cert : false,
content:' Peak = 745.400024 pos = 34.7278,133.2497 diff = 157.700012'
});
data_saddle.push({
lat: 3.4705666667e+01,
lng: 1.3320766667e+02,
content:'Saddle = 587.700012 pos = 34.7057,133.2077 diff = 157.700012'
});
data_peak.push({
lat: 3.5182777778e+01,
lng: 1.3274955556e+02,
cert : true,
content:'Name = JA/SN-040(JA/SN-040) peak = 725.099976 pos = 35.1828,132.7496 diff = 228.899963'
});
data_saddle.push({
lat: 3.5163333334e+01,
lng: 1.3277277778e+02,
content:'Saddle = 496.200012 pos = 35.1633,132.7728 diff = 228.899963'
});
data_peak.push({
lat: 3.5187666667e+01,
lng: 1.3278388889e+02,
cert : true,
content:'Name = JA/SN-048(JA/SN-048) peak = 710.500000 pos = 35.1877,132.7839 diff = 213.700012'
});
data_saddle.push({
lat: 3.5180555556e+01,
lng: 1.3277711111e+02,
content:'Saddle = 496.799988 pos = 35.1806,132.7771 diff = 213.700012'
});
data_peak.push({
lat: 3.5161333334e+01,
lng: 1.3381644444e+02,
cert : true,
content:'Name = JA/OY-063(JA/OY-063) peak = 685.799988 pos = 35.1613,133.8164 diff = 189.299988'
});
data_saddle.push({
lat: 3.5167777778e+01,
lng: 1.3382111111e+02,
content:'Saddle = 496.500000 pos = 35.1678,133.8211 diff = 189.299988'
});
data_peak.push({
lat: 3.5138333334e+01,
lng: 1.3383788889e+02,
cert : true,
content:'Name = JA/OY-052(JA/OY-052) peak = 761.900024 pos = 35.1383,133.8379 diff = 264.600037'
});
data_saddle.push({
lat: 3.5177555556e+01,
lng: 1.3386922222e+02,
content:'Saddle = 497.299988 pos = 35.1776,133.8692 diff = 264.600037'
});
data_peak.push({
lat: 3.4913222223e+01,
lng: 1.3282477778e+02,
cert : false,
content:' Peak = 706.400024 pos = 34.9132,132.8248 diff = 198.600037'
});
data_saddle.push({
lat: 3.4918666667e+01,
lng: 1.3281777778e+02,
content:'Saddle = 507.799988 pos = 34.9187,132.8178 diff = 198.600037'
});
data_peak.push({
lat: 3.5303888889e+01,
lng: 1.3423877778e+02,
cert : false,
content:' Peak = 664.200012 pos = 35.3039,134.2388 diff = 156.200012'
});
data_saddle.push({
lat: 3.5299666667e+01,
lng: 1.3425411111e+02,
content:'Saddle = 508.000000 pos = 35.2997,134.2541 diff = 156.200012'
});
data_peak.push({
lat: 3.5354000000e+01,
lng: 1.3451377778e+02,
cert : true,
content:'Name = Hyunosen (Suganosen)(JA/HG-001) peak = 1509.199951 pos = 35.3540,134.5138 diff = 1000.399963'
});
data_saddle.push({
lat: 3.5293333334e+01,
lng: 1.3378644444e+02,
content:'Saddle = 508.799988 pos = 35.2933,133.7864 diff = 1000.399963'
});
data_peak.push({
lat: 3.5139666667e+01,
lng: 1.3410288889e+02,
cert : true,
content:'Name = JA/OY-046(JA/OY-046) peak = 792.200012 pos = 35.1397,134.1029 diff = 271.299988'
});
data_saddle.push({
lat: 3.5148222223e+01,
lng: 1.3411422222e+02,
content:'Saddle = 520.900024 pos = 35.1482,134.1142 diff = 271.299988'
});
data_peak.push({
lat: 3.5165000000e+01,
lng: 1.3435400000e+02,
cert : true,
content:'Name = JA/OY-059(JA/OY-059) peak = 702.400024 pos = 35.1650,134.3540 diff = 181.300049'
});
data_saddle.push({
lat: 3.5169777778e+01,
lng: 1.3435788889e+02,
content:'Saddle = 521.099976 pos = 35.1698,134.3579 diff = 181.300049'
});
data_peak.push({
lat: 3.5422000000e+01,
lng: 1.3397244444e+02,
cert : true,
content:'Name = JA/TT-026(JA/TT-026) peak = 772.099976 pos = 35.4220,133.9724 diff = 235.399963'
});
data_saddle.push({
lat: 3.5415666667e+01,
lng: 1.3399388889e+02,
content:'Saddle = 536.700012 pos = 35.4157,133.9939 diff = 235.399963'
});
data_peak.push({
lat: 3.5178222223e+01,
lng: 1.3464700000e+02,
cert : true,
content:'Name = JA/HG-037(JA/HG-037) peak = 841.700012 pos = 35.1782,134.6470 diff = 302.700012'
});
data_saddle.push({
lat: 3.5188000000e+01,
lng: 1.3465611111e+02,
content:'Saddle = 539.000000 pos = 35.1880,134.6561 diff = 302.700012'
});
data_peak.push({
lat: 3.5128666667e+01,
lng: 1.3445188889e+02,
cert : true,
content:'Name = JA/HG-055(JA/HG-055) peak = 741.900024 pos = 35.1287,134.4519 diff = 196.100037'
});
data_saddle.push({
lat: 3.5136000000e+01,
lng: 1.3446155556e+02,
content:'Saddle = 545.799988 pos = 35.1360,134.4616 diff = 196.100037'
});
data_peak.push({
lat: 3.5158444445e+01,
lng: 1.3429388889e+02,
cert : false,
content:' Peak = 723.400024 pos = 35.1584,134.2939 diff = 176.200012'
});
data_saddle.push({
lat: 3.5169333334e+01,
lng: 1.3428900000e+02,
content:'Saddle = 547.200012 pos = 35.1693,134.2890 diff = 176.200012'
});
data_peak.push({
lat: 3.5422333334e+01,
lng: 1.3404422222e+02,
cert : true,
content:'Name = Jūbōzan(JA/TT-019) peak = 920.500000 pos = 35.4223,134.0442 diff = 358.200012'
});
data_saddle.push({
lat: 3.5403333334e+01,
lng: 1.3404155556e+02,
content:'Saddle = 562.299988 pos = 35.4033,134.0416 diff = 358.200012'
});
data_peak.push({
lat: 3.5139000000e+01,
lng: 1.3374400000e+02,
cert : true,
content:'Name = Misakayama(JA/OY-039) peak = 901.400024 pos = 35.1390,133.7440 diff = 334.000000'
});
data_saddle.push({
lat: 3.5157000000e+01,
lng: 1.3376766667e+02,
content:'Saddle = 567.400024 pos = 35.1570,133.7677 diff = 334.000000'
});
data_peak.push({
lat: 3.5145222223e+01,
lng: 1.3376122222e+02,
cert : false,
content:' Peak = 882.200012 pos = 35.1452,133.7612 diff = 169.000000'
});
data_saddle.push({
lat: 3.5140666667e+01,
lng: 1.3375022222e+02,
content:'Saddle = 713.200012 pos = 35.1407,133.7502 diff = 169.000000'
});
data_peak.push({
lat: 3.5205666667e+01,
lng: 1.3392166667e+02,
cert : false,
content:' Peak = 750.900024 pos = 35.2057,133.9217 diff = 174.300049'
});
data_saddle.push({
lat: 3.5203222223e+01,
lng: 1.3392833333e+02,
content:'Saddle = 576.599976 pos = 35.2032,133.9283 diff = 174.300049'
});
data_peak.push({
lat: 3.5146111111e+01,
lng: 1.3405055556e+02,
cert : true,
content:'Name = JA/OY-043(JA/OY-043) peak = 831.500000 pos = 35.1461,134.0506 diff = 253.299988'
});
data_saddle.push({
lat: 3.5159111111e+01,
lng: 1.3401588889e+02,
content:'Saddle = 578.200012 pos = 35.1591,134.0159 diff = 253.299988'
});
data_peak.push({
lat: 3.5183333334e+01,
lng: 1.3469755556e+02,
cert : true,
content:'Name = JA/HG-009(JA/HG-009) peak = 1140.599976 pos = 35.1833,134.6976 diff = 560.099976'
});
data_saddle.push({
lat: 3.5255111111e+01,
lng: 1.3465222222e+02,
content:'Saddle = 580.500000 pos = 35.2551,134.6522 diff = 560.099976'
});
data_peak.push({
lat: 3.5257111111e+01,
lng: 1.3474477778e+02,
cert : true,
content:'Name = JA/HG-047(JA/HG-047) peak = 796.400024 pos = 35.2571,134.7448 diff = 202.700012'
});
data_saddle.push({
lat: 3.5259777778e+01,
lng: 1.3474088889e+02,
content:'Saddle = 593.700012 pos = 35.2598,134.7409 diff = 202.700012'
});
data_peak.push({
lat: 3.5286000000e+01,
lng: 1.3469588889e+02,
cert : true,
content:'Name = JA/HG-018(JA/HG-018) peak = 1052.099976 pos = 35.2860,134.6959 diff = 378.799988'
});
data_saddle.push({
lat: 3.5224777778e+01,
lng: 1.3469811111e+02,
content:'Saddle = 673.299988 pos = 35.2248,134.6981 diff = 378.799988'
});
data_peak.push({
lat: 3.5254111111e+01,
lng: 1.3470200000e+02,
cert : true,
content:'Name = JA/HG-024(JA/HG-024) peak = 983.400024 pos = 35.2541,134.7020 diff = 209.100037'
});
data_saddle.push({
lat: 3.5268111111e+01,
lng: 1.3469166667e+02,
content:'Saddle = 774.299988 pos = 35.2681,134.6917 diff = 209.100037'
});
data_peak.push({
lat: 3.5198222223e+01,
lng: 1.3467888889e+02,
cert : true,
content:'Name = JA/HG-026(JA/HG-026) peak = 963.900024 pos = 35.1982,134.6789 diff = 261.800049'
});
data_saddle.push({
lat: 3.5200333334e+01,
lng: 1.3468977778e+02,
content:'Saddle = 702.099976 pos = 35.2003,134.6898 diff = 261.800049'
});
data_peak.push({
lat: 3.5089666667e+01,
lng: 1.3466222222e+02,
cert : true,
content:'Name = JA/HG-025(JA/HG-025) peak = 975.200012 pos = 35.0897,134.6622 diff = 247.500000'
});
data_saddle.push({
lat: 3.5106444445e+01,
lng: 1.3466233333e+02,
content:'Saddle = 727.700012 pos = 35.1064,134.6623 diff = 247.500000'
});
data_peak.push({
lat: 3.5132333334e+01,
lng: 1.3465666667e+02,
cert : true,
content:'Name = JA/HG-015(JA/HG-015) peak = 1076.599976 pos = 35.1323,134.6567 diff = 257.199951'
});
data_saddle.push({
lat: 3.5153444445e+01,
lng: 1.3469166667e+02,
content:'Saddle = 819.400024 pos = 35.1534,134.6917 diff = 257.199951'
});
data_peak.push({
lat: 3.5113222223e+01,
lng: 1.3465622222e+02,
cert : false,
content:' Peak = 1001.799988 pos = 35.1132,134.6562 diff = 154.000000'
});
data_saddle.push({
lat: 3.5119666667e+01,
lng: 1.3466000000e+02,
content:'Saddle = 847.799988 pos = 35.1197,134.6600 diff = 154.000000'
});
data_peak.push({
lat: 3.5190888889e+01,
lng: 1.3472733333e+02,
cert : true,
content:'Name = Dangamine(JA/HG-013) peak = 1101.599976 pos = 35.1909,134.7273 diff = 193.699951'
});
data_saddle.push({
lat: 3.5184777778e+01,
lng: 1.3471222222e+02,
content:'Saddle = 907.900024 pos = 35.1848,134.7122 diff = 193.699951'
});
data_peak.push({
lat: 3.5148666667e+01,
lng: 1.3457566667e+02,
cert : true,
content:'Name = JA/HG-049(JA/HG-049) peak = 790.400024 pos = 35.1487,134.5757 diff = 208.300049'
});
data_saddle.push({
lat: 3.5155000000e+01,
lng: 1.3457533333e+02,
content:'Saddle = 582.099976 pos = 35.1550,134.5753 diff = 208.300049'
});
data_peak.push({
lat: 3.5171666667e+01,
lng: 1.3418022222e+02,
cert : true,
content:'Name = Nagisan(JA/OY-001) peak = 1253.099976 pos = 35.1717,134.1802 diff = 665.599976'
});
data_saddle.push({
lat: 3.5209777778e+01,
lng: 1.3433000000e+02,
content:'Saddle = 587.500000 pos = 35.2098,134.3300 diff = 665.599976'
});
data_peak.push({
lat: 3.5327666667e+01,
lng: 1.3388855556e+02,
cert : true,
content:'Name = JA/TT-021(JA/TT-021) peak = 873.400024 pos = 35.3277,133.8886 diff = 249.400024'
});
data_saddle.push({
lat: 3.5334000000e+01,
lng: 1.3389333333e+02,
content:'Saddle = 624.000000 pos = 35.3340,133.8933 diff = 249.400024'
});
data_peak.push({
lat: 3.5198111111e+01,
lng: 1.3428277778e+02,
cert : false,
content:' Peak = 1053.099976 pos = 35.1981,134.2828 diff = 426.699951'
});
data_saddle.push({
lat: 3.5199333334e+01,
lng: 1.3423755556e+02,
content:'Saddle = 626.400024 pos = 35.1993,134.2376 diff = 426.699951'
});
data_peak.push({
lat: 3.5239222223e+01,
lng: 1.3426666667e+02,
cert : true,
content:'Name = JA/TT-018(JA/TT-018) peak = 975.299988 pos = 35.2392,134.2667 diff = 347.599976'
});
data_saddle.push({
lat: 3.5215111111e+01,
lng: 1.3426077778e+02,
content:'Saddle = 627.700012 pos = 35.2151,134.2608 diff = 347.599976'
});
data_peak.push({
lat: 3.5167888889e+01,
lng: 1.3426166667e+02,
cert : false,
content:' Peak = 931.200012 pos = 35.1679,134.2617 diff = 179.700012'
});
data_saddle.push({
lat: 3.5172888889e+01,
lng: 1.3426411111e+02,
content:'Saddle = 751.500000 pos = 35.1729,134.2641 diff = 179.700012'
});
data_peak.push({
lat: 3.5357000000e+01,
lng: 1.3401944444e+02,
cert : true,
content:'Name = Mikunigasen(JA/TT-007) peak = 1250.900024 pos = 35.3570,134.0194 diff = 623.400024'
});
data_saddle.push({
lat: 3.5222555556e+01,
lng: 1.3416177778e+02,
content:'Saddle = 627.500000 pos = 35.2226,134.1618 diff = 623.400024'
});
data_peak.push({
lat: 3.5201444445e+01,
lng: 1.3399800000e+02,
cert : true,
content:'Name = JA/OY-042(JA/OY-042) peak = 852.700012 pos = 35.2014,133.9980 diff = 215.299988'
});
data_saddle.push({
lat: 3.5214888889e+01,
lng: 1.3399844444e+02,
content:'Saddle = 637.400024 pos = 35.2149,133.9984 diff = 215.299988'
});
data_peak.push({
lat: 3.5279444445e+01,
lng: 1.3418911111e+02,
cert : true,
content:'Name = JA/TT-020(JA/TT-020) peak = 903.599976 pos = 35.2794,134.1891 diff = 250.799988'
});
data_saddle.push({
lat: 3.5273777778e+01,
lng: 1.3416522222e+02,
content:'Saddle = 652.799988 pos = 35.2738,134.1652 diff = 250.799988'
});
data_peak.push({
lat: 3.5168777778e+01,
lng: 1.3379388889e+02,
cert : false,
content:' Peak = 846.099976 pos = 35.1688,133.7939 diff = 163.500000'
});
data_saddle.push({
lat: 3.5172555556e+01,
lng: 1.3378266667e+02,
content:'Saddle = 682.599976 pos = 35.1726,133.7827 diff = 163.500000'
});
data_peak.push({
lat: 3.5392000000e+01,
lng: 1.3398866667e+02,
cert : true,
content:'Name = JA/TT-017(JA/TT-017) peak = 984.299988 pos = 35.3920,133.9887 diff = 287.299988'
});
data_saddle.push({
lat: 3.5390777778e+01,
lng: 1.3400322222e+02,
content:'Saddle = 697.000000 pos = 35.3908,134.0032 diff = 287.299988'
});
data_peak.push({
lat: 3.5198111111e+01,
lng: 1.3374544444e+02,
cert : false,
content:' Peak = 887.400024 pos = 35.1981,133.7454 diff = 175.300049'
});
data_saddle.push({
lat: 3.5198222223e+01,
lng: 1.3374977778e+02,
content:'Saddle = 712.099976 pos = 35.1982,133.7498 diff = 175.300049'
});
data_peak.push({
lat: 3.5205444445e+01,
lng: 1.3382022222e+02,
cert : true,
content:'Name = JA/OY-005(JA/OY-005) peak = 1204.300049 pos = 35.2054,133.8202 diff = 461.900024'
});
data_saddle.push({
lat: 3.5313666667e+01,
lng: 1.3393100000e+02,
content:'Saddle = 742.400024 pos = 35.3137,133.9310 diff = 461.900024'
});
data_peak.push({
lat: 3.5189888889e+01,
lng: 1.3378233333e+02,
cert : true,
content:'Name = JA/OY-021(JA/OY-021) peak = 1072.500000 pos = 35.1899,133.7823 diff = 304.000000'
});
data_saddle.push({
lat: 3.5216222223e+01,
lng: 1.3379566667e+02,
content:'Saddle = 768.500000 pos = 35.2162,133.7957 diff = 304.000000'
});
data_peak.push({
lat: 3.5222555556e+01,
lng: 1.3377844444e+02,
cert : true,
content:'Name = JA/OY-025(JA/OY-025) peak = 1040.000000 pos = 35.2226,133.7784 diff = 215.799988'
});
data_saddle.push({
lat: 3.5197777778e+01,
lng: 1.3377822222e+02,
content:'Saddle = 824.200012 pos = 35.1978,133.7782 diff = 215.799988'
});
data_peak.push({
lat: 3.5255444445e+01,
lng: 1.3390711111e+02,
cert : true,
content:'Name = JA/OY-022(JA/OY-022) peak = 1053.599976 pos = 35.2554,133.9071 diff = 265.899963'
});
data_saddle.push({
lat: 3.5271444445e+01,
lng: 1.3389722222e+02,
content:'Saddle = 787.700012 pos = 35.2714,133.8972 diff = 265.899963'
});
data_peak.push({
lat: 3.5281555556e+01,
lng: 1.3383766667e+02,
cert : false,
content:' Peak = 1020.000000 pos = 35.2816,133.8377 diff = 157.299988'
});
data_saddle.push({
lat: 3.5275222223e+01,
lng: 1.3384577778e+02,
content:'Saddle = 862.700012 pos = 35.2752,133.8458 diff = 157.299988'
});
data_peak.push({
lat: 3.5263222223e+01,
lng: 1.3385244444e+02,
cert : true,
content:'Name = JA/OY-011(JA/OY-011) peak = 1123.699951 pos = 35.2632,133.8524 diff = 210.699951'
});
data_saddle.push({
lat: 3.5250000000e+01,
lng: 1.3382588889e+02,
content:'Saddle = 913.000000 pos = 35.2500,133.8259 diff = 210.699951'
});
data_peak.push({
lat: 3.5277111111e+01,
lng: 1.3386344444e+02,
cert : true,
content:'Name = JA/OY-018(JA/OY-018) peak = 1097.599976 pos = 35.2771,133.8634 diff = 159.299988'
});
data_saddle.push({
lat: 3.5268444445e+01,
lng: 1.3385855556e+02,
content:'Saddle = 938.299988 pos = 35.2684,133.8586 diff = 159.299988'
});
data_peak.push({
lat: 3.5251888889e+01,
lng: 1.3381500000e+02,
cert : true,
content:'Name = Tsugurosen(JA/OY-012) peak = 1116.500000 pos = 35.2519,133.8150 diff = 194.700012'
});
data_saddle.push({
lat: 3.5239888889e+01,
lng: 1.3381844444e+02,
content:'Saddle = 921.799988 pos = 35.2399,133.8184 diff = 194.700012'
});
data_peak.push({
lat: 3.5259555556e+01,
lng: 1.3397488889e+02,
cert : true,
content:'Name = Hanachigasen(JA/OY-002) peak = 1246.900024 pos = 35.2596,133.9749 diff = 459.500000'
});
data_saddle.push({
lat: 3.5311111111e+01,
lng: 1.3400388889e+02,
content:'Saddle = 787.400024 pos = 35.3111,134.0039 diff = 459.500000'
});
data_peak.push({
lat: 3.5283555556e+01,
lng: 1.3411688889e+02,
cert : false,
content:' Peak = 990.299988 pos = 35.2836,134.1169 diff = 167.099976'
});
data_saddle.push({
lat: 3.5292444445e+01,
lng: 1.3410933333e+02,
content:'Saddle = 823.200012 pos = 35.2924,134.1093 diff = 167.099976'
});
data_peak.push({
lat: 3.5240111111e+01,
lng: 1.3408433333e+02,
cert : false,
content:' Peak = 990.400024 pos = 35.2401,134.0843 diff = 152.400024'
});
data_saddle.push({
lat: 3.5248333334e+01,
lng: 1.3408700000e+02,
content:'Saddle = 838.000000 pos = 35.2483,134.0870 diff = 152.400024'
});
data_peak.push({
lat: 3.5202222223e+01,
lng: 1.3395955556e+02,
cert : true,
content:'Name = Izumigasen(JA/OY-004) peak = 1207.599976 pos = 35.2022,133.9596 diff = 349.599976'
});
data_saddle.push({
lat: 3.5217777778e+01,
lng: 1.3396644444e+02,
content:'Saddle = 858.000000 pos = 35.2178,133.9664 diff = 349.599976'
});
data_peak.push({
lat: 3.5301555556e+01,
lng: 1.3406466667e+02,
cert : true,
content:'Name = Miharayama(JA/OY-014) peak = 1114.099976 pos = 35.3016,134.0647 diff = 236.899963'
});
data_saddle.push({
lat: 3.5303444445e+01,
lng: 1.3404033333e+02,
content:'Saddle = 877.200012 pos = 35.3034,134.0403 diff = 236.899963'
});
data_peak.push({
lat: 3.5232666667e+01,
lng: 1.3395766667e+02,
cert : false,
content:' Peak = 1074.199951 pos = 35.2327,133.9577 diff = 172.899963'
});
data_saddle.push({
lat: 3.5241333334e+01,
lng: 1.3396455556e+02,
content:'Saddle = 901.299988 pos = 35.2413,133.9646 diff = 172.899963'
});
data_peak.push({
lat: 3.5267666667e+01,
lng: 1.3401777778e+02,
cert : false,
content:' Peak = 1194.800049 pos = 35.2677,134.0178 diff = 163.800049'
});
data_saddle.push({
lat: 3.5258111111e+01,
lng: 1.3400577778e+02,
content:'Saddle = 1031.000000 pos = 35.2581,134.0058 diff = 163.800049'
});
data_peak.push({
lat: 3.5360444445e+01,
lng: 1.3405111111e+02,
cert : true,
content:'Name = Takahachiyama(JA/TT-009) peak = 1202.300049 pos = 35.3604,134.0511 diff = 219.700073'
});
data_saddle.push({
lat: 3.5370444445e+01,
lng: 1.3403588889e+02,
content:'Saddle = 982.599976 pos = 35.3704,134.0359 diff = 219.700073'
});
data_peak.push({
lat: 3.5177555556e+01,
lng: 1.3422388889e+02,
cert : true,
content:'Name = JA/OY-038(JA/OY-038) peak = 908.900024 pos = 35.1776,134.2239 diff = 261.600037'
});
data_saddle.push({
lat: 3.5188888889e+01,
lng: 1.3420200000e+02,
content:'Saddle = 647.299988 pos = 35.1889,134.2020 diff = 261.600037'
});
data_peak.push({
lat: 3.5168111111e+01,
lng: 1.3409488889e+02,
cert : false,
content:' Peak = 861.299988 pos = 35.1681,134.0949 diff = 150.500000'
});
data_saddle.push({
lat: 3.5194888889e+01,
lng: 1.3413866667e+02,
content:'Saddle = 710.799988 pos = 35.1949,134.1387 diff = 150.500000'
});
data_peak.push({
lat: 3.5162000000e+01,
lng: 1.3412533333e+02,
cert : true,
content:'Name = JA/OY-013(JA/OY-013) peak = 1114.099976 pos = 35.1620,134.1253 diff = 218.799988'
});
data_saddle.push({
lat: 3.5163777778e+01,
lng: 1.3413711111e+02,
content:'Saddle = 895.299988 pos = 35.1638,134.1371 diff = 218.799988'
});
data_peak.push({
lat: 3.5417333334e+01,
lng: 1.3436022222e+02,
cert : true,
content:'Name = JA/TT-024(JA/TT-024) peak = 800.500000 pos = 35.4173,134.3602 diff = 198.799988'
});
data_saddle.push({
lat: 3.5436333334e+01,
lng: 1.3437888889e+02,
content:'Saddle = 601.700012 pos = 35.4363,134.3789 diff = 198.799988'
});
data_peak.push({
lat: 3.5157000000e+01,
lng: 1.3455922222e+02,
cert : false,
content:' Peak = 767.599976 pos = 35.1570,134.5592 diff = 165.699951'
});
data_saddle.push({
lat: 3.5166666667e+01,
lng: 1.3456066667e+02,
content:'Saddle = 601.900024 pos = 35.1667,134.5607 diff = 165.699951'
});
data_peak.push({
lat: 3.5302666667e+01,
lng: 1.3464422222e+02,
cert : true,
content:'Name = JA/HG-044(JA/HG-044) peak = 803.099976 pos = 35.3027,134.6442 diff = 193.699951'
});
data_saddle.push({
lat: 3.5292000000e+01,
lng: 1.3463411111e+02,
content:'Saddle = 609.400024 pos = 35.2920,134.6341 diff = 193.699951'
});
data_peak.push({
lat: 3.5074111111e+01,
lng: 1.3452388889e+02,
cert : true,
content:'Name = JA/HG-035(JA/HG-035) peak = 881.799988 pos = 35.0741,134.5239 diff = 260.599976'
});
data_saddle.push({
lat: 3.5080000000e+01,
lng: 1.3453222222e+02,
content:'Saddle = 621.200012 pos = 35.0800,134.5322 diff = 260.599976'
});
data_peak.push({
lat: 3.5347111111e+01,
lng: 1.3463466667e+02,
cert : false,
content:' Peak = 793.099976 pos = 35.3471,134.6347 diff = 166.299988'
});
data_saddle.push({
lat: 3.5346333334e+01,
lng: 1.3462333333e+02,
content:'Saddle = 626.799988 pos = 35.3463,134.6233 diff = 166.299988'
});
data_peak.push({
lat: 3.5151666667e+01,
lng: 1.3438200000e+02,
cert : true,
content:'Name = JA/HG-040(JA/HG-040) peak = 820.599976 pos = 35.1517,134.3820 diff = 193.500000'
});
data_saddle.push({
lat: 3.5152555556e+01,
lng: 1.3439488889e+02,
content:'Saddle = 627.099976 pos = 35.1526,134.3949 diff = 193.500000'
});
data_peak.push({
lat: 3.5105666667e+01,
lng: 1.3453955556e+02,
cert : true,
content:'Name = JA/HG-020(JA/HG-020) peak = 1023.200012 pos = 35.1057,134.5396 diff = 395.500000'
});
data_saddle.push({
lat: 3.5146888889e+01,
lng: 1.3450311111e+02,
content:'Saddle = 627.700012 pos = 35.1469,134.5031 diff = 395.500000'
});
data_peak.push({
lat: 3.5120444445e+01,
lng: 1.3450033333e+02,
cert : false,
content:' Peak = 881.000000 pos = 35.1204,134.5003 diff = 154.099976'
});
data_saddle.push({
lat: 3.5132000000e+01,
lng: 1.3451644444e+02,
content:'Saddle = 726.900024 pos = 35.1320,134.5164 diff = 154.099976'
});
data_peak.push({
lat: 3.5124222223e+01,
lng: 1.3452866667e+02,
cert : true,
content:'Name = JA/HG-031(JA/HG-031) peak = 920.500000 pos = 35.1242,134.5287 diff = 168.599976'
});
data_saddle.push({
lat: 3.5119111111e+01,
lng: 1.3454100000e+02,
content:'Saddle = 751.900024 pos = 35.1191,134.5410 diff = 168.599976'
});
data_peak.push({
lat: 3.5278777778e+01,
lng: 1.3426111111e+02,
cert : true,
content:'Name = JA/TT-025(JA/TT-025) peak = 794.000000 pos = 35.2788,134.2611 diff = 157.599976'
});
data_saddle.push({
lat: 3.5282777778e+01,
lng: 1.3426333333e+02,
content:'Saddle = 636.400024 pos = 35.2828,134.2633 diff = 157.599976'
});
data_peak.push({
lat: 3.5398333334e+01,
lng: 1.3437555556e+02,
cert : false,
content:' Peak = 816.900024 pos = 35.3983,134.3756 diff = 170.200012'
});
data_saddle.push({
lat: 3.5400111111e+01,
lng: 1.3439022222e+02,
content:'Saddle = 646.700012 pos = 35.4001,134.3902 diff = 170.200012'
});
data_peak.push({
lat: 3.5147888889e+01,
lng: 1.3440855556e+02,
cert : true,
content:'Name = JA/HG-019(JA/HG-019) peak = 1046.099976 pos = 35.1479,134.4086 diff = 371.500000'
});
data_saddle.push({
lat: 3.5159111111e+01,
lng: 1.3441255556e+02,
content:'Saddle = 674.599976 pos = 35.1591,134.4126 diff = 371.500000'
});
data_peak.push({
lat: 3.5294111111e+01,
lng: 1.3461044444e+02,
cert : false,
content:' Peak = 846.099976 pos = 35.2941,134.6104 diff = 161.000000'
});
data_saddle.push({
lat: 3.5289777778e+01,
lng: 1.3461111111e+02,
content:'Saddle = 685.099976 pos = 35.2898,134.6111 diff = 161.000000'
});
data_peak.push({
lat: 3.5266777778e+01,
lng: 1.3460044444e+02,
cert : true,
content:'Name = Fujinashiyama(JA/HG-010) peak = 1138.400024 pos = 35.2668,134.6004 diff = 409.500000'
});
data_saddle.push({
lat: 3.5287555556e+01,
lng: 1.3457988889e+02,
content:'Saddle = 728.900024 pos = 35.2876,134.5799 diff = 409.500000'
});
data_peak.push({
lat: 3.5170444445e+01,
lng: 1.3458433333e+02,
cert : true,
content:'Name = JA/HG-021(JA/HG-021) peak = 1015.000000 pos = 35.1704,134.5843 diff = 267.000000'
});
data_saddle.push({
lat: 3.5191777778e+01,
lng: 1.3457788889e+02,
content:'Saddle = 748.000000 pos = 35.1918,134.5779 diff = 267.000000'
});
data_peak.push({
lat: 3.5207000000e+01,
lng: 1.3458088889e+02,
cert : true,
content:'Name = JA/HG-017(JA/HG-017) peak = 1061.300049 pos = 35.2070,134.5809 diff = 201.000061'
});
data_saddle.push({
lat: 3.5210000000e+01,
lng: 1.3457222222e+02,
content:'Saddle = 860.299988 pos = 35.2100,134.5722 diff = 201.000061'
});
data_peak.push({
lat: 3.5221222223e+01,
lng: 1.3456044444e+02,
cert : true,
content:'Name = JA/HG-014(JA/HG-014) peak = 1086.300049 pos = 35.2212,134.5604 diff = 224.300049'
});
data_saddle.push({
lat: 3.5230666667e+01,
lng: 1.3457000000e+02,
content:'Saddle = 862.000000 pos = 35.2307,134.5700 diff = 224.300049'
});
data_peak.push({
lat: 3.5247111111e+01,
lng: 1.3457200000e+02,
cert : true,
content:'Name = JA/HG-012(JA/HG-012) peak = 1123.800049 pos = 35.2471,134.5720 diff = 225.400024'
});
data_saddle.push({
lat: 3.5269333334e+01,
lng: 1.3458311111e+02,
content:'Saddle = 898.400024 pos = 35.2693,134.5831 diff = 225.400024'
});
data_peak.push({
lat: 3.5179222223e+01,
lng: 1.3448700000e+02,
cert : false,
content:' Peak = 1191.400024 pos = 35.1792,134.4870 diff = 313.600037'
});
data_saddle.push({
lat: 3.5202111111e+01,
lng: 1.3447588889e+02,
content:'Saddle = 877.799988 pos = 35.2021,134.4759 diff = 313.600037'
});
data_peak.push({
lat: 3.5418888889e+01,
lng: 1.3455611111e+02,
cert : false,
content:' Peak = 1038.000000 pos = 35.4189,134.5561 diff = 155.299988'
});
data_saddle.push({
lat: 3.5410333334e+01,
lng: 1.3454311111e+02,
content:'Saddle = 882.700012 pos = 35.4103,134.5431 diff = 155.299988'
});
data_peak.push({
lat: 3.5292333334e+01,
lng: 1.3438300000e+02,
cert : true,
content:'Name = Tousen(JA/TT-002) peak = 1383.699951 pos = 35.2923,134.3830 diff = 485.999939'
});
data_saddle.push({
lat: 3.5295555556e+01,
lng: 1.3450966667e+02,
content:'Saddle = 897.700012 pos = 35.2956,134.5097 diff = 485.999939'
});
data_peak.push({
lat: 3.5186888889e+01,
lng: 1.3441122222e+02,
cert : true,
content:'Name = Ushiroyama(JA/HG-003) peak = 1343.500000 pos = 35.1869,134.4112 diff = 351.099976'
});
data_saddle.push({
lat: 3.5223666667e+01,
lng: 1.3438622222e+02,
content:'Saddle = 992.400024 pos = 35.2237,134.3862 diff = 351.099976'
});
data_peak.push({
lat: 3.5259777778e+01,
lng: 1.3443544444e+02,
cert : false,
content:' Peak = 1281.199951 pos = 35.2598,134.4354 diff = 278.999939'
});
data_saddle.push({
lat: 3.5244000000e+01,
lng: 1.3442900000e+02,
content:'Saddle = 1002.200012 pos = 35.2440,134.4290 diff = 278.999939'
});
data_peak.push({
lat: 3.5236666667e+01,
lng: 1.3446277778e+02,
cert : true,
content:'Name = Mimuroyama(JA/HG-002) peak = 1351.599976 pos = 35.2367,134.4628 diff = 329.799988'
});
data_saddle.push({
lat: 3.5229777778e+01,
lng: 1.3443377778e+02,
content:'Saddle = 1021.799988 pos = 35.2298,134.4338 diff = 329.799988'
});
data_peak.push({
lat: 3.5280111111e+01,
lng: 1.3451333333e+02,
cert : true,
content:'Name = JA/HG-007(JA/HG-007) peak = 1210.800049 pos = 35.2801,134.5133 diff = 164.900024'
});
data_saddle.push({
lat: 3.5256000000e+01,
lng: 1.3448233333e+02,
content:'Saddle = 1045.900024 pos = 35.2560,134.4823 diff = 164.900024'
});
data_peak.push({
lat: 3.5237333334e+01,
lng: 1.3442033333e+02,
cert : true,
content:'Name = JA/HG-004(JA/HG-004) peak = 1240.900024 pos = 35.2373,134.4203 diff = 199.599976'
});
data_saddle.push({
lat: 3.5250333334e+01,
lng: 1.3439566667e+02,
content:'Saddle = 1041.300049 pos = 35.2503,134.3957 diff = 199.599976'
});
data_peak.push({
lat: 3.5248000000e+01,
lng: 1.3435688889e+02,
cert : true,
content:'Name = Okinoyama(JA/TT-004) peak = 1313.199951 pos = 35.2480,134.3569 diff = 241.000000'
});
data_saddle.push({
lat: 3.5256000000e+01,
lng: 1.3438677778e+02,
content:'Saddle = 1072.199951 pos = 35.2560,134.3868 diff = 241.000000'
});
data_peak.push({
lat: 3.5439888889e+01,
lng: 1.3444077778e+02,
cert : true,
content:'Name = Ouginosen(JA/TT-005) peak = 1308.400024 pos = 35.4399,134.4408 diff = 360.800049'
});
data_saddle.push({
lat: 3.5368000000e+01,
lng: 1.3449277778e+02,
content:'Saddle = 947.599976 pos = 35.3680,134.4928 diff = 360.800049'
});
data_peak.push({
lat: 3.5375444445e+01,
lng: 1.3445766667e+02,
cert : true,
content:'Name = JA/TT-008(JA/TT-008) peak = 1204.599976 pos = 35.3754,134.4577 diff = 242.399963'
});
data_saddle.push({
lat: 3.5392777778e+01,
lng: 1.3447544444e+02,
content:'Saddle = 962.200012 pos = 35.3928,134.4754 diff = 242.399963'
});
data_peak.push({
lat: 3.5422555556e+01,
lng: 1.3447677778e+02,
cert : false,
content:' Peak = 1234.699951 pos = 35.4226,134.4768 diff = 223.499939'
});
data_saddle.push({
lat: 3.5436666667e+01,
lng: 1.3445988889e+02,
content:'Saddle = 1011.200012 pos = 35.4367,134.4599 diff = 223.499939'
});
data_peak.push({
lat: 3.5395444445e+01,
lng: 1.3453644444e+02,
cert : true,
content:'Name = Hachibuseyama(JA/HG-006) peak = 1220.199951 pos = 35.3954,134.5364 diff = 203.199951'
});
data_saddle.push({
lat: 3.5384000000e+01,
lng: 1.3451577778e+02,
content:'Saddle = 1017.000000 pos = 35.3840,134.5158 diff = 203.199951'
});
data_peak.push({
lat: 3.4928111112e+01,
lng: 1.3285711111e+02,
cert : true,
content:'Name = JA/HS-093(JA/HS-093) peak = 732.500000 pos = 34.9281,132.8571 diff = 223.200012'
});
data_saddle.push({
lat: 3.4942888889e+01,
lng: 1.3285111111e+02,
content:'Saddle = 509.299988 pos = 34.9429,132.8511 diff = 223.200012'
});
data_peak.push({
lat: 3.5052000000e+01,
lng: 1.3306544444e+02,
cert : true,
content:'Name = Hibayama (Tateeboshiyama)(JA/HS-004) peak = 1298.300049 pos = 35.0520,133.0654 diff = 781.900024'
});
data_saddle.push({
lat: 3.5105777778e+01,
lng: 1.3336066667e+02,
content:'Saddle = 516.400024 pos = 35.1058,133.3607 diff = 781.900024'
});
data_peak.push({
lat: 3.5084222223e+01,
lng: 1.3335344444e+02,
cert : true,
content:'Name = JA/OY-058(JA/OY-058) peak = 710.799988 pos = 35.0842,133.3534 diff = 194.200012'
});
data_saddle.push({
lat: 3.5089444445e+01,
lng: 1.3334800000e+02,
content:'Saddle = 516.599976 pos = 35.0894,133.3480 diff = 194.200012'
});
data_peak.push({
lat: 3.5264000000e+01,
lng: 1.3320611111e+02,
cert : true,
content:'Name = JA/SN-039(JA/SN-039) peak = 743.299988 pos = 35.2640,133.2061 diff = 225.099976'
});
data_saddle.push({
lat: 3.5250444445e+01,
lng: 1.3320800000e+02,
content:'Saddle = 518.200012 pos = 35.2504,133.2080 diff = 225.099976'
});
data_peak.push({
lat: 3.4797111112e+01,
lng: 1.3318722222e+02,
cert : true,
content:'Name = JA/HS-111(JA/HS-111) peak = 691.700012 pos = 34.7971,133.1872 diff = 172.500000'
});
data_saddle.push({
lat: 3.4785888889e+01,
lng: 1.3316722222e+02,
content:'Saddle = 519.200012 pos = 34.7859,133.1672 diff = 172.500000'
});
data_peak.push({
lat: 3.5136444445e+01,
lng: 1.3306822222e+02,
cert : true,
content:'Name = JA/SN-045(JA/SN-045) peak = 716.299988 pos = 35.1364,133.0682 diff = 189.200012'
});
data_saddle.push({
lat: 3.5130333334e+01,
lng: 1.3307377778e+02,
content:'Saddle = 527.099976 pos = 35.1303,133.0738 diff = 189.200012'
});
data_peak.push({
lat: 3.5137111111e+01,
lng: 1.3275788889e+02,
cert : true,
content:'Name = JA/SN-042(JA/SN-042) peak = 720.700012 pos = 35.1371,132.7579 diff = 192.600037'
});
data_saddle.push({
lat: 3.5123444445e+01,
lng: 1.3276600000e+02,
content:'Saddle = 528.099976 pos = 35.1234,132.7660 diff = 192.600037'
});
data_peak.push({
lat: 3.5106111111e+01,
lng: 1.3334022222e+02,
cert : true,
content:'Name = JA/OY-049(JA/OY-049) peak = 774.299988 pos = 35.1061,133.3402 diff = 239.399963'
});
data_saddle.push({
lat: 3.5100222223e+01,
lng: 1.3333211111e+02,
content:'Saddle = 534.900024 pos = 35.1002,133.3321 diff = 239.399963'
});
data_peak.push({
lat: 3.4940777778e+01,
lng: 1.3289055556e+02,
cert : true,
content:'Name = JA/HS-080(JA/HS-080) peak = 773.000000 pos = 34.9408,132.8906 diff = 220.500000'
});
data_saddle.push({
lat: 3.4952111112e+01,
lng: 1.3288866667e+02,
content:'Saddle = 552.500000 pos = 34.9521,132.8887 diff = 220.500000'
});
data_peak.push({
lat: 3.4849444445e+01,
lng: 1.3315077778e+02,
cert : true,
content:'Name = JA/HS-051(JA/HS-051) peak = 881.799988 pos = 34.8494,133.1508 diff = 329.099976'
});
data_saddle.push({
lat: 3.4891888889e+01,
lng: 1.3314422222e+02,
content:'Saddle = 552.700012 pos = 34.8919,133.1442 diff = 329.099976'
});
data_peak.push({
lat: 3.4903555556e+01,
lng: 1.3311155556e+02,
cert : false,
content:' Peak = 731.000000 pos = 34.9036,133.1116 diff = 173.799988'
});
data_saddle.push({
lat: 3.4893333334e+01,
lng: 1.3311522222e+02,
content:'Saddle = 557.200012 pos = 34.8933,133.1152 diff = 173.799988'
});
data_peak.push({
lat: 3.4866444445e+01,
lng: 1.3309355556e+02,
cert : true,
content:'Name = JA/HS-071(JA/HS-071) peak = 801.200012 pos = 34.8664,133.0936 diff = 192.900024'
});
data_saddle.push({
lat: 3.4879222223e+01,
lng: 1.3312744444e+02,
content:'Saddle = 608.299988 pos = 34.8792,133.1274 diff = 192.900024'
});
data_peak.push({
lat: 3.5088222223e+01,
lng: 1.3332611111e+02,
cert : false,
content:' Peak = 732.200012 pos = 35.0882,133.3261 diff = 174.400024'
});
data_saddle.push({
lat: 3.5094222223e+01,
lng: 1.3331866667e+02,
content:'Saddle = 557.799988 pos = 35.0942,133.3187 diff = 174.400024'
});
data_peak.push({
lat: 3.5104000000e+01,
lng: 1.3329877778e+02,
cert : false,
content:' Peak = 723.200012 pos = 35.1040,133.2988 diff = 156.299988'
});
data_saddle.push({
lat: 3.5098333334e+01,
lng: 1.3329133333e+02,
content:'Saddle = 566.900024 pos = 35.0983,133.2913 diff = 156.299988'
});
data_peak.push({
lat: 3.5209444445e+01,
lng: 1.3313044444e+02,
cert : true,
content:'Name = JA/SN-027(JA/SN-027) peak = 834.500000 pos = 35.2094,133.1304 diff = 267.599976'
});
data_saddle.push({
lat: 3.5211777778e+01,
lng: 1.3314677778e+02,
content:'Saddle = 566.900024 pos = 35.2118,133.1468 diff = 267.599976'
});
data_peak.push({
lat: 3.5124333334e+01,
lng: 1.3278733333e+02,
cert : true,
content:'Name = JA/SN-035(JA/SN-035) peak = 781.799988 pos = 35.1243,132.7873 diff = 204.899963'
});
data_saddle.push({
lat: 3.5119000000e+01,
lng: 1.3278544444e+02,
content:'Saddle = 576.900024 pos = 35.1190,132.7854 diff = 204.899963'
});
data_peak.push({
lat: 3.4956777778e+01,
lng: 1.3297300000e+02,
cert : true,
content:'Name = JA/HS-079(JA/HS-079) peak = 772.200012 pos = 34.9568,132.9730 diff = 194.400024'
});
data_saddle.push({
lat: 3.4980333334e+01,
lng: 1.3295788889e+02,
content:'Saddle = 577.799988 pos = 34.9803,132.9579 diff = 194.400024'
});
data_peak.push({
lat: 3.4921222223e+01,
lng: 1.3319822222e+02,
cert : true,
content:'Name = JA/HS-066(JA/HS-066) peak = 812.400024 pos = 34.9212,133.1982 diff = 234.200012'
});
data_saddle.push({
lat: 3.4946666667e+01,
lng: 1.3319700000e+02,
content:'Saddle = 578.200012 pos = 34.9467,133.1970 diff = 234.200012'
});
data_peak.push({
lat: 3.4919888889e+01,
lng: 1.3321811111e+02,
cert : true,
content:'Name = JA/HS-081(JA/HS-081) peak = 773.799988 pos = 34.9199,133.2181 diff = 185.700012'
});
data_saddle.push({
lat: 3.4920000000e+01,
lng: 1.3321133333e+02,
content:'Saddle = 588.099976 pos = 34.9200,133.2113 diff = 185.700012'
});
data_peak.push({
lat: 3.4948111112e+01,
lng: 1.3272044444e+02,
cert : true,
content:'Name = JA/HS-062(JA/HS-062) peak = 830.099976 pos = 34.9481,132.7204 diff = 233.599976'
});
data_saddle.push({
lat: 3.4958111112e+01,
lng: 1.3273533333e+02,
content:'Saddle = 596.500000 pos = 34.9581,132.7353 diff = 233.599976'
});
data_peak.push({
lat: 3.4937666667e+01,
lng: 1.3293811111e+02,
cert : false,
content:' Peak = 783.500000 pos = 34.9377,132.9381 diff = 186.599976'
});
data_saddle.push({
lat: 3.4960555556e+01,
lng: 1.3292477778e+02,
content:'Saddle = 596.900024 pos = 34.9606,132.9248 diff = 186.599976'
});
data_peak.push({
lat: 3.5227444445e+01,
lng: 1.3317233333e+02,
cert : true,
content:'Name = JA/TT-022(JA/TT-022) peak = 843.599976 pos = 35.2274,133.1723 diff = 246.599976'
});
data_saddle.push({
lat: 3.5202666667e+01,
lng: 1.3317955556e+02,
content:'Saddle = 597.000000 pos = 35.2027,133.1796 diff = 246.599976'
});
data_peak.push({
lat: 3.5110111111e+01,
lng: 1.3277666667e+02,
cert : false,
content:' Peak = 784.700012 pos = 35.1101,132.7767 diff = 186.900024'
});
data_saddle.push({
lat: 3.5105666667e+01,
lng: 1.3279800000e+02,
content:'Saddle = 597.799988 pos = 35.1057,132.7980 diff = 186.900024'
});
data_peak.push({
lat: 3.5132666667e+01,
lng: 1.3280944444e+02,
cert : true,
content:'Name = JA/SN-026(JA/SN-026) peak = 842.599976 pos = 35.1327,132.8094 diff = 244.199951'
});
data_saddle.push({
lat: 3.5116111111e+01,
lng: 1.3281000000e+02,
content:'Saddle = 598.400024 pos = 35.1161,132.8100 diff = 244.199951'
});
data_peak.push({
lat: 3.5009555556e+01,
lng: 1.3316788889e+02,
cert : true,
content:'Name = JA/HS-070(JA/HS-070) peak = 812.400024 pos = 35.0096,133.1679 diff = 195.400024'
});
data_saddle.push({
lat: 3.5012666667e+01,
lng: 1.3317711111e+02,
content:'Saddle = 617.000000 pos = 35.0127,133.1771 diff = 195.400024'
});
data_peak.push({
lat: 3.5070333334e+01,
lng: 1.3334422222e+02,
cert : true,
content:'Name = JA/OY-045(JA/OY-045) peak = 812.400024 pos = 35.0703,133.3442 diff = 195.200012'
});
data_saddle.push({
lat: 3.5067444445e+01,
lng: 1.3333000000e+02,
content:'Saddle = 617.200012 pos = 35.0674,133.3300 diff = 195.200012'
});
data_peak.push({
lat: 3.4983444445e+01,
lng: 1.3318777778e+02,
cert : true,
content:'Name = JA/HS-019(JA/HS-019) peak = 1072.500000 pos = 34.9834,133.1878 diff = 451.400024'
});
data_saddle.push({
lat: 3.5007555556e+01,
lng: 1.3318844444e+02,
content:'Saddle = 621.099976 pos = 35.0076,133.1884 diff = 451.400024'
});
data_peak.push({
lat: 3.4944333334e+01,
lng: 1.3315666667e+02,
cert : false,
content:' Peak = 917.200012 pos = 34.9443,133.1567 diff = 170.500000'
});
data_saddle.push({
lat: 3.4970555556e+01,
lng: 1.3317233333e+02,
content:'Saddle = 746.700012 pos = 34.9706,133.1723 diff = 170.500000'
});
data_peak.push({
lat: 3.4982111112e+01,
lng: 1.3292288889e+02,
cert : true,
content:'Name = JA/HS-029(JA/HS-029) peak = 1015.400024 pos = 34.9821,132.9229 diff = 387.800049'
});
data_saddle.push({
lat: 3.5036333334e+01,
lng: 1.3298188889e+02,
content:'Saddle = 627.599976 pos = 35.0363,132.9819 diff = 387.800049'
});
data_peak.push({
lat: 3.5004222223e+01,
lng: 1.3283811111e+02,
cert : false,
content:' Peak = 939.200012 pos = 35.0042,132.8381 diff = 300.700012'
});
data_saddle.push({
lat: 3.4992111112e+01,
lng: 1.3287011111e+02,
content:'Saddle = 638.500000 pos = 34.9921,132.8701 diff = 300.700012'
});
data_peak.push({
lat: 3.4961333334e+01,
lng: 1.3288211111e+02,
cert : false,
content:' Peak = 843.200012 pos = 34.9613,132.8821 diff = 171.799988'
});
data_saddle.push({
lat: 3.4968222223e+01,
lng: 1.3288444444e+02,
content:'Saddle = 671.400024 pos = 34.9682,132.8844 diff = 171.799988'
});
data_peak.push({
lat: 3.4961333334e+01,
lng: 1.3290522222e+02,
cert : false,
content:' Peak = 842.700012 pos = 34.9613,132.9052 diff = 154.000000'
});
data_saddle.push({
lat: 3.4964444445e+01,
lng: 1.3290422222e+02,
content:'Saddle = 688.700012 pos = 34.9644,132.9042 diff = 154.000000'
});
data_peak.push({
lat: 3.5001555556e+01,
lng: 1.3288111111e+02,
cert : false,
content:' Peak = 863.200012 pos = 35.0016,132.8811 diff = 152.400024'
});
data_saddle.push({
lat: 3.4996555556e+01,
lng: 1.3288788889e+02,
content:'Saddle = 710.799988 pos = 34.9966,132.8879 diff = 152.400024'
});
data_peak.push({
lat: 3.5008666667e+01,
lng: 1.3293455556e+02,
cert : false,
content:' Peak = 1002.299988 pos = 35.0087,132.9346 diff = 153.799988'
});
data_saddle.push({
lat: 3.4991111112e+01,
lng: 1.3292522222e+02,
content:'Saddle = 848.500000 pos = 34.9911,132.9252 diff = 153.799988'
});
data_peak.push({
lat: 3.5104777778e+01,
lng: 1.3281355556e+02,
cert : true,
content:'Name = JA/SN-018(JA/SN-018) peak = 955.400024 pos = 35.1048,132.8136 diff = 323.600037'
});
data_saddle.push({
lat: 3.5103555556e+01,
lng: 1.3282622222e+02,
content:'Saddle = 631.799988 pos = 35.1036,132.8262 diff = 323.600037'
});
data_peak.push({
lat: 3.4973444445e+01,
lng: 1.3326522222e+02,
cert : true,
content:'Name = JA/HS-026(JA/HS-026) peak = 1041.300049 pos = 34.9734,133.2652 diff = 409.500061'
});
data_saddle.push({
lat: 3.5001555556e+01,
lng: 1.3326888889e+02,
content:'Saddle = 631.799988 pos = 35.0016,133.2689 diff = 409.500061'
});
data_peak.push({
lat: 3.5130555556e+01,
lng: 1.3319933333e+02,
cert : true,
content:'Name = JA/TT-023(JA/TT-023) peak = 825.599976 pos = 35.1306,133.1993 diff = 188.199951'
});
data_saddle.push({
lat: 3.5135777778e+01,
lng: 1.3319844444e+02,
content:'Saddle = 637.400024 pos = 35.1358,133.1984 diff = 188.199951'
});
data_peak.push({
lat: 3.5087555556e+01,
lng: 1.3285444444e+02,
cert : true,
content:'Name = Ooyorogiyama(JA/HS-010) peak = 1217.699951 pos = 35.0876,132.8544 diff = 579.099976'
});
data_saddle.push({
lat: 3.5087666667e+01,
lng: 1.3290744444e+02,
content:'Saddle = 638.599976 pos = 35.0877,132.9074 diff = 579.099976'
});
data_peak.push({
lat: 3.4912555556e+01,
lng: 1.3279788889e+02,
cert : true,
content:'Name = JA/HS-057(JA/HS-057) peak = 840.700012 pos = 34.9126,132.7979 diff = 201.400024'
});
data_saddle.push({
lat: 3.4957000000e+01,
lng: 1.3278722222e+02,
content:'Saddle = 639.299988 pos = 34.9570,132.7872 diff = 201.400024'
});
data_peak.push({
lat: 3.4939555556e+01,
lng: 1.3279344444e+02,
cert : true,
content:'Name = JA/HS-065(JA/HS-065) peak = 818.099976 pos = 34.9396,132.7934 diff = 157.500000'
});
data_saddle.push({
lat: 3.4918000000e+01,
lng: 1.3279888889e+02,
content:'Saddle = 660.599976 pos = 34.9180,132.7989 diff = 157.500000'
});
data_peak.push({
lat: 3.4993111112e+01,
lng: 1.3276322222e+02,
cert : false,
content:' Peak = 853.900024 pos = 34.9931,132.7632 diff = 187.200012'
});
data_saddle.push({
lat: 3.5002555556e+01,
lng: 1.3278111111e+02,
content:'Saddle = 666.700012 pos = 35.0026,132.7811 diff = 187.200012'
});
data_peak.push({
lat: 3.5022444445e+01,
lng: 1.3280044444e+02,
cert : true,
content:'Name = JA/HS-048(JA/HS-048) peak = 903.799988 pos = 35.0224,132.8004 diff = 211.599976'
});
data_saddle.push({
lat: 3.5031666667e+01,
lng: 1.3281077778e+02,
content:'Saddle = 692.200012 pos = 35.0317,132.8108 diff = 211.599976'
});
data_peak.push({
lat: 3.5048222223e+01,
lng: 1.3278244444e+02,
cert : true,
content:'Name = Kotobikisan (Misen)(JA/SN-013) peak = 1012.700012 pos = 35.0482,132.7824 diff = 181.000000'
});
data_saddle.push({
lat: 3.5056000000e+01,
lng: 1.3281055556e+02,
content:'Saddle = 831.700012 pos = 35.0560,132.8106 diff = 181.000000'
});
data_peak.push({
lat: 3.5047000000e+01,
lng: 1.3283544444e+02,
cert : true,
content:'Name = JA/HS-025(JA/HS-025) peak = 1042.099976 pos = 35.0470,132.8354 diff = 209.399963'
});
data_saddle.push({
lat: 3.5057111111e+01,
lng: 1.3283133333e+02,
content:'Saddle = 832.700012 pos = 35.0571,132.8313 diff = 209.399963'
});
data_peak.push({
lat: 3.5150111111e+01,
lng: 1.3323333333e+02,
cert : false,
content:' Peak = 810.599976 pos = 35.1501,133.2333 diff = 153.099976'
});
data_saddle.push({
lat: 3.5158888889e+01,
lng: 1.3322277778e+02,
content:'Saddle = 657.500000 pos = 35.1589,133.2228 diff = 153.099976'
});
data_peak.push({
lat: 3.4949777778e+01,
lng: 1.3302300000e+02,
cert : true,
content:'Name = JA/HS-040(JA/HS-040) peak = 942.099976 pos = 34.9498,133.0230 diff = 275.299988'
});
data_saddle.push({
lat: 3.4968555556e+01,
lng: 1.3304411111e+02,
content:'Saddle = 666.799988 pos = 34.9686,133.0441 diff = 275.299988'
});
data_peak.push({
lat: 3.4960888889e+01,
lng: 1.3303911111e+02,
cert : false,
content:' Peak = 903.299988 pos = 34.9609,133.0391 diff = 151.000000'
});
data_saddle.push({
lat: 3.4956666667e+01,
lng: 1.3303255556e+02,
content:'Saddle = 752.299988 pos = 34.9567,133.0326 diff = 151.000000'
});
data_peak.push({
lat: 3.5132111111e+01,
lng: 1.3328055556e+02,
cert : true,
content:'Name = JA/TT-014(JA/TT-014) peak = 1030.599976 pos = 35.1321,133.2806 diff = 358.699951'
});
data_saddle.push({
lat: 3.5117444445e+01,
lng: 1.3325588889e+02,
content:'Saddle = 671.900024 pos = 35.1174,133.2559 diff = 358.699951'
});
data_peak.push({
lat: 3.5156000000e+01,
lng: 1.3317855556e+02,
cert : true,
content:'Name = Sentsuuzan(JA/TT-011) peak = 1141.900024 pos = 35.1560,133.1786 diff = 444.900024'
});
data_saddle.push({
lat: 3.5140333334e+01,
lng: 1.3314944444e+02,
content:'Saddle = 697.000000 pos = 35.1403,133.1494 diff = 444.900024'
});
data_peak.push({
lat: 3.4960222223e+01,
lng: 1.3305966667e+02,
cert : true,
content:'Name = JA/HS-041(JA/HS-041) peak = 945.500000 pos = 34.9602,133.0597 diff = 247.200012'
});
data_saddle.push({
lat: 3.4969333334e+01,
lng: 1.3305477778e+02,
content:'Saddle = 698.299988 pos = 34.9693,133.0548 diff = 247.200012'
});
data_peak.push({
lat: 3.5098444445e+01,
lng: 1.3304144444e+02,
cert : false,
content:' Peak = 940.400024 pos = 35.0984,133.0414 diff = 239.100037'
});
data_saddle.push({
lat: 3.5094444445e+01,
lng: 1.3303622222e+02,
content:'Saddle = 701.299988 pos = 35.0944,133.0362 diff = 239.100037'
});
data_peak.push({
lat: 3.5013888889e+01,
lng: 1.3311555556e+02,
cert : false,
content:' Peak = 873.200012 pos = 35.0139,133.1156 diff = 167.100037'
});
data_saddle.push({
lat: 3.5019888889e+01,
lng: 1.3310011111e+02,
content:'Saddle = 706.099976 pos = 35.0199,133.1001 diff = 167.100037'
});
data_peak.push({
lat: 3.5029222223e+01,
lng: 1.3319600000e+02,
cert : true,
content:'Name = JA/HS-012(JA/HS-012) peak = 1194.400024 pos = 35.0292,133.1960 diff = 485.000000'
});
data_saddle.push({
lat: 3.5040555556e+01,
lng: 1.3318433333e+02,
content:'Saddle = 709.400024 pos = 35.0406,133.1843 diff = 485.000000'
});
data_peak.push({
lat: 3.5049444445e+01,
lng: 1.3333277778e+02,
cert : false,
content:' Peak = 865.500000 pos = 35.0494,133.3328 diff = 152.299988'
});
data_saddle.push({
lat: 3.5054333334e+01,
lng: 1.3332811111e+02,
content:'Saddle = 713.200012 pos = 35.0543,133.3281 diff = 152.299988'
});
data_peak.push({
lat: 3.5032222223e+01,
lng: 1.3313511111e+02,
cert : false,
content:' Peak = 878.400024 pos = 35.0322,133.1351 diff = 156.300049'
});
data_saddle.push({
lat: 3.5041777778e+01,
lng: 1.3313911111e+02,
content:'Saddle = 722.099976 pos = 35.0418,133.1391 diff = 156.300049'
});
data_peak.push({
lat: 3.5069555556e+01,
lng: 1.3323277778e+02,
cert : true,
content:'Name = Dougoyama(JA/HS-005) peak = 1270.800049 pos = 35.0696,133.2328 diff = 548.500061'
});
data_saddle.push({
lat: 3.5088777778e+01,
lng: 1.3311144444e+02,
content:'Saddle = 722.299988 pos = 35.0888,133.1114 diff = 548.500061'
});
data_peak.push({
lat: 3.5064000000e+01,
lng: 1.3332177778e+02,
cert : false,
content:' Peak = 903.799988 pos = 35.0640,133.3218 diff = 166.299988'
});
data_saddle.push({
lat: 3.5062666667e+01,
lng: 1.3330677778e+02,
content:'Saddle = 737.500000 pos = 35.0627,133.3068 diff = 166.299988'
});
data_peak.push({
lat: 3.5117333334e+01,
lng: 1.3313455556e+02,
cert : true,
content:'Name = JA/SN-007(JA/SN-007) peak = 1081.400024 pos = 35.1173,133.1346 diff = 323.600037'
});
data_saddle.push({
lat: 3.5069222223e+01,
lng: 1.3318644444e+02,
content:'Saddle = 757.799988 pos = 35.0692,133.1864 diff = 323.600037'
});
data_peak.push({
lat: 3.5073666667e+01,
lng: 1.3313644444e+02,
cert : true,
content:'Name = JA/TT-016(JA/TT-016) peak = 1003.000000 pos = 35.0737,133.1364 diff = 230.500000'
});
data_saddle.push({
lat: 3.5091111111e+01,
lng: 1.3313722222e+02,
content:'Saddle = 772.500000 pos = 35.0911,133.1372 diff = 230.500000'
});
data_peak.push({
lat: 3.5116888889e+01,
lng: 1.3316233333e+02,
cert : true,
content:'Name = JA/TT-013(JA/TT-013) peak = 1071.099976 pos = 35.1169,133.1623 diff = 193.099976'
});
data_saddle.push({
lat: 3.5120777778e+01,
lng: 1.3315277778e+02,
content:'Saddle = 878.000000 pos = 35.1208,133.1528 diff = 193.099976'
});
data_peak.push({
lat: 3.5016666667e+01,
lng: 1.3330344444e+02,
cert : false,
content:' Peak = 955.599976 pos = 35.0167,133.3034 diff = 167.599976'
});
data_saddle.push({
lat: 3.5027666667e+01,
lng: 1.3329522222e+02,
content:'Saddle = 788.000000 pos = 35.0277,133.2952 diff = 167.599976'
});
data_peak.push({
lat: 3.5002000000e+01,
lng: 1.3328800000e+02,
cert : false,
content:' Peak = 952.799988 pos = 35.0020,133.2880 diff = 156.000000'
});
data_saddle.push({
lat: 3.5006333334e+01,
lng: 1.3329255556e+02,
content:'Saddle = 796.799988 pos = 35.0063,133.2926 diff = 156.000000'
});
data_peak.push({
lat: 3.5071000000e+01,
lng: 1.3329077778e+02,
cert : false,
content:' Peak = 1062.099976 pos = 35.0710,133.2908 diff = 175.099976'
});
data_saddle.push({
lat: 3.5065888889e+01,
lng: 1.3328333333e+02,
content:'Saddle = 887.000000 pos = 35.0659,133.2833 diff = 175.099976'
});
data_peak.push({
lat: 3.5103555556e+01,
lng: 1.3322800000e+02,
cert : true,
content:'Name = JA/TT-010(JA/TT-010) peak = 1142.599976 pos = 35.1036,133.2280 diff = 255.199951'
});
data_saddle.push({
lat: 3.5092555556e+01,
lng: 1.3323977778e+02,
content:'Saddle = 887.400024 pos = 35.0926,133.2398 diff = 255.199951'
});
data_peak.push({
lat: 3.5048666667e+01,
lng: 1.3326288889e+02,
cert : false,
content:' Peak = 1157.400024 pos = 35.0487,133.2629 diff = 154.800049'
});
data_saddle.push({
lat: 3.5060777778e+01,
lng: 1.3326644444e+02,
content:'Saddle = 1002.599976 pos = 35.0608,133.2664 diff = 154.800049'
});
data_peak.push({
lat: 3.5102444445e+01,
lng: 1.3308622222e+02,
cert : true,
content:'Name = JA/SN-010(JA/SN-010) peak = 1042.199951 pos = 35.1024,133.0862 diff = 266.099976'
});
data_saddle.push({
lat: 3.5090111111e+01,
lng: 1.3309611111e+02,
content:'Saddle = 776.099976 pos = 35.0901,133.0961 diff = 266.099976'
});
data_peak.push({
lat: 3.5060444445e+01,
lng: 1.3299555556e+02,
cert : true,
content:'Name = JA/HS-028(JA/HS-028) peak = 1021.299988 pos = 35.0604,132.9956 diff = 194.599976'
});
data_saddle.push({
lat: 3.5071444445e+01,
lng: 1.3299977778e+02,
content:'Saddle = 826.700012 pos = 35.0714,132.9998 diff = 194.599976'
});
data_peak.push({
lat: 3.5081222223e+01,
lng: 1.3296833333e+02,
cert : true,
content:'Name = Sarumasayama(JA/HS-006) peak = 1264.400024 pos = 35.0812,132.9683 diff = 437.200012'
});
data_saddle.push({
lat: 3.5089888889e+01,
lng: 1.3300544444e+02,
content:'Saddle = 827.200012 pos = 35.0899,133.0054 diff = 437.200012'
});
data_peak.push({
lat: 3.5095333334e+01,
lng: 1.3298122222e+02,
cert : false,
content:' Peak = 1181.800049 pos = 35.0953,132.9812 diff = 160.100037'
});
data_saddle.push({
lat: 3.5084777778e+01,
lng: 1.3297555556e+02,
content:'Saddle = 1021.700012 pos = 35.0848,132.9756 diff = 160.100037'
});
data_peak.push({
lat: 3.4991888889e+01,
lng: 1.3308911111e+02,
cert : true,
content:'Name = JA/HS-018(JA/HS-018) peak = 1072.800049 pos = 34.9919,133.0891 diff = 200.500061'
});
data_saddle.push({
lat: 3.4996777778e+01,
lng: 1.3308244444e+02,
content:'Saddle = 872.299988 pos = 34.9968,133.0824 diff = 200.500061'
});
data_peak.push({
lat: 3.5013333334e+01,
lng: 1.3304766667e+02,
cert : true,
content:'Name = JA/HS-007(JA/HS-007) peak = 1250.699951 pos = 35.0133,133.0477 diff = 372.799927'
});
data_saddle.push({
lat: 3.5035555556e+01,
lng: 1.3305333333e+02,
content:'Saddle = 877.900024 pos = 35.0356,133.0533 diff = 372.799927'
});
data_peak.push({
lat: 3.5069000000e+01,
lng: 1.3309888889e+02,
cert : false,
content:' Peak = 1052.300049 pos = 35.0690,133.0989 diff = 172.200073'
});
data_saddle.push({
lat: 3.5071222223e+01,
lng: 1.3309388889e+02,
content:'Saddle = 880.099976 pos = 35.0712,133.0939 diff = 172.200073'
});
data_peak.push({
lat: 3.5080888889e+01,
lng: 1.3308055556e+02,
cert : true,
content:'Name = JA/HS-015(JA/HS-015) peak = 1148.500000 pos = 35.0809,133.0806 diff = 180.099976'
});
data_saddle.push({
lat: 3.5078222223e+01,
lng: 1.3305900000e+02,
content:'Saddle = 968.400024 pos = 35.0782,133.0590 diff = 180.099976'
});
data_peak.push({
lat: 3.5068333334e+01,
lng: 1.3303300000e+02,
cert : true,
content:'Name = Azumayama(JA/HS-008) peak = 1237.400024 pos = 35.0683,133.0330 diff = 224.800049'
});
data_saddle.push({
lat: 3.5068444445e+01,
lng: 1.3304577778e+02,
content:'Saddle = 1012.599976 pos = 35.0684,133.0458 diff = 224.800049'
});
data_peak.push({
lat: 3.5278555556e+01,
lng: 1.3376288889e+02,
cert : true,
content:'Name = JA/OY-047(JA/OY-047) peak = 782.599976 pos = 35.2786,133.7629 diff = 264.599976'
});
data_saddle.push({
lat: 3.5319000000e+01,
lng: 1.3372100000e+02,
content:'Saddle = 518.000000 pos = 35.3190,133.7210 diff = 264.599976'
});
data_peak.push({
lat: 3.5333777778e+01,
lng: 1.3381977778e+02,
cert : false,
content:' Peak = 704.200012 pos = 35.3338,133.8198 diff = 177.000000'
});
data_saddle.push({
lat: 3.5331333334e+01,
lng: 1.3378688889e+02,
content:'Saddle = 527.200012 pos = 35.3313,133.7869 diff = 177.000000'
});
data_peak.push({
lat: 3.5300222223e+01,
lng: 1.3375277778e+02,
cert : false,
content:' Peak = 751.700012 pos = 35.3002,133.7528 diff = 173.500000'
});
data_saddle.push({
lat: 3.5286000000e+01,
lng: 1.3376022222e+02,
content:'Saddle = 578.200012 pos = 35.2860,133.7602 diff = 173.500000'
});
data_peak.push({
lat: 3.5261555556e+01,
lng: 1.3369477778e+02,
cert : true,
content:'Name = JA/OY-051(JA/OY-051) peak = 765.299988 pos = 35.2616,133.6948 diff = 237.200012'
});
data_saddle.push({
lat: 3.5247333334e+01,
lng: 1.3368977778e+02,
content:'Saddle = 528.099976 pos = 35.2473,133.6898 diff = 237.200012'
});
data_peak.push({
lat: 3.5246888889e+01,
lng: 1.3371533333e+02,
cert : false,
content:' Peak = 733.500000 pos = 35.2469,133.7153 diff = 154.900024'
});
data_saddle.push({
lat: 3.5267666667e+01,
lng: 1.3370466667e+02,
content:'Saddle = 578.599976 pos = 35.2677,133.7047 diff = 154.900024'
});
data_peak.push({
lat: 3.5193222223e+01,
lng: 1.3369922222e+02,
cert : true,
content:'Name = JA/OY-056(JA/OY-056) peak = 723.000000 pos = 35.1932,133.6992 diff = 184.700012'
});
data_saddle.push({
lat: 3.5190333334e+01,
lng: 1.3366977778e+02,
content:'Saddle = 538.299988 pos = 35.1903,133.6698 diff = 184.700012'
});
data_peak.push({
lat: 3.5083888889e+01,
lng: 1.3338322222e+02,
cert : false,
content:' Peak = 707.099976 pos = 35.0839,133.3832 diff = 168.699951'
});
data_saddle.push({
lat: 3.5090888889e+01,
lng: 1.3338488889e+02,
content:'Saddle = 538.400024 pos = 35.0909,133.3849 diff = 168.699951'
});
data_peak.push({
lat: 3.5142111111e+01,
lng: 1.3367733333e+02,
cert : true,
content:'Name = Hoshiyama(JA/OY-028) peak = 1030.199951 pos = 35.1421,133.6773 diff = 483.099976'
});
data_saddle.push({
lat: 3.5161222223e+01,
lng: 1.3363544444e+02,
content:'Saddle = 547.099976 pos = 35.1612,133.6354 diff = 483.099976'
});
data_peak.push({
lat: 3.5132444445e+01,
lng: 1.3365577778e+02,
cert : false,
content:' Peak = 856.200012 pos = 35.1324,133.6558 diff = 154.799988'
});
data_saddle.push({
lat: 3.5137888889e+01,
lng: 1.3365633333e+02,
content:'Saddle = 701.400024 pos = 35.1379,133.6563 diff = 154.799988'
});
data_peak.push({
lat: 3.5134000000e+01,
lng: 1.3335522222e+02,
cert : true,
content:'Name = Ookurayama(JA/TT-012) peak = 1110.900024 pos = 35.1340,133.3552 diff = 548.600037'
});
data_saddle.push({
lat: 3.5142444445e+01,
lng: 1.3337511111e+02,
content:'Saddle = 562.299988 pos = 35.1424,133.3751 diff = 548.600037'
});
data_peak.push({
lat: 3.5204333334e+01,
lng: 1.3345944444e+02,
cert : true,
content:'Name = JA/TT-029(JA/TT-029) peak = 750.500000 pos = 35.2043,133.4594 diff = 178.599976'
});
data_saddle.push({
lat: 3.5195444445e+01,
lng: 1.3347588889e+02,
content:'Saddle = 571.900024 pos = 35.1954,133.4759 diff = 178.599976'
});
data_peak.push({
lat: 3.5072666667e+01,
lng: 1.3342177778e+02,
cert : true,
content:'Name = JA/OY-033(JA/OY-033) peak = 980.200012 pos = 35.0727,133.4218 diff = 406.799988'
});
data_saddle.push({
lat: 3.5088555556e+01,
lng: 1.3341155556e+02,
content:'Saddle = 573.400024 pos = 35.0886,133.4116 diff = 406.799988'
});
data_peak.push({
lat: 3.5061444445e+01,
lng: 1.3344300000e+02,
cert : false,
content:' Peak = 922.099976 pos = 35.0614,133.4430 diff = 224.000000'
});
data_saddle.push({
lat: 3.5064111111e+01,
lng: 1.3342800000e+02,
content:'Saddle = 698.099976 pos = 35.0641,133.4280 diff = 224.000000'
});
data_peak.push({
lat: 3.5066666667e+01,
lng: 1.3339888889e+02,
cert : true,
content:'Name = JA/OY-035(JA/OY-035) peak = 952.900024 pos = 35.0667,133.3989 diff = 240.400024'
});
data_saddle.push({
lat: 3.5070333334e+01,
lng: 1.3340766667e+02,
content:'Saddle = 712.500000 pos = 35.0703,133.4077 diff = 240.400024'
});
data_peak.push({
lat: 3.5064555556e+01,
lng: 1.3351288889e+02,
cert : true,
content:'Name = JA/OY-044(JA/OY-044) peak = 821.000000 pos = 35.0646,133.5129 diff = 199.700012'
});
data_saddle.push({
lat: 3.5088222223e+01,
lng: 1.3351522222e+02,
content:'Saddle = 621.299988 pos = 35.0882,133.5152 diff = 199.700012'
});
data_peak.push({
lat: 3.5228111111e+01,
lng: 1.3350544444e+02,
cert : false,
content:' Peak = 1214.599976 pos = 35.2281,133.5054 diff = 566.699951'
});
data_saddle.push({
lat: 3.5290000000e+01,
lng: 1.3357477778e+02,
content:'Saddle = 647.900024 pos = 35.2900,133.5748 diff = 566.699951'
});
data_peak.push({
lat: 3.5041777778e+01,
lng: 1.3347444444e+02,
cert : false,
content:' Peak = 802.700012 pos = 35.0418,133.4744 diff = 150.400024'
});
data_saddle.push({
lat: 3.5048333334e+01,
lng: 1.3347711111e+02,
content:'Saddle = 652.299988 pos = 35.0483,133.4771 diff = 150.400024'
});
data_peak.push({
lat: 3.5143000000e+01,
lng: 1.3352300000e+02,
cert : true,
content:'Name = JA/OY-041(JA/OY-041) peak = 853.900024 pos = 35.1430,133.5230 diff = 196.800049'
});
data_saddle.push({
lat: 3.5145888889e+01,
lng: 1.3350566667e+02,
content:'Saddle = 657.099976 pos = 35.1459,133.5057 diff = 196.800049'
});
data_peak.push({
lat: 3.5061000000e+01,
lng: 1.3348833333e+02,
cert : false,
content:' Peak = 851.700012 pos = 35.0610,133.4883 diff = 179.000000'
});
data_saddle.push({
lat: 3.5080555556e+01,
lng: 1.3348977778e+02,
content:'Saddle = 672.700012 pos = 35.0806,133.4898 diff = 179.000000'
});
data_peak.push({
lat: 3.5113888889e+01,
lng: 1.3358266667e+02,
cert : false,
content:' Peak = 853.200012 pos = 35.1139,133.5827 diff = 161.500000'
});
data_saddle.push({
lat: 3.5120000000e+01,
lng: 1.3358411111e+02,
content:'Saddle = 691.700012 pos = 35.1200,133.5841 diff = 161.500000'
});
data_peak.push({
lat: 3.5198666667e+01,
lng: 1.3364444444e+02,
cert : true,
content:'Name = JA/OY-040(JA/OY-040) peak = 860.900024 pos = 35.1987,133.6444 diff = 168.900024'
});
data_saddle.push({
lat: 3.5207000000e+01,
lng: 1.3363755556e+02,
content:'Saddle = 692.000000 pos = 35.2070,133.6376 diff = 168.900024'
});
data_peak.push({
lat: 3.5229888889e+01,
lng: 1.3347000000e+02,
cert : true,
content:'Name = Houbutsuzan(JA/TT-015) peak = 1004.000000 pos = 35.2299,133.4700 diff = 298.700012'
});
data_saddle.push({
lat: 3.5233222223e+01,
lng: 1.3348422222e+02,
content:'Saddle = 705.299988 pos = 35.2332,133.4842 diff = 298.700012'
});
data_peak.push({
lat: 3.5080555556e+01,
lng: 1.3353900000e+02,
cert : true,
content:'Name = JA/OY-032(JA/OY-032) peak = 986.500000 pos = 35.0806,133.5390 diff = 269.599976'
});
data_saddle.push({
lat: 3.5094111111e+01,
lng: 1.3351966667e+02,
content:'Saddle = 716.900024 pos = 35.0941,133.5197 diff = 269.599976'
});
data_peak.push({
lat: 3.5152444445e+01,
lng: 1.3340111111e+02,
cert : true,
content:'Name = Hanamiyama(JA/OY-007) peak = 1187.099976 pos = 35.1524,133.4011 diff = 460.500000'
});
data_saddle.push({
lat: 3.5181666667e+01,
lng: 1.3340222222e+02,
content:'Saddle = 726.599976 pos = 35.1817,133.4022 diff = 460.500000'
});
data_peak.push({
lat: 3.5121000000e+01,
lng: 1.3341277778e+02,
cert : true,
content:'Name = JA/OY-015(JA/OY-015) peak = 1110.500000 pos = 35.1210,133.4128 diff = 292.799988'
});
data_saddle.push({
lat: 3.5127777778e+01,
lng: 1.3341233333e+02,
content:'Saddle = 817.700012 pos = 35.1278,133.4123 diff = 292.799988'
});
data_peak.push({
lat: 3.5121000000e+01,
lng: 1.3349611111e+02,
cert : true,
content:'Name = JA/OY-010(JA/OY-010) peak = 1151.699951 pos = 35.1210,133.4961 diff = 414.399963'
});
data_saddle.push({
lat: 3.5187000000e+01,
lng: 1.3351811111e+02,
content:'Saddle = 737.299988 pos = 35.1870,133.5181 diff = 414.399963'
});
data_peak.push({
lat: 3.5184555556e+01,
lng: 1.3341366667e+02,
cert : true,
content:'Name = JA/OY-031(JA/OY-031) peak = 992.099976 pos = 35.1846,133.4137 diff = 235.199951'
});
data_saddle.push({
lat: 3.5176333334e+01,
lng: 1.3342677778e+02,
content:'Saddle = 756.900024 pos = 35.1763,133.4268 diff = 235.199951'
});
data_peak.push({
lat: 3.5175111111e+01,
lng: 1.3342211111e+02,
cert : false,
content:' Peak = 961.000000 pos = 35.1751,133.4221 diff = 166.299988'
});
data_saddle.push({
lat: 3.5181555556e+01,
lng: 1.3341900000e+02,
content:'Saddle = 794.700012 pos = 35.1816,133.4190 diff = 166.299988'
});
data_peak.push({
lat: 3.5170444445e+01,
lng: 1.3344755556e+02,
cert : true,
content:'Name = JA/OY-019(JA/OY-019) peak = 1081.400024 pos = 35.1704,133.4476 diff = 313.200012'
});
data_saddle.push({
lat: 3.5132333334e+01,
lng: 1.3348055556e+02,
content:'Saddle = 768.200012 pos = 35.1323,133.4806 diff = 313.200012'
});
data_peak.push({
lat: 3.5137222223e+01,
lng: 1.3346533333e+02,
cert : true,
content:'Name = JA/OY-024(JA/OY-024) peak = 1041.000000 pos = 35.1372,133.4653 diff = 263.400024'
});
data_saddle.push({
lat: 3.5143777778e+01,
lng: 1.3347877778e+02,
content:'Saddle = 777.599976 pos = 35.1438,133.4788 diff = 263.400024'
});
data_peak.push({
lat: 3.5180111111e+01,
lng: 1.3348144444e+02,
cert : true,
content:'Name = JA/OY-020(JA/OY-020) peak = 1074.800049 pos = 35.1801,133.4814 diff = 272.700073'
});
data_saddle.push({
lat: 3.5173888889e+01,
lng: 1.3345700000e+02,
content:'Saddle = 802.099976 pos = 35.1739,133.4570 diff = 272.700073'
});
data_peak.push({
lat: 3.5175222223e+01,
lng: 1.3346711111e+02,
cert : true,
content:'Name = JA/OY-026(JA/OY-026) peak = 1034.099976 pos = 35.1752,133.4671 diff = 156.500000'
});
data_saddle.push({
lat: 3.5177888889e+01,
lng: 1.3347266667e+02,
content:'Saddle = 877.599976 pos = 35.1779,133.4727 diff = 156.500000'
});
data_peak.push({
lat: 3.5093444445e+01,
lng: 1.3346377778e+02,
cert : true,
content:'Name = JA/OY-027(JA/OY-027) peak = 1033.300049 pos = 35.0934,133.4638 diff = 246.000061'
});
data_saddle.push({
lat: 3.5105555556e+01,
lng: 1.3347222222e+02,
content:'Saddle = 787.299988 pos = 35.1056,133.4722 diff = 246.000061'
});
data_peak.push({
lat: 3.5138222223e+01,
lng: 1.3359044444e+02,
cert : true,
content:'Name = JA/OY-036(JA/OY-036) peak = 926.900024 pos = 35.1382,133.5904 diff = 184.800049'
});
data_saddle.push({
lat: 3.5147333334e+01,
lng: 1.3356955556e+02,
content:'Saddle = 742.099976 pos = 35.1473,133.5696 diff = 184.800049'
});
data_peak.push({
lat: 3.5151444445e+01,
lng: 1.3353866667e+02,
cert : true,
content:'Name = JA/OY-029(JA/OY-029) peak = 1012.500000 pos = 35.1514,133.5387 diff = 258.599976'
});
data_saddle.push({
lat: 3.5196444445e+01,
lng: 1.3352322222e+02,
content:'Saddle = 753.900024 pos = 35.1964,133.5232 diff = 258.599976'
});
data_peak.push({
lat: 3.5277777778e+01,
lng: 1.3356888889e+02,
cert : true,
content:'Name = Mihirayama(JA/OY-030) peak = 1009.400024 pos = 35.2778,133.5689 diff = 231.600037'
});
data_saddle.push({
lat: 3.5270111111e+01,
lng: 1.3356988889e+02,
content:'Saddle = 777.799988 pos = 35.2701,133.5699 diff = 231.600037'
});
data_peak.push({
lat: 3.5195444445e+01,
lng: 1.3361222222e+02,
cert : true,
content:'Name = JA/OY-034(JA/OY-034) peak = 973.400024 pos = 35.1954,133.6122 diff = 191.500000'
});
data_saddle.push({
lat: 3.5202000000e+01,
lng: 1.3360666667e+02,
content:'Saddle = 781.900024 pos = 35.2020,133.6067 diff = 191.500000'
});
data_peak.push({
lat: 3.5223000000e+01,
lng: 1.3359933333e+02,
cert : true,
content:'Name = JA/OY-016(JA/OY-016) peak = 1100.900024 pos = 35.2230,133.5993 diff = 232.900024'
});
data_saddle.push({
lat: 3.5248333334e+01,
lng: 1.3357977778e+02,
content:'Saddle = 868.000000 pos = 35.2483,133.5798 diff = 232.900024'
});
data_peak.push({
lat: 3.5249333334e+01,
lng: 1.3360422222e+02,
cert : false,
content:' Peak = 1064.400024 pos = 35.2493,133.6042 diff = 151.800049'
});
data_saddle.push({
lat: 3.5238111111e+01,
lng: 1.3359344444e+02,
content:'Saddle = 912.599976 pos = 35.2381,133.5934 diff = 151.800049'
});
data_peak.push({
lat: 3.5217555556e+01,
lng: 1.3355611111e+02,
cert : false,
content:' Peak = 1062.400024 pos = 35.2176,133.5561 diff = 150.100037'
});
data_saddle.push({
lat: 3.5236000000e+01,
lng: 1.3355800000e+02,
content:'Saddle = 912.299988 pos = 35.2360,133.5580 diff = 150.100037'
});
data_peak.push({
lat: 3.5246000000e+01,
lng: 1.3355777778e+02,
cert : true,
content:'Name = Kanagayasen(JA/OY-009) peak = 1162.900024 pos = 35.2460,133.5578 diff = 242.000000'
});
data_saddle.push({
lat: 3.5239222223e+01,
lng: 1.3353877778e+02,
content:'Saddle = 920.900024 pos = 35.2392,133.5388 diff = 242.000000'
});
data_peak.push({
lat: 3.5325000000e+01,
lng: 1.3366355556e+02,
cert : true,
content:'Name = Hiruzen (Kamihiruzen)(JA/OY-006) peak = 1200.599976 pos = 35.3250,133.6636 diff = 534.299988'
});
data_saddle.push({
lat: 3.5333666667e+01,
lng: 1.3364544444e+02,
content:'Saddle = 666.299988 pos = 35.3337,133.6454 diff = 534.299988'
});
data_peak.push({
lat: 3.5325111111e+01,
lng: 1.3370044444e+02,
cert : true,
content:'Name = JA/OY-017(JA/OY-017) peak = 1103.099976 pos = 35.3251,133.7004 diff = 289.799988'
});
data_saddle.push({
lat: 3.5319333334e+01,
lng: 1.3368711111e+02,
content:'Saddle = 813.299988 pos = 35.3193,133.6871 diff = 289.799988'
});
data_peak.push({
lat: 3.5340888889e+01,
lng: 1.3361555556e+02,
cert : true,
content:'Name = JA/OY-008(JA/OY-008) peak = 1163.400024 pos = 35.3409,133.6156 diff = 278.000000'
});
data_saddle.push({
lat: 3.5343333334e+01,
lng: 1.3360333333e+02,
content:'Saddle = 885.400024 pos = 35.3433,133.6033 diff = 278.000000'
});
data_peak.push({
lat: 3.5340888889e+01,
lng: 1.3359455556e+02,
cert : false,
content:' Peak = 1110.699951 pos = 35.3409,133.5946 diff = 173.299927'
});
data_saddle.push({
lat: 3.5348000000e+01,
lng: 1.3359466667e+02,
content:'Saddle = 937.400024 pos = 35.3480,133.5947 diff = 173.299927'
});
data_peak.push({
lat: 3.5386777778e+01,
lng: 1.3358088889e+02,
cert : true,
content:'Name = Yahazugasen(JA/TT-003) peak = 1356.300049 pos = 35.3868,133.5809 diff = 245.300049'
});
data_saddle.push({
lat: 3.5382111111e+01,
lng: 1.3357111111e+02,
content:'Saddle = 1111.000000 pos = 35.3821,133.5711 diff = 245.300049'
});
data_peak.push({
lat: 3.5355888889e+01,
lng: 1.3357033333e+02,
cert : false,
content:' Peak = 1441.500000 pos = 35.3559,133.5703 diff = 209.300049'
});
data_saddle.push({
lat: 3.5363555556e+01,
lng: 1.3355888889e+02,
content:'Saddle = 1232.199951 pos = 35.3636,133.5589 diff = 209.300049'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:36,
       south:34.6667,
       east:135,
       west:132}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
