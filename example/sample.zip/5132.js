function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.4595444444e+01,
lng: 1.3212966667e+02,
cert : true,
content:'Name = Osorakanzan(JA/HS-001) peak = 1344.199951 pos = 34.5954,132.1297 diff = 1344.199951'
});
data_saddle.push({
lat: 3.4365111109e+01,
lng: 1.3251688889e+02,
content:'Saddle = 0.000000 pos = 34.3651,132.5169 diff = 1344.199951'
});
data_peak.push({
lat: 3.3849777772e+01,
lng: 1.3237033333e+02,
cert : false,
content:' Peak = 180.300003 pos = 33.8498,132.3703 diff = 180.300003'
});
data_saddle.push({
lat: 3.3846777772e+01,
lng: 1.3236611111e+02,
content:'Saddle = 0.000000 pos = 33.8468,132.3661 diff = 180.300003'
});
data_peak.push({
lat: 3.3792555549e+01,
lng: 1.3222533333e+02,
cert : true,
content:'Name = JA/YG-097(JA/YG-097) peak = 466.600006 pos = 33.7926,132.2253 diff = 466.600006'
});
data_saddle.push({
lat: 3.3831555549e+01,
lng: 1.3213866667e+02,
content:'Saddle = 0.000000 pos = 33.8316,132.1387 diff = 466.600006'
});
data_peak.push({
lat: 3.3717999993e+01,
lng: 1.3213422222e+02,
cert : false,
content:' Peak = 279.799988 pos = 33.7180,132.1342 diff = 279.799988'
});
data_saddle.push({
lat: 3.3766444438e+01,
lng: 1.3225655556e+02,
content:'Saddle = 0.000000 pos = 33.7664,132.2566 diff = 279.799988'
});
data_peak.push({
lat: 3.3812777771e+01,
lng: 1.3225300000e+02,
cert : true,
content:'Name = JA/YG-172(JA/YG-172) peak = 200.600006 pos = 33.8128,132.2530 diff = 200.600006'
});
data_saddle.push({
lat: 3.3806444438e+01,
lng: 1.3225277778e+02,
content:'Saddle = 0.000000 pos = 33.8064,132.2528 diff = 200.600006'
});
data_peak.push({
lat: 3.3805999993e+01,
lng: 1.3239488889e+02,
cert : true,
content:'Name = JA/YG-166(JA/YG-166) peak = 231.699997 pos = 33.8060,132.3949 diff = 231.699997'
});
data_saddle.push({
lat: 3.3801777771e+01,
lng: 1.3239488889e+02,
content:'Saddle = 0.000000 pos = 33.8018,132.3949 diff = 231.699997'
});
data_peak.push({
lat: 3.3834222216e+01,
lng: 1.3209344444e+02,
cert : true,
content:'Name = JA/YG-154(JA/YG-154) peak = 313.700012 pos = 33.8342,132.0934 diff = 313.700012'
});
data_saddle.push({
lat: 3.3784555549e+01,
lng: 1.3204988889e+02,
content:'Saddle = 0.000000 pos = 33.7846,132.0499 diff = 313.700012'
});
data_peak.push({
lat: 3.3793555549e+01,
lng: 1.3205000000e+02,
cert : true,
content:'Name = JA/YG-173(JA/YG-173) peak = 182.500000 pos = 33.7936,132.0500 diff = 156.000000'
});
data_saddle.push({
lat: 3.3802333327e+01,
lng: 1.3205855556e+02,
content:'Saddle = 26.500000 pos = 33.8023,132.0586 diff = 156.000000'
});
data_peak.push({
lat: 3.3952222217e+01,
lng: 1.3234977778e+02,
cert : true,
content:'Name = JA/YG-175(JA/YG-175) peak = 164.000000 pos = 33.9522,132.3498 diff = 164.000000'
});
data_saddle.push({
lat: 3.3939333328e+01,
lng: 1.3235277778e+02,
content:'Saddle = 0.000000 pos = 33.9393,132.3528 diff = 164.000000'
});
data_peak.push({
lat: 3.4102333329e+01,
lng: 1.3247122222e+02,
cert : true,
content:'Name = JA/HS-173(JA/HS-173) peak = 492.200012 pos = 34.1023,132.4712 diff = 492.200012'
});
data_saddle.push({
lat: 3.4083333329e+01,
lng: 1.3255677778e+02,
content:'Saddle = 0.000000 pos = 34.0833,132.5568 diff = 492.200012'
});
data_peak.push({
lat: 3.4175222219e+01,
lng: 1.3251222222e+02,
cert : true,
content:'Name = JA/HS-215(JA/HS-215) peak = 342.700012 pos = 34.1752,132.5122 diff = 313.100006'
});
data_saddle.push({
lat: 3.4151666663e+01,
lng: 1.3251555556e+02,
content:'Saddle = 29.600000 pos = 34.1517,132.5156 diff = 313.100006'
});
data_peak.push({
lat: 3.4102444440e+01,
lng: 1.3255988889e+02,
cert : false,
content:' Peak = 270.799988 pos = 34.1024,132.5599 diff = 233.999985'
});
data_saddle.push({
lat: 3.4102222218e+01,
lng: 1.3254033333e+02,
content:'Saddle = 36.799999 pos = 34.1022,132.5403 diff = 233.999985'
});
data_peak.push({
lat: 3.4116444440e+01,
lng: 1.3251844444e+02,
cert : true,
content:'Name = JA/HS-184(JA/HS-184) peak = 462.799988 pos = 34.1164,132.5184 diff = 315.399994'
});
data_saddle.push({
lat: 3.4116333329e+01,
lng: 1.3250622222e+02,
content:'Saddle = 147.399994 pos = 34.1163,132.5062 diff = 315.399994'
});
data_peak.push({
lat: 3.4160777774e+01,
lng: 1.3282111111e+02,
cert : false,
content:' Peak = 334.200012 pos = 34.1608,132.8211 diff = 334.200012'
});
data_saddle.push({
lat: 3.4150888885e+01,
lng: 1.3282011111e+02,
content:'Saddle = 0.000000 pos = 34.1509,132.8201 diff = 334.200012'
});
data_peak.push({
lat: 3.4166666663e+01,
lng: 1.3284300000e+02,
cert : false,
content:' Peak = 267.100006 pos = 34.1667,132.8430 diff = 193.500000'
});
data_saddle.push({
lat: 3.4166666663e+01,
lng: 1.3283744444e+02,
content:'Saddle = 73.599998 pos = 34.1667,132.8374 diff = 193.500000'
});
data_peak.push({
lat: 3.4193111108e+01,
lng: 1.3230833333e+02,
cert : true,
content:'Name = JA/HS-229(JA/HS-229) peak = 202.500000 pos = 34.1931,132.3083 diff = 202.500000'
});
data_saddle.push({
lat: 3.4184333330e+01,
lng: 1.3230544444e+02,
content:'Saddle = 0.000000 pos = 34.1843,132.3054 diff = 202.500000'
});
data_peak.push({
lat: 3.4182666663e+01,
lng: 1.3266333333e+02,
cert : true,
content:'Name = JA/HS-224(JA/HS-224) peak = 274.299988 pos = 34.1827,132.6633 diff = 274.299988'
});
data_saddle.push({
lat: 3.4169444441e+01,
lng: 1.3266288889e+02,
content:'Saddle = 0.000000 pos = 34.1694,132.6629 diff = 274.299988'
});
data_peak.push({
lat: 3.4166666663e+01,
lng: 1.3278244444e+02,
cert : false,
content:' Peak = 302.200012 pos = 34.1667,132.7824 diff = 302.200012'
});
data_saddle.push({
lat: 3.4160777774e+01,
lng: 1.3278200000e+02,
content:'Saddle = 0.000000 pos = 34.1608,132.7820 diff = 302.200012'
});
data_peak.push({
lat: 3.4181555552e+01,
lng: 1.3272800000e+02,
cert : true,
content:'Name = JA/HS-186(JA/HS-186) peak = 453.000000 pos = 34.1816,132.7280 diff = 453.000000'
});
data_saddle.push({
lat: 3.4157777774e+01,
lng: 1.3273900000e+02,
content:'Saddle = 0.000000 pos = 34.1578,132.7390 diff = 453.000000'
});
data_peak.push({
lat: 3.4171222219e+01,
lng: 1.3274944444e+02,
cert : false,
content:' Peak = 220.699997 pos = 34.1712,132.7494 diff = 192.300003'
});
data_saddle.push({
lat: 3.4176111108e+01,
lng: 1.3274733333e+02,
content:'Saddle = 28.400000 pos = 34.1761,132.7473 diff = 192.300003'
});
data_peak.push({
lat: 3.4193444441e+01,
lng: 1.3270911111e+02,
cert : true,
content:'Name = JA/HS-202(JA/HS-202) peak = 420.600006 pos = 34.1934,132.7091 diff = 311.299988'
});
data_saddle.push({
lat: 3.4183777774e+01,
lng: 1.3271755556e+02,
content:'Saddle = 109.300003 pos = 34.1838,132.7176 diff = 311.299988'
});
data_peak.push({
lat: 3.4156222218e+01,
lng: 1.3239600000e+02,
cert : true,
content:'Name = JA/HS-183(JA/HS-183) peak = 460.799988 pos = 34.1562,132.3960 diff = 460.799988'
});
data_saddle.push({
lat: 3.4146333330e+01,
lng: 1.3239766667e+02,
content:'Saddle = 0.000000 pos = 34.1463,132.3977 diff = 460.799988'
});
data_peak.push({
lat: 3.4216222219e+01,
lng: 1.3241766667e+02,
cert : true,
content:'Name = JA/HS-157(JA/HS-157) peak = 541.500000 pos = 34.2162,132.4177 diff = 541.500000'
});
data_saddle.push({
lat: 3.4128555552e+01,
lng: 1.3242977778e+02,
content:'Saddle = 0.000000 pos = 34.1286,132.4298 diff = 541.500000'
});
data_peak.push({
lat: 3.4259444442e+01,
lng: 1.3247466667e+02,
cert : false,
content:' Peak = 393.600006 pos = 34.2594,132.4747 diff = 388.000000'
});
data_saddle.push({
lat: 3.4201444441e+01,
lng: 1.3247322222e+02,
content:'Saddle = 5.600000 pos = 34.2014,132.4732 diff = 388.000000'
});
data_peak.push({
lat: 3.4251444441e+01,
lng: 1.3244111111e+02,
cert : true,
content:'Name = JA/HS-225(JA/HS-225) peak = 262.000000 pos = 34.2514,132.4411 diff = 245.199997'
});
data_saddle.push({
lat: 3.4261555553e+01,
lng: 1.3244644444e+02,
content:'Saddle = 16.799999 pos = 34.2616,132.4464 diff = 245.199997'
});
data_peak.push({
lat: 3.4209666663e+01,
lng: 1.3248344444e+02,
cert : false,
content:' Peak = 203.600006 pos = 34.2097,132.4834 diff = 156.800003'
});
data_saddle.push({
lat: 3.4248333330e+01,
lng: 1.3248400000e+02,
content:'Saddle = 46.799999 pos = 34.2483,132.4840 diff = 156.800003'
});
data_peak.push({
lat: 3.4151111107e+01,
lng: 1.3246844444e+02,
cert : true,
content:'Name = JA/HS-196(JA/HS-196) peak = 437.299988 pos = 34.1511,132.4684 diff = 421.199982'
});
data_saddle.push({
lat: 3.4211111108e+01,
lng: 1.3244155556e+02,
content:'Saddle = 16.100000 pos = 34.2111,132.4416 diff = 421.199982'
});
data_peak.push({
lat: 3.4206999997e+01,
lng: 1.3245366667e+02,
cert : true,
content:'Name = JA/HS-221(JA/HS-221) peak = 281.100006 pos = 34.2070,132.4537 diff = 254.400009'
});
data_saddle.push({
lat: 3.4178777774e+01,
lng: 1.3246588889e+02,
content:'Saddle = 26.700001 pos = 34.1788,132.4659 diff = 254.400009'
});
data_peak.push({
lat: 3.4241111108e+01,
lng: 1.3240033333e+02,
cert : false,
content:' Peak = 402.100006 pos = 34.2411,132.4003 diff = 168.500000'
});
data_saddle.push({
lat: 3.4230777775e+01,
lng: 1.3240055556e+02,
content:'Saddle = 233.600006 pos = 34.2308,132.4006 diff = 168.500000'
});
data_peak.push({
lat: 3.4335222220e+01,
lng: 1.3248255556e+02,
cert : true,
content:'Name = JA/HS-234(JA/HS-234) peak = 155.699997 pos = 34.3352,132.4826 diff = 155.699997'
});
data_saddle.push({
lat: 3.4330222220e+01,
lng: 1.3248077778e+02,
content:'Saddle = 0.000000 pos = 34.3302,132.4808 diff = 155.699997'
});
data_peak.push({
lat: 3.4319222220e+01,
lng: 1.3243977778e+02,
cert : false,
content:' Peak = 277.200012 pos = 34.3192,132.4398 diff = 277.200012'
});
data_saddle.push({
lat: 3.4296777775e+01,
lng: 1.3244266667e+02,
content:'Saddle = 0.000000 pos = 34.2968,132.4427 diff = 277.200012'
});
data_peak.push({
lat: 3.4301555553e+01,
lng: 1.3243200000e+02,
cert : true,
content:'Name = JA/HS-230(JA/HS-230) peak = 200.300003 pos = 34.3016,132.4320 diff = 158.899994'
});
data_saddle.push({
lat: 3.4308666664e+01,
lng: 1.3243611111e+02,
content:'Saddle = 41.400002 pos = 34.3087,132.4361 diff = 158.899994'
});
data_peak.push({
lat: 3.4279555553e+01,
lng: 1.3231944444e+02,
cert : true,
content:'Name = Misen(JA/HS-160) peak = 532.400024 pos = 34.2796,132.3194 diff = 532.400024'
});
data_saddle.push({
lat: 3.4231444441e+01,
lng: 1.3227455556e+02,
content:'Saddle = 0.000000 pos = 34.2314,132.2746 diff = 532.400024'
});
data_peak.push({
lat: 3.4252333330e+01,
lng: 1.3228911111e+02,
cert : false,
content:' Peak = 466.100006 pos = 34.2523,132.2891 diff = 228.500000'
});
data_saddle.push({
lat: 3.4258222219e+01,
lng: 1.3229633333e+02,
content:'Saddle = 237.600006 pos = 34.2582,132.2963 diff = 228.500000'
});
data_peak.push({
lat: 3.4271666664e+01,
lng: 1.3231122222e+02,
cert : true,
content:'Name = JA/HS-170(JA/HS-170) peak = 501.399994 pos = 34.2717,132.3112 diff = 170.299988'
});
data_saddle.push({
lat: 3.4275999997e+01,
lng: 1.3231588889e+02,
content:'Saddle = 331.100006 pos = 34.2760,132.3159 diff = 170.299988'
});
data_peak.push({
lat: 3.4234888886e+01,
lng: 1.3481411111e+02,
cert : true,
content:'Name = Yuduruhasan(JA/HG-083) peak = 606.900024 pos = 34.2349,134.8141 diff = 606.900024'
});
data_saddle.push({
lat: 3.4193222219e+01,
lng: 1.3475022222e+02,
content:'Saddle = 0.000000 pos = 34.1932,134.7502 diff = 606.900024'
});
data_peak.push({
lat: 3.4276777775e+01,
lng: 1.3472588889e+02,
cert : false,
content:' Peak = 273.700012 pos = 34.2768,134.7259 diff = 241.200012'
});
data_saddle.push({
lat: 3.4250111108e+01,
lng: 1.3474388889e+02,
content:'Saddle = 32.500000 pos = 34.2501,134.7439 diff = 241.200012'
});
data_peak.push({
lat: 3.4300333331e+01,
lng: 1.3467633333e+02,
cert : false,
content:' Peak = 245.399994 pos = 34.3003,134.6763 diff = 184.399994'
});
data_saddle.push({
lat: 3.4284555553e+01,
lng: 1.3468033333e+02,
content:'Saddle = 61.000000 pos = 34.2846,134.6803 diff = 184.399994'
});
data_peak.push({
lat: 3.4302333331e+01,
lng: 1.3471766667e+02,
cert : false,
content:' Peak = 254.100006 pos = 34.3023,134.7177 diff = 166.800003'
});
data_saddle.push({
lat: 3.4278555553e+01,
lng: 1.3470622222e+02,
content:'Saddle = 87.300003 pos = 34.2786,134.7062 diff = 166.800003'
});
data_peak.push({
lat: 3.4497333332e+01,
lng: 1.3494344444e+02,
cert : true,
content:'Name = Myukenyama(JA/HG-118) peak = 521.700012 pos = 34.4973,134.9434 diff = 477.600006'
});
data_saddle.push({
lat: 3.4439555554e+01,
lng: 1.3486933333e+02,
content:'Saddle = 44.099998 pos = 34.4396,134.8693 diff = 477.600006'
});
data_peak.push({
lat: 3.4357777776e+01,
lng: 1.3483877778e+02,
cert : true,
content:'Name = JA/HG-148(JA/HG-148) peak = 446.700012 pos = 34.3578,134.8388 diff = 387.300018'
});
data_saddle.push({
lat: 3.4325333331e+01,
lng: 1.3481677778e+02,
content:'Saddle = 59.400002 pos = 34.3253,134.8168 diff = 387.300018'
});
data_peak.push({
lat: 3.4364333331e+01,
lng: 1.3488422222e+02,
cert : false,
content:' Peak = 230.300003 pos = 34.3643,134.8842 diff = 159.300003'
});
data_saddle.push({
lat: 3.4363999998e+01,
lng: 1.3487422222e+02,
content:'Saddle = 71.000000 pos = 34.3640,134.8742 diff = 159.300003'
});
data_peak.push({
lat: 3.4318333331e+01,
lng: 1.3480777778e+02,
cert : false,
content:' Peak = 231.800003 pos = 34.3183,134.8078 diff = 165.300003'
});
data_saddle.push({
lat: 3.4311444442e+01,
lng: 1.3481211111e+02,
content:'Saddle = 66.500000 pos = 34.3114,134.8121 diff = 165.300003'
});
data_peak.push({
lat: 3.4285111108e+01,
lng: 1.3489777778e+02,
cert : false,
content:' Peak = 565.099976 pos = 34.2851,134.8978 diff = 243.599976'
});
data_saddle.push({
lat: 3.4258888886e+01,
lng: 1.3486533333e+02,
content:'Saddle = 321.500000 pos = 34.2589,134.8653 diff = 243.599976'
});
data_peak.push({
lat: 3.4276777775e+01,
lng: 1.3486577778e+02,
cert : true,
content:'Name = JA/HG-115(JA/HG-115) peak = 533.500000 pos = 34.2768,134.8658 diff = 191.000000'
});
data_saddle.push({
lat: 3.4269888886e+01,
lng: 1.3487555556e+02,
content:'Saddle = 342.500000 pos = 34.2699,134.8756 diff = 191.000000'
});
data_peak.push({
lat: 3.4272222219e+01,
lng: 1.3483566667e+02,
cert : false,
content:' Peak = 533.700012 pos = 34.2722,134.8357 diff = 155.600006'
});
data_saddle.push({
lat: 3.4267111108e+01,
lng: 1.3484122222e+02,
content:'Saddle = 378.100006 pos = 34.2671,134.8412 diff = 155.600006'
});
data_peak.push({
lat: 3.4245555553e+01,
lng: 1.3483811111e+02,
cert : true,
content:'Name = JA/HG-091(JA/HG-091) peak = 585.000000 pos = 34.2456,134.8381 diff = 162.200012'
});
data_saddle.push({
lat: 3.4239666664e+01,
lng: 1.3483200000e+02,
content:'Saddle = 422.799988 pos = 34.2397,134.8320 diff = 162.200012'
});
data_peak.push({
lat: 3.3914111105e+01,
lng: 1.3224522222e+02,
cert : true,
content:'Name = Kanōsan(JA/YG-031) peak = 690.799988 pos = 33.9141,132.2452 diff = 690.799988'
});
data_saddle.push({
lat: 3.3856777772e+01,
lng: 1.3220811111e+02,
content:'Saddle = 0.000000 pos = 33.8568,132.2081 diff = 690.799988'
});
data_peak.push({
lat: 3.3888555550e+01,
lng: 1.3235111111e+02,
cert : true,
content:'Name = JA/YG-134(JA/YG-134) peak = 373.399994 pos = 33.8886,132.3511 diff = 364.799988'
});
data_saddle.push({
lat: 3.3891111105e+01,
lng: 1.3232888889e+02,
content:'Saddle = 8.600000 pos = 33.8911,132.3289 diff = 364.799988'
});
data_peak.push({
lat: 3.3890222216e+01,
lng: 1.3221922222e+02,
cert : true,
content:'Name = JA/YG-083(JA/YG-083) peak = 536.799988 pos = 33.8902,132.2192 diff = 199.199982'
});
data_saddle.push({
lat: 3.3891222216e+01,
lng: 1.3223288889e+02,
content:'Saddle = 337.600006 pos = 33.8912,132.2329 diff = 199.199982'
});
data_peak.push({
lat: 3.3912888883e+01,
lng: 1.3227088889e+02,
cert : false,
content:' Peak = 617.599976 pos = 33.9129,132.2709 diff = 165.699982'
});
data_saddle.push({
lat: 3.3915333328e+01,
lng: 1.3226544444e+02,
content:'Saddle = 451.899994 pos = 33.9153,132.2654 diff = 165.699982'
});
data_peak.push({
lat: 3.4460111110e+01,
lng: 1.3350655556e+02,
cert : true,
content:'Name = JA/OY-135(JA/OY-135) peak = 304.200012 pos = 34.4601,133.5066 diff = 302.300018'
});
data_saddle.push({
lat: 3.4485444443e+01,
lng: 1.3351166667e+02,
content:'Saddle = 1.900000 pos = 34.4854,133.5117 diff = 302.300018'
});
data_peak.push({
lat: 3.4632777778e+01,
lng: 1.3407933333e+02,
cert : false,
content:' Peak = 181.699997 pos = 34.6328,134.0793 diff = 179.699997'
});
data_saddle.push({
lat: 3.4645222222e+01,
lng: 1.3391666667e+02,
content:'Saddle = 2.000000 pos = 34.6452,133.9167 diff = 179.699997'
});
data_peak.push({
lat: 3.4661111111e+01,
lng: 1.3395555556e+02,
cert : false,
content:' Peak = 168.000000 pos = 34.6611,133.9556 diff = 164.500000'
});
data_saddle.push({
lat: 3.4666222223e+01,
lng: 1.3399433333e+02,
content:'Saddle = 3.500000 pos = 34.6662,133.9943 diff = 164.500000'
});
data_peak.push({
lat: 3.4367222220e+01,
lng: 1.3249055556e+02,
cert : false,
content:' Peak = 220.399994 pos = 34.3672,132.4906 diff = 216.399994'
});
data_saddle.push({
lat: 3.4371555554e+01,
lng: 1.3250144444e+02,
content:'Saddle = 4.000000 pos = 34.3716,132.5014 diff = 216.399994'
});
data_peak.push({
lat: 3.4392666665e+01,
lng: 1.3325333333e+02,
cert : false,
content:' Peak = 160.600006 pos = 34.3927,133.2533 diff = 155.100006'
});
data_saddle.push({
lat: 3.4401111109e+01,
lng: 1.3327288889e+02,
content:'Saddle = 5.500000 pos = 34.4011,133.2729 diff = 155.100006'
});
data_peak.push({
lat: 3.4562111111e+01,
lng: 1.3372233333e+02,
cert : false,
content:' Peak = 163.899994 pos = 34.5621,133.7223 diff = 158.299988'
});
data_saddle.push({
lat: 3.4587222222e+01,
lng: 1.3374522222e+02,
content:'Saddle = 5.600000 pos = 34.5872,133.7452 diff = 158.299988'
});
data_peak.push({
lat: 3.4518444444e+01,
lng: 1.3386633333e+02,
cert : false,
content:' Peak = 300.200012 pos = 34.5184,133.8663 diff = 294.500000'
});
data_saddle.push({
lat: 3.4598555555e+01,
lng: 1.3374644444e+02,
content:'Saddle = 5.700000 pos = 34.5986,133.7464 diff = 294.500000'
});
data_peak.push({
lat: 3.4548333333e+01,
lng: 1.3379022222e+02,
cert : false,
content:' Peak = 257.399994 pos = 34.5483,133.7902 diff = 226.399994'
});
data_saddle.push({
lat: 3.4527444444e+01,
lng: 1.3379788889e+02,
content:'Saddle = 31.000000 pos = 34.5274,133.7979 diff = 226.399994'
});
data_peak.push({
lat: 3.4511222221e+01,
lng: 1.3378277778e+02,
cert : true,
content:'Name = JA/OY-141(JA/OY-141) peak = 282.500000 pos = 34.5112,133.7828 diff = 223.600006'
});
data_saddle.push({
lat: 3.4516333332e+01,
lng: 1.3380744444e+02,
content:'Saddle = 58.900002 pos = 34.5163,133.8074 diff = 223.600006'
});
data_peak.push({
lat: 3.3853111105e+01,
lng: 1.3214233333e+02,
cert : true,
content:'Name = Oozasan(JA/YG-086) peak = 525.299988 pos = 33.8531,132.1423 diff = 516.000000'
});
data_saddle.push({
lat: 3.3961555550e+01,
lng: 1.3205577778e+02,
content:'Saddle = 9.300000 pos = 33.9616,132.0558 diff = 516.000000'
});
data_peak.push({
lat: 3.3956666661e+01,
lng: 1.3207844444e+02,
cert : false,
content:' Peak = 230.300003 pos = 33.9567,132.0784 diff = 207.800003'
});
data_saddle.push({
lat: 3.3956555550e+01,
lng: 1.3209588889e+02,
content:'Saddle = 22.500000 pos = 33.9566,132.0959 diff = 207.800003'
});
data_peak.push({
lat: 3.3910666661e+01,
lng: 1.3209577778e+02,
cert : true,
content:'Name = JA/YG-107(JA/YG-107) peak = 436.299988 pos = 33.9107,132.0958 diff = 367.299988'
});
data_saddle.push({
lat: 3.3880666661e+01,
lng: 1.3212233333e+02,
content:'Saddle = 69.000000 pos = 33.8807,132.1223 diff = 367.299988'
});
data_peak.push({
lat: 3.4646444445e+01,
lng: 1.3375955556e+02,
cert : true,
content:'Name = JA/OY-136(JA/OY-136) peak = 302.000000 pos = 34.6464,133.7596 diff = 288.500000'
});
data_saddle.push({
lat: 3.4666666667e+01,
lng: 1.3372855556e+02,
content:'Saddle = 13.500000 pos = 34.6667,133.7286 diff = 288.500000'
});
data_peak.push({
lat: 3.4660666667e+01,
lng: 1.3380133333e+02,
cert : false,
content:' Peak = 226.399994 pos = 34.6607,133.8013 diff = 169.000000'
});
data_saddle.push({
lat: 3.4643000000e+01,
lng: 1.3377622222e+02,
content:'Saddle = 57.400002 pos = 34.6430,133.7762 diff = 169.000000'
});
data_peak.push({
lat: 3.4499333332e+01,
lng: 1.3346933333e+02,
cert : false,
content:' Peak = 169.000000 pos = 34.4993,133.4693 diff = 150.199997'
});
data_saddle.push({
lat: 3.4502111110e+01,
lng: 1.3345266667e+02,
content:'Saddle = 18.799999 pos = 34.5021,133.4527 diff = 150.199997'
});
data_peak.push({
lat: 3.4470333332e+01,
lng: 1.3354644444e+02,
cert : true,
content:'Name = JA/OY-132(JA/OY-132) peak = 321.399994 pos = 34.4703,133.5464 diff = 302.000000'
});
data_saddle.push({
lat: 3.4513222221e+01,
lng: 1.3355988889e+02,
content:'Saddle = 19.400000 pos = 34.5132,133.5599 diff = 302.000000'
});
data_peak.push({
lat: 3.4501111110e+01,
lng: 1.3358622222e+02,
cert : true,
content:'Name = JA/OY-140(JA/OY-140) peak = 287.200012 pos = 34.5011,133.5862 diff = 249.600006'
});
data_saddle.push({
lat: 3.4477333332e+01,
lng: 1.3356222222e+02,
content:'Saddle = 37.599998 pos = 34.4773,133.5622 diff = 249.600006'
});
data_peak.push({
lat: 3.4470888888e+01,
lng: 1.3357155556e+02,
cert : false,
content:' Peak = 247.800003 pos = 34.4709,133.5716 diff = 200.100006'
});
data_saddle.push({
lat: 3.4494555555e+01,
lng: 1.3357811111e+02,
content:'Saddle = 47.700001 pos = 34.4946,133.5781 diff = 200.100006'
});
data_peak.push({
lat: 3.4483111110e+01,
lng: 1.3356855556e+02,
cert : false,
content:' Peak = 242.100006 pos = 34.4831,133.5686 diff = 175.300003'
});
data_saddle.push({
lat: 3.4477777777e+01,
lng: 1.3357022222e+02,
content:'Saddle = 66.800003 pos = 34.4778,133.5702 diff = 175.300003'
});
data_peak.push({
lat: 3.4513111110e+01,
lng: 1.3338388889e+02,
cert : false,
content:' Peak = 224.300003 pos = 34.5131,133.3839 diff = 204.699997'
});
data_saddle.push({
lat: 3.4517888888e+01,
lng: 1.3338733333e+02,
content:'Saddle = 19.600000 pos = 34.5179,133.3873 diff = 204.699997'
});
data_peak.push({
lat: 3.4433444443e+01,
lng: 1.3336811111e+02,
cert : true,
content:'Name = Kumagamine(JA/HS-195) peak = 436.899994 pos = 34.4334,133.3681 diff = 407.500000'
});
data_saddle.push({
lat: 3.4465222221e+01,
lng: 1.3329288889e+02,
content:'Saddle = 29.400000 pos = 34.4652,133.2929 diff = 407.500000'
});
data_peak.push({
lat: 3.4445444443e+01,
lng: 1.3331311111e+02,
cert : true,
content:'Name = JA/HS-220(JA/HS-220) peak = 297.799988 pos = 34.4454,133.3131 diff = 216.599991'
});
data_saddle.push({
lat: 3.4430222221e+01,
lng: 1.3333033333e+02,
content:'Saddle = 81.199997 pos = 34.4302,133.3303 diff = 216.599991'
});
data_peak.push({
lat: 3.4612222222e+01,
lng: 1.3369844444e+02,
cert : false,
content:' Peak = 208.600006 pos = 34.6122,133.6984 diff = 171.300003'
});
data_saddle.push({
lat: 3.4592333333e+01,
lng: 1.3367855556e+02,
content:'Saddle = 37.299999 pos = 34.5923,133.6786 diff = 171.300003'
});
data_peak.push({
lat: 3.3932666661e+01,
lng: 1.3200066667e+02,
cert : false,
content:' Peak = 281.700012 pos = 33.9327,132.0007 diff = 244.100006'
});
data_saddle.push({
lat: 3.3976333328e+01,
lng: 1.3200000000e+02,
content:'Saddle = 37.599998 pos = 33.9763,132.0000 diff = 244.100006'
});
data_peak.push({
lat: 3.4136222218e+01,
lng: 1.3202244444e+02,
cert : true,
content:'Name = JA/YG-026(JA/YG-026) peak = 707.400024 pos = 34.1362,132.0224 diff = 668.300049'
});
data_saddle.push({
lat: 3.4215333330e+01,
lng: 1.3200000000e+02,
content:'Saddle = 39.099998 pos = 34.2153,132.0000 diff = 668.300049'
});
data_peak.push({
lat: 3.3973444439e+01,
lng: 1.3214911111e+02,
cert : true,
content:'Name = Kotoishiyama(JA/YG-077) peak = 544.799988 pos = 33.9734,132.1491 diff = 450.799988'
});
data_saddle.push({
lat: 3.4029111106e+01,
lng: 1.3210700000e+02,
content:'Saddle = 94.000000 pos = 34.0291,132.1070 diff = 450.799988'
});
data_peak.push({
lat: 3.4027333329e+01,
lng: 1.3202222222e+02,
cert : false,
content:' Peak = 382.100006 pos = 34.0273,132.0222 diff = 273.900024'
});
data_saddle.push({
lat: 3.4005444439e+01,
lng: 1.3212611111e+02,
content:'Saddle = 108.199997 pos = 34.0054,132.1261 diff = 273.900024'
});
data_peak.push({
lat: 3.3987666662e+01,
lng: 1.3203922222e+02,
cert : true,
content:'Name = JA/YG-140(JA/YG-140) peak = 361.100006 pos = 33.9877,132.0392 diff = 232.900009'
});
data_saddle.push({
lat: 3.3988888884e+01,
lng: 1.3205488889e+02,
content:'Saddle = 128.199997 pos = 33.9889,132.0549 diff = 232.900009'
});
data_peak.push({
lat: 3.4009222217e+01,
lng: 1.3211988889e+02,
cert : false,
content:' Peak = 323.100006 pos = 34.0092,132.1199 diff = 157.100006'
});
data_saddle.push({
lat: 3.4018999995e+01,
lng: 1.3208433333e+02,
content:'Saddle = 166.000000 pos = 34.0190,132.0843 diff = 157.100006'
});
data_peak.push({
lat: 3.4061444440e+01,
lng: 1.3202700000e+02,
cert : false,
content:' Peak = 364.399994 pos = 34.0614,132.0270 diff = 197.899994'
});
data_saddle.push({
lat: 3.4041777773e+01,
lng: 1.3204266667e+02,
content:'Saddle = 166.500000 pos = 34.0418,132.0427 diff = 197.899994'
});
data_peak.push({
lat: 3.4038333329e+01,
lng: 1.3205888889e+02,
cert : true,
content:'Name = JA/YG-141(JA/YG-141) peak = 360.000000 pos = 34.0383,132.0589 diff = 190.300003'
});
data_saddle.push({
lat: 3.4022444440e+01,
lng: 1.3206322222e+02,
content:'Saddle = 169.699997 pos = 34.0224,132.0632 diff = 190.300003'
});
data_peak.push({
lat: 3.4025444440e+01,
lng: 1.3207533333e+02,
cert : false,
content:' Peak = 329.899994 pos = 34.0254,132.0753 diff = 151.099991'
});
data_saddle.push({
lat: 3.4030333329e+01,
lng: 1.3206588889e+02,
content:'Saddle = 178.800003 pos = 34.0303,132.0659 diff = 151.099991'
});
data_peak.push({
lat: 3.4010888884e+01,
lng: 1.3219666667e+02,
cert : true,
content:'Name = Zenitsuboyama(JA/YG-082) peak = 540.000000 pos = 34.0109,132.1967 diff = 412.299988'
});
data_saddle.push({
lat: 3.3978999995e+01,
lng: 1.3216722222e+02,
content:'Saddle = 127.699997 pos = 33.9790,132.1672 diff = 412.299988'
});
data_peak.push({
lat: 3.3981888884e+01,
lng: 1.3217755556e+02,
cert : true,
content:'Name = JA/YG-145(JA/YG-145) peak = 352.500000 pos = 33.9819,132.1776 diff = 220.699997'
});
data_saddle.push({
lat: 3.3994777773e+01,
lng: 1.3218111111e+02,
content:'Saddle = 131.800003 pos = 33.9948,132.1811 diff = 220.699997'
});
data_peak.push({
lat: 3.4161333330e+01,
lng: 1.3216655556e+02,
cert : true,
content:'Name = JA/YG-159(JA/YG-159) peak = 300.299988 pos = 34.1613,132.1666 diff = 201.499985'
});
data_saddle.push({
lat: 3.4147444441e+01,
lng: 1.3216755556e+02,
content:'Saddle = 98.800003 pos = 34.1474,132.1676 diff = 201.499985'
});
data_peak.push({
lat: 3.4134777774e+01,
lng: 1.3210522222e+02,
cert : false,
content:' Peak = 315.700012 pos = 34.1348,132.1052 diff = 156.900009'
});
data_saddle.push({
lat: 3.4129777774e+01,
lng: 1.3211211111e+02,
content:'Saddle = 158.800003 pos = 34.1298,132.1121 diff = 156.900009'
});
data_peak.push({
lat: 3.4075555551e+01,
lng: 1.3215377778e+02,
cert : true,
content:'Name = JA/YG-039(JA/YG-039) peak = 644.400024 pos = 34.0756,132.1538 diff = 476.600037'
});
data_saddle.push({
lat: 3.4115555551e+01,
lng: 1.3210366667e+02,
content:'Saddle = 167.800003 pos = 34.1156,132.1037 diff = 476.600037'
});
data_peak.push({
lat: 3.4138333329e+01,
lng: 1.3213133333e+02,
cert : true,
content:'Name = JA/YG-109(JA/YG-109) peak = 431.899994 pos = 34.1383,132.1313 diff = 233.899994'
});
data_saddle.push({
lat: 3.4115333329e+01,
lng: 1.3211844444e+02,
content:'Saddle = 198.000000 pos = 34.1153,132.1184 diff = 233.899994'
});
data_peak.push({
lat: 3.4162111107e+01,
lng: 1.3212511111e+02,
cert : true,
content:'Name = JA/YG-113(JA/YG-113) peak = 426.600006 pos = 34.1621,132.1251 diff = 183.300003'
});
data_saddle.push({
lat: 3.4147888885e+01,
lng: 1.3213200000e+02,
content:'Saddle = 243.300003 pos = 34.1479,132.1320 diff = 183.300003'
});
data_peak.push({
lat: 3.4050777773e+01,
lng: 1.3212333333e+02,
cert : false,
content:' Peak = 561.700012 pos = 34.0508,132.1233 diff = 333.500000'
});
data_saddle.push({
lat: 3.4041111106e+01,
lng: 1.3214411111e+02,
content:'Saddle = 228.199997 pos = 34.0411,132.1441 diff = 333.500000'
});
data_peak.push({
lat: 3.4041777773e+01,
lng: 1.3215544444e+02,
cert : true,
content:'Name = JA/YG-114(JA/YG-114) peak = 426.399994 pos = 34.0418,132.1554 diff = 169.799988'
});
data_saddle.push({
lat: 3.4044444440e+01,
lng: 1.3217444444e+02,
content:'Saddle = 256.600006 pos = 34.0444,132.1744 diff = 169.799988'
});
data_peak.push({
lat: 3.4105555551e+01,
lng: 1.3212911111e+02,
cert : true,
content:'Name = JA/YG-087(JA/YG-087) peak = 523.900024 pos = 34.1056,132.1291 diff = 175.900024'
});
data_saddle.push({
lat: 3.4092999996e+01,
lng: 1.3213488889e+02,
content:'Saddle = 348.000000 pos = 34.0930,132.1349 diff = 175.900024'
});
data_peak.push({
lat: 3.4103333329e+01,
lng: 1.3201688889e+02,
cert : true,
content:'Name = JA/YG-110(JA/YG-110) peak = 430.899994 pos = 34.1033,132.0169 diff = 232.199997'
});
data_saddle.push({
lat: 3.4127555552e+01,
lng: 1.3200077778e+02,
content:'Saddle = 198.699997 pos = 34.1276,132.0008 diff = 232.199997'
});
data_peak.push({
lat: 3.4115111107e+01,
lng: 1.3209288889e+02,
cert : true,
content:'Name = JA/YG-119(JA/YG-119) peak = 401.200012 pos = 34.1151,132.0929 diff = 183.700012'
});
data_saddle.push({
lat: 3.4124333329e+01,
lng: 1.3209233333e+02,
content:'Saddle = 217.500000 pos = 34.1243,132.0923 diff = 183.700012'
});
data_peak.push({
lat: 3.4167444441e+01,
lng: 1.3204588889e+02,
cert : false,
content:' Peak = 420.799988 pos = 34.1674,132.0459 diff = 179.499985'
});
data_saddle.push({
lat: 3.4159111107e+01,
lng: 1.3205866667e+02,
content:'Saddle = 241.300003 pos = 34.1591,132.0587 diff = 179.499985'
});
data_peak.push({
lat: 3.4119888885e+01,
lng: 1.3206766667e+02,
cert : true,
content:'Name = JA/YG-067(JA/YG-067) peak = 575.200012 pos = 34.1199,132.0677 diff = 248.200012'
});
data_saddle.push({
lat: 3.4132111107e+01,
lng: 1.3205666667e+02,
content:'Saddle = 327.000000 pos = 34.1321,132.0567 diff = 248.200012'
});
data_peak.push({
lat: 3.4201444441e+01,
lng: 1.3201811111e+02,
cert : false,
content:' Peak = 494.799988 pos = 34.2014,132.0181 diff = 153.500000'
});
data_saddle.push({
lat: 3.4189999997e+01,
lng: 1.3201611111e+02,
content:'Saddle = 341.299988 pos = 34.1900,132.0161 diff = 153.500000'
});
data_peak.push({
lat: 3.4573333333e+01,
lng: 1.3361011111e+02,
cert : true,
content:'Name = JA/OY-113(JA/OY-113) peak = 404.700012 pos = 34.5733,133.6101 diff = 365.100006'
});
data_saddle.push({
lat: 3.4594555555e+01,
lng: 1.3346822222e+02,
content:'Saddle = 39.599998 pos = 34.5946,133.4682 diff = 365.100006'
});
data_peak.push({
lat: 3.4523111110e+01,
lng: 1.3350688889e+02,
cert : false,
content:' Peak = 211.800003 pos = 34.5231,133.5069 diff = 163.899994'
});
data_saddle.push({
lat: 3.4530333333e+01,
lng: 1.3351133333e+02,
content:'Saddle = 47.900002 pos = 34.5303,133.5113 diff = 163.899994'
});
data_peak.push({
lat: 3.4533777777e+01,
lng: 1.3340077778e+02,
cert : false,
content:' Peak = 256.500000 pos = 34.5338,133.4008 diff = 207.800003'
});
data_saddle.push({
lat: 3.4524888888e+01,
lng: 1.3343144444e+02,
content:'Saddle = 48.700001 pos = 34.5249,133.4314 diff = 207.800003'
});
data_peak.push({
lat: 3.4506666666e+01,
lng: 1.3352300000e+02,
cert : false,
content:' Peak = 218.500000 pos = 34.5067,133.5230 diff = 163.000000'
});
data_saddle.push({
lat: 3.4536222222e+01,
lng: 1.3352155556e+02,
content:'Saddle = 55.500000 pos = 34.5362,133.5216 diff = 163.000000'
});
data_peak.push({
lat: 3.4597777778e+01,
lng: 1.3360822222e+02,
cert : true,
content:'Name = JA/OY-142(JA/OY-142) peak = 270.000000 pos = 34.5978,133.6082 diff = 212.000000'
});
data_saddle.push({
lat: 3.4591111111e+01,
lng: 1.3361488889e+02,
content:'Saddle = 58.000000 pos = 34.5911,133.6149 diff = 212.000000'
});
data_peak.push({
lat: 3.4521555555e+01,
lng: 1.3354666667e+02,
cert : false,
content:' Peak = 261.899994 pos = 34.5216,133.5467 diff = 165.199997'
});
data_saddle.push({
lat: 3.4532666666e+01,
lng: 1.3354622222e+02,
content:'Saddle = 96.699997 pos = 34.5327,133.5462 diff = 165.199997'
});
data_peak.push({
lat: 3.4545222222e+01,
lng: 1.3354566667e+02,
cert : false,
content:' Peak = 302.799988 pos = 34.5452,133.5457 diff = 167.399994'
});
data_saddle.push({
lat: 3.4551111111e+01,
lng: 1.3355377778e+02,
content:'Saddle = 135.399994 pos = 34.5511,133.5538 diff = 167.399994'
});
data_peak.push({
lat: 3.4265333330e+01,
lng: 1.3274322222e+02,
cert : true,
content:'Name = JA/HS-213(JA/HS-213) peak = 361.600006 pos = 34.2653,132.7432 diff = 304.300018'
});
data_saddle.push({
lat: 3.4245777775e+01,
lng: 1.3271611111e+02,
content:'Saddle = 57.299999 pos = 34.2458,132.7161 diff = 304.300018'
});
data_peak.push({
lat: 3.4422777776e+01,
lng: 1.3248544444e+02,
cert : false,
content:' Peak = 260.399994 pos = 34.4228,132.4854 diff = 202.599991'
});
data_saddle.push({
lat: 3.4423222221e+01,
lng: 1.3249444444e+02,
content:'Saddle = 57.799999 pos = 34.4232,132.4944 diff = 202.599991'
});
data_peak.push({
lat: 3.4214999997e+01,
lng: 1.3264577778e+02,
cert : true,
content:'Name = JA/HS-214(JA/HS-214) peak = 357.299988 pos = 34.2150,132.6458 diff = 295.799988'
});
data_saddle.push({
lat: 3.4222999997e+01,
lng: 1.3264644444e+02,
content:'Saddle = 61.500000 pos = 34.2230,132.6464 diff = 295.799988'
});
data_peak.push({
lat: 3.4339888887e+01,
lng: 1.3302000000e+02,
cert : false,
content:' Peak = 225.000000 pos = 34.3399,133.0200 diff = 156.100006'
});
data_saddle.push({
lat: 3.4344333331e+01,
lng: 1.3300933333e+02,
content:'Saddle = 68.900002 pos = 34.3443,133.0093 diff = 156.100006'
});
data_peak.push({
lat: 3.4635222222e+01,
lng: 1.3362533333e+02,
cert : true,
content:'Name = JA/OY-115(JA/OY-115) peak = 400.299988 pos = 34.6352,133.6253 diff = 327.299988'
});
data_saddle.push({
lat: 3.4666666667e+01,
lng: 1.3359222222e+02,
content:'Saddle = 73.000000 pos = 34.6667,133.5922 diff = 327.299988'
});
data_peak.push({
lat: 3.4645444445e+01,
lng: 1.3364422222e+02,
cert : true,
content:'Name = JA/OY-120(JA/OY-120) peak = 383.500000 pos = 34.6454,133.6442 diff = 176.399994'
});
data_saddle.push({
lat: 3.4645000000e+01,
lng: 1.3363933333e+02,
content:'Saddle = 207.100006 pos = 34.6450,133.6393 diff = 176.399994'
});
data_peak.push({
lat: 3.4625777778e+01,
lng: 1.3355644444e+02,
cert : false,
content:' Peak = 252.600006 pos = 34.6258,133.5564 diff = 176.000000'
});
data_saddle.push({
lat: 3.4630777778e+01,
lng: 1.3354477778e+02,
content:'Saddle = 76.599998 pos = 34.6308,133.5448 diff = 176.000000'
});
data_peak.push({
lat: 3.4227333330e+01,
lng: 1.3257622222e+02,
cert : true,
content:'Name = JA/HS-172(JA/HS-172) peak = 495.700012 pos = 34.2273,132.5762 diff = 418.600006'
});
data_saddle.push({
lat: 3.4252555553e+01,
lng: 1.3258955556e+02,
content:'Saddle = 77.099998 pos = 34.2526,132.5896 diff = 418.600006'
});
data_peak.push({
lat: 3.4402999998e+01,
lng: 1.3305055556e+02,
cert : false,
content:' Peak = 255.699997 pos = 34.4030,133.0506 diff = 177.199997'
});
data_saddle.push({
lat: 3.4412888887e+01,
lng: 1.3304788889e+02,
content:'Saddle = 78.500000 pos = 34.4129,133.0479 diff = 177.199997'
});
data_peak.push({
lat: 3.4368333331e+01,
lng: 1.3307255556e+02,
cert : true,
content:'Name = JA/HS-193(JA/HS-193) peak = 443.500000 pos = 34.3683,133.0726 diff = 345.799988'
});
data_saddle.push({
lat: 3.4353222220e+01,
lng: 1.3298066667e+02,
content:'Saddle = 97.699997 pos = 34.3532,132.9807 diff = 345.799988'
});
data_peak.push({
lat: 3.4354444442e+01,
lng: 1.3299600000e+02,
cert : false,
content:' Peak = 348.000000 pos = 34.3544,132.9960 diff = 190.100006'
});
data_saddle.push({
lat: 3.4358666665e+01,
lng: 1.3303755556e+02,
content:'Saddle = 157.899994 pos = 34.3587,133.0376 diff = 190.100006'
});
data_peak.push({
lat: 3.4218888886e+01,
lng: 1.3220733333e+02,
cert : false,
content:' Peak = 250.600006 pos = 34.2189,132.2073 diff = 152.100006'
});
data_saddle.push({
lat: 3.4233222219e+01,
lng: 1.3220222222e+02,
content:'Saddle = 98.500000 pos = 34.2332,132.2022 diff = 152.100006'
});
data_peak.push({
lat: 3.4666555556e+01,
lng: 1.3343788889e+02,
cert : false,
content:' Peak = 454.399994 pos = 34.6666,133.4379 diff = 345.399994'
});
data_saddle.push({
lat: 3.4666555556e+01,
lng: 1.3340733333e+02,
content:'Saddle = 109.000000 pos = 34.6666,133.4073 diff = 345.399994'
});
data_peak.push({
lat: 3.4666666667e+01,
lng: 1.3356922222e+02,
cert : false,
content:' Peak = 454.399994 pos = 34.6667,133.5692 diff = 229.899994'
});
data_saddle.push({
lat: 3.4666666667e+01,
lng: 1.3347833333e+02,
content:'Saddle = 224.500000 pos = 34.6667,133.4783 diff = 229.899994'
});
data_peak.push({
lat: 3.4663666667e+01,
lng: 1.3351266667e+02,
cert : false,
content:' Peak = 449.100006 pos = 34.6637,133.5127 diff = 161.399994'
});
data_saddle.push({
lat: 3.4666555556e+01,
lng: 1.3355422222e+02,
content:'Saddle = 287.700012 pos = 34.6666,133.5542 diff = 161.399994'
});
data_peak.push({
lat: 3.4302555553e+01,
lng: 1.3276466667e+02,
cert : true,
content:'Name = JA/HS-211(JA/HS-211) peak = 384.700012 pos = 34.3026,132.7647 diff = 275.600006'
});
data_saddle.push({
lat: 3.4303666664e+01,
lng: 1.3275088889e+02,
content:'Saddle = 109.099998 pos = 34.3037,132.7509 diff = 275.600006'
});
data_peak.push({
lat: 3.4291555553e+01,
lng: 1.3274344444e+02,
cert : true,
content:'Name = JA/HS-219(JA/HS-219) peak = 301.700012 pos = 34.2916,132.7434 diff = 173.600006'
});
data_saddle.push({
lat: 3.4297222220e+01,
lng: 1.3275333333e+02,
content:'Saddle = 128.100006 pos = 34.2972,132.7533 diff = 173.600006'
});
data_peak.push({
lat: 3.4454111110e+01,
lng: 1.3243366667e+02,
cert : true,
content:'Name = JA/HS-175(JA/HS-175) peak = 487.700012 pos = 34.4541,132.4337 diff = 376.500000'
});
data_saddle.push({
lat: 3.4433111110e+01,
lng: 1.3239866667e+02,
content:'Saddle = 111.199997 pos = 34.4331,132.3987 diff = 376.500000'
});
data_peak.push({
lat: 3.4664888889e+01,
lng: 1.3340222222e+02,
cert : false,
content:' Peak = 386.700012 pos = 34.6649,133.4022 diff = 267.100006'
});
data_saddle.push({
lat: 3.4666555556e+01,
lng: 1.3337477778e+02,
content:'Saddle = 119.599998 pos = 34.6666,133.3748 diff = 267.100006'
});
data_peak.push({
lat: 3.4666222223e+01,
lng: 1.3339188889e+02,
cert : false,
content:' Peak = 381.899994 pos = 34.6662,133.3919 diff = 214.000000'
});
data_saddle.push({
lat: 3.4666000000e+01,
lng: 1.3339722222e+02,
content:'Saddle = 167.899994 pos = 34.6660,133.3972 diff = 214.000000'
});
data_peak.push({
lat: 3.4180666663e+01,
lng: 1.3212888889e+02,
cert : true,
content:'Name = JA/YG-151(JA/YG-151) peak = 322.500000 pos = 34.1807,132.1289 diff = 195.199997'
});
data_saddle.push({
lat: 3.4183666663e+01,
lng: 1.3214322222e+02,
content:'Saddle = 127.300003 pos = 34.1837,132.1432 diff = 195.199997'
});
data_peak.push({
lat: 3.4521222221e+01,
lng: 1.3247888889e+02,
cert : true,
content:'Name = JA/HS-180(JA/HS-180) peak = 470.500000 pos = 34.5212,132.4789 diff = 341.799988'
});
data_saddle.push({
lat: 3.4535333333e+01,
lng: 1.3247500000e+02,
content:'Saddle = 128.699997 pos = 34.5353,132.4750 diff = 341.799988'
});
data_peak.push({
lat: 3.4352444442e+01,
lng: 1.3296866667e+02,
cert : true,
content:'Name = JA/HS-212(JA/HS-212) peak = 381.399994 pos = 34.3524,132.9687 diff = 245.799988'
});
data_saddle.push({
lat: 3.4360444442e+01,
lng: 1.3294544444e+02,
content:'Saddle = 135.600006 pos = 34.3604,132.9454 diff = 245.799988'
});
data_peak.push({
lat: 3.4392777776e+01,
lng: 1.3312800000e+02,
cert : true,
content:'Name = JA/HS-201(JA/HS-201) peak = 429.000000 pos = 34.3928,133.1280 diff = 292.500000'
});
data_saddle.push({
lat: 3.4429333332e+01,
lng: 1.3312322222e+02,
content:'Saddle = 136.500000 pos = 34.4293,133.1232 diff = 292.500000'
});
data_peak.push({
lat: 3.4462999999e+01,
lng: 1.3254711111e+02,
cert : true,
content:'Name = JA/HS-204(JA/HS-204) peak = 412.100006 pos = 34.4630,132.5471 diff = 275.500000'
});
data_saddle.push({
lat: 3.4462111110e+01,
lng: 1.3253933333e+02,
content:'Saddle = 136.600006 pos = 34.4621,132.5393 diff = 275.500000'
});
data_peak.push({
lat: 3.4376444442e+01,
lng: 1.3291044444e+02,
cert : false,
content:' Peak = 402.700012 pos = 34.3764,132.9104 diff = 264.400024'
});
data_saddle.push({
lat: 3.4395111109e+01,
lng: 1.3290977778e+02,
content:'Saddle = 138.300003 pos = 34.3951,132.9098 diff = 264.400024'
});
data_peak.push({
lat: 3.4382888887e+01,
lng: 1.3254200000e+02,
cert : false,
content:' Peak = 344.500000 pos = 34.3829,132.5420 diff = 201.800003'
});
data_saddle.push({
lat: 3.4385444443e+01,
lng: 1.3253688889e+02,
content:'Saddle = 142.699997 pos = 34.3854,132.5369 diff = 201.800003'
});
data_peak.push({
lat: 3.4406444443e+01,
lng: 1.3293300000e+02,
cert : false,
content:' Peak = 326.299988 pos = 34.4064,132.9330 diff = 162.899994'
});
data_saddle.push({
lat: 3.4404111109e+01,
lng: 1.3291833333e+02,
content:'Saddle = 163.399994 pos = 34.4041,132.9183 diff = 162.899994'
});
data_peak.push({
lat: 3.4447111110e+01,
lng: 1.3252044444e+02,
cert : true,
content:'Name = JA/HS-179(JA/HS-179) peak = 482.200012 pos = 34.4471,132.5204 diff = 313.800018'
});
data_saddle.push({
lat: 3.4439555554e+01,
lng: 1.3253088889e+02,
content:'Saddle = 168.399994 pos = 34.4396,132.5309 diff = 313.800018'
});
data_peak.push({
lat: 3.4433222221e+01,
lng: 1.3250544444e+02,
cert : false,
content:' Peak = 373.399994 pos = 34.4332,132.5054 diff = 151.399994'
});
data_saddle.push({
lat: 3.4434222221e+01,
lng: 1.3251100000e+02,
content:'Saddle = 222.000000 pos = 34.4342,132.5110 diff = 151.399994'
});
data_peak.push({
lat: 3.4196999997e+01,
lng: 1.3211100000e+02,
cert : false,
content:' Peak = 521.400024 pos = 34.1970,132.1110 diff = 350.000031'
});
data_saddle.push({
lat: 3.4225333330e+01,
lng: 1.3210500000e+02,
content:'Saddle = 171.399994 pos = 34.2253,132.1050 diff = 350.000031'
});
data_peak.push({
lat: 3.4525666666e+01,
lng: 1.3252122222e+02,
cert : false,
content:' Peak = 338.000000 pos = 34.5257,132.5212 diff = 164.899994'
});
data_saddle.push({
lat: 3.4525888888e+01,
lng: 1.3252622222e+02,
content:'Saddle = 173.100006 pos = 34.5259,132.5262 diff = 164.899994'
});
data_peak.push({
lat: 3.4500888888e+01,
lng: 1.3327377778e+02,
cert : true,
content:'Name = JA/HS-206(JA/HS-206) peak = 400.899994 pos = 34.5009,133.2738 diff = 222.899994'
});
data_saddle.push({
lat: 3.4510888888e+01,
lng: 1.3323900000e+02,
content:'Saddle = 178.000000 pos = 34.5109,133.2390 diff = 222.899994'
});
data_peak.push({
lat: 3.4506333332e+01,
lng: 1.3330122222e+02,
cert : true,
content:'Name = JA/HS-208(JA/HS-208) peak = 397.799988 pos = 34.5063,133.3012 diff = 209.399994'
});
data_saddle.push({
lat: 3.4505444443e+01,
lng: 1.3328977778e+02,
content:'Saddle = 188.399994 pos = 34.5054,133.2898 diff = 209.399994'
});
data_peak.push({
lat: 3.4353888887e+01,
lng: 1.3288811111e+02,
cert : true,
content:'Name = JA/HS-188(JA/HS-188) peak = 453.600006 pos = 34.3539,132.8881 diff = 261.000000'
});
data_saddle.push({
lat: 3.4360555553e+01,
lng: 1.3287877778e+02,
content:'Saddle = 192.600006 pos = 34.3606,132.8788 diff = 261.000000'
});
data_peak.push({
lat: 3.4530666666e+01,
lng: 1.3245544444e+02,
cert : true,
content:'Name = JA/HS-163(JA/HS-163) peak = 524.099976 pos = 34.5307,132.4554 diff = 326.999969'
});
data_saddle.push({
lat: 3.4542999999e+01,
lng: 1.3245711111e+02,
content:'Saddle = 197.100006 pos = 34.5430,132.4571 diff = 326.999969'
});
data_peak.push({
lat: 3.4541888888e+01,
lng: 1.3243966667e+02,
cert : true,
content:'Name = JA/HS-199(JA/HS-199) peak = 432.200012 pos = 34.5419,132.4397 diff = 203.800018'
});
data_saddle.push({
lat: 3.4539333333e+01,
lng: 1.3244777778e+02,
content:'Saddle = 228.399994 pos = 34.5393,132.4478 diff = 203.800018'
});
data_peak.push({
lat: 3.4515444444e+01,
lng: 1.3241222222e+02,
cert : true,
content:'Name = JA/HS-200(JA/HS-200) peak = 425.100006 pos = 34.5154,132.4122 diff = 227.100006'
});
data_saddle.push({
lat: 3.4510888888e+01,
lng: 1.3241633333e+02,
content:'Saddle = 198.000000 pos = 34.5109,132.4163 diff = 227.100006'
});
data_peak.push({
lat: 3.4262444442e+01,
lng: 1.3266622222e+02,
cert : true,
content:'Name = Norosan (Zendanayama)(JA/HS-060) peak = 838.799988 pos = 34.2624,132.6662 diff = 632.299988'
});
data_saddle.push({
lat: 3.4307666664e+01,
lng: 1.3269711111e+02,
content:'Saddle = 206.500000 pos = 34.3077,132.6971 diff = 632.299988'
});
data_peak.push({
lat: 3.4566000000e+01,
lng: 1.3274600000e+02,
cert : true,
content:'Name = Takanosuzan(JA/HS-045) peak = 921.299988 pos = 34.5660,132.7460 diff = 707.099976'
});
data_saddle.push({
lat: 3.4622000000e+01,
lng: 1.3272155556e+02,
content:'Saddle = 214.199997 pos = 34.6220,132.7216 diff = 707.099976'
});
data_peak.push({
lat: 3.4279888886e+01,
lng: 1.3253055556e+02,
cert : false,
content:' Peak = 410.000000 pos = 34.2799,132.5306 diff = 192.899994'
});
data_saddle.push({
lat: 3.4293555553e+01,
lng: 1.3254366667e+02,
content:'Saddle = 217.100006 pos = 34.2936,132.5437 diff = 192.899994'
});
data_peak.push({
lat: 3.4265555553e+01,
lng: 1.3254688889e+02,
cert : false,
content:' Peak = 403.500000 pos = 34.2656,132.5469 diff = 186.000000'
});
data_saddle.push({
lat: 3.4273111108e+01,
lng: 1.3255044444e+02,
content:'Saddle = 217.500000 pos = 34.2731,132.5504 diff = 186.000000'
});
data_peak.push({
lat: 3.4373666665e+01,
lng: 1.3278600000e+02,
cert : true,
content:'Name = JA/HS-156(JA/HS-156) peak = 543.799988 pos = 34.3737,132.7860 diff = 326.699982'
});
data_saddle.push({
lat: 3.4438777776e+01,
lng: 1.3276233333e+02,
content:'Saddle = 217.100006 pos = 34.4388,132.7623 diff = 326.699982'
});
data_peak.push({
lat: 3.4312222220e+01,
lng: 1.3271000000e+02,
cert : false,
content:' Peak = 431.000000 pos = 34.3122,132.7100 diff = 212.399994'
});
data_saddle.push({
lat: 3.4316111109e+01,
lng: 1.3271611111e+02,
content:'Saddle = 218.600006 pos = 34.3161,132.7161 diff = 212.399994'
});
data_peak.push({
lat: 3.4459999999e+01,
lng: 1.3287433333e+02,
cert : true,
content:'Name = JA/HS-166(JA/HS-166) peak = 521.900024 pos = 34.4600,132.8743 diff = 276.100037'
});
data_saddle.push({
lat: 3.4420888887e+01,
lng: 1.3284877778e+02,
content:'Saddle = 245.800003 pos = 34.4209,132.8488 diff = 276.100037'
});
data_peak.push({
lat: 3.4427333332e+01,
lng: 1.3278455556e+02,
cert : false,
content:' Peak = 523.099976 pos = 34.4273,132.7846 diff = 255.099976'
});
data_saddle.push({
lat: 3.4400222220e+01,
lng: 1.3280155556e+02,
content:'Saddle = 268.000000 pos = 34.4002,132.8016 diff = 255.099976'
});
data_peak.push({
lat: 3.4351333331e+01,
lng: 1.3287066667e+02,
cert : false,
content:' Peak = 480.399994 pos = 34.3513,132.8707 diff = 166.899994'
});
data_saddle.push({
lat: 3.4351333331e+01,
lng: 1.3285700000e+02,
content:'Saddle = 313.500000 pos = 34.3513,132.8570 diff = 166.899994'
});
data_peak.push({
lat: 3.4326333331e+01,
lng: 1.3273766667e+02,
cert : false,
content:' Peak = 510.000000 pos = 34.3263,132.7377 diff = 153.200012'
});
data_saddle.push({
lat: 3.4338888887e+01,
lng: 1.3274288889e+02,
content:'Saddle = 356.799988 pos = 34.3389,132.7429 diff = 153.200012'
});
data_peak.push({
lat: 3.4344666664e+01,
lng: 1.3276166667e+02,
cert : false,
content:' Peak = 542.799988 pos = 34.3447,132.7617 diff = 155.599976'
});
data_saddle.push({
lat: 3.4350444442e+01,
lng: 1.3276600000e+02,
content:'Saddle = 387.200012 pos = 34.3504,132.7660 diff = 155.599976'
});
data_peak.push({
lat: 3.4552999999e+01,
lng: 1.3321977778e+02,
cert : false,
content:' Peak = 400.299988 pos = 34.5530,133.2198 diff = 173.999985'
});
data_saddle.push({
lat: 3.4509333332e+01,
lng: 1.3319722222e+02,
content:'Saddle = 226.300003 pos = 34.5093,133.1972 diff = 173.999985'
});
data_peak.push({
lat: 3.4491666666e+01,
lng: 1.3319633333e+02,
cert : false,
content:' Peak = 382.600006 pos = 34.4917,133.1963 diff = 155.800003'
});
data_saddle.push({
lat: 3.4489777777e+01,
lng: 1.3315788889e+02,
content:'Saddle = 226.800003 pos = 34.4898,133.1579 diff = 155.800003'
});
data_peak.push({
lat: 3.4311222220e+01,
lng: 1.3263622222e+02,
cert : true,
content:'Name = JA/HS-203(JA/HS-203) peak = 422.100006 pos = 34.3112,132.6362 diff = 194.100006'
});
data_saddle.push({
lat: 3.4317999998e+01,
lng: 1.3262800000e+02,
content:'Saddle = 228.000000 pos = 34.3180,132.6280 diff = 194.100006'
});
data_peak.push({
lat: 3.4391555554e+01,
lng: 1.3259844444e+02,
cert : true,
content:'Name = JA/HS-102(JA/HS-102) peak = 711.299988 pos = 34.3916,132.5984 diff = 483.199982'
});
data_saddle.push({
lat: 3.4344111109e+01,
lng: 1.3258822222e+02,
content:'Saddle = 228.100006 pos = 34.3441,132.5882 diff = 483.199982'
});
data_peak.push({
lat: 3.4319111109e+01,
lng: 1.3253966667e+02,
cert : true,
content:'Name = JA/HS-141(JA/HS-141) peak = 592.200012 pos = 34.3191,132.5397 diff = 323.700012'
});
data_saddle.push({
lat: 3.4328777775e+01,
lng: 1.3255366667e+02,
content:'Saddle = 268.500000 pos = 34.3288,132.5537 diff = 323.700012'
});
data_peak.push({
lat: 3.4324777775e+01,
lng: 1.3255588889e+02,
cert : false,
content:' Peak = 431.899994 pos = 34.3248,132.5559 diff = 153.500000'
});
data_saddle.push({
lat: 3.4321444442e+01,
lng: 1.3255066667e+02,
content:'Saddle = 278.399994 pos = 34.3214,132.5507 diff = 153.500000'
});
data_peak.push({
lat: 3.4270111108e+01,
lng: 1.3259333333e+02,
cert : true,
content:'Name = JA/HS-091(JA/HS-091) peak = 735.700012 pos = 34.2701,132.5933 diff = 476.800018'
});
data_saddle.push({
lat: 3.4444666665e+01,
lng: 1.3268588889e+02,
content:'Saddle = 258.899994 pos = 34.4447,132.6859 diff = 476.800018'
});
data_peak.push({
lat: 3.4315888886e+01,
lng: 1.3258066667e+02,
cert : false,
content:' Peak = 451.000000 pos = 34.3159,132.5807 diff = 162.600006'
});
data_saddle.push({
lat: 3.4290444442e+01,
lng: 1.3258655556e+02,
content:'Saddle = 288.399994 pos = 34.2904,132.5866 diff = 162.600006'
});
data_peak.push({
lat: 3.4351888887e+01,
lng: 1.3264122222e+02,
cert : true,
content:'Name = JA/HS-098(JA/HS-098) peak = 718.599976 pos = 34.3519,132.6412 diff = 421.199982'
});
data_saddle.push({
lat: 3.4296999997e+01,
lng: 1.3259677778e+02,
content:'Saddle = 297.399994 pos = 34.2970,132.5968 diff = 421.199982'
});
data_peak.push({
lat: 3.4310111109e+01,
lng: 1.3259088889e+02,
cert : false,
content:' Peak = 472.799988 pos = 34.3101,132.5909 diff = 154.399994'
});
data_saddle.push({
lat: 3.4306444442e+01,
lng: 1.3259888889e+02,
content:'Saddle = 318.399994 pos = 34.3064,132.5989 diff = 154.399994'
});
data_peak.push({
lat: 3.4413777776e+01,
lng: 1.3264666667e+02,
cert : true,
content:'Name = JA/HS-119(JA/HS-119) peak = 660.099976 pos = 34.4138,132.6467 diff = 332.299988'
});
data_saddle.push({
lat: 3.4387888887e+01,
lng: 1.3264544444e+02,
content:'Saddle = 327.799988 pos = 34.3879,132.6454 diff = 332.299988'
});
data_peak.push({
lat: 3.4398777776e+01,
lng: 1.3265533333e+02,
cert : false,
content:' Peak = 487.100006 pos = 34.3988,132.6553 diff = 155.500000'
});
data_saddle.push({
lat: 3.4397444443e+01,
lng: 1.3264333333e+02,
content:'Saddle = 331.600006 pos = 34.3974,132.6433 diff = 155.500000'
});
data_peak.push({
lat: 3.4328444442e+01,
lng: 1.3261333333e+02,
cert : false,
content:' Peak = 562.500000 pos = 34.3284,132.6133 diff = 205.000000'
});
data_saddle.push({
lat: 3.4347777776e+01,
lng: 1.3261544444e+02,
content:'Saddle = 357.500000 pos = 34.3478,132.6154 diff = 205.000000'
});
data_peak.push({
lat: 3.4490999999e+01,
lng: 1.3261211111e+02,
cert : true,
content:'Name = JA/HS-083(JA/HS-083) peak = 760.900024 pos = 34.4910,132.6121 diff = 500.300018'
});
data_saddle.push({
lat: 3.4459555554e+01,
lng: 1.3265100000e+02,
content:'Saddle = 260.600006 pos = 34.4596,132.6510 diff = 500.300018'
});
data_peak.push({
lat: 3.4448333332e+01,
lng: 1.3261244444e+02,
cert : true,
content:'Name = JA/HS-167(JA/HS-167) peak = 512.700012 pos = 34.4483,132.6124 diff = 203.600006'
});
data_saddle.push({
lat: 3.4454222221e+01,
lng: 1.3261066667e+02,
content:'Saddle = 309.100006 pos = 34.4542,132.6107 diff = 203.600006'
});
data_peak.push({
lat: 3.4422888887e+01,
lng: 1.3254777778e+02,
cert : true,
content:'Name = Gosasouzan(JA/HS-114) peak = 680.200012 pos = 34.4229,132.5478 diff = 302.100006'
});
data_saddle.push({
lat: 3.4477666665e+01,
lng: 1.3260577778e+02,
content:'Saddle = 378.100006 pos = 34.4777,132.6058 diff = 302.100006'
});
data_peak.push({
lat: 3.4455999999e+01,
lng: 1.3259844444e+02,
cert : true,
content:'Name = JA/HS-135(JA/HS-135) peak = 612.400024 pos = 34.4560,132.5984 diff = 190.600037'
});
data_saddle.push({
lat: 3.4443111110e+01,
lng: 1.3257800000e+02,
content:'Saddle = 421.799988 pos = 34.4431,132.5780 diff = 190.600037'
});
data_peak.push({
lat: 3.4507111110e+01,
lng: 1.3263355556e+02,
cert : false,
content:' Peak = 734.000000 pos = 34.5071,132.6336 diff = 171.599976'
});
data_saddle.push({
lat: 3.4501999999e+01,
lng: 1.3263011111e+02,
content:'Saddle = 562.400024 pos = 34.5020,132.6301 diff = 171.599976'
});
data_peak.push({
lat: 3.4488888888e+01,
lng: 1.3266400000e+02,
cert : true,
content:'Name = JA/HS-178(JA/HS-178) peak = 483.100006 pos = 34.4889,132.6640 diff = 214.800018'
});
data_saddle.push({
lat: 3.4465999999e+01,
lng: 1.3266900000e+02,
content:'Saddle = 268.299988 pos = 34.4660,132.6690 diff = 214.800018'
});
data_peak.push({
lat: 3.4649000000e+01,
lng: 1.3315666667e+02,
cert : true,
content:'Name = Dakeyama(JA/HS-088) peak = 740.400024 pos = 34.6490,133.1567 diff = 433.700012'
});
data_saddle.push({
lat: 3.4666666667e+01,
lng: 1.3312744444e+02,
content:'Saddle = 306.700012 pos = 34.6667,133.1274 diff = 433.700012'
});
data_peak.push({
lat: 3.4666666667e+01,
lng: 1.3319866667e+02,
cert : false,
content:' Peak = 668.900024 pos = 34.6667,133.1987 diff = 279.200012'
});
data_saddle.push({
lat: 3.4666666667e+01,
lng: 1.3316522222e+02,
content:'Saddle = 389.700012 pos = 34.6667,133.1652 diff = 279.200012'
});
data_peak.push({
lat: 3.4621444444e+01,
lng: 1.3321622222e+02,
cert : false,
content:' Peak = 563.700012 pos = 34.6214,133.2162 diff = 154.600006'
});
data_saddle.push({
lat: 3.4629666667e+01,
lng: 1.3322588889e+02,
content:'Saddle = 409.100006 pos = 34.6297,133.2259 diff = 154.600006'
});
data_peak.push({
lat: 3.4656777778e+01,
lng: 1.3326822222e+02,
cert : false,
content:' Peak = 610.400024 pos = 34.6568,133.2682 diff = 183.600037'
});
data_saddle.push({
lat: 3.4666666667e+01,
lng: 1.3326433333e+02,
content:'Saddle = 426.799988 pos = 34.6667,133.2643 diff = 183.600037'
});
data_peak.push({
lat: 3.4666666667e+01,
lng: 1.3323455556e+02,
cert : false,
content:' Peak = 662.500000 pos = 34.6667,133.2346 diff = 205.600006'
});
data_saddle.push({
lat: 3.4666666667e+01,
lng: 1.3322211111e+02,
content:'Saddle = 456.899994 pos = 34.6667,133.2221 diff = 205.600006'
});
data_peak.push({
lat: 3.4639666667e+01,
lng: 1.3314200000e+02,
cert : false,
content:' Peak = 636.099976 pos = 34.6397,133.1420 diff = 158.599976'
});
data_saddle.push({
lat: 3.4638777778e+01,
lng: 1.3315466667e+02,
content:'Saddle = 477.500000 pos = 34.6388,133.1547 diff = 158.599976'
});
data_peak.push({
lat: 3.4487333332e+01,
lng: 1.3288444444e+02,
cert : true,
content:'Name = JA/HS-147(JA/HS-147) peak = 572.900024 pos = 34.4873,132.8844 diff = 253.900024'
});
data_saddle.push({
lat: 3.4501999999e+01,
lng: 1.3285366667e+02,
content:'Saddle = 319.000000 pos = 34.5020,132.8537 diff = 253.900024'
});
data_peak.push({
lat: 3.4455777776e+01,
lng: 1.3308333333e+02,
cert : true,
content:'Name = Ryuuousan(JA/HS-116) peak = 664.299988 pos = 34.4558,133.0833 diff = 345.299988'
});
data_saddle.push({
lat: 3.4462999999e+01,
lng: 1.3304577778e+02,
content:'Saddle = 319.000000 pos = 34.4630,133.0458 diff = 345.299988'
});
data_peak.push({
lat: 3.4453444443e+01,
lng: 1.3304933333e+02,
cert : true,
content:'Name = JA/HS-136(JA/HS-136) peak = 610.200012 pos = 34.4534,133.0493 diff = 243.800018'
});
data_saddle.push({
lat: 3.4447222221e+01,
lng: 1.3307155556e+02,
content:'Saddle = 366.399994 pos = 34.4472,133.0716 diff = 243.800018'
});
data_peak.push({
lat: 3.4578444444e+01,
lng: 1.3314744444e+02,
cert : true,
content:'Name = JA/HS-152(JA/HS-152) peak = 560.099976 pos = 34.5784,133.1474 diff = 233.299988'
});
data_saddle.push({
lat: 3.4557555555e+01,
lng: 1.3312822222e+02,
content:'Saddle = 326.799988 pos = 34.5576,133.1282 diff = 233.299988'
});
data_peak.push({
lat: 3.4565444444e+01,
lng: 1.3316477778e+02,
cert : false,
content:' Peak = 547.099976 pos = 34.5654,133.1648 diff = 150.199982'
});
data_saddle.push({
lat: 3.4563222222e+01,
lng: 1.3314277778e+02,
content:'Saddle = 396.899994 pos = 34.5632,133.1428 diff = 150.199982'
});
data_peak.push({
lat: 3.4574888888e+01,
lng: 1.3268855556e+02,
cert : true,
content:'Name = JA/HS-150(JA/HS-150) peak = 561.200012 pos = 34.5749,132.6886 diff = 232.800018'
});
data_saddle.push({
lat: 3.4565888888e+01,
lng: 1.3269022222e+02,
content:'Saddle = 328.399994 pos = 34.5659,132.6902 diff = 232.800018'
});
data_peak.push({
lat: 3.4493888888e+01,
lng: 1.3292255556e+02,
cert : true,
content:'Name = JA/HS-162(JA/HS-162) peak = 524.900024 pos = 34.4939,132.9226 diff = 191.600037'
});
data_saddle.push({
lat: 3.4484111110e+01,
lng: 1.3297544444e+02,
content:'Saddle = 333.299988 pos = 34.4841,132.9754 diff = 191.600037'
});
data_peak.push({
lat: 3.4602555555e+01,
lng: 1.3310177778e+02,
cert : true,
content:'Name = JA/HS-158(JA/HS-158) peak = 540.299988 pos = 34.6026,133.1018 diff = 192.199982'
});
data_saddle.push({
lat: 3.4607222222e+01,
lng: 1.3308855556e+02,
content:'Saddle = 348.100006 pos = 34.6072,133.0886 diff = 192.199982'
});
data_peak.push({
lat: 3.4457222221e+01,
lng: 1.3274177778e+02,
cert : true,
content:'Name = JA/HS-146(JA/HS-146) peak = 572.099976 pos = 34.4572,132.7418 diff = 222.399963'
});
data_saddle.push({
lat: 3.4479888888e+01,
lng: 1.3273977778e+02,
content:'Saddle = 349.700012 pos = 34.4799,132.7398 diff = 222.399963'
});
data_peak.push({
lat: 3.4474111110e+01,
lng: 1.3277266667e+02,
cert : true,
content:'Name = JA/HS-161(JA/HS-161) peak = 530.000000 pos = 34.4741,132.7727 diff = 175.000000'
});
data_saddle.push({
lat: 3.4473555554e+01,
lng: 1.3276455556e+02,
content:'Saddle = 355.000000 pos = 34.4736,132.7646 diff = 175.000000'
});
data_peak.push({
lat: 3.4480333332e+01,
lng: 1.3284500000e+02,
cert : false,
content:' Peak = 517.799988 pos = 34.4803,132.8450 diff = 150.299988'
});
data_saddle.push({
lat: 3.4484666666e+01,
lng: 1.3281188889e+02,
content:'Saddle = 367.500000 pos = 34.4847,132.8119 diff = 150.299988'
});
data_peak.push({
lat: 3.4583666666e+01,
lng: 1.3311077778e+02,
cert : true,
content:'Name = JA/HS-144(JA/HS-144) peak = 584.500000 pos = 34.5837,133.1108 diff = 223.500000'
});
data_saddle.push({
lat: 3.4577111111e+01,
lng: 1.3310277778e+02,
content:'Saddle = 361.000000 pos = 34.5771,133.1028 diff = 223.500000'
});
data_peak.push({
lat: 3.4551333333e+01,
lng: 1.3307344444e+02,
cert : true,
content:'Name = JA/HS-107(JA/HS-107) peak = 697.799988 pos = 34.5513,133.0734 diff = 319.899994'
});
data_saddle.push({
lat: 3.4568666666e+01,
lng: 1.3296733333e+02,
content:'Saddle = 377.899994 pos = 34.5687,132.9673 diff = 319.899994'
});
data_peak.push({
lat: 3.4552666666e+01,
lng: 1.3299266667e+02,
cert : true,
content:'Name = JA/HS-148(JA/HS-148) peak = 570.900024 pos = 34.5527,132.9927 diff = 182.200012'
});
data_saddle.push({
lat: 3.4547666666e+01,
lng: 1.3301988889e+02,
content:'Saddle = 388.700012 pos = 34.5477,133.0199 diff = 182.200012'
});
data_peak.push({
lat: 3.4548666666e+01,
lng: 1.3282566667e+02,
cert : true,
content:'Name = JA/HS-084(JA/HS-084) peak = 755.500000 pos = 34.5487,132.8257 diff = 370.399994'
});
data_saddle.push({
lat: 3.4557555555e+01,
lng: 1.3279588889e+02,
content:'Saddle = 385.100006 pos = 34.5576,132.7959 diff = 370.399994'
});
data_peak.push({
lat: 3.4516999999e+01,
lng: 1.3287066667e+02,
cert : false,
content:' Peak = 619.599976 pos = 34.5170,132.8707 diff = 201.999969'
});
data_saddle.push({
lat: 3.4536666666e+01,
lng: 1.3282088889e+02,
content:'Saddle = 417.600006 pos = 34.5367,132.8209 diff = 201.999969'
});
data_peak.push({
lat: 3.4602111111e+01,
lng: 1.3306222222e+02,
cert : false,
content:' Peak = 635.099976 pos = 34.6021,133.0622 diff = 229.399963'
});
data_saddle.push({
lat: 3.4591111111e+01,
lng: 1.3295933333e+02,
content:'Saddle = 405.700012 pos = 34.5911,132.9593 diff = 229.399963'
});
data_peak.push({
lat: 3.4657555556e+01,
lng: 1.3308388889e+02,
cert : true,
content:'Name = JA/HS-128(JA/HS-128) peak = 633.599976 pos = 34.6576,133.0839 diff = 184.999969'
});
data_saddle.push({
lat: 3.4654666667e+01,
lng: 1.3306333333e+02,
content:'Saddle = 448.600006 pos = 34.6547,133.0633 diff = 184.999969'
});
data_peak.push({
lat: 3.4639000000e+01,
lng: 1.3278066667e+02,
cert : true,
content:'Name = JA/HS-072(JA/HS-072) peak = 800.000000 pos = 34.6390,132.7807 diff = 391.600006'
});
data_saddle.push({
lat: 3.4581888889e+01,
lng: 1.3279388889e+02,
content:'Saddle = 408.399994 pos = 34.5819,132.7939 diff = 391.600006'
});
data_peak.push({
lat: 3.4585333333e+01,
lng: 1.3285777778e+02,
cert : true,
content:'Name = JA/HS-085(JA/HS-085) peak = 757.299988 pos = 34.5853,132.8578 diff = 334.000000'
});
data_saddle.push({
lat: 3.4602000000e+01,
lng: 1.3282122222e+02,
content:'Saddle = 423.299988 pos = 34.6020,132.8212 diff = 334.000000'
});
data_peak.push({
lat: 3.4579333333e+01,
lng: 1.3287777778e+02,
cert : true,
content:'Name = JA/HS-115(JA/HS-115) peak = 664.700012 pos = 34.5793,132.8778 diff = 156.700012'
});
data_saddle.push({
lat: 3.4576222222e+01,
lng: 1.3287355556e+02,
content:'Saddle = 508.000000 pos = 34.5762,132.8736 diff = 156.700012'
});
data_peak.push({
lat: 3.4473999999e+01,
lng: 1.3271066667e+02,
cert : true,
content:'Name = JA/HS-130(JA/HS-130) peak = 631.500000 pos = 34.4740,132.7107 diff = 214.100006'
});
data_saddle.push({
lat: 3.4482111110e+01,
lng: 1.3270433333e+02,
content:'Saddle = 417.399994 pos = 34.4821,132.7043 diff = 214.100006'
});
data_peak.push({
lat: 3.4508888888e+01,
lng: 1.3271844444e+02,
cert : true,
content:'Name = JA/HS-094(JA/HS-094) peak = 730.900024 pos = 34.5089,132.7184 diff = 263.400024'
});
data_saddle.push({
lat: 3.4512666666e+01,
lng: 1.3270488889e+02,
content:'Saddle = 467.500000 pos = 34.5127,132.7049 diff = 263.400024'
});
data_peak.push({
lat: 3.4523555555e+01,
lng: 1.3268522222e+02,
cert : true,
content:'Name = JA/HS-090(JA/HS-090) peak = 740.500000 pos = 34.5236,132.6852 diff = 195.299988'
});
data_saddle.push({
lat: 3.4553666666e+01,
lng: 1.3271311111e+02,
content:'Saddle = 545.200012 pos = 34.5537,132.7131 diff = 195.299988'
});
data_peak.push({
lat: 3.4566666666e+01,
lng: 1.3278444444e+02,
cert : true,
content:'Name = JA/HS-092(JA/HS-092) peak = 733.099976 pos = 34.5667,132.7844 diff = 170.899963'
});
data_saddle.push({
lat: 3.4560888888e+01,
lng: 1.3277644444e+02,
content:'Saddle = 562.200012 pos = 34.5609,132.7764 diff = 170.899963'
});
data_peak.push({
lat: 3.4574444444e+01,
lng: 1.3275833333e+02,
cert : false,
content:' Peak = 891.299988 pos = 34.5744,132.7583 diff = 164.899963'
});
data_saddle.push({
lat: 3.4572000000e+01,
lng: 1.3274988889e+02,
content:'Saddle = 726.400024 pos = 34.5720,132.7499 diff = 164.899963'
});
data_peak.push({
lat: 3.4492999999e+01,
lng: 1.3248700000e+02,
cert : true,
content:'Name = JA/HS-142(JA/HS-142) peak = 585.599976 pos = 34.4930,132.4870 diff = 367.999969'
});
data_saddle.push({
lat: 3.4495888888e+01,
lng: 1.3244211111e+02,
content:'Saddle = 217.600006 pos = 34.4959,132.4421 diff = 367.999969'
});
data_peak.push({
lat: 3.4498111110e+01,
lng: 1.3245277778e+02,
cert : false,
content:' Peak = 450.500000 pos = 34.4981,132.4528 diff = 224.300003'
});
data_saddle.push({
lat: 3.4489888888e+01,
lng: 1.3245933333e+02,
content:'Saddle = 226.199997 pos = 34.4899,132.4593 diff = 224.300003'
});
data_peak.push({
lat: 3.4504777777e+01,
lng: 1.3246377778e+02,
cert : false,
content:' Peak = 421.200012 pos = 34.5048,132.4638 diff = 173.900009'
});
data_saddle.push({
lat: 3.4502666666e+01,
lng: 1.3245988889e+02,
content:'Saddle = 247.300003 pos = 34.5027,132.4599 diff = 173.900009'
});
data_peak.push({
lat: 3.4493777777e+01,
lng: 1.3242322222e+02,
cert : true,
content:'Name = JA/HS-129(JA/HS-129) peak = 631.000000 pos = 34.4938,132.4232 diff = 413.399994'
});
data_saddle.push({
lat: 3.4490333332e+01,
lng: 1.3239777778e+02,
content:'Saddle = 217.600006 pos = 34.4903,132.3978 diff = 413.399994'
});
data_peak.push({
lat: 3.4514222221e+01,
lng: 1.3244600000e+02,
cert : true,
content:'Name = JA/HS-176(JA/HS-176) peak = 487.000000 pos = 34.5142,132.4460 diff = 256.299988'
});
data_saddle.push({
lat: 3.4508333332e+01,
lng: 1.3243800000e+02,
content:'Saddle = 230.699997 pos = 34.5083,132.4380 diff = 256.299988'
});
data_peak.push({
lat: 3.4580333333e+01,
lng: 1.3232955556e+02,
cert : true,
content:'Name = JA/HS-192(JA/HS-192) peak = 441.700012 pos = 34.5803,132.3296 diff = 202.800018'
});
data_saddle.push({
lat: 3.4581333333e+01,
lng: 1.3233366667e+02,
content:'Saddle = 238.899994 pos = 34.5813,132.3337 diff = 202.800018'
});
data_peak.push({
lat: 3.4542333333e+01,
lng: 1.3249122222e+02,
cert : true,
content:'Name = JA/HS-171(JA/HS-171) peak = 501.200012 pos = 34.5423,132.4912 diff = 244.300018'
});
data_saddle.push({
lat: 3.4552111111e+01,
lng: 1.3249333333e+02,
content:'Saddle = 256.899994 pos = 34.5521,132.4933 diff = 244.300018'
});
data_peak.push({
lat: 3.4287111108e+01,
lng: 1.3224355556e+02,
cert : true,
content:'Name = JA/HS-139(JA/HS-139) peak = 595.799988 pos = 34.2871,132.2436 diff = 337.899994'
});
data_saddle.push({
lat: 3.4300666664e+01,
lng: 1.3223355556e+02,
content:'Saddle = 257.899994 pos = 34.3007,132.2336 diff = 337.899994'
});
data_peak.push({
lat: 3.4521333333e+01,
lng: 1.3257544444e+02,
cert : true,
content:'Name = Shirakiyama(JA/HS-052) peak = 888.200012 pos = 34.5213,132.5754 diff = 618.700012'
});
data_saddle.push({
lat: 3.4593000000e+01,
lng: 1.3258555556e+02,
content:'Saddle = 269.500000 pos = 34.5930,132.5856 diff = 618.700012'
});
data_peak.push({
lat: 3.4599111111e+01,
lng: 1.3266577778e+02,
cert : false,
content:' Peak = 620.099976 pos = 34.5991,132.6658 diff = 252.099976'
});
data_saddle.push({
lat: 3.4564666666e+01,
lng: 1.3258677778e+02,
content:'Saddle = 368.000000 pos = 34.5647,132.5868 diff = 252.099976'
});
data_peak.push({
lat: 3.4583333333e+01,
lng: 1.3259277778e+02,
cert : true,
content:'Name = JA/HS-149(JA/HS-149) peak = 563.799988 pos = 34.5833,132.5928 diff = 167.699982'
});
data_saddle.push({
lat: 3.4584777777e+01,
lng: 1.3260211111e+02,
content:'Saddle = 396.100006 pos = 34.5848,132.6021 diff = 167.699982'
});
data_peak.push({
lat: 3.4566555555e+01,
lng: 1.3263411111e+02,
cert : true,
content:'Name = JA/HS-131(JA/HS-131) peak = 628.299988 pos = 34.5666,132.6341 diff = 187.599976'
});
data_saddle.push({
lat: 3.4558999999e+01,
lng: 1.3262488889e+02,
content:'Saddle = 440.700012 pos = 34.5590,132.6249 diff = 187.599976'
});
data_peak.push({
lat: 3.4282444442e+01,
lng: 1.3220722222e+02,
cert : false,
content:' Peak = 647.700012 pos = 34.2824,132.2072 diff = 344.800018'
});
data_saddle.push({
lat: 3.4310888886e+01,
lng: 1.3222022222e+02,
content:'Saddle = 302.899994 pos = 34.3109,132.2202 diff = 344.800018'
});
data_peak.push({
lat: 3.4309666664e+01,
lng: 1.3220888889e+02,
cert : true,
content:'Name = JA/HS-154(JA/HS-154) peak = 554.599976 pos = 34.3097,132.2089 diff = 212.099976'
});
data_saddle.push({
lat: 3.4300111109e+01,
lng: 1.3220655556e+02,
content:'Saddle = 342.500000 pos = 34.3001,132.2066 diff = 212.099976'
});
data_peak.push({
lat: 3.4263999997e+01,
lng: 1.3216544444e+02,
cert : false,
content:' Peak = 607.599976 pos = 34.2640,132.1654 diff = 151.299988'
});
data_saddle.push({
lat: 3.4284444442e+01,
lng: 1.3219811111e+02,
content:'Saddle = 456.299988 pos = 34.2844,132.1981 diff = 151.299988'
});
data_peak.push({
lat: 3.4317111109e+01,
lng: 1.3214800000e+02,
cert : true,
content:'Name = Mikuradake(JA/HS-106) peak = 701.400024 pos = 34.3171,132.1480 diff = 396.400024'
});
data_saddle.push({
lat: 3.4364666665e+01,
lng: 1.3219266667e+02,
content:'Saddle = 305.000000 pos = 34.3647,132.1927 diff = 396.400024'
});
data_peak.push({
lat: 3.4331111109e+01,
lng: 1.3220433333e+02,
cert : false,
content:' Peak = 470.799988 pos = 34.3311,132.2043 diff = 162.899994'
});
data_saddle.push({
lat: 3.4339999998e+01,
lng: 1.3220522222e+02,
content:'Saddle = 307.899994 pos = 34.3400,132.2052 diff = 162.899994'
});
data_peak.push({
lat: 3.4348333331e+01,
lng: 1.3218600000e+02,
cert : true,
content:'Name = JA/HS-113(JA/HS-113) peak = 682.900024 pos = 34.3483,132.1860 diff = 240.700012'
});
data_saddle.push({
lat: 3.4329222220e+01,
lng: 1.3216088889e+02,
content:'Saddle = 442.200012 pos = 34.3292,132.1609 diff = 240.700012'
});
data_peak.push({
lat: 3.4342666664e+01,
lng: 1.3223777778e+02,
cert : true,
content:'Name = JA/HS-108(JA/HS-108) peak = 697.599976 pos = 34.3427,132.2378 diff = 359.499969'
});
data_saddle.push({
lat: 3.4355666665e+01,
lng: 1.3225444444e+02,
content:'Saddle = 338.100006 pos = 34.3557,132.2544 diff = 359.499969'
});
data_peak.push({
lat: 3.4555333333e+01,
lng: 1.3246277778e+02,
cert : false,
content:' Peak = 503.200012 pos = 34.5553,132.4628 diff = 154.900024'
});
data_saddle.push({
lat: 3.4561555555e+01,
lng: 1.3246500000e+02,
content:'Saddle = 348.299988 pos = 34.5616,132.4650 diff = 154.900024'
});
data_peak.push({
lat: 3.4271222219e+01,
lng: 1.3205844444e+02,
cert : true,
content:'Name = JA/YG-076(JA/YG-076) peak = 542.599976 pos = 34.2712,132.0584 diff = 184.299988'
});
data_saddle.push({
lat: 3.4276222219e+01,
lng: 1.3205311111e+02,
content:'Saddle = 358.299988 pos = 34.2762,132.0531 diff = 184.299988'
});
data_peak.push({
lat: 3.4245888886e+01,
lng: 1.3204655556e+02,
cert : false,
content:' Peak = 530.700012 pos = 34.2459,132.0466 diff = 153.600006'
});
data_saddle.push({
lat: 3.4257888886e+01,
lng: 1.3204977778e+02,
content:'Saddle = 377.100006 pos = 34.2579,132.0498 diff = 153.600006'
});
data_peak.push({
lat: 3.4665333334e+01,
lng: 1.3243266667e+02,
cert : true,
content:'Name = Ryūzuyama(JA/HS-043) peak = 922.000000 pos = 34.6653,132.4327 diff = 555.700012'
});
data_saddle.push({
lat: 3.4666666667e+01,
lng: 1.3240788889e+02,
content:'Saddle = 366.299988 pos = 34.6667,132.4079 diff = 555.700012'
});
data_peak.push({
lat: 3.4570333333e+01,
lng: 1.3242322222e+02,
cert : true,
content:'Name = JA/HS-112(JA/HS-112) peak = 686.000000 pos = 34.5703,132.4232 diff = 309.299988'
});
data_saddle.push({
lat: 3.4605444444e+01,
lng: 1.3244800000e+02,
content:'Saddle = 376.700012 pos = 34.6054,132.4480 diff = 309.299988'
});
data_peak.push({
lat: 3.4547555555e+01,
lng: 1.3241800000e+02,
cert : false,
content:' Peak = 571.599976 pos = 34.5476,132.4180 diff = 159.399963'
});
data_saddle.push({
lat: 3.4549888888e+01,
lng: 1.3242477778e+02,
content:'Saddle = 412.200012 pos = 34.5499,132.4248 diff = 159.399963'
});
data_peak.push({
lat: 3.4582222222e+01,
lng: 1.3239644444e+02,
cert : true,
content:'Name = JA/HS-110(JA/HS-110) peak = 691.200012 pos = 34.5822,132.3964 diff = 313.200012'
});
data_saddle.push({
lat: 3.4617555555e+01,
lng: 1.3244355556e+02,
content:'Saddle = 378.000000 pos = 34.6176,132.4436 diff = 313.200012'
});
data_peak.push({
lat: 3.4578333333e+01,
lng: 1.3249511111e+02,
cert : true,
content:'Name = JA/HS-054(JA/HS-054) peak = 859.099976 pos = 34.5783,132.4951 diff = 430.899963'
});
data_saddle.push({
lat: 3.4602666666e+01,
lng: 1.3249511111e+02,
content:'Saddle = 428.200012 pos = 34.6027,132.4951 diff = 430.899963'
});
data_peak.push({
lat: 3.4623555556e+01,
lng: 1.3257511111e+02,
cert : true,
content:'Name = JA/HS-089(JA/HS-089) peak = 739.200012 pos = 34.6236,132.5751 diff = 271.200012'
});
data_saddle.push({
lat: 3.4611666667e+01,
lng: 1.3255944444e+02,
content:'Saddle = 468.000000 pos = 34.6117,132.5594 diff = 271.200012'
});
data_peak.push({
lat: 3.4581888889e+01,
lng: 1.3253744444e+02,
cert : true,
content:'Name = JA/HS-076(JA/HS-076) peak = 788.299988 pos = 34.5819,132.5374 diff = 180.700012'
});
data_saddle.push({
lat: 3.4594555555e+01,
lng: 1.3253055556e+02,
content:'Saddle = 607.599976 pos = 34.5946,132.5306 diff = 180.700012'
});
data_peak.push({
lat: 3.4618444444e+01,
lng: 1.3251911111e+02,
cert : false,
content:' Peak = 815.799988 pos = 34.6184,132.5191 diff = 174.200012'
});
data_saddle.push({
lat: 3.4590444444e+01,
lng: 1.3249611111e+02,
content:'Saddle = 641.599976 pos = 34.5904,132.4961 diff = 174.200012'
});
data_peak.push({
lat: 3.4613666667e+01,
lng: 1.3248377778e+02,
cert : true,
content:'Name = JA/HS-053(JA/HS-053) peak = 869.099976 pos = 34.6137,132.4838 diff = 366.599976'
});
data_saddle.push({
lat: 3.4628222222e+01,
lng: 1.3248544444e+02,
content:'Saddle = 502.500000 pos = 34.6282,132.4854 diff = 366.599976'
});
data_peak.push({
lat: 3.4666333334e+01,
lng: 1.3247466667e+02,
cert : false,
content:' Peak = 835.099976 pos = 34.6663,132.4747 diff = 274.500000'
});
data_saddle.push({
lat: 3.4664555556e+01,
lng: 1.3246433333e+02,
content:'Saddle = 560.599976 pos = 34.6646,132.4643 diff = 274.500000'
});
data_peak.push({
lat: 3.4652444445e+01,
lng: 1.3249077778e+02,
cert : true,
content:'Name = JA/HS-073(JA/HS-073) peak = 794.299988 pos = 34.6524,132.4908 diff = 186.500000'
});
data_saddle.push({
lat: 3.4656777778e+01,
lng: 1.3248244444e+02,
content:'Saddle = 607.799988 pos = 34.6568,132.4824 diff = 186.500000'
});
data_peak.push({
lat: 3.4660888889e+01,
lng: 1.3245466667e+02,
cert : true,
content:'Name = JA/HS-064(JA/HS-064) peak = 820.599976 pos = 34.6609,132.4547 diff = 253.000000'
});
data_saddle.push({
lat: 3.4666555556e+01,
lng: 1.3244844444e+02,
content:'Saddle = 567.599976 pos = 34.6666,132.4484 diff = 253.000000'
});
data_peak.push({
lat: 3.4475888888e+01,
lng: 1.3230744444e+02,
cert : true,
content:'Name = JA/HS-035(JA/HS-035) peak = 977.200012 pos = 34.4759,132.3074 diff = 603.700012'
});
data_saddle.push({
lat: 3.4451222221e+01,
lng: 1.3228866667e+02,
content:'Saddle = 373.500000 pos = 34.4512,132.2887 diff = 603.700012'
});
data_peak.push({
lat: 3.4468555554e+01,
lng: 1.3236433333e+02,
cert : true,
content:'Name = JA/HS-126(JA/HS-126) peak = 641.099976 pos = 34.4686,132.3643 diff = 255.299988'
});
data_saddle.push({
lat: 3.4458777776e+01,
lng: 1.3235066667e+02,
content:'Saddle = 385.799988 pos = 34.4588,132.3507 diff = 255.299988'
});
data_peak.push({
lat: 3.4439555554e+01,
lng: 1.3233622222e+02,
cert : true,
content:'Name = Madogayama(JA/HS-101) peak = 710.700012 pos = 34.4396,132.3362 diff = 313.500000'
});
data_saddle.push({
lat: 3.4447222221e+01,
lng: 1.3232255556e+02,
content:'Saddle = 397.200012 pos = 34.4472,132.3226 diff = 313.500000'
});
data_peak.push({
lat: 3.4528444444e+01,
lng: 1.3236922222e+02,
cert : false,
content:' Peak = 663.799988 pos = 34.5284,132.3692 diff = 166.399994'
});
data_saddle.push({
lat: 3.4532777777e+01,
lng: 1.3235500000e+02,
content:'Saddle = 497.399994 pos = 34.5328,132.3550 diff = 166.399994'
});
data_peak.push({
lat: 3.4504999999e+01,
lng: 1.3234177778e+02,
cert : true,
content:'Name = JA/HS-100(JA/HS-100) peak = 711.400024 pos = 34.5050,132.3418 diff = 198.700012'
});
data_saddle.push({
lat: 3.4493999999e+01,
lng: 1.3233677778e+02,
content:'Saddle = 512.700012 pos = 34.4940,132.3368 diff = 198.700012'
});
data_peak.push({
lat: 3.4501888888e+01,
lng: 1.3232566667e+02,
cert : true,
content:'Name = JA/HS-109(JA/HS-109) peak = 693.000000 pos = 34.5019,132.3257 diff = 159.500000'
});
data_saddle.push({
lat: 3.4498222221e+01,
lng: 1.3232800000e+02,
content:'Saddle = 533.500000 pos = 34.4982,132.3280 diff = 159.500000'
});
data_peak.push({
lat: 3.4458111110e+01,
lng: 1.3231033333e+02,
cert : false,
content:' Peak = 862.799988 pos = 34.4581,132.3103 diff = 190.399963'
});
data_saddle.push({
lat: 3.4466888888e+01,
lng: 1.3231400000e+02,
content:'Saddle = 672.400024 pos = 34.4669,132.3140 diff = 190.399963'
});
data_peak.push({
lat: 3.4666000000e+01,
lng: 1.3238311111e+02,
cert : false,
content:' Peak = 917.200012 pos = 34.6660,132.3831 diff = 519.599976'
});
data_saddle.push({
lat: 3.4665666667e+01,
lng: 1.3230266667e+02,
content:'Saddle = 397.600006 pos = 34.6657,132.3027 diff = 519.599976'
});
data_peak.push({
lat: 3.4661111111e+01,
lng: 1.3235122222e+02,
cert : false,
content:' Peak = 863.500000 pos = 34.6611,132.3512 diff = 450.799988'
});
data_saddle.push({
lat: 3.4666555556e+01,
lng: 1.3236366667e+02,
content:'Saddle = 412.700012 pos = 34.6666,132.3637 diff = 450.799988'
});
data_peak.push({
lat: 3.4612222222e+01,
lng: 1.3237177778e+02,
cert : true,
content:'Name = JA/HS-078(JA/HS-078) peak = 777.700012 pos = 34.6122,132.3718 diff = 221.100037'
});
data_saddle.push({
lat: 3.4627666667e+01,
lng: 1.3236500000e+02,
content:'Saddle = 556.599976 pos = 34.6277,132.3650 diff = 221.100037'
});
data_peak.push({
lat: 3.4605000000e+01,
lng: 1.3235088889e+02,
cert : false,
content:' Peak = 774.000000 pos = 34.6050,132.3509 diff = 172.799988'
});
data_saddle.push({
lat: 3.4614333333e+01,
lng: 1.3236611111e+02,
content:'Saddle = 601.200012 pos = 34.6143,132.3661 diff = 172.799988'
});
data_peak.push({
lat: 3.4371999998e+01,
lng: 1.3227511111e+02,
cert : false,
content:' Peak = 730.900024 pos = 34.3720,132.2751 diff = 293.000031'
});
data_saddle.push({
lat: 3.4407666665e+01,
lng: 1.3227822222e+02,
content:'Saddle = 437.899994 pos = 34.4077,132.2782 diff = 293.000031'
});
data_peak.push({
lat: 3.4414888887e+01,
lng: 1.3226933333e+02,
cert : true,
content:'Name = JA/HS-124(JA/HS-124) peak = 645.500000 pos = 34.4149,132.2693 diff = 187.600006'
});
data_saddle.push({
lat: 3.4415777776e+01,
lng: 1.3226066667e+02,
content:'Saddle = 457.899994 pos = 34.4158,132.2607 diff = 187.600006'
});
data_peak.push({
lat: 3.4317222220e+01,
lng: 1.3210344444e+02,
cert : true,
content:'Name = JA/YG-016(JA/YG-016) peak = 751.099976 pos = 34.3172,132.1034 diff = 272.099976'
});
data_saddle.push({
lat: 3.4323222220e+01,
lng: 1.3209366667e+02,
content:'Saddle = 479.000000 pos = 34.3232,132.0937 diff = 272.099976'
});
data_peak.push({
lat: 3.4576111111e+01,
lng: 1.3230966667e+02,
cert : true,
content:'Name = JA/HS-097(JA/HS-097) peak = 721.099976 pos = 34.5761,132.3097 diff = 227.999969'
});
data_saddle.push({
lat: 3.4562333333e+01,
lng: 1.3228166667e+02,
content:'Saddle = 493.100006 pos = 34.5623,132.2817 diff = 227.999969'
});
data_peak.push({
lat: 3.4400777776e+01,
lng: 1.3203955556e+02,
cert : false,
content:' Peak = 703.900024 pos = 34.4008,132.0396 diff = 171.400024'
});
data_saddle.push({
lat: 3.4397999998e+01,
lng: 1.3204511111e+02,
content:'Saddle = 532.500000 pos = 34.3980,132.0451 diff = 171.400024'
});
data_peak.push({
lat: 3.4540555555e+01,
lng: 1.3228133333e+02,
cert : true,
content:'Name = JA/HS-036(JA/HS-036) peak = 971.900024 pos = 34.5406,132.2813 diff = 414.000000'
});
data_saddle.push({
lat: 3.4510444444e+01,
lng: 1.3223111111e+02,
content:'Saddle = 557.900024 pos = 34.5104,132.2311 diff = 414.000000'
});
data_peak.push({
lat: 3.4500555555e+01,
lng: 1.3226766667e+02,
cert : false,
content:' Peak = 782.400024 pos = 34.5006,132.2677 diff = 159.000000'
});
data_saddle.push({
lat: 3.4515888888e+01,
lng: 1.3226555556e+02,
content:'Saddle = 623.400024 pos = 34.5159,132.2656 diff = 159.000000'
});
data_peak.push({
lat: 3.4507999999e+01,
lng: 1.3224077778e+02,
cert : true,
content:'Name = JA/HS-047(JA/HS-047) peak = 904.200012 pos = 34.5080,132.2408 diff = 171.500000'
});
data_saddle.push({
lat: 3.4531777777e+01,
lng: 1.3225444444e+02,
content:'Saddle = 732.700012 pos = 34.5318,132.2544 diff = 171.500000'
});
data_peak.push({
lat: 3.4627444444e+01,
lng: 1.3228955556e+02,
cert : false,
content:' Peak = 750.900024 pos = 34.6274,132.2896 diff = 163.500000'
});
data_saddle.push({
lat: 3.4629555556e+01,
lng: 1.3228377778e+02,
content:'Saddle = 587.400024 pos = 34.6296,132.2838 diff = 163.500000'
});
data_peak.push({
lat: 3.4595333333e+01,
lng: 1.3226677778e+02,
cert : true,
content:'Name = JA/HS-067(JA/HS-067) peak = 813.200012 pos = 34.5953,132.2668 diff = 225.799988'
});
data_saddle.push({
lat: 3.4618111111e+01,
lng: 1.3227388889e+02,
content:'Saddle = 587.400024 pos = 34.6181,132.2739 diff = 225.799988'
});
data_peak.push({
lat: 3.4408111109e+01,
lng: 1.3216588889e+02,
cert : true,
content:'Name = JA/HS-074(JA/HS-074) peak = 791.500000 pos = 34.4081,132.1659 diff = 190.000000'
});
data_saddle.push({
lat: 3.4415333332e+01,
lng: 1.3216788889e+02,
content:'Saddle = 601.500000 pos = 34.4153,132.1679 diff = 190.000000'
});
data_peak.push({
lat: 3.4626222222e+01,
lng: 1.3225000000e+02,
cert : true,
content:'Name = JA/HS-030(JA/HS-030) peak = 1013.599976 pos = 34.6262,132.2500 diff = 346.500000'
});
data_saddle.push({
lat: 3.4643666667e+01,
lng: 1.3223911111e+02,
content:'Saddle = 667.099976 pos = 34.6437,132.2391 diff = 346.500000'
});
data_peak.push({
lat: 3.4532777777e+01,
lng: 1.3217600000e+02,
cert : true,
content:'Name = JA/HS-016(JA/HS-016) peak = 1132.599976 pos = 34.5328,132.1760 diff = 445.599976'
});
data_saddle.push({
lat: 3.4497888888e+01,
lng: 1.3216433333e+02,
content:'Saddle = 687.000000 pos = 34.4979,132.1643 diff = 445.599976'
});
data_peak.push({
lat: 3.4415777776e+01,
lng: 1.3221688889e+02,
cert : true,
content:'Name = Oomineyama(JA/HS-024) peak = 1048.000000 pos = 34.4158,132.2169 diff = 354.700012'
});
data_saddle.push({
lat: 3.4423777776e+01,
lng: 1.3219144444e+02,
content:'Saddle = 693.299988 pos = 34.4238,132.1914 diff = 354.700012'
});
data_peak.push({
lat: 3.4456777776e+01,
lng: 1.3225455556e+02,
cert : true,
content:'Name = JA/HS-046(JA/HS-046) peak = 906.500000 pos = 34.4568,132.2546 diff = 188.900024'
});
data_saddle.push({
lat: 3.4431555554e+01,
lng: 1.3223322222e+02,
content:'Saddle = 717.599976 pos = 34.4316,132.2332 diff = 188.900024'
});
data_peak.push({
lat: 3.4650000000e+01,
lng: 1.3220677778e+02,
cert : true,
content:'Name = Shinnyuuzan(JA/HS-014) peak = 1152.099976 pos = 34.6500,132.2068 diff = 407.099976'
});
data_saddle.push({
lat: 3.4652000000e+01,
lng: 1.3216966667e+02,
content:'Saddle = 745.000000 pos = 34.6520,132.1697 diff = 407.099976'
});
data_peak.push({
lat: 3.4655777778e+01,
lng: 1.3217855556e+02,
cert : false,
content:' Peak = 962.500000 pos = 34.6558,132.1786 diff = 188.700012'
});
data_saddle.push({
lat: 3.4666666667e+01,
lng: 1.3219811111e+02,
content:'Saddle = 773.799988 pos = 34.6667,132.1981 diff = 188.700012'
});
data_peak.push({
lat: 3.4628222222e+01,
lng: 1.3220766667e+02,
cert : true,
content:'Name = JA/HS-023(JA/HS-023) peak = 1067.400024 pos = 34.6282,132.2077 diff = 259.700012'
});
data_saddle.push({
lat: 3.4639666667e+01,
lng: 1.3221066667e+02,
content:'Saddle = 807.700012 pos = 34.6397,132.2107 diff = 259.700012'
});
data_peak.push({
lat: 3.4355666665e+01,
lng: 1.3206722222e+02,
cert : true,
content:'Name = Rakanzan(JA/YG-002) peak = 1107.900024 pos = 34.3557,132.0672 diff = 332.900024'
});
data_saddle.push({
lat: 3.4402999998e+01,
lng: 1.3207411111e+02,
content:'Saddle = 775.000000 pos = 34.4030,132.0741 diff = 332.900024'
});
data_peak.push({
lat: 3.4437666665e+01,
lng: 1.3217277778e+02,
cert : true,
content:'Name = JA/HS-039(JA/HS-039) peak = 947.700012 pos = 34.4377,132.1728 diff = 167.299988'
});
data_saddle.push({
lat: 3.4445888887e+01,
lng: 1.3216544444e+02,
content:'Saddle = 780.400024 pos = 34.4459,132.1654 diff = 167.299988'
});
data_peak.push({
lat: 3.4496777777e+01,
lng: 1.3218333333e+02,
cert : true,
content:'Name = JA/HS-020(JA/HS-020) peak = 1072.099976 pos = 34.4968,132.1833 diff = 290.899963'
});
data_saddle.push({
lat: 3.4430333332e+01,
lng: 1.3208833333e+02,
content:'Saddle = 781.200012 pos = 34.4303,132.0883 diff = 290.899963'
});
data_peak.push({
lat: 3.4443333332e+01,
lng: 1.3210966667e+02,
cert : false,
content:' Peak = 943.400024 pos = 34.4433,132.1097 diff = 152.800049'
});
data_saddle.push({
lat: 3.4435444443e+01,
lng: 1.3211211111e+02,
content:'Saddle = 790.599976 pos = 34.4354,132.1121 diff = 152.800049'
});
data_peak.push({
lat: 3.4476777777e+01,
lng: 1.3221333333e+02,
cert : true,
content:'Name = JA/HS-031(JA/HS-031) peak = 1004.000000 pos = 34.4768,132.2133 diff = 205.200012'
});
data_saddle.push({
lat: 3.4489444443e+01,
lng: 1.3220422222e+02,
content:'Saddle = 798.799988 pos = 34.4894,132.2042 diff = 205.200012'
});
data_peak.push({
lat: 3.4440444443e+01,
lng: 1.3214533333e+02,
cert : true,
content:'Name = JA/HS-021(JA/HS-021) peak = 1070.699951 pos = 34.4404,132.1453 diff = 219.599976'
});
data_saddle.push({
lat: 3.4473222221e+01,
lng: 1.3216455556e+02,
content:'Saddle = 851.099976 pos = 34.4732,132.1646 diff = 219.599976'
});
data_peak.push({
lat: 3.4409888887e+01,
lng: 1.3207144444e+02,
cert : true,
content:'Name = Onigajōyama(JA/HS-027) peak = 1030.599976 pos = 34.4099,132.0714 diff = 237.899963'
});
data_saddle.push({
lat: 3.4437111110e+01,
lng: 1.3207655556e+02,
content:'Saddle = 792.700012 pos = 34.4371,132.0766 diff = 237.899963'
});
data_peak.push({
lat: 3.4418111109e+01,
lng: 1.3200888889e+02,
cert : false,
content:' Peak = 1164.199951 pos = 34.4181,132.0089 diff = 347.699951'
});
data_saddle.push({
lat: 3.4429333332e+01,
lng: 1.3201988889e+02,
content:'Saddle = 816.500000 pos = 34.4293,132.0199 diff = 347.699951'
});
data_peak.push({
lat: 3.4497111110e+01,
lng: 1.3212544444e+02,
cert : false,
content:' Peak = 1081.300049 pos = 34.4971,132.1254 diff = 217.900024'
});
data_saddle.push({
lat: 3.4499888888e+01,
lng: 1.3211811111e+02,
content:'Saddle = 863.400024 pos = 34.4999,132.1181 diff = 217.900024'
});
data_peak.push({
lat: 3.4639555556e+01,
lng: 1.3214600000e+02,
cert : true,
content:'Name = JA/HS-017(JA/HS-017) peak = 1112.099976 pos = 34.6396,132.1460 diff = 200.399963'
});
data_saddle.push({
lat: 3.4641888889e+01,
lng: 1.3212788889e+02,
content:'Saddle = 911.700012 pos = 34.6419,132.1279 diff = 200.399963'
});
data_peak.push({
lat: 3.4468777777e+01,
lng: 1.3207600000e+02,
cert : true,
content:'Name = Kanmuriyama(JA/HS-002) peak = 1337.900024 pos = 34.4688,132.0760 diff = 384.500000'
});
data_saddle.push({
lat: 3.4499555555e+01,
lng: 1.3204444444e+02,
content:'Saddle = 953.400024 pos = 34.4996,132.0444 diff = 384.500000'
});
data_peak.push({
lat: 3.4515666666e+01,
lng: 1.3202833333e+02,
cert : true,
content:'Name = JA/SN-003(JA/SN-003) peak = 1180.199951 pos = 34.5157,132.0283 diff = 213.299927'
});
data_saddle.push({
lat: 3.4532444444e+01,
lng: 1.3206311111e+02,
content:'Saddle = 966.900024 pos = 34.5324,132.0631 diff = 213.299927'
});
data_peak.push({
lat: 3.4565000000e+01,
lng: 1.3214211111e+02,
cert : true,
content:'Name = Jippouzan(JA/HS-003) peak = 1327.400024 pos = 34.5650,132.1421 diff = 329.800049'
});
data_saddle.push({
lat: 3.4573666666e+01,
lng: 1.3213388889e+02,
content:'Saddle = 997.599976 pos = 34.5737,132.1339 diff = 329.800049'
});
data_peak.push({
lat: 3.4619222222e+01,
lng: 1.3212311111e+02,
cert : true,
content:'Name = JA/HS-013(JA/HS-013) peak = 1188.599976 pos = 34.6192,132.1231 diff = 188.799988'
});
data_saddle.push({
lat: 3.4601888889e+01,
lng: 1.3211855556e+02,
content:'Saddle = 999.799988 pos = 34.6019,132.1186 diff = 188.799988'
});
data_peak.push({
lat: 3.4589888889e+01,
lng: 1.3209144444e+02,
cert : true,
content:'Name = JA/SN-002(JA/SN-002) peak = 1186.099976 pos = 34.5899,132.0914 diff = 183.500000'
});
data_saddle.push({
lat: 3.4598555555e+01,
lng: 1.3209611111e+02,
content:'Saddle = 1002.599976 pos = 34.5986,132.0961 diff = 183.500000'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:34.6667,
       south:33.3333,
       east:135,
       west:132}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
