function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 2.6659555556e+01,
lng: 1.4216133333e+02,
cert : true,
content:'Name = Chibusayama(JA/TK-020) peak = 461.200012 pos = 26.6596,142.1613 diff = 461.200012'
});
data_saddle.push({
lat: 2.8000000000e+01,
lng: 1.4200000000e+02,
content:'Saddle = 0.000000 pos = 28.0000,142.0000 diff = 461.200012'
});
data_peak.push({
lat: 2.6558666667e+01,
lng: 1.4220922222e+02,
cert : true,
content:'Name = Imotojima(JA/TK-028) peak = 215.199997 pos = 26.5587,142.2092 diff = 215.199997'
});
data_saddle.push({
lat: 2.6607444445e+01,
lng: 1.4217844444e+02,
content:'Saddle = 0.000000 pos = 26.6074,142.1784 diff = 215.199997'
});
data_peak.push({
lat: 2.7628000000e+01,
lng: 1.4218344444e+02,
cert : false,
content:' Peak = 153.800003 pos = 27.6280,142.1834 diff = 153.800003'
});
data_saddle.push({
lat: 2.7619444445e+01,
lng: 1.4218544444e+02,
content:'Saddle = 0.000000 pos = 27.6194,142.1854 diff = 153.800003'
});
data_peak.push({
lat: 2.7156666667e+01,
lng: 1.4219022222e+02,
cert : true,
content:'Name = Sokuryougatake(JA/TK-027) peak = 232.699997 pos = 27.1567,142.1902 diff = 232.699997'
});
data_saddle.push({
lat: 2.7144333334e+01,
lng: 1.4218855556e+02,
content:'Saddle = 0.000000 pos = 27.1443,142.1886 diff = 232.699997'
});
data_peak.push({
lat: 2.7112444445e+01,
lng: 1.4221311111e+02,
cert : true,
content:'Name = Mikaeyama(JA/TK-026) peak = 252.500000 pos = 27.1124,142.2131 diff = 252.500000'
});
data_saddle.push({
lat: 2.7108444445e+01,
lng: 1.4221711111e+02,
content:'Saddle = 0.000000 pos = 27.1084,142.2171 diff = 252.500000'
});
data_peak.push({
lat: 2.7069777778e+01,
lng: 1.4222233333e+02,
cert : false,
content:' Peak = 321.600006 pos = 27.0698,142.2223 diff = 321.600006'
});
data_saddle.push({
lat: 2.7035666667e+01,
lng: 1.4222822222e+02,
content:'Saddle = 0.000000 pos = 27.0357,142.2282 diff = 321.600006'
});
data_peak.push({
lat: 2.7098888889e+01,
lng: 1.4218788889e+02,
cert : true,
content:'Name = (Ogasawara Is.)(JA/TK-030) peak = 202.600006 pos = 27.0989,142.1879 diff = 164.100006'
});
data_saddle.push({
lat: 2.7102000000e+01,
lng: 1.4219600000e+02,
content:'Saddle = 38.500000 pos = 27.1020,142.1960 diff = 164.100006'
});
data_peak.push({
lat: 2.6699555556e+01,
lng: 1.4214933333e+02,
cert : false,
content:' Peak = 291.500000 pos = 26.6996,142.1493 diff = 244.000000'
});
data_saddle.push({
lat: 2.6694444445e+01,
lng: 1.4214422222e+02,
content:'Saddle = 47.500000 pos = 26.6944,142.1442 diff = 244.000000'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:28,
       south:26,
       east:143,
       west:142}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
