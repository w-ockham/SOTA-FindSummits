function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.6289222222e+01,
lng: 1.3764788889e+02,
cert : false,
content:' Peak = 3192.300049 pos = 36.2892,137.6479 diff = 3192.300049'
});
data_saddle.push({
lat: 3.4809777776e+01,
lng: 1.3721677778e+02,
content:'Saddle = 0.000000 pos = 34.8098,137.2168 diff = 3192.300049'
});
data_peak.push({
lat: 3.4059777776e+01,
lng: 1.3626088889e+02,
cert : false,
content:' Peak = 163.000000 pos = 34.0598,136.2609 diff = 163.000000'
});
data_saddle.push({
lat: 3.4057555554e+01,
lng: 1.3626111111e+02,
content:'Saddle = 0.000000 pos = 34.0576,136.2611 diff = 163.000000'
});
data_peak.push({
lat: 3.4510666665e+01,
lng: 1.3686011111e+02,
cert : true,
content:'Name = JA/ME-109(JA/ME-109) peak = 166.500000 pos = 34.5107,136.8601 diff = 166.500000'
});
data_saddle.push({
lat: 3.4505555554e+01,
lng: 1.3685822222e+02,
content:'Saddle = 0.000000 pos = 34.5056,136.8582 diff = 166.500000'
});
data_peak.push({
lat: 3.4548444443e+01,
lng: 1.3698466667e+02,
cert : true,
content:'Name = JA/ME-108(JA/ME-108) peak = 170.500000 pos = 34.5484,136.9847 diff = 170.500000'
});
data_saddle.push({
lat: 3.4539888887e+01,
lng: 1.3698233333e+02,
content:'Saddle = 0.000000 pos = 34.5399,136.9823 diff = 170.500000'
});
data_peak.push({
lat: 3.4491666665e+01,
lng: 1.3688933333e+02,
cert : true,
content:'Name = JA/ME-107(JA/ME-107) peak = 233.000000 pos = 34.4917,136.8893 diff = 233.000000'
});
data_saddle.push({
lat: 3.4476333332e+01,
lng: 1.3688622222e+02,
content:'Saddle = 0.000000 pos = 34.4763,136.8862 diff = 233.000000'
});
data_peak.push({
lat: 3.4256666665e+01,
lng: 1.3654544444e+02,
cert : false,
content:' Peak = 162.800003 pos = 34.2567,136.5454 diff = 156.199997'
});
data_saddle.push({
lat: 3.4261999998e+01,
lng: 1.3654344444e+02,
content:'Saddle = 6.600000 pos = 34.2620,136.5434 diff = 156.199997'
});
data_peak.push({
lat: 3.4090666665e+01,
lng: 1.3629588889e+02,
cert : false,
content:' Peak = 173.399994 pos = 34.0907,136.2959 diff = 166.699997'
});
data_saddle.push({
lat: 3.4096111109e+01,
lng: 1.3629800000e+02,
content:'Saddle = 6.700000 pos = 34.0961,136.2980 diff = 166.699997'
});
data_peak.push({
lat: 3.4269444443e+01,
lng: 1.3654922222e+02,
cert : false,
content:' Peak = 191.199997 pos = 34.2694,136.5492 diff = 181.399994'
});
data_saddle.push({
lat: 3.4275555554e+01,
lng: 1.3654211111e+02,
content:'Saddle = 9.800000 pos = 34.2756,136.5421 diff = 181.399994'
});
data_peak.push({
lat: 3.4093555554e+01,
lng: 1.3627422222e+02,
cert : false,
content:' Peak = 300.899994 pos = 34.0936,136.2742 diff = 288.100006'
});
data_saddle.push({
lat: 3.4133444442e+01,
lng: 1.3626522222e+02,
content:'Saddle = 12.800000 pos = 34.1334,136.2652 diff = 288.100006'
});
data_peak.push({
lat: 3.4675666665e+01,
lng: 1.3723977778e+02,
cert : true,
content:'Name = JA/AC-039(JA/AC-039) peak = 277.100006 pos = 34.6757,137.2398 diff = 262.500000'
});
data_saddle.push({
lat: 3.4644666665e+01,
lng: 1.3722688889e+02,
content:'Saddle = 14.600000 pos = 34.6447,137.2269 diff = 262.500000'
});
data_peak.push({
lat: 3.4668555554e+01,
lng: 1.3720877778e+02,
cert : false,
content:' Peak = 222.800003 pos = 34.6686,137.2088 diff = 176.200012'
});
data_saddle.push({
lat: 3.4661777776e+01,
lng: 1.3721466667e+02,
content:'Saddle = 46.599998 pos = 34.6618,137.2147 diff = 176.200012'
});
data_peak.push({
lat: 3.4684999998e+01,
lng: 1.3726211111e+02,
cert : false,
content:' Peak = 250.199997 pos = 34.6850,137.2621 diff = 203.299988'
});
data_saddle.push({
lat: 3.4683888887e+01,
lng: 1.3724933333e+02,
content:'Saddle = 46.900002 pos = 34.6839,137.2493 diff = 203.299988'
});
data_peak.push({
lat: 3.4723444443e+01,
lng: 1.3799944444e+02,
cert : false,
content:' Peak = 244.399994 pos = 34.7234,137.9994 diff = 221.099991'
});
data_saddle.push({
lat: 3.4775444443e+01,
lng: 1.3799922222e+02,
content:'Saddle = 23.299999 pos = 34.7754,137.9992 diff = 221.099991'
});
data_peak.push({
lat: 3.5433444443e+01,
lng: 1.3678144444e+02,
cert : true,
content:'Name = Kinkazan(JA/GF-204) peak = 327.100006 pos = 35.4334,136.7814 diff = 302.000000'
});
data_saddle.push({
lat: 3.5433888888e+01,
lng: 1.3680433333e+02,
content:'Saddle = 25.100000 pos = 35.4339,136.8043 diff = 302.000000'
});
data_peak.push({
lat: 3.4648222221e+01,
lng: 1.3718700000e+02,
cert : false,
content:' Peak = 205.399994 pos = 34.6482,137.1870 diff = 176.299988'
});
data_saddle.push({
lat: 3.4635777776e+01,
lng: 1.3720111111e+02,
content:'Saddle = 29.100000 pos = 34.6358,137.2011 diff = 176.299988'
});
data_peak.push({
lat: 3.4602111109e+01,
lng: 1.3714644444e+02,
cert : true,
content:'Name = JA/AC-037(JA/AC-037) peak = 327.000000 pos = 34.6021,137.1464 diff = 297.899994'
});
data_saddle.push({
lat: 3.4639777776e+01,
lng: 1.3718166667e+02,
content:'Saddle = 29.100000 pos = 34.6398,137.1817 diff = 297.899994'
});
data_peak.push({
lat: 3.4623555554e+01,
lng: 1.3721788889e+02,
cert : false,
content:' Peak = 188.399994 pos = 34.6236,137.2179 diff = 158.599991'
});
data_saddle.push({
lat: 3.4723888887e+01,
lng: 1.3748277778e+02,
content:'Saddle = 29.799999 pos = 34.7239,137.4828 diff = 158.599991'
});
data_peak.push({
lat: 3.5438555555e+01,
lng: 1.3682466667e+02,
cert : false,
content:' Peak = 268.200012 pos = 35.4386,136.8247 diff = 235.700012'
});
data_saddle.push({
lat: 3.5441777777e+01,
lng: 1.3684200000e+02,
content:'Saddle = 32.500000 pos = 35.4418,136.8420 diff = 235.700012'
});
data_peak.push({
lat: 3.5429777777e+01,
lng: 1.3682922222e+02,
cert : false,
content:' Peak = 243.199997 pos = 35.4298,136.8292 diff = 198.000000'
});
data_saddle.push({
lat: 3.5432999999e+01,
lng: 1.3682500000e+02,
content:'Saddle = 45.200001 pos = 35.4330,136.8250 diff = 198.000000'
});
data_peak.push({
lat: 3.4813777776e+01,
lng: 1.3715088889e+02,
cert : false,
content:' Peak = 345.799988 pos = 34.8138,137.1509 diff = 311.199982'
});
data_saddle.push({
lat: 3.4838999999e+01,
lng: 1.3717400000e+02,
content:'Saddle = 34.599998 pos = 34.8390,137.1740 diff = 311.199982'
});
data_peak.push({
lat: 3.4843555554e+01,
lng: 1.3712300000e+02,
cert : false,
content:' Peak = 290.500000 pos = 34.8436,137.1230 diff = 183.300003'
});
data_saddle.push({
lat: 3.4828999999e+01,
lng: 1.3714366667e+02,
content:'Saddle = 107.199997 pos = 34.8290,137.1437 diff = 183.300003'
});
data_peak.push({
lat: 3.5476333332e+01,
lng: 1.3675155556e+02,
cert : false,
content:' Peak = 286.100006 pos = 35.4763,136.7516 diff = 249.600006'
});
data_saddle.push({
lat: 3.5514999999e+01,
lng: 1.3675722222e+02,
content:'Saddle = 36.500000 pos = 35.5150,136.7572 diff = 249.600006'
});
data_peak.push({
lat: 3.5477555555e+01,
lng: 1.3676911111e+02,
cert : false,
content:' Peak = 230.899994 pos = 35.4776,136.7691 diff = 187.599991'
});
data_saddle.push({
lat: 3.5487777777e+01,
lng: 1.3676544444e+02,
content:'Saddle = 43.299999 pos = 35.4878,136.7654 diff = 187.599991'
});
data_peak.push({
lat: 3.5499444444e+01,
lng: 1.3676355556e+02,
cert : true,
content:'Name = JA/GF-207(JA/GF-207) peak = 274.700012 pos = 35.4994,136.7636 diff = 176.300018'
});
data_saddle.push({
lat: 3.5494999999e+01,
lng: 1.3675566667e+02,
content:'Saddle = 98.400002 pos = 35.4950,136.7557 diff = 176.300018'
});
data_peak.push({
lat: 3.5463222221e+01,
lng: 1.3680011111e+02,
cert : false,
content:' Peak = 415.600006 pos = 35.4632,136.8001 diff = 377.200012'
});
data_saddle.push({
lat: 3.5490888888e+01,
lng: 1.3683155556e+02,
content:'Saddle = 38.400002 pos = 35.4909,136.8316 diff = 377.200012'
});
data_peak.push({
lat: 3.4347333332e+01,
lng: 1.3675344444e+02,
cert : false,
content:' Peak = 212.000000 pos = 34.3473,136.7534 diff = 165.300003'
});
data_saddle.push({
lat: 3.4355555554e+01,
lng: 1.3675066667e+02,
content:'Saddle = 46.700001 pos = 34.3556,136.7507 diff = 165.300003'
});
data_peak.push({
lat: 3.4324222220e+01,
lng: 1.3678811111e+02,
cert : false,
content:' Peak = 201.399994 pos = 34.3242,136.7881 diff = 152.899994'
});
data_saddle.push({
lat: 3.4342111109e+01,
lng: 1.3678322222e+02,
content:'Saddle = 48.500000 pos = 34.3421,136.7832 diff = 152.899994'
});
data_peak.push({
lat: 3.5505777777e+01,
lng: 1.3671322222e+02,
cert : true,
content:'Name = JA/GF-206(JA/GF-206) peak = 315.899994 pos = 35.5058,136.7132 diff = 248.099991'
});
data_saddle.push({
lat: 3.5521555555e+01,
lng: 1.3671000000e+02,
content:'Saddle = 67.800003 pos = 35.5216,136.7100 diff = 248.099991'
});
data_peak.push({
lat: 3.5479111110e+01,
lng: 1.3671177778e+02,
cert : false,
content:' Peak = 224.000000 pos = 35.4791,136.7118 diff = 155.699997'
});
data_saddle.push({
lat: 3.5483333332e+01,
lng: 1.3670900000e+02,
content:'Saddle = 68.300003 pos = 35.4833,136.7090 diff = 155.699997'
});
data_peak.push({
lat: 3.4857777776e+01,
lng: 1.3747833333e+02,
cert : false,
content:' Peak = 382.200012 pos = 34.8578,137.4783 diff = 312.700012'
});
data_saddle.push({
lat: 3.4845888887e+01,
lng: 1.3748833333e+02,
content:'Saddle = 69.500000 pos = 34.8459,137.4883 diff = 312.700012'
});
data_peak.push({
lat: 3.4408888887e+01,
lng: 1.3682411111e+02,
cert : true,
content:'Name = JA/ME-099(JA/ME-099) peak = 334.799988 pos = 34.4089,136.8241 diff = 258.299988'
});
data_saddle.push({
lat: 3.4413555554e+01,
lng: 1.3681588889e+02,
content:'Saddle = 76.500000 pos = 34.4136,136.8159 diff = 258.299988'
});
data_peak.push({
lat: 3.5428111110e+01,
lng: 1.3694544444e+02,
cert : true,
content:'Name = JA/GF-201(JA/GF-201) peak = 382.600006 pos = 35.4281,136.9454 diff = 304.000000'
});
data_saddle.push({
lat: 3.5438777777e+01,
lng: 1.3696000000e+02,
content:'Saddle = 78.599998 pos = 35.4388,136.9600 diff = 304.000000'
});
data_peak.push({
lat: 3.5430111110e+01,
lng: 1.3691044444e+02,
cert : false,
content:' Peak = 261.100006 pos = 35.4301,136.9104 diff = 153.100006'
});
data_saddle.push({
lat: 3.5432444443e+01,
lng: 1.3691444444e+02,
content:'Saddle = 108.000000 pos = 35.4324,136.9144 diff = 153.100006'
});
data_peak.push({
lat: 3.5426111110e+01,
lng: 1.3692144444e+02,
cert : false,
content:' Peak = 281.200012 pos = 35.4261,136.9214 diff = 150.200012'
});
data_saddle.push({
lat: 3.5428333332e+01,
lng: 1.3692533333e+02,
content:'Saddle = 131.000000 pos = 35.4283,136.9253 diff = 150.200012'
});
data_peak.push({
lat: 3.5444555555e+01,
lng: 1.3686822222e+02,
cert : true,
content:'Name = JA/GF-205(JA/GF-205) peak = 315.600006 pos = 35.4446,136.8682 diff = 168.500000'
});
data_saddle.push({
lat: 3.5445777777e+01,
lng: 1.3688622222e+02,
content:'Saddle = 147.100006 pos = 35.4458,136.8862 diff = 168.500000'
});
data_peak.push({
lat: 3.4448888887e+01,
lng: 1.3658166667e+02,
cert : true,
content:'Name = JA/ME-090(JA/ME-090) peak = 410.200012 pos = 34.4489,136.5817 diff = 324.100006'
});
data_saddle.push({
lat: 3.4463222220e+01,
lng: 1.3651600000e+02,
content:'Saddle = 86.099998 pos = 34.4632,136.5160 diff = 324.100006'
});
data_peak.push({
lat: 3.4448333332e+01,
lng: 1.3653188889e+02,
cert : false,
content:' Peak = 314.799988 pos = 34.4483,136.5319 diff = 211.399994'
});
data_saddle.push({
lat: 3.4460444443e+01,
lng: 1.3655111111e+02,
content:'Saddle = 103.400002 pos = 34.4604,136.5511 diff = 211.399994'
});
data_peak.push({
lat: 3.4838555554e+01,
lng: 1.3798688889e+02,
cert : false,
content:' Peak = 260.899994 pos = 34.8386,137.9869 diff = 173.699997'
});
data_saddle.push({
lat: 3.4845888887e+01,
lng: 1.3799988889e+02,
content:'Saddle = 87.199997 pos = 34.8459,137.9999 diff = 173.699997'
});
data_peak.push({
lat: 3.4484999998e+01,
lng: 1.3651244444e+02,
cert : true,
content:'Name = JA/ME-105(JA/ME-105) peak = 290.899994 pos = 34.4850,136.5124 diff = 203.699997'
});
data_saddle.push({
lat: 3.4458555554e+01,
lng: 1.3648111111e+02,
content:'Saddle = 87.199997 pos = 34.4586,136.4811 diff = 203.699997'
});
data_peak.push({
lat: 3.4274111109e+01,
lng: 1.3659944444e+02,
cert : false,
content:' Peak = 256.700012 pos = 34.2741,136.5994 diff = 169.200012'
});
data_saddle.push({
lat: 3.4276222220e+01,
lng: 1.3661144444e+02,
content:'Saddle = 87.500000 pos = 34.2762,136.6114 diff = 169.200012'
});
data_peak.push({
lat: 3.4485444443e+01,
lng: 1.3646322222e+02,
cert : false,
content:' Peak = 263.500000 pos = 34.4854,136.4632 diff = 175.899994'
});
data_saddle.push({
lat: 3.4489111109e+01,
lng: 1.3645844444e+02,
content:'Saddle = 87.599998 pos = 34.4891,136.4584 diff = 175.899994'
});
data_peak.push({
lat: 3.4735444443e+01,
lng: 1.3643222222e+02,
cert : false,
content:' Peak = 323.299988 pos = 34.7354,136.4322 diff = 226.499985'
});
data_saddle.push({
lat: 3.4724444443e+01,
lng: 1.3641188889e+02,
content:'Saddle = 96.800003 pos = 34.7244,136.4119 diff = 226.499985'
});
data_peak.push({
lat: 3.4427888887e+01,
lng: 1.3654366667e+02,
cert : false,
content:' Peak = 286.000000 pos = 34.4279,136.5437 diff = 189.100006'
});
data_saddle.push({
lat: 3.4420888887e+01,
lng: 1.3654855556e+02,
content:'Saddle = 96.900002 pos = 34.4209,136.5486 diff = 189.100006'
});
data_peak.push({
lat: 3.4422777776e+01,
lng: 1.3652300000e+02,
cert : false,
content:' Peak = 266.100006 pos = 34.4228,136.5230 diff = 168.500000'
});
data_saddle.push({
lat: 3.4415444443e+01,
lng: 1.3652500000e+02,
content:'Saddle = 97.599998 pos = 34.4154,136.5250 diff = 168.500000'
});
data_peak.push({
lat: 3.4847111110e+01,
lng: 1.3725900000e+02,
cert : true,
content:'Name = JA/AC-031(JA/AC-031) peak = 454.000000 pos = 34.8471,137.2590 diff = 345.600006'
});
data_saddle.push({
lat: 3.4880777776e+01,
lng: 1.3726944444e+02,
content:'Saddle = 108.400002 pos = 34.8808,137.2694 diff = 345.600006'
});
data_peak.push({
lat: 3.4833999999e+01,
lng: 1.3727466667e+02,
cert : false,
content:' Peak = 362.899994 pos = 34.8340,137.2747 diff = 154.899994'
});
data_saddle.push({
lat: 3.4840999999e+01,
lng: 1.3726388889e+02,
content:'Saddle = 208.000000 pos = 34.8410,137.2639 diff = 154.899994'
});
data_peak.push({
lat: 3.5349777777e+01,
lng: 1.3650655556e+02,
cert : false,
content:' Peak = 421.399994 pos = 35.3498,136.5066 diff = 310.700012'
});
data_saddle.push({
lat: 3.5358888888e+01,
lng: 1.3647488889e+02,
content:'Saddle = 110.699997 pos = 35.3589,136.4749 diff = 310.700012'
});
data_peak.push({
lat: 3.4126111109e+01,
lng: 1.3623833333e+02,
cert : true,
content:'Name = JA/ME-094(JA/ME-094) peak = 380.100006 pos = 34.1261,136.2383 diff = 267.900024'
});
data_saddle.push({
lat: 3.4141333331e+01,
lng: 1.3625900000e+02,
content:'Saddle = 112.199997 pos = 34.1413,136.2590 diff = 267.900024'
});
data_peak.push({
lat: 3.5344555555e+01,
lng: 1.3698400000e+02,
cert : false,
content:' Peak = 273.500000 pos = 35.3446,136.9840 diff = 157.100006'
});
data_saddle.push({
lat: 3.5353444443e+01,
lng: 1.3698955556e+02,
content:'Saddle = 116.400002 pos = 35.3534,136.9896 diff = 157.100006'
});
data_peak.push({
lat: 3.5417555555e+01,
lng: 1.3698477778e+02,
cert : true,
content:'Name = JA/GF-203(JA/GF-203) peak = 338.600006 pos = 35.4176,136.9848 diff = 221.000000'
});
data_saddle.push({
lat: 3.5385999999e+01,
lng: 1.3699900000e+02,
content:'Saddle = 117.599998 pos = 35.3860,136.9990 diff = 221.000000'
});
data_peak.push({
lat: 3.4282777776e+01,
lng: 1.3662177778e+02,
cert : true,
content:'Name = JA/ME-102(JA/ME-102) peak = 310.500000 pos = 34.2828,136.6218 diff = 192.800003'
});
data_saddle.push({
lat: 3.4293888887e+01,
lng: 1.3662455556e+02,
content:'Saddle = 117.699997 pos = 34.2939,136.6246 diff = 192.800003'
});
data_peak.push({
lat: 3.5333777777e+01,
lng: 1.3697966667e+02,
cert : false,
content:' Peak = 292.000000 pos = 35.3338,136.9797 diff = 174.000000'
});
data_saddle.push({
lat: 3.5325444443e+01,
lng: 1.3698711111e+02,
content:'Saddle = 118.000000 pos = 35.3254,136.9871 diff = 174.000000'
});
data_peak.push({
lat: 3.5505555555e+01,
lng: 1.3663600000e+02,
cert : true,
content:'Name = JA/GF-198(JA/GF-198) peak = 428.700012 pos = 35.5056,136.6360 diff = 310.300018'
});
data_saddle.push({
lat: 3.5490111110e+01,
lng: 1.3660577778e+02,
content:'Saddle = 118.400002 pos = 35.4901,136.6058 diff = 310.300018'
});
data_peak.push({
lat: 3.4333555554e+01,
lng: 1.3664633333e+02,
cert : true,
content:'Name = JA/ME-104(JA/ME-104) peak = 292.399994 pos = 34.3336,136.6463 diff = 170.099991'
});
data_saddle.push({
lat: 3.4328555554e+01,
lng: 1.3664377778e+02,
content:'Saddle = 122.300003 pos = 34.3286,136.6438 diff = 170.099991'
});
data_peak.push({
lat: 3.4240666665e+01,
lng: 1.3647466667e+02,
cert : false,
content:' Peak = 294.100006 pos = 34.2407,136.4747 diff = 168.200012'
});
data_saddle.push({
lat: 3.4260888887e+01,
lng: 1.3647444444e+02,
content:'Saddle = 125.900002 pos = 34.2609,136.4744 diff = 168.200012'
});
data_peak.push({
lat: 3.4396999998e+01,
lng: 1.3644077778e+02,
cert : false,
content:' Peak = 383.000000 pos = 34.3970,136.4408 diff = 255.100006'
});
data_saddle.push({
lat: 3.4402999998e+01,
lng: 1.3643722222e+02,
content:'Saddle = 127.900002 pos = 34.4030,136.4372 diff = 255.100006'
});
data_peak.push({
lat: 3.5533555555e+01,
lng: 1.3691855556e+02,
cert : false,
content:' Peak = 315.299988 pos = 35.5336,136.9186 diff = 178.099991'
});
data_saddle.push({
lat: 3.5542444444e+01,
lng: 1.3693444444e+02,
content:'Saddle = 137.199997 pos = 35.5424,136.9344 diff = 178.099991'
});
data_peak.push({
lat: 3.5119222221e+01,
lng: 1.3726855556e+02,
cert : true,
content:'Name = JA/AC-038(JA/AC-038) peak = 325.100006 pos = 35.1192,137.2686 diff = 187.400009'
});
data_saddle.push({
lat: 3.5133111110e+01,
lng: 1.3726322222e+02,
content:'Saddle = 137.699997 pos = 35.1331,137.2632 diff = 187.400009'
});
data_peak.push({
lat: 3.4849555554e+01,
lng: 1.3765477778e+02,
cert : true,
content:'Name = JA/SO-117(JA/SO-117) peak = 356.899994 pos = 34.8496,137.6548 diff = 208.099991'
});
data_saddle.push({
lat: 3.4870888887e+01,
lng: 1.3763766667e+02,
content:'Saddle = 148.800003 pos = 34.8709,137.6377 diff = 208.099991'
});
data_peak.push({
lat: 3.4507666665e+01,
lng: 1.3647111111e+02,
cert : true,
content:'Name = JA/ME-093(JA/ME-093) peak = 400.000000 pos = 34.5077,136.4711 diff = 242.500000'
});
data_saddle.push({
lat: 3.4505555554e+01,
lng: 1.3645233333e+02,
content:'Saddle = 157.500000 pos = 34.5056,136.4523 diff = 242.500000'
});
data_peak.push({
lat: 3.4826888887e+01,
lng: 1.3749788889e+02,
cert : true,
content:'Name = JA/SO-106(JA/SO-106) peak = 463.299988 pos = 34.8269,137.4979 diff = 305.699982'
});
data_saddle.push({
lat: 3.4840111110e+01,
lng: 1.3752211111e+02,
content:'Saddle = 157.600006 pos = 34.8401,137.5221 diff = 305.699982'
});
data_peak.push({
lat: 3.5314666666e+01,
lng: 1.3706522222e+02,
cert : true,
content:'Name = JA/GF-195(JA/GF-195) peak = 435.700012 pos = 35.3147,137.0652 diff = 278.000000'
});
data_saddle.push({
lat: 3.5368333332e+01,
lng: 1.3708033333e+02,
content:'Saddle = 157.699997 pos = 35.3683,137.0803 diff = 278.000000'
});
data_peak.push({
lat: 3.5346777777e+01,
lng: 1.3706900000e+02,
cert : false,
content:' Peak = 415.399994 pos = 35.3468,137.0690 diff = 177.699997'
});
data_saddle.push({
lat: 3.5329777777e+01,
lng: 1.3707155556e+02,
content:'Saddle = 237.699997 pos = 35.3298,137.0716 diff = 177.699997'
});
data_peak.push({
lat: 3.5514555555e+01,
lng: 1.3668522222e+02,
cert : true,
content:'Name = JA/GF-202(JA/GF-202) peak = 373.799988 pos = 35.5146,136.6852 diff = 215.999985'
});
data_saddle.push({
lat: 3.5536555555e+01,
lng: 1.3668222222e+02,
content:'Saddle = 157.800003 pos = 35.5366,136.6822 diff = 215.999985'
});
data_peak.push({
lat: 3.5569444444e+01,
lng: 1.3664266667e+02,
cert : false,
content:' Peak = 321.299988 pos = 35.5694,136.6427 diff = 163.299988'
});
data_saddle.push({
lat: 3.5578999999e+01,
lng: 1.3664111111e+02,
content:'Saddle = 158.000000 pos = 35.5790,136.6411 diff = 163.299988'
});
data_peak.push({
lat: 3.4886999999e+01,
lng: 1.3752455556e+02,
cert : true,
content:'Name = JA/AC-035(JA/AC-035) peak = 356.000000 pos = 34.8870,137.5246 diff = 188.500000'
});
data_saddle.push({
lat: 3.4870666665e+01,
lng: 1.3754244444e+02,
content:'Saddle = 167.500000 pos = 34.8707,137.5424 diff = 188.500000'
});
data_peak.push({
lat: 3.4460555554e+01,
lng: 1.3642000000e+02,
cert : true,
content:'Name = JA/ME-082(JA/ME-082) peak = 543.400024 pos = 34.4606,136.4200 diff = 375.800018'
});
data_saddle.push({
lat: 3.4448555554e+01,
lng: 1.3642000000e+02,
content:'Saddle = 167.600006 pos = 34.4486,136.4200 diff = 375.800018'
});
data_peak.push({
lat: 3.5503666666e+01,
lng: 1.3702277778e+02,
cert : false,
content:' Peak = 342.500000 pos = 35.5037,137.0228 diff = 171.000000'
});
data_saddle.push({
lat: 3.5500333332e+01,
lng: 1.3702644444e+02,
content:'Saddle = 171.500000 pos = 35.5003,137.0264 diff = 171.000000'
});
data_peak.push({
lat: 3.4185222220e+01,
lng: 1.3610911111e+02,
cert : true,
content:'Name = Oodaigaharazan (Hinodegatake)(JA/ME-001) peak = 1693.900024 pos = 34.1852,136.1091 diff = 1514.099976'
});
data_saddle.push({
lat: 3.5347444443e+01,
lng: 1.3641888889e+02,
content:'Saddle = 179.800003 pos = 35.3474,136.4189 diff = 1514.099976'
});
data_peak.push({
lat: 3.5348888888e+01,
lng: 1.3638355556e+02,
cert : true,
content:'Name = JA/SI-059(JA/SI-059) peak = 437.899994 pos = 35.3489,136.3836 diff = 251.000000'
});
data_saddle.push({
lat: 3.5333777777e+01,
lng: 1.3638522222e+02,
content:'Saddle = 186.899994 pos = 35.3338,136.3852 diff = 251.000000'
});
data_peak.push({
lat: 3.5256666666e+01,
lng: 1.3629155556e+02,
cert : false,
content:' Peak = 362.000000 pos = 35.2567,136.2916 diff = 153.699997'
});
data_saddle.push({
lat: 3.5260555554e+01,
lng: 1.3630522222e+02,
content:'Saddle = 208.300003 pos = 35.2606,136.3052 diff = 153.699997'
});
data_peak.push({
lat: 3.4461222220e+01,
lng: 1.3678155556e+02,
cert : true,
content:'Name = Asamagatake(JA/ME-077) peak = 554.200012 pos = 34.4612,136.7816 diff = 341.900024'
});
data_saddle.push({
lat: 3.4329666665e+01,
lng: 1.3659822222e+02,
content:'Saddle = 212.300003 pos = 34.3297,136.5982 diff = 341.900024'
});
data_peak.push({
lat: 3.4363666665e+01,
lng: 1.3667766667e+02,
cert : true,
content:'Name = JA/ME-092(JA/ME-092) peak = 400.700012 pos = 34.3637,136.6777 diff = 177.600006'
});
data_saddle.push({
lat: 3.4367222220e+01,
lng: 1.3668333333e+02,
content:'Saddle = 223.100006 pos = 34.3672,136.6833 diff = 177.600006'
});
data_peak.push({
lat: 3.4386888887e+01,
lng: 1.3663755556e+02,
cert : true,
content:'Name = JA/ME-079(JA/ME-079) peak = 550.599976 pos = 34.3869,136.6376 diff = 317.899963'
});
data_saddle.push({
lat: 3.4406777776e+01,
lng: 1.3675822222e+02,
content:'Saddle = 232.699997 pos = 34.4068,136.7582 diff = 317.899963'
});
data_peak.push({
lat: 3.4425999998e+01,
lng: 1.3669155556e+02,
cert : true,
content:'Name = JA/ME-080(JA/ME-080) peak = 546.900024 pos = 34.4260,136.6916 diff = 274.800018'
});
data_saddle.push({
lat: 3.4391444443e+01,
lng: 1.3669400000e+02,
content:'Saddle = 272.100006 pos = 34.3914,136.6940 diff = 274.800018'
});
data_peak.push({
lat: 3.4416444443e+01,
lng: 1.3664355556e+02,
cert : true,
content:'Name = JA/ME-087(JA/ME-087) peak = 491.600006 pos = 34.4164,136.6436 diff = 155.100006'
});
data_saddle.push({
lat: 3.4407777776e+01,
lng: 1.3664277778e+02,
content:'Saddle = 336.500000 pos = 34.4078,136.6428 diff = 155.100006'
});
data_peak.push({
lat: 3.4435777776e+01,
lng: 1.3674055556e+02,
cert : false,
content:' Peak = 401.799988 pos = 34.4358,136.7406 diff = 155.599991'
});
data_saddle.push({
lat: 3.4412444443e+01,
lng: 1.3676311111e+02,
content:'Saddle = 246.199997 pos = 34.4124,136.7631 diff = 155.599991'
});
data_peak.push({
lat: 3.4020888887e+01,
lng: 1.3626066667e+02,
cert : false,
content:' Peak = 392.100006 pos = 34.0209,136.2607 diff = 173.800003'
});
data_saddle.push({
lat: 3.4024666665e+01,
lng: 1.3625722222e+02,
content:'Saddle = 218.300003 pos = 34.0247,136.2572 diff = 173.800003'
});
data_peak.push({
lat: 3.4337999998e+01,
lng: 1.3651211111e+02,
cert : true,
content:'Name = JA/ME-042(JA/ME-042) peak = 784.900024 pos = 34.3380,136.5121 diff = 565.400024'
});
data_saddle.push({
lat: 3.4257333331e+01,
lng: 1.3640322222e+02,
content:'Saddle = 219.500000 pos = 34.2573,136.4032 diff = 565.400024'
});
data_peak.push({
lat: 3.4234111109e+01,
lng: 1.3641777778e+02,
cert : true,
content:'Name = JA/ME-086(JA/ME-086) peak = 502.000000 pos = 34.2341,136.4178 diff = 181.000000'
});
data_saddle.push({
lat: 3.4257222220e+01,
lng: 1.3641911111e+02,
content:'Saddle = 321.000000 pos = 34.2572,136.4191 diff = 181.000000'
});
data_peak.push({
lat: 3.4299333331e+01,
lng: 1.3655555556e+02,
cert : false,
content:' Peak = 496.299988 pos = 34.2993,136.5556 diff = 159.299988'
});
data_saddle.push({
lat: 3.4304555554e+01,
lng: 1.3655477778e+02,
content:'Saddle = 337.000000 pos = 34.3046,136.5548 diff = 159.299988'
});
data_peak.push({
lat: 3.4265777776e+01,
lng: 1.3642177778e+02,
cert : false,
content:' Peak = 554.200012 pos = 34.2658,136.4218 diff = 177.900024'
});
data_saddle.push({
lat: 3.4286999998e+01,
lng: 1.3643633333e+02,
content:'Saddle = 376.299988 pos = 34.2870,136.4363 diff = 177.900024'
});
data_peak.push({
lat: 3.4285333331e+01,
lng: 1.3641966667e+02,
cert : false,
content:' Peak = 543.200012 pos = 34.2853,136.4197 diff = 151.100006'
});
data_saddle.push({
lat: 3.4279333331e+01,
lng: 1.3642266667e+02,
content:'Saddle = 392.100006 pos = 34.2793,136.4227 diff = 151.100006'
});
data_peak.push({
lat: 3.4372999998e+01,
lng: 1.3651555556e+02,
cert : true,
content:'Name = Nanahoragatake(JA/ME-044) peak = 772.700012 pos = 34.3730,136.5156 diff = 390.300018'
});
data_saddle.push({
lat: 3.4355444443e+01,
lng: 1.3651722222e+02,
content:'Saddle = 382.399994 pos = 34.3554,136.5172 diff = 390.300018'
});
data_peak.push({
lat: 3.4364333332e+01,
lng: 1.3655288889e+02,
cert : false,
content:' Peak = 573.599976 pos = 34.3643,136.5529 diff = 166.699982'
});
data_saddle.push({
lat: 3.4370444443e+01,
lng: 1.3654811111e+02,
content:'Saddle = 406.899994 pos = 34.3704,136.5481 diff = 166.699982'
});
data_peak.push({
lat: 3.4355999998e+01,
lng: 1.3645311111e+02,
cert : true,
content:'Name = JA/ME-055(JA/ME-055) peak = 730.200012 pos = 34.3560,136.4531 diff = 279.000000'
});
data_saddle.push({
lat: 3.4340444443e+01,
lng: 1.3646511111e+02,
content:'Saddle = 451.200012 pos = 34.3404,136.4651 diff = 279.000000'
});
data_peak.push({
lat: 3.4329111109e+01,
lng: 1.3647044444e+02,
cert : true,
content:'Name = JA/ME-054(JA/ME-054) peak = 732.200012 pos = 34.3291,136.4704 diff = 214.000000'
});
data_saddle.push({
lat: 3.4325888887e+01,
lng: 1.3649188889e+02,
content:'Saddle = 518.200012 pos = 34.3259,136.4919 diff = 214.000000'
});
data_peak.push({
lat: 3.4091444442e+01,
lng: 1.3620888889e+02,
cert : true,
content:'Name = JA/ME-084(JA/ME-084) peak = 521.700012 pos = 34.0914,136.2089 diff = 299.500000'
});
data_saddle.push({
lat: 3.4091333331e+01,
lng: 1.3619733333e+02,
content:'Saddle = 222.199997 pos = 34.0913,136.1973 diff = 299.500000'
});
data_peak.push({
lat: 3.5283666666e+01,
lng: 1.3651111111e+02,
cert : true,
content:'Name = Shougadake(JA/GF-142) peak = 906.299988 pos = 35.2837,136.5111 diff = 682.500000'
});
data_saddle.push({
lat: 3.5236777777e+01,
lng: 1.3647500000e+02,
content:'Saddle = 223.800003 pos = 35.2368,136.4750 diff = 682.500000'
});
data_peak.push({
lat: 3.5175111110e+01,
lng: 1.3658788889e+02,
cert : true,
content:'Name = JA/ME-060(JA/ME-060) peak = 693.700012 pos = 35.1751,136.5879 diff = 261.200012'
});
data_saddle.push({
lat: 3.5215555554e+01,
lng: 1.3655900000e+02,
content:'Saddle = 432.500000 pos = 35.2156,136.5590 diff = 261.200012'
});
data_peak.push({
lat: 3.5263222221e+01,
lng: 1.3652322222e+02,
cert : false,
content:' Peak = 858.099976 pos = 35.2632,136.5232 diff = 150.099976'
});
data_saddle.push({
lat: 3.5284888888e+01,
lng: 1.3652133333e+02,
content:'Saddle = 708.000000 pos = 35.2849,136.5213 diff = 150.099976'
});
data_peak.push({
lat: 3.4840333332e+01,
lng: 1.3608611111e+02,
cert : false,
content:' Peak = 741.299988 pos = 34.8403,136.0861 diff = 510.199982'
});
data_saddle.push({
lat: 3.4872666665e+01,
lng: 1.3619333333e+02,
content:'Saddle = 231.100006 pos = 34.8727,136.1933 diff = 510.199982'
});
data_peak.push({
lat: 3.4966555554e+01,
lng: 1.3606088889e+02,
cert : true,
content:'Name = JA/SI-038(JA/SI-038) peak = 692.500000 pos = 34.9666,136.0609 diff = 353.799988'
});
data_saddle.push({
lat: 3.4925888888e+01,
lng: 1.3611577778e+02,
content:'Saddle = 338.700012 pos = 34.9259,136.1158 diff = 353.799988'
});
data_peak.push({
lat: 3.4958222221e+01,
lng: 1.3603377778e+02,
cert : false,
content:' Peak = 610.599976 pos = 34.9582,136.0338 diff = 182.099976'
});
data_saddle.push({
lat: 3.4960888888e+01,
lng: 1.3604166667e+02,
content:'Saddle = 428.500000 pos = 34.9609,136.0417 diff = 182.099976'
});
data_peak.push({
lat: 3.4944222221e+01,
lng: 1.3610977778e+02,
cert : true,
content:'Name = JA/SI-042(JA/SI-042) peak = 663.700012 pos = 34.9442,136.1098 diff = 185.700012'
});
data_saddle.push({
lat: 3.4953777776e+01,
lng: 1.3609777778e+02,
content:'Saddle = 478.000000 pos = 34.9538,136.0978 diff = 185.700012'
});
data_peak.push({
lat: 3.4872222221e+01,
lng: 1.3607288889e+02,
cert : false,
content:' Peak = 551.599976 pos = 34.8722,136.0729 diff = 204.399963'
});
data_saddle.push({
lat: 3.4865555554e+01,
lng: 1.3608800000e+02,
content:'Saddle = 347.200012 pos = 34.8656,136.0880 diff = 204.399963'
});
data_peak.push({
lat: 3.4898999999e+01,
lng: 1.3600022222e+02,
cert : false,
content:' Peak = 570.099976 pos = 34.8990,136.0002 diff = 221.899963'
});
data_saddle.push({
lat: 3.4855555554e+01,
lng: 1.3600322222e+02,
content:'Saddle = 348.200012 pos = 34.8556,136.0032 diff = 221.899963'
});
data_peak.push({
lat: 3.4922777776e+01,
lng: 1.3604100000e+02,
cert : false,
content:' Peak = 566.799988 pos = 34.9228,136.0410 diff = 160.099976'
});
data_saddle.push({
lat: 3.4875999999e+01,
lng: 1.3601788889e+02,
content:'Saddle = 406.700012 pos = 34.8760,136.0179 diff = 160.099976'
});
data_peak.push({
lat: 3.4094999998e+01,
lng: 1.3618366667e+02,
cert : true,
content:'Name = JA/ME-070(JA/ME-070) peak = 598.200012 pos = 34.0950,136.1837 diff = 357.000000'
});
data_saddle.push({
lat: 3.4080222220e+01,
lng: 1.3617388889e+02,
content:'Saddle = 241.199997 pos = 34.0802,136.1739 diff = 357.000000'
});
data_peak.push({
lat: 3.4267333331e+01,
lng: 1.3637922222e+02,
cert : true,
content:'Name = JA/ME-067(JA/ME-067) peak = 631.799988 pos = 34.2673,136.3792 diff = 390.500000'
});
data_saddle.push({
lat: 3.4237222220e+01,
lng: 1.3635777778e+02,
content:'Saddle = 241.300003 pos = 34.2372,136.3578 diff = 390.500000'
});
data_peak.push({
lat: 3.4580555554e+01,
lng: 1.3600388889e+02,
cert : false,
content:' Peak = 622.900024 pos = 34.5806,136.0039 diff = 323.600037'
});
data_saddle.push({
lat: 3.4555888887e+01,
lng: 1.3600655556e+02,
content:'Saddle = 299.299988 pos = 34.5559,136.0066 diff = 323.600037'
});
data_peak.push({
lat: 3.4667222221e+01,
lng: 1.3600000000e+02,
cert : false,
content:' Peak = 593.099976 pos = 34.6672,136.0000 diff = 190.299988'
});
data_saddle.push({
lat: 3.4602666665e+01,
lng: 1.3600055556e+02,
content:'Saddle = 402.799988 pos = 34.6027,136.0006 diff = 190.299988'
});
data_peak.push({
lat: 3.4856333332e+01,
lng: 1.3634922222e+02,
cert : true,
content:'Name = JA/ME-074(JA/ME-074) peak = 560.700012 pos = 34.8563,136.3492 diff = 253.600006'
});
data_saddle.push({
lat: 3.4859777776e+01,
lng: 1.3634144444e+02,
content:'Saddle = 307.100006 pos = 34.8598,136.3414 diff = 253.600006'
});
data_peak.push({
lat: 3.5178555554e+01,
lng: 1.3641466667e+02,
cert : true,
content:'Name = Oikedake(JA/SI-002) peak = 1246.500000 pos = 35.1786,136.4147 diff = 928.799988'
});
data_saddle.push({
lat: 3.4845666665e+01,
lng: 1.3628288889e+02,
content:'Saddle = 317.700012 pos = 34.8457,136.2829 diff = 928.799988'
});
data_peak.push({
lat: 3.4889555554e+01,
lng: 1.3638577778e+02,
cert : true,
content:'Name = JA/ME-075(JA/ME-075) peak = 563.400024 pos = 34.8896,136.3858 diff = 203.500031'
});
data_saddle.push({
lat: 3.4892888888e+01,
lng: 1.3637855556e+02,
content:'Saddle = 359.899994 pos = 34.8929,136.3786 diff = 203.500031'
});
data_peak.push({
lat: 3.4875888887e+01,
lng: 1.3629788889e+02,
cert : true,
content:'Name = JA/ME-040(JA/ME-040) peak = 798.500000 pos = 34.8759,136.2979 diff = 420.700012'
});
data_saddle.push({
lat: 3.4894777776e+01,
lng: 1.3633677778e+02,
content:'Saddle = 377.799988 pos = 34.8948,136.3368 diff = 420.700012'
});
data_peak.push({
lat: 3.4855555554e+01,
lng: 1.3628422222e+02,
cert : false,
content:' Peak = 716.000000 pos = 34.8556,136.2842 diff = 153.799988'
});
data_saddle.push({
lat: 3.4863666665e+01,
lng: 1.3628066667e+02,
content:'Saddle = 562.200012 pos = 34.8637,136.2807 diff = 153.799988'
});
data_peak.push({
lat: 3.5296444443e+01,
lng: 1.3632655556e+02,
cert : true,
content:'Name = JA/SI-047(JA/SI-047) peak = 600.900024 pos = 35.2964,136.3266 diff = 163.400024'
});
data_saddle.push({
lat: 3.5288555554e+01,
lng: 1.3633388889e+02,
content:'Saddle = 437.500000 pos = 35.2886,136.3339 diff = 163.400024'
});
data_peak.push({
lat: 3.4974666665e+01,
lng: 1.3632155556e+02,
cert : true,
content:'Name = JA/SI-037(JA/SI-037) peak = 721.500000 pos = 34.9747,136.3216 diff = 283.899994'
});
data_saddle.push({
lat: 3.4980555554e+01,
lng: 1.3632811111e+02,
content:'Saddle = 437.600006 pos = 34.9806,136.3281 diff = 283.899994'
});
data_peak.push({
lat: 3.5088666665e+01,
lng: 1.3647111111e+02,
cert : false,
content:' Peak = 596.299988 pos = 35.0887,136.4711 diff = 153.099976'
});
data_saddle.push({
lat: 3.5087666665e+01,
lng: 1.3646611111e+02,
content:'Saddle = 443.200012 pos = 35.0877,136.4661 diff = 153.099976'
});
data_peak.push({
lat: 3.4902888888e+01,
lng: 1.3635944444e+02,
cert : true,
content:'Name = JA/ME-065(JA/ME-065) peak = 665.200012 pos = 34.9029,136.3594 diff = 214.200012'
});
data_saddle.push({
lat: 3.4910888888e+01,
lng: 1.3636466667e+02,
content:'Saddle = 451.000000 pos = 34.9109,136.3647 diff = 214.200012'
});
data_peak.push({
lat: 3.5265111110e+01,
lng: 1.3633977778e+02,
cert : false,
content:' Peak = 686.799988 pos = 35.2651,136.3398 diff = 214.899994'
});
data_saddle.push({
lat: 3.5274666666e+01,
lng: 1.3635511111e+02,
content:'Saddle = 471.899994 pos = 35.2747,136.3551 diff = 214.899994'
});
data_peak.push({
lat: 3.5279444443e+01,
lng: 1.3632377778e+02,
cert : true,
content:'Name = JA/SI-040(JA/SI-040) peak = 682.500000 pos = 35.2794,136.3238 diff = 165.200012'
});
data_saddle.push({
lat: 3.5272333332e+01,
lng: 1.3631844444e+02,
content:'Saddle = 517.299988 pos = 35.2723,136.3184 diff = 165.200012'
});
data_peak.push({
lat: 3.5164111110e+01,
lng: 1.3630288889e+02,
cert : false,
content:' Peak = 640.700012 pos = 35.1641,136.3029 diff = 168.400024'
});
data_saddle.push({
lat: 3.5158999999e+01,
lng: 1.3630922222e+02,
content:'Saddle = 472.299988 pos = 35.1590,136.3092 diff = 168.400024'
});
data_peak.push({
lat: 3.5255444443e+01,
lng: 1.3642811111e+02,
cert : true,
content:'Name = JA/GF-171(JA/GF-171) peak = 710.599976 pos = 35.2554,136.4281 diff = 233.699982'
});
data_saddle.push({
lat: 3.5268999999e+01,
lng: 1.3643066667e+02,
content:'Saddle = 476.899994 pos = 35.2690,136.4307 diff = 233.699982'
});
data_peak.push({
lat: 3.5279222221e+01,
lng: 1.3638111111e+02,
cert : true,
content:'Name = Ryouzenzan(JA/SI-010) peak = 1092.099976 pos = 35.2792,136.3811 diff = 585.000000'
});
data_saddle.push({
lat: 3.5240333332e+01,
lng: 1.3638188889e+02,
content:'Saddle = 507.100006 pos = 35.2403,136.3819 diff = 585.000000'
});
data_peak.push({
lat: 3.5102222221e+01,
lng: 1.3634233333e+02,
cert : true,
content:'Name = JA/SI-015(JA/SI-015) peak = 933.200012 pos = 35.1022,136.3423 diff = 422.600006'
});
data_saddle.push({
lat: 3.5132222221e+01,
lng: 1.3636177778e+02,
content:'Saddle = 510.600006 pos = 35.1322,136.3618 diff = 422.600006'
});
data_peak.push({
lat: 3.5138444443e+01,
lng: 1.3630277778e+02,
cert : true,
content:'Name = JA/SI-033(JA/SI-033) peak = 771.299988 pos = 35.1384,136.3028 diff = 233.000000'
});
data_saddle.push({
lat: 3.5120111110e+01,
lng: 1.3630711111e+02,
content:'Saddle = 538.299988 pos = 35.1201,136.3071 diff = 233.000000'
});
data_peak.push({
lat: 3.5143777777e+01,
lng: 1.3633577778e+02,
cert : false,
content:' Peak = 763.700012 pos = 35.1438,136.3358 diff = 212.000000'
});
data_saddle.push({
lat: 3.5138333332e+01,
lng: 1.3632600000e+02,
content:'Saddle = 551.700012 pos = 35.1383,136.3260 diff = 212.000000'
});
data_peak.push({
lat: 3.5245666666e+01,
lng: 1.3635933333e+02,
cert : true,
content:'Name = JA/SI-027(JA/SI-027) peak = 837.599976 pos = 35.2457,136.3593 diff = 265.699951'
});
data_saddle.push({
lat: 3.5222555554e+01,
lng: 1.3637300000e+02,
content:'Saddle = 571.900024 pos = 35.2226,136.3730 diff = 265.699951'
});
data_peak.push({
lat: 3.5220222221e+01,
lng: 1.3635344444e+02,
cert : true,
content:'Name = JA/SI-029(JA/SI-029) peak = 817.299988 pos = 35.2202,136.3534 diff = 195.299988'
});
data_saddle.push({
lat: 3.5233555554e+01,
lng: 1.3635288889e+02,
content:'Saddle = 622.000000 pos = 35.2336,136.3529 diff = 195.299988'
});
data_peak.push({
lat: 3.5105333332e+01,
lng: 1.3641544444e+02,
cert : false,
content:' Peak = 752.599976 pos = 35.1053,136.4154 diff = 154.199951'
});
data_saddle.push({
lat: 3.5101888888e+01,
lng: 1.3642288889e+02,
content:'Saddle = 598.400024 pos = 35.1019,136.4229 diff = 154.199951'
});
data_peak.push({
lat: 3.5021333332e+01,
lng: 1.3638388889e+02,
cert : false,
content:' Peak = 1235.500000 pos = 35.0213,136.3839 diff = 550.099976'
});
data_saddle.push({
lat: 3.5108333332e+01,
lng: 1.3644133333e+02,
content:'Saddle = 685.400024 pos = 35.1083,136.4413 diff = 550.099976'
});
data_peak.push({
lat: 3.4999111110e+01,
lng: 1.3644877778e+02,
cert : true,
content:'Name = JA/ME-031(JA/ME-031) peak = 887.299988 pos = 34.9991,136.4488 diff = 175.000000'
});
data_saddle.push({
lat: 3.5000555554e+01,
lng: 1.3643611111e+02,
content:'Saddle = 712.299988 pos = 35.0006,136.4361 diff = 175.000000'
});
data_peak.push({
lat: 3.4975777776e+01,
lng: 1.3637033333e+02,
cert : false,
content:' Peak = 913.599976 pos = 34.9758,136.3703 diff = 193.399963'
});
data_saddle.push({
lat: 3.4972111110e+01,
lng: 1.3639122222e+02,
content:'Saddle = 720.200012 pos = 34.9721,136.3912 diff = 193.399963'
});
data_peak.push({
lat: 3.4947222221e+01,
lng: 1.3641411111e+02,
cert : false,
content:' Peak = 873.700012 pos = 34.9472,136.4141 diff = 152.100037'
});
data_saddle.push({
lat: 3.4950111110e+01,
lng: 1.3640433333e+02,
content:'Saddle = 721.599976 pos = 34.9501,136.4043 diff = 152.100037'
});
data_peak.push({
lat: 3.5088666665e+01,
lng: 1.3640722222e+02,
cert : false,
content:' Peak = 930.700012 pos = 35.0887,136.4072 diff = 168.299988'
});
data_saddle.push({
lat: 3.5082111110e+01,
lng: 1.3642288889e+02,
content:'Saddle = 762.400024 pos = 35.0821,136.4229 diff = 168.299988'
});
data_peak.push({
lat: 3.5013777776e+01,
lng: 1.3634177778e+02,
cert : true,
content:'Name = JA/SI-009(JA/SI-009) peak = 1113.199951 pos = 35.0138,136.3418 diff = 320.699951'
});
data_saddle.push({
lat: 3.5022333332e+01,
lng: 1.3636011111e+02,
content:'Saddle = 792.500000 pos = 35.0223,136.3601 diff = 320.699951'
});
data_peak.push({
lat: 3.5065666665e+01,
lng: 1.3644133333e+02,
cert : true,
content:'Name = JA/ME-016(JA/ME-016) peak = 1091.300049 pos = 35.0657,136.4413 diff = 290.200073'
});
data_saddle.push({
lat: 3.5036666665e+01,
lng: 1.3641655556e+02,
content:'Saddle = 801.099976 pos = 35.0367,136.4166 diff = 290.200073'
});
data_peak.push({
lat: 3.4951888888e+01,
lng: 1.3639533333e+02,
cert : false,
content:' Peak = 960.799988 pos = 34.9519,136.3953 diff = 157.099976'
});
data_saddle.push({
lat: 3.4955666665e+01,
lng: 1.3639622222e+02,
content:'Saddle = 803.700012 pos = 34.9557,136.3962 diff = 157.099976'
});
data_peak.push({
lat: 3.5001222221e+01,
lng: 1.3642111111e+02,
cert : true,
content:'Name = JA/ME-012(JA/ME-012) peak = 1160.300049 pos = 35.0012,136.4211 diff = 278.600037'
});
data_saddle.push({
lat: 3.5010555554e+01,
lng: 1.3641722222e+02,
content:'Saddle = 881.700012 pos = 35.0106,136.4172 diff = 278.600037'
});
data_peak.push({
lat: 3.5020444443e+01,
lng: 1.3641800000e+02,
cert : true,
content:'Name = Gozaishoyama(JA/ME-011) peak = 1211.500000 pos = 35.0204,136.4180 diff = 309.099976'
});
data_saddle.push({
lat: 3.5016555554e+01,
lng: 1.3639977778e+02,
content:'Saddle = 902.400024 pos = 35.0166,136.3998 diff = 309.099976'
});
data_peak.push({
lat: 3.5228222221e+01,
lng: 1.3643333333e+02,
cert : false,
content:' Peak = 870.299988 pos = 35.2282,136.4333 diff = 160.399963'
});
data_saddle.push({
lat: 3.5225888888e+01,
lng: 1.3642588889e+02,
content:'Saddle = 709.900024 pos = 35.2259,136.4259 diff = 160.399963'
});
data_peak.push({
lat: 3.5119333332e+01,
lng: 1.3644500000e+02,
cert : true,
content:'Name = Ryuugadake(JA/ME-014) peak = 1098.699951 pos = 35.1193,136.4450 diff = 347.399963'
});
data_saddle.push({
lat: 3.5145777777e+01,
lng: 1.3644377778e+02,
content:'Saddle = 751.299988 pos = 35.1458,136.4438 diff = 347.399963'
});
data_peak.push({
lat: 3.5130999999e+01,
lng: 1.3643455556e+02,
cert : false,
content:' Peak = 1085.699951 pos = 35.1310,136.4346 diff = 162.599976'
});
data_saddle.push({
lat: 3.5127333332e+01,
lng: 1.3644344444e+02,
content:'Saddle = 923.099976 pos = 35.1273,136.4434 diff = 162.599976'
});
data_peak.push({
lat: 3.5214777777e+01,
lng: 1.3641622222e+02,
cert : false,
content:' Peak = 912.299988 pos = 35.2148,136.4162 diff = 154.099976'
});
data_saddle.push({
lat: 3.5210666666e+01,
lng: 1.3641600000e+02,
content:'Saddle = 758.200012 pos = 35.2107,136.4160 diff = 154.099976'
});
data_peak.push({
lat: 3.5151555554e+01,
lng: 1.3639133333e+02,
cert : true,
content:'Name = JA/SI-011(JA/SI-011) peak = 985.400024 pos = 35.1516,136.3913 diff = 213.800049'
});
data_saddle.push({
lat: 3.5189333332e+01,
lng: 1.3638122222e+02,
content:'Saddle = 771.599976 pos = 35.1893,136.3812 diff = 213.800049'
});
data_peak.push({
lat: 3.5166222221e+01,
lng: 1.3644511111e+02,
cert : true,
content:'Name = JA/SI-007(JA/SI-007) peak = 1170.500000 pos = 35.1662,136.4451 diff = 229.599976'
});
data_saddle.push({
lat: 3.5184333332e+01,
lng: 1.3642411111e+02,
content:'Saddle = 940.900024 pos = 35.1843,136.4241 diff = 229.599976'
});
data_peak.push({
lat: 3.4182999998e+01,
lng: 1.3624800000e+02,
cert : false,
content:' Peak = 571.400024 pos = 34.1830,136.2480 diff = 239.800018'
});
data_saddle.push({
lat: 3.4201333331e+01,
lng: 1.3623688889e+02,
content:'Saddle = 331.600006 pos = 34.2013,136.2369 diff = 239.800018'
});
data_peak.push({
lat: 3.4600444443e+01,
lng: 1.3633555556e+02,
cert : true,
content:'Name = JA/ME-081(JA/ME-081) peak = 543.099976 pos = 34.6004,136.3356 diff = 203.099976'
});
data_saddle.push({
lat: 3.4594555554e+01,
lng: 1.3634933333e+02,
content:'Saddle = 340.000000 pos = 34.5946,136.3493 diff = 203.099976'
});
data_peak.push({
lat: 3.4420444443e+01,
lng: 1.3642466667e+02,
cert : false,
content:' Peak = 511.500000 pos = 34.4204,136.4247 diff = 160.299988'
});
data_saddle.push({
lat: 3.4416777776e+01,
lng: 1.3641266667e+02,
content:'Saddle = 351.200012 pos = 34.4168,136.4127 diff = 160.299988'
});
data_peak.push({
lat: 3.4243444443e+01,
lng: 1.3634077778e+02,
cert : false,
content:' Peak = 533.900024 pos = 34.2434,136.3408 diff = 181.800018'
});
data_saddle.push({
lat: 3.4243333331e+01,
lng: 1.3632733333e+02,
content:'Saddle = 352.100006 pos = 34.2433,136.3273 diff = 181.800018'
});
data_peak.push({
lat: 3.4529888887e+01,
lng: 1.3625866667e+02,
cert : false,
content:' Peak = 569.500000 pos = 34.5299,136.2587 diff = 207.600006'
});
data_saddle.push({
lat: 3.4526111109e+01,
lng: 1.3624855556e+02,
content:'Saddle = 361.899994 pos = 34.5261,136.2486 diff = 207.600006'
});
data_peak.push({
lat: 3.4383444443e+01,
lng: 1.3632455556e+02,
cert : true,
content:'Name = JA/ME-083(JA/ME-083) peak = 541.500000 pos = 34.3834,136.3246 diff = 178.700012'
});
data_saddle.push({
lat: 3.4396111109e+01,
lng: 1.3632144444e+02,
content:'Saddle = 362.799988 pos = 34.3961,136.3214 diff = 178.700012'
});
data_peak.push({
lat: 3.4821444443e+01,
lng: 1.3635566667e+02,
cert : true,
content:'Name = JA/ME-063(JA/ME-063) peak = 672.099976 pos = 34.8214,136.3557 diff = 305.299988'
});
data_saddle.push({
lat: 3.4818888887e+01,
lng: 1.3634222222e+02,
content:'Saddle = 366.799988 pos = 34.8189,136.3422 diff = 305.299988'
});
data_peak.push({
lat: 3.4581333332e+01,
lng: 1.3635422222e+02,
cert : false,
content:' Peak = 550.599976 pos = 34.5813,136.3542 diff = 181.599976'
});
data_saddle.push({
lat: 3.4579222221e+01,
lng: 1.3636422222e+02,
content:'Saddle = 369.000000 pos = 34.5792,136.3642 diff = 181.599976'
});
data_peak.push({
lat: 3.4545444443e+01,
lng: 1.3639155556e+02,
cert : false,
content:' Peak = 541.400024 pos = 34.5454,136.3916 diff = 163.900024'
});
data_saddle.push({
lat: 3.4539888887e+01,
lng: 1.3639455556e+02,
content:'Saddle = 377.500000 pos = 34.5399,136.3946 diff = 163.900024'
});
data_peak.push({
lat: 3.4212888887e+01,
lng: 1.3625311111e+02,
cert : false,
content:' Peak = 542.099976 pos = 34.2129,136.2531 diff = 160.699982'
});
data_saddle.push({
lat: 3.4216444443e+01,
lng: 1.3625177778e+02,
content:'Saddle = 381.399994 pos = 34.2164,136.2518 diff = 160.699982'
});
data_peak.push({
lat: 3.4573999998e+01,
lng: 1.3637000000e+02,
cert : true,
content:'Name = JA/ME-056(JA/ME-056) peak = 730.400024 pos = 34.5740,136.3700 diff = 324.000031'
});
data_saddle.push({
lat: 3.4557222221e+01,
lng: 1.3636211111e+02,
content:'Saddle = 406.399994 pos = 34.5572,136.3621 diff = 324.000031'
});
data_peak.push({
lat: 3.4408555554e+01,
lng: 1.3632955556e+02,
cert : true,
content:'Name = JA/ME-064(JA/ME-064) peak = 674.599976 pos = 34.4086,136.3296 diff = 254.899963'
});
data_saddle.push({
lat: 3.4393999998e+01,
lng: 1.3626277778e+02,
content:'Saddle = 419.700012 pos = 34.3940,136.2628 diff = 254.899963'
});
data_peak.push({
lat: 3.4401888887e+01,
lng: 1.3635488889e+02,
cert : false,
content:' Peak = 611.900024 pos = 34.4019,136.3549 diff = 169.600037'
});
data_saddle.push({
lat: 3.4405444443e+01,
lng: 1.3634622222e+02,
content:'Saddle = 442.299988 pos = 34.4054,136.3462 diff = 169.600037'
});
data_peak.push({
lat: 3.4505888887e+01,
lng: 1.3640733333e+02,
cert : true,
content:'Name = JA/ME-035(JA/ME-035) peak = 817.700012 pos = 34.5059,136.4073 diff = 386.000000'
});
data_saddle.push({
lat: 3.4490444443e+01,
lng: 1.3633733333e+02,
content:'Saddle = 431.700012 pos = 34.4904,136.3373 diff = 386.000000'
});
data_peak.push({
lat: 3.4546666665e+01,
lng: 1.3643288889e+02,
cert : true,
content:'Name = Hossakasan(JA/ME-050) peak = 750.799988 pos = 34.5467,136.4329 diff = 313.199982'
});
data_saddle.push({
lat: 3.4535222221e+01,
lng: 1.3641055556e+02,
content:'Saddle = 437.600006 pos = 34.5352,136.4106 diff = 313.199982'
});
data_peak.push({
lat: 3.4550111109e+01,
lng: 1.3636055556e+02,
cert : true,
content:'Name = JA/ME-061(JA/ME-061) peak = 681.099976 pos = 34.5501,136.3606 diff = 209.299988'
});
data_saddle.push({
lat: 3.4537777776e+01,
lng: 1.3634833333e+02,
content:'Saddle = 471.799988 pos = 34.5378,136.3483 diff = 209.299988'
});
data_peak.push({
lat: 3.4532666665e+01,
lng: 1.3632677778e+02,
cert : false,
content:' Peak = 693.099976 pos = 34.5327,136.3268 diff = 154.299988'
});
data_saddle.push({
lat: 3.4528999998e+01,
lng: 1.3633777778e+02,
content:'Saddle = 538.799988 pos = 34.5290,136.3378 diff = 154.299988'
});
data_peak.push({
lat: 3.4554333332e+01,
lng: 1.3629155556e+02,
cert : true,
content:'Name = JA/ME-047(JA/ME-047) peak = 773.099976 pos = 34.5543,136.2916 diff = 335.099976'
});
data_saddle.push({
lat: 3.4526666665e+01,
lng: 1.3629000000e+02,
content:'Saddle = 438.000000 pos = 34.5267,136.2900 diff = 335.099976'
});
data_peak.push({
lat: 3.4571111109e+01,
lng: 1.3631366667e+02,
cert : true,
content:'Name = JA/ME-052(JA/ME-052) peak = 744.500000 pos = 34.5711,136.3137 diff = 167.200012'
});
data_saddle.push({
lat: 3.4560444443e+01,
lng: 1.3629888889e+02,
content:'Saddle = 577.299988 pos = 34.5604,136.2989 diff = 167.200012'
});
data_peak.push({
lat: 3.4538666665e+01,
lng: 1.3621488889e+02,
cert : true,
content:'Name = JA/ME-022(JA/ME-022) peak = 1012.099976 pos = 34.5387,136.2149 diff = 543.899963'
});
data_saddle.push({
lat: 3.4516666665e+01,
lng: 1.3620288889e+02,
content:'Saddle = 468.200012 pos = 34.5167,136.2029 diff = 543.899963'
});
data_peak.push({
lat: 3.4766555554e+01,
lng: 1.3637433333e+02,
cert : true,
content:'Name = Kyougamine(JA/ME-036) peak = 818.200012 pos = 34.7666,136.3743 diff = 321.600006'
});
data_saddle.push({
lat: 3.4761666665e+01,
lng: 1.3632688889e+02,
content:'Saddle = 496.600006 pos = 34.7617,136.3269 diff = 321.600006'
});
data_peak.push({
lat: 3.4809222221e+01,
lng: 1.3630122222e+02,
cert : true,
content:'Name = JA/ME-041(JA/ME-041) peak = 793.700012 pos = 34.8092,136.3012 diff = 291.300018'
});
data_saddle.push({
lat: 3.4779888887e+01,
lng: 1.3633677778e+02,
content:'Saddle = 502.399994 pos = 34.7799,136.3368 diff = 291.300018'
});
data_peak.push({
lat: 3.4817222221e+01,
lng: 1.3626044444e+02,
cert : true,
content:'Name = Reisan(JA/ME-049) peak = 765.500000 pos = 34.8172,136.2604 diff = 213.400024'
});
data_saddle.push({
lat: 3.4812333332e+01,
lng: 1.3628366667e+02,
content:'Saddle = 552.099976 pos = 34.8123,136.2837 diff = 213.400024'
});
data_peak.push({
lat: 3.4733999998e+01,
lng: 1.3629633333e+02,
cert : true,
content:'Name = Kasatoriyama(JA/ME-034) peak = 841.400024 pos = 34.7340,136.2963 diff = 343.000031'
});
data_saddle.push({
lat: 3.4670666665e+01,
lng: 1.3626811111e+02,
content:'Saddle = 498.399994 pos = 34.6707,136.2681 diff = 343.000031'
});
data_peak.push({
lat: 3.4601111109e+01,
lng: 1.3624977778e+02,
cert : true,
content:'Name = JA/ME-043(JA/ME-043) peak = 777.700012 pos = 34.6011,136.2498 diff = 204.600037'
});
data_saddle.push({
lat: 3.4591999998e+01,
lng: 1.3625666667e+02,
content:'Saddle = 573.099976 pos = 34.5920,136.2567 diff = 204.600037'
});
data_peak.push({
lat: 3.4579333332e+01,
lng: 1.3622877778e+02,
cert : false,
content:' Peak = 763.000000 pos = 34.5793,136.2288 diff = 175.000000'
});
data_saddle.push({
lat: 3.4573444443e+01,
lng: 1.3622388889e+02,
content:'Saddle = 588.000000 pos = 34.5734,136.2239 diff = 175.000000'
});
data_peak.push({
lat: 3.4557333332e+01,
lng: 1.3621955556e+02,
cert : true,
content:'Name = Amagadake(JA/ME-024) peak = 960.700012 pos = 34.5573,136.2196 diff = 209.600037'
});
data_saddle.push({
lat: 3.4551666665e+01,
lng: 1.3621433333e+02,
content:'Saddle = 751.099976 pos = 34.5517,136.2143 diff = 209.600037'
});
data_peak.push({
lat: 3.4270777776e+01,
lng: 1.3634177778e+02,
cert : true,
content:'Name = JA/ME-066(JA/ME-066) peak = 635.799988 pos = 34.2708,136.3418 diff = 163.000000'
});
data_saddle.push({
lat: 3.4279444443e+01,
lng: 1.3634366667e+02,
content:'Saddle = 472.799988 pos = 34.2794,136.3437 diff = 163.000000'
});
data_peak.push({
lat: 3.4536666665e+01,
lng: 1.3602477778e+02,
cert : false,
content:' Peak = 676.400024 pos = 34.5367,136.0248 diff = 163.800049'
});
data_saddle.push({
lat: 3.4531444443e+01,
lng: 1.3603366667e+02,
content:'Saddle = 512.599976 pos = 34.5314,136.0337 diff = 163.800049'
});
data_peak.push({
lat: 3.4023111109e+01,
lng: 1.3619922222e+02,
cert : true,
content:'Name = JA/ME-051(JA/ME-051) peak = 751.400024 pos = 34.0231,136.1992 diff = 218.500000'
});
data_saddle.push({
lat: 3.4017666665e+01,
lng: 1.3618755556e+02,
content:'Saddle = 532.900024 pos = 34.0177,136.1876 diff = 218.500000'
});
data_peak.push({
lat: 3.4498777776e+01,
lng: 1.3631611111e+02,
cert : false,
content:' Peak = 691.799988 pos = 34.4988,136.3161 diff = 153.099976'
});
data_saddle.push({
lat: 3.4487888887e+01,
lng: 1.3632511111e+02,
content:'Saddle = 538.700012 pos = 34.4879,136.3251 diff = 153.099976'
});
data_peak.push({
lat: 3.4263111109e+01,
lng: 1.3630833333e+02,
cert : true,
content:'Name = JA/ME-053(JA/ME-053) peak = 733.500000 pos = 34.2631,136.3083 diff = 191.700012'
});
data_saddle.push({
lat: 3.4265555554e+01,
lng: 1.3629722222e+02,
content:'Saddle = 541.799988 pos = 34.2656,136.2972 diff = 191.700012'
});
data_peak.push({
lat: 3.4494777776e+01,
lng: 1.3628333333e+02,
cert : true,
content:'Name = JA/ME-057(JA/ME-057) peak = 725.700012 pos = 34.4948,136.2833 diff = 181.600037'
});
data_saddle.push({
lat: 3.4487333332e+01,
lng: 1.3628433333e+02,
content:'Saddle = 544.099976 pos = 34.4873,136.2843 diff = 181.600037'
});
data_peak.push({
lat: 3.4530999998e+01,
lng: 1.3617033333e+02,
cert : true,
content:'Name = Kurosoyama(JA/ME-018) peak = 1036.599976 pos = 34.5310,136.1703 diff = 478.399963'
});
data_saddle.push({
lat: 3.4486111109e+01,
lng: 1.3615322222e+02,
content:'Saddle = 558.200012 pos = 34.4861,136.1532 diff = 478.399963'
});
data_peak.push({
lat: 3.4493999998e+01,
lng: 1.3612811111e+02,
cert : true,
content:'Name = JA/NR-044(JA/NR-044) peak = 791.799988 pos = 34.4940,136.1281 diff = 173.200012'
});
data_saddle.push({
lat: 3.4496333332e+01,
lng: 1.3614366667e+02,
content:'Saddle = 618.599976 pos = 34.4963,136.1437 diff = 173.200012'
});
data_peak.push({
lat: 3.4502666665e+01,
lng: 1.3615155556e+02,
cert : false,
content:' Peak = 956.099976 pos = 34.5027,136.1516 diff = 269.599976'
});
data_saddle.push({
lat: 3.4514888887e+01,
lng: 1.3615966667e+02,
content:'Saddle = 686.500000 pos = 34.5149,136.1597 diff = 269.599976'
});
data_peak.push({
lat: 3.4548444443e+01,
lng: 1.3616200000e+02,
cert : true,
content:'Name = JA/ME-032(JA/ME-032) peak = 881.400024 pos = 34.5484,136.1620 diff = 169.900024'
});
data_saddle.push({
lat: 3.4542222221e+01,
lng: 1.3616422222e+02,
content:'Saddle = 711.500000 pos = 34.5422,136.1642 diff = 169.900024'
});
data_peak.push({
lat: 3.4246222220e+01,
lng: 1.3621733333e+02,
cert : true,
content:'Name = JA/ME-013(JA/ME-013) peak = 1094.599976 pos = 34.2462,136.2173 diff = 497.299988'
});
data_saddle.push({
lat: 3.4200111109e+01,
lng: 1.3618977778e+02,
content:'Saddle = 597.299988 pos = 34.2001,136.1898 diff = 497.299988'
});
data_peak.push({
lat: 3.4289111109e+01,
lng: 1.3626911111e+02,
cert : true,
content:'Name = JA/ME-017(JA/ME-017) peak = 1037.599976 pos = 34.2891,136.2691 diff = 338.599976'
});
data_saddle.push({
lat: 3.4263666665e+01,
lng: 1.3625200000e+02,
content:'Saddle = 699.000000 pos = 34.2637,136.2520 diff = 338.599976'
});
data_peak.push({
lat: 3.4320999998e+01,
lng: 1.3632277778e+02,
cert : true,
content:'Name = JA/ME-026(JA/ME-026) peak = 951.700012 pos = 34.3210,136.3228 diff = 224.500000'
});
data_saddle.push({
lat: 3.4310777776e+01,
lng: 1.3632100000e+02,
content:'Saddle = 727.200012 pos = 34.3108,136.3210 diff = 224.500000'
});
data_peak.push({
lat: 3.4224999998e+01,
lng: 1.3619044444e+02,
cert : true,
content:'Name = JA/ME-030(JA/ME-030) peak = 888.700012 pos = 34.2250,136.1904 diff = 176.200012'
});
data_saddle.push({
lat: 3.4221777776e+01,
lng: 1.3620755556e+02,
content:'Saddle = 712.500000 pos = 34.2218,136.2076 diff = 176.200012'
});
data_peak.push({
lat: 3.4404444443e+01,
lng: 1.3615644444e+02,
cert : true,
content:'Name = JA/ME-025(JA/ME-025) peak = 953.500000 pos = 34.4044,136.1564 diff = 336.799988'
});
data_saddle.push({
lat: 3.4399888887e+01,
lng: 1.3613800000e+02,
content:'Saddle = 616.700012 pos = 34.3999,136.1380 diff = 336.799988'
});
data_peak.push({
lat: 3.4516555554e+01,
lng: 1.3609333333e+02,
cert : true,
content:'Name = JA/NR-036(JA/NR-036) peak = 1013.299988 pos = 34.5166,136.0933 diff = 371.000000'
});
data_saddle.push({
lat: 3.4496111109e+01,
lng: 1.3608500000e+02,
content:'Saddle = 642.299988 pos = 34.4961,136.0850 diff = 371.000000'
});
data_peak.push({
lat: 3.4525888887e+01,
lng: 1.3612055556e+02,
cert : true,
content:'Name = JA/NR-038(JA/NR-038) peak = 922.700012 pos = 34.5259,136.1206 diff = 265.700012'
});
data_saddle.push({
lat: 3.4527999998e+01,
lng: 1.3611566667e+02,
content:'Saddle = 657.000000 pos = 34.5280,136.1157 diff = 265.700012'
});
data_peak.push({
lat: 3.4528888887e+01,
lng: 1.3613022222e+02,
cert : false,
content:' Peak = 892.599976 pos = 34.5289,136.1302 diff = 164.399963'
});
data_saddle.push({
lat: 3.4529777776e+01,
lng: 1.3612455556e+02,
content:'Saddle = 728.200012 pos = 34.5298,136.1246 diff = 164.399963'
});
data_peak.push({
lat: 3.4508111109e+01,
lng: 1.3602711111e+02,
cert : false,
content:' Peak = 873.599976 pos = 34.5081,136.0271 diff = 206.699951'
});
data_saddle.push({
lat: 3.4483111109e+01,
lng: 1.3604033333e+02,
content:'Saddle = 666.900024 pos = 34.4831,136.0403 diff = 206.699951'
});
data_peak.push({
lat: 3.4064111109e+01,
lng: 1.3607255556e+02,
cert : true,
content:'Name = JA/NR-027(JA/NR-027) peak = 1181.599976 pos = 34.0641,136.0726 diff = 488.899963'
});
data_saddle.push({
lat: 3.4056666665e+01,
lng: 1.3611377778e+02,
content:'Saddle = 692.700012 pos = 34.0567,136.1138 diff = 488.899963'
});
data_peak.push({
lat: 3.4003888887e+01,
lng: 1.3609400000e+02,
cert : false,
content:' Peak = 1032.000000 pos = 34.0039,136.0940 diff = 250.200012'
});
data_saddle.push({
lat: 3.4010666665e+01,
lng: 1.3611377778e+02,
content:'Saddle = 781.799988 pos = 34.0107,136.1138 diff = 250.200012'
});
data_peak.push({
lat: 3.4031999998e+01,
lng: 1.3614711111e+02,
cert : false,
content:' Peak = 1043.500000 pos = 34.0320,136.1471 diff = 160.400024'
});
data_saddle.push({
lat: 3.4026999998e+01,
lng: 1.3613300000e+02,
content:'Saddle = 883.099976 pos = 34.0270,136.1330 diff = 160.400024'
});
data_peak.push({
lat: 3.4047111109e+01,
lng: 1.3609455556e+02,
cert : false,
content:' Peak = 1150.099976 pos = 34.0471,136.0946 diff = 166.099976'
});
data_saddle.push({
lat: 3.4058222220e+01,
lng: 1.3607844444e+02,
content:'Saddle = 984.000000 pos = 34.0582,136.0784 diff = 166.099976'
});
data_peak.push({
lat: 3.4467666665e+01,
lng: 1.3615322222e+02,
cert : false,
content:' Peak = 860.000000 pos = 34.4677,136.1532 diff = 151.900024'
});
data_saddle.push({
lat: 3.4455444443e+01,
lng: 1.3615111111e+02,
content:'Saddle = 708.099976 pos = 34.4554,136.1511 diff = 151.900024'
});
data_peak.push({
lat: 3.4460555554e+01,
lng: 1.3632700000e+02,
cert : true,
content:'Name = Tsubonegadake(JA/ME-020) peak = 1020.599976 pos = 34.4606,136.3270 diff = 307.799988'
});
data_saddle.push({
lat: 3.4462444443e+01,
lng: 1.3629488889e+02,
content:'Saddle = 712.799988 pos = 34.4624,136.2949 diff = 307.799988'
});
data_peak.push({
lat: 3.4448777776e+01,
lng: 1.3620622222e+02,
cert : true,
content:'Name = Miuneyama(JA/ME-010) peak = 1234.900024 pos = 34.4488,136.2062 diff = 483.000000'
});
data_saddle.push({
lat: 3.4442999998e+01,
lng: 1.3612011111e+02,
content:'Saddle = 751.900024 pos = 34.4430,136.1201 diff = 483.000000'
});
data_peak.push({
lat: 3.4474999998e+01,
lng: 1.3618233333e+02,
cert : false,
content:' Peak = 907.200012 pos = 34.4750,136.1823 diff = 154.900024'
});
data_saddle.push({
lat: 3.4461666665e+01,
lng: 1.3618088889e+02,
content:'Saddle = 752.299988 pos = 34.4617,136.1809 diff = 154.900024'
});
data_peak.push({
lat: 3.4491999998e+01,
lng: 1.3622977778e+02,
cert : true,
content:'Name = JA/ME-021(JA/ME-021) peak = 1021.000000 pos = 34.4920,136.2298 diff = 258.900024'
});
data_saddle.push({
lat: 3.4472666665e+01,
lng: 1.3621466667e+02,
content:'Saddle = 762.099976 pos = 34.4727,136.2147 diff = 258.900024'
});
data_peak.push({
lat: 3.4450222220e+01,
lng: 1.3625611111e+02,
cert : true,
content:'Name = JA/ME-015(JA/ME-015) peak = 1092.500000 pos = 34.4502,136.2561 diff = 163.799988'
});
data_saddle.push({
lat: 3.4448111109e+01,
lng: 1.3624922222e+02,
content:'Saddle = 928.700012 pos = 34.4481,136.2492 diff = 163.799988'
});
data_peak.push({
lat: 3.4428666665e+01,
lng: 1.3608833333e+02,
cert : true,
content:'Name = Takamiyama(JA/ME-009) peak = 1246.300049 pos = 34.4287,136.0883 diff = 354.300049'
});
data_saddle.push({
lat: 3.4421222220e+01,
lng: 1.3609077778e+02,
content:'Saddle = 892.000000 pos = 34.4212,136.0908 diff = 354.300049'
});
data_peak.push({
lat: 3.4097888887e+01,
lng: 1.3602355556e+02,
cert : true,
content:'Name = JA/NR-032(JA/NR-032) peak = 1112.599976 pos = 34.0979,136.0236 diff = 170.199951'
});
data_saddle.push({
lat: 3.4108999998e+01,
lng: 1.3602666667e+02,
content:'Saddle = 942.400024 pos = 34.1090,136.0267 diff = 170.199951'
});
data_peak.push({
lat: 3.4370333332e+01,
lng: 1.3609122222e+02,
cert : false,
content:' Peak = 1432.300049 pos = 34.3703,136.0912 diff = 430.500061'
});
data_saddle.push({
lat: 3.4234111109e+01,
lng: 1.3611744444e+02,
content:'Saddle = 1001.799988 pos = 34.2341,136.1174 diff = 430.500061'
});
data_peak.push({
lat: 3.4249222220e+01,
lng: 1.3615600000e+02,
cert : false,
content:' Peak = 1293.500000 pos = 34.2492,136.1560 diff = 276.200012'
});
data_saddle.push({
lat: 3.4268999998e+01,
lng: 1.3612088889e+02,
content:'Saddle = 1017.299988 pos = 34.2690,136.1209 diff = 276.200012'
});
data_peak.push({
lat: 3.4280888887e+01,
lng: 1.3614633333e+02,
cert : true,
content:'Name = JA/ME-006(JA/ME-006) peak = 1283.800049 pos = 34.2809,136.1463 diff = 261.900024'
});
data_saddle.push({
lat: 3.4263888887e+01,
lng: 1.3611855556e+02,
content:'Saddle = 1021.900024 pos = 34.2639,136.1186 diff = 261.900024'
});
data_peak.push({
lat: 3.4350111109e+01,
lng: 1.3620755556e+02,
cert : true,
content:'Name = Mayoidake(JA/ME-005) peak = 1305.300049 pos = 34.3501,136.2076 diff = 271.900024'
});
data_saddle.push({
lat: 3.4335444443e+01,
lng: 1.3618844444e+02,
content:'Saddle = 1033.400024 pos = 34.3354,136.1884 diff = 271.900024'
});
data_peak.push({
lat: 3.4322111109e+01,
lng: 1.3616311111e+02,
cert : true,
content:'Name = JA/ME-008(JA/ME-008) peak = 1267.400024 pos = 34.3221,136.1631 diff = 205.800049'
});
data_saddle.push({
lat: 3.4317555554e+01,
lng: 1.3615911111e+02,
content:'Saddle = 1061.599976 pos = 34.3176,136.1591 diff = 205.800049'
});
data_peak.push({
lat: 3.4292999998e+01,
lng: 1.3604688889e+02,
cert : true,
content:'Name = Shirahigedake(JA/NR-010) peak = 1374.599976 pos = 34.2930,136.0469 diff = 272.099976'
});
data_saddle.push({
lat: 3.4298555554e+01,
lng: 1.3605811111e+02,
content:'Saddle = 1102.500000 pos = 34.2986,136.0581 diff = 272.099976'
});
data_peak.push({
lat: 3.4343333332e+01,
lng: 1.3602700000e+02,
cert : true,
content:'Name = JA/NR-015(JA/NR-015) peak = 1311.800049 pos = 34.3433,136.0270 diff = 189.200073'
});
data_saddle.push({
lat: 3.4346333332e+01,
lng: 1.3605822222e+02,
content:'Saddle = 1122.599976 pos = 34.3463,136.0582 diff = 189.200073'
});
data_peak.push({
lat: 3.4327111109e+01,
lng: 1.3611444444e+02,
cert : true,
content:'Name = JA/NR-008(JA/NR-008) peak = 1401.800049 pos = 34.3271,136.1144 diff = 198.400024'
});
data_saddle.push({
lat: 3.4338111109e+01,
lng: 1.3610122222e+02,
content:'Saddle = 1203.400024 pos = 34.3381,136.1012 diff = 198.400024'
});
data_peak.push({
lat: 3.4097666665e+01,
lng: 1.3608500000e+02,
cert : false,
content:' Peak = 1164.500000 pos = 34.0977,136.0850 diff = 160.400024'
});
data_saddle.push({
lat: 3.4102777776e+01,
lng: 1.3608966667e+02,
content:'Saddle = 1004.099976 pos = 34.1028,136.0897 diff = 160.400024'
});
data_peak.push({
lat: 3.4119777776e+01,
lng: 1.3605522222e+02,
cert : true,
content:'Name = JA/NR-017(JA/NR-017) peak = 1266.199951 pos = 34.1198,136.0552 diff = 236.000000'
});
data_saddle.push({
lat: 3.4133111109e+01,
lng: 1.3605177778e+02,
content:'Saddle = 1030.199951 pos = 34.1331,136.0518 diff = 236.000000'
});
data_peak.push({
lat: 3.4209444443e+01,
lng: 1.3613600000e+02,
cert : false,
content:' Peak = 1354.300049 pos = 34.2094,136.1360 diff = 162.500000'
});
data_saddle.push({
lat: 3.4206999998e+01,
lng: 1.3610688889e+02,
content:'Saddle = 1191.800049 pos = 34.2070,136.1069 diff = 162.500000'
});
data_peak.push({
lat: 3.4146444442e+01,
lng: 1.3606155556e+02,
cert : false,
content:' Peak = 1374.699951 pos = 34.1464,136.0616 diff = 169.099976'
});
data_saddle.push({
lat: 3.4157444442e+01,
lng: 1.3606444444e+02,
content:'Saddle = 1205.599976 pos = 34.1574,136.0644 diff = 169.099976'
});
data_peak.push({
lat: 3.4186444442e+01,
lng: 1.3615333333e+02,
cert : true,
content:'Name = JA/ME-003(JA/ME-003) peak = 1382.400024 pos = 34.1864,136.1533 diff = 171.400024'
});
data_saddle.push({
lat: 3.4168111109e+01,
lng: 1.3614222222e+02,
content:'Saddle = 1211.000000 pos = 34.1681,136.1422 diff = 171.400024'
});
data_peak.push({
lat: 3.5558555555e+01,
lng: 1.3693166667e+02,
cert : true,
content:'Name = JA/GF-196(JA/GF-196) peak = 434.000000 pos = 35.5586,136.9317 diff = 246.399994'
});
data_saddle.push({
lat: 3.5552222221e+01,
lng: 1.3694377778e+02,
content:'Saddle = 187.600006 pos = 35.5522,136.9438 diff = 246.399994'
});
data_peak.push({
lat: 3.4898444443e+01,
lng: 1.3757466667e+02,
cert : true,
content:'Name = JA/AC-029(JA/AC-029) peak = 481.600006 pos = 34.8984,137.5747 diff = 286.400024'
});
data_saddle.push({
lat: 3.4881777776e+01,
lng: 1.3757433333e+02,
content:'Saddle = 195.199997 pos = 34.8818,137.5743 diff = 286.400024'
});
data_peak.push({
lat: 3.5508999999e+01,
lng: 1.3703533333e+02,
cert : false,
content:' Peak = 356.399994 pos = 35.5090,137.0353 diff = 158.799988'
});
data_saddle.push({
lat: 3.5507111110e+01,
lng: 1.3704455556e+02,
content:'Saddle = 197.600006 pos = 35.5071,137.0446 diff = 158.799988'
});
data_peak.push({
lat: 3.5561111110e+01,
lng: 1.3686688889e+02,
cert : true,
content:'Name = JA/GF-188(JA/GF-188) peak = 537.200012 pos = 35.5611,136.8669 diff = 339.000000'
});
data_saddle.push({
lat: 3.5609222221e+01,
lng: 1.3680088889e+02,
content:'Saddle = 198.199997 pos = 35.6092,136.8009 diff = 339.000000'
});
data_peak.push({
lat: 3.5604111110e+01,
lng: 1.3680122222e+02,
cert : true,
content:'Name = JA/GF-193(JA/GF-193) peak = 442.899994 pos = 35.6041,136.8012 diff = 225.500000'
});
data_saddle.push({
lat: 3.5596222221e+01,
lng: 1.3679722222e+02,
content:'Saddle = 217.399994 pos = 35.5962,136.7972 diff = 225.500000'
});
data_peak.push({
lat: 3.5568777777e+01,
lng: 1.3682177778e+02,
cert : false,
content:' Peak = 520.900024 pos = 35.5688,136.8218 diff = 293.700012'
});
data_saddle.push({
lat: 3.5561111110e+01,
lng: 1.3683144444e+02,
content:'Saddle = 227.199997 pos = 35.5611,136.8314 diff = 293.700012'
});
data_peak.push({
lat: 3.5595444444e+01,
lng: 1.3683144444e+02,
cert : false,
content:' Peak = 467.000000 pos = 35.5954,136.8314 diff = 154.500000'
});
data_saddle.push({
lat: 3.5591999999e+01,
lng: 1.3682144444e+02,
content:'Saddle = 312.500000 pos = 35.5920,136.8214 diff = 154.500000'
});
data_peak.push({
lat: 3.5563666666e+01,
lng: 1.3683888889e+02,
cert : true,
content:'Name = JA/GF-190(JA/GF-190) peak = 514.500000 pos = 35.5637,136.8389 diff = 242.500000'
});
data_saddle.push({
lat: 3.5554555555e+01,
lng: 1.3685288889e+02,
content:'Saddle = 272.000000 pos = 35.5546,136.8529 diff = 242.500000'
});
data_peak.push({
lat: 3.5557444444e+01,
lng: 1.3688833333e+02,
cert : false,
content:' Peak = 501.000000 pos = 35.5574,136.8883 diff = 163.600006'
});
data_saddle.push({
lat: 3.5556444444e+01,
lng: 1.3688233333e+02,
content:'Saddle = 337.399994 pos = 35.5564,136.8823 diff = 163.600006'
});
data_peak.push({
lat: 3.5576333332e+01,
lng: 1.3702066667e+02,
cert : false,
content:' Peak = 357.700012 pos = 35.5763,137.0207 diff = 158.200012'
});
data_saddle.push({
lat: 3.5582222221e+01,
lng: 1.3702777778e+02,
content:'Saddle = 199.500000 pos = 35.5822,137.0278 diff = 158.200012'
});
data_peak.push({
lat: 3.4859666665e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 434.399994 pos = 34.8597,137.9999 diff = 234.899994'
});
data_saddle.push({
lat: 3.4874555554e+01,
lng: 1.3799988889e+02,
content:'Saddle = 199.500000 pos = 34.8746,137.9999 diff = 234.899994'
});
data_peak.push({
lat: 3.5524222221e+01,
lng: 1.3623044444e+02,
cert : true,
content:'Name = JA/SI-050(JA/SI-050) peak = 531.599976 pos = 35.5242,136.2304 diff = 326.099976'
});
data_saddle.push({
lat: 3.5547888888e+01,
lng: 1.3622188889e+02,
content:'Saddle = 205.500000 pos = 35.5479,136.2219 diff = 326.099976'
});
data_peak.push({
lat: 3.5543888888e+01,
lng: 1.3665977778e+02,
cert : true,
content:'Name = JA/GF-191(JA/GF-191) peak = 454.200012 pos = 35.5439,136.6598 diff = 247.500015'
});
data_saddle.push({
lat: 3.5559888888e+01,
lng: 1.3665722222e+02,
content:'Saddle = 206.699997 pos = 35.5599,136.6572 diff = 247.500015'
});
data_peak.push({
lat: 3.4956777776e+01,
lng: 1.3756077778e+02,
cert : true,
content:'Name = JA/AC-033(JA/AC-033) peak = 411.299988 pos = 34.9568,137.5608 diff = 203.599991'
});
data_saddle.push({
lat: 3.4963999999e+01,
lng: 1.3757111111e+02,
content:'Saddle = 207.699997 pos = 34.9640,137.5711 diff = 203.599991'
});
data_peak.push({
lat: 3.4852888887e+01,
lng: 1.3769100000e+02,
cert : true,
content:'Name = JA/SO-105(JA/SO-105) peak = 466.200012 pos = 34.8529,137.6910 diff = 253.500015'
});
data_saddle.push({
lat: 3.4868666665e+01,
lng: 1.3768188889e+02,
content:'Saddle = 212.699997 pos = 34.8687,137.6819 diff = 253.500015'
});
data_peak.push({
lat: 3.4877666665e+01,
lng: 1.3769188889e+02,
cert : true,
content:'Name = JA/SO-112(JA/SO-112) peak = 431.200012 pos = 34.8777,137.6919 diff = 218.400009'
});
data_saddle.push({
lat: 3.4879333332e+01,
lng: 1.3765422222e+02,
content:'Saddle = 212.800003 pos = 34.8793,137.6542 diff = 218.400009'
});
data_peak.push({
lat: 3.4882222221e+01,
lng: 1.3799900000e+02,
cert : false,
content:' Peak = 493.700012 pos = 34.8822,137.9990 diff = 276.500000'
});
data_saddle.push({
lat: 3.4890666665e+01,
lng: 1.3799855556e+02,
content:'Saddle = 217.199997 pos = 34.8907,137.9986 diff = 276.500000'
});
data_peak.push({
lat: 3.4849666665e+01,
lng: 1.3758711111e+02,
cert : false,
content:' Peak = 562.900024 pos = 34.8497,137.5871 diff = 345.100037'
});
data_saddle.push({
lat: 3.4895777776e+01,
lng: 1.3764188889e+02,
content:'Saddle = 217.800003 pos = 34.8958,137.6419 diff = 345.100037'
});
data_peak.push({
lat: 3.4847444443e+01,
lng: 1.3754688889e+02,
cert : true,
content:'Name = JA/SO-113(JA/SO-113) peak = 423.200012 pos = 34.8474,137.5469 diff = 185.400009'
});
data_saddle.push({
lat: 3.4851666665e+01,
lng: 1.3755477778e+02,
content:'Saddle = 237.800003 pos = 34.8517,137.5548 diff = 185.400009'
});
data_peak.push({
lat: 3.4822888887e+01,
lng: 1.3760866667e+02,
cert : true,
content:'Name = JA/SO-111(JA/SO-111) peak = 431.500000 pos = 34.8229,137.6087 diff = 164.399994'
});
data_saddle.push({
lat: 3.4831888887e+01,
lng: 1.3759100000e+02,
content:'Saddle = 267.100006 pos = 34.8319,137.5910 diff = 164.399994'
});
data_peak.push({
lat: 3.4881333332e+01,
lng: 1.3762400000e+02,
cert : true,
content:'Name = JA/SO-096(JA/SO-096) peak = 518.299988 pos = 34.8813,137.6240 diff = 220.899994'
});
data_saddle.push({
lat: 3.4859888887e+01,
lng: 1.3759544444e+02,
content:'Saddle = 297.399994 pos = 34.8599,137.5954 diff = 220.899994'
});
data_peak.push({
lat: 3.5466888888e+01,
lng: 1.3613555556e+02,
cert : true,
content:'Name = JA/SI-055(JA/SI-055) peak = 471.100006 pos = 35.4669,136.1356 diff = 248.400009'
});
data_saddle.push({
lat: 3.5497444444e+01,
lng: 1.3615544444e+02,
content:'Saddle = 222.699997 pos = 35.4974,136.1554 diff = 248.400009'
});
data_peak.push({
lat: 3.5484555555e+01,
lng: 1.3614522222e+02,
cert : false,
content:' Peak = 458.000000 pos = 35.4846,136.1452 diff = 169.899994'
});
data_saddle.push({
lat: 3.5473999999e+01,
lng: 1.3614255556e+02,
content:'Saddle = 288.100006 pos = 35.4740,136.1426 diff = 169.899994'
});
data_peak.push({
lat: 3.5514111110e+01,
lng: 1.3613866667e+02,
cert : true,
content:'Name = JA/SI-062(JA/SI-062) peak = 412.399994 pos = 35.5141,136.1387 diff = 186.199997'
});
data_saddle.push({
lat: 3.5557777777e+01,
lng: 1.3612644444e+02,
content:'Saddle = 226.199997 pos = 35.5578,136.1264 diff = 186.199997'
});
data_peak.push({
lat: 3.5542888888e+01,
lng: 1.3613600000e+02,
cert : true,
content:'Name = JA/SI-063(JA/SI-063) peak = 410.899994 pos = 35.5429,136.1360 diff = 168.299988'
});
data_saddle.push({
lat: 3.5528555555e+01,
lng: 1.3613800000e+02,
content:'Saddle = 242.600006 pos = 35.5286,136.1380 diff = 168.299988'
});
data_peak.push({
lat: 3.4946888888e+01,
lng: 1.3787300000e+02,
cert : false,
content:' Peak = 451.600006 pos = 34.9469,137.8730 diff = 225.100006'
});
data_saddle.push({
lat: 3.4936111110e+01,
lng: 1.3788077778e+02,
content:'Saddle = 226.500000 pos = 34.9361,137.8808 diff = 225.100006'
});
data_peak.push({
lat: 3.5515777777e+01,
lng: 1.3701988889e+02,
cert : false,
content:' Peak = 380.000000 pos = 35.5158,137.0199 diff = 153.300003'
});
data_saddle.push({
lat: 3.5528666666e+01,
lng: 1.3701844444e+02,
content:'Saddle = 226.699997 pos = 35.5287,137.0184 diff = 153.300003'
});
data_peak.push({
lat: 3.5549777777e+01,
lng: 1.3695922222e+02,
cert : true,
content:'Name = JA/GF-197(JA/GF-197) peak = 433.799988 pos = 35.5498,136.9592 diff = 204.999985'
});
data_saddle.push({
lat: 3.5553666666e+01,
lng: 1.3695844444e+02,
content:'Saddle = 228.800003 pos = 35.5537,136.9584 diff = 204.999985'
});
data_peak.push({
lat: 3.5691111110e+01,
lng: 1.3695400000e+02,
cert : true,
content:'Name = JA/GF-192(JA/GF-192) peak = 445.299988 pos = 35.6911,136.9540 diff = 209.199982'
});
data_saddle.push({
lat: 3.5693333333e+01,
lng: 1.3696322222e+02,
content:'Saddle = 236.100006 pos = 35.6933,136.9632 diff = 209.199982'
});
data_peak.push({
lat: 3.5524333332e+01,
lng: 1.3653788889e+02,
cert : true,
content:'Name = JA/GF-194(JA/GF-194) peak = 442.399994 pos = 35.5243,136.5379 diff = 205.599991'
});
data_saddle.push({
lat: 3.5532333332e+01,
lng: 1.3657344444e+02,
content:'Saddle = 236.800003 pos = 35.5323,136.5734 diff = 205.599991'
});
data_peak.push({
lat: 3.4900666665e+01,
lng: 1.3732255556e+02,
cert : true,
content:'Name = JA/AC-032(JA/AC-032) peak = 441.200012 pos = 34.9007,137.3226 diff = 203.900009'
});
data_saddle.push({
lat: 3.4888666665e+01,
lng: 1.3732844444e+02,
content:'Saddle = 237.300003 pos = 34.8887,137.3284 diff = 203.900009'
});
data_peak.push({
lat: 3.4895999999e+01,
lng: 1.3799511111e+02,
cert : false,
content:' Peak = 453.700012 pos = 34.8960,137.9951 diff = 216.300018'
});
data_saddle.push({
lat: 3.4903222221e+01,
lng: 1.3799977778e+02,
content:'Saddle = 237.399994 pos = 34.9032,137.9998 diff = 216.300018'
});
data_peak.push({
lat: 3.4922999999e+01,
lng: 1.3782355556e+02,
cert : false,
content:' Peak = 392.399994 pos = 34.9230,137.8236 diff = 154.899994'
});
data_saddle.push({
lat: 3.4927333332e+01,
lng: 1.3784488889e+02,
content:'Saddle = 237.500000 pos = 34.9273,137.8449 diff = 154.899994'
});
data_peak.push({
lat: 3.5352222221e+01,
lng: 1.3641300000e+02,
cert : false,
content:' Peak = 390.700012 pos = 35.3522,136.4130 diff = 152.900009'
});
data_saddle.push({
lat: 3.5376444443e+01,
lng: 1.3642177778e+02,
content:'Saddle = 237.800003 pos = 35.3764,136.4218 diff = 152.900009'
});
data_peak.push({
lat: 3.4927111110e+01,
lng: 1.3785822222e+02,
cert : true,
content:'Name = JA/SO-091(JA/SO-091) peak = 551.000000 pos = 34.9271,137.8582 diff = 304.399994'
});
data_saddle.push({
lat: 3.4926666665e+01,
lng: 1.3787866667e+02,
content:'Saddle = 246.600006 pos = 34.9267,137.8787 diff = 304.399994'
});
data_peak.push({
lat: 3.5649555555e+01,
lng: 1.3716122222e+02,
cert : false,
content:' Peak = 413.500000 pos = 35.6496,137.1612 diff = 158.399994'
});
data_saddle.push({
lat: 3.5653111110e+01,
lng: 1.3715400000e+02,
content:'Saddle = 255.100006 pos = 35.6531,137.1540 diff = 158.399994'
});
data_peak.push({
lat: 3.5465777777e+01,
lng: 1.3627344444e+02,
cert : false,
content:' Peak = 494.200012 pos = 35.4658,136.2734 diff = 238.400009'
});
data_saddle.push({
lat: 3.5473222221e+01,
lng: 1.3628577778e+02,
content:'Saddle = 255.800003 pos = 35.4732,136.2858 diff = 238.400009'
});
data_peak.push({
lat: 3.5589666666e+01,
lng: 1.3602455556e+02,
cert : true,
content:'Name = Nosakadake(JA/FI-028) peak = 913.099976 pos = 35.5897,136.0246 diff = 655.599976'
});
data_saddle.push({
lat: 3.5574888888e+01,
lng: 1.3612255556e+02,
content:'Saddle = 257.500000 pos = 35.5749,136.1226 diff = 655.599976'
});
data_peak.push({
lat: 3.5438222221e+01,
lng: 1.3600055556e+02,
cert : false,
content:' Peak = 490.700012 pos = 35.4382,136.0006 diff = 162.900024'
});
data_saddle.push({
lat: 3.5441111110e+01,
lng: 1.3600011111e+02,
content:'Saddle = 327.799988 pos = 35.4411,136.0001 diff = 162.900024'
});
data_peak.push({
lat: 3.5449555555e+01,
lng: 1.3600177778e+02,
cert : false,
content:' Peak = 512.099976 pos = 35.4496,136.0018 diff = 172.999969'
});
data_saddle.push({
lat: 3.5462777777e+01,
lng: 1.3600000000e+02,
content:'Saddle = 339.100006 pos = 35.4628,136.0000 diff = 172.999969'
});
data_peak.push({
lat: 3.5462555555e+01,
lng: 1.3609322222e+02,
cert : true,
content:'Name = JA/SI-048(JA/SI-048) peak = 591.200012 pos = 35.4626,136.0932 diff = 208.500000'
});
data_saddle.push({
lat: 3.5495666666e+01,
lng: 1.3610022222e+02,
content:'Saddle = 382.700012 pos = 35.4957,136.1002 diff = 208.500000'
});
data_peak.push({
lat: 3.5553111110e+01,
lng: 1.3610677778e+02,
cert : true,
content:'Name = JA/SI-043(JA/SI-043) peak = 653.400024 pos = 35.5531,136.1068 diff = 262.500031'
});
data_saddle.push({
lat: 3.5534999999e+01,
lng: 1.3609588889e+02,
content:'Saddle = 390.899994 pos = 35.5350,136.0959 diff = 262.500031'
});
data_peak.push({
lat: 3.5529666666e+01,
lng: 1.3602644444e+02,
cert : true,
content:'Name = JA/SI-021(JA/SI-021) peak = 874.099976 pos = 35.5297,136.0264 diff = 307.599976'
});
data_saddle.push({
lat: 3.5543555555e+01,
lng: 1.3602488889e+02,
content:'Saddle = 566.500000 pos = 35.5436,136.0249 diff = 307.599976'
});
data_peak.push({
lat: 3.5532555555e+01,
lng: 1.3607733333e+02,
cert : true,
content:'Name = JA/SI-023(JA/SI-023) peak = 864.400024 pos = 35.5326,136.0773 diff = 296.100037'
});
data_saddle.push({
lat: 3.5531888888e+01,
lng: 1.3603911111e+02,
content:'Saddle = 568.299988 pos = 35.5319,136.0391 diff = 296.100037'
});
data_peak.push({
lat: 3.5563777777e+01,
lng: 1.3602522222e+02,
cert : true,
content:'Name = JA/FI-031(JA/FI-031) peak = 865.599976 pos = 35.5638,136.0252 diff = 171.699951'
});
data_saddle.push({
lat: 3.5578555555e+01,
lng: 1.3602888889e+02,
content:'Saddle = 693.900024 pos = 35.5786,136.0289 diff = 171.699951'
});
data_peak.push({
lat: 3.4910111110e+01,
lng: 1.3735488889e+02,
cert : false,
content:' Peak = 480.100006 pos = 34.9101,137.3549 diff = 212.000000'
});
data_saddle.push({
lat: 3.4891111110e+01,
lng: 1.3735833333e+02,
content:'Saddle = 268.100006 pos = 34.8911,137.3583 diff = 212.000000'
});
data_peak.push({
lat: 3.5994222222e+01,
lng: 1.3639877778e+02,
cert : true,
content:'Name = JA/FI-072(JA/FI-072) peak = 464.200012 pos = 35.9942,136.3988 diff = 186.100006'
});
data_saddle.push({
lat: 3.5985777777e+01,
lng: 1.3640900000e+02,
content:'Saddle = 278.100006 pos = 35.9858,136.4090 diff = 186.100006'
});
data_peak.push({
lat: 3.5545222221e+01,
lng: 1.3709400000e+02,
cert : true,
content:'Name = JA/GF-181(JA/GF-181) peak = 631.299988 pos = 35.5452,137.0940 diff = 352.899994'
});
data_saddle.push({
lat: 3.5580444444e+01,
lng: 1.3706366667e+02,
content:'Saddle = 278.399994 pos = 35.5804,137.0637 diff = 352.899994'
});
data_peak.push({
lat: 3.5545888888e+01,
lng: 1.3705111111e+02,
cert : false,
content:' Peak = 553.799988 pos = 35.5459,137.0511 diff = 205.399994'
});
data_saddle.push({
lat: 3.5550888888e+01,
lng: 1.3705822222e+02,
content:'Saddle = 348.399994 pos = 35.5509,137.0582 diff = 205.399994'
});
data_peak.push({
lat: 3.5802333333e+01,
lng: 1.3621955556e+02,
cert : true,
content:'Name = JA/FI-069(JA/FI-069) peak = 491.299988 pos = 35.8023,136.2196 diff = 209.599976'
});
data_saddle.push({
lat: 3.5804222222e+01,
lng: 1.3623455556e+02,
content:'Saddle = 281.700012 pos = 35.8042,136.2346 diff = 209.599976'
});
data_peak.push({
lat: 3.4909111110e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 486.600006 pos = 34.9091,137.9999 diff = 202.500000'
});
data_saddle.push({
lat: 3.4916222221e+01,
lng: 1.3799977778e+02,
content:'Saddle = 284.100006 pos = 34.9162,137.9998 diff = 202.500000'
});
data_peak.push({
lat: 3.4970222221e+01,
lng: 1.3799455556e+02,
cert : false,
content:' Peak = 883.599976 pos = 34.9702,137.9946 diff = 574.399963'
});
data_saddle.push({
lat: 3.5032333332e+01,
lng: 1.3799988889e+02,
content:'Saddle = 309.200012 pos = 35.0323,137.9999 diff = 574.399963'
});
data_peak.push({
lat: 3.4901999999e+01,
lng: 1.3791933333e+02,
cert : false,
content:' Peak = 583.900024 pos = 34.9020,137.9193 diff = 244.700012'
});
data_saddle.push({
lat: 3.4941666665e+01,
lng: 1.3793088889e+02,
content:'Saddle = 339.200012 pos = 34.9417,137.9309 diff = 244.700012'
});
data_peak.push({
lat: 3.4928111110e+01,
lng: 1.3792455556e+02,
cert : false,
content:' Peak = 547.799988 pos = 34.9281,137.9246 diff = 159.000000'
});
data_saddle.push({
lat: 3.4908666665e+01,
lng: 1.3792411111e+02,
content:'Saddle = 388.799988 pos = 34.9087,137.9241 diff = 159.000000'
});
data_peak.push({
lat: 3.5016666665e+01,
lng: 1.3799833333e+02,
cert : false,
content:' Peak = 737.099976 pos = 35.0167,137.9983 diff = 338.899963'
});
data_saddle.push({
lat: 3.4997222221e+01,
lng: 1.3799977778e+02,
content:'Saddle = 398.200012 pos = 34.9972,137.9998 diff = 338.899963'
});
data_peak.push({
lat: 3.4936444443e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 802.000000 pos = 34.9364,137.9999 diff = 393.500000'
});
data_saddle.push({
lat: 3.4951555554e+01,
lng: 1.3799944444e+02,
content:'Saddle = 408.500000 pos = 34.9516,137.9994 diff = 393.500000'
});
data_peak.push({
lat: 3.4915777776e+01,
lng: 1.3797766667e+02,
cert : true,
content:'Name = JA/SO-077(JA/SO-077) peak = 627.700012 pos = 34.9158,137.9777 diff = 199.900024'
});
data_saddle.push({
lat: 3.4939555554e+01,
lng: 1.3798422222e+02,
content:'Saddle = 427.799988 pos = 34.9396,137.9842 diff = 199.900024'
});
data_peak.push({
lat: 3.4978222221e+01,
lng: 1.3794577778e+02,
cert : true,
content:'Name = JA/SO-075(JA/SO-075) peak = 657.500000 pos = 34.9782,137.9458 diff = 194.899994'
});
data_saddle.push({
lat: 3.4971999999e+01,
lng: 1.3797544444e+02,
content:'Saddle = 462.600006 pos = 34.9720,137.9754 diff = 194.899994'
});
data_peak.push({
lat: 3.4987777776e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 710.700012 pos = 34.9878,137.9999 diff = 214.000000'
});
data_saddle.push({
lat: 3.4980444443e+01,
lng: 1.3799988889e+02,
content:'Saddle = 496.700012 pos = 34.9804,137.9999 diff = 214.000000'
});
data_peak.push({
lat: 3.4946999999e+01,
lng: 1.3796111111e+02,
cert : false,
content:' Peak = 656.900024 pos = 34.9470,137.9611 diff = 155.500031'
});
data_saddle.push({
lat: 3.4954777776e+01,
lng: 1.3796444444e+02,
content:'Saddle = 501.399994 pos = 34.9548,137.9644 diff = 155.500031'
});
data_peak.push({
lat: 3.6201777777e+01,
lng: 1.3632955556e+02,
cert : true,
content:'Name = JA/IK-015(JA/IK-015) peak = 628.900024 pos = 36.2018,136.3296 diff = 316.100037'
});
data_saddle.push({
lat: 3.6178444444e+01,
lng: 1.3634055556e+02,
content:'Saddle = 312.799988 pos = 36.1784,136.3406 diff = 316.100037'
});
data_peak.push({
lat: 3.5571222221e+01,
lng: 1.3620333333e+02,
cert : false,
content:' Peak = 482.500000 pos = 35.5712,136.2033 diff = 164.399994'
});
data_saddle.push({
lat: 3.5577111110e+01,
lng: 1.3620355556e+02,
content:'Saddle = 318.100006 pos = 35.5771,136.2036 diff = 164.399994'
});
data_peak.push({
lat: 3.5639777777e+01,
lng: 1.3613366667e+02,
cert : true,
content:'Name = JA/FI-057(JA/FI-057) peak = 646.099976 pos = 35.6398,136.1337 diff = 324.799988'
});
data_saddle.push({
lat: 3.5655444444e+01,
lng: 1.3612722222e+02,
content:'Saddle = 321.299988 pos = 35.6554,136.1272 diff = 324.799988'
});
data_peak.push({
lat: 3.5540999999e+01,
lng: 1.3624455556e+02,
cert : false,
content:' Peak = 504.399994 pos = 35.5410,136.2446 diff = 182.100006'
});
data_saddle.push({
lat: 3.5562888888e+01,
lng: 1.3624088889e+02,
content:'Saddle = 322.299988 pos = 35.5629,136.2409 diff = 182.100006'
});
data_peak.push({
lat: 3.5043555554e+01,
lng: 1.3781333333e+02,
cert : true,
content:'Name = JA/SO-042(JA/SO-042) peak = 1057.900024 pos = 35.0436,137.8133 diff = 735.400024'
});
data_saddle.push({
lat: 3.5020666665e+01,
lng: 1.3769555556e+02,
content:'Saddle = 322.500000 pos = 35.0207,137.6956 diff = 735.400024'
});
data_peak.push({
lat: 3.4984777776e+01,
lng: 1.3765033333e+02,
cert : true,
content:'Name = JA/AC-027(JA/AC-027) peak = 582.299988 pos = 34.9848,137.6503 diff = 224.799988'
});
data_saddle.push({
lat: 3.4964555554e+01,
lng: 1.3765355556e+02,
content:'Saddle = 357.500000 pos = 34.9646,137.6536 diff = 224.799988'
});
data_peak.push({
lat: 3.4947222221e+01,
lng: 1.3774655556e+02,
cert : true,
content:'Name = JA/SO-076(JA/SO-076) peak = 657.099976 pos = 34.9472,137.7466 diff = 295.199982'
});
data_saddle.push({
lat: 3.4956888888e+01,
lng: 1.3773266667e+02,
content:'Saddle = 361.899994 pos = 34.9569,137.7327 diff = 295.199982'
});
data_peak.push({
lat: 3.4962666665e+01,
lng: 1.3781388889e+02,
cert : false,
content:' Peak = 563.200012 pos = 34.9627,137.8139 diff = 151.800018'
});
data_saddle.push({
lat: 3.4969111110e+01,
lng: 1.3779255556e+02,
content:'Saddle = 411.399994 pos = 34.9691,137.7926 diff = 151.800018'
});
data_peak.push({
lat: 3.4900111110e+01,
lng: 1.3774444444e+02,
cert : true,
content:'Name = JA/SO-084(JA/SO-084) peak = 574.000000 pos = 34.9001,137.7444 diff = 161.000000'
});
data_saddle.push({
lat: 3.4931888888e+01,
lng: 1.3770255556e+02,
content:'Saddle = 413.000000 pos = 34.9319,137.7026 diff = 161.000000'
});
data_peak.push({
lat: 3.4932888888e+01,
lng: 1.3765077778e+02,
cert : false,
content:' Peak = 677.700012 pos = 34.9329,137.6508 diff = 238.900024'
});
data_saddle.push({
lat: 3.4951777776e+01,
lng: 1.3768066667e+02,
content:'Saddle = 438.799988 pos = 34.9518,137.6807 diff = 238.900024'
});
data_peak.push({
lat: 3.5003555554e+01,
lng: 1.3770088889e+02,
cert : true,
content:'Name = JA/SO-067(JA/SO-067) peak = 711.099976 pos = 35.0036,137.7009 diff = 212.599976'
});
data_saddle.push({
lat: 3.4982777776e+01,
lng: 1.3770088889e+02,
content:'Saddle = 498.500000 pos = 34.9828,137.7009 diff = 212.599976'
});
data_peak.push({
lat: 3.4955555554e+01,
lng: 1.3777088889e+02,
cert : false,
content:' Peak = 712.599976 pos = 34.9556,137.7709 diff = 189.000000'
});
data_saddle.push({
lat: 3.4966333332e+01,
lng: 1.3775122222e+02,
content:'Saddle = 523.599976 pos = 34.9663,137.7512 diff = 189.000000'
});
data_peak.push({
lat: 3.4990999999e+01,
lng: 1.3781555556e+02,
cert : false,
content:' Peak = 772.799988 pos = 34.9910,137.8156 diff = 185.000000'
});
data_saddle.push({
lat: 3.5003333332e+01,
lng: 1.3780455556e+02,
content:'Saddle = 587.799988 pos = 35.0033,137.8046 diff = 185.000000'
});
data_peak.push({
lat: 3.4982333332e+01,
lng: 1.3775344444e+02,
cert : false,
content:' Peak = 840.700012 pos = 34.9823,137.7534 diff = 192.900024'
});
data_saddle.push({
lat: 3.4988999999e+01,
lng: 1.3775577778e+02,
content:'Saddle = 647.799988 pos = 34.9890,137.7558 diff = 192.900024'
});
data_peak.push({
lat: 3.5013333332e+01,
lng: 1.3777211111e+02,
cert : false,
content:' Peak = 1052.599976 pos = 35.0133,137.7721 diff = 365.500000'
});
data_saddle.push({
lat: 3.5034111110e+01,
lng: 1.3779500000e+02,
content:'Saddle = 687.099976 pos = 35.0341,137.7950 diff = 365.500000'
});
data_peak.push({
lat: 3.6390777778e+01,
lng: 1.3659455556e+02,
cert : true,
content:'Name = JA/IK-019(JA/IK-019) peak = 511.899994 pos = 36.3908,136.5946 diff = 188.699982'
});
data_saddle.push({
lat: 3.6366333333e+01,
lng: 1.3658411111e+02,
content:'Saddle = 323.200012 pos = 36.3663,136.5841 diff = 188.699982'
});
data_peak.push({
lat: 3.6545333333e+01,
lng: 1.3710166667e+02,
cert : false,
content:' Peak = 481.200012 pos = 36.5453,137.1017 diff = 154.100006'
});
data_saddle.push({
lat: 3.6531000000e+01,
lng: 1.3709666667e+02,
content:'Saddle = 327.100006 pos = 36.5310,137.0967 diff = 154.100006'
});
data_peak.push({
lat: 3.5842444444e+01,
lng: 1.3608477778e+02,
cert : false,
content:' Peak = 483.500000 pos = 35.8424,136.0848 diff = 154.100006'
});
data_saddle.push({
lat: 3.5845444444e+01,
lng: 1.3611922222e+02,
content:'Saddle = 329.399994 pos = 35.8454,136.1192 diff = 154.100006'
});
data_peak.push({
lat: 3.5080111110e+01,
lng: 1.3784788889e+02,
cert : false,
content:' Peak = 539.000000 pos = 35.0801,137.8479 diff = 202.500000'
});
data_saddle.push({
lat: 3.5084333332e+01,
lng: 1.3784377778e+02,
content:'Saddle = 336.500000 pos = 35.0843,137.8438 diff = 202.500000'
});
data_peak.push({
lat: 3.5602555555e+01,
lng: 1.3666333333e+02,
cert : true,
content:'Name = JA/GF-165(JA/GF-165) peak = 744.000000 pos = 35.6026,136.6633 diff = 406.700012'
});
data_saddle.push({
lat: 3.5620444444e+01,
lng: 1.3666811111e+02,
content:'Saddle = 337.299988 pos = 35.6204,136.6681 diff = 406.700012'
});
data_peak.push({
lat: 3.5973888888e+01,
lng: 1.3633300000e+02,
cert : true,
content:'Name = JA/FI-042(JA/FI-042) peak = 740.400024 pos = 35.9739,136.3330 diff = 402.800018'
});
data_saddle.push({
lat: 3.5864444444e+01,
lng: 1.3628533333e+02,
content:'Saddle = 337.600006 pos = 35.8644,136.2853 diff = 402.800018'
});
data_peak.push({
lat: 3.5905333333e+01,
lng: 1.3632044444e+02,
cert : true,
content:'Name = JA/FI-047(JA/FI-047) peak = 700.700012 pos = 35.9053,136.3204 diff = 308.300018'
});
data_saddle.push({
lat: 3.5920666666e+01,
lng: 1.3632577778e+02,
content:'Saddle = 392.399994 pos = 35.9207,136.3258 diff = 308.300018'
});
data_peak.push({
lat: 3.5873777777e+01,
lng: 1.3630511111e+02,
cert : true,
content:'Name = JA/FI-059(JA/FI-059) peak = 620.299988 pos = 35.8738,136.3051 diff = 197.000000'
});
data_saddle.push({
lat: 3.5883999999e+01,
lng: 1.3630688889e+02,
content:'Saddle = 423.299988 pos = 35.8840,136.3069 diff = 197.000000'
});
data_peak.push({
lat: 3.6276222222e+01,
lng: 1.3649777778e+02,
cert : true,
content:'Name = Yurugiyama(JA/IK-016) peak = 603.799988 pos = 36.2762,136.4978 diff = 261.099976'
});
data_saddle.push({
lat: 3.6266444444e+01,
lng: 1.3651988889e+02,
content:'Saddle = 342.700012 pos = 36.2664,136.5199 diff = 261.099976'
});
data_peak.push({
lat: 3.5015888888e+01,
lng: 1.3753900000e+02,
cert : true,
content:'Name = JA/AC-028(JA/AC-028) peak = 523.099976 pos = 35.0159,137.5390 diff = 175.499969'
});
data_saddle.push({
lat: 3.5050444443e+01,
lng: 1.3755566667e+02,
content:'Saddle = 347.600006 pos = 35.0504,137.5557 diff = 175.499969'
});
data_peak.push({
lat: 3.5604333333e+01,
lng: 1.3705611111e+02,
cert : true,
content:'Name = JA/GF-183(JA/GF-183) peak = 596.599976 pos = 35.6043,137.0561 diff = 248.099976'
});
data_saddle.push({
lat: 3.5609111110e+01,
lng: 1.3705933333e+02,
content:'Saddle = 348.500000 pos = 35.6091,137.0593 diff = 248.099976'
});
data_peak.push({
lat: 3.5453333332e+01,
lng: 1.3729900000e+02,
cert : false,
content:' Peak = 661.200012 pos = 35.4533,137.2990 diff = 303.300018'
});
data_saddle.push({
lat: 3.5443888888e+01,
lng: 1.3737888889e+02,
content:'Saddle = 357.899994 pos = 35.4439,137.3789 diff = 303.300018'
});
data_peak.push({
lat: 3.5456444444e+01,
lng: 1.3734822222e+02,
cert : true,
content:'Name = JA/GF-185(JA/GF-185) peak = 574.799988 pos = 35.4564,137.3482 diff = 197.599976'
});
data_saddle.push({
lat: 3.5457555555e+01,
lng: 1.3731244444e+02,
content:'Saddle = 377.200012 pos = 35.4576,137.3124 diff = 197.599976'
});
data_peak.push({
lat: 3.5435888888e+01,
lng: 1.3729222222e+02,
cert : false,
content:' Peak = 631.200012 pos = 35.4359,137.2922 diff = 154.800018'
});
data_saddle.push({
lat: 3.5434888888e+01,
lng: 1.3730277778e+02,
content:'Saddle = 476.399994 pos = 35.4349,137.3028 diff = 154.800018'
});
data_peak.push({
lat: 3.5201888888e+01,
lng: 1.3717244444e+02,
cert : true,
content:'Name = JA/AC-025(JA/AC-025) peak = 631.599976 pos = 35.2019,137.1724 diff = 273.599976'
});
data_saddle.push({
lat: 3.5216333332e+01,
lng: 1.3717300000e+02,
content:'Saddle = 358.000000 pos = 35.2163,137.1730 diff = 273.599976'
});
data_peak.push({
lat: 3.5601555555e+01,
lng: 1.3718622222e+02,
cert : true,
content:'Name = JA/GF-177(JA/GF-177) peak = 663.700012 pos = 35.6016,137.1862 diff = 289.600006'
});
data_saddle.push({
lat: 3.5604111110e+01,
lng: 1.3719777778e+02,
content:'Saddle = 374.100006 pos = 35.6041,137.1978 diff = 289.600006'
});
data_peak.push({
lat: 3.5794555555e+01,
lng: 1.3614888889e+02,
cert : true,
content:'Name = JA/FI-041(JA/FI-041) peak = 745.200012 pos = 35.7946,136.1489 diff = 358.400024'
});
data_saddle.push({
lat: 3.5769666666e+01,
lng: 1.3611411111e+02,
content:'Saddle = 386.799988 pos = 35.7697,136.1141 diff = 358.400024'
});
data_peak.push({
lat: 3.5574999999e+01,
lng: 1.3716700000e+02,
cert : true,
content:'Name = JA/GF-167(JA/GF-167) peak = 742.299988 pos = 35.5750,137.1670 diff = 355.299988'
});
data_saddle.push({
lat: 3.5634999999e+01,
lng: 1.3709277778e+02,
content:'Saddle = 387.000000 pos = 35.6350,137.0928 diff = 355.299988'
});
data_peak.push({
lat: 3.5631333333e+01,
lng: 1.3709077778e+02,
cert : false,
content:' Peak = 552.099976 pos = 35.6313,137.0908 diff = 152.699982'
});
data_saddle.push({
lat: 3.5626777777e+01,
lng: 1.3709388889e+02,
content:'Saddle = 399.399994 pos = 35.6268,137.0939 diff = 152.699982'
});
data_peak.push({
lat: 3.5621666666e+01,
lng: 1.3713877778e+02,
cert : true,
content:'Name = JA/GF-174(JA/GF-174) peak = 687.099976 pos = 35.6217,137.1388 diff = 214.499969'
});
data_saddle.push({
lat: 3.5607999999e+01,
lng: 1.3713766667e+02,
content:'Saddle = 472.600006 pos = 35.6080,137.1377 diff = 214.499969'
});
data_peak.push({
lat: 3.5620333333e+01,
lng: 1.3711955556e+02,
cert : false,
content:' Peak = 650.900024 pos = 35.6203,137.1196 diff = 168.200012'
});
data_saddle.push({
lat: 3.5612888888e+01,
lng: 1.3713166667e+02,
content:'Saddle = 482.700012 pos = 35.6129,137.1317 diff = 168.200012'
});
data_peak.push({
lat: 3.5614555555e+01,
lng: 1.3715566667e+02,
cert : false,
content:' Peak = 662.900024 pos = 35.6146,137.1557 diff = 166.200012'
});
data_saddle.push({
lat: 3.5600888888e+01,
lng: 1.3714822222e+02,
content:'Saddle = 496.700012 pos = 35.6009,137.1482 diff = 166.200012'
});
data_peak.push({
lat: 3.5573333332e+01,
lng: 1.3713388889e+02,
cert : false,
content:' Peak = 673.900024 pos = 35.5733,137.1339 diff = 150.700012'
});
data_saddle.push({
lat: 3.5576777777e+01,
lng: 1.3714266667e+02,
content:'Saddle = 523.200012 pos = 35.5768,137.1427 diff = 150.700012'
});
data_peak.push({
lat: 3.5590111110e+01,
lng: 1.3715744444e+02,
cert : false,
content:' Peak = 707.400024 pos = 35.5901,137.1574 diff = 155.400024'
});
data_saddle.push({
lat: 3.5583666666e+01,
lng: 1.3715922222e+02,
content:'Saddle = 552.000000 pos = 35.5837,137.1592 diff = 155.400024'
});
data_peak.push({
lat: 3.5618999999e+01,
lng: 1.3698644444e+02,
cert : true,
content:'Name = JA/GF-186(JA/GF-186) peak = 567.400024 pos = 35.6190,136.9864 diff = 179.300018'
});
data_saddle.push({
lat: 3.5631333333e+01,
lng: 1.3698333333e+02,
content:'Saddle = 388.100006 pos = 35.6313,136.9833 diff = 179.300018'
});
data_peak.push({
lat: 3.5059777777e+01,
lng: 1.3774533333e+02,
cert : true,
content:'Name = JA/SO-094(JA/SO-094) peak = 543.599976 pos = 35.0598,137.7453 diff = 152.099976'
});
data_saddle.push({
lat: 3.5056888888e+01,
lng: 1.3773233333e+02,
content:'Saddle = 391.500000 pos = 35.0569,137.7323 diff = 152.099976'
});
data_peak.push({
lat: 3.6531222222e+01,
lng: 1.3674688889e+02,
cert : false,
content:' Peak = 546.799988 pos = 36.5312,136.7469 diff = 154.299988'
});
data_saddle.push({
lat: 3.6528555555e+01,
lng: 1.3675211111e+02,
content:'Saddle = 392.500000 pos = 36.5286,136.7521 diff = 154.299988'
});
data_peak.push({
lat: 3.5586666666e+01,
lng: 1.3616244444e+02,
cert : false,
content:' Peak = 663.000000 pos = 35.5867,136.1624 diff = 265.200012'
});
data_saddle.push({
lat: 3.5594111110e+01,
lng: 1.3617633333e+02,
content:'Saddle = 397.799988 pos = 35.5941,136.1763 diff = 265.200012'
});
data_peak.push({
lat: 3.6256111111e+01,
lng: 1.3646855556e+02,
cert : false,
content:' Peak = 557.099976 pos = 36.2561,136.4686 diff = 155.099976'
});
data_saddle.push({
lat: 3.6245111111e+01,
lng: 1.3647400000e+02,
content:'Saddle = 402.000000 pos = 36.2451,136.4740 diff = 155.099976'
});
data_peak.push({
lat: 3.5656777777e+01,
lng: 1.3713844444e+02,
cert : false,
content:' Peak = 564.700012 pos = 35.6568,137.1384 diff = 162.200012'
});
data_saddle.push({
lat: 3.5658444444e+01,
lng: 1.3713366667e+02,
content:'Saddle = 402.500000 pos = 35.6584,137.1337 diff = 162.200012'
});
data_peak.push({
lat: 3.5973999999e+01,
lng: 1.3639944444e+02,
cert : true,
content:'Name = JA/FI-056(JA/FI-056) peak = 651.799988 pos = 35.9740,136.3994 diff = 249.299988'
});
data_saddle.push({
lat: 3.5972888888e+01,
lng: 1.3642966667e+02,
content:'Saddle = 402.500000 pos = 35.9729,136.4297 diff = 249.299988'
});
data_peak.push({
lat: 3.5728666666e+01,
lng: 1.3696266667e+02,
cert : false,
content:' Peak = 618.000000 pos = 35.7287,136.9627 diff = 213.799988'
});
data_saddle.push({
lat: 3.5736444444e+01,
lng: 1.3696488889e+02,
content:'Saddle = 404.200012 pos = 35.7364,136.9649 diff = 213.799988'
});
data_peak.push({
lat: 3.5423777777e+01,
lng: 1.3635733333e+02,
cert : true,
content:'Name = JA/SI-039(JA/SI-039) peak = 690.500000 pos = 35.4238,136.3573 diff = 283.500000'
});
data_saddle.push({
lat: 3.5459666666e+01,
lng: 1.3634300000e+02,
content:'Saddle = 407.000000 pos = 35.4597,136.3430 diff = 283.500000'
});
data_peak.push({
lat: 3.5066999999e+01,
lng: 1.3771455556e+02,
cert : false,
content:' Peak = 580.299988 pos = 35.0670,137.7146 diff = 173.199982'
});
data_saddle.push({
lat: 3.5062555554e+01,
lng: 1.3770588889e+02,
content:'Saddle = 407.100006 pos = 35.0626,137.7059 diff = 173.199982'
});
data_peak.push({
lat: 3.5640555555e+01,
lng: 1.3709555556e+02,
cert : true,
content:'Name = JA/GF-182(JA/GF-182) peak = 604.099976 pos = 35.6406,137.0956 diff = 196.899963'
});
data_saddle.push({
lat: 3.5644222221e+01,
lng: 1.3709300000e+02,
content:'Saddle = 407.200012 pos = 35.6442,137.0930 diff = 196.899963'
});
data_peak.push({
lat: 3.6221444444e+01,
lng: 1.3641811111e+02,
cert : true,
content:'Name = JA/IK-011(JA/IK-011) peak = 687.700012 pos = 36.2214,136.4181 diff = 276.900024'
});
data_saddle.push({
lat: 3.6231111111e+01,
lng: 1.3645755556e+02,
content:'Saddle = 410.799988 pos = 36.2311,136.4576 diff = 276.900024'
});
data_peak.push({
lat: 3.6311444444e+01,
lng: 1.3659088889e+02,
cert : false,
content:' Peak = 682.200012 pos = 36.3114,136.5909 diff = 270.800018'
});
data_saddle.push({
lat: 3.6237888889e+01,
lng: 1.3652877778e+02,
content:'Saddle = 411.399994 pos = 36.2379,136.5288 diff = 270.800018'
});
data_peak.push({
lat: 3.6284333333e+01,
lng: 1.3654855556e+02,
cert : true,
content:'Name = Ookuradake(JA/IK-013) peak = 651.099976 pos = 36.2843,136.5486 diff = 209.099976'
});
data_saddle.push({
lat: 3.6300555555e+01,
lng: 1.3655988889e+02,
content:'Saddle = 442.000000 pos = 36.3006,136.5599 diff = 209.099976'
});
data_peak.push({
lat: 3.6264777777e+01,
lng: 1.3654633333e+02,
cert : false,
content:' Peak = 613.200012 pos = 36.2648,136.5463 diff = 150.700012'
});
data_saddle.push({
lat: 3.6279888889e+01,
lng: 1.3654322222e+02,
content:'Saddle = 462.500000 pos = 36.2799,136.5432 diff = 150.700012'
});
data_peak.push({
lat: 3.4984111110e+01,
lng: 1.3758277778e+02,
cert : true,
content:'Name = Houraijisan(JA/AC-022) peak = 692.299988 pos = 34.9841,137.5828 diff = 280.899994'
});
data_saddle.push({
lat: 3.4997444443e+01,
lng: 1.3758233333e+02,
content:'Saddle = 411.399994 pos = 34.9974,137.5823 diff = 280.899994'
});
data_peak.push({
lat: 3.5652999999e+01,
lng: 1.3701133333e+02,
cert : true,
content:'Name = JA/GF-184(JA/GF-184) peak = 590.599976 pos = 35.6530,137.0113 diff = 163.199982'
});
data_saddle.push({
lat: 3.5671666666e+01,
lng: 1.3699333333e+02,
content:'Saddle = 427.399994 pos = 35.6717,136.9933 diff = 163.199982'
});
data_peak.push({
lat: 3.5060333332e+01,
lng: 1.3730277778e+02,
cert : true,
content:'Name = JA/AC-024(JA/AC-024) peak = 683.099976 pos = 35.0603,137.3028 diff = 255.499969'
});
data_saddle.push({
lat: 3.5044777777e+01,
lng: 1.3733322222e+02,
content:'Saddle = 427.600006 pos = 35.0448,137.3332 diff = 255.499969'
});
data_peak.push({
lat: 3.5054999999e+01,
lng: 1.3728422222e+02,
cert : true,
content:'Name = JA/AC-026(JA/AC-026) peak = 610.799988 pos = 35.0550,137.2842 diff = 181.500000'
});
data_saddle.push({
lat: 3.5053888888e+01,
lng: 1.3729255556e+02,
content:'Saddle = 429.299988 pos = 35.0539,137.2926 diff = 181.500000'
});
data_peak.push({
lat: 3.6512777778e+01,
lng: 1.3679600000e+02,
cert : true,
content:'Name = Iouzen (Okuiouzen)(JA/TY-047) peak = 938.400024 pos = 36.5128,136.7960 diff = 501.700012'
});
data_saddle.push({
lat: 3.6466000000e+01,
lng: 1.3679588889e+02,
content:'Saddle = 436.700012 pos = 36.4660,136.7959 diff = 501.700012'
});
data_peak.push({
lat: 3.5544888888e+01,
lng: 1.3659611111e+02,
cert : true,
content:'Name = JA/GF-176(JA/GF-176) peak = 662.799988 pos = 35.5449,136.5961 diff = 224.599976'
});
data_saddle.push({
lat: 3.5562555555e+01,
lng: 1.3656855556e+02,
content:'Saddle = 438.200012 pos = 35.5626,136.5686 diff = 224.599976'
});
data_peak.push({
lat: 3.5653111110e+01,
lng: 1.3722611111e+02,
cert : false,
content:' Peak = 613.099976 pos = 35.6531,137.2261 diff = 163.699982'
});
data_saddle.push({
lat: 3.5658999999e+01,
lng: 1.3722822222e+02,
content:'Saddle = 449.399994 pos = 35.6590,137.2282 diff = 163.699982'
});
data_peak.push({
lat: 3.5863555555e+01,
lng: 1.3634677778e+02,
cert : false,
content:' Peak = 653.500000 pos = 35.8636,136.3468 diff = 201.600006'
});
data_saddle.push({
lat: 3.5855666666e+01,
lng: 1.3634233333e+02,
content:'Saddle = 451.899994 pos = 35.8557,136.3423 diff = 201.600006'
});
data_peak.push({
lat: 3.5254888888e+01,
lng: 1.3719011111e+02,
cert : true,
content:'Name = Mikuniyama(JA/AC-021) peak = 700.799988 pos = 35.2549,137.1901 diff = 244.899994'
});
data_saddle.push({
lat: 3.5258999999e+01,
lng: 1.3721022222e+02,
content:'Saddle = 455.899994 pos = 35.2590,137.2102 diff = 244.899994'
});
data_peak.push({
lat: 3.5680888888e+01,
lng: 1.3710933333e+02,
cert : true,
content:'Name = JA/GF-172(JA/GF-172) peak = 703.099976 pos = 35.6809,137.1093 diff = 245.899963'
});
data_saddle.push({
lat: 3.5678333333e+01,
lng: 1.3708200000e+02,
content:'Saddle = 457.200012 pos = 35.6783,137.0820 diff = 245.899963'
});
data_peak.push({
lat: 3.5660111110e+01,
lng: 1.3710944444e+02,
cert : true,
content:'Name = JA/GF-178(JA/GF-178) peak = 663.299988 pos = 35.6601,137.1094 diff = 195.299988'
});
data_saddle.push({
lat: 3.5663555555e+01,
lng: 1.3710000000e+02,
content:'Saddle = 468.000000 pos = 35.6636,137.1000 diff = 195.299988'
});
data_peak.push({
lat: 3.4940777776e+01,
lng: 1.3749300000e+02,
cert : true,
content:'Name = JA/AC-023(JA/AC-023) peak = 687.200012 pos = 34.9408,137.4930 diff = 229.100006'
});
data_saddle.push({
lat: 3.4919888888e+01,
lng: 1.3744688889e+02,
content:'Saddle = 458.100006 pos = 34.9199,137.4469 diff = 229.100006'
});
data_peak.push({
lat: 3.5840333333e+01,
lng: 1.3689511111e+02,
cert : true,
content:'Name = JA/GF-180(JA/GF-180) peak = 639.400024 pos = 35.8403,136.8951 diff = 181.000031'
});
data_saddle.push({
lat: 3.5865666666e+01,
lng: 1.3689922222e+02,
content:'Saddle = 458.399994 pos = 35.8657,136.8992 diff = 181.000031'
});
data_peak.push({
lat: 3.5859222222e+01,
lng: 1.3620744444e+02,
cert : true,
content:'Name = Hinosan(JA/FI-034) peak = 793.799988 pos = 35.8592,136.2074 diff = 312.000000'
});
data_saddle.push({
lat: 3.5856222222e+01,
lng: 1.3622100000e+02,
content:'Saddle = 481.799988 pos = 35.8562,136.2210 diff = 312.000000'
});
data_peak.push({
lat: 3.6476555555e+01,
lng: 1.3685511111e+02,
cert : false,
content:' Peak = 633.400024 pos = 36.4766,136.8551 diff = 151.400024'
});
data_saddle.push({
lat: 3.6452222222e+01,
lng: 1.3686600000e+02,
content:'Saddle = 482.000000 pos = 36.4522,136.8660 diff = 151.400024'
});
data_peak.push({
lat: 3.5521888888e+01,
lng: 1.3716188889e+02,
cert : true,
content:'Name = JA/GF-175(JA/GF-175) peak = 684.900024 pos = 35.5219,137.1619 diff = 191.800018'
});
data_saddle.push({
lat: 3.5524666666e+01,
lng: 1.3717588889e+02,
content:'Saddle = 493.100006 pos = 35.5247,137.1759 diff = 191.800018'
});
data_peak.push({
lat: 3.5280666666e+01,
lng: 1.3726088889e+02,
cert : true,
content:'Name = JA/AC-020(JA/AC-020) peak = 723.299988 pos = 35.2807,137.2609 diff = 226.799988'
});
data_saddle.push({
lat: 3.5289444443e+01,
lng: 1.3729955556e+02,
content:'Saddle = 496.500000 pos = 35.2894,137.2996 diff = 226.799988'
});
data_peak.push({
lat: 3.5578666666e+01,
lng: 1.3624744444e+02,
cert : true,
content:'Name = JA/SI-036(JA/SI-036) peak = 734.599976 pos = 35.5787,136.2474 diff = 233.599976'
});
data_saddle.push({
lat: 3.5586777777e+01,
lng: 1.3625666667e+02,
content:'Saddle = 501.000000 pos = 35.5868,136.2567 diff = 233.599976'
});
data_peak.push({
lat: 3.5550888888e+01,
lng: 1.3653611111e+02,
cert : true,
content:'Name = JA/GF-170(JA/GF-170) peak = 721.400024 pos = 35.5509,136.5361 diff = 217.700012'
});
data_saddle.push({
lat: 3.5566666666e+01,
lng: 1.3654177778e+02,
content:'Saddle = 503.700012 pos = 35.5667,136.5418 diff = 217.700012'
});
data_peak.push({
lat: 3.5617444444e+01,
lng: 1.3619400000e+02,
cert : true,
content:'Name = JA/SI-018(JA/SI-018) peak = 900.900024 pos = 35.6174,136.1940 diff = 396.600037'
});
data_saddle.push({
lat: 3.5639444444e+01,
lng: 1.3616255556e+02,
content:'Saddle = 504.299988 pos = 35.6394,136.1626 diff = 396.600037'
});
data_peak.push({
lat: 3.5643444444e+01,
lng: 1.3617255556e+02,
cert : true,
content:'Name = JA/SI-020(JA/SI-020) peak = 891.000000 pos = 35.6434,136.1726 diff = 208.299988'
});
data_saddle.push({
lat: 3.5625111110e+01,
lng: 1.3618166667e+02,
content:'Saddle = 682.700012 pos = 35.6251,136.1817 diff = 208.299988'
});
data_peak.push({
lat: 3.5067222221e+01,
lng: 1.3785533333e+02,
cert : true,
content:'Name = JA/SO-073(JA/SO-073) peak = 677.000000 pos = 35.0672,137.8553 diff = 171.700012'
});
data_saddle.push({
lat: 3.5070111110e+01,
lng: 1.3786377778e+02,
content:'Saddle = 505.299988 pos = 35.0701,137.8638 diff = 171.700012'
});
data_peak.push({
lat: 3.5428333332e+01,
lng: 1.3744522222e+02,
cert : true,
content:'Name = JA/GF-173(JA/GF-173) peak = 701.299988 pos = 35.4283,137.4452 diff = 194.500000'
});
data_saddle.push({
lat: 3.5414444443e+01,
lng: 1.3745955556e+02,
content:'Saddle = 506.799988 pos = 35.4144,137.4596 diff = 194.500000'
});
data_peak.push({
lat: 3.5823888888e+01,
lng: 1.3627277778e+02,
cert : true,
content:'Name = JA/FI-036(JA/FI-036) peak = 774.000000 pos = 35.8239,136.2728 diff = 266.899994'
});
data_saddle.push({
lat: 3.5820888888e+01,
lng: 1.3631366667e+02,
content:'Saddle = 507.100006 pos = 35.8209,136.3137 diff = 266.899994'
});
data_peak.push({
lat: 3.5830555555e+01,
lng: 1.3630177778e+02,
cert : true,
content:'Name = JA/FI-045(JA/FI-045) peak = 727.700012 pos = 35.8306,136.3018 diff = 220.300018'
});
data_saddle.push({
lat: 3.5824666666e+01,
lng: 1.3629644444e+02,
content:'Saddle = 507.399994 pos = 35.8247,136.2964 diff = 220.300018'
});
data_peak.push({
lat: 3.5849666666e+01,
lng: 1.3623511111e+02,
cert : false,
content:' Peak = 712.200012 pos = 35.8497,136.2351 diff = 150.200012'
});
data_saddle.push({
lat: 3.5847111110e+01,
lng: 1.3623922222e+02,
content:'Saddle = 562.000000 pos = 35.8471,136.2392 diff = 150.200012'
});
data_peak.push({
lat: 3.5857333333e+01,
lng: 1.3627255556e+02,
cert : true,
content:'Name = JA/FI-043(JA/FI-043) peak = 735.700012 pos = 35.8573,136.2726 diff = 164.799988'
});
data_saddle.push({
lat: 3.5850222222e+01,
lng: 1.3626644444e+02,
content:'Saddle = 570.900024 pos = 35.8502,136.2664 diff = 164.799988'
});
data_peak.push({
lat: 3.6162111111e+01,
lng: 1.3649322222e+02,
cert : true,
content:'Name = Dainichizan(JA/IK-004) peak = 1367.099976 pos = 36.1621,136.4932 diff = 854.500000'
});
data_saddle.push({
lat: 3.6166777777e+01,
lng: 1.3661988889e+02,
content:'Saddle = 512.599976 pos = 36.1668,136.6199 diff = 854.500000'
});
data_peak.push({
lat: 3.6101222222e+01,
lng: 1.3645100000e+02,
cert : false,
content:' Peak = 780.500000 pos = 36.1012,136.4510 diff = 169.599976'
});
data_saddle.push({
lat: 3.6109666666e+01,
lng: 1.3645511111e+02,
content:'Saddle = 610.900024 pos = 36.1097,136.4551 diff = 169.599976'
});
data_peak.push({
lat: 3.6188555555e+01,
lng: 1.3636388889e+02,
cert : true,
content:'Name = Fujishagadake(JA/IK-009) peak = 941.500000 pos = 36.1886,136.3639 diff = 328.900024'
});
data_saddle.push({
lat: 3.6168444444e+01,
lng: 1.3639255556e+02,
content:'Saddle = 612.599976 pos = 36.1684,136.3926 diff = 328.900024'
});
data_peak.push({
lat: 3.6166000000e+01,
lng: 1.3636555556e+02,
cert : true,
content:'Name = JA/FI-029(JA/FI-029) peak = 910.299988 pos = 36.1660,136.3656 diff = 199.099976'
});
data_saddle.push({
lat: 3.6175888889e+01,
lng: 1.3636633333e+02,
content:'Saddle = 711.200012 pos = 36.1759,136.3663 diff = 199.099976'
});
data_peak.push({
lat: 3.6177777777e+01,
lng: 1.3655588889e+02,
cert : true,
content:'Name = JA/IK-006(JA/IK-006) peak = 1313.400024 pos = 36.1778,136.5559 diff = 665.700012'
});
data_saddle.push({
lat: 3.6166888889e+01,
lng: 1.3652288889e+02,
content:'Saddle = 647.700012 pos = 36.1669,136.5229 diff = 665.700012'
});
data_peak.push({
lat: 3.6265888889e+01,
lng: 1.3661544444e+02,
cert : true,
content:'Name = Wassougatake(JA/IK-008) peak = 1095.000000 pos = 36.2659,136.6154 diff = 376.900024'
});
data_saddle.push({
lat: 3.6241222222e+01,
lng: 1.3660022222e+02,
content:'Saddle = 718.099976 pos = 36.2412,136.6002 diff = 376.900024'
});
data_peak.push({
lat: 3.6166777777e+01,
lng: 1.3658166667e+02,
cert : false,
content:' Peak = 1011.799988 pos = 36.1668,136.5817 diff = 247.599976'
});
data_saddle.push({
lat: 3.6166777777e+01,
lng: 1.3657466667e+02,
content:'Saddle = 764.200012 pos = 36.1668,136.5747 diff = 247.599976'
});
data_peak.push({
lat: 3.6170000000e+01,
lng: 1.3660388889e+02,
cert : false,
content:' Peak = 956.299988 pos = 36.1700,136.6039 diff = 163.500000'
});
data_saddle.push({
lat: 3.6166777777e+01,
lng: 1.3659544444e+02,
content:'Saddle = 792.799988 pos = 36.1668,136.5954 diff = 163.500000'
});
data_peak.push({
lat: 3.6131111111e+01,
lng: 1.3641555556e+02,
cert : true,
content:'Name = JA/FI-024(JA/FI-024) peak = 1103.400024 pos = 36.1311,136.4156 diff = 242.000000'
});
data_saddle.push({
lat: 3.6134111111e+01,
lng: 1.3643344444e+02,
content:'Saddle = 861.400024 pos = 36.1341,136.4334 diff = 242.000000'
});
data_peak.push({
lat: 3.5049777777e+01,
lng: 1.3766244444e+02,
cert : true,
content:'Name = JA/AC-006(JA/AC-006) peak = 1014.599976 pos = 35.0498,137.6624 diff = 495.099976'
});
data_saddle.push({
lat: 3.5053777777e+01,
lng: 1.3760422222e+02,
content:'Saddle = 519.500000 pos = 35.0538,137.6042 diff = 495.099976'
});
data_peak.push({
lat: 3.5615888888e+01,
lng: 1.3678855556e+02,
cert : false,
content:' Peak = 671.200012 pos = 35.6159,136.7886 diff = 151.500000'
});
data_saddle.push({
lat: 3.5625777777e+01,
lng: 1.3677677778e+02,
content:'Saddle = 519.700012 pos = 35.6258,136.7768 diff = 151.500000'
});
data_peak.push({
lat: 3.5351666666e+01,
lng: 1.3732477778e+02,
cert : false,
content:' Peak = 821.400024 pos = 35.3517,137.3248 diff = 294.400024'
});
data_saddle.push({
lat: 3.5357555555e+01,
lng: 1.3742322222e+02,
content:'Saddle = 527.000000 pos = 35.3576,137.4232 diff = 294.400024'
});
data_peak.push({
lat: 3.5414444443e+01,
lng: 1.3740111111e+02,
cert : true,
content:'Name = JA/GF-162(JA/GF-162) peak = 770.299988 pos = 35.4144,137.4011 diff = 193.899963'
});
data_saddle.push({
lat: 3.5380888888e+01,
lng: 1.3738266667e+02,
content:'Saddle = 576.400024 pos = 35.3809,137.3827 diff = 193.899963'
});
data_peak.push({
lat: 3.5684999999e+01,
lng: 1.3706955556e+02,
cert : false,
content:' Peak = 703.700012 pos = 35.6850,137.0696 diff = 176.500000'
});
data_saddle.push({
lat: 3.5690777777e+01,
lng: 1.3705811111e+02,
content:'Saddle = 527.200012 pos = 35.6908,137.0581 diff = 176.500000'
});
data_peak.push({
lat: 3.6540666667e+01,
lng: 1.3725633333e+02,
cert : true,
content:'Name = Kosanami Onmaeyama(JA/TY-052) peak = 756.900024 pos = 36.5407,137.2563 diff = 228.800049'
});
data_saddle.push({
lat: 3.6531111111e+01,
lng: 1.3725922222e+02,
content:'Saddle = 528.099976 pos = 36.5311,137.2592 diff = 228.800049'
});
data_peak.push({
lat: 3.5321888888e+01,
lng: 1.3736655556e+02,
cert : true,
content:'Name = JA/GF-166(JA/GF-166) peak = 740.799988 pos = 35.3219,137.3666 diff = 212.599976'
});
data_saddle.push({
lat: 3.5332888888e+01,
lng: 1.3738944444e+02,
content:'Saddle = 528.200012 pos = 35.3329,137.3894 diff = 212.599976'
});
data_peak.push({
lat: 3.5550555555e+01,
lng: 1.3750588889e+02,
cert : true,
content:'Name = JA/GF-135(JA/GF-135) peak = 944.200012 pos = 35.5506,137.5059 diff = 415.600037'
});
data_saddle.push({
lat: 3.5612555555e+01,
lng: 1.3748744444e+02,
content:'Saddle = 528.599976 pos = 35.6126,137.4874 diff = 415.600037'
});
data_peak.push({
lat: 3.6517555555e+01,
lng: 1.3726611111e+02,
cert : true,
content:'Name = JA/TY-053(JA/TY-053) peak = 751.299988 pos = 36.5176,137.2661 diff = 221.000000'
});
data_saddle.push({
lat: 3.6514111111e+01,
lng: 1.3727611111e+02,
content:'Saddle = 530.299988 pos = 36.5141,137.2761 diff = 221.000000'
});
data_peak.push({
lat: 3.5701555555e+01,
lng: 1.3706755556e+02,
cert : true,
content:'Name = JA/GF-157(JA/GF-157) peak = 792.500000 pos = 35.7016,137.0676 diff = 261.599976'
});
data_saddle.push({
lat: 3.5693555555e+01,
lng: 1.3702000000e+02,
content:'Saddle = 530.900024 pos = 35.6936,137.0200 diff = 261.599976'
});
data_peak.push({
lat: 3.4909777776e+01,
lng: 1.3742055556e+02,
cert : true,
content:'Name = Honguusan(JA/AC-017) peak = 788.099976 pos = 34.9098,137.4206 diff = 256.099976'
});
data_saddle.push({
lat: 3.4970666665e+01,
lng: 1.3742855556e+02,
content:'Saddle = 532.000000 pos = 34.9707,137.4286 diff = 256.099976'
});
data_peak.push({
lat: 3.4975999999e+01,
lng: 1.3740188889e+02,
cert : false,
content:' Peak = 733.299988 pos = 34.9760,137.4019 diff = 175.899963'
});
data_saddle.push({
lat: 3.4957333332e+01,
lng: 1.3740833333e+02,
content:'Saddle = 557.400024 pos = 34.9573,137.4083 diff = 175.899963'
});
data_peak.push({
lat: 3.6366333333e+01,
lng: 1.3664366667e+02,
cert : true,
content:'Name = JA/IK-010(JA/IK-010) peak = 690.700012 pos = 36.3663,136.6437 diff = 158.200012'
});
data_saddle.push({
lat: 3.6356444444e+01,
lng: 1.3664822222e+02,
content:'Saddle = 532.500000 pos = 36.3564,136.6482 diff = 158.200012'
});
data_peak.push({
lat: 3.5322999999e+01,
lng: 1.3794277778e+02,
cert : true,
content:'Name = JA/NN-193(JA/NN-193) peak = 716.400024 pos = 35.3230,137.9428 diff = 183.700012'
});
data_saddle.push({
lat: 3.5323444443e+01,
lng: 1.3794866667e+02,
content:'Saddle = 532.700012 pos = 35.3234,137.9487 diff = 183.700012'
});
data_peak.push({
lat: 3.5681666666e+01,
lng: 1.3721833333e+02,
cert : true,
content:'Name = JA/GF-141(JA/GF-141) peak = 906.599976 pos = 35.6817,137.2183 diff = 369.799988'
});
data_saddle.push({
lat: 3.5676777777e+01,
lng: 1.3723733333e+02,
content:'Saddle = 536.799988 pos = 35.6768,137.2373 diff = 369.799988'
});
data_peak.push({
lat: 3.5695666666e+01,
lng: 1.3719922222e+02,
cert : false,
content:' Peak = 700.000000 pos = 35.6957,137.1992 diff = 162.299988'
});
data_saddle.push({
lat: 3.5691888888e+01,
lng: 1.3720733333e+02,
content:'Saddle = 537.700012 pos = 35.6919,137.2073 diff = 162.299988'
});
data_peak.push({
lat: 3.5721333333e+01,
lng: 1.3613388889e+02,
cert : true,
content:'Name = JA/FI-040(JA/FI-040) peak = 761.200012 pos = 35.7213,136.1339 diff = 223.900024'
});
data_saddle.push({
lat: 3.5698444444e+01,
lng: 1.3615944444e+02,
content:'Saddle = 537.299988 pos = 35.6984,136.1594 diff = 223.900024'
});
data_peak.push({
lat: 3.5694444444e+01,
lng: 1.3615000000e+02,
cert : false,
content:' Peak = 751.299988 pos = 35.6944,136.1500 diff = 158.700012'
});
data_saddle.push({
lat: 3.5708999999e+01,
lng: 1.3614855556e+02,
content:'Saddle = 592.599976 pos = 35.7090,136.1486 diff = 158.700012'
});
data_peak.push({
lat: 3.5441111110e+01,
lng: 1.3651688889e+02,
cert : true,
content:'Name = JA/GF-136(JA/GF-136) peak = 923.299988 pos = 35.4411,136.5169 diff = 381.299988'
});
data_saddle.push({
lat: 3.5415888888e+01,
lng: 1.3647877778e+02,
content:'Saddle = 542.000000 pos = 35.4159,136.4788 diff = 381.299988'
});
data_peak.push({
lat: 3.5436444443e+01,
lng: 1.3646522222e+02,
cert : true,
content:'Name = JA/GF-137(JA/GF-137) peak = 918.599976 pos = 35.4364,136.4652 diff = 241.399963'
});
data_saddle.push({
lat: 3.5431666666e+01,
lng: 1.3650488889e+02,
content:'Saddle = 677.200012 pos = 35.4317,136.5049 diff = 241.399963'
});
data_peak.push({
lat: 3.5086777777e+01,
lng: 1.3766111111e+02,
cert : true,
content:'Name = JA/AC-016(JA/AC-016) peak = 788.400024 pos = 35.0868,137.6611 diff = 245.900024'
});
data_saddle.push({
lat: 3.5084777777e+01,
lng: 1.3763855556e+02,
content:'Saddle = 542.500000 pos = 35.0848,137.6386 diff = 245.900024'
});
data_peak.push({
lat: 3.5915666666e+01,
lng: 1.3639766667e+02,
cert : false,
content:' Peak = 711.200012 pos = 35.9157,136.3977 diff = 168.100037'
});
data_saddle.push({
lat: 3.5906444444e+01,
lng: 1.3639800000e+02,
content:'Saddle = 543.099976 pos = 35.9064,136.3980 diff = 168.100037'
});
data_peak.push({
lat: 3.5823999999e+01,
lng: 1.3632533333e+02,
cert : true,
content:'Name = JA/FI-044(JA/FI-044) peak = 734.000000 pos = 35.8240,136.3253 diff = 186.599976'
});
data_saddle.push({
lat: 3.5813111110e+01,
lng: 1.3634933333e+02,
content:'Saddle = 547.400024 pos = 35.8131,136.3493 diff = 186.599976'
});
data_peak.push({
lat: 3.5544666666e+01,
lng: 1.3720655556e+02,
cert : true,
content:'Name = JA/GF-168(JA/GF-168) peak = 732.900024 pos = 35.5447,137.2066 diff = 185.400024'
});
data_saddle.push({
lat: 3.5552444444e+01,
lng: 1.3720355556e+02,
content:'Saddle = 547.500000 pos = 35.5524,137.2036 diff = 185.400024'
});
data_peak.push({
lat: 3.5588999999e+01,
lng: 1.3724100000e+02,
cert : true,
content:'Name = JA/GF-169(JA/GF-169) peak = 723.500000 pos = 35.5890,137.2410 diff = 175.900024'
});
data_saddle.push({
lat: 3.5589777777e+01,
lng: 1.3725055556e+02,
content:'Saddle = 547.599976 pos = 35.5898,137.2506 diff = 175.900024'
});
data_peak.push({
lat: 3.5094555554e+01,
lng: 1.3771500000e+02,
cert : true,
content:'Name = JA/AC-019(JA/AC-019) peak = 715.700012 pos = 35.0946,137.7150 diff = 167.700012'
});
data_saddle.push({
lat: 3.5110777777e+01,
lng: 1.3770777778e+02,
content:'Saddle = 548.000000 pos = 35.1108,137.7078 diff = 167.700012'
});
data_peak.push({
lat: 3.5733666666e+01,
lng: 1.3702333333e+02,
cert : true,
content:'Name = JA/GF-163(JA/GF-163) peak = 761.200012 pos = 35.7337,137.0233 diff = 212.299988'
});
data_saddle.push({
lat: 3.5740444444e+01,
lng: 1.3701844444e+02,
content:'Saddle = 548.900024 pos = 35.7404,137.0184 diff = 212.299988'
});
data_peak.push({
lat: 3.5711555555e+01,
lng: 1.3700744444e+02,
cert : true,
content:'Name = JA/GF-160(JA/GF-160) peak = 771.099976 pos = 35.7116,137.0074 diff = 214.099976'
});
data_saddle.push({
lat: 3.5734888888e+01,
lng: 1.3698788889e+02,
content:'Saddle = 557.000000 pos = 35.7349,136.9879 diff = 214.099976'
});
data_peak.push({
lat: 3.5730777777e+01,
lng: 1.3700033333e+02,
cert : true,
content:'Name = JA/GF-164(JA/GF-164) peak = 754.099976 pos = 35.7308,137.0003 diff = 195.899963'
});
data_saddle.push({
lat: 3.5716666666e+01,
lng: 1.3699277778e+02,
content:'Saddle = 558.200012 pos = 35.7167,136.9928 diff = 195.899963'
});
data_peak.push({
lat: 3.5563888888e+01,
lng: 1.3719700000e+02,
cert : false,
content:' Peak = 713.700012 pos = 35.5639,137.1970 diff = 155.700012'
});
data_saddle.push({
lat: 3.5557666666e+01,
lng: 1.3720811111e+02,
content:'Saddle = 558.000000 pos = 35.5577,137.2081 diff = 155.700012'
});
data_peak.push({
lat: 3.6165222222e+01,
lng: 1.3662533333e+02,
cert : false,
content:' Peak = 770.900024 pos = 36.1652,136.6253 diff = 212.800049'
});
data_saddle.push({
lat: 3.6155888889e+01,
lng: 1.3662511111e+02,
content:'Saddle = 558.099976 pos = 36.1559,136.6251 diff = 212.800049'
});
data_peak.push({
lat: 3.5118333332e+01,
lng: 1.3783944444e+02,
cert : true,
content:'Name = JA/SO-060(JA/SO-060) peak = 813.400024 pos = 35.1183,137.8394 diff = 252.200012'
});
data_saddle.push({
lat: 3.5125111110e+01,
lng: 1.3783633333e+02,
content:'Saddle = 561.200012 pos = 35.1251,137.8363 diff = 252.200012'
});
data_peak.push({
lat: 3.5413555555e+01,
lng: 1.3646000000e+02,
cert : true,
content:'Name = JA/GF-159(JA/GF-159) peak = 795.700012 pos = 35.4136,136.4600 diff = 232.900024'
});
data_saddle.push({
lat: 3.5399888888e+01,
lng: 1.3646366667e+02,
content:'Saddle = 562.799988 pos = 35.3999,136.4637 diff = 232.900024'
});
data_peak.push({
lat: 3.6514000000e+01,
lng: 1.3720088889e+02,
cert : true,
content:'Name = JA/TY-051(JA/TY-051) peak = 781.700012 pos = 36.5140,137.2009 diff = 218.600037'
});
data_saddle.push({
lat: 3.6502777778e+01,
lng: 1.3720244444e+02,
content:'Saddle = 563.099976 pos = 36.5028,137.2024 diff = 218.600037'
});
data_peak.push({
lat: 3.5761444444e+01,
lng: 1.3625155556e+02,
cert : true,
content:'Name = JA/FI-039(JA/FI-039) peak = 761.500000 pos = 35.7614,136.2516 diff = 190.700012'
});
data_saddle.push({
lat: 3.5763999999e+01,
lng: 1.3626588889e+02,
content:'Saddle = 570.799988 pos = 35.7640,136.2659 diff = 190.700012'
});
data_peak.push({
lat: 3.5707555555e+01,
lng: 1.3692677778e+02,
cert : false,
content:' Peak = 734.200012 pos = 35.7076,136.9268 diff = 162.600037'
});
data_saddle.push({
lat: 3.5699333333e+01,
lng: 1.3691800000e+02,
content:'Saddle = 571.599976 pos = 35.6993,136.9180 diff = 162.600037'
});
data_peak.push({
lat: 3.5084999999e+01,
lng: 1.3763155556e+02,
cert : true,
content:'Name = JA/AC-018(JA/AC-018) peak = 756.200012 pos = 35.0850,137.6316 diff = 183.799988'
});
data_saddle.push({
lat: 3.5087666665e+01,
lng: 1.3762866667e+02,
content:'Saddle = 572.400024 pos = 35.0877,137.6287 diff = 183.799988'
});
data_peak.push({
lat: 3.6519555555e+01,
lng: 1.3700866667e+02,
cert : true,
content:'Name = JA/TY-048(JA/TY-048) peak = 860.799988 pos = 36.5196,137.0087 diff = 287.899963'
});
data_saddle.push({
lat: 3.6509111111e+01,
lng: 1.3701055556e+02,
content:'Saddle = 572.900024 pos = 36.5091,137.0106 diff = 287.899963'
});
data_peak.push({
lat: 3.5264999999e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 2064.699951 pos = 35.2650,137.9999 diff = 1490.199951'
});
data_saddle.push({
lat: 3.5376222221e+01,
lng: 1.3799944444e+02,
content:'Saddle = 574.500000 pos = 35.3762,137.9994 diff = 1490.199951'
});
data_peak.push({
lat: 3.5055777777e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 931.599976 pos = 35.0558,137.9999 diff = 280.299988'
});
data_saddle.push({
lat: 3.5068666665e+01,
lng: 1.3799988889e+02,
content:'Saddle = 651.299988 pos = 35.0687,137.9999 diff = 280.299988'
});
data_peak.push({
lat: 3.5063111110e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 867.700012 pos = 35.0631,137.9999 diff = 155.700012'
});
data_saddle.push({
lat: 3.5060111110e+01,
lng: 1.3799988889e+02,
content:'Saddle = 712.000000 pos = 35.0601,137.9999 diff = 155.700012'
});
data_peak.push({
lat: 3.5165222221e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 1791.800049 pos = 35.1652,137.9999 diff = 1050.400024'
});
data_saddle.push({
lat: 3.5212555554e+01,
lng: 1.3799988889e+02,
content:'Saddle = 741.400024 pos = 35.2126,137.9999 diff = 1050.400024'
});
data_peak.push({
lat: 3.5080444443e+01,
lng: 1.3799633333e+02,
cert : false,
content:' Peak = 1136.800049 pos = 35.0804,137.9963 diff = 334.600037'
});
data_saddle.push({
lat: 3.5102111110e+01,
lng: 1.3799988889e+02,
content:'Saddle = 802.200012 pos = 35.1021,137.9999 diff = 334.600037'
});
data_peak.push({
lat: 3.5093222221e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 1095.699951 pos = 35.0932,137.9999 diff = 194.499939'
});
data_saddle.push({
lat: 3.5086666665e+01,
lng: 1.3799988889e+02,
content:'Saddle = 901.200012 pos = 35.0867,137.9999 diff = 194.499939'
});
data_peak.push({
lat: 3.5068111110e+01,
lng: 1.3788222222e+02,
cert : false,
content:' Peak = 1353.000000 pos = 35.0681,137.8822 diff = 285.500000'
});
data_saddle.push({
lat: 3.5135555554e+01,
lng: 1.3791422222e+02,
content:'Saddle = 1067.500000 pos = 35.1356,137.9142 diff = 285.500000'
});
data_peak.push({
lat: 3.5121111110e+01,
lng: 1.3789666667e+02,
cert : true,
content:'Name = JA/SO-035(JA/SO-035) peak = 1331.400024 pos = 35.1211,137.8967 diff = 228.500000'
});
data_saddle.push({
lat: 3.5114222221e+01,
lng: 1.3789666667e+02,
content:'Saddle = 1102.900024 pos = 35.1142,137.8967 diff = 228.500000'
});
data_peak.push({
lat: 3.5114777777e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 1551.199951 pos = 35.1148,137.9999 diff = 471.299927'
});
data_saddle.push({
lat: 3.5126555554e+01,
lng: 1.3799988889e+02,
content:'Saddle = 1079.900024 pos = 35.1266,137.9999 diff = 471.299927'
});
data_peak.push({
lat: 3.5106111110e+01,
lng: 1.3794255556e+02,
cert : false,
content:' Peak = 1433.500000 pos = 35.1061,137.9426 diff = 211.400024'
});
data_saddle.push({
lat: 3.5100333332e+01,
lng: 1.3795200000e+02,
content:'Saddle = 1222.099976 pos = 35.1003,137.9520 diff = 211.400024'
});
data_peak.push({
lat: 3.5095999999e+01,
lng: 1.3796588889e+02,
cert : false,
content:' Peak = 1465.099976 pos = 35.0960,137.9659 diff = 181.799927'
});
data_saddle.push({
lat: 3.5101111110e+01,
lng: 1.3797366667e+02,
content:'Saddle = 1283.300049 pos = 35.1011,137.9737 diff = 181.799927'
});
data_peak.push({
lat: 3.5194888888e+01,
lng: 1.3798544444e+02,
cert : true,
content:'Name = JA/SO-022(JA/SO-022) peak = 1781.000000 pos = 35.1949,137.9854 diff = 562.000000'
});
data_saddle.push({
lat: 3.5190333332e+01,
lng: 1.3799977778e+02,
content:'Saddle = 1219.000000 pos = 35.1903,137.9998 diff = 562.000000'
});
data_peak.push({
lat: 3.5158222221e+01,
lng: 1.3791444444e+02,
cert : false,
content:' Peak = 1434.400024 pos = 35.1582,137.9144 diff = 213.099976'
});
data_saddle.push({
lat: 3.5150888888e+01,
lng: 1.3792766667e+02,
content:'Saddle = 1221.300049 pos = 35.1509,137.9277 diff = 213.099976'
});
data_peak.push({
lat: 3.5131111110e+01,
lng: 1.3799944444e+02,
cert : false,
content:' Peak = 1470.599976 pos = 35.1311,137.9994 diff = 228.799927'
});
data_saddle.push({
lat: 3.5136666665e+01,
lng: 1.3799988889e+02,
content:'Saddle = 1241.800049 pos = 35.1367,137.9999 diff = 228.799927'
});
data_peak.push({
lat: 3.5133111110e+01,
lng: 1.3782700000e+02,
cert : true,
content:'Name = JA/SO-052(JA/SO-052) peak = 954.299988 pos = 35.1331,137.8270 diff = 202.700012'
});
data_saddle.push({
lat: 3.5142888888e+01,
lng: 1.3783677778e+02,
content:'Saddle = 751.599976 pos = 35.1429,137.8368 diff = 202.700012'
});
data_peak.push({
lat: 3.5121222221e+01,
lng: 1.3781388889e+02,
cert : false,
content:' Peak = 924.799988 pos = 35.1212,137.8139 diff = 162.899963'
});
data_saddle.push({
lat: 3.5128666665e+01,
lng: 1.3782177778e+02,
content:'Saddle = 761.900024 pos = 35.1287,137.8218 diff = 162.899963'
});
data_peak.push({
lat: 3.5370444443e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 960.500000 pos = 35.3704,137.9999 diff = 185.799988'
});
data_saddle.push({
lat: 3.5367555555e+01,
lng: 1.3799988889e+02,
content:'Saddle = 774.700012 pos = 35.3676,137.9999 diff = 185.799988'
});
data_peak.push({
lat: 3.5201777777e+01,
lng: 1.3790600000e+02,
cert : false,
content:' Peak = 1167.199951 pos = 35.2018,137.9060 diff = 238.599976'
});
data_saddle.push({
lat: 3.5230444443e+01,
lng: 1.3790788889e+02,
content:'Saddle = 928.599976 pos = 35.2304,137.9079 diff = 238.599976'
});
data_peak.push({
lat: 3.5343333332e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 1737.000000 pos = 35.3433,137.9999 diff = 768.099976'
});
data_saddle.push({
lat: 3.5331888888e+01,
lng: 1.3799933333e+02,
content:'Saddle = 968.900024 pos = 35.3319,137.9993 diff = 768.099976'
});
data_peak.push({
lat: 3.5231444443e+01,
lng: 1.3799488889e+02,
cert : false,
content:' Peak = 1474.300049 pos = 35.2314,137.9949 diff = 409.500000'
});
data_saddle.push({
lat: 3.5245555554e+01,
lng: 1.3799988889e+02,
content:'Saddle = 1064.800049 pos = 35.2456,137.9999 diff = 409.500000'
});
data_peak.push({
lat: 3.5263333332e+01,
lng: 1.3789477778e+02,
cert : true,
content:'Name = Kumabushiyama(JA/NN-106) peak = 1652.400024 pos = 35.2633,137.8948 diff = 565.000000'
});
data_saddle.push({
lat: 3.5254111110e+01,
lng: 1.3791077778e+02,
content:'Saddle = 1087.400024 pos = 35.2541,137.9108 diff = 565.000000'
});
data_peak.push({
lat: 3.5254555554e+01,
lng: 1.3791866667e+02,
cert : true,
content:'Name = JA/SO-032(JA/SO-032) peak = 1366.800049 pos = 35.2546,137.9187 diff = 213.200073'
});
data_saddle.push({
lat: 3.5274111110e+01,
lng: 1.3792911111e+02,
content:'Saddle = 1153.599976 pos = 35.2741,137.9291 diff = 213.200073'
});
data_peak.push({
lat: 3.5321444443e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 1548.099976 pos = 35.3214,137.9999 diff = 382.000000'
});
data_saddle.push({
lat: 3.5316555555e+01,
lng: 1.3799988889e+02,
content:'Saddle = 1166.099976 pos = 35.3166,137.9999 diff = 382.000000'
});
data_peak.push({
lat: 3.5302888888e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 1882.900024 pos = 35.3029,137.9999 diff = 479.000000'
});
data_saddle.push({
lat: 3.5282444443e+01,
lng: 1.3799988889e+02,
content:'Saddle = 1403.900024 pos = 35.2824,137.9999 diff = 479.000000'
});
data_peak.push({
lat: 3.5288222221e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 1826.300049 pos = 35.2882,137.9999 diff = 340.800049'
});
data_saddle.push({
lat: 3.5297555554e+01,
lng: 1.3799988889e+02,
content:'Saddle = 1485.500000 pos = 35.2976,137.9999 diff = 340.800049'
});
data_peak.push({
lat: 3.5751666666e+01,
lng: 1.3699377778e+02,
cert : true,
content:'Name = JA/GF-156(JA/GF-156) peak = 815.799988 pos = 35.7517,136.9938 diff = 227.599976'
});
data_saddle.push({
lat: 3.5756777777e+01,
lng: 1.3700744444e+02,
content:'Saddle = 588.200012 pos = 35.7568,137.0074 diff = 227.599976'
});
data_peak.push({
lat: 3.5734999999e+01,
lng: 1.3658933333e+02,
cert : true,
content:'Name = JA/GF-149(JA/GF-149) peak = 874.500000 pos = 35.7350,136.5893 diff = 285.799988'
});
data_saddle.push({
lat: 3.5746333333e+01,
lng: 1.3658844444e+02,
content:'Saddle = 588.700012 pos = 35.7463,136.5884 diff = 285.799988'
});
data_peak.push({
lat: 3.5705999999e+01,
lng: 1.3715577778e+02,
cert : true,
content:'Name = JA/GF-161(JA/GF-161) peak = 772.900024 pos = 35.7060,137.1558 diff = 179.800049'
});
data_saddle.push({
lat: 3.5717444444e+01,
lng: 1.3715233333e+02,
content:'Saddle = 593.099976 pos = 35.7174,137.1523 diff = 179.800049'
});
data_peak.push({
lat: 3.5037555554e+01,
lng: 1.3757666667e+02,
cert : false,
content:' Peak = 761.099976 pos = 35.0376,137.5767 diff = 164.799988'
});
data_saddle.push({
lat: 3.5040444443e+01,
lng: 1.3758266667e+02,
content:'Saddle = 596.299988 pos = 35.0404,137.5827 diff = 164.799988'
});
data_peak.push({
lat: 3.6299666666e+01,
lng: 1.3688655556e+02,
cert : false,
content:' Peak = 763.200012 pos = 36.2997,136.8866 diff = 160.299988'
});
data_saddle.push({
lat: 3.6295000000e+01,
lng: 1.3688800000e+02,
content:'Saddle = 602.900024 pos = 36.2950,136.8880 diff = 160.299988'
});
data_peak.push({
lat: 3.5451333332e+01,
lng: 1.3777777778e+02,
cert : true,
content:'Name = JA/NN-192(JA/NN-192) peak = 797.700012 pos = 35.4513,137.7778 diff = 194.799988'
});
data_saddle.push({
lat: 3.5464666666e+01,
lng: 1.3776844444e+02,
content:'Saddle = 602.900024 pos = 35.4647,137.7684 diff = 194.799988'
});
data_peak.push({
lat: 3.5492111110e+01,
lng: 1.3799011111e+02,
cert : true,
content:'Name = Kimenzan(JA/NN-079) peak = 1887.300049 pos = 35.4921,137.9901 diff = 1282.300049'
});
data_saddle.push({
lat: 3.5600333333e+01,
lng: 1.3799988889e+02,
content:'Saddle = 605.000000 pos = 35.6003,137.9999 diff = 1282.300049'
});
data_peak.push({
lat: 3.5521777777e+01,
lng: 1.3795855556e+02,
cert : false,
content:' Peak = 1134.099976 pos = 35.5218,137.9586 diff = 186.299988'
});
data_saddle.push({
lat: 3.5514666666e+01,
lng: 1.3796188889e+02,
content:'Saddle = 947.799988 pos = 35.5147,137.9619 diff = 186.299988'
});
data_peak.push({
lat: 3.5407111110e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 1700.300049 pos = 35.4071,137.9999 diff = 741.900024'
});
data_saddle.push({
lat: 3.5439888888e+01,
lng: 1.3799988889e+02,
content:'Saddle = 958.400024 pos = 35.4399,137.9999 diff = 741.900024'
});
data_peak.push({
lat: 3.5395555555e+01,
lng: 1.3799900000e+02,
cert : false,
content:' Peak = 1645.699951 pos = 35.3956,137.9990 diff = 188.099976'
});
data_saddle.push({
lat: 3.5402555555e+01,
lng: 1.3799988889e+02,
content:'Saddle = 1457.599976 pos = 35.4026,137.9999 diff = 188.099976'
});
data_peak.push({
lat: 3.5547333332e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 1556.699951 pos = 35.5473,137.9999 diff = 260.599976'
});
data_saddle.push({
lat: 3.5534666666e+01,
lng: 1.3799988889e+02,
content:'Saddle = 1296.099976 pos = 35.5347,137.9999 diff = 260.599976'
});
data_peak.push({
lat: 3.5344777777e+01,
lng: 1.3792388889e+02,
cert : false,
content:' Peak = 1473.500000 pos = 35.3448,137.9239 diff = 161.699951'
});
data_saddle.push({
lat: 3.5353888888e+01,
lng: 1.3792366667e+02,
content:'Saddle = 1311.800049 pos = 35.3539,137.9237 diff = 161.699951'
});
data_peak.push({
lat: 3.5409111110e+01,
lng: 1.3793966667e+02,
cert : true,
content:'Name = JA/NN-096(JA/NN-096) peak = 1700.800049 pos = 35.4091,137.9397 diff = 228.300049'
});
data_saddle.push({
lat: 3.5443555555e+01,
lng: 1.3796300000e+02,
content:'Saddle = 1472.500000 pos = 35.4436,137.9630 diff = 228.300049'
});
data_peak.push({
lat: 3.5966999999e+01,
lng: 1.3645711111e+02,
cert : true,
content:'Name = JA/FI-030(JA/FI-030) peak = 883.700012 pos = 35.9670,136.4571 diff = 272.200012'
});
data_saddle.push({
lat: 3.5943666666e+01,
lng: 1.3646177778e+02,
content:'Saddle = 611.500000 pos = 35.9437,136.4618 diff = 272.200012'
});
data_peak.push({
lat: 3.5759999999e+01,
lng: 1.3724244444e+02,
cert : true,
content:'Name = JA/GF-140(JA/GF-140) peak = 906.599976 pos = 35.7600,137.2424 diff = 288.199951'
});
data_saddle.push({
lat: 3.5739888888e+01,
lng: 1.3725633333e+02,
content:'Saddle = 618.400024 pos = 35.7399,137.2563 diff = 288.199951'
});
data_peak.push({
lat: 3.5243111110e+01,
lng: 1.3743044444e+02,
cert : true,
content:'Name = JA/GF-158(JA/GF-158) peak = 793.900024 pos = 35.2431,137.4304 diff = 175.400024'
});
data_saddle.push({
lat: 3.5257111110e+01,
lng: 1.3744777778e+02,
content:'Saddle = 618.500000 pos = 35.2571,137.4478 diff = 175.400024'
});
data_peak.push({
lat: 3.5732222222e+01,
lng: 1.3722122222e+02,
cert : false,
content:' Peak = 773.500000 pos = 35.7322,137.2212 diff = 154.900024'
});
data_saddle.push({
lat: 3.5724555555e+01,
lng: 1.3722833333e+02,
content:'Saddle = 618.599976 pos = 35.7246,137.2283 diff = 154.900024'
});
data_peak.push({
lat: 3.5022777776e+01,
lng: 1.3759777778e+02,
cert : true,
content:'Name = JA/AC-011(JA/AC-011) peak = 928.200012 pos = 35.0228,137.5978 diff = 307.000000'
});
data_saddle.push({
lat: 3.5047888888e+01,
lng: 1.3758522222e+02,
content:'Saddle = 621.200012 pos = 35.0479,137.5852 diff = 307.000000'
});
data_peak.push({
lat: 3.5620111110e+01,
lng: 1.3651922222e+02,
cert : true,
content:'Name = JA/GF-094(JA/GF-094) peak = 1181.699951 pos = 35.6201,136.5192 diff = 560.299927'
});
data_saddle.push({
lat: 3.5678333333e+01,
lng: 1.3651800000e+02,
content:'Saddle = 621.400024 pos = 35.6783,136.5180 diff = 560.299927'
});
data_peak.push({
lat: 3.5596777777e+01,
lng: 1.3659855556e+02,
cert : false,
content:' Peak = 940.700012 pos = 35.5968,136.5986 diff = 179.400024'
});
data_saddle.push({
lat: 3.5580222221e+01,
lng: 1.3657833333e+02,
content:'Saddle = 761.299988 pos = 35.5802,136.5783 diff = 179.400024'
});
data_peak.push({
lat: 3.5638666666e+01,
lng: 1.3654622222e+02,
cert : false,
content:' Peak = 1170.199951 pos = 35.6387,136.5462 diff = 307.299927'
});
data_saddle.push({
lat: 3.5630999999e+01,
lng: 1.3653644444e+02,
content:'Saddle = 862.900024 pos = 35.6310,136.5364 diff = 307.299927'
});
data_peak.push({
lat: 3.5599333333e+01,
lng: 1.3656188889e+02,
cert : false,
content:' Peak = 1065.599976 pos = 35.5993,136.5619 diff = 156.799988'
});
data_saddle.push({
lat: 3.5616888888e+01,
lng: 1.3656011111e+02,
content:'Saddle = 908.799988 pos = 35.6169,136.5601 diff = 156.799988'
});
data_peak.push({
lat: 3.5597555555e+01,
lng: 1.3649433333e+02,
cert : true,
content:'Name = JA/GF-098(JA/GF-098) peak = 1156.900024 pos = 35.5976,136.4943 diff = 274.000000'
});
data_saddle.push({
lat: 3.5607222221e+01,
lng: 1.3650811111e+02,
content:'Saddle = 882.900024 pos = 35.6072,136.5081 diff = 274.000000'
});
data_peak.push({
lat: 3.5722666666e+01,
lng: 1.3681477778e+02,
cert : false,
content:' Peak = 792.200012 pos = 35.7227,136.8148 diff = 170.500000'
});
data_saddle.push({
lat: 3.5729888888e+01,
lng: 1.3681977778e+02,
content:'Saddle = 621.700012 pos = 35.7299,136.8198 diff = 170.500000'
});
data_peak.push({
lat: 3.6506333333e+01,
lng: 1.3704600000e+02,
cert : true,
content:'Name = JA/TY-049(JA/TY-049) peak = 853.200012 pos = 36.5063,137.0460 diff = 229.700012'
});
data_saddle.push({
lat: 3.6500333333e+01,
lng: 1.3705055556e+02,
content:'Saddle = 623.500000 pos = 36.5003,137.0506 diff = 229.700012'
});
data_peak.push({
lat: 3.6530000000e+01,
lng: 1.3706488889e+02,
cert : false,
content:' Peak = 806.400024 pos = 36.5300,137.0649 diff = 153.700012'
});
data_saddle.push({
lat: 3.6526222222e+01,
lng: 1.3706233333e+02,
content:'Saddle = 652.700012 pos = 36.5262,137.0623 diff = 153.700012'
});
data_peak.push({
lat: 3.5722444444e+01,
lng: 1.3726077778e+02,
cert : true,
content:'Name = JA/GF-146(JA/GF-146) peak = 880.799988 pos = 35.7224,137.2608 diff = 254.700012'
});
data_saddle.push({
lat: 3.5720444444e+01,
lng: 1.3728844444e+02,
content:'Saddle = 626.099976 pos = 35.7204,137.2884 diff = 254.700012'
});
data_peak.push({
lat: 3.6537888889e+01,
lng: 1.3730688889e+02,
cert : false,
content:' Peak = 782.299988 pos = 36.5379,137.3069 diff = 155.099976'
});
data_saddle.push({
lat: 3.6533222222e+01,
lng: 1.3730977778e+02,
content:'Saddle = 627.200012 pos = 36.5332,137.3098 diff = 155.099976'
});
data_peak.push({
lat: 3.5645666666e+01,
lng: 1.3675733333e+02,
cert : true,
content:'Name = JA/GF-147(JA/GF-147) peak = 880.700012 pos = 35.6457,136.7573 diff = 249.100037'
});
data_saddle.push({
lat: 3.5653666666e+01,
lng: 1.3675711111e+02,
content:'Saddle = 631.599976 pos = 35.6537,136.7571 diff = 249.100037'
});
data_peak.push({
lat: 3.6339666666e+01,
lng: 1.3686066667e+02,
cert : true,
content:'Name = JA/GF-112(JA/GF-112) peak = 1084.099976 pos = 36.3397,136.8607 diff = 452.299988'
});
data_saddle.push({
lat: 3.6326666666e+01,
lng: 1.3684311111e+02,
content:'Saddle = 631.799988 pos = 36.3267,136.8431 diff = 452.299988'
});
data_peak.push({
lat: 3.5572777777e+01,
lng: 1.3739900000e+02,
cert : false,
content:' Peak = 1222.400024 pos = 35.5728,137.3990 diff = 583.900024'
});
data_saddle.push({
lat: 3.5682888888e+01,
lng: 1.3740155556e+02,
content:'Saddle = 638.500000 pos = 35.6829,137.4016 diff = 583.900024'
});
data_peak.push({
lat: 3.5483666666e+01,
lng: 1.3730966667e+02,
cert : false,
content:' Peak = 791.200012 pos = 35.4837,137.3097 diff = 150.100037'
});
data_saddle.push({
lat: 3.5509888888e+01,
lng: 1.3728322222e+02,
content:'Saddle = 641.099976 pos = 35.5099,137.2832 diff = 150.100037'
});
data_peak.push({
lat: 3.5597777777e+01,
lng: 1.3728344444e+02,
cert : true,
content:'Name = JA/GF-145(JA/GF-145) peak = 886.900024 pos = 35.5978,137.2834 diff = 239.500000'
});
data_saddle.push({
lat: 3.5606444444e+01,
lng: 1.3730355556e+02,
content:'Saddle = 647.400024 pos = 35.6064,137.3036 diff = 239.500000'
});
data_peak.push({
lat: 3.5527111110e+01,
lng: 1.3726888889e+02,
cert : true,
content:'Name = JA/GF-143(JA/GF-143) peak = 903.900024 pos = 35.5271,137.2689 diff = 253.300049'
});
data_saddle.push({
lat: 3.5534222221e+01,
lng: 1.3731855556e+02,
content:'Saddle = 650.599976 pos = 35.5342,137.3186 diff = 253.300049'
});
data_peak.push({
lat: 3.5531222221e+01,
lng: 1.3728922222e+02,
cert : true,
content:'Name = JA/GF-150(JA/GF-150) peak = 865.900024 pos = 35.5312,137.2892 diff = 199.800049'
});
data_saddle.push({
lat: 3.5530111110e+01,
lng: 1.3727844444e+02,
content:'Saddle = 666.099976 pos = 35.5301,137.2784 diff = 199.800049'
});
data_peak.push({
lat: 3.5639333333e+01,
lng: 1.3736955556e+02,
cert : true,
content:'Name = JA/GF-125(JA/GF-125) peak = 1002.799988 pos = 35.6393,137.3696 diff = 294.000000'
});
data_saddle.push({
lat: 3.5629777777e+01,
lng: 1.3737233333e+02,
content:'Saddle = 708.799988 pos = 35.6298,137.3723 diff = 294.000000'
});
data_peak.push({
lat: 3.5510666666e+01,
lng: 1.3734766667e+02,
cert : true,
content:'Name = JA/GF-107(JA/GF-107) peak = 1126.500000 pos = 35.5107,137.3477 diff = 409.000000'
});
data_saddle.push({
lat: 3.5537999999e+01,
lng: 1.3734700000e+02,
content:'Saddle = 717.500000 pos = 35.5380,137.3470 diff = 409.000000'
});
data_peak.push({
lat: 3.5569333332e+01,
lng: 1.3728133333e+02,
cert : false,
content:' Peak = 912.700012 pos = 35.5693,137.2813 diff = 150.700012'
});
data_saddle.push({
lat: 3.5565333332e+01,
lng: 1.3728700000e+02,
content:'Saddle = 762.000000 pos = 35.5653,137.2870 diff = 150.700012'
});
data_peak.push({
lat: 3.5662444444e+01,
lng: 1.3739666667e+02,
cert : false,
content:' Peak = 983.000000 pos = 35.6624,137.3967 diff = 205.099976'
});
data_saddle.push({
lat: 3.5641333333e+01,
lng: 1.3740588889e+02,
content:'Saddle = 777.900024 pos = 35.6413,137.4059 diff = 205.099976'
});
data_peak.push({
lat: 3.5646333333e+01,
lng: 1.3739955556e+02,
cert : true,
content:'Name = JA/GF-129(JA/GF-129) peak = 971.299988 pos = 35.6463,137.3996 diff = 163.099976'
});
data_saddle.push({
lat: 3.5658777777e+01,
lng: 1.3740800000e+02,
content:'Saddle = 808.200012 pos = 35.6588,137.4080 diff = 163.099976'
});
data_peak.push({
lat: 3.5617444444e+01,
lng: 1.3734455556e+02,
cert : true,
content:'Name = JA/GF-126(JA/GF-126) peak = 1001.599976 pos = 35.6174,137.3446 diff = 213.299988'
});
data_saddle.push({
lat: 3.5616333333e+01,
lng: 1.3736566667e+02,
content:'Saddle = 788.299988 pos = 35.6163,137.3657 diff = 213.299988'
});
data_peak.push({
lat: 3.5564999999e+01,
lng: 1.3734288889e+02,
cert : true,
content:'Name = JA/GF-114(JA/GF-114) peak = 1080.000000 pos = 35.5650,137.3429 diff = 281.299988'
});
data_saddle.push({
lat: 3.5565222221e+01,
lng: 1.3735933333e+02,
content:'Saddle = 798.700012 pos = 35.5652,137.3593 diff = 281.299988'
});
data_peak.push({
lat: 3.5602999999e+01,
lng: 1.3738666667e+02,
cert : true,
content:'Name = JA/GF-099(JA/GF-099) peak = 1155.400024 pos = 35.6030,137.3867 diff = 273.700012'
});
data_saddle.push({
lat: 3.5589777777e+01,
lng: 1.3739033333e+02,
content:'Saddle = 881.700012 pos = 35.5898,137.3903 diff = 273.700012'
});
data_peak.push({
lat: 3.5446222221e+01,
lng: 1.3638755556e+02,
cert : true,
content:'Name = JA/SI-024(JA/SI-024) peak = 861.599976 pos = 35.4462,136.3876 diff = 219.699951'
});
data_saddle.push({
lat: 3.5449222221e+01,
lng: 1.3640888889e+02,
content:'Saddle = 641.900024 pos = 35.4492,136.4089 diff = 219.699951'
});
data_peak.push({
lat: 3.5922888888e+01,
lng: 1.3644622222e+02,
cert : false,
content:' Peak = 809.500000 pos = 35.9229,136.4462 diff = 161.599976'
});
data_saddle.push({
lat: 3.5919222222e+01,
lng: 1.3646055556e+02,
content:'Saddle = 647.900024 pos = 35.9192,136.4606 diff = 161.599976'
});
data_peak.push({
lat: 3.5123444443e+01,
lng: 1.3773722222e+02,
cert : true,
content:'Name = JA/AC-008(JA/AC-008) peak = 983.200012 pos = 35.1234,137.7372 diff = 335.100037'
});
data_saddle.push({
lat: 3.5132555554e+01,
lng: 1.3768922222e+02,
content:'Saddle = 648.099976 pos = 35.1326,137.6892 diff = 335.100037'
});
data_peak.push({
lat: 3.5125777777e+01,
lng: 1.3770288889e+02,
cert : false,
content:' Peak = 936.500000 pos = 35.1258,137.7029 diff = 155.000000'
});
data_saddle.push({
lat: 3.5128888888e+01,
lng: 1.3771933333e+02,
content:'Saddle = 781.500000 pos = 35.1289,137.7193 diff = 155.000000'
});
data_peak.push({
lat: 3.5607777777e+01,
lng: 1.3751422222e+02,
cert : true,
content:'Name = JA/GF-152(JA/GF-152) peak = 840.200012 pos = 35.6078,137.5142 diff = 191.500000'
});
data_saddle.push({
lat: 3.5614999999e+01,
lng: 1.3751600000e+02,
content:'Saddle = 648.700012 pos = 35.6150,137.5160 diff = 191.500000'
});
data_peak.push({
lat: 3.5058111110e+01,
lng: 1.3757977778e+02,
cert : true,
content:'Name = JA/AC-013(JA/AC-013) peak = 885.400024 pos = 35.0581,137.5798 diff = 233.700012'
});
data_saddle.push({
lat: 3.5079333332e+01,
lng: 1.3760000000e+02,
content:'Saddle = 651.700012 pos = 35.0793,137.6000 diff = 233.700012'
});
data_peak.push({
lat: 3.5571222221e+01,
lng: 1.3643622222e+02,
cert : true,
content:'Name = JA/GF-153(JA/GF-153) peak = 824.299988 pos = 35.5712,136.4362 diff = 172.200012'
});
data_saddle.push({
lat: 3.5543666666e+01,
lng: 1.3642544444e+02,
content:'Saddle = 652.099976 pos = 35.5437,136.4254 diff = 172.200012'
});
data_peak.push({
lat: 3.5840666666e+01,
lng: 1.3653466667e+02,
cert : true,
content:'Name = JA/FI-027(JA/FI-027) peak = 928.400024 pos = 35.8407,136.5347 diff = 274.800049'
});
data_saddle.push({
lat: 3.5833999999e+01,
lng: 1.3652844444e+02,
content:'Saddle = 653.599976 pos = 35.8340,136.5284 diff = 274.800049'
});
data_peak.push({
lat: 3.5678999999e+01,
lng: 1.3676944444e+02,
cert : true,
content:'Name = JA/GF-109(JA/GF-109) peak = 1105.099976 pos = 35.6790,136.7694 diff = 445.799988'
});
data_saddle.push({
lat: 3.5683555555e+01,
lng: 1.3674755556e+02,
content:'Saddle = 659.299988 pos = 35.6836,136.7476 diff = 445.799988'
});
data_peak.push({
lat: 3.5668444444e+01,
lng: 1.3677922222e+02,
cert : false,
content:' Peak = 1086.599976 pos = 35.6684,136.7792 diff = 195.000000'
});
data_saddle.push({
lat: 3.5671111110e+01,
lng: 1.3677111111e+02,
content:'Saddle = 891.599976 pos = 35.6711,136.7711 diff = 195.000000'
});
data_peak.push({
lat: 3.5139111110e+01,
lng: 1.3765533333e+02,
cert : true,
content:'Name = JA/AC-010(JA/AC-010) peak = 953.099976 pos = 35.1391,137.6553 diff = 292.699951'
});
data_saddle.push({
lat: 3.5150111110e+01,
lng: 1.3764888889e+02,
content:'Saddle = 660.400024 pos = 35.1501,137.6489 diff = 292.699951'
});
data_peak.push({
lat: 3.6180444444e+01,
lng: 1.3723033333e+02,
cert : true,
content:'Name = JA/GF-154(JA/GF-154) peak = 823.299988 pos = 36.1804,137.2303 diff = 162.599976'
});
data_saddle.push({
lat: 3.6181111111e+01,
lng: 1.3721888889e+02,
content:'Saddle = 660.700012 pos = 36.1811,137.2189 diff = 162.599976'
});
data_peak.push({
lat: 3.5501666666e+01,
lng: 1.3649922222e+02,
cert : true,
content:'Name = JA/GF-139(JA/GF-139) peak = 912.099976 pos = 35.5017,136.4992 diff = 249.399963'
});
data_saddle.push({
lat: 3.5513999999e+01,
lng: 1.3648722222e+02,
content:'Saddle = 662.700012 pos = 35.5140,136.4872 diff = 249.399963'
});
data_peak.push({
lat: 3.5650222221e+01,
lng: 1.3728266667e+02,
cert : true,
content:'Name = JA/GF-134(JA/GF-134) peak = 943.799988 pos = 35.6502,137.2827 diff = 275.200012'
});
data_saddle.push({
lat: 3.5669444444e+01,
lng: 1.3730633333e+02,
content:'Saddle = 668.599976 pos = 35.6694,137.3063 diff = 275.200012'
});
data_peak.push({
lat: 3.5619888888e+01,
lng: 1.3722866667e+02,
cert : true,
content:'Name = JA/GF-151(JA/GF-151) peak = 861.900024 pos = 35.6199,137.2287 diff = 169.200012'
});
data_saddle.push({
lat: 3.5634888888e+01,
lng: 1.3724433333e+02,
content:'Saddle = 692.700012 pos = 35.6349,137.2443 diff = 169.200012'
});
data_peak.push({
lat: 3.5671888888e+01,
lng: 1.3685922222e+02,
cert : true,
content:'Name = Kougasan(JA/GF-087) peak = 1223.300049 pos = 35.6719,136.8592 diff = 554.700073'
});
data_saddle.push({
lat: 3.5710333333e+01,
lng: 1.3684466667e+02,
content:'Saddle = 668.599976 pos = 35.7103,136.8447 diff = 554.700073'
});
data_peak.push({
lat: 3.5669111110e+01,
lng: 1.3684266667e+02,
cert : true,
content:'Name = JA/GF-120(JA/GF-120) peak = 1053.099976 pos = 35.6691,136.8427 diff = 195.599976'
});
data_saddle.push({
lat: 3.5670666666e+01,
lng: 1.3684788889e+02,
content:'Saddle = 857.500000 pos = 35.6707,136.8479 diff = 195.599976'
});
data_peak.push({
lat: 3.5632111110e+01,
lng: 1.3687788889e+02,
cert : true,
content:'Name = JA/GF-122(JA/GF-122) peak = 1047.099976 pos = 35.6321,136.8779 diff = 171.799988'
});
data_saddle.push({
lat: 3.5648555555e+01,
lng: 1.3687077778e+02,
content:'Saddle = 875.299988 pos = 35.6486,136.8708 diff = 171.799988'
});
data_peak.push({
lat: 3.5671777777e+01,
lng: 1.3798400000e+02,
cert : false,
content:' Peak = 1444.099976 pos = 35.6718,137.9840 diff = 773.399963'
});
data_saddle.push({
lat: 3.5829777777e+01,
lng: 1.3799988889e+02,
content:'Saddle = 670.700012 pos = 35.8298,137.9999 diff = 773.399963'
});
data_peak.push({
lat: 3.5780111110e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 1088.699951 pos = 35.7801,137.9999 diff = 417.899963'
});
data_saddle.push({
lat: 3.5718222221e+01,
lng: 1.3799988889e+02,
content:'Saddle = 670.799988 pos = 35.7182,137.9999 diff = 417.899963'
});
data_peak.push({
lat: 3.5755888888e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 1045.099976 pos = 35.7559,137.9999 diff = 183.500000'
});
data_saddle.push({
lat: 3.5764777777e+01,
lng: 1.3799988889e+02,
content:'Saddle = 861.599976 pos = 35.7648,137.9999 diff = 183.500000'
});
data_peak.push({
lat: 3.5628333333e+01,
lng: 1.3799988889e+02,
cert : false,
content:' Peak = 959.599976 pos = 35.6283,137.9999 diff = 183.899963'
});
data_saddle.push({
lat: 3.5630888888e+01,
lng: 1.3799988889e+02,
content:'Saddle = 775.700012 pos = 35.6309,137.9999 diff = 183.899963'
});
data_peak.push({
lat: 3.5754111110e+01,
lng: 1.3691233333e+02,
cert : false,
content:' Peak = 831.000000 pos = 35.7541,136.9123 diff = 158.799988'
});
data_saddle.push({
lat: 3.5761777777e+01,
lng: 1.3690488889e+02,
content:'Saddle = 672.200012 pos = 35.7618,136.9049 diff = 158.799988'
});
data_peak.push({
lat: 3.6493444444e+01,
lng: 1.3707977778e+02,
cert : true,
content:'Name = Sodeyama(JA/TY-050) peak = 855.799988 pos = 36.4934,137.0798 diff = 182.799988'
});
data_saddle.push({
lat: 3.6489777778e+01,
lng: 1.3709911111e+02,
content:'Saddle = 673.000000 pos = 36.4898,137.0991 diff = 182.799988'
});
data_peak.push({
lat: 3.5250444443e+01,
lng: 1.3751700000e+02,
cert : false,
content:' Peak = 830.599976 pos = 35.2504,137.5170 diff = 154.000000'
});
data_saddle.push({
lat: 3.5223777777e+01,
lng: 1.3753622222e+02,
content:'Saddle = 676.599976 pos = 35.2238,137.5362 diff = 154.000000'
});
data_peak.push({
lat: 3.5929333333e+01,
lng: 1.3685488889e+02,
cert : true,
content:'Name = JA/GF-138(JA/GF-138) peak = 916.599976 pos = 35.9293,136.8549 diff = 238.799988'
});
data_saddle.push({
lat: 3.5915555555e+01,
lng: 1.3686100000e+02,
content:'Saddle = 677.799988 pos = 35.9156,136.8610 diff = 238.799988'
});
data_peak.push({
lat: 3.5217111110e+01,
lng: 1.3746288889e+02,
cert : false,
content:' Peak = 864.700012 pos = 35.2171,137.4629 diff = 186.299988'
});
data_saddle.push({
lat: 3.5194888888e+01,
lng: 1.3746211111e+02,
content:'Saddle = 678.400024 pos = 35.1949,137.4621 diff = 186.299988'
});
data_peak.push({
lat: 3.5105222221e+01,
lng: 1.3760633333e+02,
cert : true,
content:'Name = JA/AC-007(JA/AC-007) peak = 1011.000000 pos = 35.1052,137.6063 diff = 332.000000'
});
data_saddle.push({
lat: 3.5154444443e+01,
lng: 1.3761222222e+02,
content:'Saddle = 679.000000 pos = 35.1544,137.6122 diff = 332.000000'
});
data_peak.push({
lat: 3.5140888888e+01,
lng: 1.3762666667e+02,
cert : true,
content:'Name = JA/AC-014(JA/AC-014) peak = 864.700012 pos = 35.1409,137.6267 diff = 156.799988'
});
data_saddle.push({
lat: 3.5131888888e+01,
lng: 1.3760977778e+02,
content:'Saddle = 707.900024 pos = 35.1319,137.6098 diff = 156.799988'
});
data_peak.push({
lat: 3.6271333333e+01,
lng: 1.3711533333e+02,
cert : true,
content:'Name = JA/GF-127(JA/GF-127) peak = 994.099976 pos = 36.2713,137.1153 diff = 311.599976'
});
data_saddle.push({
lat: 3.6255777777e+01,
lng: 1.3710144444e+02,
content:'Saddle = 682.500000 pos = 36.2558,137.1014 diff = 311.599976'
});
data_peak.push({
lat: 3.5745777777e+01,
lng: 1.3717444444e+02,
cert : true,
content:'Name = JA/GF-148(JA/GF-148) peak = 871.500000 pos = 35.7458,137.1744 diff = 186.500000'
});
data_saddle.push({
lat: 3.5756999999e+01,
lng: 1.3717933333e+02,
content:'Saddle = 685.000000 pos = 35.7570,137.1793 diff = 186.500000'
});
data_peak.push({
lat: 3.5152666665e+01,
lng: 1.3749488889e+02,
cert : true,
content:'Name = Takanosuyama(JA/AC-003) peak = 1152.099976 pos = 35.1527,137.4949 diff = 457.199951'
});
data_saddle.push({
lat: 3.5128888888e+01,
lng: 1.3756111111e+02,
content:'Saddle = 694.900024 pos = 35.1289,137.5611 diff = 457.199951'
});
data_peak.push({
lat: 3.5136222221e+01,
lng: 1.3744377778e+02,
cert : true,
content:'Name = JA/AC-004(JA/AC-004) peak = 1126.099976 pos = 35.1362,137.4438 diff = 188.099976'
});
data_saddle.push({
lat: 3.5115999999e+01,
lng: 1.3748200000e+02,
content:'Saddle = 938.000000 pos = 35.1160,137.4820 diff = 188.099976'
});
data_peak.push({
lat: 3.5707888888e+01,
lng: 1.3734166667e+02,
cert : false,
content:' Peak = 1144.300049 pos = 35.7079,137.3417 diff = 449.100037'
});
data_saddle.push({
lat: 3.5749888888e+01,
lng: 1.3732922222e+02,
content:'Saddle = 695.200012 pos = 35.7499,137.3292 diff = 449.100037'
});
data_peak.push({
lat: 3.5760666666e+01,
lng: 1.3727666667e+02,
cert : false,
content:' Peak = 881.500000 pos = 35.7607,137.2767 diff = 173.500000'
});
data_saddle.push({
lat: 3.5754222222e+01,
lng: 1.3727955556e+02,
content:'Saddle = 708.000000 pos = 35.7542,137.2796 diff = 173.500000'
});
data_peak.push({
lat: 3.6284111111e+01,
lng: 1.3689022222e+02,
cert : true,
content:'Name = JA/GF-132(JA/GF-132) peak = 951.500000 pos = 36.2841,136.8902 diff = 256.099976'
});
data_saddle.push({
lat: 3.6269888889e+01,
lng: 1.3688511111e+02,
content:'Saddle = 695.400024 pos = 36.2699,136.8851 diff = 256.099976'
});
data_peak.push({
lat: 3.5736555555e+01,
lng: 1.3679944444e+02,
cert : false,
content:' Peak = 1062.599976 pos = 35.7366,136.7994 diff = 356.099976'
});
data_saddle.push({
lat: 3.5758666666e+01,
lng: 1.3681633333e+02,
content:'Saddle = 706.500000 pos = 35.7587,136.8163 diff = 356.099976'
});
data_peak.push({
lat: 3.5890444444e+01,
lng: 1.3666688889e+02,
cert : true,
content:'Name = JA/FI-025(JA/FI-025) peak = 1010.299988 pos = 35.8904,136.6669 diff = 297.599976'
});
data_saddle.push({
lat: 3.5878999999e+01,
lng: 1.3664644444e+02,
content:'Saddle = 712.700012 pos = 35.8790,136.6464 diff = 297.599976'
});
data_peak.push({
lat: 3.6339666666e+01,
lng: 1.3665677778e+02,
cert : false,
content:' Peak = 865.599976 pos = 36.3397,136.6568 diff = 152.799988'
});
data_saddle.push({
lat: 3.6334333333e+01,
lng: 1.3666300000e+02,
content:'Saddle = 712.799988 pos = 36.3343,136.6630 diff = 152.799988'
});
data_peak.push({
lat: 3.5819111110e+01,
lng: 1.3701111111e+02,
cert : true,
content:'Name = JA/GF-131(JA/GF-131) peak = 951.700012 pos = 35.8191,137.0111 diff = 234.600037'
});
data_saddle.push({
lat: 3.5836222222e+01,
lng: 1.3699877778e+02,
content:'Saddle = 717.099976 pos = 35.8362,136.9988 diff = 234.600037'
});
data_peak.push({
lat: 3.5731333333e+01,
lng: 1.3675588889e+02,
cert : true,
content:'Name = JA/GF-133(JA/GF-133) peak = 951.400024 pos = 35.7313,136.7559 diff = 224.800049'
});
data_saddle.push({
lat: 3.5720444444e+01,
lng: 1.3674822222e+02,
content:'Saddle = 726.599976 pos = 35.7204,136.7482 diff = 224.800049'
});
data_peak.push({
lat: 3.6483555555e+01,
lng: 1.3721233333e+02,
cert : true,
content:'Name = JA/TY-046(JA/TY-046) peak = 960.700012 pos = 36.4836,137.2123 diff = 233.900024'
});
data_saddle.push({
lat: 3.6477111111e+01,
lng: 1.3721100000e+02,
content:'Saddle = 726.799988 pos = 36.4771,137.2110 diff = 233.900024'
});
data_peak.push({
lat: 3.5679666666e+01,
lng: 1.3659488889e+02,
cert : false,
content:' Peak = 926.400024 pos = 35.6797,136.5949 diff = 199.400024'
});
data_saddle.push({
lat: 3.5684111110e+01,
lng: 1.3660144444e+02,
content:'Saddle = 727.000000 pos = 35.6841,136.6014 diff = 199.400024'
});
data_peak.push({
lat: 3.5698333333e+01,
lng: 1.3674311111e+02,
cert : true,
content:'Name = JA/GF-124(JA/GF-124) peak = 1032.300049 pos = 35.6983,136.7431 diff = 305.200073'
});
data_saddle.push({
lat: 3.5694444444e+01,
lng: 1.3672366667e+02,
content:'Saddle = 727.099976 pos = 35.6944,136.7237 diff = 305.200073'
});
data_peak.push({
lat: 3.6541333333e+01,
lng: 1.3703166667e+02,
cert : true,
content:'Name = Ushidake(JA/TY-044) peak = 985.200012 pos = 36.5413,137.0317 diff = 258.000000'
});
data_saddle.push({
lat: 3.6529444444e+01,
lng: 1.3703355556e+02,
content:'Saddle = 727.200012 pos = 36.5294,137.0336 diff = 258.000000'
});
data_peak.push({
lat: 3.5417888888e+01,
lng: 1.3640622222e+02,
cert : true,
content:'Name = Ibukiyama(JA/SI-001) peak = 1376.900024 pos = 35.4179,136.4062 diff = 649.000000'
});
data_saddle.push({
lat: 3.5595888888e+01,
lng: 1.3632133333e+02,
content:'Saddle = 727.900024 pos = 35.5959,136.3213 diff = 649.000000'
});
data_peak.push({
lat: 3.5520999999e+01,
lng: 1.3647166667e+02,
cert : false,
content:' Peak = 1054.300049 pos = 35.5210,136.4717 diff = 321.100037'
});
data_saddle.push({
lat: 3.5526555555e+01,
lng: 1.3646022222e+02,
content:'Saddle = 733.200012 pos = 35.5266,136.4602 diff = 321.100037'
});
data_peak.push({
lat: 3.5550222221e+01,
lng: 1.3633711111e+02,
cert : true,
content:'Name = Kanakusodake(JA/GF-072) peak = 1316.500000 pos = 35.5502,136.3371 diff = 470.099976'
});
data_saddle.push({
lat: 3.5467333332e+01,
lng: 1.3641322222e+02,
content:'Saddle = 846.400024 pos = 35.4673,136.4132 diff = 470.099976'
});
data_peak.push({
lat: 3.5507222221e+01,
lng: 1.3639655556e+02,
cert : true,
content:'Name = JA/GF-081(JA/GF-081) peak = 1258.900024 pos = 35.5072,136.3966 diff = 360.900024'
});
data_saddle.push({
lat: 3.5549999999e+01,
lng: 1.3636044444e+02,
content:'Saddle = 898.000000 pos = 35.5500,136.3604 diff = 360.900024'
});
data_peak.push({
lat: 3.5471666666e+01,
lng: 1.3640155556e+02,
cert : false,
content:' Peak = 1183.800049 pos = 35.4717,136.4016 diff = 172.200073'
});
data_saddle.push({
lat: 3.5482777777e+01,
lng: 1.3639511111e+02,
content:'Saddle = 1011.599976 pos = 35.4828,136.3951 diff = 172.200073'
});
data_peak.push({
lat: 3.5517999999e+01,
lng: 1.3642200000e+02,
cert : true,
content:'Name = JA/GF-084(JA/GF-084) peak = 1233.400024 pos = 35.5180,136.4220 diff = 205.099976'
});
data_saddle.push({
lat: 3.5516222221e+01,
lng: 1.3641400000e+02,
content:'Saddle = 1028.300049 pos = 35.5162,136.4140 diff = 205.099976'
});
data_peak.push({
lat: 3.5461777777e+01,
lng: 1.3642111111e+02,
cert : true,
content:'Name = JA/GF-108(JA/GF-108) peak = 1125.599976 pos = 35.4618,136.4211 diff = 184.399963'
});
data_saddle.push({
lat: 3.5437222221e+01,
lng: 1.3642088889e+02,
content:'Saddle = 941.200012 pos = 35.4372,136.4209 diff = 184.399963'
});
data_peak.push({
lat: 3.5769333333e+01,
lng: 1.3719444444e+02,
cert : true,
content:'Name = JA/GF-144(JA/GF-144) peak = 896.099976 pos = 35.7693,137.1944 diff = 167.699951'
});
data_saddle.push({
lat: 3.5774333333e+01,
lng: 1.3719744444e+02,
content:'Saddle = 728.400024 pos = 35.7743,137.1974 diff = 167.699951'
});
data_peak.push({
lat: 3.6435444444e+01,
lng: 1.3692633333e+02,
cert : false,
content:' Peak = 932.299988 pos = 36.4354,136.9263 diff = 200.099976'
});
data_saddle.push({
lat: 3.6433888889e+01,
lng: 1.3692200000e+02,
content:'Saddle = 732.200012 pos = 36.4339,136.9220 diff = 200.099976'
});
data_peak.push({
lat: 3.6477333333e+01,
lng: 1.3694288889e+02,
cert : true,
content:'Name = Takashouzuyama(JA/TY-034) peak = 1143.300049 pos = 36.4773,136.9429 diff = 405.200073'
});
data_saddle.push({
lat: 3.6447888889e+01,
lng: 1.3689911111e+02,
content:'Saddle = 738.099976 pos = 36.4479,136.8991 diff = 405.200073'
});
data_peak.push({
lat: 3.6229333333e+01,
lng: 1.3715544444e+02,
cert : false,
content:' Peak = 911.299988 pos = 36.2293,137.1554 diff = 163.099976'
});
data_saddle.push({
lat: 3.6225111111e+01,
lng: 1.3715566667e+02,
content:'Saddle = 748.200012 pos = 36.2251,137.1557 diff = 163.099976'
});
data_peak.push({
lat: 3.5160222221e+01,
lng: 1.3765133333e+02,
cert : false,
content:' Peak = 967.500000 pos = 35.1602,137.6513 diff = 213.900024'
});
data_saddle.push({
lat: 3.5168333332e+01,
lng: 1.3764600000e+02,
content:'Saddle = 753.599976 pos = 35.1683,137.6460 diff = 213.900024'
});
data_peak.push({
lat: 3.5792777777e+01,
lng: 1.3721166667e+02,
cert : true,
content:'Name = JA/GF-111(JA/GF-111) peak = 1100.400024 pos = 35.7928,137.2117 diff = 346.700012'
});
data_saddle.push({
lat: 3.5867999999e+01,
lng: 1.3718988889e+02,
content:'Saddle = 753.700012 pos = 35.8680,137.1899 diff = 346.700012'
});
data_peak.push({
lat: 3.5848333333e+01,
lng: 1.3720011111e+02,
cert : false,
content:' Peak = 1068.300049 pos = 35.8483,137.2001 diff = 157.900024'
});
data_saddle.push({
lat: 3.5815555555e+01,
lng: 1.3721333333e+02,
content:'Saddle = 910.400024 pos = 35.8156,137.2133 diff = 157.900024'
});
data_peak.push({
lat: 3.5706777777e+01,
lng: 1.3663400000e+02,
cert : true,
content:'Name = JA/GF-085(JA/GF-085) peak = 1233.800049 pos = 35.7068,136.6340 diff = 475.700073'
});
data_saddle.push({
lat: 3.5724666666e+01,
lng: 1.3664055556e+02,
content:'Saddle = 758.099976 pos = 35.7247,136.6406 diff = 475.700073'
});
data_peak.push({
lat: 3.5675222221e+01,
lng: 1.3661855556e+02,
cert : true,
content:'Name = JA/GF-121(JA/GF-121) peak = 1044.599976 pos = 35.6752,136.6186 diff = 252.500000'
});
data_saddle.push({
lat: 3.5687999999e+01,
lng: 1.3662922222e+02,
content:'Saddle = 792.099976 pos = 35.6880,136.6292 diff = 252.500000'
});
data_peak.push({
lat: 3.6416111111e+01,
lng: 1.3669066667e+02,
cert : false,
content:' Peak = 915.900024 pos = 36.4161,136.6907 diff = 153.000000'
});
data_saddle.push({
lat: 3.6403000000e+01,
lng: 1.3669700000e+02,
content:'Saddle = 762.900024 pos = 36.4030,136.6970 diff = 153.000000'
});
data_peak.push({
lat: 3.5113333332e+01,
lng: 1.3777622222e+02,
cert : true,
content:'Name = JA/AC-012(JA/AC-012) peak = 921.700012 pos = 35.1133,137.7762 diff = 158.400024'
});
data_saddle.push({
lat: 3.5141111110e+01,
lng: 1.3777022222e+02,
content:'Saddle = 763.299988 pos = 35.1411,137.7702 diff = 158.400024'
});
data_peak.push({
lat: 3.6131888888e+01,
lng: 1.3733855556e+02,
cert : true,
content:'Name = JA/GF-130(JA/GF-130) peak = 961.500000 pos = 36.1319,137.3386 diff = 194.599976'
});
data_saddle.push({
lat: 3.6132222222e+01,
lng: 1.3734666667e+02,
content:'Saddle = 766.900024 pos = 36.1322,137.3467 diff = 194.599976'
});
data_peak.push({
lat: 3.6493111111e+01,
lng: 1.3703911111e+02,
cert : true,
content:'Name = Takamine(JA/TY-038) peak = 1071.000000 pos = 36.4931,137.0391 diff = 299.200012'
});
data_saddle.push({
lat: 3.6449888889e+01,
lng: 1.3703144444e+02,
content:'Saddle = 771.799988 pos = 36.4499,137.0314 diff = 299.200012'
});
data_peak.push({
lat: 3.5934333333e+01,
lng: 1.3660122222e+02,
cert : true,
content:'Name = Arashimadake(JA/FI-005) peak = 1523.199951 pos = 35.9343,136.6012 diff = 750.799927'
});
data_saddle.push({
lat: 3.5836555555e+01,
lng: 1.3662611111e+02,
content:'Saddle = 772.400024 pos = 35.8366,136.6261 diff = 750.799927'
});
data_peak.push({
lat: 3.5848555555e+01,
lng: 1.3662411111e+02,
cert : false,
content:' Peak = 1284.599976 pos = 35.8486,136.6241 diff = 377.000000'
});
data_saddle.push({
lat: 3.5894999999e+01,
lng: 1.3657366667e+02,
content:'Saddle = 907.599976 pos = 35.8950,136.5737 diff = 377.000000'
});
data_peak.push({
lat: 3.5878444444e+01,
lng: 1.3653655556e+02,
cert : true,
content:'Name = JA/FI-021(JA/FI-021) peak = 1187.599976 pos = 35.8784,136.5366 diff = 235.099976'
});
data_saddle.push({
lat: 3.5865999999e+01,
lng: 1.3655522222e+02,
content:'Saddle = 952.500000 pos = 35.8660,136.5552 diff = 235.099976'
});
data_peak.push({
lat: 3.5866444444e+01,
lng: 1.3656566667e+02,
cert : true,
content:'Name = JA/FI-017(JA/FI-017) peak = 1204.099976 pos = 35.8664,136.5657 diff = 250.799988'
});
data_saddle.push({
lat: 3.5858777777e+01,
lng: 1.3657588889e+02,
content:'Saddle = 953.299988 pos = 35.8588,136.5759 diff = 250.799988'
});
data_peak.push({
lat: 3.5865666666e+01,
lng: 1.3665300000e+02,
cert : true,
content:'Name = JA/FI-020(JA/FI-020) peak = 1182.000000 pos = 35.8657,136.6530 diff = 179.299988'
});
data_saddle.push({
lat: 3.5860999999e+01,
lng: 1.3663944444e+02,
content:'Saddle = 1002.700012 pos = 35.8610,136.6394 diff = 179.299988'
});
data_peak.push({
lat: 3.5903333333e+01,
lng: 1.3658688889e+02,
cert : true,
content:'Name = JA/FI-011(JA/FI-011) peak = 1314.000000 pos = 35.9033,136.5869 diff = 174.199951'
});
data_saddle.push({
lat: 3.5919888888e+01,
lng: 1.3658766667e+02,
content:'Saddle = 1139.800049 pos = 35.9199,136.5877 diff = 174.199951'
});
data_peak.push({
lat: 3.5762444444e+01,
lng: 1.3651400000e+02,
cert : true,
content:'Name = Nougouhakusan (Gongensan)(JA/GF-031) peak = 1617.099976 pos = 35.7624,136.5140 diff = 839.399963'
});
data_saddle.push({
lat: 3.5869111111e+01,
lng: 1.3682744444e+02,
content:'Saddle = 777.700012 pos = 35.8691,136.8274 diff = 839.399963'
});
data_peak.push({
lat: 3.5648111110e+01,
lng: 1.3640244444e+02,
cert : true,
content:'Name = JA/GF-075(JA/GF-075) peak = 1291.199951 pos = 35.6481,136.4024 diff = 498.199951'
});
data_saddle.push({
lat: 3.5639777777e+01,
lng: 1.3637400000e+02,
content:'Saddle = 793.000000 pos = 35.6398,136.3740 diff = 498.199951'
});
data_peak.push({
lat: 3.5614777777e+01,
lng: 1.3638355556e+02,
cert : true,
content:'Name = JA/GF-113(JA/GF-113) peak = 1078.099976 pos = 35.6148,136.3836 diff = 177.299988'
});
data_saddle.push({
lat: 3.5632111110e+01,
lng: 1.3638133333e+02,
content:'Saddle = 900.799988 pos = 35.6321,136.3813 diff = 177.299988'
});
data_peak.push({
lat: 3.5635888888e+01,
lng: 1.3642666667e+02,
cert : true,
content:'Name = JA/GF-093(JA/GF-093) peak = 1191.800049 pos = 35.6359,136.4267 diff = 189.300049'
});
data_saddle.push({
lat: 3.5652222221e+01,
lng: 1.3642066667e+02,
content:'Saddle = 1002.500000 pos = 35.6522,136.4207 diff = 189.300049'
});
data_peak.push({
lat: 3.5750555555e+01,
lng: 1.3686055556e+02,
cert : true,
content:'Name = JA/GF-105(JA/GF-105) peak = 1131.699951 pos = 35.7506,136.8606 diff = 326.199951'
});
data_saddle.push({
lat: 3.5777111110e+01,
lng: 1.3683633333e+02,
content:'Saddle = 805.500000 pos = 35.7771,136.8363 diff = 326.199951'
});
data_peak.push({
lat: 3.5767888888e+01,
lng: 1.3684466667e+02,
cert : false,
content:' Peak = 993.599976 pos = 35.7679,136.8447 diff = 156.199951'
});
data_saddle.push({
lat: 3.5765888888e+01,
lng: 1.3683788889e+02,
content:'Saddle = 837.400024 pos = 35.7659,136.8379 diff = 156.199951'
});
data_peak.push({
lat: 3.5756888888e+01,
lng: 1.3635355556e+02,
cert : true,
content:'Name = JA/GF-096(JA/GF-096) peak = 1174.199951 pos = 35.7569,136.3536 diff = 366.999939'
});
data_saddle.push({
lat: 3.5766333333e+01,
lng: 1.3634411111e+02,
content:'Saddle = 807.200012 pos = 35.7663,136.3441 diff = 366.999939'
});
data_peak.push({
lat: 3.5795444444e+01,
lng: 1.3686533333e+02,
cert : true,
content:'Name = JA/GF-118(JA/GF-118) peak = 1051.900024 pos = 35.7954,136.8653 diff = 200.700012'
});
data_saddle.push({
lat: 3.5805666666e+01,
lng: 1.3686511111e+02,
content:'Saddle = 851.200012 pos = 35.8057,136.8651 diff = 200.700012'
});
data_peak.push({
lat: 3.5886222222e+01,
lng: 1.3643922222e+02,
cert : true,
content:'Name = Hekosan(JA/FI-006) peak = 1462.800049 pos = 35.8862,136.4392 diff = 610.200073'
});
data_saddle.push({
lat: 3.5818777777e+01,
lng: 1.3642255556e+02,
content:'Saddle = 852.599976 pos = 35.8188,136.4226 diff = 610.200073'
});
data_peak.push({
lat: 3.5849888888e+01,
lng: 1.3643644444e+02,
cert : true,
content:'Name = JA/FI-016(JA/FI-016) peak = 1217.500000 pos = 35.8499,136.4364 diff = 260.700012'
});
data_saddle.push({
lat: 3.5862444444e+01,
lng: 1.3642944444e+02,
content:'Saddle = 956.799988 pos = 35.8624,136.4294 diff = 260.700012'
});
data_peak.push({
lat: 3.5837555555e+01,
lng: 1.3642322222e+02,
cert : false,
content:' Peak = 1182.000000 pos = 35.8376,136.4232 diff = 180.200012'
});
data_saddle.push({
lat: 3.5841666666e+01,
lng: 1.3642933333e+02,
content:'Saddle = 1001.799988 pos = 35.8417,136.4293 diff = 180.200012'
});
data_peak.push({
lat: 3.5886555555e+01,
lng: 1.3646477778e+02,
cert : true,
content:'Name = JA/FI-009(JA/FI-009) peak = 1440.599976 pos = 35.8866,136.4648 diff = 183.400024'
});
data_saddle.push({
lat: 3.5891222222e+01,
lng: 1.3644355556e+02,
content:'Saddle = 1257.199951 pos = 35.8912,136.4436 diff = 183.400024'
});
data_peak.push({
lat: 3.5624999999e+01,
lng: 1.3631733333e+02,
cert : false,
content:' Peak = 1075.199951 pos = 35.6250,136.3173 diff = 207.399963'
});
data_saddle.push({
lat: 3.5617444444e+01,
lng: 1.3629788889e+02,
content:'Saddle = 867.799988 pos = 35.6174,136.2979 diff = 207.399963'
});
data_peak.push({
lat: 3.5658333333e+01,
lng: 1.3668144444e+02,
cert : true,
content:'Name = JA/GF-123(JA/GF-123) peak = 1040.199951 pos = 35.6583,136.6814 diff = 158.399963'
});
data_saddle.push({
lat: 3.5669444444e+01,
lng: 1.3669155556e+02,
content:'Saddle = 881.799988 pos = 35.6694,136.6916 diff = 158.399963'
});
data_peak.push({
lat: 3.5649444444e+01,
lng: 1.3635855556e+02,
cert : false,
content:' Peak = 1094.400024 pos = 35.6494,136.3586 diff = 207.000000'
});
data_saddle.push({
lat: 3.5658444444e+01,
lng: 1.3635033333e+02,
content:'Saddle = 887.400024 pos = 35.6584,136.3503 diff = 207.000000'
});
data_peak.push({
lat: 3.5600888888e+01,
lng: 1.3627000000e+02,
cert : false,
content:' Peak = 1133.800049 pos = 35.6009,136.2700 diff = 231.300049'
});
data_saddle.push({
lat: 3.5615111110e+01,
lng: 1.3629077778e+02,
content:'Saddle = 902.500000 pos = 35.6151,136.2908 diff = 231.300049'
});
data_peak.push({
lat: 3.5672333333e+01,
lng: 1.3631677778e+02,
cert : true,
content:'Name = JA/GF-073(JA/GF-073) peak = 1315.500000 pos = 35.6723,136.3168 diff = 411.900024'
});
data_saddle.push({
lat: 3.5794666666e+01,
lng: 1.3637877778e+02,
content:'Saddle = 903.599976 pos = 35.7947,136.3788 diff = 411.900024'
});
data_peak.push({
lat: 3.5786999999e+01,
lng: 1.3636011111e+02,
cert : true,
content:'Name = JA/GF-086(JA/GF-086) peak = 1225.500000 pos = 35.7870,136.3601 diff = 303.000000'
});
data_saddle.push({
lat: 3.5752888888e+01,
lng: 1.3631922222e+02,
content:'Saddle = 922.500000 pos = 35.7529,136.3192 diff = 303.000000'
});
data_peak.push({
lat: 3.5673666666e+01,
lng: 1.3624466667e+02,
cert : true,
content:'Name = JA/SI-005(JA/SI-005) peak = 1195.699951 pos = 35.6737,136.2447 diff = 258.199951'
});
data_saddle.push({
lat: 3.5666666666e+01,
lng: 1.3627088889e+02,
content:'Saddle = 937.500000 pos = 35.6667,136.2709 diff = 258.199951'
});
data_peak.push({
lat: 3.5722666666e+01,
lng: 1.3632044444e+02,
cert : false,
content:' Peak = 1293.000000 pos = 35.7227,136.3204 diff = 260.900024'
});
data_saddle.push({
lat: 3.5695666666e+01,
lng: 1.3630066667e+02,
content:'Saddle = 1032.099976 pos = 35.6957,136.3007 diff = 260.900024'
});
data_peak.push({
lat: 3.5723666666e+01,
lng: 1.3637166667e+02,
cert : true,
content:'Name = JA/GF-083(JA/GF-083) peak = 1244.099976 pos = 35.7237,136.3717 diff = 157.199951'
});
data_saddle.push({
lat: 3.5724777777e+01,
lng: 1.3634033333e+02,
content:'Saddle = 1086.900024 pos = 35.7248,136.3403 diff = 157.199951'
});
data_peak.push({
lat: 3.5683777777e+01,
lng: 1.3630011111e+02,
cert : true,
content:'Name = Sanshyuugatake(JA/GF-077) peak = 1291.099976 pos = 35.6838,136.3001 diff = 182.799927'
});
data_saddle.push({
lat: 3.5674555555e+01,
lng: 1.3630822222e+02,
content:'Saddle = 1108.300049 pos = 35.6746,136.3082 diff = 182.799927'
});
data_peak.push({
lat: 3.5853666666e+01,
lng: 1.3679955556e+02,
cert : true,
content:'Name = JA/FI-019(JA/FI-019) peak = 1191.800049 pos = 35.8537,136.7996 diff = 269.800049'
});
data_saddle.push({
lat: 3.5813666666e+01,
lng: 1.3679655556e+02,
content:'Saddle = 922.000000 pos = 35.8137,136.7966 diff = 269.800049'
});
data_peak.push({
lat: 3.5850222222e+01,
lng: 1.3682733333e+02,
cert : false,
content:' Peak = 1114.900024 pos = 35.8502,136.8273 diff = 153.400024'
});
data_saddle.push({
lat: 3.5842888888e+01,
lng: 1.3681644444e+02,
content:'Saddle = 961.500000 pos = 35.8429,136.8164 diff = 153.400024'
});
data_peak.push({
lat: 3.5839444444e+01,
lng: 1.3674622222e+02,
cert : true,
content:'Name = JA/FI-015(JA/FI-015) peak = 1246.000000 pos = 35.8394,136.7462 diff = 319.400024'
});
data_saddle.push({
lat: 3.5825888888e+01,
lng: 1.3673911111e+02,
content:'Saddle = 926.599976 pos = 35.8259,136.7391 diff = 319.400024'
});
data_peak.push({
lat: 3.5801111110e+01,
lng: 1.3674066667e+02,
cert : true,
content:'Name = JA/GF-044(JA/GF-044) peak = 1449.500000 pos = 35.8011,136.7407 diff = 506.799988'
});
data_saddle.push({
lat: 3.5792999999e+01,
lng: 1.3660588889e+02,
content:'Saddle = 942.700012 pos = 35.7930,136.6059 diff = 506.799988'
});
data_peak.push({
lat: 3.5821555555e+01,
lng: 1.3663011111e+02,
cert : true,
content:'Name = JA/FI-022(JA/FI-022) peak = 1180.300049 pos = 35.8216,136.6301 diff = 233.300049'
});
data_saddle.push({
lat: 3.5816111110e+01,
lng: 1.3663677778e+02,
content:'Saddle = 947.000000 pos = 35.8161,136.6368 diff = 233.300049'
});
data_peak.push({
lat: 3.5751999999e+01,
lng: 1.3669566667e+02,
cert : true,
content:'Name = JA/GF-069(JA/GF-069) peak = 1330.500000 pos = 35.7520,136.6957 diff = 353.900024'
});
data_saddle.push({
lat: 3.5763333333e+01,
lng: 1.3668433333e+02,
content:'Saddle = 976.599976 pos = 35.7633,136.6843 diff = 353.900024'
});
data_peak.push({
lat: 3.5720222221e+01,
lng: 1.3670266667e+02,
cert : true,
content:'Name = JA/GF-090(JA/GF-090) peak = 1214.099976 pos = 35.7202,136.7027 diff = 201.599976'
});
data_saddle.push({
lat: 3.5721222221e+01,
lng: 1.3668988889e+02,
content:'Saddle = 1012.500000 pos = 35.7212,136.6899 diff = 201.599976'
});
data_peak.push({
lat: 3.5731444444e+01,
lng: 1.3668644444e+02,
cert : false,
content:' Peak = 1181.500000 pos = 35.7314,136.6864 diff = 163.900024'
});
data_saddle.push({
lat: 3.5735999999e+01,
lng: 1.3668811111e+02,
content:'Saddle = 1017.599976 pos = 35.7360,136.6881 diff = 163.900024'
});
data_peak.push({
lat: 3.5796888888e+01,
lng: 1.3662655556e+02,
cert : true,
content:'Name = Byoubuzan(JA/GF-064) peak = 1353.099976 pos = 35.7969,136.6266 diff = 370.000000'
});
data_saddle.push({
lat: 3.5803777777e+01,
lng: 1.3664855556e+02,
content:'Saddle = 983.099976 pos = 35.8038,136.6486 diff = 370.000000'
});
data_peak.push({
lat: 3.5773444444e+01,
lng: 1.3668500000e+02,
cert : false,
content:' Peak = 1251.099976 pos = 35.7734,136.6850 diff = 214.699951'
});
data_saddle.push({
lat: 3.5789666666e+01,
lng: 1.3668255556e+02,
content:'Saddle = 1036.400024 pos = 35.7897,136.6826 diff = 214.699951'
});
data_peak.push({
lat: 3.5797888888e+01,
lng: 1.3677422222e+02,
cert : true,
content:'Name = JA/GF-050(JA/GF-050) peak = 1411.199951 pos = 35.7979,136.7742 diff = 298.599976'
});
data_saddle.push({
lat: 3.5809666666e+01,
lng: 1.3675711111e+02,
content:'Saddle = 1112.599976 pos = 35.8097,136.7571 diff = 298.599976'
});
data_peak.push({
lat: 3.5809888888e+01,
lng: 1.3671888889e+02,
cert : true,
content:'Name = Heikegadake(JA/FI-008) peak = 1440.800049 pos = 35.8099,136.7189 diff = 238.400024'
});
data_saddle.push({
lat: 3.5807111110e+01,
lng: 1.3673133333e+02,
content:'Saddle = 1202.400024 pos = 35.8071,136.7313 diff = 238.400024'
});
data_peak.push({
lat: 3.5816888888e+01,
lng: 1.3660188889e+02,
cert : true,
content:'Name = JA/FI-018(JA/FI-018) peak = 1200.300049 pos = 35.8169,136.6019 diff = 238.500061'
});
data_saddle.push({
lat: 3.5779666666e+01,
lng: 1.3656577778e+02,
content:'Saddle = 961.799988 pos = 35.7797,136.5658 diff = 238.500061'
});
data_peak.push({
lat: 3.5850999999e+01,
lng: 1.3648922222e+02,
cert : false,
content:' Peak = 1141.400024 pos = 35.8510,136.4892 diff = 159.000000'
});
data_saddle.push({
lat: 3.5837666666e+01,
lng: 1.3649377778e+02,
content:'Saddle = 982.400024 pos = 35.8377,136.4938 diff = 159.000000'
});
data_peak.push({
lat: 3.5809444444e+01,
lng: 1.3650577778e+02,
cert : true,
content:'Name = Ubagatake(JA/FI-007) peak = 1453.199951 pos = 35.8094,136.5058 diff = 430.999939'
});
data_saddle.push({
lat: 3.5779444444e+01,
lng: 1.3651855556e+02,
content:'Saddle = 1022.200012 pos = 35.7794,136.5186 diff = 430.999939'
});
data_peak.push({
lat: 3.5772666666e+01,
lng: 1.3644577778e+02,
cert : false,
content:' Peak = 1284.900024 pos = 35.7727,136.4458 diff = 182.099976'
});
data_saddle.push({
lat: 3.5770555555e+01,
lng: 1.3648988889e+02,
content:'Saddle = 1102.800049 pos = 35.7706,136.4899 diff = 182.099976'
});
data_peak.push({
lat: 3.5776777777e+01,
lng: 1.3648511111e+02,
cert : true,
content:'Name = JA/FI-013(JA/FI-013) peak = 1281.300049 pos = 35.7768,136.4851 diff = 163.300049'
});
data_saddle.push({
lat: 3.5777333333e+01,
lng: 1.3645444444e+02,
content:'Saddle = 1118.000000 pos = 35.7773,136.4544 diff = 163.300049'
});
data_peak.push({
lat: 3.5551555555e+01,
lng: 1.3757144444e+02,
cert : true,
content:'Name = JA/NN-180(JA/NN-180) peak = 1031.800049 pos = 35.5516,137.5714 diff = 244.900024'
});
data_saddle.push({
lat: 3.5538555555e+01,
lng: 1.3758444444e+02,
content:'Saddle = 786.900024 pos = 35.5386,137.5844 diff = 244.900024'
});
data_peak.push({
lat: 3.6071000000e+01,
lng: 1.3728011111e+02,
cert : true,
content:'Name = JA/GF-128(JA/GF-128) peak = 993.200012 pos = 36.0710,137.2801 diff = 204.700012'
});
data_saddle.push({
lat: 3.6082222222e+01,
lng: 1.3727900000e+02,
content:'Saddle = 788.500000 pos = 36.0822,137.2790 diff = 204.700012'
});
data_peak.push({
lat: 3.6193000000e+01,
lng: 1.3728422222e+02,
cert : false,
content:' Peak = 944.200012 pos = 36.1930,137.2842 diff = 154.400024'
});
data_saddle.push({
lat: 3.6198222222e+01,
lng: 1.3733444444e+02,
content:'Saddle = 789.799988 pos = 36.1982,137.3344 diff = 154.400024'
});
data_peak.push({
lat: 3.6155111111e+01,
lng: 1.3677144444e+02,
cert : true,
content:'Name = Hakusan (Gozengamine)(JA/GF-007) peak = 2701.500000 pos = 36.1551,136.7714 diff = 1911.500000'
});
data_saddle.push({
lat: 3.6080333333e+01,
lng: 1.3726455556e+02,
content:'Saddle = 790.000000 pos = 36.0803,137.2646 diff = 1911.500000'
});
data_peak.push({
lat: 3.6437666667e+01,
lng: 1.3683400000e+02,
cert : true,
content:'Name = JA/TY-045(JA/TY-045) peak = 981.000000 pos = 36.4377,136.8340 diff = 189.700012'
});
data_saddle.push({
lat: 3.6432111111e+01,
lng: 1.3683622222e+02,
content:'Saddle = 791.299988 pos = 36.4321,136.8362 diff = 189.700012'
});
data_peak.push({
lat: 3.6363666666e+01,
lng: 1.3684877778e+02,
cert : true,
content:'Name = Takanbouyama(JA/TY-036) peak = 1118.900024 pos = 36.3637,136.8488 diff = 307.200012'
});
data_saddle.push({
lat: 3.6366888889e+01,
lng: 1.3683644444e+02,
content:'Saddle = 811.700012 pos = 36.3669,136.8364 diff = 307.200012'
});
data_peak.push({
lat: 3.6481888889e+01,
lng: 1.3700733333e+02,
cert : true,
content:'Name = JA/TY-043(JA/TY-043) peak = 1005.400024 pos = 36.4819,137.0073 diff = 182.500000'
});
data_saddle.push({
lat: 3.6469888889e+01,
lng: 1.3700866667e+02,
content:'Saddle = 822.900024 pos = 36.4699,137.0087 diff = 182.500000'
});
data_peak.push({
lat: 3.6423555555e+01,
lng: 1.3671622222e+02,
cert : false,
content:' Peak = 984.500000 pos = 36.4236,136.7162 diff = 152.400024'
});
data_saddle.push({
lat: 3.6404111111e+01,
lng: 1.3672144444e+02,
content:'Saddle = 832.099976 pos = 36.4041,136.7214 diff = 152.400024'
});
data_peak.push({
lat: 3.6473111111e+01,
lng: 1.3705800000e+02,
cert : true,
content:'Name = JA/TY-042(JA/TY-042) peak = 1010.000000 pos = 36.4731,137.0580 diff = 172.099976'
});
data_saddle.push({
lat: 3.6458444444e+01,
lng: 1.3706200000e+02,
content:'Saddle = 837.900024 pos = 36.4584,137.0620 diff = 172.099976'
});
data_peak.push({
lat: 3.5982888888e+01,
lng: 1.3661866667e+02,
cert : false,
content:' Peak = 999.799988 pos = 35.9829,136.6187 diff = 157.099976'
});
data_saddle.push({
lat: 3.5997222222e+01,
lng: 1.3662255556e+02,
content:'Saddle = 842.700012 pos = 35.9972,136.6226 diff = 157.099976'
});
data_peak.push({
lat: 3.6417111111e+01,
lng: 1.3691644444e+02,
cert : true,
content:'Name = Takatuboyama(JA/TY-041) peak = 1013.400024 pos = 36.4171,136.9164 diff = 168.000000'
});
data_saddle.push({
lat: 3.6426444444e+01,
lng: 1.3691000000e+02,
content:'Saddle = 845.400024 pos = 36.4264,136.9100 diff = 168.000000'
});
data_peak.push({
lat: 3.6271111111e+01,
lng: 1.3706311111e+02,
cert : true,
content:'Name = JA/GF-074(JA/GF-074) peak = 1296.199951 pos = 36.2711,137.0631 diff = 447.599976'
});
data_saddle.push({
lat: 3.6244111111e+01,
lng: 1.3704511111e+02,
content:'Saddle = 848.599976 pos = 36.2441,137.0451 diff = 447.599976'
});
data_peak.push({
lat: 3.6226000000e+01,
lng: 1.3694288889e+02,
cert : true,
content:'Name = Sarugababayama(JA/GF-013) peak = 1874.400024 pos = 36.2260,136.9429 diff = 1000.500000'
});
data_saddle.push({
lat: 3.5996666666e+01,
lng: 1.3689888889e+02,
content:'Saddle = 873.900024 pos = 35.9967,136.8989 diff = 1000.500000'
});
data_peak.push({
lat: 3.6415222222e+01,
lng: 1.3695111111e+02,
cert : true,
content:'Name = JA/TY-040(JA/TY-040) peak = 1030.900024 pos = 36.4152,136.9511 diff = 154.500000'
});
data_saddle.push({
lat: 3.6402111111e+01,
lng: 1.3695300000e+02,
content:'Saddle = 876.400024 pos = 36.4021,136.9530 diff = 154.500000'
});
data_peak.push({
lat: 3.6448000000e+01,
lng: 1.3699866667e+02,
cert : true,
content:'Name = JA/TY-037(JA/TY-037) peak = 1101.699951 pos = 36.4480,136.9987 diff = 219.299927'
});
data_saddle.push({
lat: 3.6425666667e+01,
lng: 1.3699577778e+02,
content:'Saddle = 882.400024 pos = 36.4257,136.9958 diff = 219.299927'
});
data_peak.push({
lat: 3.5831999999e+01,
lng: 1.3704655556e+02,
cert : true,
content:'Name = JA/GF-100(JA/GF-100) peak = 1152.900024 pos = 35.8320,137.0466 diff = 265.400024'
});
data_saddle.push({
lat: 3.5833111110e+01,
lng: 1.3706155556e+02,
content:'Saddle = 887.500000 pos = 35.8331,137.0616 diff = 265.400024'
});
data_peak.push({
lat: 3.6102444444e+01,
lng: 1.3720366667e+02,
cert : true,
content:'Name = JA/GF-102(JA/GF-102) peak = 1141.800049 pos = 36.1024,137.2037 diff = 249.900024'
});
data_saddle.push({
lat: 3.6060777777e+01,
lng: 1.3717377778e+02,
content:'Saddle = 891.900024 pos = 36.0608,137.1738 diff = 249.900024'
});
data_peak.push({
lat: 3.6086222222e+01,
lng: 1.3721377778e+02,
cert : true,
content:'Name = JA/GF-106(JA/GF-106) peak = 1130.800049 pos = 36.0862,137.2138 diff = 192.900024'
});
data_saddle.push({
lat: 3.6095000000e+01,
lng: 1.3721344444e+02,
content:'Saddle = 937.900024 pos = 36.0950,137.2134 diff = 192.900024'
});
data_peak.push({
lat: 3.6066444444e+01,
lng: 1.3724800000e+02,
cert : false,
content:' Peak = 1086.599976 pos = 36.0664,137.2480 diff = 189.199951'
});
data_saddle.push({
lat: 3.6061777777e+01,
lng: 1.3722633333e+02,
content:'Saddle = 897.400024 pos = 36.0618,137.2263 diff = 189.199951'
});
data_peak.push({
lat: 3.6467555555e+01,
lng: 1.3719577778e+02,
cert : true,
content:'Name = JA/TY-035(JA/TY-035) peak = 1127.800049 pos = 36.4676,137.1958 diff = 225.300049'
});
data_saddle.push({
lat: 3.6455111111e+01,
lng: 1.3719166667e+02,
content:'Saddle = 902.500000 pos = 36.4551,137.1917 diff = 225.300049'
});
data_peak.push({
lat: 3.5836777777e+01,
lng: 1.3712333333e+02,
cert : true,
content:'Name = JA/GF-091(JA/GF-091) peak = 1213.099976 pos = 35.8368,137.1233 diff = 301.500000'
});
data_saddle.push({
lat: 3.5853555555e+01,
lng: 1.3707600000e+02,
content:'Saddle = 911.599976 pos = 35.8536,137.0760 diff = 301.500000'
});
data_peak.push({
lat: 3.5825111110e+01,
lng: 1.3707600000e+02,
cert : false,
content:' Peak = 1110.900024 pos = 35.8251,137.0760 diff = 168.600037'
});
data_saddle.push({
lat: 3.5836666666e+01,
lng: 1.3707988889e+02,
content:'Saddle = 942.299988 pos = 35.8367,137.0799 diff = 168.600037'
});
data_peak.push({
lat: 3.5903222222e+01,
lng: 1.3717844444e+02,
cert : true,
content:'Name = JA/GF-103(JA/GF-103) peak = 1138.199951 pos = 35.9032,137.1784 diff = 225.099976'
});
data_saddle.push({
lat: 3.5910111111e+01,
lng: 1.3717788889e+02,
content:'Saddle = 913.099976 pos = 35.9101,137.1779 diff = 225.099976'
});
data_peak.push({
lat: 3.5865555555e+01,
lng: 1.3715055556e+02,
cert : true,
content:'Name = JA/GF-110(JA/GF-110) peak = 1102.400024 pos = 35.8656,137.1506 diff = 164.700012'
});
data_saddle.push({
lat: 3.5882999999e+01,
lng: 1.3714233333e+02,
content:'Saddle = 937.700012 pos = 35.8830,137.1423 diff = 164.700012'
});
data_peak.push({
lat: 3.5922777777e+01,
lng: 1.3710233333e+02,
cert : true,
content:'Name = JA/GF-078(JA/GF-078) peak = 1285.199951 pos = 35.9228,137.1023 diff = 307.499939'
});
data_saddle.push({
lat: 3.5919111111e+01,
lng: 1.3706977778e+02,
content:'Saddle = 977.700012 pos = 35.9191,137.0698 diff = 307.499939'
});
data_peak.push({
lat: 3.6446222222e+01,
lng: 1.3719566667e+02,
cert : false,
content:' Peak = 1158.300049 pos = 36.4462,137.1957 diff = 166.000061'
});
data_saddle.push({
lat: 3.6438000000e+01,
lng: 1.3718266667e+02,
content:'Saddle = 992.299988 pos = 36.4380,137.1827 diff = 166.000061'
});
data_peak.push({
lat: 3.6189888889e+01,
lng: 1.3711255556e+02,
cert : true,
content:'Name = JA/GF-038(JA/GF-038) peak = 1518.300049 pos = 36.1899,137.1126 diff = 515.600037'
});
data_saddle.push({
lat: 3.6142444444e+01,
lng: 1.3711955556e+02,
content:'Saddle = 1002.700012 pos = 36.1424,137.1196 diff = 515.600037'
});
data_peak.push({
lat: 3.6216555555e+01,
lng: 1.3705000000e+02,
cert : false,
content:' Peak = 1383.000000 pos = 36.2166,137.0500 diff = 263.699951'
});
data_saddle.push({
lat: 3.6206222222e+01,
lng: 1.3710533333e+02,
content:'Saddle = 1119.300049 pos = 36.2062,137.1053 diff = 263.699951'
});
data_peak.push({
lat: 3.6219666666e+01,
lng: 1.3710044444e+02,
cert : true,
content:'Name = JA/GF-061(JA/GF-061) peak = 1366.099976 pos = 36.2197,137.1004 diff = 164.199951'
});
data_saddle.push({
lat: 3.6220444444e+01,
lng: 1.3707733333e+02,
content:'Saddle = 1201.900024 pos = 36.2204,137.0773 diff = 164.199951'
});
data_peak.push({
lat: 3.6421666667e+01,
lng: 1.3716411111e+02,
cert : true,
content:'Name = JA/GF-092(JA/GF-092) peak = 1206.199951 pos = 36.4217,137.1641 diff = 169.599976'
});
data_saddle.push({
lat: 3.6403000000e+01,
lng: 1.3714755556e+02,
content:'Saddle = 1036.599976 pos = 36.4030,137.1476 diff = 169.599976'
});
data_peak.push({
lat: 3.6415555555e+01,
lng: 1.3711200000e+02,
cert : true,
content:'Name = Shirakimine(JA/GF-032) peak = 1594.500000 pos = 36.4156,137.1120 diff = 530.500000'
});
data_saddle.push({
lat: 3.6381444444e+01,
lng: 1.3709455556e+02,
content:'Saddle = 1064.000000 pos = 36.3814,137.0946 diff = 530.500000'
});
data_peak.push({
lat: 3.6141777777e+01,
lng: 1.3705566667e+02,
cert : false,
content:' Peak = 1236.199951 pos = 36.1418,137.0557 diff = 153.000000'
});
data_saddle.push({
lat: 3.6120444444e+01,
lng: 1.3704444444e+02,
content:'Saddle = 1083.199951 pos = 36.1204,137.0444 diff = 153.000000'
});
data_peak.push({
lat: 3.6337333333e+01,
lng: 1.3694933333e+02,
cert : true,
content:'Name = Mitsugatsujiyama(JA/GF-019) peak = 1761.599976 pos = 36.3373,136.9493 diff = 673.900024'
});
data_saddle.push({
lat: 3.6310111111e+01,
lng: 1.3697255556e+02,
content:'Saddle = 1087.699951 pos = 36.3101,136.9726 diff = 673.900024'
});
data_peak.push({
lat: 3.6024222222e+01,
lng: 1.3723944444e+02,
cert : true,
content:'Name = JA/GF-042(JA/GF-042) peak = 1478.699951 pos = 36.0242,137.2394 diff = 390.799927'
});
data_saddle.push({
lat: 3.6012777777e+01,
lng: 1.3721300000e+02,
content:'Saddle = 1087.900024 pos = 36.0128,137.2130 diff = 390.799927'
});
data_peak.push({
lat: 3.5940333333e+01,
lng: 1.3697155556e+02,
cert : true,
content:'Name = Washigatake(JA/GF-025) peak = 1670.699951 pos = 35.9403,136.9716 diff = 582.099976'
});
data_saddle.push({
lat: 3.6068888888e+01,
lng: 1.3705277778e+02,
content:'Saddle = 1088.599976 pos = 36.0689,137.0528 diff = 582.099976'
});
data_peak.push({
lat: 3.6008333333e+01,
lng: 1.3714955556e+02,
cert : true,
content:'Name = Kaoredake(JA/GF-030) peak = 1625.099976 pos = 36.0083,137.1496 diff = 517.900024'
});
data_saddle.push({
lat: 3.6026111111e+01,
lng: 1.3707088889e+02,
content:'Saddle = 1107.199951 pos = 36.0261,137.0709 diff = 517.900024'
});
data_peak.push({
lat: 3.6012000000e+01,
lng: 1.3719433333e+02,
cert : true,
content:'Name = JA/GF-052(JA/GF-052) peak = 1402.199951 pos = 36.0120,137.1943 diff = 224.899902'
});
data_saddle.push({
lat: 3.6025777777e+01,
lng: 1.3719966667e+02,
content:'Saddle = 1177.300049 pos = 36.0258,137.1997 diff = 224.899902'
});
data_peak.push({
lat: 3.6017222222e+01,
lng: 1.3712900000e+02,
cert : false,
content:' Peak = 1397.699951 pos = 36.0172,137.1290 diff = 168.500000'
});
data_saddle.push({
lat: 3.6013666666e+01,
lng: 1.3713800000e+02,
content:'Saddle = 1229.199951 pos = 36.0137,137.1380 diff = 168.500000'
});
data_peak.push({
lat: 3.5956333333e+01,
lng: 1.3716222222e+02,
cert : true,
content:'Name = JA/GF-039(JA/GF-039) peak = 1510.599976 pos = 35.9563,137.1622 diff = 207.900024'
});
data_saddle.push({
lat: 3.5974333333e+01,
lng: 1.3716366667e+02,
content:'Saddle = 1302.699951 pos = 35.9743,137.1637 diff = 207.900024'
});
data_peak.push({
lat: 3.6090333333e+01,
lng: 1.3699088889e+02,
cert : true,
content:'Name = JA/GF-041(JA/GF-041) peak = 1480.599976 pos = 36.0903,136.9909 diff = 351.400024'
});
data_saddle.push({
lat: 3.6073666666e+01,
lng: 1.3698988889e+02,
content:'Saddle = 1129.199951 pos = 36.0737,136.9899 diff = 351.400024'
});
data_peak.push({
lat: 3.6056777777e+01,
lng: 1.3699766667e+02,
cert : false,
content:' Peak = 1293.400024 pos = 36.0568,136.9977 diff = 154.800049'
});
data_saddle.push({
lat: 3.6050888888e+01,
lng: 1.3701533333e+02,
content:'Saddle = 1138.599976 pos = 36.0509,137.0153 diff = 154.800049'
});
data_peak.push({
lat: 3.5884555555e+01,
lng: 1.3696955556e+02,
cert : false,
content:' Peak = 1342.099976 pos = 35.8846,136.9696 diff = 199.400024'
});
data_saddle.push({
lat: 3.5891666666e+01,
lng: 1.3697277778e+02,
content:'Saddle = 1142.699951 pos = 35.8917,136.9728 diff = 199.400024'
});
data_peak.push({
lat: 3.5981333333e+01,
lng: 1.3696000000e+02,
cert : false,
content:' Peak = 1351.800049 pos = 35.9813,136.9600 diff = 174.700073'
});
data_saddle.push({
lat: 3.5960888888e+01,
lng: 1.3696655556e+02,
content:'Saddle = 1177.099976 pos = 35.9609,136.9666 diff = 174.700073'
});
data_peak.push({
lat: 3.6044222222e+01,
lng: 1.3704866667e+02,
cert : true,
content:'Name = JA/GF-058(JA/GF-058) peak = 1378.599976 pos = 36.0442,137.0487 diff = 177.000000'
});
data_saddle.push({
lat: 3.6005444444e+01,
lng: 1.3703500000e+02,
content:'Saddle = 1201.599976 pos = 36.0054,137.0350 diff = 177.000000'
});
data_peak.push({
lat: 3.5957111111e+01,
lng: 1.3700433333e+02,
cert : true,
content:'Name = JA/GF-029(JA/GF-029) peak = 1630.800049 pos = 35.9571,137.0043 diff = 210.000000'
});
data_saddle.push({
lat: 3.5926999999e+01,
lng: 1.3699055556e+02,
content:'Saddle = 1420.800049 pos = 35.9270,136.9906 diff = 210.000000'
});
data_peak.push({
lat: 3.6137111111e+01,
lng: 1.3700355556e+02,
cert : true,
content:'Name = JA/GF-036(JA/GF-036) peak = 1534.500000 pos = 36.1371,137.0036 diff = 417.099976'
});
data_saddle.push({
lat: 3.6178111111e+01,
lng: 1.3701955556e+02,
content:'Saddle = 1117.400024 pos = 36.1781,137.0196 diff = 417.099976'
});
data_peak.push({
lat: 3.6097000000e+01,
lng: 1.3704488889e+02,
cert : true,
content:'Name = JA/GF-043(JA/GF-043) peak = 1464.800049 pos = 36.0970,137.0449 diff = 249.700073'
});
data_saddle.push({
lat: 3.6110888888e+01,
lng: 1.3702633333e+02,
content:'Saddle = 1215.099976 pos = 36.1109,137.0263 diff = 249.700073'
});
data_peak.push({
lat: 3.6351333333e+01,
lng: 1.3707988889e+02,
cert : true,
content:'Name = JA/GF-047(JA/GF-047) peak = 1438.400024 pos = 36.3513,137.0799 diff = 211.599976'
});
data_saddle.push({
lat: 3.6347444444e+01,
lng: 1.3706677778e+02,
content:'Saddle = 1226.800049 pos = 36.3474,137.0668 diff = 211.599976'
});
data_peak.push({
lat: 3.6350444444e+01,
lng: 1.3701555556e+02,
cert : true,
content:'Name = JA/TY-029(JA/TY-029) peak = 1453.900024 pos = 36.3504,137.0156 diff = 206.500000'
});
data_saddle.push({
lat: 3.6347666666e+01,
lng: 1.3702944444e+02,
content:'Saddle = 1247.400024 pos = 36.3477,137.0294 diff = 206.500000'
});
data_peak.push({
lat: 3.6378888889e+01,
lng: 1.3704888889e+02,
cert : true,
content:'Name = Kongoudouzan(JA/TY-026) peak = 1647.800049 pos = 36.3789,137.0489 diff = 391.000000'
});
data_saddle.push({
lat: 3.6348444444e+01,
lng: 1.3705066667e+02,
content:'Saddle = 1256.800049 pos = 36.3484,137.0507 diff = 391.000000'
});
data_peak.push({
lat: 3.6265666666e+01,
lng: 1.3694955556e+02,
cert : false,
content:' Peak = 1431.900024 pos = 36.2657,136.9496 diff = 174.400024'
});
data_saddle.push({
lat: 3.6260000000e+01,
lng: 1.3695444444e+02,
content:'Saddle = 1257.500000 pos = 36.2600,136.9544 diff = 174.400024'
});
data_peak.push({
lat: 3.6334444444e+01,
lng: 1.3705200000e+02,
cert : true,
content:'Name = JA/GF-045(JA/GF-045) peak = 1443.900024 pos = 36.3344,137.0520 diff = 182.300049'
});
data_saddle.push({
lat: 3.6317222222e+01,
lng: 1.3702688889e+02,
content:'Saddle = 1261.599976 pos = 36.3172,137.0269 diff = 182.300049'
});
data_peak.push({
lat: 3.6280111111e+01,
lng: 1.3695711111e+02,
cert : true,
content:'Name = JA/GF-035(JA/GF-035) peak = 1554.300049 pos = 36.2801,136.9571 diff = 277.700073'
});
data_saddle.push({
lat: 3.6261555555e+01,
lng: 1.3696577778e+02,
content:'Saddle = 1276.599976 pos = 36.2616,136.9658 diff = 277.700073'
});
data_peak.push({
lat: 3.6177777777e+01,
lng: 1.3694422222e+02,
cert : false,
content:' Peak = 1757.699951 pos = 36.1778,136.9442 diff = 165.299927'
});
data_saddle.push({
lat: 3.6194777777e+01,
lng: 1.3694788889e+02,
content:'Saddle = 1592.400024 pos = 36.1948,136.9479 diff = 165.299927'
});
data_peak.push({
lat: 3.6388777778e+01,
lng: 1.3673988889e+02,
cert : false,
content:' Peak = 1053.500000 pos = 36.3888,136.7399 diff = 172.799988'
});
data_saddle.push({
lat: 3.6385666666e+01,
lng: 1.3675877778e+02,
content:'Saddle = 880.700012 pos = 36.3857,136.7588 diff = 172.799988'
});
data_peak.push({
lat: 3.6430666667e+01,
lng: 1.3689155556e+02,
cert : false,
content:' Peak = 1071.199951 pos = 36.4307,136.8916 diff = 168.799927'
});
data_saddle.push({
lat: 3.6432222222e+01,
lng: 1.3688011111e+02,
content:'Saddle = 902.400024 pos = 36.4322,136.8801 diff = 168.799927'
});
data_peak.push({
lat: 3.5939222222e+01,
lng: 1.3679233333e+02,
cert : true,
content:'Name = JA/GF-056(JA/GF-056) peak = 1384.500000 pos = 35.9392,136.7923 diff = 437.099976'
});
data_saddle.push({
lat: 3.5960111111e+01,
lng: 1.3680788889e+02,
content:'Saddle = 947.400024 pos = 35.9601,136.8079 diff = 437.099976'
});
data_peak.push({
lat: 3.5896999999e+01,
lng: 1.3672977778e+02,
cert : true,
content:'Name = JA/FI-023(JA/FI-023) peak = 1160.599976 pos = 35.8970,136.7298 diff = 178.899963'
});
data_saddle.push({
lat: 3.5896333333e+01,
lng: 1.3674522222e+02,
content:'Saddle = 981.700012 pos = 35.8963,136.7452 diff = 178.899963'
});
data_peak.push({
lat: 3.5890888888e+01,
lng: 1.3681111111e+02,
cert : true,
content:'Name = JA/FI-014(JA/FI-014) peak = 1270.000000 pos = 35.8909,136.8111 diff = 206.900024'
});
data_saddle.push({
lat: 3.5913111111e+01,
lng: 1.3680844444e+02,
content:'Saddle = 1063.099976 pos = 35.9131,136.8084 diff = 206.900024'
});
data_peak.push({
lat: 3.5927666666e+01,
lng: 1.3678377778e+02,
cert : true,
content:'Name = JA/GF-063(JA/GF-063) peak = 1358.900024 pos = 35.9277,136.7838 diff = 205.900024'
});
data_saddle.push({
lat: 3.5934222222e+01,
lng: 1.3678755556e+02,
content:'Saddle = 1153.000000 pos = 35.9342,136.7876 diff = 205.900024'
});
data_peak.push({
lat: 3.5956999999e+01,
lng: 1.3666844444e+02,
cert : true,
content:'Name = JA/FI-010(JA/FI-010) peak = 1327.400024 pos = 35.9570,136.6684 diff = 356.400024'
});
data_saddle.push({
lat: 3.5966777777e+01,
lng: 1.3669622222e+02,
content:'Saddle = 971.000000 pos = 35.9668,136.6962 diff = 356.400024'
});
data_peak.push({
lat: 3.6404222222e+01,
lng: 1.3684344444e+02,
cert : true,
content:'Name = Sarugayama(JA/TY-030) peak = 1447.099976 pos = 36.4042,136.8434 diff = 459.500000'
});
data_saddle.push({
lat: 3.6372777778e+01,
lng: 1.3682377778e+02,
content:'Saddle = 987.599976 pos = 36.3728,136.8238 diff = 459.500000'
});
data_peak.push({
lat: 3.6427888889e+01,
lng: 1.3687277778e+02,
cert : true,
content:'Name = Hakamakoshiyama(JA/TY-033) peak = 1158.000000 pos = 36.4279,136.8728 diff = 166.900024'
});
data_saddle.push({
lat: 3.6431222222e+01,
lng: 1.3686133333e+02,
content:'Saddle = 991.099976 pos = 36.4312,136.8613 diff = 166.900024'
});
data_peak.push({
lat: 3.6304888889e+01,
lng: 1.3686655556e+02,
cert : true,
content:'Name = JA/GF-079(JA/GF-079) peak = 1278.099976 pos = 36.3049,136.8666 diff = 236.500000'
});
data_saddle.push({
lat: 3.6291555555e+01,
lng: 1.3685800000e+02,
content:'Saddle = 1041.599976 pos = 36.2916,136.8580 diff = 236.500000'
});
data_peak.push({
lat: 3.6373222222e+01,
lng: 1.3671544444e+02,
cert : true,
content:'Name = Kuchisanboudake(JA/IK-007) peak = 1267.500000 pos = 36.3732,136.7154 diff = 204.500000'
});
data_saddle.push({
lat: 3.6367333333e+01,
lng: 1.3673000000e+02,
content:'Saddle = 1063.000000 pos = 36.3673,136.7300 diff = 204.500000'
});
data_peak.push({
lat: 3.6044777777e+01,
lng: 1.3691577778e+02,
cert : false,
content:' Peak = 1272.599976 pos = 36.0448,136.9158 diff = 190.099976'
});
data_saddle.push({
lat: 3.6033666666e+01,
lng: 1.3690511111e+02,
content:'Saddle = 1082.500000 pos = 36.0337,136.9051 diff = 190.099976'
});
data_peak.push({
lat: 3.6056000000e+01,
lng: 1.3688844444e+02,
cert : false,
content:' Peak = 1362.800049 pos = 36.0560,136.8884 diff = 271.300049'
});
data_saddle.push({
lat: 3.6039222222e+01,
lng: 1.3687066667e+02,
content:'Saddle = 1091.500000 pos = 36.0392,136.8707 diff = 271.300049'
});
data_peak.push({
lat: 3.6270333333e+01,
lng: 1.3674177778e+02,
cert : true,
content:'Name = Bunaoyama(JA/IK-005) peak = 1364.900024 pos = 36.2703,136.7418 diff = 167.599976'
});
data_saddle.push({
lat: 3.6278111111e+01,
lng: 1.3674944444e+02,
content:'Saddle = 1197.300049 pos = 36.2781,136.7494 diff = 167.599976'
});
data_peak.push({
lat: 3.6090555555e+01,
lng: 1.3665133333e+02,
cert : true,
content:'Name = Oochousan(JA/IK-001) peak = 1671.199951 pos = 36.0906,136.6513 diff = 409.599976'
});
data_saddle.push({
lat: 3.6075000000e+01,
lng: 1.3670166667e+02,
content:'Saddle = 1261.599976 pos = 36.0750,136.7017 diff = 409.599976'
});
data_peak.push({
lat: 3.6046333333e+01,
lng: 1.3662188889e+02,
cert : true,
content:'Name = Kyougadake(JA/FI-002) peak = 1622.099976 pos = 36.0463,136.6219 diff = 281.900024'
});
data_saddle.push({
lat: 3.6060666666e+01,
lng: 1.3663700000e+02,
content:'Saddle = 1340.199951 pos = 36.0607,136.6370 diff = 281.900024'
});
data_peak.push({
lat: 3.6098333333e+01,
lng: 1.3663733333e+02,
cert : true,
content:'Name = JA/FI-004(JA/FI-004) peak = 1548.000000 pos = 36.0983,136.6373 diff = 159.000000'
});
data_saddle.push({
lat: 3.6095333333e+01,
lng: 1.3664500000e+02,
content:'Saddle = 1389.000000 pos = 36.0953,136.6450 diff = 159.000000'
});
data_peak.push({
lat: 3.6067444444e+01,
lng: 1.3666200000e+02,
cert : true,
content:'Name = Akausagiyama(JA/FI-001) peak = 1624.300049 pos = 36.0674,136.6620 diff = 229.900024'
});
data_saddle.push({
lat: 3.6073888888e+01,
lng: 1.3665777778e+02,
content:'Saddle = 1394.400024 pos = 36.0739,136.6578 diff = 229.900024'
});
data_peak.push({
lat: 3.6277222222e+01,
lng: 1.3685166667e+02,
cert : false,
content:' Peak = 1441.099976 pos = 36.2772,136.8517 diff = 164.000000'
});
data_saddle.push({
lat: 3.6269666666e+01,
lng: 1.3684377778e+02,
content:'Saddle = 1277.099976 pos = 36.2697,136.8438 diff = 164.000000'
});
data_peak.push({
lat: 3.6001444444e+01,
lng: 1.3683777778e+02,
cert : true,
content:'Name = Dainichigatake(JA/GF-023) peak = 1708.300049 pos = 36.0014,136.8378 diff = 360.500000'
});
data_saddle.push({
lat: 3.6024333333e+01,
lng: 1.3680822222e+02,
content:'Saddle = 1347.800049 pos = 36.0243,136.8082 diff = 360.500000'
});
data_peak.push({
lat: 3.6365222222e+01,
lng: 1.3680366667e+02,
cert : true,
content:'Name = Daimonzan(JA/TY-028) peak = 1570.800049 pos = 36.3652,136.8037 diff = 209.900024'
});
data_saddle.push({
lat: 3.6352333333e+01,
lng: 1.3679855556e+02,
content:'Saddle = 1360.900024 pos = 36.3523,136.7986 diff = 209.900024'
});
data_peak.push({
lat: 3.6241666666e+01,
lng: 1.3677633333e+02,
cert : false,
content:' Peak = 1548.599976 pos = 36.2417,136.7763 diff = 154.299927'
});
data_saddle.push({
lat: 3.6235555555e+01,
lng: 1.3678166667e+02,
content:'Saddle = 1394.300049 pos = 36.2356,136.7817 diff = 154.299927'
});
data_peak.push({
lat: 3.5992777777e+01,
lng: 1.3672211111e+02,
cert : true,
content:'Name = JA/FI-003(JA/FI-003) peak = 1601.099976 pos = 35.9928,136.7221 diff = 192.900024'
});
data_saddle.push({
lat: 3.6002666666e+01,
lng: 1.3672922222e+02,
content:'Saddle = 1408.199951 pos = 36.0027,136.7292 diff = 192.900024'
});
data_peak.push({
lat: 3.6220444444e+01,
lng: 1.3668500000e+02,
cert : true,
content:'Name = Shougasan(JA/IK-002) peak = 1624.400024 pos = 36.2204,136.6850 diff = 188.000000'
});
data_saddle.push({
lat: 3.6205333333e+01,
lng: 1.3667744444e+02,
content:'Saddle = 1436.400024 pos = 36.2053,136.6774 diff = 188.000000'
});
data_peak.push({
lat: 3.6204333333e+01,
lng: 1.3668622222e+02,
cert : true,
content:'Name = JA/IK-003(JA/IK-003) peak = 1607.099976 pos = 36.2043,136.6862 diff = 168.799927'
});
data_saddle.push({
lat: 3.6197666666e+01,
lng: 1.3669122222e+02,
content:'Saddle = 1438.300049 pos = 36.1977,136.6912 diff = 168.799927'
});
data_peak.push({
lat: 3.6012777777e+01,
lng: 1.3673222222e+02,
cert : true,
content:'Name = Nobusegadake(JA/GF-024) peak = 1672.400024 pos = 36.0128,136.7322 diff = 220.700073'
});
data_saddle.push({
lat: 3.6051333333e+01,
lng: 1.3673600000e+02,
content:'Saddle = 1451.699951 pos = 36.0513,136.7360 diff = 220.700073'
});
data_peak.push({
lat: 3.6041222222e+01,
lng: 1.3673533333e+02,
cert : true,
content:'Name = JA/GF-026(JA/GF-026) peak = 1668.199951 pos = 36.0412,136.7353 diff = 206.199951'
});
data_saddle.push({
lat: 3.6019000000e+01,
lng: 1.3673233333e+02,
content:'Saddle = 1462.000000 pos = 36.0190,136.7323 diff = 206.199951'
});
data_peak.push({
lat: 3.6029666666e+01,
lng: 1.3673444444e+02,
cert : false,
content:' Peak = 1644.500000 pos = 36.0297,136.7344 diff = 154.500000'
});
data_saddle.push({
lat: 3.6035333333e+01,
lng: 1.3673533333e+02,
content:'Saddle = 1490.000000 pos = 36.0353,136.7353 diff = 154.500000'
});
data_peak.push({
lat: 3.6298555555e+01,
lng: 1.3679211111e+02,
cert : true,
content:'Name = Oizurugadake(JA/GF-014) peak = 1840.900024 pos = 36.2986,136.7921 diff = 309.000000'
});
data_saddle.push({
lat: 3.6271222222e+01,
lng: 1.3681322222e+02,
content:'Saddle = 1531.900024 pos = 36.2712,136.8132 diff = 309.000000'
});
data_peak.push({
lat: 3.6320555555e+01,
lng: 1.3678955556e+02,
cert : true,
content:'Name = Oogasayama(JA/TY-022) peak = 1821.699951 pos = 36.3206,136.7896 diff = 273.299927'
});
data_saddle.push({
lat: 3.6309555555e+01,
lng: 1.3678955556e+02,
content:'Saddle = 1548.400024 pos = 36.3096,136.7896 diff = 273.299927'
});
data_peak.push({
lat: 3.6049888888e+01,
lng: 1.3679688889e+02,
cert : true,
content:'Name = JA/GF-018(JA/GF-018) peak = 1781.500000 pos = 36.0499,136.7969 diff = 219.300049'
});
data_saddle.push({
lat: 3.6053111111e+01,
lng: 1.3677755556e+02,
content:'Saddle = 1562.199951 pos = 36.0531,136.7776 diff = 219.300049'
});
data_peak.push({
lat: 3.6223000000e+01,
lng: 1.3679911111e+02,
cert : false,
content:' Peak = 1773.500000 pos = 36.2230,136.7991 diff = 185.300049'
});
data_saddle.push({
lat: 3.6214666666e+01,
lng: 1.3679911111e+02,
content:'Saddle = 1588.199951 pos = 36.2147,136.7991 diff = 185.300049'
});
data_peak.push({
lat: 3.6179777777e+01,
lng: 1.3684622222e+02,
cert : true,
content:'Name = JA/GF-010(JA/GF-010) peak = 2149.100098 pos = 36.1798,136.8462 diff = 355.300049'
});
data_saddle.push({
lat: 3.6182777777e+01,
lng: 1.3682022222e+02,
content:'Saddle = 1793.800049 pos = 36.1828,136.8202 diff = 355.300049'
});
data_peak.push({
lat: 3.6162666666e+01,
lng: 1.3673222222e+02,
cert : false,
content:' Peak = 2082.899902 pos = 36.1627,136.7322 diff = 155.099854'
});
data_saddle.push({
lat: 3.6159333333e+01,
lng: 1.3673822222e+02,
content:'Saddle = 1927.800049 pos = 36.1593,136.7382 diff = 155.099854'
});
data_peak.push({
lat: 3.6105555555e+01,
lng: 1.3676566667e+02,
cert : true,
content:'Name = Bessan(JA/GF-008) peak = 2397.100098 pos = 36.1056,136.7657 diff = 254.600098'
});
data_saddle.push({
lat: 3.6138111111e+01,
lng: 1.3678000000e+02,
content:'Saddle = 2142.500000 pos = 36.1381,136.7800 diff = 254.600098'
});
data_peak.push({
lat: 3.5271666666e+01,
lng: 1.3777211111e+02,
cert : true,
content:'Name = JA/NN-174(JA/NN-174) peak = 1131.099976 pos = 35.2717,137.7721 diff = 313.399963'
});
data_saddle.push({
lat: 3.5272999999e+01,
lng: 1.3776044444e+02,
content:'Saddle = 817.700012 pos = 35.2730,137.7604 diff = 313.399963'
});
data_peak.push({
lat: 3.5654888888e+01,
lng: 1.3763511111e+02,
cert : true,
content:'Name = JA/NN-176(JA/NN-176) peak = 1100.199951 pos = 35.6549,137.6351 diff = 262.999939'
});
data_saddle.push({
lat: 3.5653333333e+01,
lng: 1.3765522222e+02,
content:'Saddle = 837.200012 pos = 35.6533,137.6552 diff = 262.999939'
});
data_peak.push({
lat: 3.6096777777e+01,
lng: 1.3727811111e+02,
cert : true,
content:'Name = JA/GF-117(JA/GF-117) peak = 1052.199951 pos = 36.0968,137.2781 diff = 185.199951'
});
data_saddle.push({
lat: 3.6105222222e+01,
lng: 1.3731722222e+02,
content:'Saddle = 867.000000 pos = 36.1052,137.3172 diff = 185.199951'
});
data_peak.push({
lat: 3.6323333333e+01,
lng: 1.3723577778e+02,
cert : true,
content:'Name = JA/GF-049(JA/GF-049) peak = 1422.599976 pos = 36.3233,137.2358 diff = 542.799988'
});
data_saddle.push({
lat: 3.6265333333e+01,
lng: 1.3722166667e+02,
content:'Saddle = 879.799988 pos = 36.2653,137.2217 diff = 542.799988'
});
data_peak.push({
lat: 3.6278888889e+01,
lng: 1.3719244444e+02,
cert : false,
content:' Peak = 1142.000000 pos = 36.2789,137.1924 diff = 243.900024'
});
data_saddle.push({
lat: 3.6302111111e+01,
lng: 1.3722166667e+02,
content:'Saddle = 898.099976 pos = 36.3021,137.2217 diff = 243.900024'
});
data_peak.push({
lat: 3.6368888889e+01,
lng: 1.3722366667e+02,
cert : true,
content:'Name = JA/GF-089(JA/GF-089) peak = 1221.699951 pos = 36.3689,137.2237 diff = 229.799927'
});
data_saddle.push({
lat: 3.6363888889e+01,
lng: 1.3723444444e+02,
content:'Saddle = 991.900024 pos = 36.3639,137.2344 diff = 229.799927'
});
data_peak.push({
lat: 3.6401444444e+01,
lng: 1.3725800000e+02,
cert : true,
content:'Name = JA/GF-054(JA/GF-054) peak = 1392.599976 pos = 36.4014,137.2580 diff = 270.500000'
});
data_saddle.push({
lat: 3.6363555555e+01,
lng: 1.3724233333e+02,
content:'Saddle = 1122.099976 pos = 36.3636,137.2423 diff = 270.500000'
});
data_peak.push({
lat: 3.6308222222e+01,
lng: 1.3717544444e+02,
cert : true,
content:'Name = JA/GF-067(JA/GF-067) peak = 1334.699951 pos = 36.3082,137.1754 diff = 187.899902'
});
data_saddle.push({
lat: 3.6310222222e+01,
lng: 1.3720677778e+02,
content:'Saddle = 1146.800049 pos = 36.3102,137.2068 diff = 187.899902'
});
data_peak.push({
lat: 3.6337888889e+01,
lng: 1.3726800000e+02,
cert : false,
content:' Peak = 1350.400024 pos = 36.3379,137.2680 diff = 170.099976'
});
data_saddle.push({
lat: 3.6328555555e+01,
lng: 1.3725344444e+02,
content:'Saddle = 1180.300049 pos = 36.3286,137.2534 diff = 170.099976'
});
data_peak.push({
lat: 3.6018777777e+01,
lng: 1.3799266667e+02,
cert : true,
content:'Name = JA/NN-156(JA/NN-156) peak = 1290.599976 pos = 36.0188,137.9927 diff = 407.000000'
});
data_saddle.push({
lat: 3.6074666666e+01,
lng: 1.3797922222e+02,
content:'Saddle = 883.599976 pos = 36.0747,137.9792 diff = 407.000000'
});
data_peak.push({
lat: 3.6075222222e+01,
lng: 1.3799033333e+02,
cert : false,
content:' Peak = 1094.599976 pos = 36.0752,137.9903 diff = 197.000000'
});
data_saddle.push({
lat: 3.6071000000e+01,
lng: 1.3799988889e+02,
content:'Saddle = 897.599976 pos = 36.0710,137.9999 diff = 197.000000'
});
data_peak.push({
lat: 3.5153111110e+01,
lng: 1.3776688889e+02,
cert : true,
content:'Name = JA/AC-005(JA/AC-005) peak = 1108.699951 pos = 35.1531,137.7669 diff = 215.599976'
});
data_saddle.push({
lat: 3.5169222221e+01,
lng: 1.3775811111e+02,
content:'Saddle = 893.099976 pos = 35.1692,137.7581 diff = 215.599976'
});
data_peak.push({
lat: 3.5164111110e+01,
lng: 1.3759544444e+02,
cert : false,
content:' Peak = 1054.199951 pos = 35.1641,137.5954 diff = 151.999939'
});
data_saddle.push({
lat: 3.5166222221e+01,
lng: 1.3758944444e+02,
content:'Saddle = 902.200012 pos = 35.1662,137.5894 diff = 151.999939'
});
data_peak.push({
lat: 3.5190444443e+01,
lng: 1.3758088889e+02,
cert : false,
content:' Peak = 1238.500000 pos = 35.1904,137.5809 diff = 331.000000'
});
data_saddle.push({
lat: 3.5190666666e+01,
lng: 1.3760644444e+02,
content:'Saddle = 907.500000 pos = 35.1907,137.6064 diff = 331.000000'
});
data_peak.push({
lat: 3.5422777777e+01,
lng: 1.3772300000e+02,
cert : false,
content:' Peak = 1071.099976 pos = 35.4228,137.7230 diff = 163.299988'
});
data_saddle.push({
lat: 3.5419888888e+01,
lng: 1.3771944444e+02,
content:'Saddle = 907.799988 pos = 35.4199,137.7194 diff = 163.299988'
});
data_peak.push({
lat: 3.6442777778e+01,
lng: 1.3781822222e+02,
cert : true,
content:'Name = JA/NN-178(JA/NN-178) peak = 1092.400024 pos = 36.4428,137.8182 diff = 170.200012'
});
data_saddle.push({
lat: 3.6441000000e+01,
lng: 1.3781477778e+02,
content:'Saddle = 922.200012 pos = 36.4410,137.8148 diff = 170.200012'
});
data_peak.push({
lat: 3.6283222222e+01,
lng: 1.3727477778e+02,
cert : false,
content:' Peak = 1144.000000 pos = 36.2832,137.2748 diff = 219.500000'
});
data_saddle.push({
lat: 3.6276000000e+01,
lng: 1.3726900000e+02,
content:'Saddle = 924.500000 pos = 36.2760,137.2690 diff = 219.500000'
});
data_peak.push({
lat: 3.5225666666e+01,
lng: 1.3778788889e+02,
cert : true,
content:'Name = JA/NN-168(JA/NN-168) peak = 1204.800049 pos = 35.2257,137.7879 diff = 246.900024'
});
data_saddle.push({
lat: 3.5222333332e+01,
lng: 1.3773177778e+02,
content:'Saddle = 957.900024 pos = 35.2223,137.7318 diff = 246.900024'
});
data_peak.push({
lat: 3.6084222222e+01,
lng: 1.3794222222e+02,
cert : false,
content:' Peak = 1160.500000 pos = 36.0842,137.9422 diff = 188.299988'
});
data_saddle.push({
lat: 3.6078888888e+01,
lng: 1.3794411111e+02,
content:'Saddle = 972.200012 pos = 36.0789,137.9441 diff = 188.299988'
});
data_peak.push({
lat: 3.5321111110e+01,
lng: 1.3760600000e+02,
cert : false,
content:' Peak = 1271.000000 pos = 35.3211,137.6060 diff = 293.700012'
});
data_saddle.push({
lat: 3.5305333332e+01,
lng: 1.3762211111e+02,
content:'Saddle = 977.299988 pos = 35.3053,137.6221 diff = 293.700012'
});
data_peak.push({
lat: 3.5449555555e+01,
lng: 1.3769633333e+02,
cert : false,
content:' Peak = 1135.199951 pos = 35.4496,137.6963 diff = 153.399963'
});
data_saddle.push({
lat: 3.5445222221e+01,
lng: 1.3769588889e+02,
content:'Saddle = 981.799988 pos = 35.4452,137.6959 diff = 153.399963'
});
data_peak.push({
lat: 3.5208888888e+01,
lng: 1.3761511111e+02,
cert : false,
content:' Peak = 1160.500000 pos = 35.2089,137.6151 diff = 153.799988'
});
data_saddle.push({
lat: 3.5198333332e+01,
lng: 1.3761988889e+02,
content:'Saddle = 1006.700012 pos = 35.1983,137.6199 diff = 153.799988'
});
data_peak.push({
lat: 3.6027333333e+01,
lng: 1.3796133333e+02,
cert : true,
content:'Name = JA/NN-166(JA/NN-166) peak = 1201.900024 pos = 36.0273,137.9613 diff = 190.800049'
});
data_saddle.push({
lat: 3.6027444444e+01,
lng: 1.3793666667e+02,
content:'Saddle = 1011.099976 pos = 36.0274,137.9367 diff = 190.800049'
});
data_peak.push({
lat: 3.5285444443e+01,
lng: 1.3760744444e+02,
cert : false,
content:' Peak = 1181.400024 pos = 35.2854,137.6074 diff = 153.300049'
});
data_saddle.push({
lat: 3.5279222221e+01,
lng: 1.3761333333e+02,
content:'Saddle = 1028.099976 pos = 35.2792,137.6133 diff = 153.300049'
});
data_peak.push({
lat: 3.5941666666e+01,
lng: 1.3777122222e+02,
cert : true,
content:'Name = JA/NN-152(JA/NN-152) peak = 1316.900024 pos = 35.9417,137.7712 diff = 257.599976'
});
data_saddle.push({
lat: 3.5963333333e+01,
lng: 1.3775100000e+02,
content:'Saddle = 1059.300049 pos = 35.9633,137.7510 diff = 257.599976'
});
data_peak.push({
lat: 3.6463666667e+01,
lng: 1.3730855556e+02,
cert : true,
content:'Name = JA/GF-053(JA/GF-053) peak = 1391.199951 pos = 36.4637,137.3086 diff = 322.699951'
});
data_saddle.push({
lat: 3.6452777778e+01,
lng: 1.3731722222e+02,
content:'Saddle = 1068.500000 pos = 36.4528,137.3172 diff = 322.699951'
});
data_peak.push({
lat: 3.6034555555e+01,
lng: 1.3790444444e+02,
cert : true,
content:'Name = JA/NN-139(JA/NN-139) peak = 1392.199951 pos = 36.0346,137.9044 diff = 323.699951'
});
data_saddle.push({
lat: 3.6026222222e+01,
lng: 1.3791011111e+02,
content:'Saddle = 1068.500000 pos = 36.0262,137.9101 diff = 323.699951'
});
data_peak.push({
lat: 3.6253444444e+01,
lng: 1.3729844444e+02,
cert : true,
content:'Name = Ooamamiyama(JA/GF-068) peak = 1335.800049 pos = 36.2534,137.2984 diff = 263.300049'
});
data_saddle.push({
lat: 3.6226333333e+01,
lng: 1.3737744444e+02,
content:'Saddle = 1072.500000 pos = 36.2263,137.3774 diff = 263.300049'
});
data_peak.push({
lat: 3.6251444444e+01,
lng: 1.3736266667e+02,
cert : true,
content:'Name = JA/GF-071(JA/GF-071) peak = 1316.699951 pos = 36.2514,137.3627 diff = 185.699951'
});
data_saddle.push({
lat: 3.6251222222e+01,
lng: 1.3733533333e+02,
content:'Saddle = 1131.000000 pos = 36.2512,137.3353 diff = 185.699951'
});
data_peak.push({
lat: 3.5470777777e+01,
lng: 1.3768033333e+02,
cert : true,
content:'Name = JA/NN-151(JA/NN-151) peak = 1314.199951 pos = 35.4708,137.6803 diff = 235.899902'
});
data_saddle.push({
lat: 3.5492666666e+01,
lng: 1.3767533333e+02,
content:'Saddle = 1078.300049 pos = 35.4927,137.6753 diff = 235.899902'
});
data_peak.push({
lat: 3.5392999999e+01,
lng: 1.3770522222e+02,
cert : false,
content:' Peak = 1450.599976 pos = 35.3930,137.7052 diff = 363.400024'
});
data_saddle.push({
lat: 3.5399222221e+01,
lng: 1.3768877778e+02,
content:'Saddle = 1087.199951 pos = 35.3992,137.6888 diff = 363.400024'
});
data_peak.push({
lat: 3.5613444444e+01,
lng: 1.3758344444e+02,
cert : false,
content:' Peak = 1372.699951 pos = 35.6134,137.5834 diff = 261.000000'
});
data_saddle.push({
lat: 3.5622555555e+01,
lng: 1.3757666667e+02,
content:'Saddle = 1111.699951 pos = 35.6226,137.5767 diff = 261.000000'
});
data_peak.push({
lat: 3.5791888888e+01,
lng: 1.3766266667e+02,
cert : true,
content:'Name = JA/NN-121(JA/NN-121) peak = 1501.500000 pos = 35.7919,137.6627 diff = 388.599976'
});
data_saddle.push({
lat: 3.5796888888e+01,
lng: 1.3762955556e+02,
content:'Saddle = 1112.900024 pos = 35.7969,137.6296 diff = 388.599976'
});
data_peak.push({
lat: 3.6602444444e+01,
lng: 1.3745200000e+02,
cert : false,
content:' Peak = 1360.599976 pos = 36.6024,137.4520 diff = 232.599976'
});
data_saddle.push({
lat: 3.6608000000e+01,
lng: 1.3747888889e+02,
content:'Saddle = 1128.000000 pos = 36.6080,137.4789 diff = 232.599976'
});
data_peak.push({
lat: 3.6592888889e+01,
lng: 1.3781955556e+02,
cert : true,
content:'Name = JA/NN-146(JA/NN-146) peak = 1336.400024 pos = 36.5929,137.8196 diff = 207.500000'
});
data_saddle.push({
lat: 3.6597111111e+01,
lng: 1.3782566667e+02,
content:'Saddle = 1128.900024 pos = 36.5971,137.8257 diff = 207.500000'
});
data_peak.push({
lat: 3.6063666666e+01,
lng: 1.3741611111e+02,
cert : false,
content:' Peak = 1414.099976 pos = 36.0637,137.4161 diff = 282.299927'
});
data_saddle.push({
lat: 3.6052888888e+01,
lng: 1.3742155556e+02,
content:'Saddle = 1131.800049 pos = 36.0529,137.4216 diff = 282.299927'
});
data_peak.push({
lat: 3.5883333333e+01,
lng: 1.3726844444e+02,
cert : true,
content:'Name = JA/GF-027(JA/GF-027) peak = 1652.500000 pos = 35.8833,137.2684 diff = 519.500000'
});
data_saddle.push({
lat: 3.5849777777e+01,
lng: 1.3726177778e+02,
content:'Saddle = 1133.000000 pos = 35.8498,137.2618 diff = 519.500000'
});
data_peak.push({
lat: 3.6427000000e+01,
lng: 1.3731100000e+02,
cert : true,
content:'Name = Ikenoyama(JA/GF-059) peak = 1366.300049 pos = 36.4270,137.3110 diff = 229.700073'
});
data_saddle.push({
lat: 3.6430444444e+01,
lng: 1.3732877778e+02,
content:'Saddle = 1136.599976 pos = 36.4304,137.3288 diff = 229.700073'
});
data_peak.push({
lat: 3.6049444444e+01,
lng: 1.3740855556e+02,
cert : false,
content:' Peak = 1322.699951 pos = 36.0494,137.4086 diff = 180.299927'
});
data_saddle.push({
lat: 3.6041111111e+01,
lng: 1.3740900000e+02,
content:'Saddle = 1142.400024 pos = 36.0411,137.4090 diff = 180.299927'
});
data_peak.push({
lat: 3.5275888888e+01,
lng: 1.3762555556e+02,
cert : false,
content:' Peak = 1321.300049 pos = 35.2759,137.6256 diff = 174.600098'
});
data_saddle.push({
lat: 3.5271777777e+01,
lng: 1.3764644444e+02,
content:'Saddle = 1146.699951 pos = 35.2718,137.6464 diff = 174.600098'
});
data_peak.push({
lat: 3.6433333333e+01,
lng: 1.3734022222e+02,
cert : true,
content:'Name = JA/GF-070(JA/GF-070) peak = 1332.000000 pos = 36.4333,137.3402 diff = 178.599976'
});
data_saddle.push({
lat: 3.6433111111e+01,
lng: 1.3734977778e+02,
content:'Saddle = 1153.400024 pos = 36.4331,137.3498 diff = 178.599976'
});
data_peak.push({
lat: 3.5501666666e+01,
lng: 1.3773922222e+02,
cert : true,
content:'Name = JA/NN-138(JA/NN-138) peak = 1391.400024 pos = 35.5017,137.7392 diff = 235.099976'
});
data_saddle.push({
lat: 3.5510888888e+01,
lng: 1.3774566667e+02,
content:'Saddle = 1156.300049 pos = 35.5109,137.7457 diff = 235.099976'
});
data_peak.push({
lat: 3.6113000000e+01,
lng: 1.3737633333e+02,
cert : false,
content:' Peak = 1315.199951 pos = 36.1130,137.3763 diff = 158.500000'
});
data_saddle.push({
lat: 3.6115888888e+01,
lng: 1.3738422222e+02,
content:'Saddle = 1156.699951 pos = 36.1159,137.3842 diff = 158.500000'
});
data_peak.push({
lat: 3.6064444444e+01,
lng: 1.3733655556e+02,
cert : false,
content:' Peak = 1314.699951 pos = 36.0644,137.3366 diff = 157.799927'
});
data_saddle.push({
lat: 3.6061555555e+01,
lng: 1.3734677778e+02,
content:'Saddle = 1156.900024 pos = 36.0616,137.3468 diff = 157.799927'
});
data_peak.push({
lat: 3.6491777778e+01,
lng: 1.3776122222e+02,
cert : false,
content:' Peak = 1353.900024 pos = 36.4918,137.7612 diff = 196.000000'
});
data_saddle.push({
lat: 3.6487777778e+01,
lng: 1.3776077778e+02,
content:'Saddle = 1157.900024 pos = 36.4878,137.7608 diff = 196.000000'
});
data_peak.push({
lat: 3.5227666666e+01,
lng: 1.3765544444e+02,
cert : true,
content:'Name = Chausuyama(JA/AC-001) peak = 1414.400024 pos = 35.2277,137.6554 diff = 249.099976'
});
data_saddle.push({
lat: 3.5234111110e+01,
lng: 1.3766811111e+02,
content:'Saddle = 1165.300049 pos = 35.2341,137.6681 diff = 249.099976'
});
data_peak.push({
lat: 3.6665444444e+01,
lng: 1.3754900000e+02,
cert : false,
content:' Peak = 1550.300049 pos = 36.6654,137.5490 diff = 382.000000'
});
data_saddle.push({
lat: 3.6666555556e+01,
lng: 1.3755844444e+02,
content:'Saddle = 1168.300049 pos = 36.6666,137.5584 diff = 382.000000'
});
data_peak.push({
lat: 3.5533555555e+01,
lng: 1.3760700000e+02,
cert : false,
content:' Peak = 1341.900024 pos = 35.5336,137.6070 diff = 170.400024'
});
data_saddle.push({
lat: 3.5531444444e+01,
lng: 1.3760944444e+02,
content:'Saddle = 1171.500000 pos = 35.5314,137.6094 diff = 170.400024'
});
data_peak.push({
lat: 3.5592555555e+01,
lng: 1.3764422222e+02,
cert : true,
content:'Name = Nagisodake(JA/NN-099) peak = 1677.900024 pos = 35.5926,137.6442 diff = 505.400024'
});
data_saddle.push({
lat: 3.5594999999e+01,
lng: 1.3767622222e+02,
content:'Saddle = 1172.500000 pos = 35.5950,137.6762 diff = 505.400024'
});
data_peak.push({
lat: 3.6037888888e+01,
lng: 1.3746566667e+02,
cert : false,
content:' Peak = 1343.400024 pos = 36.0379,137.4657 diff = 165.599976'
});
data_saddle.push({
lat: 3.6043111111e+01,
lng: 1.3747433333e+02,
content:'Saddle = 1177.800049 pos = 36.0431,137.4743 diff = 165.599976'
});
data_peak.push({
lat: 3.5941444444e+01,
lng: 1.3731222222e+02,
cert : false,
content:' Peak = 1364.500000 pos = 35.9414,137.3122 diff = 184.500000'
});
data_saddle.push({
lat: 3.5946222222e+01,
lng: 1.3730644444e+02,
content:'Saddle = 1180.000000 pos = 35.9462,137.3064 diff = 184.500000'
});
data_peak.push({
lat: 3.5443222221e+01,
lng: 1.3759766667e+02,
cert : true,
content:'Name = Enasan(JA/NN-053) peak = 2190.600098 pos = 35.4432,137.5977 diff = 1003.000122'
});
data_saddle.push({
lat: 3.5532666666e+01,
lng: 1.3766433333e+02,
content:'Saddle = 1187.599976 pos = 35.5327,137.6643 diff = 1003.000122'
});
data_peak.push({
lat: 3.5341444443e+01,
lng: 1.3768811111e+02,
cert : false,
content:' Peak = 1663.099976 pos = 35.3414,137.6881 diff = 466.699951'
});
data_saddle.push({
lat: 3.5349666666e+01,
lng: 1.3766533333e+02,
content:'Saddle = 1196.400024 pos = 35.3497,137.6653 diff = 466.699951'
});
data_peak.push({
lat: 3.5317444443e+01,
lng: 1.3767422222e+02,
cert : false,
content:' Peak = 1463.800049 pos = 35.3174,137.6742 diff = 216.200073'
});
data_saddle.push({
lat: 3.5326555555e+01,
lng: 1.3767666667e+02,
content:'Saddle = 1247.599976 pos = 35.3266,137.6767 diff = 216.200073'
});
data_peak.push({
lat: 3.5415888888e+01,
lng: 1.3767877778e+02,
cert : false,
content:' Peak = 1460.900024 pos = 35.4159,137.6788 diff = 226.300049'
});
data_saddle.push({
lat: 3.5419333332e+01,
lng: 1.3766900000e+02,
content:'Saddle = 1234.599976 pos = 35.4193,137.6690 diff = 226.300049'
});
data_peak.push({
lat: 3.5403888888e+01,
lng: 1.3756411111e+02,
cert : true,
content:'Name = JA/GF-022(JA/GF-022) peak = 1708.099976 pos = 35.4039,137.5641 diff = 298.900024'
});
data_saddle.push({
lat: 3.5394999999e+01,
lng: 1.3758822222e+02,
content:'Saddle = 1409.199951 pos = 35.3950,137.5882 diff = 298.900024'
});
data_peak.push({
lat: 3.5483111110e+01,
lng: 1.3762955556e+02,
cert : true,
content:'Name = JA/NN-092(JA/NN-092) peak = 1738.000000 pos = 35.4831,137.6296 diff = 190.199951'
});
data_saddle.push({
lat: 3.5468222221e+01,
lng: 1.3762055556e+02,
content:'Saddle = 1547.800049 pos = 35.4682,137.6206 diff = 190.199951'
});
data_peak.push({
lat: 3.5398333332e+01,
lng: 1.3763388889e+02,
cert : true,
content:'Name = JA/NN-074(JA/NN-074) peak = 1940.699951 pos = 35.3983,137.6339 diff = 273.799927'
});
data_saddle.push({
lat: 3.5420111110e+01,
lng: 1.3761811111e+02,
content:'Saddle = 1666.900024 pos = 35.4201,137.6181 diff = 273.799927'
});
data_peak.push({
lat: 3.6350333333e+01,
lng: 1.3736244444e+02,
cert : true,
content:'Name = JA/GF-037(JA/GF-037) peak = 1522.000000 pos = 36.3503,137.3624 diff = 333.699951'
});
data_saddle.push({
lat: 3.6343000000e+01,
lng: 1.3739588889e+02,
content:'Saddle = 1188.300049 pos = 36.3430,137.3959 diff = 333.699951'
});
data_peak.push({
lat: 3.5837555555e+01,
lng: 1.3727755556e+02,
cert : true,
content:'Name = JA/GF-051(JA/GF-051) peak = 1410.199951 pos = 35.8376,137.2776 diff = 215.000000'
});
data_saddle.push({
lat: 3.5824444444e+01,
lng: 1.3728333333e+02,
content:'Saddle = 1195.199951 pos = 35.8244,137.2833 diff = 215.000000'
});
data_peak.push({
lat: 3.5789666666e+01,
lng: 1.3780466667e+02,
cert : true,
content:'Name = Komagatake(JA/NN-006) peak = 2954.199951 pos = 35.7897,137.8047 diff = 1746.599976'
});
data_saddle.push({
lat: 3.5951888888e+01,
lng: 1.3779677778e+02,
content:'Saddle = 1207.599976 pos = 35.9519,137.7968 diff = 1746.599976'
});
data_peak.push({
lat: 3.5542333332e+01,
lng: 1.3774033333e+02,
cert : true,
content:'Name = JA/NN-122(JA/NN-122) peak = 1491.900024 pos = 35.5423,137.7403 diff = 253.599976'
});
data_saddle.push({
lat: 3.5552999999e+01,
lng: 1.3773533333e+02,
content:'Saddle = 1238.300049 pos = 35.5530,137.7353 diff = 253.599976'
});
data_peak.push({
lat: 3.5549555555e+01,
lng: 1.3778377778e+02,
cert : true,
content:'Name = Kazakoshiyama (Gongenyama)(JA/NN-119) peak = 1534.699951 pos = 35.5496,137.7838 diff = 293.500000'
});
data_saddle.push({
lat: 3.5586333333e+01,
lng: 1.3779844444e+02,
content:'Saddle = 1241.199951 pos = 35.5863,137.7984 diff = 293.500000'
});
data_peak.push({
lat: 3.5820888888e+01,
lng: 1.3772044444e+02,
cert : true,
content:'Name = JA/NN-132(JA/NN-132) peak = 1451.900024 pos = 35.8209,137.7204 diff = 209.200073'
});
data_saddle.push({
lat: 3.5819333333e+01,
lng: 1.3773633333e+02,
content:'Saddle = 1242.699951 pos = 35.8193,137.7363 diff = 209.200073'
});
data_peak.push({
lat: 3.5915999999e+01,
lng: 1.3780566667e+02,
cert : true,
content:'Name = JA/NN-123(JA/NN-123) peak = 1491.500000 pos = 35.9160,137.8057 diff = 204.599976'
});
data_saddle.push({
lat: 3.5905888888e+01,
lng: 1.3780444444e+02,
content:'Saddle = 1286.900024 pos = 35.9059,137.8044 diff = 204.599976'
});
data_peak.push({
lat: 3.5533222221e+01,
lng: 1.3767744444e+02,
cert : false,
content:' Peak = 1473.000000 pos = 35.5332,137.6774 diff = 175.099976'
});
data_saddle.push({
lat: 3.5544888888e+01,
lng: 1.3768655556e+02,
content:'Saddle = 1297.900024 pos = 35.5449,137.6866 diff = 175.099976'
});
data_peak.push({
lat: 3.5552777777e+01,
lng: 1.3770411111e+02,
cert : true,
content:'Name = JA/NN-111(JA/NN-111) peak = 1635.099976 pos = 35.5528,137.7041 diff = 283.000000'
});
data_saddle.push({
lat: 3.5559111110e+01,
lng: 1.3769500000e+02,
content:'Saddle = 1352.099976 pos = 35.5591,137.6950 diff = 283.000000'
});
data_peak.push({
lat: 3.5912888888e+01,
lng: 1.3786255556e+02,
cert : true,
content:'Name = Kyougatake(JA/NN-046) peak = 2292.500000 pos = 35.9129,137.8626 diff = 769.800049'
});
data_saddle.push({
lat: 3.5872444444e+01,
lng: 1.3785688889e+02,
content:'Saddle = 1522.699951 pos = 35.8724,137.8569 diff = 769.800049'
});
data_peak.push({
lat: 3.5938222222e+01,
lng: 1.3782877778e+02,
cert : false,
content:' Peak = 1960.500000 pos = 35.9382,137.8288 diff = 198.400024'
});
data_saddle.push({
lat: 3.5929666666e+01,
lng: 1.3783422222e+02,
content:'Saddle = 1762.099976 pos = 35.9297,137.8342 diff = 198.400024'
});
data_peak.push({
lat: 3.5708333333e+01,
lng: 1.3773377778e+02,
cert : true,
content:'Name = Itoseyama(JA/NN-082) peak = 1866.000000 pos = 35.7083,137.7338 diff = 329.699951'
});
data_saddle.push({
lat: 3.5722777777e+01,
lng: 1.3775077778e+02,
content:'Saddle = 1536.300049 pos = 35.7228,137.7508 diff = 329.699951'
});
data_peak.push({
lat: 3.5812222222e+01,
lng: 1.3777033333e+02,
cert : false,
content:' Peak = 2176.100098 pos = 35.8122,137.7703 diff = 152.200073'
});
data_saddle.push({
lat: 3.5809777777e+01,
lng: 1.3777344444e+02,
content:'Saddle = 2023.900024 pos = 35.8098,137.7734 diff = 152.200073'
});
data_peak.push({
lat: 3.5630444444e+01,
lng: 1.3777433333e+02,
cert : true,
content:'Name = Anpeijiyama(JA/NN-041) peak = 2362.600098 pos = 35.6304,137.7743 diff = 280.700195'
});
data_saddle.push({
lat: 3.5642444444e+01,
lng: 1.3778900000e+02,
content:'Saddle = 2081.899902 pos = 35.6424,137.7890 diff = 280.700195'
});
data_peak.push({
lat: 3.5847999999e+01,
lng: 1.3781000000e+02,
cert : true,
content:'Name = Oodanairiyama(JA/NN-039) peak = 2373.399902 pos = 35.8480,137.8100 diff = 260.199951'
});
data_saddle.push({
lat: 3.5838333333e+01,
lng: 1.3780766667e+02,
content:'Saddle = 2113.199951 pos = 35.8383,137.8077 diff = 260.199951'
});
data_peak.push({
lat: 3.5655333333e+01,
lng: 1.3782700000e+02,
cert : true,
content:'Name = JA/NN-044(JA/NN-044) peak = 2326.899902 pos = 35.6553,137.8270 diff = 204.099854'
});
data_saddle.push({
lat: 3.5651111110e+01,
lng: 1.3780733333e+02,
content:'Saddle = 2122.800049 pos = 35.6511,137.8073 diff = 204.099854'
});
data_peak.push({
lat: 3.5718999999e+01,
lng: 1.3781700000e+02,
cert : true,
content:'Name = Utsugidake(JA/NN-013) peak = 2862.000000 pos = 35.7190,137.8170 diff = 368.300049'
});
data_saddle.push({
lat: 3.5723333333e+01,
lng: 1.3780788889e+02,
content:'Saddle = 2493.699951 pos = 35.7233,137.8079 diff = 368.300049'
});
data_peak.push({
lat: 3.5739333333e+01,
lng: 1.3780322222e+02,
cert : true,
content:'Name = Kumazawadake(JA/NN-017) peak = 2775.500000 pos = 35.7393,137.8032 diff = 238.699951'
});
data_saddle.push({
lat: 3.5757222222e+01,
lng: 1.3781266667e+02,
content:'Saddle = 2536.800049 pos = 35.7572,137.8127 diff = 238.699951'
});
data_peak.push({
lat: 3.5766777777e+01,
lng: 1.3779400000e+02,
cert : false,
content:' Peak = 2845.600098 pos = 35.7668,137.7940 diff = 189.300049'
});
data_saddle.push({
lat: 3.5772111110e+01,
lng: 1.3779911111e+02,
content:'Saddle = 2656.300049 pos = 35.7721,137.7991 diff = 189.300049'
});
data_peak.push({
lat: 3.6044222222e+01,
lng: 1.3735255556e+02,
cert : true,
content:'Name = JA/GF-048(JA/GF-048) peak = 1432.199951 pos = 36.0442,137.3526 diff = 224.099976'
});
data_saddle.push({
lat: 3.6037888888e+01,
lng: 1.3736577778e+02,
content:'Saddle = 1208.099976 pos = 36.0379,137.3658 diff = 224.099976'
});
data_peak.push({
lat: 3.6019555555e+01,
lng: 1.3735022222e+02,
cert : true,
content:'Name = JA/GF-040(JA/GF-040) peak = 1484.099976 pos = 36.0196,137.3502 diff = 273.099976'
});
data_saddle.push({
lat: 3.5975111111e+01,
lng: 1.3735800000e+02,
content:'Saddle = 1211.000000 pos = 35.9751,137.3580 diff = 273.099976'
});
data_peak.push({
lat: 3.6111777777e+01,
lng: 1.3739955556e+02,
cert : false,
content:' Peak = 1402.099976 pos = 36.1118,137.3996 diff = 160.599976'
});
data_saddle.push({
lat: 3.6125111111e+01,
lng: 1.3740833333e+02,
content:'Saddle = 1241.500000 pos = 36.1251,137.4083 diff = 160.599976'
});
data_peak.push({
lat: 3.5778888888e+01,
lng: 1.3758044444e+02,
cert : false,
content:' Peak = 1463.000000 pos = 35.7789,137.5804 diff = 211.099976'
});
data_saddle.push({
lat: 3.5777111110e+01,
lng: 1.3758822222e+02,
content:'Saddle = 1251.900024 pos = 35.7771,137.5882 diff = 211.099976'
});
data_peak.push({
lat: 3.5732888888e+01,
lng: 1.3740700000e+02,
cert : true,
content:'Name = JA/GF-034(JA/GF-034) peak = 1562.099976 pos = 35.7329,137.4070 diff = 300.599976'
});
data_saddle.push({
lat: 3.5733333333e+01,
lng: 1.3739477778e+02,
content:'Saddle = 1261.500000 pos = 35.7333,137.3948 diff = 300.599976'
});
data_peak.push({
lat: 3.6304000000e+01,
lng: 1.3742344444e+02,
cert : true,
content:'Name = JA/GF-046(JA/GF-046) peak = 1442.400024 pos = 36.3040,137.4234 diff = 180.800049'
});
data_saddle.push({
lat: 3.6303111111e+01,
lng: 1.3743822222e+02,
content:'Saddle = 1261.599976 pos = 36.3031,137.4382 diff = 180.800049'
});
data_peak.push({
lat: 3.6514666667e+01,
lng: 1.3742677778e+02,
cert : true,
content:'Name = Hachibuseyama(JA/TY-023) peak = 1782.099976 pos = 36.5147,137.4268 diff = 483.699951'
});
data_saddle.push({
lat: 3.6448000000e+01,
lng: 1.3739488889e+02,
content:'Saddle = 1298.400024 pos = 36.4480,137.3949 diff = 483.699951'
});
data_peak.push({
lat: 3.6470444444e+01,
lng: 1.3740622222e+02,
cert : true,
content:'Name = JA/TY-024(JA/TY-024) peak = 1698.000000 pos = 36.4704,137.4062 diff = 220.400024'
});
data_saddle.push({
lat: 3.6490000000e+01,
lng: 1.3741177778e+02,
content:'Saddle = 1477.599976 pos = 36.4900,137.4118 diff = 220.400024'
});
data_peak.push({
lat: 3.6486111111e+01,
lng: 1.3737788889e+02,
cert : true,
content:'Name = Nishikasayama(JA/TY-025) peak = 1697.400024 pos = 36.4861,137.3779 diff = 199.599976'
});
data_saddle.push({
lat: 3.6475000000e+01,
lng: 1.3738088889e+02,
content:'Saddle = 1497.800049 pos = 36.4750,137.3809 diff = 199.599976'
});
data_peak.push({
lat: 3.6497555555e+01,
lng: 1.3741166667e+02,
cert : false,
content:' Peak = 1687.099976 pos = 36.4976,137.4117 diff = 208.799927'
});
data_saddle.push({
lat: 3.6497555555e+01,
lng: 1.3742288889e+02,
content:'Saddle = 1478.300049 pos = 36.4976,137.4229 diff = 208.799927'
});
data_peak.push({
lat: 3.5751444444e+01,
lng: 1.3765411111e+02,
cert : true,
content:'Name = JA/NN-126(JA/NN-126) peak = 1473.800049 pos = 35.7514,137.6541 diff = 172.200073'
});
data_saddle.push({
lat: 3.5721444444e+01,
lng: 1.3764866667e+02,
content:'Saddle = 1301.599976 pos = 35.7214,137.6487 diff = 172.200073'
});
data_peak.push({
lat: 3.6130222222e+01,
lng: 1.3768800000e+02,
cert : false,
content:' Peak = 1572.900024 pos = 36.1302,137.6880 diff = 239.599976'
});
data_saddle.push({
lat: 3.6124111111e+01,
lng: 1.3768244444e+02,
content:'Saddle = 1333.300049 pos = 36.1241,137.6824 diff = 239.599976'
});
data_peak.push({
lat: 3.6484888889e+01,
lng: 1.3779488889e+02,
cert : true,
content:'Name = JA/NN-114(JA/NN-114) peak = 1622.699951 pos = 36.4849,137.7949 diff = 286.899902'
});
data_saddle.push({
lat: 3.6482777778e+01,
lng: 1.3778166667e+02,
content:'Saddle = 1335.800049 pos = 36.4828,137.7817 diff = 286.899902'
});
data_peak.push({
lat: 3.6036555555e+01,
lng: 1.3751000000e+02,
cert : true,
content:'Name = JA/GF-033(JA/GF-033) peak = 1591.800049 pos = 36.0366,137.5100 diff = 239.800049'
});
data_saddle.push({
lat: 3.6044666666e+01,
lng: 1.3751888889e+02,
content:'Saddle = 1352.000000 pos = 36.0447,137.5189 diff = 239.800049'
});
data_peak.push({
lat: 3.5893111111e+01,
lng: 1.3748044444e+02,
cert : true,
content:'Name = Ontakesan (Kengamine)(JA/NN-005) peak = 3064.300049 pos = 35.8931,137.4804 diff = 1707.400024'
});
data_saddle.push({
lat: 3.5971777777e+01,
lng: 1.3754355556e+02,
content:'Saddle = 1356.900024 pos = 35.9718,137.5436 diff = 1707.400024'
});
data_peak.push({
lat: 3.5716333333e+01,
lng: 1.3759300000e+02,
cert : true,
content:'Name = JA/NN-118(JA/NN-118) peak = 1556.800049 pos = 35.7163,137.5930 diff = 190.800049'
});
data_saddle.push({
lat: 3.5736999999e+01,
lng: 1.3758077778e+02,
content:'Saddle = 1366.000000 pos = 35.7370,137.5808 diff = 190.800049'
});
data_peak.push({
lat: 3.5852888888e+01,
lng: 1.3757277778e+02,
cert : true,
content:'Name = JA/NN-117(JA/NN-117) peak = 1554.400024 pos = 35.8529,137.5728 diff = 186.400024'
});
data_saddle.push({
lat: 3.5860333333e+01,
lng: 1.3755333333e+02,
content:'Saddle = 1368.000000 pos = 35.8603,137.5533 diff = 186.400024'
});
data_peak.push({
lat: 3.5785444444e+01,
lng: 1.3739688889e+02,
cert : true,
content:'Name = Kohideyama(JA/NN-070) peak = 1981.000000 pos = 35.7854,137.3969 diff = 609.900024'
});
data_saddle.push({
lat: 3.5842555555e+01,
lng: 1.3734866667e+02,
content:'Saddle = 1371.099976 pos = 35.8426,137.3487 diff = 609.900024'
});
data_peak.push({
lat: 3.5713444444e+01,
lng: 1.3748711111e+02,
cert : true,
content:'Name = JA/NN-085(JA/NN-085) peak = 1842.199951 pos = 35.7134,137.4871 diff = 459.199951'
});
data_saddle.push({
lat: 3.5774777777e+01,
lng: 1.3741722222e+02,
content:'Saddle = 1383.000000 pos = 35.7748,137.4172 diff = 459.199951'
});
data_peak.push({
lat: 3.5794222222e+01,
lng: 1.3746244444e+02,
cert : true,
content:'Name = JA/NN-105(JA/NN-105) peak = 1654.900024 pos = 35.7942,137.4624 diff = 230.000000'
});
data_saddle.push({
lat: 3.5784333333e+01,
lng: 1.3744966667e+02,
content:'Saddle = 1424.900024 pos = 35.7843,137.4497 diff = 230.000000'
});
data_peak.push({
lat: 3.5771777777e+01,
lng: 1.3747855556e+02,
cert : false,
content:' Peak = 1700.599976 pos = 35.7718,137.4786 diff = 218.699951'
});
data_saddle.push({
lat: 3.5752333333e+01,
lng: 1.3746500000e+02,
content:'Saddle = 1481.900024 pos = 35.7523,137.4650 diff = 218.699951'
});
data_peak.push({
lat: 3.5765777777e+01,
lng: 1.3743477778e+02,
cert : true,
content:'Name = JA/NN-097(JA/NN-097) peak = 1691.000000 pos = 35.7658,137.4348 diff = 152.500000'
});
data_saddle.push({
lat: 3.5758333333e+01,
lng: 1.3744288889e+02,
content:'Saddle = 1538.500000 pos = 35.7583,137.4429 diff = 152.500000'
});
data_peak.push({
lat: 3.5754333333e+01,
lng: 1.3753355556e+02,
cert : true,
content:'Name = JA/NN-095(JA/NN-095) peak = 1714.800049 pos = 35.7543,137.5336 diff = 226.800049'
});
data_saddle.push({
lat: 3.5730333333e+01,
lng: 1.3754400000e+02,
content:'Saddle = 1488.000000 pos = 35.7303,137.5440 diff = 226.800049'
});
data_peak.push({
lat: 3.5681666666e+01,
lng: 1.3750711111e+02,
cert : true,
content:'Name = Okusangaidake(JA/GF-016) peak = 1811.300049 pos = 35.6817,137.5071 diff = 209.000000'
});
data_saddle.push({
lat: 3.5698555555e+01,
lng: 1.3749600000e+02,
content:'Saddle = 1602.300049 pos = 35.6986,137.4960 diff = 209.000000'
});
data_peak.push({
lat: 3.5726666666e+01,
lng: 1.3747888889e+02,
cert : true,
content:'Name = JA/GF-015(JA/GF-015) peak = 1822.099976 pos = 35.7267,137.4789 diff = 153.799927'
});
data_saddle.push({
lat: 3.5722333333e+01,
lng: 1.3748611111e+02,
content:'Saddle = 1668.300049 pos = 35.7223,137.4861 diff = 153.799927'
});
data_peak.push({
lat: 3.5808444444e+01,
lng: 1.3733244444e+02,
cert : false,
content:' Peak = 1662.500000 pos = 35.8084,137.3324 diff = 231.199951'
});
data_saddle.push({
lat: 3.5801222222e+01,
lng: 1.3735388889e+02,
content:'Saddle = 1431.300049 pos = 35.8012,137.3539 diff = 231.199951'
});
data_peak.push({
lat: 3.5956222222e+01,
lng: 1.3736711111e+02,
cert : false,
content:' Peak = 1590.400024 pos = 35.9562,137.3671 diff = 162.800049'
});
data_saddle.push({
lat: 3.5948111111e+01,
lng: 1.3737800000e+02,
content:'Saddle = 1427.599976 pos = 35.9481,137.3780 diff = 162.800049'
});
data_peak.push({
lat: 3.5961222222e+01,
lng: 1.3739911111e+02,
cert : true,
content:'Name = JA/GF-028(JA/GF-028) peak = 1633.500000 pos = 35.9612,137.3991 diff = 198.500000'
});
data_saddle.push({
lat: 3.5968777777e+01,
lng: 1.3741488889e+02,
content:'Saddle = 1435.000000 pos = 35.9688,137.4149 diff = 198.500000'
});
data_peak.push({
lat: 3.5936777777e+01,
lng: 1.3742144444e+02,
cert : false,
content:' Peak = 1798.400024 pos = 35.9368,137.4214 diff = 164.500000'
});
data_saddle.push({
lat: 3.5928999999e+01,
lng: 1.3743355556e+02,
content:'Saddle = 1633.900024 pos = 35.9290,137.4336 diff = 164.500000'
});
data_peak.push({
lat: 3.6540222222e+01,
lng: 1.3747800000e+02,
cert : true,
content:'Name = Kuwasakiyama(JA/TY-018) peak = 2084.399902 pos = 36.5402,137.4780 diff = 692.299927'
});
data_saddle.push({
lat: 3.6488888889e+01,
lng: 1.3747466667e+02,
content:'Saddle = 1392.099976 pos = 36.4889,137.4747 diff = 692.299927'
});
data_peak.push({
lat: 3.6666666667e+01,
lng: 1.3757022222e+02,
cert : false,
content:' Peak = 1854.500000 pos = 36.6667,137.5702 diff = 388.199951'
});
data_saddle.push({
lat: 3.6666555556e+01,
lng: 1.3759411111e+02,
content:'Saddle = 1466.300049 pos = 36.6666,137.5941 diff = 388.199951'
});
data_peak.push({
lat: 3.6666666667e+01,
lng: 1.3758266667e+02,
cert : false,
content:' Peak = 1789.199951 pos = 36.6667,137.5827 diff = 226.699951'
});
data_saddle.push({
lat: 3.6666666667e+01,
lng: 1.3757788889e+02,
content:'Saddle = 1562.500000 pos = 36.6667,137.5779 diff = 226.699951'
});
data_peak.push({
lat: 3.6351111111e+01,
lng: 1.3741833333e+02,
cert : true,
content:'Name = JA/GF-021(JA/GF-021) peak = 1726.900024 pos = 36.3511,137.4183 diff = 255.400024'
});
data_saddle.push({
lat: 3.6371666666e+01,
lng: 1.3742900000e+02,
content:'Saddle = 1471.500000 pos = 36.3717,137.4290 diff = 255.400024'
});
data_peak.push({
lat: 3.6086666666e+01,
lng: 1.3775477778e+02,
cert : false,
content:' Peak = 2445.600098 pos = 36.0867,137.7548 diff = 959.100098'
});
data_saddle.push({
lat: 3.6025444444e+01,
lng: 1.3771966667e+02,
content:'Saddle = 1486.500000 pos = 36.0254,137.7197 diff = 959.100098'
});
data_peak.push({
lat: 3.6016444444e+01,
lng: 1.3779044444e+02,
cert : true,
content:'Name = JA/NN-090(JA/NN-090) peak = 1783.000000 pos = 36.0164,137.7904 diff = 209.800049'
});
data_saddle.push({
lat: 3.6033000000e+01,
lng: 1.3781111111e+02,
content:'Saddle = 1573.199951 pos = 36.0330,137.8111 diff = 209.800049'
});
data_peak.push({
lat: 3.6073222222e+01,
lng: 1.3778200000e+02,
cert : false,
content:' Peak = 2021.199951 pos = 36.0732,137.7820 diff = 159.299927'
});
data_saddle.push({
lat: 3.6077888888e+01,
lng: 1.3777322222e+02,
content:'Saddle = 1861.900024 pos = 36.0779,137.7732 diff = 159.299927'
});
data_peak.push({
lat: 3.6071000000e+01,
lng: 1.3773733333e+02,
cert : false,
content:' Peak = 2371.000000 pos = 36.0710,137.7373 diff = 173.600098'
});
data_saddle.push({
lat: 3.6076555555e+01,
lng: 1.3774433333e+02,
content:'Saddle = 2197.399902 pos = 36.0766,137.7443 diff = 173.600098'
});
data_peak.push({
lat: 3.6420000000e+01,
lng: 1.3742700000e+02,
cert : true,
content:'Name = JA/GF-020(JA/GF-020) peak = 1730.500000 pos = 36.4200,137.4270 diff = 188.300049'
});
data_saddle.push({
lat: 3.6417666667e+01,
lng: 1.3743822222e+02,
content:'Saddle = 1542.199951 pos = 36.4177,137.4382 diff = 188.300049'
});
data_peak.push({
lat: 3.6398111111e+01,
lng: 1.3745644444e+02,
cert : true,
content:'Name = JA/GF-017(JA/GF-017) peak = 1792.800049 pos = 36.3981,137.4564 diff = 229.600098'
});
data_saddle.push({
lat: 3.6406000000e+01,
lng: 1.3744811111e+02,
content:'Saddle = 1563.199951 pos = 36.4060,137.4481 diff = 229.600098'
});
data_peak.push({
lat: 3.6338777778e+01,
lng: 1.3747744444e+02,
cert : true,
content:'Name = JA/GF-012(JA/GF-012) peak = 2005.699951 pos = 36.3388,137.4774 diff = 364.399902'
});
data_saddle.push({
lat: 3.6332444444e+01,
lng: 1.3749800000e+02,
content:'Saddle = 1641.300049 pos = 36.3324,137.4980 diff = 364.399902'
});
data_peak.push({
lat: 3.6058666666e+01,
lng: 1.3766677778e+02,
cert : true,
content:'Name = JA/NN-088(JA/NN-088) peak = 1811.400024 pos = 36.0587,137.6668 diff = 159.200073'
});
data_saddle.push({
lat: 3.6054888888e+01,
lng: 1.3762177778e+02,
content:'Saddle = 1652.199951 pos = 36.0549,137.6218 diff = 159.200073'
});
data_peak.push({
lat: 3.6026666666e+01,
lng: 1.3759900000e+02,
cert : true,
content:'Name = Kamagamine(JA/NN-057) peak = 2120.699951 pos = 36.0267,137.5990 diff = 449.799927'
});
data_saddle.push({
lat: 3.6052555555e+01,
lng: 1.3760544444e+02,
content:'Saddle = 1670.900024 pos = 36.0526,137.6054 diff = 449.799927'
});
data_peak.push({
lat: 3.5977111111e+01,
lng: 1.3769722222e+02,
cert : false,
content:' Peak = 2043.900024 pos = 35.9771,137.6972 diff = 351.900024'
});
data_saddle.push({
lat: 3.6024444444e+01,
lng: 1.3763833333e+02,
content:'Saddle = 1692.000000 pos = 36.0244,137.6383 diff = 351.900024'
});
data_peak.push({
lat: 3.6020666666e+01,
lng: 1.3765155556e+02,
cert : false,
content:' Peak = 1936.000000 pos = 36.0207,137.6516 diff = 167.000000'
});
data_saddle.push({
lat: 3.6016222222e+01,
lng: 1.3765544444e+02,
content:'Saddle = 1769.000000 pos = 36.0162,137.6554 diff = 167.000000'
});
data_peak.push({
lat: 3.6014888888e+01,
lng: 1.3767800000e+02,
cert : false,
content:' Peak = 2032.199951 pos = 36.0149,137.6780 diff = 263.000000'
});
data_saddle.push({
lat: 3.5990666666e+01,
lng: 1.3769900000e+02,
content:'Saddle = 1769.199951 pos = 35.9907,137.6990 diff = 263.000000'
});
data_peak.push({
lat: 3.5995999999e+01,
lng: 1.3769777778e+02,
cert : false,
content:' Peak = 1983.699951 pos = 35.9960,137.6978 diff = 182.099976'
});
data_saddle.push({
lat: 3.6005333333e+01,
lng: 1.3770233333e+02,
content:'Saddle = 1801.599976 pos = 36.0053,137.7023 diff = 182.099976'
});
data_peak.push({
lat: 3.6194111111e+01,
lng: 1.3752200000e+02,
cert : true,
content:'Name = Terashiyama(JA/GF-011) peak = 2062.300049 pos = 36.1941,137.5220 diff = 381.300049'
});
data_saddle.push({
lat: 3.6180555555e+01,
lng: 1.3753011111e+02,
content:'Saddle = 1681.000000 pos = 36.1806,137.5301 diff = 381.300049'
});
data_peak.push({
lat: 3.6243222222e+01,
lng: 1.3778788889e+02,
cert : true,
content:'Name = JA/NN-063(JA/NN-063) peak = 2052.000000 pos = 36.2432,137.7879 diff = 330.099976'
});
data_saddle.push({
lat: 3.6272111111e+01,
lng: 1.3779522222e+02,
content:'Saddle = 1721.900024 pos = 36.2721,137.7952 diff = 330.099976'
});
data_peak.push({
lat: 3.6106555555e+01,
lng: 1.3755355556e+02,
cert : true,
content:'Name = Norikuradake (Kengamine)(JA/GF-001) peak = 3024.300049 pos = 36.1066,137.5536 diff = 1226.000000'
});
data_saddle.push({
lat: 3.6194222222e+01,
lng: 1.3758377778e+02,
content:'Saddle = 1798.300049 pos = 36.1942,137.5838 diff = 1226.000000'
});
data_peak.push({
lat: 3.6190666666e+01,
lng: 1.3759511111e+02,
cert : false,
content:' Peak = 2221.300049 pos = 36.1907,137.5951 diff = 160.100098'
});
data_saddle.push({
lat: 3.6186333333e+01,
lng: 1.3759133333e+02,
content:'Saddle = 2061.199951 pos = 36.1863,137.5913 diff = 160.100098'
});
data_peak.push({
lat: 3.6160000000e+01,
lng: 1.3758044444e+02,
cert : true,
content:'Name = JA/NN-030(JA/NN-030) peak = 2531.300049 pos = 36.1600,137.5804 diff = 219.400146'
});
data_saddle.push({
lat: 3.6157222222e+01,
lng: 1.3757377778e+02,
content:'Saddle = 2311.899902 pos = 36.1572,137.5738 diff = 219.400146'
});
data_peak.push({
lat: 3.6147111111e+01,
lng: 1.3755288889e+02,
cert : true,
content:'Name = JA/GF-006(JA/GF-006) peak = 2751.000000 pos = 36.1471,137.5529 diff = 173.300049'
});
data_saddle.push({
lat: 3.6142555555e+01,
lng: 1.3755111111e+02,
content:'Saddle = 2577.699951 pos = 36.1426,137.5511 diff = 173.300049'
});
data_peak.push({
lat: 3.6210666666e+01,
lng: 1.3757322222e+02,
cert : true,
content:'Name = JA/NN-054(JA/NN-054) peak = 2185.500000 pos = 36.2107,137.5732 diff = 278.000000'
});
data_saddle.push({
lat: 3.6218444444e+01,
lng: 1.3757344444e+02,
content:'Saddle = 1907.500000 pos = 36.2184,137.5734 diff = 278.000000'
});
data_peak.push({
lat: 3.6272555555e+01,
lng: 1.3754211111e+02,
cert : true,
content:'Name = JA/GF-009(JA/GF-009) peak = 2230.699951 pos = 36.2726,137.5421 diff = 237.099976'
});
data_saddle.push({
lat: 3.6278333333e+01,
lng: 1.3754633333e+02,
content:'Saddle = 1993.599976 pos = 36.2783,137.5463 diff = 237.099976'
});
data_peak.push({
lat: 3.6611888889e+01,
lng: 1.3766100000e+02,
cert : true,
content:'Name = Kurobebetsusan(JA/TY-016) peak = 2352.500000 pos = 36.6119,137.6610 diff = 342.000000'
});
data_saddle.push({
lat: 3.6606777778e+01,
lng: 1.3765244444e+02,
content:'Saddle = 2010.500000 pos = 36.6068,137.6524 diff = 342.000000'
});
data_peak.push({
lat: 3.6640444444e+01,
lng: 1.3764488889e+02,
cert : false,
content:' Peak = 2212.500000 pos = 36.6404,137.6449 diff = 170.500000'
});
data_saddle.push({
lat: 3.6639111111e+01,
lng: 1.3763988889e+02,
content:'Saddle = 2042.000000 pos = 36.6391,137.6399 diff = 170.500000'
});
data_peak.push({
lat: 3.6395666666e+01,
lng: 1.3776222222e+02,
cert : true,
content:'Name = JA/NN-048(JA/NN-048) peak = 2281.899902 pos = 36.3957,137.7622 diff = 198.899902'
});
data_saddle.push({
lat: 3.6406777778e+01,
lng: 1.3775266667e+02,
content:'Saddle = 2083.000000 pos = 36.4068,137.7527 diff = 198.899902'
});
data_peak.push({
lat: 3.6226888889e+01,
lng: 1.3758733333e+02,
cert : false,
content:' Peak = 2452.800049 pos = 36.2269,137.5873 diff = 365.800049'
});
data_saddle.push({
lat: 3.6236333333e+01,
lng: 1.3759388889e+02,
content:'Saddle = 2087.000000 pos = 36.2363,137.5939 diff = 365.800049'
});
data_peak.push({
lat: 3.6207666666e+01,
lng: 1.3771166667e+02,
cert : true,
content:'Name = JA/NN-038(JA/NN-038) peak = 2387.199951 pos = 36.2077,137.7117 diff = 259.500000'
});
data_saddle.push({
lat: 3.6212222222e+01,
lng: 1.3768866667e+02,
content:'Saddle = 2127.699951 pos = 36.2122,137.6887 diff = 259.500000'
});
data_peak.push({
lat: 3.6221222222e+01,
lng: 1.3764055556e+02,
cert : true,
content:'Name = Kasumizawadake(JA/NN-025) peak = 2643.800049 pos = 36.2212,137.6406 diff = 513.400146'
});
data_saddle.push({
lat: 3.6226222222e+01,
lng: 1.3767611111e+02,
content:'Saddle = 2130.399902 pos = 36.2262,137.6761 diff = 513.400146'
});
data_peak.push({
lat: 3.6222666666e+01,
lng: 1.3767033333e+02,
cert : false,
content:' Peak = 2427.199951 pos = 36.2227,137.6703 diff = 166.500000'
});
data_saddle.push({
lat: 3.6225444444e+01,
lng: 1.3766111111e+02,
content:'Saddle = 2260.699951 pos = 36.2254,137.6611 diff = 166.500000'
});
data_peak.push({
lat: 3.6576000000e+01,
lng: 1.3761966667e+02,
cert : true,
content:'Name = Tateyama(JA/TY-001) peak = 3012.500000 pos = 36.5760,137.6197 diff = 865.800049'
});
data_saddle.push({
lat: 3.6505555555e+01,
lng: 1.3757488889e+02,
content:'Saddle = 2146.699951 pos = 36.5056,137.5749 diff = 865.800049'
});
data_peak.push({
lat: 3.6650333333e+01,
lng: 1.3762077778e+02,
cert : true,
content:'Name = Shirohage(JA/TY-015) peak = 2382.699951 pos = 36.6503,137.6208 diff = 204.800049'
});
data_saddle.push({
lat: 3.6646888889e+01,
lng: 1.3762244444e+02,
content:'Saddle = 2177.899902 pos = 36.6469,137.6224 diff = 204.800049'
});
data_peak.push({
lat: 3.6641444444e+01,
lng: 1.3762533333e+02,
cert : false,
content:' Peak = 2560.100098 pos = 36.6414,137.6253 diff = 219.800049'
});
data_saddle.push({
lat: 3.6636333333e+01,
lng: 1.3762355556e+02,
content:'Saddle = 2340.300049 pos = 36.6363,137.6236 diff = 219.800049'
});
data_peak.push({
lat: 3.6541888889e+01,
lng: 1.3758711111e+02,
cert : true,
content:'Name = Washidake(JA/TY-010) peak = 2615.600098 pos = 36.5419,137.5871 diff = 273.900146'
});
data_saddle.push({
lat: 3.6548000000e+01,
lng: 1.3759977778e+02,
content:'Saddle = 2341.699951 pos = 36.5480,137.5998 diff = 273.900146'
});
data_peak.push({
lat: 3.6515111111e+01,
lng: 1.3758288889e+02,
cert : true,
content:'Name = Ecchuuzawadake(JA/TY-012) peak = 2591.500000 pos = 36.5151,137.5829 diff = 239.699951'
});
data_saddle.push({
lat: 3.6526000000e+01,
lng: 1.3758255556e+02,
content:'Saddle = 2351.800049 pos = 36.5260,137.5826 diff = 239.699951'
});
data_peak.push({
lat: 3.6598444444e+01,
lng: 1.3758088889e+02,
cert : true,
content:'Name = Okudainichidake(JA/TY-011) peak = 2610.800049 pos = 36.5984,137.5809 diff = 258.500000'
});
data_saddle.push({
lat: 3.6591888889e+01,
lng: 1.3759300000e+02,
content:'Saddle = 2352.300049 pos = 36.5919,137.5930 diff = 258.500000'
});
data_peak.push({
lat: 3.6623333333e+01,
lng: 1.3761700000e+02,
cert : true,
content:'Name = Tsurugidake(JA/TY-002) peak = 2995.800049 pos = 36.6233,137.6170 diff = 466.000000'
});
data_saddle.push({
lat: 3.6609444444e+01,
lng: 1.3761000000e+02,
content:'Saddle = 2529.800049 pos = 36.6094,137.6100 diff = 466.000000'
});
data_peak.push({
lat: 3.6564777778e+01,
lng: 1.3760711111e+02,
cert : true,
content:'Name = Ryuuoudake(JA/TY-005) peak = 2871.600098 pos = 36.5648,137.6071 diff = 189.600098'
});
data_saddle.push({
lat: 3.6569666667e+01,
lng: 1.3761066667e+02,
content:'Saddle = 2682.000000 pos = 36.5697,137.6107 diff = 189.600098'
});
data_peak.push({
lat: 3.6624555556e+01,
lng: 1.3774700000e+02,
cert : true,
content:'Name = Kashimayarigatake(JA/NN-012) peak = 2880.600098 pos = 36.6246,137.7470 diff = 698.900146'
});
data_saddle.push({
lat: 3.6513777778e+01,
lng: 1.3768755556e+02,
content:'Saddle = 2181.699951 pos = 36.5138,137.6876 diff = 698.900146'
});
data_peak.push({
lat: 3.6517666667e+01,
lng: 1.3770544444e+02,
cert : true,
content:'Name = Kitakuzudake(JA/NN-029) peak = 2550.100098 pos = 36.5177,137.7054 diff = 272.200195'
});
data_saddle.push({
lat: 3.6526333333e+01,
lng: 1.3770366667e+02,
content:'Saddle = 2277.899902 pos = 36.5263,137.7037 diff = 272.200195'
});
data_peak.push({
lat: 3.6510666667e+01,
lng: 1.3769444444e+02,
cert : false,
content:' Peak = 2508.500000 pos = 36.5107,137.6944 diff = 176.300049'
});
data_saddle.push({
lat: 3.6515444444e+01,
lng: 1.3769922222e+02,
content:'Saddle = 2332.199951 pos = 36.5154,137.6992 diff = 176.300049'
});
data_peak.push({
lat: 3.6538111111e+01,
lng: 1.3768444444e+02,
cert : true,
content:'Name = Harinokidake(JA/TY-007) peak = 2820.199951 pos = 36.5381,137.6844 diff = 433.599854'
});
data_saddle.push({
lat: 3.6601777778e+01,
lng: 1.3774922222e+02,
content:'Saddle = 2386.600098 pos = 36.6018,137.7492 diff = 433.599854'
});
data_peak.push({
lat: 3.6588333333e+01,
lng: 1.3775088889e+02,
cert : true,
content:'Name = Jiigatake(JA/NN-022) peak = 2667.800049 pos = 36.5883,137.7509 diff = 271.600098'
});
data_saddle.push({
lat: 3.6587333333e+01,
lng: 1.3772944444e+02,
content:'Saddle = 2396.199951 pos = 36.5873,137.7294 diff = 271.600098'
});
data_peak.push({
lat: 3.6577000000e+01,
lng: 1.3771333333e+02,
cert : false,
content:' Peak = 2628.800049 pos = 36.5770,137.7133 diff = 168.199951'
});
data_saddle.push({
lat: 3.6571000000e+01,
lng: 1.3770177778e+02,
content:'Saddle = 2460.600098 pos = 36.5710,137.7018 diff = 168.199951'
});
data_peak.push({
lat: 3.6562000000e+01,
lng: 1.3768744444e+02,
cert : true,
content:'Name = Akazawadake(JA/NN-020) peak = 2676.300049 pos = 36.5620,137.6874 diff = 185.100098'
});
data_saddle.push({
lat: 3.6554555555e+01,
lng: 1.3768922222e+02,
content:'Saddle = 2491.199951 pos = 36.5546,137.6892 diff = 185.100098'
});
data_peak.push({
lat: 3.6535777778e+01,
lng: 1.3771044444e+02,
cert : false,
content:' Peak = 2795.699951 pos = 36.5358,137.7104 diff = 260.699951'
});
data_saddle.push({
lat: 3.6537222222e+01,
lng: 1.3769422222e+02,
content:'Saddle = 2535.000000 pos = 36.5372,137.6942 diff = 260.699951'
});
data_peak.push({
lat: 3.6658444444e+01,
lng: 1.3775266667e+02,
cert : true,
content:'Name = Goryuudake(JA/NN-016) peak = 2812.100098 pos = 36.6584,137.7527 diff = 390.300049'
});
data_saddle.push({
lat: 3.6641444444e+01,
lng: 1.3775377778e+02,
content:'Saddle = 2421.800049 pos = 36.6414,137.7538 diff = 390.300049'
});
data_peak.push({
lat: 3.6514555555e+01,
lng: 1.3767700000e+02,
cert : true,
content:'Name = JA/NN-034(JA/NN-034) peak = 2456.899902 pos = 36.5146,137.6770 diff = 225.199951'
});
data_saddle.push({
lat: 3.6509111111e+01,
lng: 1.3766866667e+02,
content:'Saddle = 2231.699951 pos = 36.5091,137.6687 diff = 225.199951'
});
data_peak.push({
lat: 3.6447222222e+01,
lng: 1.3773588889e+02,
cert : true,
content:'Name = Gakidake(JA/NN-023) peak = 2645.000000 pos = 36.4472,137.7359 diff = 393.399902'
});
data_saddle.push({
lat: 3.6421777778e+01,
lng: 1.3772244444e+02,
content:'Saddle = 2251.600098 pos = 36.4218,137.7224 diff = 393.399902'
});
data_peak.push({
lat: 3.6461222222e+01,
lng: 1.3771666667e+02,
cert : false,
content:' Peak = 2634.100098 pos = 36.4612,137.7167 diff = 241.600098'
});
data_saddle.push({
lat: 3.6456444444e+01,
lng: 1.3772544444e+02,
content:'Saddle = 2392.500000 pos = 36.4564,137.7254 diff = 241.600098'
});
data_peak.push({
lat: 3.6325222222e+01,
lng: 1.3770455556e+02,
cert : false,
content:' Peak = 2490.800049 pos = 36.3252,137.7046 diff = 228.500000'
});
data_saddle.push({
lat: 3.6331333333e+01,
lng: 1.3770655556e+02,
content:'Saddle = 2262.300049 pos = 36.3313,137.7066 diff = 228.500000'
});
data_peak.push({
lat: 3.6468888889e+01,
lng: 1.3754477778e+02,
cert : true,
content:'Name = Yakushidake(JA/TY-004) peak = 2924.500000 pos = 36.4689,137.5448 diff = 630.199951'
});
data_saddle.push({
lat: 3.6453333333e+01,
lng: 1.3752500000e+02,
content:'Saddle = 2294.300049 pos = 36.4533,137.5250 diff = 630.199951'
});
data_peak.push({
lat: 3.6380666666e+01,
lng: 1.3765044444e+02,
cert : true,
content:'Name = Ioudake(JA/NN-028) peak = 2550.500000 pos = 36.3807,137.6504 diff = 217.800049'
});
data_saddle.push({
lat: 3.6370666666e+01,
lng: 1.3763511111e+02,
content:'Saddle = 2332.699951 pos = 36.3707,137.6351 diff = 217.800049'
});
data_peak.push({
lat: 3.6392666666e+01,
lng: 1.3753988889e+02,
cert : true,
content:'Name = Kurobegoroudake (Nakanomatadake)(JA/GF-005) peak = 2833.300049 pos = 36.3927,137.5399 diff = 486.900146'
});
data_saddle.push({
lat: 3.6388777778e+01,
lng: 1.3756544444e+02,
content:'Saddle = 2346.399902 pos = 36.3888,137.5654 diff = 486.900146'
});
data_peak.push({
lat: 3.6421111111e+01,
lng: 1.3751233333e+02,
cert : true,
content:'Name = Kitanomatadake (Kaminodake)(JA/TY-009) peak = 2661.399902 pos = 36.4211,137.5123 diff = 204.099854'
});
data_saddle.push({
lat: 3.6404888889e+01,
lng: 1.3752477778e+02,
content:'Saddle = 2457.300049 pos = 36.4049,137.5248 diff = 204.099854'
});
data_peak.push({
lat: 3.6495444444e+01,
lng: 1.3766733333e+02,
cert : false,
content:' Peak = 2600.199951 pos = 36.4954,137.6673 diff = 204.599854'
});
data_saddle.push({
lat: 3.6493333333e+01,
lng: 1.3765933333e+02,
content:'Saddle = 2395.600098 pos = 36.4933,137.6593 diff = 204.599854'
});
data_peak.push({
lat: 3.6299444444e+01,
lng: 1.3767822222e+02,
cert : true,
content:'Name = JA/NN-027(JA/NN-027) peak = 2573.899902 pos = 36.2994,137.6782 diff = 167.000000'
});
data_saddle.push({
lat: 3.6293888889e+01,
lng: 1.3767477778e+02,
content:'Saddle = 2406.899902 pos = 36.2939,137.6748 diff = 167.000000'
});
data_peak.push({
lat: 3.6325555555e+01,
lng: 1.3772755556e+02,
cert : true,
content:'Name = Jyounendake(JA/NN-014) peak = 2856.399902 pos = 36.3256,137.7276 diff = 398.799805'
});
data_saddle.push({
lat: 3.6333222222e+01,
lng: 1.3772766667e+02,
content:'Saddle = 2457.600098 pos = 36.3332,137.7277 diff = 398.799805'
});
data_peak.push({
lat: 3.6287444444e+01,
lng: 1.3772600000e+02,
cert : true,
content:'Name = Chyougatake(JA/NN-021) peak = 2676.500000 pos = 36.2874,137.7260 diff = 215.800049'
});
data_saddle.push({
lat: 3.6312000000e+01,
lng: 1.3772500000e+02,
content:'Saddle = 2460.699951 pos = 36.3120,137.7250 diff = 215.800049'
});
data_peak.push({
lat: 3.6315555555e+01,
lng: 1.3755033333e+02,
cert : true,
content:'Name = Kasagatake(JA/GF-003) peak = 2897.000000 pos = 36.3156,137.5503 diff = 439.199951'
});
data_saddle.push({
lat: 3.6347666666e+01,
lng: 1.3759122222e+02,
content:'Saddle = 2457.800049 pos = 36.3477,137.5912 diff = 439.199951'
});
data_peak.push({
lat: 3.6365000000e+01,
lng: 1.3770111111e+02,
cert : true,
content:'Name = Daitenjyoudake(JA/NN-010) peak = 2921.300049 pos = 36.3650,137.7011 diff = 448.600098'
});
data_saddle.push({
lat: 3.6337000000e+01,
lng: 1.3767011111e+02,
content:'Saddle = 2472.699951 pos = 36.3370,137.6701 diff = 448.600098'
});
data_peak.push({
lat: 3.6343444444e+01,
lng: 1.3768400000e+02,
cert : true,
content:'Name = Akaiwadake(JA/NN-018) peak = 2764.300049 pos = 36.3434,137.6840 diff = 217.100098'
});
data_saddle.push({
lat: 3.6357111111e+01,
lng: 1.3769022222e+02,
content:'Saddle = 2547.199951 pos = 36.3571,137.6902 diff = 217.100098'
});
data_peak.push({
lat: 3.6406888889e+01,
lng: 1.3771266667e+02,
cert : true,
content:'Name = Tsubakurodake(JA/NN-019) peak = 2762.000000 pos = 36.4069,137.7127 diff = 199.100098'
});
data_saddle.push({
lat: 3.6382333333e+01,
lng: 1.3770733333e+02,
content:'Saddle = 2562.899902 pos = 36.3823,137.7073 diff = 199.100098'
});
data_peak.push({
lat: 3.6426333333e+01,
lng: 1.3760277778e+02,
cert : true,
content:'Name = Suishoudake (Kurodake)(JA/TY-003) peak = 2979.699951 pos = 36.4263,137.6028 diff = 448.199951'
});
data_saddle.push({
lat: 3.6396888889e+01,
lng: 1.3759822222e+02,
content:'Saddle = 2531.500000 pos = 36.3969,137.5982 diff = 448.199951'
});
data_peak.push({
lat: 3.6432777778e+01,
lng: 1.3763777778e+02,
cert : true,
content:'Name = Noguchigoroudake(JA/NN-009) peak = 2923.699951 pos = 36.4328,137.6378 diff = 192.500000'
});
data_saddle.push({
lat: 3.6418666667e+01,
lng: 1.3761633333e+02,
content:'Saddle = 2731.199951 pos = 36.4187,137.6163 diff = 192.500000'
});
data_peak.push({
lat: 3.6371888889e+01,
lng: 1.3758711111e+02,
cert : true,
content:'Name = Sugorokudake(JA/GF-004) peak = 2860.100098 pos = 36.3719,137.5871 diff = 312.500000'
});
data_saddle.push({
lat: 3.6369666666e+01,
lng: 1.3760166667e+02,
content:'Saddle = 2547.600098 pos = 36.3697,137.6017 diff = 312.500000'
});
data_peak.push({
lat: 3.6366555555e+01,
lng: 1.3760777778e+02,
cert : false,
content:' Peak = 2752.600098 pos = 36.3666,137.6078 diff = 159.500000'
});
data_saddle.push({
lat: 3.6354111111e+01,
lng: 1.3762477778e+02,
content:'Saddle = 2593.100098 pos = 36.3541,137.6248 diff = 159.500000'
});
data_peak.push({
lat: 3.6342000000e+01,
lng: 1.3764766667e+02,
cert : true,
content:'Name = Yarigatake(JA/NN-002) peak = 3181.399902 pos = 36.3420,137.6477 diff = 434.699951'
});
data_saddle.push({
lat: 3.6310777778e+01,
lng: 1.3764922222e+02,
content:'Saddle = 2746.699951 pos = 36.3108,137.6492 diff = 434.699951'
});
data_peak.push({
lat: 3.6282000000e+01,
lng: 1.3766055556e+02,
cert : true,
content:'Name = Maehotakadake(JA/NN-004) peak = 3090.100098 pos = 36.2820,137.6606 diff = 158.700195'
});
data_saddle.push({
lat: 3.6284000000e+01,
lng: 1.3765655556e+02,
content:'Saddle = 2931.399902 pos = 36.2840,137.6566 diff = 158.700195'
});
data_peak.push({
lat: 3.6302555555e+01,
lng: 1.3765200000e+02,
cert : true,
content:'Name = Kitahotakadake(JA/NN-003) peak = 3103.600098 pos = 36.3026,137.6520 diff = 158.900146'
});
data_saddle.push({
lat: 3.6299000000e+01,
lng: 1.3764811111e+02,
content:'Saddle = 2944.699951 pos = 36.2990,137.6481 diff = 158.900146'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:36.6667,
       south:34,
       east:138,
       west:136}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
