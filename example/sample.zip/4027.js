function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 2.6717111111e+01,
lng: 1.2821866667e+02,
cert : true,
content:'Name = Yonahadake(JA6/ON-002) peak = 501.899994 pos = 26.7171,128.2187 diff = 501.899994'
});
data_saddle.push({
lat: 2.7333333333e+01,
lng: 1.2858222222e+02,
content:'Saddle = 0.000000 pos = 27.3333,128.5822 diff = 501.899994'
});
data_peak.push({
lat: 2.6211111112e+01,
lng: 1.2736344444e+02,
cert : true,
content:'Name = JA6/ON-032(JA6/ON-032) peak = 226.899994 pos = 26.2111,127.3634 diff = 226.899994'
});
data_saddle.push({
lat: 2.6145666667e+01,
lng: 1.2734777778e+02,
content:'Saddle = 0.000000 pos = 26.1457,127.3478 diff = 226.899994'
});
data_peak.push({
lat: 2.6182555556e+01,
lng: 1.2728844444e+02,
cert : true,
content:'Name = JA6/ON-044(JA6/ON-044) peak = 156.899994 pos = 26.1826,127.2884 diff = 156.899994'
});
data_saddle.push({
lat: 2.6175666667e+01,
lng: 1.2729277778e+02,
content:'Saddle = 0.000000 pos = 26.1757,127.2928 diff = 156.899994'
});
data_peak.push({
lat: 2.6203777778e+01,
lng: 1.2727533333e+02,
cert : true,
content:'Name = JA6/ON-040(JA6/ON-040) peak = 185.600006 pos = 26.2038,127.2753 diff = 185.600006'
});
data_saddle.push({
lat: 2.6186666667e+01,
lng: 1.2727677778e+02,
content:'Saddle = 0.000000 pos = 26.1867,127.2768 diff = 185.600006'
});
data_peak.push({
lat: 2.6242111112e+01,
lng: 1.2732700000e+02,
cert : false,
content:' Peak = 160.399994 pos = 26.2421,127.3270 diff = 160.399994'
});
data_saddle.push({
lat: 2.6218555556e+01,
lng: 1.2730811111e+02,
content:'Saddle = 0.000000 pos = 26.2186,127.3081 diff = 160.399994'
});
data_peak.push({
lat: 2.6719888889e+01,
lng: 1.2780711111e+02,
cert : false,
content:' Peak = 171.600006 pos = 26.7199,127.8071 diff = 171.600006'
});
data_saddle.push({
lat: 2.6704555556e+01,
lng: 1.2780533333e+02,
content:'Saddle = 0.000000 pos = 26.7046,127.8053 diff = 171.600006'
});
data_peak.push({
lat: 2.6360111111e+01,
lng: 1.2714777778e+02,
cert : true,
content:'Name = Ootake(JA6/ON-043) peak = 177.800003 pos = 26.3601,127.1478 diff = 177.800003'
});
data_saddle.push({
lat: 2.6348333334e+01,
lng: 1.2714644444e+02,
content:'Saddle = 0.000000 pos = 26.3483,127.1464 diff = 177.800003'
});
data_peak.push({
lat: 2.6218555556e+01,
lng: 1.2724577778e+02,
cert : true,
content:'Name = JA6/ON-034(JA6/ON-034) peak = 213.300003 pos = 26.2186,127.2458 diff = 213.300003'
});
data_saddle.push({
lat: 2.6208111112e+01,
lng: 1.2724300000e+02,
content:'Saddle = 0.000000 pos = 26.2081,127.2430 diff = 213.300003'
});
data_peak.push({
lat: 2.6167333334e+01,
lng: 1.2723544444e+02,
cert : true,
content:'Name = JA6/ON-025(JA6/ON-025) peak = 270.799988 pos = 26.1673,127.2354 diff = 270.799988'
});
data_saddle.push({
lat: 2.6162222223e+01,
lng: 1.2724022222e+02,
content:'Saddle = 0.000000 pos = 26.1622,127.2402 diff = 270.799988'
});
data_peak.push({
lat: 2.7027333333e+01,
lng: 1.2794911111e+02,
cert : true,
content:'Name = JA6/ON-020(JA6/ON-020) peak = 291.600006 pos = 27.0273,127.9491 diff = 291.600006'
});
data_saddle.push({
lat: 2.6994777778e+01,
lng: 1.2793555556e+02,
content:'Saddle = 0.000000 pos = 26.9948,127.9356 diff = 291.600006'
});
data_peak.push({
lat: 2.7047888889e+01,
lng: 1.2798522222e+02,
cert : true,
content:'Name = JA6/ON-042(JA6/ON-042) peak = 173.699997 pos = 27.0479,127.9852 diff = 163.000000'
});
data_saddle.push({
lat: 2.7048000000e+01,
lng: 1.2797600000e+02,
content:'Saddle = 10.700000 pos = 27.0480,127.9760 diff = 163.000000'
});
data_peak.push({
lat: 2.7078555556e+01,
lng: 1.2799544444e+02,
cert : true,
content:'Name = JA6/ON-027(JA6/ON-027) peak = 235.000000 pos = 27.0786,127.9954 diff = 219.199997'
});
data_saddle.push({
lat: 2.7038444445e+01,
lng: 1.2795122222e+02,
content:'Saddle = 15.800000 pos = 27.0384,127.9512 diff = 219.199997'
});
data_peak.push({
lat: 2.7046222222e+01,
lng: 1.2796122222e+02,
cert : true,
content:'Name = JA6/ON-031(JA6/ON-031) peak = 225.500000 pos = 27.0462,127.9612 diff = 204.600006'
});
data_saddle.push({
lat: 2.7064444445e+01,
lng: 1.2797744444e+02,
content:'Saddle = 20.900000 pos = 27.0644,127.9774 diff = 204.600006'
});
data_peak.push({
lat: 2.7013777778e+01,
lng: 1.2793711111e+02,
cert : true,
content:'Name = JA6/ON-036(JA6/ON-036) peak = 210.199997 pos = 27.0138,127.9371 diff = 191.800003'
});
data_saddle.push({
lat: 2.7019000000e+01,
lng: 1.2793755556e+02,
content:'Saddle = 18.400000 pos = 27.0190,127.9376 diff = 191.800003'
});
data_peak.push({
lat: 2.6153444445e+01,
lng: 1.2776444444e+02,
cert : false,
content:' Peak = 191.800003 pos = 26.1534,127.7644 diff = 167.900009'
});
data_saddle.push({
lat: 2.6197666667e+01,
lng: 1.2774766667e+02,
content:'Saddle = 23.900000 pos = 26.1977,127.7477 diff = 167.900009'
});
data_peak.push({
lat: 2.6635555556e+01,
lng: 1.2792822222e+02,
cert : true,
content:'Name = Yaedake(JA6/ON-004) peak = 453.000000 pos = 26.6356,127.9282 diff = 422.100006'
});
data_saddle.push({
lat: 2.6617111111e+01,
lng: 1.2798844444e+02,
content:'Saddle = 30.900000 pos = 26.6171,127.9884 diff = 422.100006'
});
data_peak.push({
lat: 2.6670666667e+01,
lng: 1.2793822222e+02,
cert : true,
content:'Name = JA6/ON-021(JA6/ON-021) peak = 294.399994 pos = 26.6707,127.9382 diff = 186.799988'
});
data_saddle.push({
lat: 2.6655333334e+01,
lng: 1.2793555556e+02,
content:'Saddle = 107.599998 pos = 26.6553,127.9356 diff = 186.799988'
});
data_peak.push({
lat: 2.6420111111e+01,
lng: 1.2778700000e+02,
cert : false,
content:' Peak = 202.300003 pos = 26.4201,127.7870 diff = 163.200012'
});
data_saddle.push({
lat: 2.6442666667e+01,
lng: 1.2780955556e+02,
content:'Saddle = 39.099998 pos = 26.4427,127.8096 diff = 163.200012'
});
data_peak.push({
lat: 2.6598555556e+01,
lng: 1.2804788889e+02,
cert : true,
content:'Name = JA6/ON-009(JA6/ON-009) peak = 384.600006 pos = 26.5986,128.0479 diff = 342.700012'
});
data_saddle.push({
lat: 2.6644666667e+01,
lng: 1.2814666667e+02,
content:'Saddle = 41.900002 pos = 26.6447,128.1467 diff = 342.700012'
});
data_peak.push({
lat: 2.6479333334e+01,
lng: 1.2787466667e+02,
cert : true,
content:'Name = Onnadake(JA6/ON-011) peak = 361.600006 pos = 26.4793,127.8747 diff = 294.900024'
});
data_saddle.push({
lat: 2.6498777778e+01,
lng: 1.2790433333e+02,
content:'Saddle = 66.699997 pos = 26.4988,127.9043 diff = 294.900024'
});
data_peak.push({
lat: 2.6522888889e+01,
lng: 1.2797088889e+02,
cert : true,
content:'Name = JA6/ON-024(JA6/ON-024) peak = 283.000000 pos = 26.5229,127.9709 diff = 184.500000'
});
data_saddle.push({
lat: 2.6529111111e+01,
lng: 1.2797411111e+02,
content:'Saddle = 98.500000 pos = 26.5291,127.9741 diff = 184.500000'
});
data_peak.push({
lat: 2.6585555556e+01,
lng: 1.2800977778e+02,
cert : true,
content:'Name = JA6/ON-014(JA6/ON-014) peak = 344.600006 pos = 26.5856,128.0098 diff = 237.800003'
});
data_saddle.push({
lat: 2.6573777778e+01,
lng: 1.2802788889e+02,
content:'Saddle = 106.800003 pos = 26.5738,128.0279 diff = 237.800003'
});
data_peak.push({
lat: 2.6539444445e+01,
lng: 1.2800100000e+02,
cert : true,
content:'Name = JA6/ON-015(JA6/ON-015) peak = 333.000000 pos = 26.5394,128.0010 diff = 191.800003'
});
data_saddle.push({
lat: 2.6556222222e+01,
lng: 1.2800566667e+02,
content:'Saddle = 141.199997 pos = 26.5562,128.0057 diff = 191.800003'
});
data_peak.push({
lat: 2.6545222223e+01,
lng: 1.2800722222e+02,
cert : true,
content:'Name = JA6/ON-016(JA6/ON-016) peak = 331.299988 pos = 26.5452,128.0072 diff = 169.599991'
});
data_saddle.push({
lat: 2.6541555556e+01,
lng: 1.2800400000e+02,
content:'Saddle = 161.699997 pos = 26.5416,128.0040 diff = 169.599991'
});
data_peak.push({
lat: 2.6612222222e+01,
lng: 1.2808177778e+02,
cert : true,
content:'Name = JA6/ON-022(JA6/ON-022) peak = 291.600006 pos = 26.6122,128.0818 diff = 178.200012'
});
data_saddle.push({
lat: 2.6589888889e+01,
lng: 1.2809611111e+02,
content:'Saddle = 113.400002 pos = 26.5899,128.0961 diff = 178.200012'
});
data_peak.push({
lat: 2.6684444445e+01,
lng: 1.2813866667e+02,
cert : true,
content:'Name = JA6/ON-013(JA6/ON-013) peak = 360.399994 pos = 26.6844,128.1387 diff = 167.500000'
});
data_saddle.push({
lat: 2.6687555556e+01,
lng: 1.2817344444e+02,
content:'Saddle = 192.899994 pos = 26.6876,128.1734 diff = 167.500000'
});
data_peak.push({
lat: 2.6804111111e+01,
lng: 1.2827411111e+02,
cert : false,
content:' Peak = 420.799988 pos = 26.8041,128.2741 diff = 200.199982'
});
data_saddle.push({
lat: 2.6780888889e+01,
lng: 1.2827900000e+02,
content:'Saddle = 220.600006 pos = 26.7809,128.2790 diff = 200.199982'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:27.3333,
       south:26,
       east:129,
       west:127}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
