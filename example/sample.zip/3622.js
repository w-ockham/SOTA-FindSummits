function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 2.4427333333e+01,
lng: 1.2418333333e+02,
cert : true,
content:'Name = Omotodake(JA6/ON-001) peak = 524.599976 pos = 24.4273,124.1833 diff = 524.599976'
});
data_saddle.push({
lat: 2.4657444444e+01,
lng: 1.2467044444e+02,
content:'Saddle = 0.000000 pos = 24.6574,124.6704 diff = 524.599976'
});
data_peak.push({
lat: 2.4375111111e+01,
lng: 1.2371300000e+02,
cert : false,
content:' Peak = 151.500000 pos = 24.3751,123.7130 diff = 151.500000'
});
data_saddle.push({
lat: 2.4365222222e+01,
lng: 1.2371888889e+02,
content:'Saddle = 0.000000 pos = 24.3652,123.7189 diff = 151.500000'
});
data_peak.push({
lat: 2.4351222222e+01,
lng: 1.2373900000e+02,
cert : false,
content:' Peak = 194.000000 pos = 24.3512,123.7390 diff = 194.000000'
});
data_saddle.push({
lat: 2.4345777778e+01,
lng: 1.2374200000e+02,
content:'Saddle = 0.000000 pos = 24.3458,123.7420 diff = 194.000000'
});
data_peak.push({
lat: 2.4452888889e+01,
lng: 1.2300544444e+02,
cert : true,
content:'Name = Urabudake(JA6/ON-029) peak = 230.699997 pos = 24.4529,123.0054 diff = 230.699997'
});
data_saddle.push({
lat: 2.4436777778e+01,
lng: 1.2301100000e+02,
content:'Saddle = 0.000000 pos = 24.4368,123.0110 diff = 230.699997'
});
data_peak.push({
lat: 2.4361111111e+01,
lng: 1.2389200000e+02,
cert : false,
content:' Peak = 464.100006 pos = 24.3611,123.8920 diff = 464.100006'
});
data_saddle.push({
lat: 2.4329777778e+01,
lng: 1.2416988889e+02,
content:'Saddle = 0.000000 pos = 24.3298,124.1699 diff = 464.100006'
});
data_peak.push({
lat: 2.4341444444e+01,
lng: 1.2375588889e+02,
cert : true,
content:'Name = JA6/ON-037(JA6/ON-037) peak = 205.500000 pos = 24.3414,123.7559 diff = 162.800003'
});
data_saddle.push({
lat: 2.4336444444e+01,
lng: 1.2375300000e+02,
content:'Saddle = 42.700001 pos = 24.3364,123.7530 diff = 162.800003'
});
data_peak.push({
lat: 2.4295111111e+01,
lng: 1.2368222222e+02,
cert : true,
content:'Name = JA6/ON-017(JA6/ON-017) peak = 313.299988 pos = 24.2951,123.6822 diff = 220.799988'
});
data_saddle.push({
lat: 2.4291666666e+01,
lng: 1.2374533333e+02,
content:'Saddle = 92.500000 pos = 24.2917,123.7453 diff = 220.799988'
});
data_peak.push({
lat: 2.4327888889e+01,
lng: 1.2372233333e+02,
cert : true,
content:'Name = JA6/ON-019(JA6/ON-019) peak = 292.600006 pos = 24.3279,123.7223 diff = 162.400009'
});
data_saddle.push({
lat: 2.4303666666e+01,
lng: 1.2371488889e+02,
content:'Saddle = 130.199997 pos = 24.3037,123.7149 diff = 162.400009'
});
data_peak.push({
lat: 2.4340666666e+01,
lng: 1.2379488889e+02,
cert : false,
content:' Peak = 443.700012 pos = 24.3407,123.7949 diff = 226.300018'
});
data_saddle.push({
lat: 2.4315444444e+01,
lng: 1.2384311111e+02,
content:'Saddle = 217.399994 pos = 24.3154,123.8431 diff = 226.300018'
});
data_peak.push({
lat: 2.4281444444e+01,
lng: 1.2379566667e+02,
cert : true,
content:'Name = JA6/ON-007(JA6/ON-007) peak = 423.600006 pos = 24.2814,123.7957 diff = 202.500000'
});
data_saddle.push({
lat: 2.4311777778e+01,
lng: 1.2378922222e+02,
content:'Saddle = 221.100006 pos = 24.3118,123.7892 diff = 202.500000'
});
data_peak.push({
lat: 2.4362555555e+01,
lng: 1.2381633333e+02,
cert : true,
content:'Name = JA6/ON-006(JA6/ON-006) peak = 442.500000 pos = 24.3626,123.8163 diff = 159.399994'
});
data_saddle.push({
lat: 2.4366888889e+01,
lng: 1.2383744444e+02,
content:'Saddle = 283.100006 pos = 24.3669,123.8374 diff = 159.399994'
});
data_peak.push({
lat: 2.4572111111e+01,
lng: 1.2431400000e+02,
cert : true,
content:'Name = JA6/ON-010(JA6/ON-010) peak = 363.799988 pos = 24.5721,124.3140 diff = 358.199982'
});
data_saddle.push({
lat: 2.4504333333e+01,
lng: 1.2428055556e+02,
content:'Saddle = 5.600000 pos = 24.5043,124.2806 diff = 358.199982'
});
data_peak.push({
lat: 2.4522333333e+01,
lng: 1.2428888889e+02,
cert : false,
content:' Peak = 237.800003 pos = 24.5223,124.2889 diff = 226.000000'
});
data_saddle.push({
lat: 2.4542777778e+01,
lng: 1.2429844444e+02,
content:'Saddle = 11.800000 pos = 24.5428,124.2984 diff = 226.000000'
});
data_peak.push({
lat: 2.4439444444e+01,
lng: 1.2408622222e+02,
cert : true,
content:'Name = JA6/ON-033(JA6/ON-033) peak = 215.000000 pos = 24.4394,124.0862 diff = 197.300003'
});
data_saddle.push({
lat: 2.4439222222e+01,
lng: 1.2410644444e+02,
content:'Saddle = 17.700001 pos = 24.4392,124.1064 diff = 197.300003'
});
data_peak.push({
lat: 2.4381888889e+01,
lng: 1.2416544444e+02,
cert : false,
content:' Peak = 231.800003 pos = 24.3819,124.1654 diff = 195.200012'
});
data_saddle.push({
lat: 2.4393444444e+01,
lng: 1.2417755556e+02,
content:'Saddle = 36.599998 pos = 24.3934,124.1776 diff = 195.200012'
});
data_peak.push({
lat: 2.4456777778e+01,
lng: 1.2412755556e+02,
cert : true,
content:'Name = JA6/ON-026(JA6/ON-026) peak = 261.299988 pos = 24.4568,124.1276 diff = 211.399994'
});
data_saddle.push({
lat: 2.4447000000e+01,
lng: 1.2412733333e+02,
content:'Saddle = 49.900002 pos = 24.4470,124.1273 diff = 211.399994'
});
data_peak.push({
lat: 2.4442111111e+01,
lng: 1.2419377778e+02,
cert : false,
content:' Peak = 474.899994 pos = 24.4421,124.1938 diff = 164.000000'
});
data_saddle.push({
lat: 2.4436111111e+01,
lng: 1.2418833333e+02,
content:'Saddle = 310.899994 pos = 24.4361,124.1883 diff = 164.000000'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:24.6667,
       south:24,
       east:125,
       west:122}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
