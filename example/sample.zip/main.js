function map_canvas() {
    var region_data = new Array();
    var region = new Array();
    region_data.push({	region: "./6841.html",	    bounds: {
       north:46,
       south:45.3333,
       east:143,
       west:141}});

    region_data.push({	region: "./6642.html",	    bounds: {
       north:44.6667,
       south:42,
       east:144,
       west:142}});

    region_data.push({	region: "./6644.html",	    bounds: {
       north:44.6667,
       south:42.6667,
       east:146,
       west:144}});

    region_data.push({	region: "./6540.html",	    bounds: {
       north:44,
       south:42.6667,
       east:143,
       west:140}});

    region_data.push({	region: "./6339.html",	    bounds: {
       north:42.6667,
       south:41.3333,
       east:142,
       west:139}});

    region_data.push({	region: "./6140.html",	    bounds: {
       north:41.3333,
       south:38.6667,
       east:142,
       west:140}});

    region_data.push({	region: "./5839.html",	    bounds: {
       north:39.3333,
       south:38,
       east:142,
       west:139}});

    region_data.push({	region: "./5739.html",	    bounds: {
       north:38.6667,
       south:36.6667,
       east:141,
       west:139}});

    region_data.push({	region: "./5637.html",	    bounds: {
       north:38,
       south:36.6667,
       east:141,
       west:137}});

    region_data.push({	region: "./5537.html",	    bounds: {
       north:37.3333,
       south:36,
       east:141,
       west:137}});

    region_data.push({	region: "./5337.html",	    bounds: {
       north:36,
       south:34.6667,
       east:141,
       west:137}});

    region_data.push({	region: "./5338.html",	    bounds: {
       north:36,
       south:33.3333,
       east:140,
       west:138}});

    region_data.push({	region: "./4939.html",	    bounds: {
       north:33.3333,
       south:31.3333,
       east:140,
       west:139}});

    region_data.push({	region: "./4740.html",	    bounds: {
       north:32,
       south:31.3333,
       east:141,
       west:140}});

    region_data.push({	region: "./4540.html",	    bounds: {
       north:30.6667,
       south:29.3333,
       east:141,
       west:140}});

    region_data.push({	region: "./4040.html",	    bounds: {
       north:27.3333,
       south:26.6667,
       east:141,
       west:140}});

    region_data.push({	region: "./4142.html",	    bounds: {
       north:28,
       south:26,
       east:143,
       west:142}});

    region_data.push({	region: "./3841.html",	    bounds: {
       north:26,
       south:24,
       east:142,
       west:141}});

    region_data.push({	region: "./5436.html",	    bounds: {
       north:36.6667,
       south:34,
       east:138,
       west:136}});

    region_data.push({	region: "./5335.html",	    bounds: {
       north:36,
       south:33.3333,
       east:137,
       west:135}});

    region_data.push({	region: "./5332.html",	    bounds: {
       north:36,
       south:34.6667,
       east:135,
       west:132}});

    region_data.push({	region: "./5132.html",	    bounds: {
       north:34.6667,
       south:33.3333,
       east:135,
       west:132}});

    region_data.push({	region: "./5032.html",	    bounds: {
       north:34,
       south:32.6667,
       east:135,
       west:132}});

    region_data.push({	region: "./5432.html",	    bounds: {
       north:36.6667,
       south:35.3333,
       east:134,
       west:132}});

    region_data.push({	region: "./5231.html",	    bounds: {
       north:35.3333,
       south:34,
       east:133,
       west:131}});

    region_data.push({	region: "./5030.html",	    bounds: {
       north:34,
       south:31.3333,
       east:132,
       west:130}});

    region_data.push({	region: "./5029.html",	    bounds: {
       north:34,
       south:31.3333,
       east:131,
       west:129}});

    region_data.push({	region: "./5229.html",	    bounds: {
       north:35.3333,
       south:34,
       east:130,
       west:129}});

    region_data.push({	region: "./4928.html",	    bounds: {
       north:33.3333,
       south:32,
       east:131,
       west:128}});

    region_data.push({	region: "./4729.html",	    bounds: {
       north:32,
       south:30.6667,
       east:132,
       west:129}});

    region_data.push({	region: "./4629.html",	    bounds: {
       north:31.3333,
       south:30,
       east:132,
       west:129}});

    region_data.push({	region: "./4429.html",	    bounds: {
       north:30,
       south:28.6667,
       east:130,
       west:129}});

    region_data.push({	region: "./4128.html",	    bounds: {
       north:28,
       south:27.3333,
       east:130,
       west:128}});

    region_data.push({	region: "./4027.html",	    bounds: {
       north:27.3333,
       south:26,
       east:129,
       west:127}});

    region_data.push({	region: "./3926.html",	    bounds: {
       north:26.6667,
       south:26,
       east:127,
       west:126}});

    region_data.push({	region: "./3831.html",	    bounds: {
       north:26,
       south:25.3333,
       east:132,
       west:131}});

    region_data.push({	region: "./3631.html",	    bounds: {
       north:24.6667,
       south:24,
       east:132,
       west:131}});

    region_data.push({	region: "./3823.html",	    bounds: {
       north:26,
       south:25.3333,
       east:125,
       west:123}});

    region_data.push({	region: "./3622.html",	    bounds: {
       north:24.6667,
       south:24,
       east:125,
       west:122}});

    region_data.push({	region: "./3724.html",	    bounds: {
       north:25.3333,
       south:24.6667,
       east:126,
       west:124}});

    var latlng = new google.maps.LatLng(region_data[0].bounds.north, region_data[0].bounds.west);    var opts = {	zoom: 8,	center: latlng,	mapTypeId: google.maps.MapTypeId.TERRAIN    };    var map = new google.maps.Map(document.getElementById("map"), opts);    for(i = 0; i < region_data.length; i++) {	region[i] = new google.maps.Rectangle({	    region : region_data[i].region,	    map : map,	    strokeColor:"#00007f",	    strokeOpacity:1.0,	    strokeWeight:8,	    fillColor: '00003f',	    fillOpacity: 0.1,	    bounds: {		north : region_data[i].bounds.north,		south : region_data[i].bounds.south,		east : region_data[i].bounds.east,		west : region_data[i].bounds.west}	});	google.maps.event.addListener(region[i],'click',function(event){	    var newWindow =window.open(this.region)	    });    }}google.maps.event.addDomListener(window, 'load', map_canvas);
