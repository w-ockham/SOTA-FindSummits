function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.5371222221e+01,
lng: 1.3354633333e+02,
cert : true,
content:'Name = Daisen (Kengamine)(JA/TT-001) peak = 1725.699951 pos = 35.3712,133.5463 diff = 1725.699951'
});
data_saddle.push({
lat: 3.6352777778e+01,
lng: 1.3328144444e+02,
content:'Saddle = 0.000000 pos = 36.3528,133.2814 diff = 1725.699951'
});
data_peak.push({
lat: 3.6095888888e+01,
lng: 1.3307211111e+02,
cert : false,
content:' Peak = 245.899994 pos = 36.0959,133.0721 diff = 245.899994'
});
data_saddle.push({
lat: 3.6034777777e+01,
lng: 1.3306922222e+02,
content:'Saddle = 0.000000 pos = 36.0348,133.0692 diff = 245.899994'
});
data_peak.push({
lat: 3.6092777777e+01,
lng: 1.3311400000e+02,
cert : false,
content:' Peak = 226.199997 pos = 36.0928,133.1140 diff = 207.899994'
});
data_saddle.push({
lat: 3.6083666666e+01,
lng: 1.3307688889e+02,
content:'Saddle = 18.299999 pos = 36.0837,133.0769 diff = 207.899994'
});
data_peak.push({
lat: 3.6020777777e+01,
lng: 1.3301466667e+02,
cert : true,
content:'Name = JA/SN-130(JA/SN-130) peak = 323.000000 pos = 36.0208,133.0147 diff = 323.000000'
});
data_saddle.push({
lat: 3.5993888888e+01,
lng: 1.3306100000e+02,
content:'Saddle = 0.000000 pos = 35.9939,133.0610 diff = 323.000000'
});
data_peak.push({
lat: 3.6137888888e+01,
lng: 1.3317488889e+02,
cert : false,
content:' Peak = 151.399994 pos = 36.1379,133.1749 diff = 151.399994'
});
data_saddle.push({
lat: 3.6132777777e+01,
lng: 1.3317144444e+02,
content:'Saddle = 0.000000 pos = 36.1328,133.1714 diff = 151.399994'
});
data_peak.push({
lat: 3.6074777777e+01,
lng: 1.3303177778e+02,
cert : true,
content:'Name = Takuhiyama(JA/SN-106) peak = 450.899994 pos = 36.0748,133.0318 diff = 450.899994'
});
data_saddle.push({
lat: 3.6038000000e+01,
lng: 1.3299844444e+02,
content:'Saddle = 0.000000 pos = 36.0380,132.9984 diff = 450.899994'
});
data_peak.push({
lat: 3.6055666666e+01,
lng: 1.3298388889e+02,
cert : false,
content:' Peak = 288.399994 pos = 36.0557,132.9839 diff = 284.799988'
});
data_saddle.push({
lat: 3.6106888888e+01,
lng: 1.3300733333e+02,
content:'Saddle = 3.600000 pos = 36.1069,133.0073 diff = 284.799988'
});
data_peak.push({
lat: 3.6106666666e+01,
lng: 1.3297255556e+02,
cert : false,
content:' Peak = 256.200012 pos = 36.1067,132.9726 diff = 185.100006'
});
data_saddle.push({
lat: 3.6096000000e+01,
lng: 1.3298033333e+02,
content:'Saddle = 71.099998 pos = 36.0960,132.9803 diff = 185.100006'
});
data_peak.push({
lat: 3.6130777777e+01,
lng: 1.3302611111e+02,
cert : true,
content:'Name = JA/SN-112(JA/SN-112) peak = 432.200012 pos = 36.1308,133.0261 diff = 374.100006'
});
data_saddle.push({
lat: 3.6106555555e+01,
lng: 1.3302977778e+02,
content:'Saddle = 58.099998 pos = 36.1066,133.0298 diff = 374.100006'
});
data_peak.push({
lat: 3.6129000000e+01,
lng: 1.3307211111e+02,
cert : false,
content:' Peak = 274.799988 pos = 36.1290,133.0721 diff = 154.199982'
});
data_saddle.push({
lat: 3.6117444444e+01,
lng: 1.3304077778e+02,
content:'Saddle = 120.599998 pos = 36.1174,133.0408 diff = 154.199982'
});
data_peak.push({
lat: 3.6256888889e+01,
lng: 1.3333044444e+02,
cert : true,
content:'Name = Daimanjisan(JA/SN-062) peak = 605.500000 pos = 36.2569,133.3304 diff = 605.500000'
});
data_saddle.push({
lat: 3.6159444444e+01,
lng: 1.3324877778e+02,
content:'Saddle = 0.000000 pos = 36.1594,133.2488 diff = 605.500000'
});
data_peak.push({
lat: 3.6192000000e+01,
lng: 1.3331644444e+02,
cert : false,
content:' Peak = 236.199997 pos = 36.1920,133.3164 diff = 226.800003'
});
data_saddle.push({
lat: 3.6183888889e+01,
lng: 1.3330777778e+02,
content:'Saddle = 9.400000 pos = 36.1839,133.3078 diff = 226.800003'
});
data_peak.push({
lat: 3.6200111111e+01,
lng: 1.3334722222e+02,
cert : false,
content:' Peak = 198.100006 pos = 36.2001,133.3472 diff = 164.700012'
});
data_saddle.push({
lat: 3.6204888889e+01,
lng: 1.3335122222e+02,
content:'Saddle = 33.400002 pos = 36.2049,133.3512 diff = 164.700012'
});
data_peak.push({
lat: 3.6187555555e+01,
lng: 1.3329622222e+02,
cert : false,
content:' Peak = 251.699997 pos = 36.1876,133.2962 diff = 193.799988'
});
data_saddle.push({
lat: 3.6193777777e+01,
lng: 1.3329433333e+02,
content:'Saddle = 57.900002 pos = 36.1938,133.2943 diff = 193.799988'
});
data_peak.push({
lat: 3.6198777777e+01,
lng: 1.3329111111e+02,
cert : true,
content:'Name = JA/SN-132(JA/SN-132) peak = 271.899994 pos = 36.1988,133.2911 diff = 178.000000'
});
data_saddle.push({
lat: 3.6203111111e+01,
lng: 1.3329455556e+02,
content:'Saddle = 93.900002 pos = 36.2031,133.2946 diff = 178.000000'
});
data_peak.push({
lat: 3.6207777777e+01,
lng: 1.3327700000e+02,
cert : true,
content:'Name = JA/SN-119(JA/SN-119) peak = 371.100006 pos = 36.2078,133.2770 diff = 264.200012'
});
data_saddle.push({
lat: 3.6223444444e+01,
lng: 1.3327211111e+02,
content:'Saddle = 106.900002 pos = 36.2234,133.2721 diff = 264.200012'
});
data_peak.push({
lat: 3.6323666666e+01,
lng: 1.3325111111e+02,
cert : true,
content:'Name = JA/SN-131(JA/SN-131) peak = 322.600006 pos = 36.3237,133.2511 diff = 185.500000'
});
data_saddle.push({
lat: 3.6317444444e+01,
lng: 1.3325100000e+02,
content:'Saddle = 137.100006 pos = 36.3174,133.2510 diff = 185.500000'
});
data_peak.push({
lat: 3.6248666666e+01,
lng: 1.3323944444e+02,
cert : true,
content:'Name = JA/SN-075(JA/SN-075) peak = 572.299988 pos = 36.2487,133.2394 diff = 360.799988'
});
data_saddle.push({
lat: 3.6255444444e+01,
lng: 1.3325022222e+02,
content:'Saddle = 211.500000 pos = 36.2554,133.2502 diff = 360.799988'
});
data_peak.push({
lat: 3.6224333333e+01,
lng: 1.3325000000e+02,
cert : false,
content:' Peak = 473.299988 pos = 36.2243,133.2500 diff = 175.399994'
});
data_saddle.push({
lat: 3.6230222222e+01,
lng: 1.3324522222e+02,
content:'Saddle = 297.899994 pos = 36.2302,133.2452 diff = 175.399994'
});
data_peak.push({
lat: 3.6310555555e+01,
lng: 1.3327700000e+02,
cert : false,
content:' Peak = 507.500000 pos = 36.3106,133.2770 diff = 260.399994'
});
data_saddle.push({
lat: 3.6289777778e+01,
lng: 1.3328033333e+02,
content:'Saddle = 247.100006 pos = 36.2898,133.2803 diff = 260.399994'
});
data_peak.push({
lat: 3.6272222222e+01,
lng: 1.3328433333e+02,
cert : true,
content:'Name = JA/SN-090(JA/SN-090) peak = 521.000000 pos = 36.2722,133.2843 diff = 249.200012'
});
data_saddle.push({
lat: 3.6268000000e+01,
lng: 1.3329888889e+02,
content:'Saddle = 271.799988 pos = 36.2680,133.2989 diff = 249.200012'
});
data_peak.push({
lat: 3.6279222222e+01,
lng: 1.3331533333e+02,
cert : true,
content:'Name = JA/SN-065(JA/SN-065) peak = 597.299988 pos = 36.2792,133.3153 diff = 184.199982'
});
data_saddle.push({
lat: 3.6269666666e+01,
lng: 1.3331900000e+02,
content:'Saddle = 413.100006 pos = 36.2697,133.3190 diff = 184.199982'
});
data_peak.push({
lat: 3.5565999999e+01,
lng: 1.3316311111e+02,
cert : false,
content:' Peak = 171.399994 pos = 35.5660,133.1631 diff = 168.299988'
});
data_saddle.push({
lat: 3.5562111110e+01,
lng: 1.3316188889e+02,
content:'Saddle = 3.100000 pos = 35.5621,133.1619 diff = 168.299988'
});
data_peak.push({
lat: 3.5541555555e+01,
lng: 1.3310311111e+02,
cert : true,
content:'Name = JA/SN-084(JA/SN-084) peak = 535.500000 pos = 35.5416,133.1031 diff = 530.200012'
});
data_saddle.push({
lat: 3.5488333332e+01,
lng: 1.3301077778e+02,
content:'Saddle = 5.300000 pos = 35.4883,133.0108 diff = 530.200012'
});
data_peak.push({
lat: 3.5486666666e+01,
lng: 1.3310755556e+02,
cert : true,
content:'Name = Dakesan(JA/SN-128) peak = 330.899994 pos = 35.4867,133.1076 diff = 296.500000'
});
data_saddle.push({
lat: 3.5509555555e+01,
lng: 1.3310688889e+02,
content:'Saddle = 34.400002 pos = 35.5096,133.1069 diff = 296.500000'
});
data_peak.push({
lat: 3.5559999999e+01,
lng: 1.3323955556e+02,
cert : true,
content:'Name = JA/SN-129(JA/SN-129) peak = 330.100006 pos = 35.5600,133.2396 diff = 293.000000'
});
data_saddle.push({
lat: 3.5543333332e+01,
lng: 1.3316400000e+02,
content:'Saddle = 37.099998 pos = 35.5433,133.1640 diff = 293.000000'
});
data_peak.push({
lat: 3.5566222221e+01,
lng: 1.3327177778e+02,
cert : false,
content:' Peak = 261.600006 pos = 35.5662,133.2718 diff = 204.300003'
});
data_saddle.push({
lat: 3.5556888888e+01,
lng: 1.3325688889e+02,
content:'Saddle = 57.299999 pos = 35.5569,133.2569 diff = 204.300003'
});
data_peak.push({
lat: 3.5515111110e+01,
lng: 1.3306833333e+02,
cert : false,
content:' Peak = 295.799988 pos = 35.5151,133.0683 diff = 153.899994'
});
data_saddle.push({
lat: 3.5519555555e+01,
lng: 1.3306855556e+02,
content:'Saddle = 141.899994 pos = 35.5196,133.0686 diff = 153.899994'
});
data_peak.push({
lat: 3.5412666666e+01,
lng: 1.3275255556e+02,
cert : true,
content:'Name = Hanatakasen(JA/SN-085) peak = 535.000000 pos = 35.4127,132.7526 diff = 525.500000'
});
data_saddle.push({
lat: 3.5400333332e+01,
lng: 1.3278488889e+02,
content:'Saddle = 9.500000 pos = 35.4003,132.7849 diff = 525.500000'
});
data_peak.push({
lat: 3.5471777777e+01,
lng: 1.3278722222e+02,
cert : true,
content:'Name = JA/SN-116(JA/SN-116) peak = 420.799988 pos = 35.4718,132.7872 diff = 383.399994'
});
data_saddle.push({
lat: 3.5443111110e+01,
lng: 1.3276488889e+02,
content:'Saddle = 37.400002 pos = 35.4431,132.7649 diff = 383.399994'
});
data_peak.push({
lat: 3.5507888888e+01,
lng: 1.3297633333e+02,
cert : true,
content:'Name = Asahiyama(JA/SN-126) peak = 342.600006 pos = 35.5079,132.9763 diff = 245.700012'
});
data_saddle.push({
lat: 3.5511333332e+01,
lng: 1.3294200000e+02,
content:'Saddle = 96.900002 pos = 35.5113,132.9420 diff = 245.700012'
});
data_peak.push({
lat: 3.5484555555e+01,
lng: 1.3285644444e+02,
cert : false,
content:' Peak = 356.100006 pos = 35.4846,132.8564 diff = 217.500000'
});
data_saddle.push({
lat: 3.5483444444e+01,
lng: 1.3282544444e+02,
content:'Saddle = 138.600006 pos = 35.4834,132.8254 diff = 217.500000'
});
data_peak.push({
lat: 3.5425777777e+01,
lng: 1.3265477778e+02,
cert : false,
content:' Peak = 356.399994 pos = 35.4258,132.6548 diff = 155.199997'
});
data_saddle.push({
lat: 3.5417222221e+01,
lng: 1.3266388889e+02,
content:'Saddle = 201.199997 pos = 35.4172,132.6639 diff = 155.199997'
});
data_peak.push({
lat: 3.5490333332e+01,
lng: 1.3390711111e+02,
cert : false,
content:' Peak = 185.899994 pos = 35.4903,133.9071 diff = 171.599991'
});
data_saddle.push({
lat: 3.5489999999e+01,
lng: 1.3392422222e+02,
content:'Saddle = 14.300000 pos = 35.4900,133.9242 diff = 171.599991'
});
data_peak.push({
lat: 3.5436111110e+01,
lng: 1.3309400000e+02,
cert : false,
content:' Peak = 170.800003 pos = 35.4361,133.0940 diff = 152.100006'
});
data_saddle.push({
lat: 3.5433888888e+01,
lng: 1.3308966667e+02,
content:'Saddle = 18.700001 pos = 35.4339,133.0897 diff = 152.100006'
});
data_peak.push({
lat: 3.5452333332e+01,
lng: 1.3382066667e+02,
cert : false,
content:' Peak = 196.899994 pos = 35.4523,133.8207 diff = 177.199997'
});
data_saddle.push({
lat: 3.5446555555e+01,
lng: 1.3380366667e+02,
content:'Saddle = 19.700001 pos = 35.4466,133.8037 diff = 177.199997'
});
data_peak.push({
lat: 3.5335666666e+01,
lng: 1.3278922222e+02,
cert : false,
content:' Peak = 235.399994 pos = 35.3357,132.7892 diff = 214.599991'
});
data_saddle.push({
lat: 3.5333444443e+01,
lng: 1.3282400000e+02,
content:'Saddle = 20.799999 pos = 35.3334,132.8240 diff = 214.599991'
});
data_peak.push({
lat: 3.5339777777e+01,
lng: 1.3308288889e+02,
cert : false,
content:' Peak = 610.200012 pos = 35.3398,133.0829 diff = 580.299988'
});
data_saddle.push({
lat: 3.5333444443e+01,
lng: 1.3327266667e+02,
content:'Saddle = 29.900000 pos = 35.3334,133.2727 diff = 580.299988'
});
data_peak.push({
lat: 3.5344666666e+01,
lng: 1.3318277778e+02,
cert : false,
content:' Peak = 364.000000 pos = 35.3447,133.1828 diff = 322.000000'
});
data_saddle.push({
lat: 3.5333555555e+01,
lng: 1.3317444444e+02,
content:'Saddle = 42.000000 pos = 35.3336,133.1744 diff = 322.000000'
});
data_peak.push({
lat: 3.5358111110e+01,
lng: 1.3283022222e+02,
cert : true,
content:'Name = JA/SN-120(JA/SN-120) peak = 364.700012 pos = 35.3581,132.8302 diff = 286.500000'
});
data_saddle.push({
lat: 3.5368888888e+01,
lng: 1.3290266667e+02,
content:'Saddle = 78.199997 pos = 35.3689,132.9027 diff = 286.500000'
});
data_peak.push({
lat: 3.5351777777e+01,
lng: 1.3286266667e+02,
cert : false,
content:' Peak = 316.000000 pos = 35.3518,132.8627 diff = 178.000000'
});
data_saddle.push({
lat: 3.5359999999e+01,
lng: 1.3284833333e+02,
content:'Saddle = 138.000000 pos = 35.3600,132.8483 diff = 178.000000'
});
data_peak.push({
lat: 3.5337222221e+01,
lng: 1.3314700000e+02,
cert : false,
content:' Peak = 254.000000 pos = 35.3372,133.1470 diff = 167.000000'
});
data_saddle.push({
lat: 3.5333444443e+01,
lng: 1.3312188889e+02,
content:'Saddle = 87.000000 pos = 35.3334,133.1219 diff = 167.000000'
});
data_peak.push({
lat: 3.5371555555e+01,
lng: 1.3295900000e+02,
cert : true,
content:'Name = JA/SN-117(JA/SN-117) peak = 410.399994 pos = 35.3716,132.9590 diff = 202.399994'
});
data_saddle.push({
lat: 3.5370444443e+01,
lng: 1.3297966667e+02,
content:'Saddle = 208.000000 pos = 35.3704,132.9797 diff = 202.399994'
});
data_peak.push({
lat: 3.5367999999e+01,
lng: 1.3300822222e+02,
cert : true,
content:'Name = JA/SN-101(JA/SN-101) peak = 471.799988 pos = 35.3680,133.0082 diff = 253.099991'
});
data_saddle.push({
lat: 3.5343333332e+01,
lng: 1.3305144444e+02,
content:'Saddle = 218.699997 pos = 35.3433,133.0514 diff = 253.099991'
});
data_peak.push({
lat: 3.5364777777e+01,
lng: 1.3304955556e+02,
cert : false,
content:' Peak = 423.299988 pos = 35.3648,133.0496 diff = 165.299988'
});
data_saddle.push({
lat: 3.5377444443e+01,
lng: 1.3303033333e+02,
content:'Saddle = 258.000000 pos = 35.3774,133.0303 diff = 165.299988'
});
data_peak.push({
lat: 3.5387222221e+01,
lng: 1.3316411111e+02,
cert : true,
content:'Name = Kyouragisan(JA/SN-100) peak = 472.500000 pos = 35.3872,133.1641 diff = 180.399994'
});
data_saddle.push({
lat: 3.5362333332e+01,
lng: 1.3312288889e+02,
content:'Saddle = 292.100006 pos = 35.3623,133.1229 diff = 180.399994'
});
data_peak.push({
lat: 3.5381888888e+01,
lng: 1.3331933333e+02,
cert : true,
content:'Name = Yougaisan(JA/TT-051) peak = 280.799988 pos = 35.3819,133.3193 diff = 238.699982'
});
data_saddle.push({
lat: 3.5333444443e+01,
lng: 1.3333177778e+02,
content:'Saddle = 42.099998 pos = 35.3334,133.3318 diff = 238.699982'
});
data_peak.push({
lat: 3.5387888888e+01,
lng: 1.3330366667e+02,
cert : false,
content:' Peak = 256.500000 pos = 35.3879,133.3037 diff = 178.199997'
});
data_saddle.push({
lat: 3.5385555555e+01,
lng: 1.3331433333e+02,
content:'Saddle = 78.300003 pos = 35.3856,133.3143 diff = 178.199997'
});
data_peak.push({
lat: 3.5354888888e+01,
lng: 1.3334833333e+02,
cert : true,
content:'Name = JA/TT-049(JA/TT-049) peak = 331.000000 pos = 35.3549,133.3483 diff = 268.899994'
});
data_saddle.push({
lat: 3.5333444443e+01,
lng: 1.3336966667e+02,
content:'Saddle = 62.099998 pos = 35.3334,133.3697 diff = 268.899994'
});
data_peak.push({
lat: 3.5340111110e+01,
lng: 1.3341966667e+02,
cert : false,
content:' Peak = 300.700012 pos = 35.3401,133.4197 diff = 220.900009'
});
data_saddle.push({
lat: 3.5333444443e+01,
lng: 1.3343644444e+02,
content:'Saddle = 79.800003 pos = 35.3334,133.4364 diff = 220.900009'
});
data_peak.push({
lat: 3.5346999999e+01,
lng: 1.3399266667e+02,
cert : false,
content:' Peak = 1140.699951 pos = 35.3470,133.9927 diff = 987.999939'
});
data_saddle.push({
lat: 3.5333555555e+01,
lng: 1.3384011111e+02,
content:'Saddle = 152.699997 pos = 35.3336,133.8401 diff = 987.999939'
});
data_peak.push({
lat: 3.5428555555e+01,
lng: 1.3390888889e+02,
cert : true,
content:'Name = JA/TT-041(JA/TT-041) peak = 517.400024 pos = 35.4286,133.9089 diff = 300.100037'
});
data_saddle.push({
lat: 3.5427222221e+01,
lng: 1.3392233333e+02,
content:'Saddle = 217.300003 pos = 35.4272,133.9223 diff = 300.100037'
});
data_peak.push({
lat: 3.5456111110e+01,
lng: 1.3394800000e+02,
cert : true,
content:'Name = JA/TT-042(JA/TT-042) peak = 512.900024 pos = 35.4561,133.9480 diff = 176.500031'
});
data_saddle.push({
lat: 3.5444888888e+01,
lng: 1.3394966667e+02,
content:'Saddle = 336.399994 pos = 35.4449,133.9497 diff = 176.500031'
});
data_peak.push({
lat: 3.5421999999e+01,
lng: 1.3397244444e+02,
cert : true,
content:'Name = JA/TT-026(JA/TT-026) peak = 772.099976 pos = 35.4220,133.9724 diff = 235.399963'
});
data_saddle.push({
lat: 3.5415666666e+01,
lng: 1.3399388889e+02,
content:'Saddle = 536.700012 pos = 35.4157,133.9939 diff = 235.399963'
});
data_peak.push({
lat: 3.5391999999e+01,
lng: 1.3398866667e+02,
cert : true,
content:'Name = JA/TT-017(JA/TT-017) peak = 984.299988 pos = 35.3920,133.9887 diff = 410.799988'
});
data_saddle.push({
lat: 3.5380666666e+01,
lng: 1.3399977778e+02,
content:'Saddle = 573.500000 pos = 35.3807,133.9998 diff = 410.799988'
});
data_peak.push({
lat: 3.5333777777e+01,
lng: 1.3381977778e+02,
cert : false,
content:' Peak = 704.200012 pos = 35.3338,133.8198 diff = 491.000000'
});
data_saddle.push({
lat: 3.5333444443e+01,
lng: 1.3375222222e+02,
content:'Saddle = 213.199997 pos = 35.3334,133.7522 diff = 491.000000'
});
data_peak.push({
lat: 3.5437666666e+01,
lng: 1.3347922222e+02,
cert : true,
content:'Name = Kōreizan(JA/TT-028) peak = 750.799988 pos = 35.4377,133.4792 diff = 373.000000'
});
data_saddle.push({
lat: 3.5415777777e+01,
lng: 1.3349522222e+02,
content:'Saddle = 377.799988 pos = 35.4158,133.4952 diff = 373.000000'
});
data_peak.push({
lat: 3.5425999999e+01,
lng: 1.3348777778e+02,
cert : true,
content:'Name = JA/TT-038(JA/TT-038) peak = 604.099976 pos = 35.4260,133.4878 diff = 225.699982'
});
data_saddle.push({
lat: 3.5430777777e+01,
lng: 1.3348333333e+02,
content:'Saddle = 378.399994 pos = 35.4308,133.4833 diff = 225.699982'
});
data_peak.push({
lat: 3.5333444443e+01,
lng: 1.3369855556e+02,
cert : false,
content:' Peak = 842.599976 pos = 35.3334,133.6986 diff = 395.699982'
});
data_saddle.push({
lat: 3.5333444443e+01,
lng: 1.3368966667e+02,
content:'Saddle = 446.899994 pos = 35.3334,133.6897 diff = 395.699982'
});
data_peak.push({
lat: 3.5333444443e+01,
lng: 1.3370688889e+02,
cert : false,
content:' Peak = 784.299988 pos = 35.3334,133.7069 diff = 216.599976'
});
data_saddle.push({
lat: 3.5333444443e+01,
lng: 1.3370355556e+02,
content:'Saddle = 567.700012 pos = 35.3334,133.7036 diff = 216.599976'
});
data_peak.push({
lat: 3.5333444443e+01,
lng: 1.3368488889e+02,
cert : false,
content:' Peak = 721.500000 pos = 35.3334,133.6849 diff = 158.200012'
});
data_saddle.push({
lat: 3.5333444443e+01,
lng: 1.3368177778e+02,
content:'Saddle = 563.299988 pos = 35.3334,133.6818 diff = 158.200012'
});
data_peak.push({
lat: 3.5333444443e+01,
lng: 1.3365711111e+02,
cert : false,
content:' Peak = 921.799988 pos = 35.3334,133.6571 diff = 255.500000'
});
data_saddle.push({
lat: 3.5333666666e+01,
lng: 1.3364544444e+02,
content:'Saddle = 666.299988 pos = 35.3337,133.6454 diff = 255.500000'
});
data_peak.push({
lat: 3.5340888888e+01,
lng: 1.3361555556e+02,
cert : true,
content:'Name = JA/OY-008(JA/OY-008) peak = 1163.400024 pos = 35.3409,133.6156 diff = 278.000000'
});
data_saddle.push({
lat: 3.5343333332e+01,
lng: 1.3360333333e+02,
content:'Saddle = 885.400024 pos = 35.3433,133.6033 diff = 278.000000'
});
data_peak.push({
lat: 3.5340888888e+01,
lng: 1.3359455556e+02,
cert : false,
content:' Peak = 1110.699951 pos = 35.3409,133.5946 diff = 173.299927'
});
data_saddle.push({
lat: 3.5347999999e+01,
lng: 1.3359466667e+02,
content:'Saddle = 937.400024 pos = 35.3480,133.5947 diff = 173.299927'
});
data_peak.push({
lat: 3.5386777777e+01,
lng: 1.3358088889e+02,
cert : true,
content:'Name = Yahazugasen(JA/TT-003) peak = 1356.300049 pos = 35.3868,133.5809 diff = 245.300049'
});
data_saddle.push({
lat: 3.5382111110e+01,
lng: 1.3357111111e+02,
content:'Saddle = 1111.000000 pos = 35.3821,133.5711 diff = 245.300049'
});
data_peak.push({
lat: 3.5355888888e+01,
lng: 1.3357033333e+02,
cert : false,
content:' Peak = 1441.500000 pos = 35.3559,133.5703 diff = 209.300049'
});
data_saddle.push({
lat: 3.5363555555e+01,
lng: 1.3355888889e+02,
content:'Saddle = 1232.199951 pos = 35.3636,133.5589 diff = 209.300049'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:36.6667,
       south:35.3333,
       east:134,
       west:132}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
