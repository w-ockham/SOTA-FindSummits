function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 4.3663555556e+01,
lng: 1.4285400000e+02,
cert : true,
content:'Name = Taisetsuzan (Asahidake)(JA8/KK-001) peak = 2290.100098 pos = 43.6636,142.8540 diff = 2290.100098'
});
data_saddle.push({
lat: 4.3975222222e+01,
lng: 1.4162755556e+02,
content:'Saddle = 0.000000 pos = 43.9752,141.6276 diff = 2290.100098'
});
data_peak.push({
lat: 4.2833444445e+01,
lng: 1.4080688889e+02,
cert : false,
content:' Peak = 1708.199951 pos = 42.8334,140.8069 diff = 1688.699951'
});
data_saddle.push({
lat: 4.2818000000e+01,
lng: 1.4170077778e+02,
content:'Saddle = 19.500000 pos = 42.8180,141.7008 diff = 1688.699951'
});
data_peak.push({
lat: 4.2667555556e+01,
lng: 1.4000544444e+02,
cert : false,
content:' Peak = 321.600006 pos = 42.6676,140.0054 diff = 301.700012'
});
data_saddle.push({
lat: 4.2666777778e+01,
lng: 1.4002200000e+02,
content:'Saddle = 19.900000 pos = 42.6668,140.0220 diff = 301.700012'
});
data_peak.push({
lat: 4.2666777778e+01,
lng: 1.4012322222e+02,
cert : false,
content:' Peak = 773.900024 pos = 42.6668,140.1232 diff = 750.100037'
});
data_saddle.push({
lat: 4.2666777778e+01,
lng: 1.4031077778e+02,
content:'Saddle = 23.799999 pos = 42.6668,140.3108 diff = 750.100037'
});
data_peak.push({
lat: 4.2666777778e+01,
lng: 1.4004922222e+02,
cert : false,
content:' Peak = 390.299988 pos = 42.6668,140.0492 diff = 331.599976'
});
data_saddle.push({
lat: 4.2666888889e+01,
lng: 1.4008766667e+02,
content:'Saddle = 58.700001 pos = 42.6669,140.0877 diff = 331.599976'
});
data_peak.push({
lat: 4.2666777778e+01,
lng: 1.4023788889e+02,
cert : false,
content:' Peak = 310.799988 pos = 42.6668,140.2379 diff = 206.199982'
});
data_saddle.push({
lat: 4.2667666667e+01,
lng: 1.4022900000e+02,
content:'Saddle = 104.599998 pos = 42.6677,140.2290 diff = 206.199982'
});
data_peak.push({
lat: 4.2770222223e+01,
lng: 1.4021488889e+02,
cert : true,
content:'Name = Horodukiyama(JA8/SB-049) peak = 502.899994 pos = 42.7702,140.2149 diff = 367.399994'
});
data_saddle.push({
lat: 4.2666888889e+01,
lng: 1.4020344444e+02,
content:'Saddle = 135.500000 pos = 42.6669,140.2034 diff = 367.399994'
});
data_peak.push({
lat: 4.2671777778e+01,
lng: 1.4020922222e+02,
cert : false,
content:' Peak = 400.500000 pos = 42.6718,140.2092 diff = 158.500000'
});
data_saddle.push({
lat: 4.2702000001e+01,
lng: 1.4020611111e+02,
content:'Saddle = 242.000000 pos = 42.7020,140.2061 diff = 158.500000'
});
data_peak.push({
lat: 4.2677333334e+01,
lng: 1.4016622222e+02,
cert : true,
content:'Name = JA8/SB-048(JA8/SB-048) peak = 526.599976 pos = 42.6773,140.1662 diff = 344.299988'
});
data_saddle.push({
lat: 4.2666777778e+01,
lng: 1.4016933333e+02,
content:'Saddle = 182.300003 pos = 42.6668,140.1693 diff = 344.299988'
});
data_peak.push({
lat: 4.2699000001e+01,
lng: 1.4012966667e+02,
cert : true,
content:'Name = JA8/SB-051(JA8/SB-051) peak = 465.200012 pos = 42.6990,140.1297 diff = 172.700012'
});
data_saddle.push({
lat: 4.2697777778e+01,
lng: 1.4013511111e+02,
content:'Saddle = 292.500000 pos = 42.6978,140.1351 diff = 172.700012'
});
data_peak.push({
lat: 4.2669888889e+01,
lng: 1.4014455556e+02,
cert : false,
content:' Peak = 606.200012 pos = 42.6699,140.1446 diff = 296.900024'
});
data_saddle.push({
lat: 4.2666777778e+01,
lng: 1.4014033333e+02,
content:'Saddle = 309.299988 pos = 42.6668,140.1403 diff = 296.900024'
});
data_peak.push({
lat: 4.2666777778e+01,
lng: 1.4010922222e+02,
cert : false,
content:' Peak = 592.400024 pos = 42.6668,140.1092 diff = 158.600037'
});
data_saddle.push({
lat: 4.2666777778e+01,
lng: 1.4011222222e+02,
content:'Saddle = 433.799988 pos = 42.6668,140.1122 diff = 158.600037'
});
data_peak.push({
lat: 4.2781888889e+01,
lng: 1.4047233333e+02,
cert : true,
content:'Name = JA8/SB-055(JA8/SB-055) peak = 333.299988 pos = 42.7819,140.4723 diff = 254.099991'
});
data_saddle.push({
lat: 4.2767777778e+01,
lng: 1.4047466667e+02,
content:'Saddle = 79.199997 pos = 42.7678,140.4747 diff = 254.099991'
});
data_peak.push({
lat: 4.3225555556e+01,
lng: 1.4077255556e+02,
cert : false,
content:' Peak = 299.000000 pos = 43.2256,140.7726 diff = 205.699997'
});
data_saddle.push({
lat: 4.3225333334e+01,
lng: 1.4075900000e+02,
content:'Saddle = 93.300003 pos = 43.2253,140.7590 diff = 205.699997'
});
data_peak.push({
lat: 4.3232333334e+01,
lng: 1.4098188889e+02,
cert : true,
content:'Name = JA8/SB-054(JA8/SB-054) peak = 370.799988 pos = 43.2323,140.9819 diff = 259.500000'
});
data_saddle.push({
lat: 4.3219555556e+01,
lng: 1.4094922222e+02,
content:'Saddle = 111.300003 pos = 43.2196,140.9492 diff = 259.500000'
});
data_peak.push({
lat: 4.2762888889e+01,
lng: 1.4036266667e+02,
cert : true,
content:'Name = JA8/SB-025(JA8/SB-025) peak = 913.700012 pos = 42.7629,140.3627 diff = 707.000000'
});
data_saddle.push({
lat: 4.2666777778e+01,
lng: 1.4057622222e+02,
content:'Saddle = 206.699997 pos = 42.6668,140.5762 diff = 707.000000'
});
data_peak.push({
lat: 4.2700333334e+01,
lng: 1.4051044444e+02,
cert : true,
content:'Name = JA8/SB-030(JA8/SB-030) peak = 843.400024 pos = 42.7003,140.5104 diff = 631.600037'
});
data_saddle.push({
lat: 4.2704222223e+01,
lng: 1.4040655556e+02,
content:'Saddle = 211.800003 pos = 42.7042,140.4066 diff = 631.600037'
});
data_peak.push({
lat: 4.2773777778e+01,
lng: 1.4056511111e+02,
cert : true,
content:'Name = JA8/SB-046(JA8/SB-046) peak = 591.000000 pos = 42.7738,140.5651 diff = 223.100006'
});
data_saddle.push({
lat: 4.2765555556e+01,
lng: 1.4053888889e+02,
content:'Saddle = 367.899994 pos = 42.7656,140.5389 diff = 223.100006'
});
data_peak.push({
lat: 4.2972000000e+01,
lng: 1.4131477778e+02,
cert : true,
content:'Name = JA8/IS-032(JA8/IS-032) peak = 390.200012 pos = 42.9720,141.3148 diff = 173.200012'
});
data_saddle.push({
lat: 4.2976333334e+01,
lng: 1.4130000000e+02,
content:'Saddle = 217.000000 pos = 42.9763,141.3000 diff = 173.200012'
});
data_peak.push({
lat: 4.3283555556e+01,
lng: 1.4061844444e+02,
cert : true,
content:'Name = JA8/SB-053(JA8/SB-053) peak = 424.600006 pos = 43.2836,140.6184 diff = 184.200012'
});
data_saddle.push({
lat: 4.3269666667e+01,
lng: 1.4059777778e+02,
content:'Saddle = 240.399994 pos = 43.2697,140.5978 diff = 184.200012'
});
data_peak.push({
lat: 4.2875111112e+01,
lng: 1.4065888889e+02,
cert : true,
content:'Name = Nisekoannupuri(JA8/SB-005) peak = 1306.500000 pos = 42.8751,140.6589 diff = 1058.699951'
});
data_saddle.push({
lat: 4.2921888889e+01,
lng: 1.4071988889e+02,
content:'Saddle = 247.800003 pos = 42.9219,140.7199 diff = 1058.699951'
});
data_peak.push({
lat: 4.2899777778e+01,
lng: 1.4051522222e+02,
cert : true,
content:'Name = Mekunnaidake(JA8/SB-008) peak = 1218.500000 pos = 42.8998,140.5152 diff = 469.299988'
});
data_saddle.push({
lat: 4.2897777778e+01,
lng: 1.4054877778e+02,
content:'Saddle = 749.200012 pos = 42.8978,140.5488 diff = 469.299988'
});
data_peak.push({
lat: 4.2903666667e+01,
lng: 1.4046955556e+02,
cert : true,
content:'Name = Raidenyama(JA8/SB-009) peak = 1211.500000 pos = 42.9037,140.4696 diff = 247.700012'
});
data_saddle.push({
lat: 4.2910333334e+01,
lng: 1.4050888889e+02,
content:'Saddle = 963.799988 pos = 42.9103,140.5089 diff = 247.700012'
});
data_peak.push({
lat: 4.2888111112e+01,
lng: 1.4059677778e+02,
cert : true,
content:'Name = JA8/SB-011(JA8/SB-011) peak = 1133.500000 pos = 42.8881,140.5968 diff = 335.799988'
});
data_saddle.push({
lat: 4.2877222223e+01,
lng: 1.4064255556e+02,
content:'Saddle = 797.700012 pos = 42.8772,140.6426 diff = 335.799988'
});
data_peak.push({
lat: 4.2885333334e+01,
lng: 1.4064044444e+02,
cert : true,
content:'Name = JA8/SB-012(JA8/SB-012) peak = 1114.500000 pos = 42.8853,140.6404 diff = 282.099976'
});
data_saddle.push({
lat: 4.2889111112e+01,
lng: 1.4060833333e+02,
content:'Saddle = 832.400024 pos = 42.8891,140.6083 diff = 282.099976'
});
data_peak.push({
lat: 4.2908222223e+01,
lng: 1.4063344444e+02,
cert : true,
content:'Name = JA8/SB-018(JA8/SB-018) peak = 1044.599976 pos = 42.9082,140.6334 diff = 176.500000'
});
data_saddle.push({
lat: 4.2893666667e+01,
lng: 1.4062155556e+02,
content:'Saddle = 868.099976 pos = 42.8937,140.6216 diff = 176.500000'
});
data_peak.push({
lat: 4.2885222223e+01,
lng: 1.4061800000e+02,
cert : true,
content:'Name = JA8/SB-015(JA8/SB-015) peak = 1078.000000 pos = 42.8852,140.6180 diff = 199.900024'
});
data_saddle.push({
lat: 4.2883666667e+01,
lng: 1.4062500000e+02,
content:'Saddle = 878.099976 pos = 42.8837,140.6250 diff = 199.900024'
});
data_peak.push({
lat: 4.2889111112e+01,
lng: 1.4057733333e+02,
cert : true,
content:'Name = JA8/SB-016(JA8/SB-016) peak = 1073.699951 pos = 42.8891,140.5773 diff = 192.599976'
});
data_saddle.push({
lat: 4.2888777778e+01,
lng: 1.4058655556e+02,
content:'Saddle = 881.099976 pos = 42.8888,140.5866 diff = 192.599976'
});
data_peak.push({
lat: 4.2710444445e+01,
lng: 1.4065544444e+02,
cert : true,
content:'Name = Konbudake(JA8/SB-017) peak = 1043.599976 pos = 42.7104,140.6554 diff = 782.799988'
});
data_saddle.push({
lat: 4.2706555556e+01,
lng: 1.4079488889e+02,
content:'Saddle = 260.799988 pos = 42.7066,140.7949 diff = 782.799988'
});
data_peak.push({
lat: 4.2763777778e+01,
lng: 1.4072455556e+02,
cert : true,
content:'Name = JA8/SB-050(JA8/SB-050) peak = 501.200012 pos = 42.7638,140.7246 diff = 239.000000'
});
data_saddle.push({
lat: 4.2744444445e+01,
lng: 1.4072444444e+02,
content:'Saddle = 262.200012 pos = 42.7444,140.7244 diff = 239.000000'
});
data_peak.push({
lat: 4.3032777778e+01,
lng: 1.4101977778e+02,
cert : true,
content:'Name = Yoichidake(JA8/SB-003) peak = 1487.699951 pos = 43.0328,141.0198 diff = 1215.099976'
});
data_saddle.push({
lat: 4.2807444445e+01,
lng: 1.4087500000e+02,
content:'Saddle = 272.600006 pos = 42.8074,140.8750 diff = 1215.099976'
});
data_peak.push({
lat: 4.2954666667e+01,
lng: 1.4073355556e+02,
cert : true,
content:'Name = JA8/SB-052(JA8/SB-052) peak = 455.500000 pos = 42.9547,140.7336 diff = 162.200012'
});
data_saddle.push({
lat: 4.2972444445e+01,
lng: 1.4074822222e+02,
content:'Saddle = 293.299988 pos = 42.9724,140.7482 diff = 162.200012'
});
data_peak.push({
lat: 4.2753777778e+01,
lng: 1.4141311111e+02,
cert : true,
content:'Name = JA8/IR-026(JA8/IR-026) peak = 505.899994 pos = 42.7538,141.4131 diff = 205.600006'
});
data_saddle.push({
lat: 4.2748000001e+01,
lng: 1.4140977778e+02,
content:'Saddle = 300.299988 pos = 42.7480,141.4098 diff = 205.600006'
});
data_peak.push({
lat: 4.2765000000e+01,
lng: 1.4140600000e+02,
cert : true,
content:'Name = JA8/IS-030(JA8/IS-030) peak = 476.299988 pos = 42.7650,141.4060 diff = 175.299988'
});
data_saddle.push({
lat: 4.2759111112e+01,
lng: 1.4140333333e+02,
content:'Saddle = 301.000000 pos = 42.7591,141.4033 diff = 175.299988'
});
data_peak.push({
lat: 4.3022333334e+01,
lng: 1.4132211111e+02,
cert : true,
content:'Name = Moiwayama(JA8/IS-028) peak = 535.500000 pos = 43.0223,141.3221 diff = 228.700012'
});
data_saddle.push({
lat: 4.3019888889e+01,
lng: 1.4129311111e+02,
content:'Saddle = 306.799988 pos = 43.0199,141.2931 diff = 228.700012'
});
data_peak.push({
lat: 4.2892222223e+01,
lng: 1.4142200000e+02,
cert : true,
content:'Name = JA8/IS-029(JA8/IS-029) peak = 505.799988 pos = 42.8922,141.4220 diff = 184.399994'
});
data_saddle.push({
lat: 4.2888444445e+01,
lng: 1.4139577778e+02,
content:'Saddle = 321.399994 pos = 42.8884,141.3958 diff = 184.399994'
});
data_peak.push({
lat: 4.3214000000e+01,
lng: 1.4034633333e+02,
cert : false,
content:' Peak = 492.399994 pos = 43.2140,140.3463 diff = 161.600006'
});
data_saddle.push({
lat: 4.3215888889e+01,
lng: 1.4035055556e+02,
content:'Saddle = 330.799988 pos = 43.2159,140.3506 diff = 161.600006'
});
data_peak.push({
lat: 4.3107666667e+01,
lng: 1.4078633333e+02,
cert : false,
content:' Peak = 722.099976 pos = 43.1077,140.7863 diff = 378.099976'
});
data_saddle.push({
lat: 4.3118777778e+01,
lng: 1.4082244444e+02,
content:'Saddle = 344.000000 pos = 43.1188,140.8224 diff = 378.099976'
});
data_peak.push({
lat: 4.3094444445e+01,
lng: 1.4076422222e+02,
cert : false,
content:' Peak = 611.299988 pos = 43.0944,140.7642 diff = 153.500000'
});
data_saddle.push({
lat: 4.3098444445e+01,
lng: 1.4076666667e+02,
content:'Saddle = 457.799988 pos = 43.0984,140.7667 diff = 153.500000'
});
data_peak.push({
lat: 4.2893000000e+01,
lng: 1.4136911111e+02,
cert : true,
content:'Name = JA8/IS-027(JA8/IS-027) peak = 537.299988 pos = 42.8930,141.3691 diff = 172.099976'
});
data_saddle.push({
lat: 4.2877222223e+01,
lng: 1.4135788889e+02,
content:'Saddle = 365.200012 pos = 42.8772,141.3579 diff = 172.099976'
});
data_peak.push({
lat: 4.2938888889e+01,
lng: 1.4128777778e+02,
cert : true,
content:'Name = JA8/IS-026(JA8/IS-026) peak = 578.599976 pos = 42.9389,141.2878 diff = 200.799988'
});
data_saddle.push({
lat: 4.2932777778e+01,
lng: 1.4128844444e+02,
content:'Saddle = 377.799988 pos = 42.9328,141.2884 diff = 200.799988'
});
data_peak.push({
lat: 4.3260111111e+01,
lng: 1.4045911111e+02,
cert : true,
content:'Name = Yobetsudake(JA8/SB-006) peak = 1297.000000 pos = 43.2601,140.4591 diff = 902.799988'
});
data_saddle.push({
lat: 4.3055111111e+01,
lng: 1.4068655556e+02,
content:'Saddle = 394.200012 pos = 43.0551,140.6866 diff = 902.799988'
});
data_peak.push({
lat: 4.3078222223e+01,
lng: 1.4063122222e+02,
cert : true,
content:'Name = JA8/SB-023(JA8/SB-023) peak = 943.299988 pos = 43.0782,140.6312 diff = 479.899994'
});
data_saddle.push({
lat: 4.3175444445e+01,
lng: 1.4053133333e+02,
content:'Saddle = 463.399994 pos = 43.1754,140.5313 diff = 479.899994'
});
data_peak.push({
lat: 4.3109000000e+01,
lng: 1.4051388889e+02,
cert : true,
content:'Name = JA8/SB-043(JA8/SB-043) peak = 687.200012 pos = 43.1090,140.5139 diff = 159.700012'
});
data_saddle.push({
lat: 4.3115888889e+01,
lng: 1.4052211111e+02,
content:'Saddle = 527.500000 pos = 43.1159,140.5221 diff = 159.700012'
});
data_peak.push({
lat: 4.3157555556e+01,
lng: 1.4054666667e+02,
cert : true,
content:'Name = JA8/SB-034(JA8/SB-034) peak = 783.099976 pos = 43.1576,140.5467 diff = 241.199951'
});
data_saddle.push({
lat: 4.3147444445e+01,
lng: 1.4054877778e+02,
content:'Saddle = 541.900024 pos = 43.1474,140.5488 diff = 241.199951'
});
data_peak.push({
lat: 4.3143222223e+01,
lng: 1.4051022222e+02,
cert : true,
content:'Name = JA8/SB-041(JA8/SB-041) peak = 713.099976 pos = 43.1432,140.5102 diff = 155.199951'
});
data_saddle.push({
lat: 4.3146000000e+01,
lng: 1.4051277778e+02,
content:'Saddle = 557.900024 pos = 43.1460,140.5128 diff = 155.199951'
});
data_peak.push({
lat: 4.3184888889e+01,
lng: 1.4066077778e+02,
cert : true,
content:'Name = Tengudake(JA8/SB-028) peak = 871.599976 pos = 43.1849,140.6608 diff = 319.500000'
});
data_saddle.push({
lat: 4.3144222223e+01,
lng: 1.4065200000e+02,
content:'Saddle = 552.099976 pos = 43.1442,140.6520 diff = 319.500000'
});
data_peak.push({
lat: 4.3115555556e+01,
lng: 1.4056466667e+02,
cert : true,
content:'Name = JA8/SB-031(JA8/SB-031) peak = 823.599976 pos = 43.1156,140.5647 diff = 270.399963'
});
data_saddle.push({
lat: 4.3103333334e+01,
lng: 1.4058088889e+02,
content:'Saddle = 553.200012 pos = 43.1033,140.5809 diff = 270.399963'
});
data_peak.push({
lat: 4.3227000000e+01,
lng: 1.4037400000e+02,
cert : false,
content:' Peak = 777.799988 pos = 43.2270,140.3740 diff = 190.200012'
});
data_saddle.push({
lat: 4.3230555556e+01,
lng: 1.4037555556e+02,
content:'Saddle = 587.599976 pos = 43.2306,140.3756 diff = 190.200012'
});
data_peak.push({
lat: 4.3197222223e+01,
lng: 1.4053688889e+02,
cert : true,
content:'Name = JA8/SB-032(JA8/SB-032) peak = 800.200012 pos = 43.1972,140.5369 diff = 192.000000'
});
data_saddle.push({
lat: 4.3204444445e+01,
lng: 1.4053366667e+02,
content:'Saddle = 608.200012 pos = 43.2044,140.5337 diff = 192.000000'
});
data_peak.push({
lat: 4.3230555556e+01,
lng: 1.4053444444e+02,
cert : true,
content:'Name = JA8/SB-026(JA8/SB-026) peak = 903.400024 pos = 43.2306,140.5344 diff = 280.400024'
});
data_saddle.push({
lat: 4.3212666667e+01,
lng: 1.4051677778e+02,
content:'Saddle = 623.000000 pos = 43.2127,140.5168 diff = 280.400024'
});
data_peak.push({
lat: 4.3218333334e+01,
lng: 1.4047311111e+02,
cert : false,
content:' Peak = 882.400024 pos = 43.2183,140.4731 diff = 205.400024'
});
data_saddle.push({
lat: 4.3234555556e+01,
lng: 1.4047144444e+02,
content:'Saddle = 677.000000 pos = 43.2346,140.4714 diff = 205.400024'
});
data_peak.push({
lat: 4.3239333334e+01,
lng: 1.4037688889e+02,
cert : true,
content:'Name = JA8/SB-027(JA8/SB-027) peak = 894.799988 pos = 43.2393,140.3769 diff = 163.299988'
});
data_saddle.push({
lat: 4.3234444445e+01,
lng: 1.4039555556e+02,
content:'Saddle = 731.500000 pos = 43.2344,140.3956 diff = 163.299988'
});
data_peak.push({
lat: 4.3234000000e+01,
lng: 1.4041177778e+02,
cert : true,
content:'Name = JA8/SB-014(JA8/SB-014) peak = 1090.699951 pos = 43.2340,140.4118 diff = 327.499939'
});
data_saddle.push({
lat: 4.3235888889e+01,
lng: 1.4045000000e+02,
content:'Saddle = 763.200012 pos = 43.2359,140.4500 diff = 327.499939'
});
data_peak.push({
lat: 4.3192777778e+01,
lng: 1.4041022222e+02,
cert : true,
content:'Name = JA8/SB-021(JA8/SB-021) peak = 1007.700012 pos = 43.1928,140.4102 diff = 160.000000'
});
data_saddle.push({
lat: 4.3208555556e+01,
lng: 1.4042111111e+02,
content:'Saddle = 847.700012 pos = 43.2086,140.4211 diff = 160.000000'
});
data_peak.push({
lat: 4.3270666667e+01,
lng: 1.4048033333e+02,
cert : true,
content:'Name = JA8/SB-007(JA8/SB-007) peak = 1254.300049 pos = 43.2707,140.4803 diff = 217.100098'
});
data_saddle.push({
lat: 4.3262888889e+01,
lng: 1.4046677778e+02,
content:'Saddle = 1037.199951 pos = 43.2629,140.4668 diff = 217.100098'
});
data_peak.push({
lat: 4.2772666667e+01,
lng: 1.4091033333e+02,
cert : true,
content:'Name = Shiribetsudake(JA8/SB-013) peak = 1106.099976 pos = 42.7727,140.9103 diff = 695.099976'
});
data_saddle.push({
lat: 4.2749333334e+01,
lng: 1.4090377778e+02,
content:'Saddle = 411.000000 pos = 42.7493,140.9038 diff = 695.099976'
});
data_peak.push({
lat: 4.3178777778e+01,
lng: 1.4092233333e+02,
cert : true,
content:'Name = JA8/SB-045(JA8/SB-045) peak = 623.599976 pos = 43.1788,140.9223 diff = 184.999969'
});
data_saddle.push({
lat: 4.3173666667e+01,
lng: 1.4092577778e+02,
content:'Saddle = 438.600006 pos = 43.1737,140.9258 diff = 184.999969'
});
data_peak.push({
lat: 4.2794000000e+01,
lng: 1.4139400000e+02,
cert : true,
content:'Name = JA8/IS-013(JA8/IS-013) peak = 863.799988 pos = 42.7940,141.3940 diff = 405.799988'
});
data_saddle.push({
lat: 4.2807333334e+01,
lng: 1.4134855556e+02,
content:'Saddle = 458.000000 pos = 42.8073,141.3486 diff = 405.799988'
});
data_peak.push({
lat: 4.2925444445e+01,
lng: 1.4129822222e+02,
cert : true,
content:'Name = JA8/IS-024(JA8/IS-024) peak = 650.799988 pos = 42.9254,141.2982 diff = 178.000000'
});
data_saddle.push({
lat: 4.2921888889e+01,
lng: 1.4129288889e+02,
content:'Saddle = 472.799988 pos = 42.9219,141.2929 diff = 178.000000'
});
data_peak.push({
lat: 4.2937666667e+01,
lng: 1.4127255556e+02,
cert : true,
content:'Name = JA8/IS-022(JA8/IS-022) peak = 662.099976 pos = 42.9377,141.2726 diff = 189.299988'
});
data_saddle.push({
lat: 4.2934000000e+01,
lng: 1.4127433333e+02,
content:'Saddle = 472.799988 pos = 42.9340,141.2743 diff = 189.299988'
});
data_peak.push({
lat: 4.2677666667e+01,
lng: 1.4087333333e+02,
cert : true,
content:'Name = JA8/IR-018(JA8/IR-018) peak = 653.099976 pos = 42.6777,140.8733 diff = 176.999969'
});
data_saddle.push({
lat: 4.2673444445e+01,
lng: 1.4089800000e+02,
content:'Saddle = 476.100006 pos = 42.6734,140.8980 diff = 176.999969'
});
data_peak.push({
lat: 4.2716888889e+01,
lng: 1.4135888889e+02,
cert : true,
content:'Name = Fuppushidake(JA8/IS-009) peak = 1101.599976 pos = 42.7169,141.3589 diff = 624.799988'
});
data_saddle.push({
lat: 4.2699666667e+01,
lng: 1.4123433333e+02,
content:'Saddle = 476.799988 pos = 42.6997,141.2343 diff = 624.799988'
});
data_peak.push({
lat: 4.2694000001e+01,
lng: 1.4129711111e+02,
cert : true,
content:'Name = JA8/IR-017(JA8/IR-017) peak = 660.700012 pos = 42.6940,141.2971 diff = 169.400024'
});
data_saddle.push({
lat: 4.2689666667e+01,
lng: 1.4130366667e+02,
content:'Saddle = 491.299988 pos = 42.6897,141.3037 diff = 169.400024'
});
data_peak.push({
lat: 4.2690555556e+01,
lng: 1.4137666667e+02,
cert : true,
content:'Name = Tarumaesan(JA8/IR-003) peak = 1040.599976 pos = 42.6906,141.3767 diff = 254.699951'
});
data_saddle.push({
lat: 4.2705222223e+01,
lng: 1.4136533333e+02,
content:'Saddle = 785.900024 pos = 42.7052,141.3653 diff = 254.699951'
});
data_peak.push({
lat: 4.3012555556e+01,
lng: 1.4077100000e+02,
cert : true,
content:'Name = JA8/SB-042(JA8/SB-042) peak = 710.299988 pos = 43.0126,140.7710 diff = 231.899994'
});
data_saddle.push({
lat: 4.3008222223e+01,
lng: 1.4079955556e+02,
content:'Saddle = 478.399994 pos = 43.0082,140.7996 diff = 231.899994'
});
data_peak.push({
lat: 4.3001000000e+01,
lng: 1.4075000000e+02,
cert : false,
content:' Peak = 673.500000 pos = 43.0010,140.7500 diff = 156.099976'
});
data_saddle.push({
lat: 4.3012222223e+01,
lng: 1.4075811111e+02,
content:'Saddle = 517.400024 pos = 43.0122,140.7581 diff = 156.099976'
});
data_peak.push({
lat: 4.2710111112e+01,
lng: 1.4092266667e+02,
cert : true,
content:'Name = Nukkibetsuyama(JA8/SB-022) peak = 992.799988 pos = 42.7101,140.9227 diff = 438.700012'
});
data_saddle.push({
lat: 4.2666777778e+01,
lng: 1.4101144444e+02,
content:'Saddle = 554.099976 pos = 42.6668,141.0114 diff = 438.700012'
});
data_peak.push({
lat: 4.2690777778e+01,
lng: 1.4094588889e+02,
cert : true,
content:'Name = JA8/SB-024(JA8/SB-024) peak = 932.000000 pos = 42.6908,140.9459 diff = 184.400024'
});
data_saddle.push({
lat: 4.2701444445e+01,
lng: 1.4093555556e+02,
content:'Saddle = 747.599976 pos = 42.7014,140.9356 diff = 184.400024'
});
data_peak.push({
lat: 4.2670333334e+01,
lng: 1.4103988889e+02,
cert : false,
content:' Peak = 842.299988 pos = 42.6703,141.0399 diff = 280.399963'
});
data_saddle.push({
lat: 4.2702888889e+01,
lng: 1.4108633333e+02,
content:'Saddle = 561.900024 pos = 42.7029,141.0863 diff = 280.399963'
});
data_peak.push({
lat: 4.2824444445e+01,
lng: 1.4134577778e+02,
cert : true,
content:'Name = JA8/IS-014(JA8/IS-014) peak = 824.599976 pos = 42.8244,141.3458 diff = 258.199951'
});
data_saddle.push({
lat: 4.2811000000e+01,
lng: 1.4128900000e+02,
content:'Saddle = 566.400024 pos = 42.8110,141.2890 diff = 258.199951'
});
data_peak.push({
lat: 4.2812555556e+01,
lng: 1.4131566667e+02,
cert : true,
content:'Name = JA8/IS-017(JA8/IS-017) peak = 721.900024 pos = 42.8126,141.3157 diff = 154.600037'
});
data_saddle.push({
lat: 4.2812444445e+01,
lng: 1.4132733333e+02,
content:'Saddle = 567.299988 pos = 42.8124,141.3273 diff = 154.600037'
});
data_peak.push({
lat: 4.3151666667e+01,
lng: 1.4092344444e+02,
cert : true,
content:'Name = JA8/SB-039(JA8/SB-039) peak = 734.799988 pos = 43.1517,140.9234 diff = 161.200012'
});
data_saddle.push({
lat: 4.3135666667e+01,
lng: 1.4092100000e+02,
content:'Saddle = 573.599976 pos = 43.1357,140.9210 diff = 161.200012'
});
data_peak.push({
lat: 4.2995000000e+01,
lng: 1.4083733333e+02,
cert : true,
content:'Name = JA8/SB-033(JA8/SB-033) peak = 792.900024 pos = 42.9950,140.8373 diff = 205.600037'
});
data_saddle.push({
lat: 4.2985333334e+01,
lng: 1.4085288889e+02,
content:'Saddle = 587.299988 pos = 42.9853,140.8529 diff = 205.600037'
});
data_peak.push({
lat: 4.2683555556e+01,
lng: 1.4118300000e+02,
cert : true,
content:'Name = JA8/IR-006(JA8/IR-006) peak = 966.500000 pos = 42.6836,141.1830 diff = 349.099976'
});
data_saddle.push({
lat: 4.2708111112e+01,
lng: 1.4118622222e+02,
content:'Saddle = 617.400024 pos = 42.7081,141.1862 diff = 349.099976'
});
data_peak.push({
lat: 4.2679444445e+01,
lng: 1.4117155556e+02,
cert : true,
content:'Name = JA8/IR-007(JA8/IR-007) peak = 943.099976 pos = 42.6794,141.1716 diff = 151.399963'
});
data_saddle.push({
lat: 4.2681888889e+01,
lng: 1.4117566667e+02,
content:'Saddle = 791.700012 pos = 42.6819,141.1757 diff = 151.399963'
});
data_peak.push({
lat: 4.3012000000e+01,
lng: 1.4118466667e+02,
cert : true,
content:'Name = JA8/IS-008(JA8/IS-008) peak = 1108.599976 pos = 43.0120,141.1847 diff = 455.599976'
});
data_saddle.push({
lat: 4.3108666667e+01,
lng: 1.4112388889e+02,
content:'Saddle = 653.000000 pos = 43.1087,141.1239 diff = 455.599976'
});
data_peak.push({
lat: 4.2997555556e+01,
lng: 1.4125888889e+02,
cert : false,
content:' Peak = 825.599976 pos = 42.9976,141.2589 diff = 171.699951'
});
data_saddle.push({
lat: 4.3008444445e+01,
lng: 1.4122622222e+02,
content:'Saddle = 653.900024 pos = 43.0084,141.2262 diff = 171.699951'
});
data_peak.push({
lat: 4.3076777778e+01,
lng: 1.4119255556e+02,
cert : false,
content:' Peak = 1023.000000 pos = 43.0768,141.1926 diff = 250.900024'
});
data_saddle.push({
lat: 4.3036777778e+01,
lng: 1.4118566667e+02,
content:'Saddle = 772.099976 pos = 43.0368,141.1857 diff = 250.900024'
});
data_peak.push({
lat: 4.2793333334e+01,
lng: 1.4128533333e+02,
cert : true,
content:'Name = Eniwadake(JA8/IS-004) peak = 1319.000000 pos = 42.7933,141.2853 diff = 652.099976'
});
data_saddle.push({
lat: 4.2806000000e+01,
lng: 1.4127522222e+02,
content:'Saddle = 666.900024 pos = 42.8060,141.2752 diff = 652.099976'
});
data_peak.push({
lat: 4.3113666667e+01,
lng: 1.4110366667e+02,
cert : true,
content:'Name = JA8/IS-012(JA8/IS-012) peak = 906.400024 pos = 43.1137,141.1037 diff = 189.300049'
});
data_saddle.push({
lat: 4.3091777778e+01,
lng: 1.4106922222e+02,
content:'Saddle = 717.099976 pos = 43.0918,141.0692 diff = 189.300049'
});
data_peak.push({
lat: 4.2955222223e+01,
lng: 1.4091300000e+02,
cert : true,
content:'Name = Ponkutosan(JA8/SB-020) peak = 1007.000000 pos = 42.9552,140.9130 diff = 244.500000'
});
data_saddle.push({
lat: 4.2977222223e+01,
lng: 1.4095077778e+02,
content:'Saddle = 762.500000 pos = 42.9772,140.9508 diff = 244.500000'
});
data_peak.push({
lat: 4.2826444445e+01,
lng: 1.4123555556e+02,
cert : true,
content:'Name = JA8/IS-003(JA8/IS-003) peak = 1326.599976 pos = 42.8264,141.2356 diff = 503.099976'
});
data_saddle.push({
lat: 4.2783555556e+01,
lng: 1.4115733333e+02,
content:'Saddle = 823.500000 pos = 42.7836,141.1573 diff = 503.099976'
});
data_peak.push({
lat: 4.2900333334e+01,
lng: 1.4120022222e+02,
cert : true,
content:'Name = Sapporodake(JA8/IS-006) peak = 1291.800049 pos = 42.9003,141.2002 diff = 256.100098'
});
data_saddle.push({
lat: 4.2890888889e+01,
lng: 1.4122155556e+02,
content:'Saddle = 1035.699951 pos = 42.8909,141.2216 diff = 256.100098'
});
data_peak.push({
lat: 4.2877222223e+01,
lng: 1.4120533333e+02,
cert : true,
content:'Name = JA8/IS-005(JA8/IS-005) peak = 1290.199951 pos = 42.8772,141.2053 diff = 237.099976'
});
data_saddle.push({
lat: 4.2839000000e+01,
lng: 1.4124188889e+02,
content:'Saddle = 1053.099976 pos = 42.8390,141.2419 diff = 237.099976'
});
data_peak.push({
lat: 4.2865111112e+01,
lng: 1.4125355556e+02,
cert : false,
content:' Peak = 1250.599976 pos = 42.8651,141.2536 diff = 158.599976'
});
data_saddle.push({
lat: 4.2880222223e+01,
lng: 1.4122422222e+02,
content:'Saddle = 1092.000000 pos = 42.8802,141.2242 diff = 158.599976'
});
data_peak.push({
lat: 4.2808333334e+01,
lng: 1.4111266667e+02,
cert : true,
content:'Name = JA8/IR-004(JA8/IR-004) peak = 1035.000000 pos = 42.8083,141.1127 diff = 202.099976'
});
data_saddle.push({
lat: 4.2856555556e+01,
lng: 1.4109766667e+02,
content:'Saddle = 832.900024 pos = 42.8566,141.0977 diff = 202.099976'
});
data_peak.push({
lat: 4.3010777778e+01,
lng: 1.4110855556e+02,
cert : true,
content:'Name = JA8/IS-007(JA8/IS-007) peak = 1138.800049 pos = 43.0108,141.1086 diff = 270.300049'
});
data_saddle.push({
lat: 4.3024555556e+01,
lng: 1.4109944444e+02,
content:'Saddle = 868.500000 pos = 43.0246,141.0994 diff = 270.300049'
});
data_peak.push({
lat: 4.3029333334e+01,
lng: 1.4109377778e+02,
cert : false,
content:' Peak = 1081.900024 pos = 43.0293,141.0938 diff = 179.000000'
});
data_saddle.push({
lat: 4.3032555556e+01,
lng: 1.4108888889e+02,
content:'Saddle = 902.900024 pos = 43.0326,141.0889 diff = 179.000000'
});
data_peak.push({
lat: 4.2930777778e+01,
lng: 1.4104055556e+02,
cert : true,
content:'Name = Muineyama(JA8/SB-004) peak = 1462.699951 pos = 42.9308,141.0406 diff = 500.099976'
});
data_saddle.push({
lat: 4.2971111112e+01,
lng: 1.4100855556e+02,
content:'Saddle = 962.599976 pos = 42.9711,141.0086 diff = 500.099976'
});
data_peak.push({
lat: 4.2989444445e+01,
lng: 1.4174666667e+02,
cert : true,
content:'Name = JA8/SC-066(JA8/SC-066) peak = 284.799988 pos = 42.9894,141.7467 diff = 228.999985'
});
data_saddle.push({
lat: 4.2930000000e+01,
lng: 1.4181788889e+02,
content:'Saddle = 55.799999 pos = 42.9300,141.8179 diff = 228.999985'
});
data_peak.push({
lat: 4.3301111111e+01,
lng: 1.4158155556e+02,
cert : true,
content:'Name = JA8/IS-034(JA8/IS-034) peak = 308.700012 pos = 43.3011,141.5816 diff = 226.500015'
});
data_saddle.push({
lat: 4.3330888889e+01,
lng: 1.4158588889e+02,
content:'Saddle = 82.199997 pos = 43.3309,141.5859 diff = 226.500015'
});
data_peak.push({
lat: 4.3715888889e+01,
lng: 1.4152288889e+02,
cert : true,
content:'Name = Shokanbetsudake(JA8/RM-001) peak = 1490.800049 pos = 43.7159,141.5229 diff = 1389.100098'
});
data_saddle.push({
lat: 4.3858000000e+01,
lng: 1.4186000000e+02,
content:'Saddle = 101.699997 pos = 43.8580,141.8600 diff = 1389.100098'
});
data_peak.push({
lat: 4.3830444445e+01,
lng: 1.4179466667e+02,
cert : true,
content:'Name = JA8/RM-021(JA8/RM-021) peak = 321.100006 pos = 43.8304,141.7947 diff = 179.900009'
});
data_saddle.push({
lat: 4.3786666667e+01,
lng: 1.4177533333e+02,
content:'Saddle = 141.199997 pos = 43.7867,141.7753 diff = 179.900009'
});
data_peak.push({
lat: 4.3865444444e+01,
lng: 1.4170066667e+02,
cert : true,
content:'Name = JA8/RM-020(JA8/RM-020) peak = 350.500000 pos = 43.8654,141.7007 diff = 199.100006'
});
data_saddle.push({
lat: 4.3857000000e+01,
lng: 1.4168622222e+02,
content:'Saddle = 151.399994 pos = 43.8570,141.6862 diff = 199.100006'
});
data_peak.push({
lat: 4.3308000000e+01,
lng: 1.4152066667e+02,
cert : true,
content:'Name = JA8/IS-031(JA8/IS-031) peak = 416.700012 pos = 43.3080,141.5207 diff = 243.700012'
});
data_saddle.push({
lat: 4.3379111111e+01,
lng: 1.4154111111e+02,
content:'Saddle = 173.000000 pos = 43.3791,141.5411 diff = 243.700012'
});
data_peak.push({
lat: 4.3589444445e+01,
lng: 1.4153577778e+02,
cert : true,
content:'Name = JA8/IS-033(JA8/IS-033) peak = 381.700012 pos = 43.5894,141.5358 diff = 200.100006'
});
data_saddle.push({
lat: 4.3579111111e+01,
lng: 1.4155200000e+02,
content:'Saddle = 181.600006 pos = 43.5791,141.5520 diff = 200.100006'
});
data_peak.push({
lat: 4.3760222222e+01,
lng: 1.4174022222e+02,
cert : true,
content:'Name = JA8/SC-061(JA8/SC-061) peak = 413.299988 pos = 43.7602,141.7402 diff = 196.199982'
});
data_saddle.push({
lat: 4.3751888889e+01,
lng: 1.4172744444e+02,
content:'Saddle = 217.100006 pos = 43.7519,141.7274 diff = 196.199982'
});
data_peak.push({
lat: 4.3534444445e+01,
lng: 1.4152466667e+02,
cert : false,
content:' Peak = 724.500000 pos = 43.5344,141.5247 diff = 478.299988'
});
data_saddle.push({
lat: 4.3562222222e+01,
lng: 1.4155955556e+02,
content:'Saddle = 246.199997 pos = 43.5622,141.5596 diff = 478.299988'
});
data_peak.push({
lat: 4.3541555556e+01,
lng: 1.4156300000e+02,
cert : false,
content:' Peak = 421.299988 pos = 43.5416,141.5630 diff = 160.500000'
});
data_saddle.push({
lat: 4.3552555556e+01,
lng: 1.4155955556e+02,
content:'Saddle = 260.799988 pos = 43.5526,141.5596 diff = 160.500000'
});
data_peak.push({
lat: 4.3457333334e+01,
lng: 1.4144533333e+02,
cert : true,
content:'Name = JA8/IS-023(JA8/IS-023) peak = 653.599976 pos = 43.4573,141.4453 diff = 321.499969'
});
data_saddle.push({
lat: 4.3497777778e+01,
lng: 1.4144577778e+02,
content:'Saddle = 332.100006 pos = 43.4978,141.4458 diff = 321.499969'
});
data_peak.push({
lat: 4.3520777778e+01,
lng: 1.4142700000e+02,
cert : true,
content:'Name = JA8/IS-018(JA8/IS-018) peak = 692.299988 pos = 43.5208,141.4270 diff = 319.599976'
});
data_saddle.push({
lat: 4.3566000000e+01,
lng: 1.4148777778e+02,
content:'Saddle = 372.700012 pos = 43.5660,141.4878 diff = 319.599976'
});
data_peak.push({
lat: 4.3515777778e+01,
lng: 1.4147188889e+02,
cert : true,
content:'Name = JA8/IS-019(JA8/IS-019) peak = 690.299988 pos = 43.5158,141.4719 diff = 308.799988'
});
data_saddle.push({
lat: 4.3529333334e+01,
lng: 1.4144722222e+02,
content:'Saddle = 381.500000 pos = 43.5293,141.4472 diff = 308.799988'
});
data_peak.push({
lat: 4.3536888889e+01,
lng: 1.4148188889e+02,
cert : true,
content:'Name = JA8/IS-021(JA8/IS-021) peak = 663.200012 pos = 43.5369,141.4819 diff = 172.200012'
});
data_saddle.push({
lat: 4.3528666667e+01,
lng: 1.4147777778e+02,
content:'Saddle = 491.000000 pos = 43.5287,141.4778 diff = 172.200012'
});
data_peak.push({
lat: 4.3480111111e+01,
lng: 1.4155588889e+02,
cert : false,
content:' Peak = 672.400024 pos = 43.4801,141.5559 diff = 232.100037'
});
data_saddle.push({
lat: 4.3507222222e+01,
lng: 1.4153888889e+02,
content:'Saddle = 440.299988 pos = 43.5072,141.5389 diff = 232.100037'
});
data_peak.push({
lat: 4.3617000000e+01,
lng: 1.4173755556e+02,
cert : true,
content:'Name = JA8/SC-058(JA8/SC-058) peak = 501.899994 pos = 43.6170,141.7376 diff = 229.199982'
});
data_saddle.push({
lat: 4.3630333333e+01,
lng: 1.4172444444e+02,
content:'Saddle = 272.700012 pos = 43.6303,141.7244 diff = 229.199982'
});
data_peak.push({
lat: 4.3491888889e+01,
lng: 1.4170666667e+02,
cert : true,
content:'Name = Pinneshiri(JA8/SC-007) peak = 1100.199951 pos = 43.4919,141.7067 diff = 819.199951'
});
data_saddle.push({
lat: 4.3543222222e+01,
lng: 1.4162344444e+02,
content:'Saddle = 281.000000 pos = 43.5432,141.6234 diff = 819.199951'
});
data_peak.push({
lat: 4.3550777778e+01,
lng: 1.4171444444e+02,
cert : true,
content:'Name = JA8/SC-040(JA8/SC-040) peak = 682.299988 pos = 43.5508,141.7144 diff = 260.899994'
});
data_saddle.push({
lat: 4.3530000000e+01,
lng: 1.4170944444e+02,
content:'Saddle = 421.399994 pos = 43.5300,141.7094 diff = 260.899994'
});
data_peak.push({
lat: 4.3459666667e+01,
lng: 1.4166788889e+02,
cert : true,
content:'Name = JA8/IS-025(JA8/IS-025) peak = 596.400024 pos = 43.4597,141.6679 diff = 173.900024'
});
data_saddle.push({
lat: 4.3466000000e+01,
lng: 1.4167311111e+02,
content:'Saddle = 422.500000 pos = 43.4660,141.6731 diff = 173.900024'
});
data_peak.push({
lat: 4.3526666667e+01,
lng: 1.4169511111e+02,
cert : false,
content:' Peak = 664.200012 pos = 43.5267,141.6951 diff = 152.300018'
});
data_saddle.push({
lat: 4.3507555556e+01,
lng: 1.4169022222e+02,
content:'Saddle = 511.899994 pos = 43.5076,141.6902 diff = 152.300018'
});
data_peak.push({
lat: 4.3521777778e+01,
lng: 1.4173333333e+02,
cert : true,
content:'Name = JA8/SC-029(JA8/SC-029) peak = 791.299988 pos = 43.5218,141.7333 diff = 207.700012'
});
data_saddle.push({
lat: 4.3504555556e+01,
lng: 1.4171966667e+02,
content:'Saddle = 583.599976 pos = 43.5046,141.7197 diff = 207.700012'
});
data_peak.push({
lat: 4.3500333334e+01,
lng: 1.4166244444e+02,
cert : true,
content:'Name = JA8/IS-011(JA8/IS-011) peak = 940.099976 pos = 43.5003,141.6624 diff = 321.099976'
});
data_saddle.push({
lat: 4.3498222222e+01,
lng: 1.4169144444e+02,
content:'Saddle = 619.000000 pos = 43.4982,141.6914 diff = 321.099976'
});
data_peak.push({
lat: 4.3459555556e+01,
lng: 1.4172188889e+02,
cert : true,
content:'Name = JA8/SC-012(JA8/SC-012) peak = 970.299988 pos = 43.4596,141.7219 diff = 295.799988'
});
data_saddle.push({
lat: 4.3475333334e+01,
lng: 1.4172500000e+02,
content:'Saddle = 674.500000 pos = 43.4753,141.7250 diff = 295.799988'
});
data_peak.push({
lat: 4.3760222222e+01,
lng: 1.4171000000e+02,
cert : false,
content:' Peak = 574.099976 pos = 43.7602,141.7100 diff = 261.999969'
});
data_saddle.push({
lat: 4.3747111111e+01,
lng: 1.4169155556e+02,
content:'Saddle = 312.100006 pos = 43.7471,141.6916 diff = 261.999969'
});
data_peak.push({
lat: 4.3795333333e+01,
lng: 1.4171877778e+02,
cert : true,
content:'Name = JA8/SC-059(JA8/SC-059) peak = 490.500000 pos = 43.7953,141.7188 diff = 162.500000'
});
data_saddle.push({
lat: 4.3775000000e+01,
lng: 1.4169766667e+02,
content:'Saddle = 328.000000 pos = 43.7750,141.6977 diff = 162.500000'
});
data_peak.push({
lat: 4.3624111111e+01,
lng: 1.4147311111e+02,
cert : true,
content:'Name = JA8/IS-015(JA8/IS-015) peak = 737.700012 pos = 43.6241,141.4731 diff = 306.000000'
});
data_saddle.push({
lat: 4.3630222222e+01,
lng: 1.4147211111e+02,
content:'Saddle = 431.700012 pos = 43.6302,141.4721 diff = 306.000000'
});
data_peak.push({
lat: 4.3611444445e+01,
lng: 1.4165277778e+02,
cert : true,
content:'Name = JA8/SC-044(JA8/SC-044) peak = 633.799988 pos = 43.6114,141.6528 diff = 170.299988'
});
data_saddle.push({
lat: 4.3623555556e+01,
lng: 1.4163277778e+02,
content:'Saddle = 463.500000 pos = 43.6236,141.6328 diff = 170.299988'
});
data_peak.push({
lat: 4.3614888889e+01,
lng: 1.4162788889e+02,
cert : true,
content:'Name = JA8/SC-045(JA8/SC-045) peak = 624.000000 pos = 43.6149,141.6279 diff = 152.000000'
});
data_saddle.push({
lat: 4.3619000000e+01,
lng: 1.4163522222e+02,
content:'Saddle = 472.000000 pos = 43.6190,141.6352 diff = 152.000000'
});
data_peak.push({
lat: 4.3666666667e+01,
lng: 1.4170800000e+02,
cert : true,
content:'Name = JA8/SC-037(JA8/SC-037) peak = 734.299988 pos = 43.6667,141.7080 diff = 192.799988'
});
data_saddle.push({
lat: 4.3662555556e+01,
lng: 1.4169133333e+02,
content:'Saddle = 541.500000 pos = 43.6626,141.6913 diff = 192.799988'
});
data_peak.push({
lat: 4.3654666667e+01,
lng: 1.4165433333e+02,
cert : false,
content:' Peak = 840.000000 pos = 43.6547,141.6543 diff = 211.299988'
});
data_saddle.push({
lat: 4.3652222222e+01,
lng: 1.4164488889e+02,
content:'Saddle = 628.700012 pos = 43.6522,141.6449 diff = 211.299988'
});
data_peak.push({
lat: 4.3776444445e+01,
lng: 1.4141588889e+02,
cert : true,
content:'Name = JA8/RM-005(JA8/RM-005) peak = 971.900024 pos = 43.7764,141.4159 diff = 328.800049'
});
data_saddle.push({
lat: 4.3763333333e+01,
lng: 1.4141811111e+02,
content:'Saddle = 643.099976 pos = 43.7633,141.4181 diff = 328.800049'
});
data_peak.push({
lat: 4.3754333333e+01,
lng: 1.4162277778e+02,
cert : true,
content:'Name = JA8/SC-013(JA8/SC-013) peak = 968.500000 pos = 43.7543,141.6228 diff = 274.799988'
});
data_saddle.push({
lat: 4.3741111111e+01,
lng: 1.4159788889e+02,
content:'Saddle = 693.700012 pos = 43.7411,141.5979 diff = 274.799988'
});
data_peak.push({
lat: 4.3646777778e+01,
lng: 1.4163355556e+02,
cert : true,
content:'Name = JA8/SC-015(JA8/SC-015) peak = 925.500000 pos = 43.6468,141.6336 diff = 179.799988'
});
data_saddle.push({
lat: 4.3673000000e+01,
lng: 1.4159277778e+02,
content:'Saddle = 745.700012 pos = 43.6730,141.5928 diff = 179.799988'
});
data_peak.push({
lat: 4.3647555556e+01,
lng: 1.4152666667e+02,
cert : false,
content:' Peak = 983.799988 pos = 43.6476,141.5267 diff = 162.200012'
});
data_saddle.push({
lat: 4.3662777778e+01,
lng: 1.4151744444e+02,
content:'Saddle = 821.599976 pos = 43.6628,141.5174 diff = 162.200012'
});
data_peak.push({
lat: 4.3737777778e+01,
lng: 1.4140577778e+02,
cert : true,
content:'Name = JA8/RM-003(JA8/RM-003) peak = 1198.500000 pos = 43.7378,141.4058 diff = 341.299988'
});
data_saddle.push({
lat: 4.3718222222e+01,
lng: 1.4141277778e+02,
content:'Saddle = 857.200012 pos = 43.7182,141.4128 diff = 341.299988'
});
data_peak.push({
lat: 4.3719555556e+01,
lng: 1.4164422222e+02,
cert : true,
content:'Name = JA8/SC-009(JA8/SC-009) peak = 1065.199951 pos = 43.7196,141.6442 diff = 201.899963'
});
data_saddle.push({
lat: 4.3705111111e+01,
lng: 1.4159366667e+02,
content:'Saddle = 863.299988 pos = 43.7051,141.5937 diff = 201.899963'
});
data_peak.push({
lat: 4.3703888889e+01,
lng: 1.4143877778e+02,
cert : true,
content:'Name = JA8/RM-002(JA8/RM-002) peak = 1253.199951 pos = 43.7039,141.4388 diff = 300.099976'
});
data_saddle.push({
lat: 4.3698000000e+01,
lng: 1.4147077778e+02,
content:'Saddle = 953.099976 pos = 43.6980,141.4708 diff = 300.099976'
});
data_peak.push({
lat: 4.3696666667e+01,
lng: 1.4155311111e+02,
cert : true,
content:'Name = JA8/SC-006(JA8/SC-006) peak = 1294.699951 pos = 43.6967,141.5531 diff = 226.299927'
});
data_saddle.push({
lat: 4.3698333333e+01,
lng: 1.4153822222e+02,
content:'Saddle = 1068.400024 pos = 43.6983,141.5382 diff = 226.299927'
});
data_peak.push({
lat: 4.3684777778e+01,
lng: 1.4148777778e+02,
cert : true,
content:'Name = Kunbetsudake(JA8/IS-001) peak = 1371.300049 pos = 43.6848,141.4878 diff = 229.800049'
});
data_saddle.push({
lat: 4.3703777778e+01,
lng: 1.4152022222e+02,
content:'Saddle = 1141.500000 pos = 43.7038,141.5202 diff = 229.800049'
});
data_peak.push({
lat: 4.3676888889e+01,
lng: 1.4150755556e+02,
cert : true,
content:'Name = JA8/IS-002(JA8/IS-002) peak = 1344.599976 pos = 43.6769,141.5076 diff = 183.500000'
});
data_saddle.push({
lat: 4.3682555556e+01,
lng: 1.4149888889e+02,
content:'Saddle = 1161.099976 pos = 43.6826,141.4989 diff = 183.500000'
});
data_peak.push({
lat: 4.3935000000e+01,
lng: 1.4173688889e+02,
cert : true,
content:'Name = JA8/RM-022(JA8/RM-022) peak = 272.799988 pos = 43.9350,141.7369 diff = 154.699982'
});
data_saddle.push({
lat: 4.3933000000e+01,
lng: 1.4175422222e+02,
content:'Saddle = 118.099998 pos = 43.9330,141.7542 diff = 154.699982'
});
data_peak.push({
lat: 4.3498222222e+01,
lng: 1.4222266667e+02,
cert : true,
content:'Name = JA8/SC-065(JA8/SC-065) peak = 312.799988 pos = 43.4982,142.2227 diff = 164.899994'
});
data_saddle.push({
lat: 4.3494666667e+01,
lng: 1.4223933333e+02,
content:'Saddle = 147.899994 pos = 43.4947,142.2393 diff = 164.899994'
});
data_peak.push({
lat: 4.3968000000e+01,
lng: 1.4202877778e+02,
cert : true,
content:'Name = JA8/SC-032(JA8/SC-032) peak = 773.599976 pos = 43.9680,142.0288 diff = 624.899963'
});
data_saddle.push({
lat: 4.3999888889e+01,
lng: 1.4213111111e+02,
content:'Saddle = 148.699997 pos = 43.9999,142.1311 diff = 624.899963'
});
data_peak.push({
lat: 4.4000000000e+01,
lng: 1.4209466667e+02,
cert : false,
content:' Peak = 372.600006 pos = 44.0000,142.0947 diff = 174.400009'
});
data_saddle.push({
lat: 4.4000000000e+01,
lng: 1.4208666667e+02,
content:'Saddle = 198.199997 pos = 44.0000,142.0867 diff = 174.400009'
});
data_peak.push({
lat: 4.3893000000e+01,
lng: 1.4190988889e+02,
cert : true,
content:'Name = JA8/SC-063(JA8/SC-063) peak = 376.200012 pos = 43.8930,141.9099 diff = 164.700012'
});
data_saddle.push({
lat: 4.3913444444e+01,
lng: 1.4189077778e+02,
content:'Saddle = 211.500000 pos = 43.9134,141.8908 diff = 164.700012'
});
data_peak.push({
lat: 4.3962333333e+01,
lng: 1.4183644444e+02,
cert : true,
content:'Name = Poroshiriyama(JA8/RM-009) peak = 730.400024 pos = 43.9623,141.8364 diff = 512.700012'
});
data_saddle.push({
lat: 4.3964555556e+01,
lng: 1.4193055556e+02,
content:'Saddle = 217.699997 pos = 43.9646,141.9306 diff = 512.700012'
});
data_peak.push({
lat: 4.3986111111e+01,
lng: 1.4182988889e+02,
cert : true,
content:'Name = JA8/RM-011(JA8/RM-011) peak = 582.599976 pos = 43.9861,141.8299 diff = 197.599976'
});
data_saddle.push({
lat: 4.3977666667e+01,
lng: 1.4184200000e+02,
content:'Saddle = 385.000000 pos = 43.9777,141.8420 diff = 197.599976'
});
data_peak.push({
lat: 4.3937777778e+01,
lng: 1.4196100000e+02,
cert : false,
content:' Peak = 494.000000 pos = 43.9378,141.9610 diff = 152.399994'
});
data_saddle.push({
lat: 4.3936555556e+01,
lng: 1.4197400000e+02,
content:'Saddle = 341.600006 pos = 43.9366,141.9740 diff = 152.399994'
});
data_peak.push({
lat: 4.3999444444e+01,
lng: 1.4204033333e+02,
cert : false,
content:' Peak = 622.099976 pos = 43.9994,142.0403 diff = 198.399963'
});
data_saddle.push({
lat: 4.4000000000e+01,
lng: 1.4201488889e+02,
content:'Saddle = 423.700012 pos = 44.0000,142.0149 diff = 198.399963'
});
data_peak.push({
lat: 4.3987666667e+01,
lng: 1.4208044444e+02,
cert : true,
content:'Name = JA8/SC-050(JA8/SC-050) peak = 601.599976 pos = 43.9877,142.0804 diff = 159.699982'
});
data_saddle.push({
lat: 4.3995555556e+01,
lng: 1.4205166667e+02,
content:'Saddle = 441.899994 pos = 43.9956,142.0517 diff = 159.699982'
});
data_peak.push({
lat: 4.3914777778e+01,
lng: 1.4203977778e+02,
cert : true,
content:'Name = JA8/SC-041(JA8/SC-041) peak = 676.000000 pos = 43.9148,142.0398 diff = 215.600006'
});
data_saddle.push({
lat: 4.3943888889e+01,
lng: 1.4202244444e+02,
content:'Saddle = 460.399994 pos = 43.9439,142.0224 diff = 215.600006'
});
data_peak.push({
lat: 4.2755555556e+01,
lng: 1.4221766667e+02,
cert : false,
content:' Peak = 361.100006 pos = 42.7556,142.2177 diff = 181.700012'
});
data_saddle.push({
lat: 4.2750111112e+01,
lng: 1.4224988889e+02,
content:'Saddle = 179.399994 pos = 42.7501,142.2499 diff = 181.700012'
});
data_peak.push({
lat: 4.3826888889e+01,
lng: 1.4228777778e+02,
cert : true,
content:'Name = JA8/KK-127(JA8/KK-127) peak = 422.299988 pos = 43.8269,142.2878 diff = 233.899994'
});
data_saddle.push({
lat: 4.3844555556e+01,
lng: 1.4228755556e+02,
content:'Saddle = 188.399994 pos = 43.8446,142.2876 diff = 233.899994'
});
data_peak.push({
lat: 4.3173111111e+01,
lng: 1.4188844444e+02,
cert : true,
content:'Name = JA8/SC-064(JA8/SC-064) peak = 360.399994 pos = 43.1731,141.8884 diff = 169.199997'
});
data_saddle.push({
lat: 4.3192333334e+01,
lng: 1.4189600000e+02,
content:'Saddle = 191.199997 pos = 43.1923,141.8960 diff = 169.199997'
});
data_peak.push({
lat: 4.3519000000e+01,
lng: 1.4200633333e+02,
cert : true,
content:'Name = JA8/SC-060(JA8/SC-060) peak = 467.000000 pos = 43.5190,142.0063 diff = 269.899994'
});
data_saddle.push({
lat: 4.3525444445e+01,
lng: 1.4206900000e+02,
content:'Saddle = 197.100006 pos = 43.5254,142.0690 diff = 269.899994'
});
data_peak.push({
lat: 4.3629333333e+01,
lng: 1.4211022222e+02,
cert : true,
content:'Name = Irumukeppuyama(JA8/SC-021) peak = 862.200012 pos = 43.6293,142.1102 diff = 663.300049'
});
data_saddle.push({
lat: 4.3635888889e+01,
lng: 1.4220144444e+02,
content:'Saddle = 198.899994 pos = 43.6359,142.2014 diff = 663.300049'
});
data_peak.push({
lat: 4.2668666667e+01,
lng: 1.4240055556e+02,
cert : false,
content:' Peak = 405.399994 pos = 42.6687,142.4006 diff = 196.000000'
});
data_saddle.push({
lat: 4.2666888889e+01,
lng: 1.4241500000e+02,
content:'Saddle = 209.399994 pos = 42.6669,142.4150 diff = 196.000000'
});
data_peak.push({
lat: 4.3870333333e+01,
lng: 1.4228977778e+02,
cert : true,
content:'Name = JA8/KK-129(JA8/KK-129) peak = 383.299988 pos = 43.8703,142.2898 diff = 164.299988'
});
data_saddle.push({
lat: 4.3881555556e+01,
lng: 1.4227911111e+02,
content:'Saddle = 219.000000 pos = 43.8816,142.2791 diff = 164.299988'
});
data_peak.push({
lat: 4.3539111111e+01,
lng: 1.4222522222e+02,
cert : true,
content:'Name = JA8/SC-062(JA8/SC-062) peak = 381.600006 pos = 43.5391,142.2252 diff = 153.800003'
});
data_saddle.push({
lat: 4.3561666667e+01,
lng: 1.4223655556e+02,
content:'Saddle = 227.800003 pos = 43.5617,142.2366 diff = 153.800003'
});
data_peak.push({
lat: 4.2807555556e+01,
lng: 1.4218466667e+02,
cert : true,
content:'Name = JA8/IR-025(JA8/IR-025) peak = 511.399994 pos = 42.8076,142.1847 diff = 270.399994'
});
data_saddle.push({
lat: 4.2811444445e+01,
lng: 1.4220711111e+02,
content:'Saddle = 241.000000 pos = 42.8114,142.2071 diff = 270.399994'
});
data_peak.push({
lat: 4.3895000000e+01,
lng: 1.4227122222e+02,
cert : true,
content:'Name = JA8/KK-122(JA8/KK-122) peak = 468.799988 pos = 43.8950,142.2712 diff = 227.199982'
});
data_saddle.push({
lat: 4.3924444444e+01,
lng: 1.4227955556e+02,
content:'Saddle = 241.600006 pos = 43.9244,142.2796 diff = 227.199982'
});
data_peak.push({
lat: 4.2835222223e+01,
lng: 1.4215433333e+02,
cert : false,
content:' Peak = 403.799988 pos = 42.8352,142.1543 diff = 151.899994'
});
data_saddle.push({
lat: 4.2847888889e+01,
lng: 1.4213144444e+02,
content:'Saddle = 251.899994 pos = 42.8479,142.1314 diff = 151.899994'
});
data_peak.push({
lat: 4.3905444444e+01,
lng: 1.4214922222e+02,
cert : true,
content:'Name = JA8/KK-095(JA8/KK-095) peak = 653.500000 pos = 43.9054,142.1492 diff = 386.600006'
});
data_saddle.push({
lat: 4.3966555556e+01,
lng: 1.4245444444e+02,
content:'Saddle = 266.899994 pos = 43.9666,142.4544 diff = 386.600006'
});
data_peak.push({
lat: 4.3981222222e+01,
lng: 1.4244333333e+02,
cert : true,
content:'Name = JA8/KK-124(JA8/KK-124) peak = 443.299988 pos = 43.9812,142.4433 diff = 171.299988'
});
data_saddle.push({
lat: 4.3957888889e+01,
lng: 1.4243488889e+02,
content:'Saddle = 272.000000 pos = 43.9579,142.4349 diff = 171.299988'
});
data_peak.push({
lat: 4.3953555556e+01,
lng: 1.4241255556e+02,
cert : true,
content:'Name = JA8/KK-117(JA8/KK-117) peak = 520.799988 pos = 43.9536,142.4126 diff = 244.000000'
});
data_saddle.push({
lat: 4.3958000000e+01,
lng: 1.4237333333e+02,
content:'Saddle = 276.799988 pos = 43.9580,142.3733 diff = 244.000000'
});
data_peak.push({
lat: 4.3932666667e+01,
lng: 1.4212211111e+02,
cert : true,
content:'Name = JA8/KK-114(JA8/KK-114) peak = 551.400024 pos = 43.9327,142.1221 diff = 273.500031'
});
data_saddle.push({
lat: 4.3921888889e+01,
lng: 1.4213433333e+02,
content:'Saddle = 277.899994 pos = 43.9219,142.1343 diff = 273.500031'
});
data_peak.push({
lat: 4.3956666667e+01,
lng: 1.4230655556e+02,
cert : false,
content:' Peak = 575.700012 pos = 43.9567,142.3066 diff = 267.600006'
});
data_saddle.push({
lat: 4.3946111111e+01,
lng: 1.4229855556e+02,
content:'Saddle = 308.100006 pos = 43.9461,142.2986 diff = 267.600006'
});
data_peak.push({
lat: 4.3961333333e+01,
lng: 1.4234433333e+02,
cert : true,
content:'Name = JA8/KK-109(JA8/KK-109) peak = 574.200012 pos = 43.9613,142.3443 diff = 262.500000'
});
data_saddle.push({
lat: 4.3955555556e+01,
lng: 1.4232844444e+02,
content:'Saddle = 311.700012 pos = 43.9556,142.3284 diff = 262.500000'
});
data_peak.push({
lat: 4.3993555556e+01,
lng: 1.4225000000e+02,
cert : false,
content:' Peak = 534.599976 pos = 43.9936,142.2500 diff = 205.399963'
});
data_saddle.push({
lat: 4.3978888889e+01,
lng: 1.4225311111e+02,
content:'Saddle = 329.200012 pos = 43.9789,142.2531 diff = 205.399963'
});
data_peak.push({
lat: 4.3838000000e+01,
lng: 1.4220855556e+02,
cert : true,
content:'Name = JA8/SC-048(JA8/SC-048) peak = 612.799988 pos = 43.8380,142.2086 diff = 250.000000'
});
data_saddle.push({
lat: 4.3868000000e+01,
lng: 1.4218477778e+02,
content:'Saddle = 362.799988 pos = 43.8680,142.1848 diff = 250.000000'
});
data_peak.push({
lat: 4.3761666667e+01,
lng: 1.4220466667e+02,
cert : true,
content:'Name = JA8/KK-108(JA8/KK-108) peak = 591.700012 pos = 43.7617,142.2047 diff = 188.700012'
});
data_saddle.push({
lat: 4.3804000000e+01,
lng: 1.4223733333e+02,
content:'Saddle = 403.000000 pos = 43.8040,142.2373 diff = 188.700012'
});
data_peak.push({
lat: 4.3870000000e+01,
lng: 1.4216855556e+02,
cert : true,
content:'Name = JA8/KK-110(JA8/KK-110) peak = 577.500000 pos = 43.8700,142.1686 diff = 150.399994'
});
data_saddle.push({
lat: 4.3883222222e+01,
lng: 1.4215933333e+02,
content:'Saddle = 427.100006 pos = 43.8832,142.1593 diff = 150.399994'
});
data_peak.push({
lat: 4.3949222222e+01,
lng: 1.4221044444e+02,
cert : true,
content:'Name = JA8/KK-097(JA8/KK-097) peak = 641.000000 pos = 43.9492,142.2104 diff = 185.799988'
});
data_saddle.push({
lat: 4.3914666667e+01,
lng: 1.4216222222e+02,
content:'Saddle = 455.200012 pos = 43.9147,142.1622 diff = 185.799988'
});
data_peak.push({
lat: 4.3606000000e+01,
lng: 1.4227155556e+02,
cert : true,
content:'Name = JA8/SC-018(JA8/SC-018) peak = 901.099976 pos = 43.6060,142.2716 diff = 627.599976'
});
data_saddle.push({
lat: 4.3520444445e+01,
lng: 1.4247433333e+02,
content:'Saddle = 273.500000 pos = 43.5204,142.4743 diff = 627.599976'
});
data_peak.push({
lat: 4.3410111111e+01,
lng: 1.4235333333e+02,
cert : true,
content:'Name = JA8/SC-055(JA8/SC-055) peak = 542.500000 pos = 43.4101,142.3533 diff = 265.899994'
});
data_saddle.push({
lat: 4.3406555556e+01,
lng: 1.4238188889e+02,
content:'Saddle = 276.600006 pos = 43.4066,142.3819 diff = 265.899994'
});
data_peak.push({
lat: 4.3428888889e+01,
lng: 1.4236144444e+02,
cert : false,
content:' Peak = 623.700012 pos = 43.4289,142.3614 diff = 155.700012'
});
data_saddle.push({
lat: 4.3434000000e+01,
lng: 1.4236766667e+02,
content:'Saddle = 468.000000 pos = 43.4340,142.3677 diff = 155.700012'
});
data_peak.push({
lat: 4.3466333334e+01,
lng: 1.4235711111e+02,
cert : false,
content:' Peak = 817.700012 pos = 43.4663,142.3571 diff = 264.500000'
});
data_saddle.push({
lat: 4.3482222222e+01,
lng: 1.4236522222e+02,
content:'Saddle = 553.200012 pos = 43.4822,142.3652 diff = 264.500000'
});
data_peak.push({
lat: 4.3689666667e+01,
lng: 1.4221877778e+02,
cert : true,
content:'Name = JA8/KK-078(JA8/KK-078) peak = 793.799988 pos = 43.6897,142.2188 diff = 202.000000'
});
data_saddle.push({
lat: 4.3693666667e+01,
lng: 1.4223533333e+02,
content:'Saddle = 591.799988 pos = 43.6937,142.2353 diff = 202.000000'
});
data_peak.push({
lat: 4.3544333334e+01,
lng: 1.4232177778e+02,
cert : true,
content:'Name = JA8/KK-067(JA8/KK-067) peak = 858.400024 pos = 43.5443,142.3218 diff = 208.200012'
});
data_saddle.push({
lat: 4.3563111111e+01,
lng: 1.4229911111e+02,
content:'Saddle = 650.200012 pos = 43.5631,142.2991 diff = 208.200012'
});
data_peak.push({
lat: 4.2945666667e+01,
lng: 1.4199988889e+02,
cert : true,
content:'Name = JA8/SC-043(JA8/SC-043) peak = 640.500000 pos = 42.9457,141.9999 diff = 348.200012'
});
data_saddle.push({
lat: 4.3038777778e+01,
lng: 1.4195855556e+02,
content:'Saddle = 292.299988 pos = 43.0388,141.9586 diff = 348.200012'
});
data_peak.push({
lat: 4.3787111111e+01,
lng: 1.4253577778e+02,
cert : false,
content:' Peak = 480.200012 pos = 43.7871,142.5358 diff = 177.700012'
});
data_saddle.push({
lat: 4.3774888889e+01,
lng: 1.4256600000e+02,
content:'Saddle = 302.500000 pos = 43.7749,142.5660 diff = 177.700012'
});
data_peak.push({
lat: 4.3990444444e+01,
lng: 1.4251677778e+02,
cert : true,
content:'Name = JA8/KK-074(JA8/KK-074) peak = 827.700012 pos = 43.9904,142.5168 diff = 508.600006'
});
data_saddle.push({
lat: 4.4000000000e+01,
lng: 1.4264177778e+02,
content:'Saddle = 319.100006 pos = 44.0000,142.6418 diff = 508.600006'
});
data_peak.push({
lat: 4.4000000000e+01,
lng: 1.4262166667e+02,
cert : false,
content:' Peak = 596.400024 pos = 44.0000,142.6217 diff = 232.900024'
});
data_saddle.push({
lat: 4.4000000000e+01,
lng: 1.4259944444e+02,
content:'Saddle = 363.500000 pos = 44.0000,142.5994 diff = 232.900024'
});
data_peak.push({
lat: 4.3956111111e+01,
lng: 1.4254388889e+02,
cert : true,
content:'Name = JA8/KK-084(JA8/KK-084) peak = 754.400024 pos = 43.9561,142.5439 diff = 200.900024'
});
data_saddle.push({
lat: 4.3969666667e+01,
lng: 1.4252800000e+02,
content:'Saddle = 553.500000 pos = 43.9697,142.5280 diff = 200.900024'
});
data_peak.push({
lat: 4.3980000000e+01,
lng: 1.4254088889e+02,
cert : true,
content:'Name = JA8/KK-075(JA8/KK-075) peak = 819.799988 pos = 43.9800,142.5409 diff = 220.000000'
});
data_saddle.push({
lat: 4.3985888889e+01,
lng: 1.4253288889e+02,
content:'Saddle = 599.799988 pos = 43.9859,142.5329 diff = 220.000000'
});
data_peak.push({
lat: 4.3213666667e+01,
lng: 1.4247044444e+02,
cert : true,
content:'Name = JA8/KK-120(JA8/KK-120) peak = 483.899994 pos = 43.2137,142.4704 diff = 152.299988'
});
data_saddle.push({
lat: 4.3233444445e+01,
lng: 1.4248422222e+02,
content:'Saddle = 331.600006 pos = 43.2334,142.4842 diff = 152.299988'
});
data_peak.push({
lat: 4.2784000000e+01,
lng: 1.4237744444e+02,
cert : true,
content:'Name = JA8/HD-095(JA8/HD-095) peak = 540.400024 pos = 42.7840,142.3774 diff = 208.700012'
});
data_saddle.push({
lat: 4.2802555556e+01,
lng: 1.4238444444e+02,
content:'Saddle = 331.700012 pos = 42.8026,142.3844 diff = 208.700012'
});
data_peak.push({
lat: 4.3230777778e+01,
lng: 1.4196688889e+02,
cert : true,
content:'Name = JA8/SC-049(JA8/SC-049) peak = 610.200012 pos = 43.2308,141.9669 diff = 277.400024'
});
data_saddle.push({
lat: 4.3194222223e+01,
lng: 1.4195700000e+02,
content:'Saddle = 332.799988 pos = 43.1942,141.9570 diff = 277.400024'
});
data_peak.push({
lat: 4.2874111112e+01,
lng: 1.4206444444e+02,
cert : true,
content:'Name = JA8/IR-019(JA8/IR-019) peak = 642.599976 pos = 42.8741,142.0644 diff = 300.699982'
});
data_saddle.push({
lat: 4.2884222223e+01,
lng: 1.4209533333e+02,
content:'Saddle = 341.899994 pos = 42.8842,142.0953 diff = 300.699982'
});
data_peak.push({
lat: 4.2850666667e+01,
lng: 1.4199266667e+02,
cert : true,
content:'Name = JA8/SC-057(JA8/SC-057) peak = 504.899994 pos = 42.8507,141.9927 diff = 160.500000'
});
data_saddle.push({
lat: 4.2848666667e+01,
lng: 1.4201988889e+02,
content:'Saddle = 344.399994 pos = 42.8487,142.0199 diff = 160.500000'
});
data_peak.push({
lat: 4.3411444445e+01,
lng: 1.4197133333e+02,
cert : true,
content:'Name = JA8/SC-056(JA8/SC-056) peak = 520.400024 pos = 43.4114,141.9713 diff = 157.400024'
});
data_saddle.push({
lat: 4.3412111111e+01,
lng: 1.4198533333e+02,
content:'Saddle = 363.000000 pos = 43.4121,141.9853 diff = 157.400024'
});
data_peak.push({
lat: 4.2914777778e+01,
lng: 1.4211044444e+02,
cert : true,
content:'Name = JA8/SC-054(JA8/SC-054) peak = 541.900024 pos = 42.9148,142.1104 diff = 171.000031'
});
data_saddle.push({
lat: 4.2918222223e+01,
lng: 1.4211855556e+02,
content:'Saddle = 370.899994 pos = 42.9182,142.1186 diff = 171.000031'
});
data_peak.push({
lat: 4.3265444445e+01,
lng: 1.4241655556e+02,
cert : true,
content:'Name = JA8/KK-105(JA8/KK-105) peak = 602.200012 pos = 43.2654,142.4166 diff = 226.600006'
});
data_saddle.push({
lat: 4.3285222223e+01,
lng: 1.4249222222e+02,
content:'Saddle = 375.600006 pos = 43.2852,142.4922 diff = 226.600006'
});
data_peak.push({
lat: 4.2995333334e+01,
lng: 1.4210200000e+02,
cert : false,
content:' Peak = 752.000000 pos = 42.9953,142.1020 diff = 374.600006'
});
data_saddle.push({
lat: 4.2957222223e+01,
lng: 1.4217433333e+02,
content:'Saddle = 377.399994 pos = 42.9572,142.1743 diff = 374.600006'
});
data_peak.push({
lat: 4.2907222223e+01,
lng: 1.4216144444e+02,
cert : false,
content:' Peak = 572.299988 pos = 42.9072,142.1614 diff = 150.199982'
});
data_saddle.push({
lat: 4.2959888889e+01,
lng: 1.4213077778e+02,
content:'Saddle = 422.100006 pos = 42.9599,142.1308 diff = 150.199982'
});
data_peak.push({
lat: 4.2666777778e+01,
lng: 1.4249566667e+02,
cert : false,
content:' Peak = 929.799988 pos = 42.6668,142.4957 diff = 550.400024'
});
data_saddle.push({
lat: 4.2666777778e+01,
lng: 1.4252344444e+02,
content:'Saddle = 379.399994 pos = 42.6668,142.5234 diff = 550.400024'
});
data_peak.push({
lat: 4.2666777778e+01,
lng: 1.4246144444e+02,
cert : false,
content:' Peak = 833.299988 pos = 42.6668,142.4614 diff = 416.500000'
});
data_saddle.push({
lat: 4.2666777778e+01,
lng: 1.4247355556e+02,
content:'Saddle = 416.799988 pos = 42.6668,142.4736 diff = 416.500000'
});
data_peak.push({
lat: 4.2666777778e+01,
lng: 1.4248122222e+02,
cert : false,
content:' Peak = 780.700012 pos = 42.6668,142.4812 diff = 151.000000'
});
data_saddle.push({
lat: 4.2666777778e+01,
lng: 1.4248722222e+02,
content:'Saddle = 629.700012 pos = 42.6668,142.4872 diff = 151.000000'
});
data_peak.push({
lat: 4.3861111111e+01,
lng: 1.4273511111e+02,
cert : true,
content:'Name = JA8/KK-107(JA8/KK-107) peak = 590.900024 pos = 43.8611,142.7351 diff = 210.100037'
});
data_saddle.push({
lat: 4.3856444445e+01,
lng: 1.4276255556e+02,
content:'Saddle = 380.799988 pos = 43.8564,142.7626 diff = 210.100037'
});
data_peak.push({
lat: 4.3721000000e+01,
lng: 1.4259888889e+02,
cert : true,
content:'Name = JA8/KK-111(JA8/KK-111) peak = 570.700012 pos = 43.7210,142.5989 diff = 185.000000'
});
data_saddle.push({
lat: 4.3719555556e+01,
lng: 1.4262300000e+02,
content:'Saddle = 385.700012 pos = 43.7196,142.6230 diff = 185.000000'
});
data_peak.push({
lat: 4.2751444445e+01,
lng: 1.4240111111e+02,
cert : true,
content:'Name = JA8/HD-094(JA8/HD-094) peak = 550.900024 pos = 42.7514,142.4011 diff = 164.500031'
});
data_saddle.push({
lat: 4.2740555556e+01,
lng: 1.4241388889e+02,
content:'Saddle = 386.399994 pos = 42.7406,142.4139 diff = 164.500031'
});
data_peak.push({
lat: 4.3371777778e+01,
lng: 1.4196877778e+02,
cert : true,
content:'Name = JA8/SC-053(JA8/SC-053) peak = 564.400024 pos = 43.3718,141.9688 diff = 177.000031'
});
data_saddle.push({
lat: 4.3368555556e+01,
lng: 1.4198300000e+02,
content:'Saddle = 387.399994 pos = 43.3686,141.9830 diff = 177.000031'
});
data_peak.push({
lat: 4.3436666667e+01,
lng: 1.4217400000e+02,
cert : true,
content:'Name = JA8/SC-051(JA8/SC-051) peak = 584.400024 pos = 43.4367,142.1740 diff = 182.100037'
});
data_saddle.push({
lat: 4.3440000000e+01,
lng: 1.4218644444e+02,
content:'Saddle = 402.299988 pos = 43.4400,142.1864 diff = 182.100037'
});
data_peak.push({
lat: 4.3183777778e+01,
lng: 1.4198833333e+02,
cert : true,
content:'Name = JA8/SC-046(JA8/SC-046) peak = 623.000000 pos = 43.1838,141.9883 diff = 196.100006'
});
data_saddle.push({
lat: 4.3172777778e+01,
lng: 1.4201311111e+02,
content:'Saddle = 426.899994 pos = 43.1728,142.0131 diff = 196.100006'
});
data_peak.push({
lat: 4.3398111111e+01,
lng: 1.4220500000e+02,
cert : true,
content:'Name = JA8/SC-034(JA8/SC-034) peak = 756.700012 pos = 43.3981,142.2050 diff = 325.800018'
});
data_saddle.push({
lat: 4.3401222222e+01,
lng: 1.4223277778e+02,
content:'Saddle = 430.899994 pos = 43.4012,142.2328 diff = 325.800018'
});
data_peak.push({
lat: 4.3337888889e+01,
lng: 1.4215900000e+02,
cert : false,
content:' Peak = 604.099976 pos = 43.3379,142.1590 diff = 156.399963'
});
data_saddle.push({
lat: 4.3348111111e+01,
lng: 1.4216411111e+02,
content:'Saddle = 447.700012 pos = 43.3481,142.1641 diff = 156.399963'
});
data_peak.push({
lat: 4.2848777778e+01,
lng: 1.4222766667e+02,
cert : true,
content:'Name = JA8/IR-011(JA8/IR-011) peak = 790.500000 pos = 42.8488,142.2277 diff = 336.500000'
});
data_saddle.push({
lat: 4.2896111112e+01,
lng: 1.4222155556e+02,
content:'Saddle = 454.000000 pos = 42.8961,142.2216 diff = 336.500000'
});
data_peak.push({
lat: 4.3448000000e+01,
lng: 1.4202055556e+02,
cert : true,
content:'Name = JA8/SC-047(JA8/SC-047) peak = 621.799988 pos = 43.4480,142.0206 diff = 159.799988'
});
data_saddle.push({
lat: 4.3444111111e+01,
lng: 1.4202322222e+02,
content:'Saddle = 462.000000 pos = 43.4441,142.0232 diff = 159.799988'
});
data_peak.push({
lat: 4.3013444445e+01,
lng: 1.4216377778e+02,
cert : false,
content:' Peak = 613.000000 pos = 43.0134,142.1638 diff = 150.100006'
});
data_saddle.push({
lat: 4.3011777778e+01,
lng: 1.4217833333e+02,
content:'Saddle = 462.899994 pos = 43.0118,142.1783 diff = 150.100006'
});
data_peak.push({
lat: 4.3999111111e+01,
lng: 1.4267711111e+02,
cert : false,
content:' Peak = 627.200012 pos = 43.9991,142.6771 diff = 161.200012'
});
data_saddle.push({
lat: 4.4000000000e+01,
lng: 1.4269077778e+02,
content:'Saddle = 466.000000 pos = 44.0000,142.6908 diff = 161.200012'
});
data_peak.push({
lat: 4.3079111111e+01,
lng: 1.4204155556e+02,
cert : true,
content:'Name = JA8/SC-020(JA8/SC-020) peak = 871.799988 pos = 43.0791,142.0416 diff = 393.699982'
});
data_saddle.push({
lat: 4.3164666667e+01,
lng: 1.4207255556e+02,
content:'Saddle = 478.100006 pos = 43.1647,142.0726 diff = 393.699982'
});
data_peak.push({
lat: 4.3118666667e+01,
lng: 1.4207800000e+02,
cert : true,
content:'Name = JA8/SC-039(JA8/SC-039) peak = 723.900024 pos = 43.1187,142.0780 diff = 165.700012'
});
data_saddle.push({
lat: 4.3121888889e+01,
lng: 1.4205877778e+02,
content:'Saddle = 558.200012 pos = 43.1219,142.0588 diff = 165.700012'
});
data_peak.push({
lat: 4.3094444445e+01,
lng: 1.4198433333e+02,
cert : true,
content:'Name = JA8/SC-033(JA8/SC-033) peak = 769.500000 pos = 43.0944,141.9843 diff = 156.500000'
});
data_saddle.push({
lat: 4.3102222223e+01,
lng: 1.4200833333e+02,
content:'Saddle = 613.000000 pos = 43.1022,142.0083 diff = 156.500000'
});
data_peak.push({
lat: 4.3143555556e+01,
lng: 1.4204133333e+02,
cert : false,
content:' Peak = 835.599976 pos = 43.1436,142.0413 diff = 215.000000'
});
data_saddle.push({
lat: 4.3109222223e+01,
lng: 1.4204188889e+02,
content:'Saddle = 620.599976 pos = 43.1092,142.0419 diff = 215.000000'
});
data_peak.push({
lat: 4.3084888889e+01,
lng: 1.4207411111e+02,
cert : true,
content:'Name = JA8/SC-024(JA8/SC-024) peak = 840.799988 pos = 43.0849,142.0741 diff = 212.200012'
});
data_saddle.push({
lat: 4.3085444445e+01,
lng: 1.4205888889e+02,
content:'Saddle = 628.599976 pos = 43.0854,142.0589 diff = 212.200012'
});
data_peak.push({
lat: 4.3196333334e+01,
lng: 1.4252622222e+02,
cert : true,
content:'Name = JA8/KK-068(JA8/KK-068) peak = 852.200012 pos = 43.1963,142.5262 diff = 373.400024'
});
data_saddle.push({
lat: 4.3196777778e+01,
lng: 1.4258388889e+02,
content:'Saddle = 478.799988 pos = 43.1968,142.5839 diff = 373.400024'
});
data_peak.push({
lat: 4.3189777778e+01,
lng: 1.4255277778e+02,
cert : false,
content:' Peak = 790.799988 pos = 43.1898,142.5528 diff = 157.700012'
});
data_saddle.push({
lat: 4.3190444445e+01,
lng: 1.4254600000e+02,
content:'Saddle = 633.099976 pos = 43.1904,142.5460 diff = 157.700012'
});
data_peak.push({
lat: 4.2821555556e+01,
lng: 1.4228333333e+02,
cert : false,
content:' Peak = 645.799988 pos = 42.8216,142.2833 diff = 153.399994'
});
data_saddle.push({
lat: 4.2822000000e+01,
lng: 1.4229044444e+02,
content:'Saddle = 492.399994 pos = 42.8220,142.2904 diff = 153.399994'
});
data_peak.push({
lat: 4.2847000000e+01,
lng: 1.4231311111e+02,
cert : true,
content:'Name = Hattaomanaidake(JA8/HD-046) peak = 1021.099976 pos = 42.8470,142.3131 diff = 527.699951'
});
data_saddle.push({
lat: 4.2912666667e+01,
lng: 1.4244677778e+02,
content:'Saddle = 493.399994 pos = 42.9127,142.4468 diff = 527.699951'
});
data_peak.push({
lat: 4.2843222223e+01,
lng: 1.4240155556e+02,
cert : true,
content:'Name = JA8/HD-078(JA8/HD-078) peak = 714.700012 pos = 42.8432,142.4016 diff = 186.799988'
});
data_saddle.push({
lat: 4.2847333334e+01,
lng: 1.4239844444e+02,
content:'Saddle = 527.900024 pos = 42.8473,142.3984 diff = 186.799988'
});
data_peak.push({
lat: 4.2772777778e+01,
lng: 1.4231533333e+02,
cert : true,
content:'Name = JA8/HD-074(JA8/HD-074) peak = 740.700012 pos = 42.7728,142.3153 diff = 185.500000'
});
data_saddle.push({
lat: 4.2778777778e+01,
lng: 1.4230400000e+02,
content:'Saddle = 555.200012 pos = 42.7788,142.3040 diff = 185.500000'
});
data_peak.push({
lat: 4.2886777778e+01,
lng: 1.4237877778e+02,
cert : true,
content:'Name = JA8/KK-057(JA8/KK-057) peak = 934.700012 pos = 42.8868,142.3788 diff = 327.200012'
});
data_saddle.push({
lat: 4.2886222223e+01,
lng: 1.4234755556e+02,
content:'Saddle = 607.500000 pos = 42.8862,142.3476 diff = 327.200012'
});
data_peak.push({
lat: 4.2905777778e+01,
lng: 1.4238166667e+02,
cert : false,
content:' Peak = 790.900024 pos = 42.9058,142.3817 diff = 157.600037'
});
data_saddle.push({
lat: 4.2898555556e+01,
lng: 1.4238622222e+02,
content:'Saddle = 633.299988 pos = 42.8986,142.3862 diff = 157.600037'
});
data_peak.push({
lat: 4.2881111112e+01,
lng: 1.4231288889e+02,
cert : true,
content:'Name = JA8/IR-005(JA8/IR-005) peak = 1015.799988 pos = 42.8811,142.3129 diff = 213.000000'
});
data_saddle.push({
lat: 4.2861555556e+01,
lng: 1.4231522222e+02,
content:'Saddle = 802.799988 pos = 42.8616,142.3152 diff = 213.000000'
});
data_peak.push({
lat: 4.3401222222e+01,
lng: 1.4204988889e+02,
cert : true,
content:'Name = JA8/SC-011(JA8/SC-011) peak = 985.900024 pos = 43.4012,142.0499 diff = 484.000031'
});
data_saddle.push({
lat: 4.3288555556e+01,
lng: 1.4207422222e+02,
content:'Saddle = 501.899994 pos = 43.2886,142.0742 diff = 484.000031'
});
data_peak.push({
lat: 4.3324111111e+01,
lng: 1.4211877778e+02,
cert : true,
content:'Name = JA8/SC-038(JA8/SC-038) peak = 721.299988 pos = 43.3241,142.1188 diff = 199.299988'
});
data_saddle.push({
lat: 4.3327444445e+01,
lng: 1.4208711111e+02,
content:'Saddle = 522.000000 pos = 43.3274,142.0871 diff = 199.299988'
});
data_peak.push({
lat: 4.3330333334e+01,
lng: 1.4205855556e+02,
cert : true,
content:'Name = JA8/SC-025(JA8/SC-025) peak = 847.799988 pos = 43.3303,142.0586 diff = 305.399963'
});
data_saddle.push({
lat: 4.3345000000e+01,
lng: 1.4205377778e+02,
content:'Saddle = 542.400024 pos = 43.3450,142.0538 diff = 305.399963'
});
data_peak.push({
lat: 4.3355555556e+01,
lng: 1.4201866667e+02,
cert : true,
content:'Name = JA8/SC-031(JA8/SC-031) peak = 780.299988 pos = 43.3556,142.0187 diff = 198.000000'
});
data_saddle.push({
lat: 4.3356111111e+01,
lng: 1.4203377778e+02,
content:'Saddle = 582.299988 pos = 43.3561,142.0338 diff = 198.000000'
});
data_peak.push({
lat: 4.3449444445e+01,
lng: 1.4209744444e+02,
cert : false,
content:' Peak = 743.200012 pos = 43.4494,142.0974 diff = 155.100037'
});
data_saddle.push({
lat: 4.3440333334e+01,
lng: 1.4207788889e+02,
content:'Saddle = 588.099976 pos = 43.4403,142.0779 diff = 155.100037'
});
data_peak.push({
lat: 4.3363555556e+01,
lng: 1.4212822222e+02,
cert : true,
content:'Name = JA8/SC-030(JA8/SC-030) peak = 780.000000 pos = 43.3636,142.1282 diff = 157.400024'
});
data_saddle.push({
lat: 4.3379777778e+01,
lng: 1.4210066667e+02,
content:'Saddle = 622.599976 pos = 43.3798,142.1007 diff = 157.400024'
});
data_peak.push({
lat: 4.3404222222e+01,
lng: 1.4210422222e+02,
cert : true,
content:'Name = JA8/SC-022(JA8/SC-022) peak = 852.599976 pos = 43.4042,142.1042 diff = 215.199951'
});
data_saddle.push({
lat: 4.3398222222e+01,
lng: 1.4209355556e+02,
content:'Saddle = 637.400024 pos = 43.3982,142.0936 diff = 215.199951'
});
data_peak.push({
lat: 4.3358555556e+01,
lng: 1.4205988889e+02,
cert : true,
content:'Name = JA8/SC-027(JA8/SC-027) peak = 832.500000 pos = 43.3586,142.0599 diff = 163.900024'
});
data_saddle.push({
lat: 4.3375666667e+01,
lng: 1.4206055556e+02,
content:'Saddle = 668.599976 pos = 43.3757,142.0606 diff = 163.900024'
});
data_peak.push({
lat: 4.3925888889e+01,
lng: 1.4267388889e+02,
cert : true,
content:'Name = JA8/KK-076(JA8/KK-076) peak = 810.799988 pos = 43.9259,142.6739 diff = 302.899994'
});
data_saddle.push({
lat: 4.3922333333e+01,
lng: 1.4268933333e+02,
content:'Saddle = 507.899994 pos = 43.9223,142.6893 diff = 302.899994'
});
data_peak.push({
lat: 4.3158111111e+01,
lng: 1.4237800000e+02,
cert : true,
content:'Name = JA8/KK-081(JA8/KK-081) peak = 770.599976 pos = 43.1581,142.3780 diff = 253.299988'
});
data_saddle.push({
lat: 4.3166333334e+01,
lng: 1.4235966667e+02,
content:'Saddle = 517.299988 pos = 43.1663,142.3597 diff = 253.299988'
});
data_peak.push({
lat: 4.3153555556e+01,
lng: 1.4263822222e+02,
cert : true,
content:'Name = JA8/KK-069(JA8/KK-069) peak = 844.200012 pos = 43.1536,142.6382 diff = 326.600037'
});
data_saddle.push({
lat: 4.3180444445e+01,
lng: 1.4266266667e+02,
content:'Saddle = 517.599976 pos = 43.1804,142.6627 diff = 326.600037'
});
data_peak.push({
lat: 4.3235777778e+01,
lng: 1.4228344444e+02,
cert : true,
content:'Name = Ashibetsudake(JA8/KK-019) peak = 1722.800049 pos = 43.2358,142.2834 diff = 1204.900024'
});
data_saddle.push({
lat: 4.3091777778e+01,
lng: 1.4240066667e+02,
content:'Saddle = 517.900024 pos = 43.0918,142.4007 diff = 1204.900024'
});
data_peak.push({
lat: 4.3002555556e+01,
lng: 1.4237011111e+02,
cert : false,
content:' Peak = 783.299988 pos = 43.0026,142.3701 diff = 241.299988'
});
data_saddle.push({
lat: 4.3017777778e+01,
lng: 1.4235611111e+02,
content:'Saddle = 542.000000 pos = 43.0178,142.3561 diff = 241.299988'
});
data_peak.push({
lat: 4.2978888889e+01,
lng: 1.4227566667e+02,
cert : false,
content:' Peak = 850.900024 pos = 42.9789,142.2757 diff = 303.700012'
});
data_saddle.push({
lat: 4.3016333334e+01,
lng: 1.4230100000e+02,
content:'Saddle = 547.200012 pos = 43.0163,142.3010 diff = 303.700012'
});
data_peak.push({
lat: 4.2930333334e+01,
lng: 1.4225133333e+02,
cert : true,
content:'Name = JA8/IR-012(JA8/IR-012) peak = 760.299988 pos = 42.9303,142.2513 diff = 179.299988'
});
data_saddle.push({
lat: 4.2946222223e+01,
lng: 1.4226322222e+02,
content:'Saddle = 581.000000 pos = 42.9462,142.2632 diff = 179.299988'
});
data_peak.push({
lat: 4.3382555556e+01,
lng: 1.4228966667e+02,
cert : true,
content:'Name = JA8/SC-017(JA8/SC-017) peak = 903.200012 pos = 43.3826,142.2897 diff = 310.200012'
});
data_saddle.push({
lat: 4.3335555556e+01,
lng: 1.4226188889e+02,
content:'Saddle = 593.000000 pos = 43.3356,142.2619 diff = 310.200012'
});
data_peak.push({
lat: 4.3357555556e+01,
lng: 1.4227100000e+02,
cert : true,
content:'Name = JA8/SC-019(JA8/SC-019) peak = 872.500000 pos = 43.3576,142.2710 diff = 155.299988'
});
data_saddle.push({
lat: 4.3363888889e+01,
lng: 1.4228500000e+02,
content:'Saddle = 717.200012 pos = 43.3639,142.2850 diff = 155.299988'
});
data_peak.push({
lat: 4.3346000000e+01,
lng: 1.4218844444e+02,
cert : false,
content:' Peak = 811.599976 pos = 43.3460,142.1884 diff = 209.399963'
});
data_saddle.push({
lat: 4.3340111111e+01,
lng: 1.4221077778e+02,
content:'Saddle = 602.200012 pos = 43.3401,142.2108 diff = 209.399963'
});
data_peak.push({
lat: 4.3105888889e+01,
lng: 1.4232722222e+02,
cert : true,
content:'Name = JA8/KK-080(JA8/KK-080) peak = 780.200012 pos = 43.1059,142.3272 diff = 162.500000'
});
data_saddle.push({
lat: 4.3097666667e+01,
lng: 1.4231933333e+02,
content:'Saddle = 617.700012 pos = 43.0977,142.3193 diff = 162.500000'
});
data_peak.push({
lat: 4.3290111111e+01,
lng: 1.4216944444e+02,
cert : true,
content:'Name = JA8/SC-016(JA8/SC-016) peak = 924.099976 pos = 43.2901,142.1694 diff = 251.399963'
});
data_saddle.push({
lat: 4.3296777778e+01,
lng: 1.4222266667e+02,
content:'Saddle = 672.700012 pos = 43.2968,142.2227 diff = 251.399963'
});
data_peak.push({
lat: 4.3307777778e+01,
lng: 1.4220344444e+02,
cert : true,
content:'Name = JA8/SC-014(JA8/SC-014) peak = 922.900024 pos = 43.3078,142.2034 diff = 190.800049'
});
data_saddle.push({
lat: 4.3296444445e+01,
lng: 1.4218122222e+02,
content:'Saddle = 732.099976 pos = 43.2964,142.1812 diff = 190.800049'
});
data_peak.push({
lat: 4.3227111111e+01,
lng: 1.4215933333e+02,
cert : true,
content:'Name = Ikushyunbetsudake(JA8/SC-008) peak = 1067.400024 pos = 43.2271,142.1593 diff = 384.400024'
});
data_saddle.push({
lat: 4.3208888889e+01,
lng: 1.4220611111e+02,
content:'Saddle = 683.000000 pos = 43.2089,142.2061 diff = 384.400024'
});
data_peak.push({
lat: 4.3258444445e+01,
lng: 1.4217711111e+02,
cert : true,
content:'Name = JA8/SC-010(JA8/SC-010) peak = 1017.700012 pos = 43.2584,142.1771 diff = 315.400024'
});
data_saddle.push({
lat: 4.3262333334e+01,
lng: 1.4219788889e+02,
content:'Saddle = 702.299988 pos = 43.2623,142.1979 diff = 315.400024'
});
data_peak.push({
lat: 4.3097444445e+01,
lng: 1.4236466667e+02,
cert : true,
content:'Name = JA8/KK-061(JA8/KK-061) peak = 910.599976 pos = 43.0974,142.3647 diff = 198.799988'
});
data_saddle.push({
lat: 4.3077111111e+01,
lng: 1.4233677778e+02,
content:'Saddle = 711.799988 pos = 43.0771,142.3368 diff = 198.799988'
});
data_peak.push({
lat: 4.3089555556e+01,
lng: 1.4234722222e+02,
cert : true,
content:'Name = JA8/KK-064(JA8/KK-064) peak = 871.099976 pos = 43.0896,142.3472 diff = 158.000000'
});
data_saddle.push({
lat: 4.3098666667e+01,
lng: 1.4235466667e+02,
content:'Saddle = 713.099976 pos = 43.0987,142.3547 diff = 158.000000'
});
data_peak.push({
lat: 4.3142000000e+01,
lng: 1.4228755556e+02,
cert : true,
content:'Name = JA8/KK-037(JA8/KK-037) peak = 1207.400024 pos = 43.1420,142.2876 diff = 189.800049'
});
data_saddle.push({
lat: 4.3140888889e+01,
lng: 1.4227966667e+02,
content:'Saddle = 1017.599976 pos = 43.1409,142.2797 diff = 189.800049'
});
data_peak.push({
lat: 4.3099777778e+01,
lng: 1.4225100000e+02,
cert : true,
content:'Name = Yuubaridake(JA8/KK-021) peak = 1664.300049 pos = 43.0998,142.2510 diff = 611.000000'
});
data_saddle.push({
lat: 4.3175444445e+01,
lng: 1.4226700000e+02,
content:'Saddle = 1053.300049 pos = 43.1754,142.2670 diff = 611.000000'
});
data_peak.push({
lat: 4.3067777778e+01,
lng: 1.4226788889e+02,
cert : false,
content:' Peak = 1302.099976 pos = 43.0678,142.2679 diff = 163.699951'
});
data_saddle.push({
lat: 4.3085666667e+01,
lng: 1.4226100000e+02,
content:'Saddle = 1138.400024 pos = 43.0857,142.2610 diff = 163.699951'
});
data_peak.push({
lat: 4.3169666667e+01,
lng: 1.4225400000e+02,
cert : true,
content:'Name = JA8/SC-003(JA8/SC-003) peak = 1413.900024 pos = 43.1697,142.2540 diff = 213.200073'
});
data_saddle.push({
lat: 4.3159444445e+01,
lng: 1.4225622222e+02,
content:'Saddle = 1200.699951 pos = 43.1594,142.2562 diff = 213.200073'
});
data_peak.push({
lat: 4.3288888889e+01,
lng: 1.4226966667e+02,
cert : true,
content:'Name = JA8/SC-004(JA8/SC-004) peak = 1310.500000 pos = 43.2889,142.2697 diff = 227.500000'
});
data_saddle.push({
lat: 4.3284555556e+01,
lng: 1.4227622222e+02,
content:'Saddle = 1083.000000 pos = 43.2846,142.2762 diff = 227.500000'
});
data_peak.push({
lat: 4.3297111111e+01,
lng: 1.4229088889e+02,
cert : false,
content:' Peak = 1336.500000 pos = 43.2971,142.2909 diff = 202.800049'
});
data_saddle.push({
lat: 4.3290444445e+01,
lng: 1.4229677778e+02,
content:'Saddle = 1133.699951 pos = 43.2904,142.2968 diff = 202.800049'
});
data_peak.push({
lat: 4.3224000000e+01,
lng: 1.4224733333e+02,
cert : true,
content:'Name = JA8/SC-002(JA8/SC-002) peak = 1433.800049 pos = 43.2240,142.2473 diff = 191.600098'
});
data_saddle.push({
lat: 4.3221888889e+01,
lng: 1.4225211111e+02,
content:'Saddle = 1242.199951 pos = 43.2219,142.2521 diff = 191.600098'
});
data_peak.push({
lat: 4.3252444445e+01,
lng: 1.4225555556e+02,
cert : true,
content:'Name = JA8/SC-001(JA8/SC-001) peak = 1492.599976 pos = 43.2524,142.2556 diff = 225.199951'
});
data_saddle.push({
lat: 4.3253222223e+01,
lng: 1.4226900000e+02,
content:'Saddle = 1267.400024 pos = 43.2532,142.2690 diff = 225.199951'
});
data_peak.push({
lat: 4.3197777778e+01,
lng: 1.4228444444e+02,
cert : true,
content:'Name = JA8/KK-026(JA8/KK-026) peak = 1452.199951 pos = 43.1978,142.2844 diff = 169.599976'
});
data_saddle.push({
lat: 4.3202777778e+01,
lng: 1.4228266667e+02,
content:'Saddle = 1282.599976 pos = 43.2028,142.2827 diff = 169.599976'
});
data_peak.push({
lat: 4.3242888889e+01,
lng: 1.4255233333e+02,
cert : true,
content:'Name = JA8/KK-070(JA8/KK-070) peak = 845.099976 pos = 43.2429,142.5523 diff = 289.699951'
});
data_saddle.push({
lat: 4.3273555556e+01,
lng: 1.4258444444e+02,
content:'Saddle = 555.400024 pos = 43.2736,142.5844 diff = 289.699951'
});
data_peak.push({
lat: 4.3078666667e+01,
lng: 1.4259600000e+02,
cert : true,
content:'Name = Tomamusan(JA8/KK-035) peak = 1238.099976 pos = 43.0787,142.5960 diff = 668.899963'
});
data_saddle.push({
lat: 4.3044111111e+01,
lng: 1.4266544444e+02,
content:'Saddle = 569.200012 pos = 43.0441,142.6654 diff = 668.899963'
});
data_peak.push({
lat: 4.3133222223e+01,
lng: 1.4252433333e+02,
cert : true,
content:'Name = Shamanshadake(JA8/KK-046) peak = 1060.599976 pos = 43.1332,142.5243 diff = 334.000000'
});
data_saddle.push({
lat: 4.3128888889e+01,
lng: 1.4254588889e+02,
content:'Saddle = 726.599976 pos = 43.1289,142.5459 diff = 334.000000'
});
data_peak.push({
lat: 4.3113555556e+01,
lng: 1.4256900000e+02,
cert : true,
content:'Name = JA8/KK-053(JA8/KK-053) peak = 981.500000 pos = 43.1136,142.5690 diff = 238.299988'
});
data_saddle.push({
lat: 4.3108666667e+01,
lng: 1.4258200000e+02,
content:'Saddle = 743.200012 pos = 43.1087,142.5820 diff = 238.299988'
});
data_peak.push({
lat: 4.3074333334e+01,
lng: 1.4263433333e+02,
cert : true,
content:'Name = JA8/KK-056(JA8/KK-056) peak = 951.299988 pos = 43.0743,142.6343 diff = 190.399963'
});
data_saddle.push({
lat: 4.3079666667e+01,
lng: 1.4262122222e+02,
content:'Saddle = 760.900024 pos = 43.0797,142.6212 diff = 190.399963'
});
data_peak.push({
lat: 4.3100444445e+01,
lng: 1.4261844444e+02,
cert : true,
content:'Name = JA8/KK-040(JA8/KK-040) peak = 1164.800049 pos = 43.1004,142.6184 diff = 187.800049'
});
data_saddle.push({
lat: 4.3102888889e+01,
lng: 1.4260288889e+02,
content:'Saddle = 977.000000 pos = 43.1029,142.6029 diff = 187.800049'
});
data_peak.push({
lat: 4.2924111112e+01,
lng: 1.4248655556e+02,
cert : true,
content:'Name = JA8/KK-083(JA8/KK-083) peak = 761.599976 pos = 42.9241,142.4866 diff = 169.399963'
});
data_saddle.push({
lat: 4.2916222223e+01,
lng: 1.4250800000e+02,
content:'Saddle = 592.200012 pos = 42.9162,142.5080 diff = 169.399963'
});
data_peak.push({
lat: 4.2704555556e+01,
lng: 1.4247544444e+02,
cert : true,
content:'Name = JA8/HD-058(JA8/HD-058) peak = 893.799988 pos = 42.7046,142.4754 diff = 271.200012'
});
data_saddle.push({
lat: 4.2701888889e+01,
lng: 1.4248988889e+02,
content:'Saddle = 622.599976 pos = 42.7019,142.4899 diff = 271.200012'
});
data_peak.push({
lat: 4.2693000001e+01,
lng: 1.4247166667e+02,
cert : false,
content:' Peak = 883.299988 pos = 42.6930,142.4717 diff = 201.700012'
});
data_saddle.push({
lat: 4.2698333334e+01,
lng: 1.4247800000e+02,
content:'Saddle = 681.599976 pos = 42.6983,142.4780 diff = 201.700012'
});
data_peak.push({
lat: 4.2719444445e+01,
lng: 1.4268277778e+02,
cert : true,
content:'Name = Poroshiridake(JA8/HD-001) peak = 2050.800049 pos = 42.7194,142.6828 diff = 1407.300049'
});
data_saddle.push({
lat: 4.3135555556e+01,
lng: 1.4276477778e+02,
content:'Saddle = 643.500000 pos = 43.1356,142.7648 diff = 1407.300049'
});
data_peak.push({
lat: 4.2989888889e+01,
lng: 1.4247466667e+02,
cert : false,
content:' Peak = 841.099976 pos = 42.9899,142.4747 diff = 168.500000'
});
data_saddle.push({
lat: 4.3003222223e+01,
lng: 1.4248766667e+02,
content:'Saddle = 672.599976 pos = 43.0032,142.4877 diff = 168.500000'
});
data_peak.push({
lat: 4.3046222223e+01,
lng: 1.4255400000e+02,
cert : true,
content:'Name = JA8/KK-065(JA8/KK-065) peak = 865.099976 pos = 43.0462,142.5540 diff = 182.199951'
});
data_saddle.push({
lat: 4.3047666667e+01,
lng: 1.4256122222e+02,
content:'Saddle = 682.900024 pos = 43.0477,142.5612 diff = 182.199951'
});
data_peak.push({
lat: 4.3080666667e+01,
lng: 1.4273388889e+02,
cert : true,
content:'Name = JA8/TC-070(JA8/TC-070) peak = 1070.199951 pos = 43.0807,142.7339 diff = 383.799927'
});
data_saddle.push({
lat: 4.3067777778e+01,
lng: 1.4273733333e+02,
content:'Saddle = 686.400024 pos = 43.0678,142.7373 diff = 383.799927'
});
data_peak.push({
lat: 4.3118111111e+01,
lng: 1.4273144444e+02,
cert : true,
content:'Name = JA8/KK-052(JA8/KK-052) peak = 983.500000 pos = 43.1181,142.7314 diff = 262.299988'
});
data_saddle.push({
lat: 4.3106666667e+01,
lng: 1.4274666667e+02,
content:'Saddle = 721.200012 pos = 43.1067,142.7467 diff = 262.299988'
});
data_peak.push({
lat: 4.2719888889e+01,
lng: 1.4252511111e+02,
cert : true,
content:'Name = JA8/HD-047(JA8/HD-047) peak = 1010.700012 pos = 42.7199,142.5251 diff = 319.799988'
});
data_saddle.push({
lat: 4.2715444445e+01,
lng: 1.4256566667e+02,
content:'Saddle = 690.900024 pos = 42.7154,142.5657 diff = 319.799988'
});
data_peak.push({
lat: 4.2693111112e+01,
lng: 1.4252066667e+02,
cert : true,
content:'Name = JA8/HD-055(JA8/HD-055) peak = 942.299988 pos = 42.6931,142.5207 diff = 182.200012'
});
data_saddle.push({
lat: 4.2697333334e+01,
lng: 1.4252366667e+02,
content:'Saddle = 760.099976 pos = 42.6973,142.5237 diff = 182.200012'
});
data_peak.push({
lat: 4.2706777778e+01,
lng: 1.4254677778e+02,
cert : true,
content:'Name = JA8/HD-049(JA8/HD-049) peak = 1002.299988 pos = 42.7068,142.5468 diff = 210.599976'
});
data_saddle.push({
lat: 4.2713111112e+01,
lng: 1.4253333333e+02,
content:'Saddle = 791.700012 pos = 42.7131,142.5333 diff = 210.599976'
});
data_peak.push({
lat: 4.2680333334e+01,
lng: 1.4292777778e+02,
cert : true,
content:'Name = JA8/TC-089(JA8/TC-089) peak = 881.500000 pos = 42.6803,142.9278 diff = 174.700012'
});
data_saddle.push({
lat: 4.2684555556e+01,
lng: 1.4292533333e+02,
content:'Saddle = 706.799988 pos = 42.6846,142.9253 diff = 174.700012'
});
data_peak.push({
lat: 4.3017666667e+01,
lng: 1.4260277778e+02,
cert : true,
content:'Name = JA8/KK-043(JA8/KK-043) peak = 1127.199951 pos = 43.0177,142.6028 diff = 419.099976'
});
data_saddle.push({
lat: 4.3011666667e+01,
lng: 1.4266077778e+02,
content:'Saddle = 708.099976 pos = 43.0117,142.6608 diff = 419.099976'
});
data_peak.push({
lat: 4.3010888889e+01,
lng: 1.4262844444e+02,
cert : true,
content:'Name = JA8/KK-044(JA8/KK-044) peak = 1105.599976 pos = 43.0109,142.6284 diff = 197.599976'
});
data_saddle.push({
lat: 4.3019555556e+01,
lng: 1.4262022222e+02,
content:'Saddle = 908.000000 pos = 43.0196,142.6202 diff = 197.599976'
});
data_peak.push({
lat: 4.3007555556e+01,
lng: 1.4257488889e+02,
cert : true,
content:'Name = JA8/KK-045(JA8/KK-045) peak = 1080.800049 pos = 43.0076,142.5749 diff = 167.800049'
});
data_saddle.push({
lat: 4.3007888889e+01,
lng: 1.4258555556e+02,
content:'Saddle = 913.000000 pos = 43.0079,142.5856 diff = 167.800049'
});
data_peak.push({
lat: 4.2801000000e+01,
lng: 1.4244822222e+02,
cert : true,
content:'Name = JA8/HD-051(JA8/HD-051) peak = 963.500000 pos = 42.8010,142.4482 diff = 239.200012'
});
data_saddle.push({
lat: 4.2806444445e+01,
lng: 1.4246100000e+02,
content:'Saddle = 724.299988 pos = 42.8064,142.4610 diff = 239.200012'
});
data_peak.push({
lat: 4.3052000000e+01,
lng: 1.4274900000e+02,
cert : true,
content:'Name = JA8/TC-063(JA8/TC-063) peak = 1096.400024 pos = 43.0520,142.7490 diff = 310.800049'
});
data_saddle.push({
lat: 4.3030333334e+01,
lng: 1.4275055556e+02,
content:'Saddle = 785.599976 pos = 43.0303,142.7506 diff = 310.800049'
});
data_peak.push({
lat: 4.2782444445e+01,
lng: 1.4250722222e+02,
cert : true,
content:'Name = JA8/HD-033(JA8/HD-033) peak = 1348.599976 pos = 42.7824,142.5072 diff = 561.899963'
});
data_saddle.push({
lat: 4.2814888889e+01,
lng: 1.4255466667e+02,
content:'Saddle = 786.700012 pos = 42.8149,142.5547 diff = 561.899963'
});
data_peak.push({
lat: 4.2756888889e+01,
lng: 1.4245022222e+02,
cert : true,
content:'Name = JA8/HD-043(JA8/HD-043) peak = 1092.699951 pos = 42.7569,142.4502 diff = 229.299927'
});
data_saddle.push({
lat: 4.2764000000e+01,
lng: 1.4245600000e+02,
content:'Saddle = 863.400024 pos = 42.7640,142.4560 diff = 229.299927'
});
data_peak.push({
lat: 4.2772333334e+01,
lng: 1.4244711111e+02,
cert : false,
content:' Peak = 1055.900024 pos = 42.7723,142.4471 diff = 159.600037'
});
data_saddle.push({
lat: 4.2773222223e+01,
lng: 1.4245033333e+02,
content:'Saddle = 896.299988 pos = 42.7732,142.4503 diff = 159.600037'
});
data_peak.push({
lat: 4.2786000000e+01,
lng: 1.4253477778e+02,
cert : true,
content:'Name = JA8/HD-040(JA8/HD-040) peak = 1121.400024 pos = 42.7860,142.5348 diff = 207.500000'
});
data_saddle.push({
lat: 4.2788000000e+01,
lng: 1.4252844444e+02,
content:'Saddle = 913.900024 pos = 42.7880,142.5284 diff = 207.500000'
});
data_peak.push({
lat: 4.2970444445e+01,
lng: 1.4259777778e+02,
cert : true,
content:'Name = JA8/KK-029(JA8/KK-029) peak = 1344.599976 pos = 42.9704,142.5978 diff = 512.299988'
});
data_saddle.push({
lat: 4.2985777778e+01,
lng: 1.4265211111e+02,
content:'Saddle = 832.299988 pos = 42.9858,142.6521 diff = 512.299988'
});
data_peak.push({
lat: 4.2941777778e+01,
lng: 1.4257088889e+02,
cert : true,
content:'Name = JA8/KK-038(JA8/KK-038) peak = 1191.400024 pos = 42.9418,142.5709 diff = 288.700012'
});
data_saddle.push({
lat: 4.2958555556e+01,
lng: 1.4258366667e+02,
content:'Saddle = 902.700012 pos = 42.9586,142.5837 diff = 288.700012'
});
data_peak.push({
lat: 4.2754333334e+01,
lng: 1.4289211111e+02,
cert : true,
content:'Name = JA8/TC-066(JA8/TC-066) peak = 1094.199951 pos = 42.7543,142.8921 diff = 190.499939'
});
data_saddle.push({
lat: 4.2756333334e+01,
lng: 1.4286533333e+02,
content:'Saddle = 903.700012 pos = 42.7563,142.8653 diff = 190.499939'
});
data_peak.push({
lat: 4.2792888889e+01,
lng: 1.4258155556e+02,
cert : true,
content:'Name = JA8/HD-044(JA8/HD-044) peak = 1081.500000 pos = 42.7929,142.5816 diff = 169.099976'
});
data_saddle.push({
lat: 4.2789111112e+01,
lng: 1.4258988889e+02,
content:'Saddle = 912.400024 pos = 42.7891,142.5899 diff = 169.099976'
});
data_peak.push({
lat: 4.2948000000e+01,
lng: 1.4263555556e+02,
cert : false,
content:' Peak = 1188.699951 pos = 42.9480,142.6356 diff = 271.599976'
});
data_saddle.push({
lat: 4.2939111112e+01,
lng: 1.4264722222e+02,
content:'Saddle = 917.099976 pos = 42.9391,142.6472 diff = 271.599976'
});
data_peak.push({
lat: 4.2848777778e+01,
lng: 1.4288500000e+02,
cert : false,
content:' Peak = 1201.599976 pos = 42.8488,142.8850 diff = 274.500000'
});
data_saddle.push({
lat: 4.2852222223e+01,
lng: 1.4284833333e+02,
content:'Saddle = 927.099976 pos = 42.8522,142.8483 diff = 274.500000'
});
data_peak.push({
lat: 4.2889333334e+01,
lng: 1.4261500000e+02,
cert : true,
content:'Name = JA8/HD-037(JA8/HD-037) peak = 1211.800049 pos = 42.8893,142.6150 diff = 250.900024'
});
data_saddle.push({
lat: 4.2888666667e+01,
lng: 1.4262355556e+02,
content:'Saddle = 960.900024 pos = 42.8887,142.6236 diff = 250.900024'
});
data_peak.push({
lat: 4.2857333334e+01,
lng: 1.4260466667e+02,
cert : true,
content:'Name = JA8/HD-028(JA8/HD-028) peak = 1384.900024 pos = 42.8573,142.6047 diff = 312.599976'
});
data_saddle.push({
lat: 4.2851777778e+01,
lng: 1.4261311111e+02,
content:'Saddle = 1072.300049 pos = 42.8518,142.6131 diff = 312.599976'
});
data_peak.push({
lat: 4.3009888889e+01,
lng: 1.4272766667e+02,
cert : true,
content:'Name = JA8/HD-029(JA8/HD-029) peak = 1382.199951 pos = 43.0099,142.7277 diff = 276.899902'
});
data_saddle.push({
lat: 4.2971222223e+01,
lng: 1.4275222222e+02,
content:'Saddle = 1105.300049 pos = 42.9712,142.7522 diff = 276.899902'
});
data_peak.push({
lat: 4.3025111112e+01,
lng: 1.4270888889e+02,
cert : true,
content:'Name = JA8/KK-031(JA8/KK-031) peak = 1320.199951 pos = 43.0251,142.7089 diff = 209.399902'
});
data_saddle.push({
lat: 4.3019333334e+01,
lng: 1.4271688889e+02,
content:'Saddle = 1110.800049 pos = 43.0193,142.7169 diff = 209.399902'
});
data_peak.push({
lat: 4.2964000000e+01,
lng: 1.4274266667e+02,
cert : true,
content:'Name = JA8/HD-025(JA8/HD-025) peak = 1444.300049 pos = 42.9640,142.7427 diff = 283.900024'
});
data_saddle.push({
lat: 4.2956666667e+01,
lng: 1.4275488889e+02,
content:'Saddle = 1160.400024 pos = 42.9567,142.7549 diff = 283.900024'
});
data_peak.push({
lat: 4.2952000000e+01,
lng: 1.4271566667e+02,
cert : true,
content:'Name = JA8/HD-027(JA8/HD-027) peak = 1421.699951 pos = 42.9520,142.7157 diff = 175.199951'
});
data_saddle.push({
lat: 4.2955444445e+01,
lng: 1.4272077778e+02,
content:'Saddle = 1246.500000 pos = 42.9554,142.7208 diff = 175.199951'
});
data_peak.push({
lat: 4.2942555556e+01,
lng: 1.4275933333e+02,
cert : true,
content:'Name = JA8/HD-019(JA8/HD-019) peak = 1531.699951 pos = 42.9426,142.7593 diff = 313.500000'
});
data_saddle.push({
lat: 4.2928888889e+01,
lng: 1.4277466667e+02,
content:'Saddle = 1218.199951 pos = 42.9289,142.7747 diff = 313.500000'
});
data_peak.push({
lat: 4.2722333334e+01,
lng: 1.4261366667e+02,
cert : true,
content:'Name = JA8/HD-021(JA8/HD-021) peak = 1517.400024 pos = 42.7223,142.6137 diff = 277.300049'
});
data_saddle.push({
lat: 4.2727222223e+01,
lng: 1.4263688889e+02,
content:'Saddle = 1240.099976 pos = 42.7272,142.6369 diff = 277.300049'
});
data_peak.push({
lat: 4.2810888889e+01,
lng: 1.4263522222e+02,
cert : false,
content:' Peak = 1503.900024 pos = 42.8109,142.6352 diff = 247.000000'
});
data_saddle.push({
lat: 4.2816666667e+01,
lng: 1.4264077778e+02,
content:'Saddle = 1256.900024 pos = 42.8167,142.6408 diff = 247.000000'
});
data_peak.push({
lat: 4.2835555556e+01,
lng: 1.4262466667e+02,
cert : true,
content:'Name = JA8/HD-023(JA8/HD-023) peak = 1491.099976 pos = 42.8356,142.6247 diff = 198.599976'
});
data_saddle.push({
lat: 4.2824777778e+01,
lng: 1.4263977778e+02,
content:'Saddle = 1292.500000 pos = 42.8248,142.6398 diff = 198.599976'
});
data_peak.push({
lat: 4.2892111112e+01,
lng: 1.4267911111e+02,
cert : true,
content:'Name = JA8/HD-010(JA8/HD-010) peak = 1750.000000 pos = 42.8921,142.6791 diff = 431.900024'
});
data_saddle.push({
lat: 4.2884333334e+01,
lng: 1.4276577778e+02,
content:'Saddle = 1318.099976 pos = 42.8843,142.7658 diff = 431.900024'
});
data_peak.push({
lat: 4.2899555556e+01,
lng: 1.4274066667e+02,
cert : true,
content:'Name = JA8/HD-014(JA8/HD-014) peak = 1694.400024 pos = 42.8996,142.7407 diff = 156.800049'
});
data_saddle.push({
lat: 4.2895888889e+01,
lng: 1.4269655556e+02,
content:'Saddle = 1537.599976 pos = 42.8959,142.6966 diff = 156.800049'
});
data_peak.push({
lat: 4.2800888889e+01,
lng: 1.4277377778e+02,
cert : true,
content:'Name = JA8/TC-031(JA8/TC-031) peak = 1470.699951 pos = 42.8009,142.7738 diff = 150.399902'
});
data_saddle.push({
lat: 4.2791333334e+01,
lng: 1.4276188889e+02,
content:'Saddle = 1320.300049 pos = 42.7913,142.7619 diff = 150.399902'
});
data_peak.push({
lat: 4.2779111112e+01,
lng: 1.4261711111e+02,
cert : true,
content:'Name = JA8/HD-018(JA8/HD-018) peak = 1590.199951 pos = 42.7791,142.6171 diff = 237.299927'
});
data_saddle.push({
lat: 4.2773000000e+01,
lng: 1.4263411111e+02,
content:'Saddle = 1352.900024 pos = 42.7730,142.6341 diff = 237.299927'
});
data_peak.push({
lat: 4.2754888889e+01,
lng: 1.4264444444e+02,
cert : true,
content:'Name = JA8/HD-015(JA8/HD-015) peak = 1632.599976 pos = 42.7549,142.6444 diff = 241.500000'
});
data_saddle.push({
lat: 4.2751222223e+01,
lng: 1.4265988889e+02,
content:'Saddle = 1391.099976 pos = 42.7512,142.6599 diff = 241.500000'
});
data_peak.push({
lat: 4.2666777778e+01,
lng: 1.4272044444e+02,
cert : true,
content:'Name = JA8/HD-008(JA8/HD-008) peak = 1778.400024 pos = 42.6668,142.7204 diff = 325.500000'
});
data_saddle.push({
lat: 4.2666777778e+01,
lng: 1.4272777778e+02,
content:'Saddle = 1452.900024 pos = 42.6668,142.7278 diff = 325.500000'
});
data_peak.push({
lat: 4.2825666667e+01,
lng: 1.4267533333e+02,
cert : true,
content:'Name = Chirorodake(JA8/HD-005) peak = 1878.900024 pos = 42.8257,142.6753 diff = 397.900024'
});
data_saddle.push({
lat: 4.2813555556e+01,
lng: 1.4272566667e+02,
content:'Saddle = 1481.000000 pos = 42.8136,142.7257 diff = 397.900024'
});
data_peak.push({
lat: 4.2869000000e+01,
lng: 1.4278533333e+02,
cert : true,
content:'Name = Memurodake(JA8/TC-013) peak = 1753.199951 pos = 42.8690,142.7853 diff = 265.299927'
});
data_saddle.push({
lat: 4.2858222223e+01,
lng: 1.4277933333e+02,
content:'Saddle = 1487.900024 pos = 42.8582,142.7793 diff = 265.299927'
});
data_peak.push({
lat: 4.2844444445e+01,
lng: 1.4274044444e+02,
cert : true,
content:'Name = JA8/HD-012(JA8/HD-012) peak = 1724.300049 pos = 42.8444,142.7404 diff = 213.000000'
});
data_saddle.push({
lat: 4.2838111112e+01,
lng: 1.4273488889e+02,
content:'Saddle = 1511.300049 pos = 42.8381,142.7349 diff = 213.000000'
});
data_peak.push({
lat: 4.2695555556e+01,
lng: 1.4285933333e+02,
cert : true,
content:'Name = Tokachiporoshiridake(JA8/TC-010) peak = 1841.300049 pos = 42.6956,142.8593 diff = 353.600098'
});
data_saddle.push({
lat: 4.2690666667e+01,
lng: 1.4282144444e+02,
content:'Saddle = 1487.699951 pos = 42.6907,142.8214 diff = 353.600098'
});
data_peak.push({
lat: 4.2689444445e+01,
lng: 1.4275777778e+02,
cert : true,
content:'Name = Esaomantottabetsudake(JA8/TC-006) peak = 1901.699951 pos = 42.6894,142.7578 diff = 408.199951'
});
data_saddle.push({
lat: 4.2705000001e+01,
lng: 1.4275677778e+02,
content:'Saddle = 1493.500000 pos = 42.7050,142.7568 diff = 408.199951'
});
data_peak.push({
lat: 4.2666777778e+01,
lng: 1.4273933333e+02,
cert : false,
content:' Peak = 1736.699951 pos = 42.6668,142.7393 diff = 182.599976'
});
data_saddle.push({
lat: 4.2666777778e+01,
lng: 1.4274688889e+02,
content:'Saddle = 1554.099976 pos = 42.6668,142.7469 diff = 182.599976'
});
data_peak.push({
lat: 4.2693777778e+01,
lng: 1.4279666667e+02,
cert : true,
content:'Name = Satsunaidake(JA8/TC-007) peak = 1890.400024 pos = 42.6938,142.7967 diff = 208.000000'
});
data_saddle.push({
lat: 4.2690444445e+01,
lng: 1.4278088889e+02,
content:'Saddle = 1682.400024 pos = 42.6904,142.7809 diff = 208.000000'
});
data_peak.push({
lat: 4.2775888889e+01,
lng: 1.4276555556e+02,
cert : false,
content:' Peak = 1790.800049 pos = 42.7759,142.7656 diff = 250.100098'
});
data_saddle.push({
lat: 4.2771222223e+01,
lng: 1.4274355556e+02,
content:'Saddle = 1540.699951 pos = 42.7712,142.7436 diff = 250.100098'
});
data_peak.push({
lat: 4.2763555556e+01,
lng: 1.4278233333e+02,
cert : true,
content:'Name = JA8/TC-015(JA8/TC-015) peak = 1730.400024 pos = 42.7636,142.7823 diff = 157.700073'
});
data_saddle.push({
lat: 4.2768888889e+01,
lng: 1.4277466667e+02,
content:'Saddle = 1572.699951 pos = 42.7689,142.7747 diff = 157.700073'
});
data_peak.push({
lat: 4.2791888889e+01,
lng: 1.4272155556e+02,
cert : true,
content:'Name = JA8/TC-016(JA8/TC-016) peak = 1711.099976 pos = 42.7919,142.7216 diff = 158.400024'
});
data_saddle.push({
lat: 4.2785333334e+01,
lng: 1.4271733333e+02,
content:'Saddle = 1552.699951 pos = 42.7853,142.7173 diff = 158.400024'
});
data_peak.push({
lat: 4.2772333334e+01,
lng: 1.4270644444e+02,
cert : true,
content:'Name = JA8/HD-003(JA8/HD-003) peak = 1964.400024 pos = 42.7723,142.7064 diff = 231.599976'
});
data_saddle.push({
lat: 4.2730888889e+01,
lng: 1.4269155556e+02,
content:'Saddle = 1732.800049 pos = 42.7309,142.6916 diff = 231.599976'
});
data_peak.push({
lat: 4.2738666667e+01,
lng: 1.4269500000e+02,
cert : true,
content:'Name = Tottabetsudake(JA8/TC-004) peak = 1956.900024 pos = 42.7387,142.6950 diff = 184.599976'
});
data_saddle.push({
lat: 4.2758444445e+01,
lng: 1.4269188889e+02,
content:'Saddle = 1772.300049 pos = 42.7584,142.6919 diff = 184.599976'
});
data_peak.push({
lat: 4.3964444444e+01,
lng: 1.4288800000e+02,
cert : true,
content:'Name = Teshiodake(JA8/OH-004) peak = 1556.699951 pos = 43.9644,142.8880 diff = 903.199951'
});
data_saddle.push({
lat: 4.3895444444e+01,
lng: 1.4299955556e+02,
content:'Saddle = 653.500000 pos = 43.8954,142.9996 diff = 903.199951'
});
data_peak.push({
lat: 4.4000000000e+01,
lng: 1.4275611111e+02,
cert : false,
content:' Peak = 931.799988 pos = 44.0000,142.7561 diff = 175.700012'
});
data_saddle.push({
lat: 4.4000000000e+01,
lng: 1.4276144444e+02,
content:'Saddle = 756.099976 pos = 44.0000,142.7614 diff = 175.700012'
});
data_peak.push({
lat: 4.4000000000e+01,
lng: 1.4279077778e+02,
cert : false,
content:' Peak = 1064.300049 pos = 44.0000,142.7908 diff = 296.800049'
});
data_saddle.push({
lat: 4.4000000000e+01,
lng: 1.4281144444e+02,
content:'Saddle = 767.500000 pos = 44.0000,142.8114 diff = 296.800049'
});
data_peak.push({
lat: 4.3990111111e+01,
lng: 1.4281333333e+02,
cert : true,
content:'Name = JA8/KK-048(JA8/KK-048) peak = 1021.299988 pos = 43.9901,142.8133 diff = 243.500000'
});
data_saddle.push({
lat: 4.3999888889e+01,
lng: 1.4285988889e+02,
content:'Saddle = 777.799988 pos = 43.9999,142.8599 diff = 243.500000'
});
data_peak.push({
lat: 4.4000000000e+01,
lng: 1.4283955556e+02,
cert : false,
content:' Peak = 956.799988 pos = 44.0000,142.8396 diff = 159.700012'
});
data_saddle.push({
lat: 4.4000000000e+01,
lng: 1.4282911111e+02,
content:'Saddle = 797.099976 pos = 44.0000,142.8291 diff = 159.700012'
});
data_peak.push({
lat: 4.3897111111e+01,
lng: 1.4282655556e+02,
cert : true,
content:'Name = JA8/KK-047(JA8/KK-047) peak = 1024.300049 pos = 43.8971,142.8266 diff = 240.800049'
});
data_saddle.push({
lat: 4.3903333333e+01,
lng: 1.4281955556e+02,
content:'Saddle = 783.500000 pos = 43.9033,142.8196 diff = 240.800049'
});
data_peak.push({
lat: 4.3929777778e+01,
lng: 1.4283022222e+02,
cert : true,
content:'Name = JA8/KK-036(JA8/KK-036) peak = 1215.500000 pos = 43.9298,142.8302 diff = 212.900024'
});
data_saddle.push({
lat: 4.3935000000e+01,
lng: 1.4283933333e+02,
content:'Saddle = 1002.599976 pos = 43.9350,142.8393 diff = 212.900024'
});
data_peak.push({
lat: 4.3976555556e+01,
lng: 1.4288677778e+02,
cert : true,
content:'Name = JA8/KK-024(JA8/KK-024) peak = 1539.300049 pos = 43.9766,142.8868 diff = 188.400024'
});
data_saddle.push({
lat: 4.3971666667e+01,
lng: 1.4289066667e+02,
content:'Saddle = 1350.900024 pos = 43.9717,142.8907 diff = 188.400024'
});
data_peak.push({
lat: 4.3296777778e+01,
lng: 1.4298488889e+02,
cert : true,
content:'Name = JA8/TC-041(JA8/TC-041) peak = 1310.800049 pos = 43.2968,142.9849 diff = 654.800049'
});
data_saddle.push({
lat: 4.3338444445e+01,
lng: 1.4299988889e+02,
content:'Saddle = 656.000000 pos = 43.3384,142.9999 diff = 654.800049'
});
data_peak.push({
lat: 4.3332888889e+01,
lng: 1.4299988889e+02,
cert : false,
content:' Peak = 1050.699951 pos = 43.3329,142.9999 diff = 289.799927'
});
data_saddle.push({
lat: 4.3330000000e+01,
lng: 1.4299988889e+02,
content:'Saddle = 760.900024 pos = 43.3300,142.9999 diff = 289.799927'
});
data_peak.push({
lat: 4.3349000000e+01,
lng: 1.4299988889e+02,
cert : false,
content:' Peak = 1024.000000 pos = 43.3490,142.9999 diff = 366.299988'
});
data_saddle.push({
lat: 4.3386000000e+01,
lng: 1.4299933333e+02,
content:'Saddle = 657.700012 pos = 43.3860,142.9993 diff = 366.299988'
});
data_peak.push({
lat: 4.3370333334e+01,
lng: 1.4299822222e+02,
cert : false,
content:' Peak = 990.900024 pos = 43.3703,142.9982 diff = 230.400024'
});
data_saddle.push({
lat: 4.3367222222e+01,
lng: 1.4299988889e+02,
content:'Saddle = 760.500000 pos = 43.3672,142.9999 diff = 230.400024'
});
data_peak.push({
lat: 4.3779888889e+01,
lng: 1.4298522222e+02,
cert : true,
content:'Name = Niseikaushyuppeyama(JA8/KK-013) peak = 1880.599976 pos = 43.7799,142.9852 diff = 1201.199951'
});
data_saddle.push({
lat: 4.3715444445e+01,
lng: 1.4299988889e+02,
content:'Saddle = 679.400024 pos = 43.7154,142.9999 diff = 1201.199951'
});
data_peak.push({
lat: 4.3854888889e+01,
lng: 1.4297555556e+02,
cert : false,
content:' Peak = 1010.900024 pos = 43.8549,142.9756 diff = 266.400024'
});
data_saddle.push({
lat: 4.3853111111e+01,
lng: 1.4299977778e+02,
content:'Saddle = 744.500000 pos = 43.8531,142.9998 diff = 266.400024'
});
data_peak.push({
lat: 4.3874000000e+01,
lng: 1.4298677778e+02,
cert : false,
content:' Peak = 938.700012 pos = 43.8740,142.9868 diff = 152.400024'
});
data_saddle.push({
lat: 4.3873111111e+01,
lng: 1.4299988889e+02,
content:'Saddle = 786.299988 pos = 43.8731,142.9999 diff = 152.400024'
});
data_peak.push({
lat: 4.3759333333e+01,
lng: 1.4299988889e+02,
cert : false,
content:' Peak = 1660.800049 pos = 43.7593,142.9999 diff = 286.000000'
});
data_saddle.push({
lat: 4.3764333333e+01,
lng: 1.4299988889e+02,
content:'Saddle = 1374.800049 pos = 43.7643,142.9999 diff = 286.000000'
});
data_peak.push({
lat: 4.3173444445e+01,
lng: 1.4278088889e+02,
cert : true,
content:'Name = Sahorodake(JA8/TC-072) peak = 1059.199951 pos = 43.1734,142.7809 diff = 345.799927'
});
data_saddle.push({
lat: 4.3245111111e+01,
lng: 1.4273711111e+02,
content:'Saddle = 713.400024 pos = 43.2451,142.7371 diff = 345.799927'
});
data_peak.push({
lat: 4.3392333334e+01,
lng: 1.4299977778e+02,
cert : false,
content:' Peak = 1062.599976 pos = 43.3923,142.9998 diff = 334.000000'
});
data_saddle.push({
lat: 4.3398555556e+01,
lng: 1.4299988889e+02,
content:'Saddle = 728.599976 pos = 43.3986,142.9999 diff = 334.000000'
});
data_peak.push({
lat: 4.3327222222e+01,
lng: 1.4286877778e+02,
cert : true,
content:'Name = JA8/TC-081(JA8/TC-081) peak = 999.900024 pos = 43.3272,142.8688 diff = 269.600037'
});
data_saddle.push({
lat: 4.3318111111e+01,
lng: 1.4284866667e+02,
content:'Saddle = 730.299988 pos = 43.3181,142.8487 diff = 269.600037'
});
data_peak.push({
lat: 4.3334444445e+01,
lng: 1.4289188889e+02,
cert : false,
content:' Peak = 990.799988 pos = 43.3344,142.8919 diff = 258.799988'
});
data_saddle.push({
lat: 4.3328888889e+01,
lng: 1.4287877778e+02,
content:'Saddle = 732.000000 pos = 43.3289,142.8788 diff = 258.799988'
});
data_peak.push({
lat: 4.3439000000e+01,
lng: 1.4287755556e+02,
cert : false,
content:' Peak = 912.099976 pos = 43.4390,142.8776 diff = 156.000000'
});
data_saddle.push({
lat: 4.3443000000e+01,
lng: 1.4287355556e+02,
content:'Saddle = 756.099976 pos = 43.4430,142.8736 diff = 156.000000'
});
data_peak.push({
lat: 4.3403444445e+01,
lng: 1.4299466667e+02,
cert : false,
content:' Peak = 1054.099976 pos = 43.4034,142.9947 diff = 270.299988'
});
data_saddle.push({
lat: 4.3415111111e+01,
lng: 1.4299988889e+02,
content:'Saddle = 783.799988 pos = 43.4151,142.9999 diff = 270.299988'
});
data_peak.push({
lat: 4.3387222222e+01,
lng: 1.4283855556e+02,
cert : true,
content:'Name = JA8/TC-064(JA8/TC-064) peak = 1092.900024 pos = 43.3872,142.8386 diff = 266.100037'
});
data_saddle.push({
lat: 4.3369222222e+01,
lng: 1.4283022222e+02,
content:'Saddle = 826.799988 pos = 43.3692,142.8302 diff = 266.100037'
});
data_peak.push({
lat: 4.3472555556e+01,
lng: 1.4297666667e+02,
cert : true,
content:'Name = JA8/TC-036(JA8/TC-036) peak = 1354.500000 pos = 43.4726,142.9767 diff = 488.500000'
});
data_saddle.push({
lat: 4.3488000000e+01,
lng: 1.4299988889e+02,
content:'Saddle = 866.000000 pos = 43.4880,142.9999 diff = 488.500000'
});
data_peak.push({
lat: 4.3418777778e+01,
lng: 1.4299700000e+02,
cert : false,
content:' Peak = 1080.900024 pos = 43.4188,142.9970 diff = 165.400024'
});
data_saddle.push({
lat: 4.3426000000e+01,
lng: 1.4299977778e+02,
content:'Saddle = 915.500000 pos = 43.4260,142.9998 diff = 165.400024'
});
data_peak.push({
lat: 4.3428333334e+01,
lng: 1.4299288889e+02,
cert : false,
content:' Peak = 1180.000000 pos = 43.4283,142.9929 diff = 241.700012'
});
data_saddle.push({
lat: 4.3434777778e+01,
lng: 1.4299988889e+02,
content:'Saddle = 938.299988 pos = 43.4348,142.9999 diff = 241.700012'
});
data_peak.push({
lat: 4.3399888889e+01,
lng: 1.4290777778e+02,
cert : true,
content:'Name = JA8/TC-060(JA8/TC-060) peak = 1153.699951 pos = 43.3999,142.9078 diff = 191.799927'
});
data_saddle.push({
lat: 4.3405333334e+01,
lng: 1.4292000000e+02,
content:'Saddle = 961.900024 pos = 43.4053,142.9200 diff = 191.799927'
});
data_peak.push({
lat: 4.3436333334e+01,
lng: 1.4293088889e+02,
cert : true,
content:'Name = JA8/TC-051(JA8/TC-051) peak = 1241.699951 pos = 43.4363,142.9309 diff = 198.299927'
});
data_saddle.push({
lat: 4.3428666667e+01,
lng: 1.4293511111e+02,
content:'Saddle = 1043.400024 pos = 43.4287,142.9351 diff = 198.299927'
});
data_peak.push({
lat: 4.3423777778e+01,
lng: 1.4295111111e+02,
cert : false,
content:' Peak = 1264.000000 pos = 43.4238,142.9511 diff = 186.699951'
});
data_saddle.push({
lat: 4.3446555556e+01,
lng: 1.4298744444e+02,
content:'Saddle = 1077.300049 pos = 43.4466,142.9874 diff = 186.699951'
});
data_peak.push({
lat: 4.3348000000e+01,
lng: 1.4281822222e+02,
cert : false,
content:' Peak = 1018.900024 pos = 43.3480,142.8182 diff = 150.600037'
});
data_saddle.push({
lat: 4.3352666667e+01,
lng: 1.4276244444e+02,
content:'Saddle = 868.299988 pos = 43.3527,142.7624 diff = 150.600037'
});
data_peak.push({
lat: 4.3494555556e+01,
lng: 1.4299988889e+02,
cert : false,
content:' Peak = 1230.000000 pos = 43.4946,142.9999 diff = 263.299988'
});
data_saddle.push({
lat: 4.3498000000e+01,
lng: 1.4299988889e+02,
content:'Saddle = 966.700012 pos = 43.4980,142.9999 diff = 263.299988'
});
data_peak.push({
lat: 4.3685000000e+01,
lng: 1.4274022222e+02,
cert : false,
content:' Peak = 1247.000000 pos = 43.6850,142.7402 diff = 229.200012'
});
data_saddle.push({
lat: 4.3697111111e+01,
lng: 1.4277233333e+02,
content:'Saddle = 1017.799988 pos = 43.6971,142.7723 diff = 229.200012'
});
data_peak.push({
lat: 4.3339666667e+01,
lng: 1.4263222222e+02,
cert : true,
content:'Name = JA8/KK-025(JA8/KK-025) peak = 1455.099976 pos = 43.3397,142.6322 diff = 371.699951'
});
data_saddle.push({
lat: 4.3360000000e+01,
lng: 1.4265233333e+02,
content:'Saddle = 1083.400024 pos = 43.3600,142.6523 diff = 371.699951'
});
data_peak.push({
lat: 4.3516777778e+01,
lng: 1.4299700000e+02,
cert : false,
content:' Peak = 1408.400024 pos = 43.5168,142.9970 diff = 178.800049'
});
data_saddle.push({
lat: 4.3522222222e+01,
lng: 1.4299988889e+02,
content:'Saddle = 1229.599976 pos = 43.5222,142.9999 diff = 178.800049'
});
data_peak.push({
lat: 4.3560555556e+01,
lng: 1.4299988889e+02,
cert : false,
content:' Peak = 1520.099976 pos = 43.5606,142.9999 diff = 261.199951'
});
data_saddle.push({
lat: 4.3550222222e+01,
lng: 1.4299988889e+02,
content:'Saddle = 1258.900024 pos = 43.5502,142.9999 diff = 261.199951'
});
data_peak.push({
lat: 4.3553888889e+01,
lng: 1.4299988889e+02,
cert : false,
content:' Peak = 1491.599976 pos = 43.5539,142.9999 diff = 167.500000'
});
data_saddle.push({
lat: 4.3556888889e+01,
lng: 1.4299988889e+02,
content:'Saddle = 1324.099976 pos = 43.5569,142.9999 diff = 167.500000'
});
data_peak.push({
lat: 4.3360777778e+01,
lng: 1.4271944444e+02,
cert : true,
content:'Name = JA8/KK-020(JA8/KK-020) peak = 1661.400024 pos = 43.3608,142.7194 diff = 392.400024'
});
data_saddle.push({
lat: 4.3369333334e+01,
lng: 1.4271411111e+02,
content:'Saddle = 1269.000000 pos = 43.3693,142.7141 diff = 392.400024'
});
data_peak.push({
lat: 4.3530333334e+01,
lng: 1.4299988889e+02,
cert : false,
content:' Peak = 1730.599976 pos = 43.5303,142.9999 diff = 442.799927'
});
data_saddle.push({
lat: 4.3533666667e+01,
lng: 1.4298644444e+02,
content:'Saddle = 1287.800049 pos = 43.5337,142.9864 diff = 442.799927'
});
data_peak.push({
lat: 4.3546222222e+01,
lng: 1.4299988889e+02,
cert : false,
content:' Peak = 1453.300049 pos = 43.5462,142.9999 diff = 161.800049'
});
data_saddle.push({
lat: 4.3544000000e+01,
lng: 1.4299988889e+02,
content:'Saddle = 1291.500000 pos = 43.5440,142.9999 diff = 161.800049'
});
data_peak.push({
lat: 4.3539333334e+01,
lng: 1.4299988889e+02,
cert : false,
content:' Peak = 1613.599976 pos = 43.5393,142.9999 diff = 286.400024'
});
data_saddle.push({
lat: 4.3535777778e+01,
lng: 1.4299988889e+02,
content:'Saddle = 1327.199951 pos = 43.5358,142.9999 diff = 286.400024'
});
data_peak.push({
lat: 4.3381888889e+01,
lng: 1.4260577778e+02,
cert : true,
content:'Name = JA8/KK-023(JA8/KK-023) peak = 1624.500000 pos = 43.3819,142.6058 diff = 265.300049'
});
data_saddle.push({
lat: 4.3385888889e+01,
lng: 1.4261822222e+02,
content:'Saddle = 1359.199951 pos = 43.3859,142.6182 diff = 265.300049'
});
data_peak.push({
lat: 4.3417888889e+01,
lng: 1.4268622222e+02,
cert : true,
content:'Name = Tokachidake(JA8/KK-005) peak = 2076.399902 pos = 43.4179,142.6862 diff = 671.799927'
});
data_saddle.push({
lat: 4.3482111111e+01,
lng: 1.4276644444e+02,
content:'Saddle = 1404.599976 pos = 43.4821,142.7664 diff = 671.799927'
});
data_peak.push({
lat: 4.3470222222e+01,
lng: 1.4275155556e+02,
cert : true,
content:'Name = Oputateshikeyama(JA8/TC-003) peak = 2011.400024 pos = 43.4702,142.7516 diff = 357.200073'
});
data_saddle.push({
lat: 4.3452222222e+01,
lng: 1.4272300000e+02,
content:'Saddle = 1654.199951 pos = 43.4522,142.7230 diff = 357.200073'
});
data_peak.push({
lat: 4.3393777778e+01,
lng: 1.4263500000e+02,
cert : true,
content:'Name = Furanodake(JA8/KK-011) peak = 1911.099976 pos = 43.3938,142.6350 diff = 204.400024'
});
data_saddle.push({
lat: 4.3395111111e+01,
lng: 1.4264333333e+02,
content:'Saddle = 1706.699951 pos = 43.3951,142.6433 diff = 204.400024'
});
data_peak.push({
lat: 4.3452666667e+01,
lng: 1.4271355556e+02,
cert : true,
content:'Name = JA8/KK-012(JA8/KK-012) peak = 1887.800049 pos = 43.4527,142.7136 diff = 171.300049'
});
data_saddle.push({
lat: 4.3447000000e+01,
lng: 1.4271277778e+02,
content:'Saddle = 1716.500000 pos = 43.4470,142.7128 diff = 171.300049'
});
data_peak.push({
lat: 4.3439888889e+01,
lng: 1.4270633333e+02,
cert : true,
content:'Name = Bieidake(JA8/KK-006) peak = 2051.300049 pos = 43.4399,142.7063 diff = 264.600098'
});
data_saddle.push({
lat: 4.3428222222e+01,
lng: 1.4270277778e+02,
content:'Saddle = 1786.699951 pos = 43.4282,142.7028 diff = 264.600098'
});
data_peak.push({
lat: 4.3494222222e+01,
lng: 1.4277822222e+02,
cert : true,
content:'Name = JA8/TC-019(JA8/TC-019) peak = 1667.900024 pos = 43.4942,142.7782 diff = 184.099976'
});
data_saddle.push({
lat: 4.3500444445e+01,
lng: 1.4279644444e+02,
content:'Saddle = 1483.800049 pos = 43.5004,142.7964 diff = 184.099976'
});
data_peak.push({
lat: 4.3510222222e+01,
lng: 1.4281066667e+02,
cert : true,
content:'Name = JA8/TC-017(JA8/TC-017) peak = 1706.300049 pos = 43.5102,142.8107 diff = 197.700073'
});
data_saddle.push({
lat: 4.3516888889e+01,
lng: 1.4281488889e+02,
content:'Saddle = 1508.599976 pos = 43.5169,142.8149 diff = 197.700073'
});
data_peak.push({
lat: 4.3527111111e+01,
lng: 1.4284877778e+02,
cert : true,
content:'Name = Tomuraushiyama(JA8/TC-001) peak = 2140.500000 pos = 43.5271,142.8488 diff = 438.500000'
});
data_saddle.push({
lat: 4.3576000000e+01,
lng: 1.4289100000e+02,
content:'Saddle = 1702.000000 pos = 43.5760,142.8910 diff = 438.500000'
});
data_peak.push({
lat: 4.3565444445e+01,
lng: 1.4286133333e+02,
cert : true,
content:'Name = JA8/KK-009(JA8/KK-009) peak = 1952.500000 pos = 43.5654,142.8613 diff = 161.599976'
});
data_saddle.push({
lat: 4.3555222222e+01,
lng: 1.4285622222e+02,
content:'Saddle = 1790.900024 pos = 43.5552,142.8562 diff = 161.599976'
});
data_peak.push({
lat: 4.3591111111e+01,
lng: 1.4289444444e+02,
cert : true,
content:'Name = Chuubetsudake(JA8/KK-008) peak = 1962.300049 pos = 43.5911,142.8944 diff = 248.400024'
});
data_saddle.push({
lat: 4.3628666667e+01,
lng: 1.4290188889e+02,
content:'Saddle = 1713.900024 pos = 43.6287,142.9019 diff = 248.400024'
});
data_peak.push({
lat: 4.3698333333e+01,
lng: 1.4289700000e+02,
cert : true,
content:'Name = JA8/KK-004(JA8/KK-004) peak = 2124.300049 pos = 43.6983,142.8970 diff = 162.200073'
});
data_saddle.push({
lat: 4.3696000000e+01,
lng: 1.4289044444e+02,
content:'Saddle = 1962.099976 pos = 43.6960,142.8904 diff = 162.200073'
});
data_peak.push({
lat: 4.3692888889e+01,
lng: 1.4287988889e+02,
cert : true,
content:'Name = Taisetsuzan (Hokuchindake)(JA8/KK-002) peak = 2242.899902 pos = 43.6929,142.8799 diff = 201.099854'
});
data_saddle.push({
lat: 4.3681777778e+01,
lng: 1.4287400000e+02,
content:'Saddle = 2041.800049 pos = 43.6818,142.8740 diff = 201.099854'
});
data_peak.push({
lat: 4.3661222222e+01,
lng: 1.4290588889e+02,
cert : true,
content:'Name = Taisetsuzan (Hakuundake)(JA8/KK-003) peak = 2227.899902 pos = 43.6612,142.9059 diff = 169.500000'
});
data_saddle.push({
lat: 4.3673222222e+01,
lng: 1.4290088889e+02,
content:'Saddle = 2058.399902 pos = 43.6732,142.9009 diff = 169.500000'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:44,
       south:42.6667,
       east:143,
       west:140}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
