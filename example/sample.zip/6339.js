function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 4.2613333333e+01,
lng: 1.3994055556e+02,
cert : true,
content:'Name = Karibayama(JA8/SB-002) peak = 1516.400024 pos = 42.6133,139.9406 diff = 1516.400024'
});
data_saddle.push({
lat: 4.2666444444e+01,
lng: 1.3987377778e+02,
content:'Saddle = 0.000000 pos = 42.6664,139.8738 diff = 1516.400024'
});
data_peak.push({
lat: 4.2160333333e+01,
lng: 1.3944266667e+02,
cert : true,
content:'Name = Kamuiyama(JA8/HY-021) peak = 583.200012 pos = 42.1603,139.4427 diff = 583.200012'
});
data_saddle.push({
lat: 4.2051444444e+01,
lng: 1.3945077778e+02,
content:'Saddle = 0.000000 pos = 42.0514,139.4508 diff = 583.200012'
});
data_peak.push({
lat: 4.1509999999e+01,
lng: 1.3936700000e+02,
cert : true,
content:'Name = Eradake(JA8/OM-030) peak = 731.299988 pos = 41.5100,139.3670 diff = 731.299988'
});
data_saddle.push({
lat: 4.1494999999e+01,
lng: 1.3934666667e+02,
content:'Saddle = 0.000000 pos = 41.4950,139.3467 diff = 731.299988'
});
data_peak.push({
lat: 4.1439111110e+01,
lng: 1.4105277778e+02,
cert : true,
content:'Name = Hiuchidake(JA/AM-030) peak = 782.700012 pos = 41.4391,141.0528 diff = 782.700012'
});
data_saddle.push({
lat: 4.1397777777e+01,
lng: 1.4019755556e+02,
content:'Saddle = 0.000000 pos = 41.3978,140.1976 diff = 782.700012'
});
data_peak.push({
lat: 4.1360222221e+01,
lng: 1.3980100000e+02,
cert : false,
content:' Peak = 291.700012 pos = 41.3602,139.8010 diff = 291.700012'
});
data_saddle.push({
lat: 4.1352111110e+01,
lng: 1.3979922222e+02,
content:'Saddle = 0.000000 pos = 41.3521,139.7992 diff = 291.700012'
});
data_peak.push({
lat: 4.1387555555e+01,
lng: 1.4144066667e+02,
cert : true,
content:'Name = Kuwahatayama(JA/AM-067) peak = 399.100006 pos = 41.3876,141.4407 diff = 386.100006'
});
data_saddle.push({
lat: 4.1333444443e+01,
lng: 1.4135866667e+02,
content:'Saddle = 13.000000 pos = 41.3334,141.3587 diff = 386.100006'
});
data_peak.push({
lat: 4.1333444443e+01,
lng: 1.4140522222e+02,
cert : false,
content:' Peak = 252.600006 pos = 41.3334,141.4052 diff = 189.800003'
});
data_saddle.push({
lat: 4.1364111110e+01,
lng: 1.4140788889e+02,
content:'Saddle = 62.799999 pos = 41.3641,141.4079 diff = 189.800003'
});
data_peak.push({
lat: 4.1333444443e+01,
lng: 1.4102655556e+02,
cert : false,
content:' Peak = 733.700012 pos = 41.3334,141.0266 diff = 425.500000'
});
data_saddle.push({
lat: 4.1402222221e+01,
lng: 1.4093411111e+02,
content:'Saddle = 308.200012 pos = 41.4022,140.9341 diff = 425.500000'
});
data_peak.push({
lat: 4.1337999999e+01,
lng: 1.4087155556e+02,
cert : false,
content:' Peak = 681.400024 pos = 41.3380,140.8716 diff = 348.500031'
});
data_saddle.push({
lat: 4.1347333332e+01,
lng: 1.4093511111e+02,
content:'Saddle = 332.899994 pos = 41.3473,140.9351 diff = 348.500031'
});
data_peak.push({
lat: 4.1373666666e+01,
lng: 1.4091144444e+02,
cert : false,
content:' Peak = 672.400024 pos = 41.3737,140.9114 diff = 158.700012'
});
data_saddle.push({
lat: 4.1346555555e+01,
lng: 1.4088211111e+02,
content:'Saddle = 513.700012 pos = 41.3466,140.8821 diff = 158.700012'
});
data_peak.push({
lat: 4.1333444443e+01,
lng: 1.4104622222e+02,
cert : false,
content:' Peak = 532.700012 pos = 41.3334,141.0462 diff = 188.900024'
});
data_saddle.push({
lat: 4.1333444443e+01,
lng: 1.4104200000e+02,
content:'Saddle = 343.799988 pos = 41.3334,141.0420 diff = 188.900024'
});
data_peak.push({
lat: 4.1439111110e+01,
lng: 1.4097533333e+02,
cert : true,
content:'Name = JA/AM-051(JA/AM-051) peak = 612.700012 pos = 41.4391,140.9753 diff = 204.600006'
});
data_saddle.push({
lat: 4.1435444443e+01,
lng: 1.4100244444e+02,
content:'Saddle = 408.100006 pos = 41.4354,141.0024 diff = 204.600006'
});
data_peak.push({
lat: 4.1759111110e+01,
lng: 1.4070433333e+02,
cert : true,
content:'Name = JA8/OM-066(JA8/OM-066) peak = 333.700012 pos = 41.7591,140.7043 diff = 332.700012'
});
data_saddle.push({
lat: 4.1772222222e+01,
lng: 1.4073088889e+02,
content:'Saddle = 1.000000 pos = 41.7722,140.7309 diff = 332.700012'
});
data_peak.push({
lat: 4.2650333333e+01,
lng: 1.4199988889e+02,
cert : false,
content:' Peak = 254.600006 pos = 42.6503,141.9999 diff = 251.700012'
});
data_saddle.push({
lat: 4.2663777778e+01,
lng: 1.4177422222e+02,
content:'Saddle = 2.900000 pos = 42.6638,141.7742 diff = 251.700012'
});
data_peak.push({
lat: 4.2322111111e+01,
lng: 1.4095811111e+02,
cert : false,
content:' Peak = 198.000000 pos = 42.3221,140.9581 diff = 193.600006'
});
data_saddle.push({
lat: 4.2312777778e+01,
lng: 1.4097177778e+02,
content:'Saddle = 4.400000 pos = 42.3128,140.9718 diff = 193.600006'
});
data_peak.push({
lat: 4.2320444444e+01,
lng: 1.4100755556e+02,
cert : false,
content:' Peak = 185.800003 pos = 42.3204,141.0076 diff = 180.800003'
});
data_saddle.push({
lat: 4.2346222222e+01,
lng: 1.4102111111e+02,
content:'Saddle = 5.000000 pos = 42.3462,141.0211 diff = 180.800003'
});
data_peak.push({
lat: 4.2633555556e+01,
lng: 1.4114244444e+02,
cert : true,
content:'Name = Horohoroyama(JA8/IR-001) peak = 1321.800049 pos = 42.6336,141.1424 diff = 1228.200073'
});
data_saddle.push({
lat: 4.2621666667e+01,
lng: 1.4031444444e+02,
content:'Saddle = 93.599998 pos = 42.6217,140.3144 diff = 1228.200073'
});
data_peak.push({
lat: 4.2666666667e+01,
lng: 1.4051966667e+02,
cert : false,
content:' Peak = 703.000000 pos = 42.6667,140.5197 diff = 593.299988'
});
data_saddle.push({
lat: 4.2666555556e+01,
lng: 1.4075400000e+02,
content:'Saddle = 109.699997 pos = 42.6666,140.7540 diff = 593.299988'
});
data_peak.push({
lat: 4.2590888889e+01,
lng: 1.4038566667e+02,
cert : true,
content:'Name = JA8/OM-058(JA8/OM-058) peak = 494.299988 pos = 42.5909,140.3857 diff = 360.899994'
});
data_saddle.push({
lat: 4.2602444444e+01,
lng: 1.4042777778e+02,
content:'Saddle = 133.399994 pos = 42.6024,140.4278 diff = 360.899994'
});
data_peak.push({
lat: 4.2591555556e+01,
lng: 1.4060866667e+02,
cert : false,
content:' Peak = 302.899994 pos = 42.5916,140.6087 diff = 161.199997'
});
data_saddle.push({
lat: 4.2600111111e+01,
lng: 1.4059911111e+02,
content:'Saddle = 141.699997 pos = 42.6001,140.5991 diff = 161.199997'
});
data_peak.push({
lat: 4.2662555556e+01,
lng: 1.4046300000e+02,
cert : false,
content:' Peak = 570.500000 pos = 42.6626,140.4630 diff = 366.799988'
});
data_saddle.push({
lat: 4.2666666667e+01,
lng: 1.4048011111e+02,
content:'Saddle = 203.699997 pos = 42.6667,140.4801 diff = 366.799988'
});
data_peak.push({
lat: 4.2636777778e+01,
lng: 1.4063077778e+02,
cert : false,
content:' Peak = 462.899994 pos = 42.6368,140.6308 diff = 170.600006'
});
data_saddle.push({
lat: 4.2647222222e+01,
lng: 1.4058011111e+02,
content:'Saddle = 292.299988 pos = 42.6472,140.5801 diff = 170.600006'
});
data_peak.push({
lat: 4.2618222222e+01,
lng: 1.4053733333e+02,
cert : true,
content:'Name = JA8/SB-047(JA8/SB-047) peak = 561.599976 pos = 42.6182,140.5373 diff = 234.999969'
});
data_saddle.push({
lat: 4.2628111111e+01,
lng: 1.4055122222e+02,
content:'Saddle = 326.600006 pos = 42.6281,140.5512 diff = 234.999969'
});
data_peak.push({
lat: 4.2666666667e+01,
lng: 1.4136188889e+02,
cert : false,
content:' Peak = 648.599976 pos = 42.6667,141.3619 diff = 480.399963'
});
data_saddle.push({
lat: 4.2666555556e+01,
lng: 1.4125555556e+02,
content:'Saddle = 168.199997 pos = 42.6666,141.2556 diff = 480.399963'
});
data_peak.push({
lat: 4.2544000000e+01,
lng: 1.4083922222e+02,
cert : true,
content:'Name = Usuzan (Oousu)(JA8/IR-014) peak = 730.099976 pos = 42.5440,140.8392 diff = 547.899963'
});
data_saddle.push({
lat: 4.2555222222e+01,
lng: 1.4080055556e+02,
content:'Saddle = 182.199997 pos = 42.5552,140.8006 diff = 547.899963'
});
data_peak.push({
lat: 4.2542666667e+01,
lng: 1.4086422222e+02,
cert : true,
content:'Name = Shouwashinzan(JA8/IR-028) peak = 394.299988 pos = 42.5427,140.8642 diff = 204.899994'
});
data_saddle.push({
lat: 4.2540444444e+01,
lng: 1.4085777778e+02,
content:'Saddle = 189.399994 pos = 42.5404,140.8578 diff = 204.899994'
});
data_peak.push({
lat: 4.2593666667e+01,
lng: 1.4075966667e+02,
cert : false,
content:' Peak = 625.099976 pos = 42.5937,140.7597 diff = 404.299988'
});
data_saddle.push({
lat: 4.2666666667e+01,
lng: 1.4087422222e+02,
content:'Saddle = 220.800003 pos = 42.6667,140.8742 diff = 404.299988'
});
data_peak.push({
lat: 4.2665555556e+01,
lng: 1.4123466667e+02,
cert : true,
content:'Name = JA8/IR-020(JA8/IR-020) peak = 630.900024 pos = 42.6656,141.2347 diff = 354.700012'
});
data_saddle.push({
lat: 4.2666666667e+01,
lng: 1.4121800000e+02,
content:'Saddle = 276.200012 pos = 42.6667,141.2180 diff = 354.700012'
});
data_peak.push({
lat: 4.2497444444e+01,
lng: 1.4120244444e+02,
cert : true,
content:'Name = JA8/IR-024(JA8/IR-024) peak = 533.799988 pos = 42.4974,141.2024 diff = 181.099976'
});
data_saddle.push({
lat: 4.2512555555e+01,
lng: 1.4118611111e+02,
content:'Saddle = 352.700012 pos = 42.5126,141.1861 diff = 181.099976'
});
data_peak.push({
lat: 4.2521888889e+01,
lng: 1.4116444444e+02,
cert : true,
content:'Name = JA8/IR-022(JA8/IR-022) peak = 580.400024 pos = 42.5219,141.1644 diff = 219.200012'
});
data_saddle.push({
lat: 4.2523888889e+01,
lng: 1.4114166667e+02,
content:'Saddle = 361.200012 pos = 42.5239,141.1417 diff = 219.200012'
});
data_peak.push({
lat: 4.2492111111e+01,
lng: 1.4116100000e+02,
cert : false,
content:' Peak = 550.299988 pos = 42.4921,141.1610 diff = 169.599976'
});
data_saddle.push({
lat: 4.2508444444e+01,
lng: 1.4116177778e+02,
content:'Saddle = 380.700012 pos = 42.5084,141.1618 diff = 169.599976'
});
data_peak.push({
lat: 4.2641444444e+01,
lng: 1.4095800000e+02,
cert : false,
content:' Peak = 879.099976 pos = 42.6414,140.9580 diff = 515.799988'
});
data_saddle.push({
lat: 4.2666666667e+01,
lng: 1.4107744444e+02,
content:'Saddle = 363.299988 pos = 42.6667,141.0774 diff = 515.799988'
});
data_peak.push({
lat: 4.2659888889e+01,
lng: 1.4120322222e+02,
cert : false,
content:' Peak = 612.799988 pos = 42.6599,141.2032 diff = 206.699982'
});
data_saddle.push({
lat: 4.2666666667e+01,
lng: 1.4119055556e+02,
content:'Saddle = 406.100006 pos = 42.6667,141.1906 diff = 206.699982'
});
data_peak.push({
lat: 4.2665444444e+01,
lng: 1.4118188889e+02,
cert : false,
content:' Peak = 672.700012 pos = 42.6654,141.1819 diff = 233.900024'
});
data_saddle.push({
lat: 4.2666666667e+01,
lng: 1.4117577778e+02,
content:'Saddle = 438.799988 pos = 42.6667,141.1758 diff = 233.900024'
});
data_peak.push({
lat: 4.2455000000e+01,
lng: 1.4094700000e+02,
cert : true,
content:'Name = JA8/IR-016(JA8/IR-016) peak = 701.599976 pos = 42.4550,140.9470 diff = 213.599976'
});
data_saddle.push({
lat: 4.2461777778e+01,
lng: 1.4095411111e+02,
content:'Saddle = 488.000000 pos = 42.4618,140.9541 diff = 213.599976'
});
data_peak.push({
lat: 4.2435666667e+01,
lng: 1.4100300000e+02,
cert : false,
content:' Peak = 910.799988 pos = 42.4357,141.0030 diff = 359.099976'
});
data_saddle.push({
lat: 4.2459222222e+01,
lng: 1.4098677778e+02,
content:'Saddle = 551.700012 pos = 42.4592,140.9868 diff = 359.099976'
});
data_peak.push({
lat: 4.2433888889e+01,
lng: 1.4102844444e+02,
cert : false,
content:' Peak = 751.099976 pos = 42.4339,141.0284 diff = 179.000000'
});
data_saddle.push({
lat: 4.2434777778e+01,
lng: 1.4101644444e+02,
content:'Saddle = 572.099976 pos = 42.4348,141.0164 diff = 179.000000'
});
data_peak.push({
lat: 4.2505000000e+01,
lng: 1.4097044444e+02,
cert : true,
content:'Name = JA8/IR-010(JA8/IR-010) peak = 791.099976 pos = 42.5050,140.9704 diff = 161.599976'
});
data_saddle.push({
lat: 4.2514888889e+01,
lng: 1.4101377778e+02,
content:'Saddle = 629.500000 pos = 42.5149,141.0138 diff = 161.599976'
});
data_peak.push({
lat: 4.2541333333e+01,
lng: 1.4111911111e+02,
cert : true,
content:'Name = JA8/IR-009(JA8/IR-009) peak = 896.700012 pos = 42.5413,141.1191 diff = 183.600037'
});
data_saddle.push({
lat: 4.2548555555e+01,
lng: 1.4111066667e+02,
content:'Saddle = 713.099976 pos = 42.5486,141.1107 diff = 183.600037'
});
data_peak.push({
lat: 4.2566000000e+01,
lng: 1.4108700000e+02,
cert : true,
content:'Name = JA8/IR-002(JA8/IR-002) peak = 1230.599976 pos = 42.5660,141.0870 diff = 355.000000'
});
data_saddle.push({
lat: 4.2598555556e+01,
lng: 1.4110000000e+02,
content:'Saddle = 875.599976 pos = 42.5986,141.1000 diff = 355.000000'
});
data_peak.push({
lat: 4.2540444444e+01,
lng: 1.4106733333e+02,
cert : false,
content:' Peak = 1076.099976 pos = 42.5404,141.0673 diff = 155.699951'
});
data_saddle.push({
lat: 4.2552444444e+01,
lng: 1.4107566667e+02,
content:'Saddle = 920.400024 pos = 42.5524,141.0757 diff = 155.699951'
});
data_peak.push({
lat: 4.1804444444e+01,
lng: 1.4116611111e+02,
cert : true,
content:'Name = Esan(JA8/OM-045) peak = 615.299988 pos = 41.8044,141.1661 diff = 496.899994'
});
data_saddle.push({
lat: 4.1811666666e+01,
lng: 1.4110600000e+02,
content:'Saddle = 118.400002 pos = 41.8117,141.1060 diff = 496.899994'
});
data_peak.push({
lat: 4.1813777777e+01,
lng: 1.4113400000e+02,
cert : true,
content:'Name = JA8/OM-054(JA8/OM-054) peak = 568.599976 pos = 41.8138,141.1340 diff = 252.699982'
});
data_saddle.push({
lat: 4.1811111110e+01,
lng: 1.4114511111e+02,
content:'Saddle = 315.899994 pos = 41.8111,141.1451 diff = 252.699982'
});
data_peak.push({
lat: 4.1549222221e+01,
lng: 1.4003688889e+02,
cert : false,
content:' Peak = 401.500000 pos = 41.5492,140.0369 diff = 273.200012'
});
data_saddle.push({
lat: 4.1551999999e+01,
lng: 1.4004711111e+02,
content:'Saddle = 128.300003 pos = 41.5520,140.0471 diff = 273.200012'
});
data_peak.push({
lat: 4.1798333333e+01,
lng: 1.4057988889e+02,
cert : true,
content:'Name = JA8/OM-067(JA8/OM-067) peak = 332.000000 pos = 41.7983,140.5799 diff = 190.600006'
});
data_saddle.push({
lat: 4.1813444444e+01,
lng: 1.4054444444e+02,
content:'Saddle = 141.399994 pos = 41.8134,140.5444 diff = 190.600006'
});
data_peak.push({
lat: 4.2219000000e+01,
lng: 1.4001022222e+02,
cert : true,
content:'Name = Yuurappudake (Kenichidake)(JA8/OM-001) peak = 1276.199951 pos = 42.2190,140.0102 diff = 1124.000000'
});
data_saddle.push({
lat: 4.2482666667e+01,
lng: 1.4021877778e+02,
content:'Saddle = 152.199997 pos = 42.4827,140.2188 diff = 1124.000000'
});
data_peak.push({
lat: 4.1782666666e+01,
lng: 1.4088688889e+02,
cert : true,
content:'Name = JA8/OM-068(JA8/OM-068) peak = 321.000000 pos = 41.7827,140.8869 diff = 152.199997'
});
data_saddle.push({
lat: 4.1775666666e+01,
lng: 1.4089444444e+02,
content:'Saddle = 168.800003 pos = 41.7757,140.8944 diff = 152.199997'
});
data_peak.push({
lat: 4.1542666666e+01,
lng: 1.4037122222e+02,
cert : false,
content:' Peak = 852.299988 pos = 41.5427,140.3712 diff = 683.099976'
});
data_saddle.push({
lat: 4.1533222221e+01,
lng: 1.4025666667e+02,
content:'Saddle = 169.199997 pos = 41.5332,140.2567 diff = 683.099976'
});
data_peak.push({
lat: 4.1512777777e+01,
lng: 1.4027055556e+02,
cert : true,
content:'Name = JA8/OM-057(JA8/OM-057) peak = 523.799988 pos = 41.5128,140.2706 diff = 171.399994'
});
data_saddle.push({
lat: 4.1513777777e+01,
lng: 1.4027577778e+02,
content:'Saddle = 352.399994 pos = 41.5138,140.2758 diff = 171.399994'
});
data_peak.push({
lat: 4.1527111110e+01,
lng: 1.4031077778e+02,
cert : true,
content:'Name = Iwabedake(JA8/OM-021) peak = 792.299988 pos = 41.5271,140.3108 diff = 249.399963'
});
data_saddle.push({
lat: 4.1529222221e+01,
lng: 1.4035088889e+02,
content:'Saddle = 542.900024 pos = 41.5292,140.3509 diff = 249.399963'
});
data_peak.push({
lat: 4.2063555555e+01,
lng: 1.4067722222e+02,
cert : true,
content:'Name = Komagatake (Kengamine)(JA8/OM-004) peak = 1130.900024 pos = 42.0636,140.6772 diff = 957.700012'
});
data_saddle.push({
lat: 4.2049777777e+01,
lng: 1.4061411111e+02,
content:'Saddle = 173.199997 pos = 42.0498,140.6141 diff = 957.700012'
});
data_peak.push({
lat: 4.2074555555e+01,
lng: 1.4068844444e+02,
cert : false,
content:' Peak = 1110.800049 pos = 42.0746,140.6884 diff = 158.600037'
});
data_saddle.push({
lat: 4.2067777777e+01,
lng: 1.4068011111e+02,
content:'Saddle = 952.200012 pos = 42.0678,140.6801 diff = 158.600037'
});
data_peak.push({
lat: 4.1745777777e+01,
lng: 1.4054900000e+02,
cert : false,
content:' Peak = 483.899994 pos = 41.7458,140.5490 diff = 310.299988'
});
data_saddle.push({
lat: 4.1753222222e+01,
lng: 1.4052811111e+02,
content:'Saddle = 173.600006 pos = 41.7532,140.5281 diff = 310.299988'
});
data_peak.push({
lat: 4.1417222221e+01,
lng: 1.4020622222e+02,
cert : false,
content:' Peak = 352.100006 pos = 41.4172,140.2062 diff = 174.800003'
});
data_saddle.push({
lat: 4.1426555555e+01,
lng: 1.4020588889e+02,
content:'Saddle = 177.300003 pos = 41.4266,140.2059 diff = 174.800003'
});
data_peak.push({
lat: 4.1579333332e+01,
lng: 1.4016100000e+02,
cert : true,
content:'Name = Daisengendake(JA8/OM-005) peak = 1071.000000 pos = 41.5793,140.1610 diff = 869.299988'
});
data_saddle.push({
lat: 4.1715333333e+01,
lng: 1.4032188889e+02,
content:'Saddle = 201.699997 pos = 41.7153,140.3219 diff = 869.299988'
});
data_peak.push({
lat: 4.1659888888e+01,
lng: 1.4028166667e+02,
cert : true,
content:'Name = JA8/OM-035(JA8/OM-035) peak = 693.099976 pos = 41.6599,140.2817 diff = 355.199982'
});
data_saddle.push({
lat: 4.1643777777e+01,
lng: 1.4024977778e+02,
content:'Saddle = 337.899994 pos = 41.6438,140.2498 diff = 355.199982'
});
data_peak.push({
lat: 4.1673888888e+01,
lng: 1.4002388889e+02,
cert : true,
content:'Name = JA8/HY-023(JA8/HY-023) peak = 561.200012 pos = 41.6739,140.0239 diff = 198.800018'
});
data_saddle.push({
lat: 4.1660333333e+01,
lng: 1.4001544444e+02,
content:'Saddle = 362.399994 pos = 41.6603,140.0154 diff = 198.800018'
});
data_peak.push({
lat: 4.1597222221e+01,
lng: 1.4024433333e+02,
cert : true,
content:'Name = JA8/OM-056(JA8/OM-056) peak = 530.799988 pos = 41.5972,140.2443 diff = 163.399994'
});
data_saddle.push({
lat: 4.1595666666e+01,
lng: 1.4023877778e+02,
content:'Saddle = 367.399994 pos = 41.5957,140.2388 diff = 163.399994'
});
data_peak.push({
lat: 4.1512333332e+01,
lng: 1.4008577778e+02,
cert : true,
content:'Name = JA8/OM-043(JA8/OM-043) peak = 632.200012 pos = 41.5123,140.0858 diff = 264.800018'
});
data_saddle.push({
lat: 4.1515888888e+01,
lng: 1.4014211111e+02,
content:'Saddle = 367.399994 pos = 41.5159,140.1421 diff = 264.800018'
});
data_peak.push({
lat: 4.1494222221e+01,
lng: 1.4007133333e+02,
cert : true,
content:'Name = JA8/OM-047(JA8/OM-047) peak = 612.500000 pos = 41.4942,140.0713 diff = 171.399994'
});
data_saddle.push({
lat: 4.1492555555e+01,
lng: 1.4007566667e+02,
content:'Saddle = 441.100006 pos = 41.4926,140.0757 diff = 171.399994'
});
data_peak.push({
lat: 4.1592777777e+01,
lng: 1.4023166667e+02,
cert : false,
content:' Peak = 583.299988 pos = 41.5928,140.2317 diff = 150.199982'
});
data_saddle.push({
lat: 4.1593111110e+01,
lng: 1.4022433333e+02,
content:'Saddle = 433.100006 pos = 41.5931,140.2243 diff = 150.199982'
});
data_peak.push({
lat: 4.1531999999e+01,
lng: 1.4011333333e+02,
cert : true,
content:'Name = JA8/OM-023(JA8/OM-023) peak = 793.200012 pos = 41.5320,140.1133 diff = 327.000000'
});
data_saddle.push({
lat: 4.1533333332e+01,
lng: 1.4014000000e+02,
content:'Saddle = 466.200012 pos = 41.5333,140.1400 diff = 327.000000'
});
data_peak.push({
lat: 4.1475555555e+01,
lng: 1.4018100000e+02,
cert : true,
content:'Name = JA8/OM-041(JA8/OM-041) peak = 660.599976 pos = 41.4756,140.1810 diff = 159.599976'
});
data_saddle.push({
lat: 4.1487444444e+01,
lng: 1.4018333333e+02,
content:'Saddle = 501.000000 pos = 41.4874,140.1833 diff = 159.599976'
});
data_peak.push({
lat: 4.1611444444e+01,
lng: 1.4023633333e+02,
cert : true,
content:'Name = JA8/OM-040(JA8/OM-040) peak = 660.700012 pos = 41.6114,140.2363 diff = 158.100006'
});
data_saddle.push({
lat: 4.1614999999e+01,
lng: 1.4023811111e+02,
content:'Saddle = 502.600006 pos = 41.6150,140.2381 diff = 158.100006'
});
data_peak.push({
lat: 4.1548444444e+01,
lng: 1.4011411111e+02,
cert : true,
content:'Name = JA8/OM-025(JA8/OM-025) peak = 773.900024 pos = 41.5484,140.1141 diff = 262.300018'
});
data_saddle.push({
lat: 4.1554222221e+01,
lng: 1.4013455556e+02,
content:'Saddle = 511.600006 pos = 41.5542,140.1346 diff = 262.300018'
});
data_peak.push({
lat: 4.1633777777e+01,
lng: 1.4022933333e+02,
cert : false,
content:' Peak = 700.900024 pos = 41.6338,140.2293 diff = 158.700012'
});
data_saddle.push({
lat: 4.1631888888e+01,
lng: 1.4022355556e+02,
content:'Saddle = 542.200012 pos = 41.6319,140.2236 diff = 158.700012'
});
data_peak.push({
lat: 4.1702333333e+01,
lng: 1.4014200000e+02,
cert : true,
content:'Name = JA8/HY-014(JA8/HY-014) peak = 774.099976 pos = 41.7023,140.1420 diff = 230.699951'
});
data_saddle.push({
lat: 4.1658888888e+01,
lng: 1.4019300000e+02,
content:'Saddle = 543.400024 pos = 41.6589,140.1930 diff = 230.699951'
});
data_peak.push({
lat: 4.1677999999e+01,
lng: 1.4019322222e+02,
cert : false,
content:' Peak = 732.000000 pos = 41.6780,140.1932 diff = 151.400024'
});
data_saddle.push({
lat: 4.1691999999e+01,
lng: 1.4018955556e+02,
content:'Saddle = 580.599976 pos = 41.6920,140.1896 diff = 151.400024'
});
data_peak.push({
lat: 4.1614666666e+01,
lng: 1.4004611111e+02,
cert : false,
content:' Peak = 873.900024 pos = 41.6147,140.0461 diff = 306.400024'
});
data_saddle.push({
lat: 4.1590444444e+01,
lng: 1.4007522222e+02,
content:'Saddle = 567.500000 pos = 41.5904,140.0752 diff = 306.400024'
});
data_peak.push({
lat: 4.1588666666e+01,
lng: 1.4010366667e+02,
cert : true,
content:'Name = JA8/HY-010(JA8/HY-010) peak = 858.000000 pos = 41.5887,140.1037 diff = 255.099976'
});
data_saddle.push({
lat: 4.1582333332e+01,
lng: 1.4013244444e+02,
content:'Saddle = 602.900024 pos = 41.5823,140.1324 diff = 255.099976'
});
data_peak.push({
lat: 4.1568666666e+01,
lng: 1.4011300000e+02,
cert : true,
content:'Name = JA8/OM-015(JA8/OM-015) peak = 852.700012 pos = 41.5687,140.1130 diff = 159.000000'
});
data_saddle.push({
lat: 4.1580222221e+01,
lng: 1.4011288889e+02,
content:'Saddle = 693.700012 pos = 41.5802,140.1129 diff = 159.000000'
});
data_peak.push({
lat: 4.1521888888e+01,
lng: 1.4016744444e+02,
cert : true,
content:'Name = JA8/OM-026(JA8/OM-026) peak = 771.099976 pos = 41.5219,140.1674 diff = 157.299988'
});
data_saddle.push({
lat: 4.1529555555e+01,
lng: 1.4017611111e+02,
content:'Saddle = 613.799988 pos = 41.5296,140.1761 diff = 157.299988'
});
data_peak.push({
lat: 4.1624222221e+01,
lng: 1.4021400000e+02,
cert : true,
content:'Name = Nanatsudake(JA8/OM-009) peak = 951.599976 pos = 41.6242,140.2140 diff = 324.099976'
});
data_saddle.push({
lat: 4.1614111110e+01,
lng: 1.4019444444e+02,
content:'Saddle = 627.500000 pos = 41.6141,140.1944 diff = 324.099976'
});
data_peak.push({
lat: 4.2152555555e+01,
lng: 1.4040088889e+02,
cert : true,
content:'Name = JA8/OM-063(JA8/OM-063) peak = 404.000000 pos = 42.1526,140.4009 diff = 192.399994'
});
data_saddle.push({
lat: 4.2143222222e+01,
lng: 1.4039855556e+02,
content:'Saddle = 211.600006 pos = 42.1432,140.3986 diff = 192.399994'
});
data_peak.push({
lat: 4.1763444444e+01,
lng: 1.4096744444e+02,
cert : true,
content:'Name = JA8/OM-062(JA8/OM-062) peak = 414.399994 pos = 41.7634,140.9674 diff = 197.599991'
});
data_saddle.push({
lat: 4.1786777777e+01,
lng: 1.4101177778e+02,
content:'Saddle = 216.800003 pos = 41.7868,141.0118 diff = 197.599991'
});
data_peak.push({
lat: 4.1775111110e+01,
lng: 1.4098688889e+02,
cert : false,
content:' Peak = 402.700012 pos = 41.7751,140.9869 diff = 151.800018'
});
data_saddle.push({
lat: 4.1769333333e+01,
lng: 1.4098211111e+02,
content:'Saddle = 250.899994 pos = 41.7693,140.9821 diff = 151.800018'
});
data_peak.push({
lat: 4.2295444444e+01,
lng: 1.3981066667e+02,
cert : true,
content:'Name = JA8/HY-012(JA8/HY-012) peak = 815.700012 pos = 42.2954,139.8107 diff = 592.900024'
});
data_saddle.push({
lat: 4.2259222222e+01,
lng: 1.3990311111e+02,
content:'Saddle = 222.800003 pos = 42.2592,139.9031 diff = 592.900024'
});
data_peak.push({
lat: 4.2267000000e+01,
lng: 1.3980644444e+02,
cert : true,
content:'Name = JA8/HY-025(JA8/HY-025) peak = 530.500000 pos = 42.2670,139.8064 diff = 243.799988'
});
data_saddle.push({
lat: 4.2276111111e+01,
lng: 1.3981488889e+02,
content:'Saddle = 286.700012 pos = 42.2761,139.8149 diff = 243.799988'
});
data_peak.push({
lat: 4.1937888888e+01,
lng: 1.4077122222e+02,
cert : true,
content:'Name = Yokotsudake(JA8/OM-003) peak = 1166.900024 pos = 41.9379,140.7712 diff = 943.500000'
});
data_saddle.push({
lat: 4.1955333333e+01,
lng: 1.4064411111e+02,
content:'Saddle = 223.399994 pos = 41.9553,140.6441 diff = 943.500000'
});
data_peak.push({
lat: 4.1812888888e+01,
lng: 1.4100555556e+02,
cert : true,
content:'Name = JA8/OM-051(JA8/OM-051) peak = 585.400024 pos = 41.8129,141.0056 diff = 222.000031'
});
data_saddle.push({
lat: 4.1823222222e+01,
lng: 1.4099955556e+02,
content:'Saddle = 363.399994 pos = 41.8232,140.9996 diff = 222.000031'
});
data_peak.push({
lat: 4.1851999999e+01,
lng: 1.4109188889e+02,
cert : true,
content:'Name = JA8/OM-036(JA8/OM-036) peak = 690.700012 pos = 41.8520,141.0919 diff = 319.200012'
});
data_saddle.push({
lat: 4.1845222222e+01,
lng: 1.4104511111e+02,
content:'Saddle = 371.500000 pos = 41.8452,141.0451 diff = 319.200012'
});
data_peak.push({
lat: 4.1836333333e+01,
lng: 1.4100011111e+02,
cert : true,
content:'Name = JA8/OM-044(JA8/OM-044) peak = 632.599976 pos = 41.8363,141.0001 diff = 215.399963'
});
data_saddle.push({
lat: 4.1879222222e+01,
lng: 1.4094166667e+02,
content:'Saddle = 417.200012 pos = 41.8792,140.9417 diff = 215.399963'
});
data_peak.push({
lat: 4.1884555555e+01,
lng: 1.4087433333e+02,
cert : true,
content:'Name = JA8/OM-016(JA8/OM-016) peak = 841.299988 pos = 41.8846,140.8743 diff = 343.000000'
});
data_saddle.push({
lat: 4.1911888888e+01,
lng: 1.4086833333e+02,
content:'Saddle = 498.299988 pos = 41.9119,140.8683 diff = 343.000000'
});
data_peak.push({
lat: 4.1952777777e+01,
lng: 1.4087677778e+02,
cert : true,
content:'Name = JA8/OM-017(JA8/OM-017) peak = 834.299988 pos = 41.9528,140.8768 diff = 195.200012'
});
data_saddle.push({
lat: 4.1944999999e+01,
lng: 1.4085888889e+02,
content:'Saddle = 639.099976 pos = 41.9450,140.8589 diff = 195.200012'
});
data_peak.push({
lat: 4.2423666667e+01,
lng: 1.4022544444e+02,
cert : false,
content:' Peak = 543.400024 pos = 42.4237,140.2254 diff = 316.400024'
});
data_saddle.push({
lat: 4.2375555555e+01,
lng: 1.4017966667e+02,
content:'Saddle = 227.000000 pos = 42.3756,140.1797 diff = 316.400024'
});
data_peak.push({
lat: 4.2186111111e+01,
lng: 1.4029888889e+02,
cert : true,
content:'Name = JA8/OM-061(JA8/OM-061) peak = 444.399994 pos = 42.1861,140.2989 diff = 167.199982'
});
data_saddle.push({
lat: 4.2168444444e+01,
lng: 1.4027866667e+02,
content:'Saddle = 277.200012 pos = 42.1684,140.2787 diff = 167.199982'
});
data_peak.push({
lat: 4.1851888888e+01,
lng: 1.4022988889e+02,
cert : true,
content:'Name = Hachimandake(JA8/HY-018) peak = 662.900024 pos = 41.8519,140.2299 diff = 373.800018'
});
data_saddle.push({
lat: 4.1806222222e+01,
lng: 1.4032011111e+02,
content:'Saddle = 289.100006 pos = 41.8062,140.3201 diff = 373.800018'
});
data_peak.push({
lat: 4.1863777777e+01,
lng: 1.4027188889e+02,
cert : false,
content:' Peak = 513.200012 pos = 41.8638,140.2719 diff = 152.500000'
});
data_saddle.push({
lat: 4.1858555555e+01,
lng: 1.4026255556e+02,
content:'Saddle = 360.700012 pos = 41.8586,140.2626 diff = 152.500000'
});
data_peak.push({
lat: 4.1815222222e+01,
lng: 1.4047755556e+02,
cert : true,
content:'Name = JA8/OM-059(JA8/OM-059) peak = 492.500000 pos = 41.8152,140.4776 diff = 195.100006'
});
data_saddle.push({
lat: 4.1804777777e+01,
lng: 1.4046155556e+02,
content:'Saddle = 297.399994 pos = 41.8048,140.4616 diff = 195.100006'
});
data_peak.push({
lat: 4.1786999999e+01,
lng: 1.4035844444e+02,
cert : true,
content:'Name = JA8/HY-020(JA8/HY-020) peak = 631.099976 pos = 41.7870,140.3584 diff = 329.399963'
});
data_saddle.push({
lat: 4.1806333333e+01,
lng: 1.4038500000e+02,
content:'Saddle = 301.700012 pos = 41.8063,140.3850 diff = 329.399963'
});
data_peak.push({
lat: 4.1789222222e+01,
lng: 1.4046433333e+02,
cert : true,
content:'Name = Katsuradake(JA8/OM-029) peak = 732.000000 pos = 41.7892,140.4643 diff = 418.700012'
});
data_saddle.push({
lat: 4.1842777777e+01,
lng: 1.4044555556e+02,
content:'Saddle = 313.299988 pos = 41.8428,140.4456 diff = 418.700012'
});
data_peak.push({
lat: 4.2011777777e+01,
lng: 1.4035833333e+02,
cert : true,
content:'Name = JA8/HY-022(JA8/HY-022) peak = 567.000000 pos = 42.0118,140.3583 diff = 233.899994'
});
data_saddle.push({
lat: 4.2005888888e+01,
lng: 1.4036011111e+02,
content:'Saddle = 333.100006 pos = 42.0059,140.3601 diff = 233.899994'
});
data_peak.push({
lat: 4.1837111110e+01,
lng: 1.4049000000e+02,
cert : true,
content:'Name = JA8/OM-046(JA8/OM-046) peak = 612.000000 pos = 41.8371,140.4900 diff = 243.100006'
});
data_saddle.push({
lat: 4.1848555555e+01,
lng: 1.4046111111e+02,
content:'Saddle = 368.899994 pos = 41.8486,140.4611 diff = 243.100006'
});
data_peak.push({
lat: 4.1857333333e+01,
lng: 1.4055500000e+02,
cert : true,
content:'Name = JA8/OM-052(JA8/OM-052) peak = 570.599976 pos = 41.8573,140.5550 diff = 198.199982'
});
data_saddle.push({
lat: 4.1878777777e+01,
lng: 1.4050911111e+02,
content:'Saddle = 372.399994 pos = 41.8788,140.5091 diff = 198.199982'
});
data_peak.push({
lat: 4.2275888889e+01,
lng: 1.4005055556e+02,
cert : true,
content:'Name = JA8/OM-055(JA8/OM-055) peak = 562.299988 pos = 42.2759,140.0506 diff = 189.799988'
});
data_saddle.push({
lat: 4.2282333333e+01,
lng: 1.4002711111e+02,
content:'Saddle = 372.500000 pos = 42.2823,140.0271 diff = 189.799988'
});
data_peak.push({
lat: 4.1922222222e+01,
lng: 1.4042133333e+02,
cert : true,
content:'Name = JA8/HY-024(JA8/HY-024) peak = 563.900024 pos = 41.9222,140.4213 diff = 171.800018'
});
data_saddle.push({
lat: 4.1929444444e+01,
lng: 1.4042322222e+02,
content:'Saddle = 392.100006 pos = 41.9294,140.4232 diff = 171.800018'
});
data_peak.push({
lat: 4.2034888888e+01,
lng: 1.4022255556e+02,
cert : false,
content:' Peak = 570.500000 pos = 42.0349,140.2226 diff = 178.000000'
});
data_saddle.push({
lat: 4.2039777777e+01,
lng: 1.4023011111e+02,
content:'Saddle = 392.500000 pos = 42.0398,140.2301 diff = 178.000000'
});
data_peak.push({
lat: 4.2070777777e+01,
lng: 1.4038166667e+02,
cert : true,
content:'Name = JA8/OM-049(JA8/OM-049) peak = 611.799988 pos = 42.0708,140.3817 diff = 218.500000'
});
data_saddle.push({
lat: 4.2060222222e+01,
lng: 1.4039488889e+02,
content:'Saddle = 393.299988 pos = 42.0602,140.3949 diff = 218.500000'
});
data_peak.push({
lat: 4.1901555555e+01,
lng: 1.4048544444e+02,
cert : true,
content:'Name = JA8/OM-033(JA8/OM-033) peak = 703.900024 pos = 41.9016,140.4854 diff = 310.400024'
});
data_saddle.push({
lat: 4.1925888888e+01,
lng: 1.4045033333e+02,
content:'Saddle = 393.500000 pos = 41.9259,140.4503 diff = 310.400024'
});
data_peak.push({
lat: 4.1882222222e+01,
lng: 1.4048555556e+02,
cert : false,
content:' Peak = 610.299988 pos = 41.8822,140.4856 diff = 162.399994'
});
data_saddle.push({
lat: 4.1889333333e+01,
lng: 1.4046988889e+02,
content:'Saddle = 447.899994 pos = 41.8893,140.4699 diff = 162.399994'
});
data_peak.push({
lat: 4.2039444444e+01,
lng: 1.4027455556e+02,
cert : true,
content:'Name = Otobedake(JA8/HY-006) peak = 1016.299988 pos = 42.0394,140.2746 diff = 622.400024'
});
data_saddle.push({
lat: 4.2174666666e+01,
lng: 1.4010377778e+02,
content:'Saddle = 393.899994 pos = 42.1747,140.1038 diff = 622.400024'
});
data_peak.push({
lat: 4.2069777777e+01,
lng: 1.4012855556e+02,
cert : true,
content:'Name = JA8/OM-042(JA8/OM-042) peak = 644.400024 pos = 42.0698,140.1286 diff = 241.100037'
});
data_saddle.push({
lat: 4.2068000000e+01,
lng: 1.4017055556e+02,
content:'Saddle = 403.299988 pos = 42.0680,140.1706 diff = 241.100037'
});
data_peak.push({
lat: 4.1924444444e+01,
lng: 1.4054522222e+02,
cert : true,
content:'Name = JA8/OM-027(JA8/OM-027) peak = 752.000000 pos = 41.9244,140.5452 diff = 348.600006'
});
data_saddle.push({
lat: 4.1948777777e+01,
lng: 1.4045877778e+02,
content:'Saddle = 403.399994 pos = 41.9488,140.4588 diff = 348.600006'
});
data_peak.push({
lat: 4.1947222222e+01,
lng: 1.4051188889e+02,
cert : false,
content:' Peak = 603.799988 pos = 41.9472,140.5119 diff = 151.199982'
});
data_saddle.push({
lat: 4.1944222222e+01,
lng: 1.4050977778e+02,
content:'Saddle = 452.600006 pos = 41.9442,140.5098 diff = 151.199982'
});
data_peak.push({
lat: 4.1928666666e+01,
lng: 1.4048333333e+02,
cert : true,
content:'Name = JA8/OM-034(JA8/OM-034) peak = 701.299988 pos = 41.9287,140.4833 diff = 193.299988'
});
data_saddle.push({
lat: 4.1936222222e+01,
lng: 1.4051133333e+02,
content:'Saddle = 508.000000 pos = 41.9362,140.5113 diff = 193.299988'
});
data_peak.push({
lat: 4.2058777777e+01,
lng: 1.4043222222e+02,
cert : true,
content:'Name = JA8/OM-011(JA8/OM-011) peak = 891.500000 pos = 42.0588,140.4322 diff = 478.299988'
});
data_saddle.push({
lat: 4.2032888888e+01,
lng: 1.4038622222e+02,
content:'Saddle = 413.200012 pos = 42.0329,140.3862 diff = 478.299988'
});
data_peak.push({
lat: 4.2087666666e+01,
lng: 1.4047044444e+02,
cert : true,
content:'Name = JA8/OM-037(JA8/OM-037) peak = 685.000000 pos = 42.0877,140.4704 diff = 202.899994'
});
data_saddle.push({
lat: 4.2080666666e+01,
lng: 1.4046711111e+02,
content:'Saddle = 482.100006 pos = 42.0807,140.4671 diff = 202.899994'
});
data_peak.push({
lat: 4.1952777777e+01,
lng: 1.4060277778e+02,
cert : true,
content:'Name = JA8/OM-038(JA8/OM-038) peak = 682.900024 pos = 41.9528,140.6028 diff = 179.500031'
});
data_saddle.push({
lat: 4.1971666666e+01,
lng: 1.4056788889e+02,
content:'Saddle = 503.399994 pos = 41.9717,140.5679 diff = 179.500031'
});
data_peak.push({
lat: 4.1997222222e+01,
lng: 1.4038100000e+02,
cert : true,
content:'Name = JA8/HY-015(JA8/HY-015) peak = 730.700012 pos = 41.9972,140.3810 diff = 183.500000'
});
data_saddle.push({
lat: 4.2001888888e+01,
lng: 1.4039477778e+02,
content:'Saddle = 547.200012 pos = 42.0019,140.3948 diff = 183.500000'
});
data_peak.push({
lat: 4.1976555555e+01,
lng: 1.4054533333e+02,
cert : false,
content:' Peak = 822.000000 pos = 41.9766,140.5453 diff = 259.599976'
});
data_saddle.push({
lat: 4.2002777777e+01,
lng: 1.4046188889e+02,
content:'Saddle = 562.400024 pos = 42.0028,140.4619 diff = 259.599976'
});
data_peak.push({
lat: 4.2030777777e+01,
lng: 1.4051744444e+02,
cert : true,
content:'Name = JA8/OM-019(JA8/OM-019) peak = 818.700012 pos = 42.0308,140.5174 diff = 151.500000'
});
data_saddle.push({
lat: 4.2021555555e+01,
lng: 1.4051966667e+02,
content:'Saddle = 667.200012 pos = 42.0216,140.5197 diff = 151.500000'
});
data_peak.push({
lat: 4.1986444444e+01,
lng: 1.4041422222e+02,
cert : false,
content:' Peak = 824.200012 pos = 41.9864,140.4142 diff = 235.700012'
});
data_saddle.push({
lat: 4.2040444444e+01,
lng: 1.4043244444e+02,
content:'Saddle = 588.500000 pos = 42.0404,140.4324 diff = 235.700012'
});
data_peak.push({
lat: 4.2032888888e+01,
lng: 1.4040900000e+02,
cert : true,
content:'Name = JA8/OM-024(JA8/OM-024) peak = 783.900024 pos = 42.0329,140.4090 diff = 170.500000'
});
data_saddle.push({
lat: 4.2017444444e+01,
lng: 1.4041233333e+02,
content:'Saddle = 613.400024 pos = 42.0174,140.4123 diff = 170.500000'
});
data_peak.push({
lat: 4.2054666666e+01,
lng: 1.4045022222e+02,
cert : true,
content:'Name = JA8/OM-012(JA8/OM-012) peak = 882.900024 pos = 42.0547,140.4502 diff = 178.900024'
});
data_saddle.push({
lat: 4.2055444444e+01,
lng: 1.4043444444e+02,
content:'Saddle = 704.000000 pos = 42.0554,140.4344 diff = 178.900024'
});
data_peak.push({
lat: 4.2051333333e+01,
lng: 1.4018988889e+02,
cert : true,
content:'Name = JA8/HY-017(JA8/HY-017) peak = 713.200012 pos = 42.0513,140.1899 diff = 265.900024'
});
data_saddle.push({
lat: 4.2058666666e+01,
lng: 1.4019100000e+02,
content:'Saddle = 447.299988 pos = 42.0587,140.1910 diff = 265.900024'
});
data_peak.push({
lat: 4.2129777777e+01,
lng: 1.4006122222e+02,
cert : true,
content:'Name = JA8/OM-031(JA8/OM-031) peak = 721.000000 pos = 42.1298,140.0612 diff = 268.100006'
});
data_saddle.push({
lat: 4.2137111111e+01,
lng: 1.4009500000e+02,
content:'Saddle = 452.899994 pos = 42.1371,140.0950 diff = 268.100006'
});
data_peak.push({
lat: 4.2113444444e+01,
lng: 1.4030755556e+02,
cert : true,
content:'Name = JA8/OM-032(JA8/OM-032) peak = 705.400024 pos = 42.1134,140.3076 diff = 228.200012'
});
data_saddle.push({
lat: 4.2099666666e+01,
lng: 1.4029677778e+02,
content:'Saddle = 477.200012 pos = 42.0997,140.2968 diff = 228.200012'
});
data_peak.push({
lat: 4.2177666666e+01,
lng: 1.4015055556e+02,
cert : true,
content:'Name = JA8/OM-028(JA8/OM-028) peak = 743.299988 pos = 42.1777,140.1506 diff = 211.299988'
});
data_saddle.push({
lat: 4.2170666666e+01,
lng: 1.4015700000e+02,
content:'Saddle = 532.000000 pos = 42.1707,140.1570 diff = 211.299988'
});
data_peak.push({
lat: 4.2111888888e+01,
lng: 1.4024188889e+02,
cert : false,
content:' Peak = 793.900024 pos = 42.1119,140.2419 diff = 220.900024'
});
data_saddle.push({
lat: 4.2101888888e+01,
lng: 1.4024555556e+02,
content:'Saddle = 573.000000 pos = 42.1019,140.2456 diff = 220.900024'
});
data_peak.push({
lat: 4.2067888888e+01,
lng: 1.4026600000e+02,
cert : false,
content:' Peak = 731.900024 pos = 42.0679,140.2660 diff = 151.400024'
});
data_saddle.push({
lat: 4.2062000000e+01,
lng: 1.4026633333e+02,
content:'Saddle = 580.500000 pos = 42.0620,140.2663 diff = 151.400024'
});
data_peak.push({
lat: 4.2038888888e+01,
lng: 1.4032322222e+02,
cert : true,
content:'Name = JA8/HY-013(JA8/HY-013) peak = 772.700012 pos = 42.0389,140.3232 diff = 180.600037'
});
data_saddle.push({
lat: 4.2050111111e+01,
lng: 1.4031311111e+02,
content:'Saddle = 592.099976 pos = 42.0501,140.3131 diff = 180.600037'
});
data_peak.push({
lat: 4.2153888889e+01,
lng: 1.4011622222e+02,
cert : true,
content:'Name = JA8/OM-006(JA8/OM-006) peak = 993.200012 pos = 42.1539,140.1162 diff = 399.200012'
});
data_saddle.push({
lat: 4.2072777777e+01,
lng: 1.4023011111e+02,
content:'Saddle = 594.000000 pos = 42.0728,140.2301 diff = 399.200012'
});
data_peak.push({
lat: 4.2086666666e+01,
lng: 1.4024033333e+02,
cert : false,
content:' Peak = 902.200012 pos = 42.0867,140.2403 diff = 222.100037'
});
data_saddle.push({
lat: 4.2111000000e+01,
lng: 1.4019077778e+02,
content:'Saddle = 680.099976 pos = 42.1110,140.1908 diff = 222.100037'
});
data_peak.push({
lat: 4.2138888888e+01,
lng: 1.4023455556e+02,
cert : true,
content:'Name = JA8/OM-007(JA8/OM-007) peak = 981.799988 pos = 42.1389,140.2346 diff = 288.899963'
});
data_saddle.push({
lat: 4.2121111111e+01,
lng: 1.4020422222e+02,
content:'Saddle = 692.900024 pos = 42.1211,140.2042 diff = 288.899963'
});
data_peak.push({
lat: 4.2145555555e+01,
lng: 1.4014577778e+02,
cert : true,
content:'Name = JA8/OM-008(JA8/OM-008) peak = 963.200012 pos = 42.1456,140.1458 diff = 166.299988'
});
data_saddle.push({
lat: 4.2144888889e+01,
lng: 1.4012544444e+02,
content:'Saddle = 796.900024 pos = 42.1449,140.1254 diff = 166.299988'
});
data_peak.push({
lat: 4.2134000000e+01,
lng: 1.4017700000e+02,
cert : true,
content:'Name = JA8/OM-010(JA8/OM-010) peak = 955.799988 pos = 42.1340,140.1770 diff = 152.700012'
});
data_saddle.push({
lat: 4.2144777777e+01,
lng: 1.4017077778e+02,
content:'Saddle = 803.099976 pos = 42.1448,140.1708 diff = 152.700012'
});
data_peak.push({
lat: 4.2183222222e+01,
lng: 1.3993388889e+02,
cert : true,
content:'Name = JA8/OM-048(JA8/OM-048) peak = 612.599976 pos = 42.1832,139.9339 diff = 189.699982'
});
data_saddle.push({
lat: 4.2186444444e+01,
lng: 1.3994266667e+02,
content:'Saddle = 422.899994 pos = 42.1864,139.9427 diff = 189.699982'
});
data_peak.push({
lat: 4.2154000000e+01,
lng: 1.4006344444e+02,
cert : false,
content:' Peak = 583.700012 pos = 42.1540,140.0634 diff = 155.000000'
});
data_saddle.push({
lat: 4.2181666666e+01,
lng: 1.4009100000e+02,
content:'Saddle = 428.700012 pos = 42.1817,140.0910 diff = 155.000000'
});
data_peak.push({
lat: 4.2154666666e+01,
lng: 1.3998466667e+02,
cert : false,
content:' Peak = 614.500000 pos = 42.1547,139.9847 diff = 167.100006'
});
data_saddle.push({
lat: 4.2160000000e+01,
lng: 1.3998222222e+02,
content:'Saddle = 447.399994 pos = 42.1600,139.9822 diff = 167.100006'
});
data_peak.push({
lat: 4.2201222222e+01,
lng: 1.4008333333e+02,
cert : true,
content:'Name = JA8/OM-020(JA8/OM-020) peak = 800.599976 pos = 42.2012,140.0833 diff = 258.500000'
});
data_saddle.push({
lat: 4.2203666666e+01,
lng: 1.4009355556e+02,
content:'Saddle = 542.099976 pos = 42.2037,140.0936 diff = 258.500000'
});
data_peak.push({
lat: 4.2217444444e+01,
lng: 1.4009788889e+02,
cert : true,
content:'Name = JA8/OM-014(JA8/OM-014) peak = 851.500000 pos = 42.2174,140.0979 diff = 309.200012'
});
data_saddle.push({
lat: 4.2209333333e+01,
lng: 1.4008266667e+02,
content:'Saddle = 542.299988 pos = 42.2093,140.0827 diff = 309.200012'
});
data_peak.push({
lat: 4.2239222222e+01,
lng: 1.4003033333e+02,
cert : true,
content:'Name = JA8/HY-003(JA8/HY-003) peak = 1051.099976 pos = 42.2392,140.0303 diff = 208.399963'
});
data_saddle.push({
lat: 4.2234111111e+01,
lng: 1.4003611111e+02,
content:'Saddle = 842.700012 pos = 42.2341,140.0361 diff = 208.399963'
});
data_peak.push({
lat: 4.2182333333e+01,
lng: 1.4001866667e+02,
cert : true,
content:'Name = JA8/OM-002(JA8/OM-002) peak = 1173.400024 pos = 42.1823,140.0187 diff = 270.400024'
});
data_saddle.push({
lat: 4.2192333333e+01,
lng: 1.4001422222e+02,
content:'Saddle = 903.000000 pos = 42.1923,140.0142 diff = 270.400024'
});
data_peak.push({
lat: 4.2198000000e+01,
lng: 1.3999111111e+02,
cert : true,
content:'Name = JA8/HY-002(JA8/HY-002) peak = 1135.599976 pos = 42.1980,139.9911 diff = 173.599976'
});
data_saddle.push({
lat: 4.2201444444e+01,
lng: 1.4000088889e+02,
content:'Saddle = 962.000000 pos = 42.2014,140.0009 diff = 173.599976'
});
data_peak.push({
lat: 4.2483666667e+01,
lng: 1.4028622222e+02,
cert : true,
content:'Name = JA8/OM-065(JA8/OM-065) peak = 352.200012 pos = 42.4837,140.2862 diff = 179.700012'
});
data_saddle.push({
lat: 4.2488000000e+01,
lng: 1.4027822222e+02,
content:'Saddle = 172.500000 pos = 42.4880,140.2782 diff = 179.700012'
});
data_peak.push({
lat: 4.2554777778e+01,
lng: 1.4028844444e+02,
cert : true,
content:'Name = JA8/OM-053(JA8/OM-053) peak = 566.700012 pos = 42.5548,140.2884 diff = 294.200012'
});
data_saddle.push({
lat: 4.2551444444e+01,
lng: 1.4027366667e+02,
content:'Saddle = 272.500000 pos = 42.5514,140.2737 diff = 294.200012'
});
data_peak.push({
lat: 4.2618888889e+01,
lng: 1.4024211111e+02,
cert : true,
content:'Name = JA8/SB-038(JA8/SB-038) peak = 750.700012 pos = 42.6189,140.2421 diff = 318.100006'
});
data_saddle.push({
lat: 4.2611777778e+01,
lng: 1.4022522222e+02,
content:'Saddle = 432.600006 pos = 42.6118,140.2252 diff = 318.100006'
});
data_peak.push({
lat: 4.2553777778e+01,
lng: 1.4025200000e+02,
cert : true,
content:'Name = JA8/OM-039(JA8/OM-039) peak = 673.000000 pos = 42.5538,140.2520 diff = 180.100006'
});
data_saddle.push({
lat: 4.2567000000e+01,
lng: 1.4024788889e+02,
content:'Saddle = 492.899994 pos = 42.5670,140.2479 diff = 180.100006'
});
data_peak.push({
lat: 4.2558111111e+01,
lng: 1.4021244444e+02,
cert : false,
content:' Peak = 721.900024 pos = 42.5581,140.2124 diff = 214.200012'
});
data_saddle.push({
lat: 4.2573888889e+01,
lng: 1.4021811111e+02,
content:'Saddle = 507.700012 pos = 42.5739,140.2181 diff = 214.200012'
});
data_peak.push({
lat: 4.2636000000e+01,
lng: 1.4013555556e+02,
cert : true,
content:'Name = Oobirayama(JA8/SB-010) peak = 1192.300049 pos = 42.6360,140.1356 diff = 609.500061'
});
data_saddle.push({
lat: 4.2552333333e+01,
lng: 1.4009922222e+02,
content:'Saddle = 582.799988 pos = 42.5523,140.0992 diff = 609.500061'
});
data_peak.push({
lat: 4.2546888889e+01,
lng: 1.4015366667e+02,
cert : true,
content:'Name = JA8/HY-008(JA8/HY-008) peak = 985.099976 pos = 42.5469,140.1537 diff = 378.299988'
});
data_saddle.push({
lat: 4.2561666667e+01,
lng: 1.4013266667e+02,
content:'Saddle = 606.799988 pos = 42.5617,140.1327 diff = 378.299988'
});
data_peak.push({
lat: 4.2597333333e+01,
lng: 1.4012211111e+02,
cert : true,
content:'Name = JA8/SB-029(JA8/SB-029) peak = 842.700012 pos = 42.5973,140.1221 diff = 165.700012'
});
data_saddle.push({
lat: 4.2602555556e+01,
lng: 1.4012644444e+02,
content:'Saddle = 677.000000 pos = 42.6026,140.1264 diff = 165.700012'
});
data_peak.push({
lat: 4.2586000000e+01,
lng: 1.4018944444e+02,
cert : true,
content:'Name = JA8/HY-009(JA8/HY-009) peak = 973.200012 pos = 42.5860,140.1894 diff = 200.200012'
});
data_saddle.push({
lat: 4.2590555556e+01,
lng: 1.4018977778e+02,
content:'Saddle = 773.000000 pos = 42.5906,140.1898 diff = 200.200012'
});
data_peak.push({
lat: 4.2579888889e+01,
lng: 1.4015244444e+02,
cert : true,
content:'Name = JA8/HY-005(JA8/HY-005) peak = 1021.599976 pos = 42.5799,140.1524 diff = 234.500000'
});
data_saddle.push({
lat: 4.2588222222e+01,
lng: 1.4015588889e+02,
content:'Saddle = 787.099976 pos = 42.5882,140.1559 diff = 234.500000'
});
data_peak.push({
lat: 4.2545222222e+01,
lng: 1.3998211111e+02,
cert : true,
content:'Name = JA8/HY-004(JA8/HY-004) peak = 1044.599976 pos = 42.5452,139.9821 diff = 312.000000'
});
data_saddle.push({
lat: 4.2545333333e+01,
lng: 1.4000088889e+02,
content:'Saddle = 732.599976 pos = 42.5453,140.0009 diff = 312.000000'
});
data_peak.push({
lat: 4.2539888889e+01,
lng: 1.4002022222e+02,
cert : true,
content:'Name = JA8/HY-001(JA8/HY-001) peak = 1141.599976 pos = 42.5399,140.0202 diff = 393.699951'
});
data_saddle.push({
lat: 4.2574444444e+01,
lng: 1.4001677778e+02,
content:'Saddle = 747.900024 pos = 42.5744,140.0168 diff = 393.699951'
});
data_peak.push({
lat: 4.2584111111e+01,
lng: 1.4001888889e+02,
cert : true,
content:'Name = JA8/SB-019(JA8/SB-019) peak = 1010.599976 pos = 42.5841,140.0189 diff = 227.500000'
});
data_saddle.push({
lat: 4.2587666667e+01,
lng: 1.3996588889e+02,
content:'Saddle = 783.099976 pos = 42.5877,139.9659 diff = 227.500000'
});
data_peak.push({
lat: 4.2571666667e+01,
lng: 1.3988422222e+02,
cert : true,
content:'Name = JA8/HY-007(JA8/HY-007) peak = 1002.400024 pos = 42.5717,139.8842 diff = 200.800049'
});
data_saddle.push({
lat: 4.2568555556e+01,
lng: 1.3990433333e+02,
content:'Saddle = 801.599976 pos = 42.5686,139.9043 diff = 200.800049'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:42.6667,
       south:41.3333,
       east:142,
       west:139}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
