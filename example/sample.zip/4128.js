function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 2.7778777778e+01,
lng: 1.2898333333e+02,
cert : true,
content:'Name = Inokawadake(JA6/KG-038) peak = 643.299988 pos = 27.7788,128.9833 diff = 643.299988'
});
data_saddle.push({
lat: 2.7998000000e+01,
lng: 1.2925177778e+02,
content:'Saddle = 0.000000 pos = 27.9980,129.2518 diff = 643.299988'
});
data_peak.push({
lat: 2.7881222222e+01,
lng: 1.2822244444e+02,
cert : true,
content:'Name = JA6/ON-035(JA6/ON-035) peak = 211.399994 pos = 27.8812,128.2224 diff = 211.399994'
});
data_saddle.push({
lat: 2.7860222222e+01,
lng: 1.2823422222e+02,
content:'Saddle = 0.000000 pos = 27.8602,128.2342 diff = 211.399994'
});
data_peak.push({
lat: 2.7366666667e+01,
lng: 1.2856644444e+02,
cert : false,
content:' Peak = 244.699997 pos = 27.3667,128.5664 diff = 244.699997'
});
data_saddle.push({
lat: 2.7661000000e+01,
lng: 1.2893644444e+02,
content:'Saddle = 0.000000 pos = 27.6610,128.9364 diff = 244.699997'
});
data_peak.push({
lat: 2.7870555556e+01,
lng: 1.2892800000e+02,
cert : true,
content:'Name = JA6/KG-058(JA6/KG-058) peak = 530.900024 pos = 27.8706,128.9280 diff = 419.600037'
});
data_saddle.push({
lat: 2.7823111111e+01,
lng: 1.2892588889e+02,
content:'Saddle = 111.300003 pos = 27.8231,128.9259 diff = 419.600037'
});
data_peak.push({
lat: 2.7738444445e+01,
lng: 1.2894544444e+02,
cert : true,
content:'Name = JA6/KG-097(JA6/KG-097) peak = 412.299988 pos = 27.7384,128.9454 diff = 203.699982'
});
data_saddle.push({
lat: 2.7738777778e+01,
lng: 1.2896777778e+02,
content:'Saddle = 208.600006 pos = 27.7388,128.9678 diff = 203.699982'
});
data_peak.push({
lat: 2.7799222222e+01,
lng: 1.2894177778e+02,
cert : false,
content:' Peak = 434.500000 pos = 27.7992,128.9418 diff = 156.700012'
});
data_saddle.push({
lat: 2.7798777778e+01,
lng: 1.2895344444e+02,
content:'Saddle = 277.799988 pos = 27.7988,128.9534 diff = 156.700012'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:28,
       south:27.3333,
       east:130,
       west:128}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
