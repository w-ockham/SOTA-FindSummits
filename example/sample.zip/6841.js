function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 4.5372444445e+01,
lng: 1.4101566667e+02,
cert : true,
content:'Name = Rebundake(JA8/SY-017) peak = 482.500000 pos = 45.3724,141.0157 diff = 482.500000'
});
data_saddle.push({
lat: 4.5525555556e+01,
lng: 1.4191977778e+02,
content:'Saddle = 0.000000 pos = 45.5256,141.9198 diff = 482.500000'
});
data_peak.push({
lat: 4.5342000000e+01,
lng: 1.4196200000e+02,
cert : false,
content:' Peak = 248.000000 pos = 45.3420,141.9620 diff = 248.000000'
});
data_saddle.push({
lat: 4.5333444445e+01,
lng: 1.4105111111e+02,
content:'Saddle = 0.000000 pos = 45.3334,141.0511 diff = 248.000000'
});
data_peak.push({
lat: 4.5406000000e+01,
lng: 1.4164877778e+02,
cert : true,
content:'Name = JA8/SY-031(JA8/SY-031) peak = 210.300003 pos = 45.4060,141.6488 diff = 203.400009'
});
data_saddle.push({
lat: 4.5364666667e+01,
lng: 1.4180533333e+02,
content:'Saddle = 6.900000 pos = 45.3647,141.8053 diff = 203.400009'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:46,
       south:45.3333,
       east:143,
       west:141}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
