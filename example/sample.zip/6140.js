function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.9099444445e+01,
lng: 1.4004877778e+02,
cert : true,
content:'Name = Chyoukaizan (Shinzan)(JA/YM-001) peak = 2234.899902 pos = 39.0994,140.0488 diff = 2234.899902'
});
data_saddle.push({
lat: 4.1333333333e+01,
lng: 1.4000000000e+02,
content:'Saddle = 0.000000 pos = 41.3333,140.0000 diff = 2234.899902'
});
data_peak.push({
lat: 4.1278777778e+01,
lng: 1.4111988889e+02,
cert : true,
content:'Name = Kamafuseyama(JA/AM-020) peak = 876.599976 pos = 41.2788,141.1199 diff = 868.799988'
});
data_saddle.push({
lat: 4.1323111111e+01,
lng: 1.4126822222e+02,
content:'Saddle = 7.800000 pos = 41.3231,141.2682 diff = 868.799988'
});
data_peak.push({
lat: 4.1201333333e+01,
lng: 1.4078166667e+02,
cert : true,
content:'Name = JA/AM-070(JA/AM-070) peak = 335.500000 pos = 41.2013,140.7817 diff = 206.699997'
});
data_saddle.push({
lat: 4.1206666667e+01,
lng: 1.4078744444e+02,
content:'Saddle = 128.800003 pos = 41.2067,140.7874 diff = 206.699997'
});
data_peak.push({
lat: 4.1156111111e+01,
lng: 1.4078277778e+02,
cert : false,
content:' Peak = 301.299988 pos = 41.1561,140.7828 diff = 163.199982'
});
data_saddle.push({
lat: 4.1168888889e+01,
lng: 1.4077122222e+02,
content:'Saddle = 138.100006 pos = 41.1689,140.7712 diff = 163.199982'
});
data_peak.push({
lat: 4.1181666667e+01,
lng: 1.4077522222e+02,
cert : false,
content:' Peak = 305.000000 pos = 41.1817,140.7752 diff = 163.000000'
});
data_saddle.push({
lat: 4.1186222222e+01,
lng: 1.4076833333e+02,
content:'Saddle = 142.000000 pos = 41.1862,140.7683 diff = 163.000000'
});
data_peak.push({
lat: 4.1324555556e+01,
lng: 1.4086011111e+02,
cert : true,
content:'Name = JA/AM-031(JA/AM-031) peak = 775.200012 pos = 41.3246,140.8601 diff = 640.099976'
});
data_saddle.push({
lat: 4.1333111111e+01,
lng: 1.4096088889e+02,
content:'Saddle = 135.100006 pos = 41.3331,140.9609 diff = 640.099976'
});
data_peak.push({
lat: 4.1332111111e+01,
lng: 1.4082322222e+02,
cert : false,
content:' Peak = 344.200012 pos = 41.3321,140.8232 diff = 174.300018'
});
data_saddle.push({
lat: 4.1333333333e+01,
lng: 1.4083477778e+02,
content:'Saddle = 169.899994 pos = 41.3333,140.8348 diff = 174.300018'
});
data_peak.push({
lat: 4.1238888889e+01,
lng: 1.4081633333e+02,
cert : true,
content:'Name = JA/AM-048(JA/AM-048) peak = 643.500000 pos = 41.2389,140.8163 diff = 429.700012'
});
data_saddle.push({
lat: 4.1272888889e+01,
lng: 1.4083788889e+02,
content:'Saddle = 213.800003 pos = 41.2729,140.8379 diff = 429.700012'
});
data_peak.push({
lat: 4.1263000000e+01,
lng: 1.4095755556e+02,
cert : true,
content:'Name = JA/AM-060(JA/AM-060) peak = 554.400024 pos = 41.2630,140.9576 diff = 251.500031'
});
data_saddle.push({
lat: 4.1245222222e+01,
lng: 1.4093300000e+02,
content:'Saddle = 302.899994 pos = 41.2452,140.9330 diff = 251.500031'
});
data_peak.push({
lat: 4.1281000000e+01,
lng: 1.4096033333e+02,
cert : true,
content:'Name = JA/AM-065(JA/AM-065) peak = 501.799988 pos = 41.2810,140.9603 diff = 164.199982'
});
data_saddle.push({
lat: 4.1270333333e+01,
lng: 1.4095911111e+02,
content:'Saddle = 337.600006 pos = 41.2703,140.9591 diff = 164.199982'
});
data_peak.push({
lat: 4.1236777778e+01,
lng: 1.4087877778e+02,
cert : true,
content:'Name = JA/AM-049(JA/AM-049) peak = 630.500000 pos = 41.2368,140.8788 diff = 250.200012'
});
data_saddle.push({
lat: 4.1226666667e+01,
lng: 1.4085844444e+02,
content:'Saddle = 380.299988 pos = 41.2267,140.8584 diff = 250.200012'
});
data_peak.push({
lat: 4.1313222222e+01,
lng: 1.4082222222e+02,
cert : true,
content:'Name = JA/AM-063(JA/AM-063) peak = 514.799988 pos = 41.3132,140.8222 diff = 226.599976'
});
data_saddle.push({
lat: 4.1305111111e+01,
lng: 1.4082955556e+02,
content:'Saddle = 288.200012 pos = 41.3051,140.8296 diff = 226.599976'
});
data_peak.push({
lat: 4.1299222222e+01,
lng: 1.4082811111e+02,
cert : false,
content:' Peak = 510.899994 pos = 41.2992,140.8281 diff = 184.699982'
});
data_saddle.push({
lat: 4.1308222222e+01,
lng: 1.4084633333e+02,
content:'Saddle = 326.200012 pos = 41.3082,140.8463 diff = 184.699982'
});
data_peak.push({
lat: 4.1313333333e+01,
lng: 1.4084700000e+02,
cert : false,
content:' Peak = 622.900024 pos = 41.3133,140.8470 diff = 165.700012'
});
data_saddle.push({
lat: 4.1313555556e+01,
lng: 1.4085400000e+02,
content:'Saddle = 457.200012 pos = 41.3136,140.8540 diff = 165.700012'
});
data_peak.push({
lat: 4.1327666667e+01,
lng: 1.4102466667e+02,
cert : true,
content:'Name = JA/AM-021(JA/AM-021) peak = 874.200012 pos = 41.3277,141.0247 diff = 391.500000'
});
data_saddle.push({
lat: 4.1290111111e+01,
lng: 1.4108955556e+02,
content:'Saddle = 482.700012 pos = 41.2901,141.0896 diff = 391.500000'
});
data_peak.push({
lat: 4.1293000000e+01,
lng: 1.4106844444e+02,
cert : true,
content:'Name = JA/AM-025(JA/AM-025) peak = 822.000000 pos = 41.2930,141.0684 diff = 330.299988'
});
data_saddle.push({
lat: 4.1300777778e+01,
lng: 1.4104911111e+02,
content:'Saddle = 491.700012 pos = 41.3008,141.0491 diff = 330.299988'
});
data_peak.push({
lat: 4.0952555556e+01,
lng: 1.4091600000e+02,
cert : true,
content:'Name = JA/AM-071(JA/AM-071) peak = 321.000000 pos = 40.9526,140.9160 diff = 284.100006'
});
data_saddle.push({
lat: 4.0917444445e+01,
lng: 1.4088033333e+02,
content:'Saddle = 36.900002 pos = 40.9174,140.8803 diff = 284.100006'
});
data_peak.push({
lat: 4.0931777778e+01,
lng: 1.4087588889e+02,
cert : false,
content:' Peak = 230.199997 pos = 40.9318,140.8759 diff = 162.799988'
});
data_saddle.push({
lat: 4.0935777778e+01,
lng: 1.4088366667e+02,
content:'Saddle = 67.400002 pos = 40.9358,140.8837 diff = 162.799988'
});
data_peak.push({
lat: 4.1088777778e+01,
lng: 1.4134455556e+02,
cert : true,
content:'Name = JA/AM-059(JA/AM-059) peak = 550.400024 pos = 41.0888,141.3446 diff = 497.300018'
});
data_saddle.push({
lat: 4.0963888889e+01,
lng: 1.4125933333e+02,
content:'Saddle = 53.099998 pos = 40.9639,141.2593 diff = 497.300018'
});
data_peak.push({
lat: 4.1327111111e+01,
lng: 1.4140622222e+02,
cert : true,
content:'Name = JA/AM-072(JA/AM-072) peak = 301.399994 pos = 41.3271,141.4062 diff = 234.199997'
});
data_saddle.push({
lat: 4.1261444444e+01,
lng: 1.4136688889e+02,
content:'Saddle = 67.199997 pos = 41.2614,141.3669 diff = 234.199997'
});
data_peak.push({
lat: 4.1023555556e+01,
lng: 1.4134022222e+02,
cert : true,
content:'Name = JA/AM-066(JA/AM-066) peak = 465.600006 pos = 41.0236,141.3402 diff = 174.600006'
});
data_saddle.push({
lat: 4.1043111111e+01,
lng: 1.4134088889e+02,
content:'Saddle = 291.000000 pos = 41.0431,141.3409 diff = 174.600006'
});
data_peak.push({
lat: 4.1126666667e+01,
lng: 1.4025300000e+02,
cert : false,
content:' Peak = 228.600006 pos = 41.1267,140.2530 diff = 172.500000'
});
data_saddle.push({
lat: 4.1117777778e+01,
lng: 1.4030055556e+02,
content:'Saddle = 56.099998 pos = 41.1178,140.3006 diff = 172.500000'
});
data_peak.push({
lat: 4.0896111111e+01,
lng: 1.4089144444e+02,
cert : true,
content:'Name = JA/AM-068(JA/AM-068) peak = 381.799988 pos = 40.8961,140.8914 diff = 304.500000'
});
data_saddle.push({
lat: 4.0886555556e+01,
lng: 1.4089233333e+02,
content:'Saddle = 77.300003 pos = 40.8866,140.8923 diff = 304.500000'
});
data_peak.push({
lat: 4.0894111111e+01,
lng: 1.4096488889e+02,
cert : false,
content:' Peak = 264.100006 pos = 40.8941,140.9649 diff = 167.100006'
});
data_saddle.push({
lat: 4.0881777778e+01,
lng: 1.4096966667e+02,
content:'Saddle = 97.000000 pos = 40.8818,140.9697 diff = 167.100006'
});
data_peak.push({
lat: 4.1141777778e+01,
lng: 1.4040177778e+02,
cert : true,
content:'Name = JA/AM-040(JA/AM-040) peak = 714.200012 pos = 41.1418,140.4018 diff = 612.900024'
});
data_saddle.push({
lat: 4.1071111111e+01,
lng: 1.4049077778e+02,
content:'Saddle = 101.300003 pos = 41.0711,140.4908 diff = 612.900024'
});
data_peak.push({
lat: 4.1153000000e+01,
lng: 1.4058655556e+02,
cert : true,
content:'Name = Maruyagatadake(JA/AM-039) peak = 711.599976 pos = 41.1530,140.5866 diff = 588.500000'
});
data_saddle.push({
lat: 4.1106222222e+01,
lng: 1.4053411111e+02,
content:'Saddle = 123.099998 pos = 41.1062,140.5341 diff = 588.500000'
});
data_peak.push({
lat: 4.1169555556e+01,
lng: 1.4057855556e+02,
cert : false,
content:' Peak = 705.599976 pos = 41.1696,140.5786 diff = 258.199982'
});
data_saddle.push({
lat: 4.1159666667e+01,
lng: 1.4058000000e+02,
content:'Saddle = 447.399994 pos = 41.1597,140.5800 diff = 258.199982'
});
data_peak.push({
lat: 4.1151666667e+01,
lng: 1.4057277778e+02,
cert : false,
content:' Peak = 684.900024 pos = 41.1517,140.5728 diff = 163.000000'
});
data_saddle.push({
lat: 4.1151333333e+01,
lng: 1.4057800000e+02,
content:'Saddle = 521.900024 pos = 41.1513,140.5780 diff = 163.000000'
});
data_peak.push({
lat: 4.1112666667e+01,
lng: 1.4047200000e+02,
cert : false,
content:' Peak = 445.799988 pos = 41.1127,140.4720 diff = 174.599976'
});
data_saddle.push({
lat: 4.1117000000e+01,
lng: 1.4045700000e+02,
content:'Saddle = 271.200012 pos = 41.1170,140.4570 diff = 174.599976'
});
data_peak.push({
lat: 4.1212222222e+01,
lng: 1.4036866667e+02,
cert : true,
content:'Name = JA/AM-058(JA/AM-058) peak = 553.299988 pos = 41.2122,140.3687 diff = 191.699982'
});
data_saddle.push({
lat: 4.1184111111e+01,
lng: 1.4036888889e+02,
content:'Saddle = 361.600006 pos = 41.1841,140.3689 diff = 191.699982'
});
data_peak.push({
lat: 4.1173777778e+01,
lng: 1.4037033333e+02,
cert : true,
content:'Name = JA/AM-056(JA/AM-056) peak = 584.000000 pos = 41.1738,140.3703 diff = 201.399994'
});
data_saddle.push({
lat: 4.1146222222e+01,
lng: 1.4037255556e+02,
content:'Saddle = 382.600006 pos = 41.1462,140.3726 diff = 201.399994'
});
data_peak.push({
lat: 4.1121666667e+01,
lng: 1.4040022222e+02,
cert : true,
content:'Name = Yotsudakiyama(JA/AM-046) peak = 662.900024 pos = 41.1217,140.4002 diff = 266.900024'
});
data_saddle.push({
lat: 4.1131888889e+01,
lng: 1.4039966667e+02,
content:'Saddle = 396.000000 pos = 41.1319,140.3997 diff = 266.900024'
});
data_peak.push({
lat: 4.1144888889e+01,
lng: 1.4043888889e+02,
cert : true,
content:'Name = JA/AM-054(JA/AM-054) peak = 604.400024 pos = 41.1449,140.4389 diff = 193.600037'
});
data_saddle.push({
lat: 4.1134333333e+01,
lng: 1.4043166667e+02,
content:'Saddle = 410.799988 pos = 41.1343,140.4317 diff = 193.600037'
});
data_peak.push({
lat: 4.0970222222e+01,
lng: 1.4054811111e+02,
cert : true,
content:'Name = JA/AM-045(JA/AM-045) peak = 673.400024 pos = 40.9702,140.5481 diff = 566.200012'
});
data_saddle.push({
lat: 4.0751222222e+01,
lng: 1.4061400000e+02,
content:'Saddle = 107.199997 pos = 40.7512,140.6140 diff = 566.200012'
});
data_peak.push({
lat: 4.0829000000e+01,
lng: 1.4057700000e+02,
cert : true,
content:'Name = JA/AM-061(JA/AM-061) peak = 548.000000 pos = 40.8290,140.5770 diff = 393.000000'
});
data_saddle.push({
lat: 4.0883444445e+01,
lng: 1.4058966667e+02,
content:'Saddle = 155.000000 pos = 40.8834,140.5897 diff = 393.000000'
});
data_peak.push({
lat: 4.0995555556e+01,
lng: 1.4052155556e+02,
cert : true,
content:'Name = JA/AM-050(JA/AM-050) peak = 624.700012 pos = 40.9956,140.5216 diff = 191.500000'
});
data_saddle.push({
lat: 4.0983444445e+01,
lng: 1.4054244444e+02,
content:'Saddle = 433.200012 pos = 40.9834,140.5424 diff = 191.500000'
});
data_peak.push({
lat: 3.9538555556e+01,
lng: 1.4197488889e+02,
cert : true,
content:'Name = Jyuunishinzan(JA/IT-115) peak = 730.799988 pos = 39.5386,141.9749 diff = 603.399963'
});
data_saddle.push({
lat: 3.9492000001e+01,
lng: 1.4192688889e+02,
content:'Saddle = 127.400002 pos = 39.4920,141.9269 diff = 603.399963'
});
data_peak.push({
lat: 3.9614555556e+01,
lng: 1.4199788889e+02,
cert : false,
content:' Peak = 350.399994 pos = 39.6146,141.9979 diff = 199.899994'
});
data_saddle.push({
lat: 3.9606555556e+01,
lng: 1.4199988889e+02,
content:'Saddle = 150.500000 pos = 39.6066,141.9999 diff = 199.899994'
});
data_peak.push({
lat: 3.8802222223e+01,
lng: 1.4147311111e+02,
cert : true,
content:'Name = JA/MG-063(JA/MG-063) peak = 333.399994 pos = 38.8022,141.4731 diff = 201.099991'
});
data_saddle.push({
lat: 3.8807777779e+01,
lng: 1.4146644444e+02,
content:'Saddle = 132.300003 pos = 38.8078,141.4664 diff = 201.099991'
});
data_peak.push({
lat: 3.9230222223e+01,
lng: 1.4193355556e+02,
cert : false,
content:' Peak = 341.700012 pos = 39.2302,141.9336 diff = 208.900009'
});
data_saddle.push({
lat: 3.9229444445e+01,
lng: 1.4192122222e+02,
content:'Saddle = 132.800003 pos = 39.2294,141.9212 diff = 208.900009'
});
data_peak.push({
lat: 3.8962333334e+01,
lng: 1.4127322222e+02,
cert : true,
content:'Name = JA/IT-168(JA/IT-168) peak = 433.899994 pos = 38.9623,141.2732 diff = 296.700012'
});
data_saddle.push({
lat: 3.8966444445e+01,
lng: 1.4133255556e+02,
content:'Saddle = 137.199997 pos = 38.9664,141.3326 diff = 296.700012'
});
data_peak.push({
lat: 3.9276000001e+01,
lng: 1.4118944444e+02,
cert : false,
content:' Peak = 357.600006 pos = 39.2760,141.1894 diff = 208.600006'
});
data_saddle.push({
lat: 3.9311777779e+01,
lng: 1.4118344444e+02,
content:'Saddle = 149.000000 pos = 39.3118,141.1834 diff = 208.600006'
});
data_peak.push({
lat: 3.8938777779e+01,
lng: 1.4123055556e+02,
cert : true,
content:'Name = JA/IT-177(JA/IT-177) peak = 354.200012 pos = 38.9388,141.2306 diff = 190.700012'
});
data_saddle.push({
lat: 3.8976888890e+01,
lng: 1.4122611111e+02,
content:'Saddle = 163.500000 pos = 38.9769,141.2261 diff = 190.700012'
});
data_peak.push({
lat: 3.8963333334e+01,
lng: 1.4120355556e+02,
cert : true,
content:'Name = JA/IT-178(JA/IT-178) peak = 350.500000 pos = 38.9633,141.2036 diff = 179.699997'
});
data_saddle.push({
lat: 3.8967222223e+01,
lng: 1.4119811111e+02,
content:'Saddle = 170.800003 pos = 38.9672,141.1981 diff = 179.699997'
});
data_peak.push({
lat: 3.8815333334e+01,
lng: 1.4145900000e+02,
cert : false,
content:' Peak = 347.500000 pos = 38.8153,141.4590 diff = 174.899994'
});
data_saddle.push({
lat: 3.8811666668e+01,
lng: 1.4144300000e+02,
content:'Saddle = 172.600006 pos = 38.8117,141.4430 diff = 174.899994'
});
data_peak.push({
lat: 3.9016555556e+01,
lng: 1.4169100000e+02,
cert : true,
content:'Name = JA/IT-165(JA/IT-165) peak = 445.799988 pos = 39.0166,141.6910 diff = 267.699982'
});
data_saddle.push({
lat: 3.9025666668e+01,
lng: 1.4168777778e+02,
content:'Saddle = 178.100006 pos = 39.0257,141.6878 diff = 267.699982'
});
data_peak.push({
lat: 4.0881111111e+01,
lng: 1.4092011111e+02,
cert : true,
content:'Name = JA/AM-069(JA/AM-069) peak = 361.700012 pos = 40.8811,140.9201 diff = 181.900009'
});
data_saddle.push({
lat: 4.0876000000e+01,
lng: 1.4091500000e+02,
content:'Saddle = 179.800003 pos = 40.8760,140.9150 diff = 181.900009'
});
data_peak.push({
lat: 4.0891333333e+01,
lng: 1.4093577778e+02,
cert : false,
content:' Peak = 343.100006 pos = 40.8913,140.9358 diff = 161.000000'
});
data_saddle.push({
lat: 4.0890333333e+01,
lng: 1.4093055556e+02,
content:'Saddle = 182.100006 pos = 40.8903,140.9306 diff = 161.000000'
});
data_peak.push({
lat: 3.9668555556e+01,
lng: 1.4109211111e+02,
cert : true,
content:'Name = JA/IT-175(JA/IT-175) peak = 358.100006 pos = 39.6686,141.0921 diff = 169.900009'
});
data_saddle.push({
lat: 3.9667333334e+01,
lng: 1.4108311111e+02,
content:'Saddle = 188.199997 pos = 39.6673,141.0831 diff = 169.900009'
});
data_peak.push({
lat: 3.9286555556e+01,
lng: 1.4187566667e+02,
cert : true,
content:'Name = JA/IT-172(JA/IT-172) peak = 381.000000 pos = 39.2866,141.8757 diff = 189.000000'
});
data_saddle.push({
lat: 3.9282333334e+01,
lng: 1.4186211111e+02,
content:'Saddle = 192.000000 pos = 39.2823,141.8621 diff = 189.000000'
});
data_peak.push({
lat: 3.8926777779e+01,
lng: 1.4156322222e+02,
cert : false,
content:' Peak = 346.799988 pos = 38.9268,141.5632 diff = 154.299988'
});
data_saddle.push({
lat: 3.8934000001e+01,
lng: 1.4156033333e+02,
content:'Saddle = 192.500000 pos = 38.9340,141.5603 diff = 154.299988'
});
data_peak.push({
lat: 3.9182777779e+01,
lng: 1.4127922222e+02,
cert : true,
content:'Name = JA/IT-173(JA/IT-173) peak = 364.100006 pos = 39.1828,141.2792 diff = 167.400009'
});
data_saddle.push({
lat: 3.9187888890e+01,
lng: 1.4128233333e+02,
content:'Saddle = 196.699997 pos = 39.1879,141.2823 diff = 167.400009'
});
data_peak.push({
lat: 3.9012888890e+01,
lng: 1.4118388889e+02,
cert : true,
content:'Name = JA/IT-146(JA/IT-146) peak = 595.299988 pos = 39.0129,141.1839 diff = 398.000000'
});
data_saddle.push({
lat: 3.9041333334e+01,
lng: 1.4120566667e+02,
content:'Saddle = 197.300003 pos = 39.0413,141.2057 diff = 398.000000'
});
data_peak.push({
lat: 3.8862000001e+01,
lng: 1.4145211111e+02,
cert : true,
content:'Name = JA/IT-105(JA/IT-105) peak = 760.099976 pos = 38.8620,141.4521 diff = 561.199951'
});
data_saddle.push({
lat: 3.8936333334e+01,
lng: 1.4140933333e+02,
content:'Saddle = 198.899994 pos = 38.9363,141.4093 diff = 561.199951'
});
data_peak.push({
lat: 3.8803777779e+01,
lng: 1.4134411111e+02,
cert : true,
content:'Name = JA/MG-056(JA/MG-056) peak = 412.000000 pos = 38.8038,141.3441 diff = 183.800003'
});
data_saddle.push({
lat: 3.8827888890e+01,
lng: 1.4136544444e+02,
content:'Saddle = 228.199997 pos = 38.8279,141.3654 diff = 183.800003'
});
data_peak.push({
lat: 3.8862666668e+01,
lng: 1.4139733333e+02,
cert : true,
content:'Name = JA/IT-161(JA/IT-161) peak = 482.200012 pos = 38.8627,141.3973 diff = 195.500000'
});
data_saddle.push({
lat: 3.8882444445e+01,
lng: 1.4142511111e+02,
content:'Saddle = 286.700012 pos = 38.8824,141.4251 diff = 195.500000'
});
data_peak.push({
lat: 3.8829333334e+01,
lng: 1.4152011111e+02,
cert : true,
content:'Name = JA/MG-049(JA/MG-049) peak = 485.200012 pos = 38.8293,141.5201 diff = 197.300018'
});
data_saddle.push({
lat: 3.8835888890e+01,
lng: 1.4151411111e+02,
content:'Saddle = 287.899994 pos = 38.8359,141.5141 diff = 197.300018'
});
data_peak.push({
lat: 3.8912888890e+01,
lng: 1.4143877778e+02,
cert : false,
content:' Peak = 517.099976 pos = 38.9129,141.4388 diff = 169.799988'
});
data_saddle.push({
lat: 3.8884222223e+01,
lng: 1.4146288889e+02,
content:'Saddle = 347.299988 pos = 38.8842,141.4629 diff = 169.799988'
});
data_peak.push({
lat: 3.8848444445e+01,
lng: 1.4146955556e+02,
cert : true,
content:'Name = Tokusenjyouyama(JA/MG-034) peak = 711.200012 pos = 38.8484,141.4696 diff = 174.700012'
});
data_saddle.push({
lat: 3.8855888890e+01,
lng: 1.4146711111e+02,
content:'Saddle = 536.500000 pos = 38.8559,141.4671 diff = 174.700012'
});
data_peak.push({
lat: 3.8986888890e+01,
lng: 1.4158044444e+02,
cert : true,
content:'Name = JA/MG-044(JA/MG-044) peak = 518.400024 pos = 38.9869,141.5804 diff = 307.700012'
});
data_saddle.push({
lat: 3.8996444445e+01,
lng: 1.4154688889e+02,
content:'Saddle = 210.699997 pos = 38.9964,141.5469 diff = 307.700012'
});
data_peak.push({
lat: 3.8959111112e+01,
lng: 1.4160088889e+02,
cert : false,
content:' Peak = 474.899994 pos = 38.9591,141.6009 diff = 157.799988'
});
data_saddle.push({
lat: 3.8958888890e+01,
lng: 1.4159366667e+02,
content:'Saddle = 317.100006 pos = 38.9589,141.5937 diff = 157.799988'
});
data_peak.push({
lat: 4.0245444445e+01,
lng: 1.4128122222e+02,
cert : false,
content:' Peak = 374.000000 pos = 40.2454,141.2812 diff = 151.699997'
});
data_saddle.push({
lat: 4.0248666667e+01,
lng: 1.4128744444e+02,
content:'Saddle = 222.300003 pos = 40.2487,141.2874 diff = 151.699997'
});
data_peak.push({
lat: 3.9671000001e+01,
lng: 1.4118588889e+02,
cert : true,
content:'Name = JA/IT-171(JA/IT-171) peak = 390.299988 pos = 39.6710,141.1859 diff = 162.399994'
});
data_saddle.push({
lat: 3.9660111112e+01,
lng: 1.4120888889e+02,
content:'Saddle = 227.899994 pos = 39.6601,141.2089 diff = 162.399994'
});
data_peak.push({
lat: 3.9980333334e+01,
lng: 1.4193155556e+02,
cert : true,
content:'Name = JA/IT-170(JA/IT-170) peak = 428.100006 pos = 39.9803,141.9316 diff = 196.200012'
});
data_saddle.push({
lat: 3.9967333334e+01,
lng: 1.4189344444e+02,
content:'Saddle = 231.899994 pos = 39.9673,141.8934 diff = 196.200012'
});
data_peak.push({
lat: 3.9125000001e+01,
lng: 1.4183655556e+02,
cert : false,
content:' Peak = 514.000000 pos = 39.1250,141.8366 diff = 275.000000'
});
data_saddle.push({
lat: 3.9131000001e+01,
lng: 1.4182300000e+02,
content:'Saddle = 239.000000 pos = 39.1310,141.8230 diff = 275.000000'
});
data_peak.push({
lat: 4.0263111112e+01,
lng: 1.4126144444e+02,
cert : true,
content:'Name = JA/IT-167(JA/IT-167) peak = 439.100006 pos = 40.2631,141.2614 diff = 191.900009'
});
data_saddle.push({
lat: 4.0251444445e+01,
lng: 1.4119922222e+02,
content:'Saddle = 247.199997 pos = 40.2514,141.1992 diff = 191.900009'
});
data_peak.push({
lat: 4.0400666667e+01,
lng: 1.4158433333e+02,
cert : true,
content:'Name = Hashikamidake (Taneichidake)(JA/IT-112) peak = 741.400024 pos = 40.4007,141.5843 diff = 483.300018'
});
data_saddle.push({
lat: 4.0318222223e+01,
lng: 1.4157000000e+02,
content:'Saddle = 258.100006 pos = 40.3182,141.5700 diff = 483.300018'
});
data_peak.push({
lat: 4.0357444445e+01,
lng: 1.4161288889e+02,
cert : true,
content:'Name = JA/IT-123(JA/IT-123) peak = 703.099976 pos = 40.3574,141.6129 diff = 314.699982'
});
data_saddle.push({
lat: 4.0364888889e+01,
lng: 1.4158833333e+02,
content:'Saddle = 388.399994 pos = 40.3649,141.5883 diff = 314.699982'
});
data_peak.push({
lat: 3.9308444445e+01,
lng: 1.4123977778e+02,
cert : false,
content:' Peak = 432.500000 pos = 39.3084,141.2398 diff = 173.399994'
});
data_saddle.push({
lat: 3.9311222223e+01,
lng: 1.4125655556e+02,
content:'Saddle = 259.100006 pos = 39.3112,141.2566 diff = 173.399994'
});
data_peak.push({
lat: 3.9930333334e+01,
lng: 1.4116477778e+02,
cert : true,
content:'Name = JA/IT-163(JA/IT-163) peak = 471.299988 pos = 39.9303,141.1648 diff = 207.399994'
});
data_saddle.push({
lat: 3.9942111112e+01,
lng: 1.4114522222e+02,
content:'Saddle = 263.899994 pos = 39.9421,141.1452 diff = 207.399994'
});
data_peak.push({
lat: 4.0655888889e+01,
lng: 1.4030300000e+02,
cert : true,
content:'Name = Iwakisan(JA/AM-001) peak = 1621.400024 pos = 40.6559,140.3030 diff = 1356.900024'
});
data_saddle.push({
lat: 4.0421333334e+01,
lng: 1.4062600000e+02,
content:'Saddle = 264.500000 pos = 40.4213,140.6260 diff = 1356.900024'
});
data_peak.push({
lat: 4.0493777778e+01,
lng: 1.4059311111e+02,
cert : true,
content:'Name = JA/AM-041(JA/AM-041) peak = 713.200012 pos = 40.4938,140.5931 diff = 444.800018'
});
data_saddle.push({
lat: 4.0472888889e+01,
lng: 1.4059777778e+02,
content:'Saddle = 268.399994 pos = 40.4729,140.5978 diff = 444.800018'
});
data_peak.push({
lat: 4.0328222223e+01,
lng: 1.4024388889e+02,
cert : false,
content:' Peak = 448.200012 pos = 40.3282,140.2439 diff = 176.300018'
});
data_saddle.push({
lat: 4.0348444445e+01,
lng: 1.4026166667e+02,
content:'Saddle = 271.899994 pos = 40.3484,140.2617 diff = 176.300018'
});
data_peak.push({
lat: 4.0375444445e+01,
lng: 1.4058811111e+02,
cert : false,
content:' Peak = 432.100006 pos = 40.3754,140.5881 diff = 158.800018'
});
data_saddle.push({
lat: 4.0382000000e+01,
lng: 1.4058366667e+02,
content:'Saddle = 273.299988 pos = 40.3820,140.5837 diff = 158.800018'
});
data_peak.push({
lat: 4.0359444445e+01,
lng: 1.4044733333e+02,
cert : true,
content:'Name = JA/AT-115(JA/AT-115) peak = 465.200012 pos = 40.3594,140.4473 diff = 174.400024'
});
data_saddle.push({
lat: 4.0376666667e+01,
lng: 1.4044911111e+02,
content:'Saddle = 290.799988 pos = 40.3767,140.4491 diff = 174.400024'
});
data_peak.push({
lat: 4.0385222223e+01,
lng: 1.4050055556e+02,
cert : true,
content:'Name = JA/AT-105(JA/AT-105) peak = 541.900024 pos = 40.3852,140.5006 diff = 200.200012'
});
data_saddle.push({
lat: 4.0385555556e+01,
lng: 1.4052022222e+02,
content:'Saddle = 341.700012 pos = 40.3856,140.5202 diff = 200.200012'
});
data_peak.push({
lat: 4.0524777778e+01,
lng: 1.4052488889e+02,
cert : true,
content:'Name = JA/AM-064(JA/AM-064) peak = 510.899994 pos = 40.5248,140.5249 diff = 154.899994'
});
data_saddle.push({
lat: 4.0522777778e+01,
lng: 1.4051433333e+02,
content:'Saddle = 356.000000 pos = 40.5228,140.5143 diff = 154.899994'
});
data_peak.push({
lat: 4.0528666667e+01,
lng: 1.4039466667e+02,
cert : true,
content:'Name = JA/AM-055(JA/AM-055) peak = 586.099976 pos = 40.5287,140.3947 diff = 198.299988'
});
data_saddle.push({
lat: 4.0519444445e+01,
lng: 1.4039255556e+02,
content:'Saddle = 387.799988 pos = 40.5194,140.3926 diff = 198.299988'
});
data_peak.push({
lat: 4.0363666667e+01,
lng: 1.4051111111e+02,
cert : false,
content:' Peak = 691.200012 pos = 40.3637,140.5111 diff = 302.900024'
});
data_saddle.push({
lat: 4.0390444445e+01,
lng: 1.4056688889e+02,
content:'Saddle = 388.299988 pos = 40.3904,140.5669 diff = 302.900024'
});
data_peak.push({
lat: 4.0425777778e+01,
lng: 1.4055755556e+02,
cert : false,
content:' Peak = 821.700012 pos = 40.4258,140.5576 diff = 430.300018'
});
data_saddle.push({
lat: 4.0407777778e+01,
lng: 1.4053722222e+02,
content:'Saddle = 391.399994 pos = 40.4078,140.5372 diff = 430.300018'
});
data_peak.push({
lat: 4.0463333334e+01,
lng: 1.4056266667e+02,
cert : true,
content:'Name = JA/AM-053(JA/AM-053) peak = 611.599976 pos = 40.4633,140.5627 diff = 219.499969'
});
data_saddle.push({
lat: 4.0455111111e+01,
lng: 1.4056322222e+02,
content:'Saddle = 392.100006 pos = 40.4551,140.5632 diff = 219.499969'
});
data_peak.push({
lat: 4.0401222223e+01,
lng: 1.4057600000e+02,
cert : false,
content:' Peak = 768.000000 pos = 40.4012,140.5760 diff = 155.700012'
});
data_saddle.push({
lat: 4.0406000000e+01,
lng: 1.4056600000e+02,
content:'Saddle = 612.299988 pos = 40.4060,140.5660 diff = 155.700012'
});
data_peak.push({
lat: 4.0527333334e+01,
lng: 1.4042377778e+02,
cert : true,
content:'Name = JA/AM-047(JA/AM-047) peak = 662.000000 pos = 40.5273,140.4238 diff = 269.600006'
});
data_saddle.push({
lat: 4.0520666667e+01,
lng: 1.4042677778e+02,
content:'Saddle = 392.399994 pos = 40.5207,140.4268 diff = 269.600006'
});
data_peak.push({
lat: 4.0396777778e+01,
lng: 1.4049222222e+02,
cert : true,
content:'Name = JA/AT-086(JA/AT-086) peak = 636.599976 pos = 40.3968,140.4922 diff = 228.999969'
});
data_saddle.push({
lat: 4.0415555556e+01,
lng: 1.4052455556e+02,
content:'Saddle = 407.600006 pos = 40.4156,140.5246 diff = 228.999969'
});
data_peak.push({
lat: 4.0524000000e+01,
lng: 1.4004544444e+02,
cert : true,
content:'Name = Mukaishirakamidake(JA/AM-004) peak = 1248.800049 pos = 40.5240,140.0454 diff = 823.800049'
});
data_saddle.push({
lat: 4.0626555556e+01,
lng: 1.4026466667e+02,
content:'Saddle = 425.000000 pos = 40.6266,140.2647 diff = 823.800049'
});
data_peak.push({
lat: 4.0417555556e+01,
lng: 1.4048411111e+02,
cert : true,
content:'Name = JA/AT-081(JA/AT-081) peak = 680.799988 pos = 40.4176,140.4841 diff = 247.199982'
});
data_saddle.push({
lat: 4.0425111111e+01,
lng: 1.4048777778e+02,
content:'Saddle = 433.600006 pos = 40.4251,140.4878 diff = 247.199982'
});
data_peak.push({
lat: 4.0664000000e+01,
lng: 1.4016377778e+02,
cert : true,
content:'Name = JA/AM-036(JA/AM-036) peak = 731.500000 pos = 40.6640,140.1638 diff = 270.000000'
});
data_saddle.push({
lat: 4.0654111111e+01,
lng: 1.4017777778e+02,
content:'Saddle = 461.500000 pos = 40.6541,140.1778 diff = 270.000000'
});
data_peak.push({
lat: 4.0366555556e+01,
lng: 1.4035622222e+02,
cert : true,
content:'Name = JA/AT-083(JA/AT-083) peak = 665.299988 pos = 40.3666,140.3562 diff = 187.099976'
});
data_saddle.push({
lat: 4.0376777778e+01,
lng: 1.4034022222e+02,
content:'Saddle = 478.200012 pos = 40.3768,140.3402 diff = 187.099976'
});
data_peak.push({
lat: 4.0696666667e+01,
lng: 1.4004588889e+02,
cert : true,
content:'Name = JA/AM-035(JA/AM-035) peak = 731.599976 pos = 40.6967,140.0459 diff = 208.799988'
});
data_saddle.push({
lat: 4.0688000000e+01,
lng: 1.4005211111e+02,
content:'Saddle = 522.799988 pos = 40.6880,140.0521 diff = 208.799988'
});
data_peak.push({
lat: 4.0342111111e+01,
lng: 1.4015911111e+02,
cert : true,
content:'Name = JA/AT-070(JA/AT-070) peak = 721.099976 pos = 40.3421,140.1591 diff = 188.199951'
});
data_saddle.push({
lat: 4.0350555556e+01,
lng: 1.4016433333e+02,
content:'Saddle = 532.900024 pos = 40.3506,140.1643 diff = 188.199951'
});
data_peak.push({
lat: 4.0579555556e+01,
lng: 1.4015544444e+02,
cert : true,
content:'Name = JA/AM-018(JA/AM-018) peak = 881.299988 pos = 40.5796,140.1554 diff = 308.700012'
});
data_saddle.push({
lat: 4.0537444445e+01,
lng: 1.4013655556e+02,
content:'Saddle = 572.599976 pos = 40.5374,140.1366 diff = 308.700012'
});
data_peak.push({
lat: 4.0606555556e+01,
lng: 1.4014466667e+02,
cert : false,
content:' Peak = 874.700012 pos = 40.6066,140.1447 diff = 237.100037'
});
data_saddle.push({
lat: 4.0597444445e+01,
lng: 1.4015422222e+02,
content:'Saddle = 637.599976 pos = 40.5974,140.1542 diff = 237.100037'
});
data_peak.push({
lat: 4.0543555556e+01,
lng: 1.4016411111e+02,
cert : false,
content:' Peak = 830.099976 pos = 40.5436,140.1641 diff = 181.699951'
});
data_saddle.push({
lat: 4.0556555556e+01,
lng: 1.4016311111e+02,
content:'Saddle = 648.400024 pos = 40.5566,140.1631 diff = 181.699951'
});
data_peak.push({
lat: 4.0381111111e+01,
lng: 1.4029266667e+02,
cert : true,
content:'Name = JA/AT-051(JA/AT-051) peak = 850.299988 pos = 40.3811,140.2927 diff = 258.700012'
});
data_saddle.push({
lat: 4.0395444445e+01,
lng: 1.4027488889e+02,
content:'Saddle = 591.599976 pos = 40.3954,140.2749 diff = 258.700012'
});
data_peak.push({
lat: 4.0501222223e+01,
lng: 1.4024833333e+02,
cert : true,
content:'Name = JA/AM-029(JA/AM-029) peak = 785.099976 pos = 40.5012,140.2483 diff = 167.099976'
});
data_saddle.push({
lat: 4.0489888889e+01,
lng: 1.4025077778e+02,
content:'Saddle = 618.000000 pos = 40.4899,140.2508 diff = 167.099976'
});
data_peak.push({
lat: 4.0489444445e+01,
lng: 1.4023888889e+02,
cert : false,
content:' Peak = 783.200012 pos = 40.4894,140.2389 diff = 151.700012'
});
data_saddle.push({
lat: 4.0487444445e+01,
lng: 1.4024422222e+02,
content:'Saddle = 631.500000 pos = 40.4874,140.2442 diff = 151.700012'
});
data_peak.push({
lat: 4.0676111111e+01,
lng: 1.4004822222e+02,
cert : true,
content:'Name = JA/AM-026(JA/AM-026) peak = 820.799988 pos = 40.6761,140.0482 diff = 188.799988'
});
data_saddle.push({
lat: 4.0647222222e+01,
lng: 1.4008200000e+02,
content:'Saddle = 632.000000 pos = 40.6472,140.0820 diff = 188.799988'
});
data_peak.push({
lat: 4.0428555556e+01,
lng: 1.4040877778e+02,
cert : true,
content:'Name = Tashirodake(JA/AT-014) peak = 1177.599976 pos = 40.4286,140.4088 diff = 534.099976'
});
data_saddle.push({
lat: 4.0439444445e+01,
lng: 1.4032422222e+02,
content:'Saddle = 643.500000 pos = 40.4394,140.3242 diff = 534.099976'
});
data_peak.push({
lat: 4.0402444445e+01,
lng: 1.4033344444e+02,
cert : true,
content:'Name = JA/AT-055(JA/AT-055) peak = 816.500000 pos = 40.4024,140.3334 diff = 170.099976'
});
data_saddle.push({
lat: 4.0411555556e+01,
lng: 1.4033655556e+02,
content:'Saddle = 646.400024 pos = 40.4116,140.3366 diff = 170.099976'
});
data_peak.push({
lat: 4.0439333334e+01,
lng: 1.4047922222e+02,
cert : true,
content:'Name = JA/AT-047(JA/AT-047) peak = 890.400024 pos = 40.4393,140.4792 diff = 238.300049'
});
data_saddle.push({
lat: 4.0456000000e+01,
lng: 1.4045866667e+02,
content:'Saddle = 652.099976 pos = 40.4560,140.4587 diff = 238.300049'
});
data_peak.push({
lat: 4.0479888889e+01,
lng: 1.4031011111e+02,
cert : false,
content:' Peak = 1048.199951 pos = 40.4799,140.3101 diff = 326.599976'
});
data_saddle.push({
lat: 4.0476555556e+01,
lng: 1.4041144444e+02,
content:'Saddle = 721.599976 pos = 40.4766,140.4114 diff = 326.599976'
});
data_peak.push({
lat: 4.0476555556e+01,
lng: 1.4037788889e+02,
cert : true,
content:'Name = JA/AT-040(JA/AT-040) peak = 960.700012 pos = 40.4766,140.3779 diff = 178.100037'
});
data_saddle.push({
lat: 4.0478000000e+01,
lng: 1.4036544444e+02,
content:'Saddle = 782.599976 pos = 40.4780,140.3654 diff = 178.100037'
});
data_peak.push({
lat: 4.0478000000e+01,
lng: 1.4044844444e+02,
cert : true,
content:'Name = JA/AM-014(JA/AM-014) peak = 955.000000 pos = 40.4780,140.4484 diff = 158.099976'
});
data_saddle.push({
lat: 4.0447888889e+01,
lng: 1.4041311111e+02,
content:'Saddle = 796.900024 pos = 40.4479,140.4131 diff = 158.099976'
});
data_peak.push({
lat: 4.0654777778e+01,
lng: 1.4009877778e+02,
cert : true,
content:'Name = JA/AM-017(JA/AM-017) peak = 890.200012 pos = 40.6548,140.0988 diff = 238.700012'
});
data_saddle.push({
lat: 4.0605777778e+01,
lng: 1.4009800000e+02,
content:'Saddle = 651.500000 pos = 40.6058,140.0980 diff = 238.700012'
});
data_peak.push({
lat: 4.0374222223e+01,
lng: 1.4015611111e+02,
cert : true,
content:'Name = JA/AT-038(JA/AT-038) peak = 962.400024 pos = 40.3742,140.1561 diff = 300.000000'
});
data_saddle.push({
lat: 4.0403444445e+01,
lng: 1.4013322222e+02,
content:'Saddle = 662.400024 pos = 40.4034,140.1332 diff = 300.000000'
});
data_peak.push({
lat: 4.0371666667e+01,
lng: 1.4019077778e+02,
cert : true,
content:'Name = JA/AT-042(JA/AT-042) peak = 940.599976 pos = 40.3717,140.1908 diff = 209.000000'
});
data_saddle.push({
lat: 4.0363333334e+01,
lng: 1.4017977778e+02,
content:'Saddle = 731.599976 pos = 40.3633,140.1798 diff = 209.000000'
});
data_peak.push({
lat: 4.0412888889e+01,
lng: 1.4025111111e+02,
cert : true,
content:'Name = Komagatake(JA/AT-020) peak = 1154.000000 pos = 40.4129,140.2511 diff = 482.400024'
});
data_saddle.push({
lat: 4.0467555556e+01,
lng: 1.4005744444e+02,
content:'Saddle = 671.599976 pos = 40.4676,140.0574 diff = 482.400024'
});
data_peak.push({
lat: 4.0527222223e+01,
lng: 1.4008488889e+02,
cert : true,
content:'Name = Tengudake(JA/AM-013) peak = 955.299988 pos = 40.5272,140.0849 diff = 234.500000'
});
data_saddle.push({
lat: 4.0471444445e+01,
lng: 1.4006877778e+02,
content:'Saddle = 720.799988 pos = 40.4714,140.0688 diff = 234.500000'
});
data_peak.push({
lat: 4.0570666667e+01,
lng: 1.4009855556e+02,
cert : true,
content:'Name = JA/AM-015(JA/AM-015) peak = 924.299988 pos = 40.5707,140.0986 diff = 201.500000'
});
data_saddle.push({
lat: 4.0531222223e+01,
lng: 1.4009255556e+02,
content:'Saddle = 722.799988 pos = 40.5312,140.0926 diff = 201.500000'
});
data_peak.push({
lat: 4.0462222223e+01,
lng: 1.4008333333e+02,
cert : true,
content:'Name = Masedake(JA/AT-037) peak = 981.500000 pos = 40.4622,140.0833 diff = 238.200012'
});
data_saddle.push({
lat: 4.0455888889e+01,
lng: 1.4009677778e+02,
content:'Saddle = 743.299988 pos = 40.4559,140.0968 diff = 238.200012'
});
data_peak.push({
lat: 4.0423333334e+01,
lng: 1.4028222222e+02,
cert : true,
content:'Name = JA/AT-039(JA/AT-039) peak = 960.700012 pos = 40.4233,140.2822 diff = 209.000000'
});
data_saddle.push({
lat: 4.0427333334e+01,
lng: 1.4029922222e+02,
content:'Saddle = 751.700012 pos = 40.4273,140.2992 diff = 209.000000'
});
data_peak.push({
lat: 4.0435777778e+01,
lng: 1.4012000000e+02,
cert : false,
content:' Peak = 1081.599976 pos = 40.4358,140.1200 diff = 328.199951'
});
data_saddle.push({
lat: 4.0432222223e+01,
lng: 1.4021800000e+02,
content:'Saddle = 753.400024 pos = 40.4322,140.2180 diff = 328.199951'
});
data_peak.push({
lat: 4.0432888889e+01,
lng: 1.4019766667e+02,
cert : true,
content:'Name = Kodake(JA/AT-028) peak = 1040.400024 pos = 40.4329,140.1977 diff = 269.700012'
});
data_saddle.push({
lat: 4.0438222223e+01,
lng: 1.4013400000e+02,
content:'Saddle = 770.700012 pos = 40.4382,140.1340 diff = 269.700012'
});
data_peak.push({
lat: 4.0451555556e+01,
lng: 1.4018411111e+02,
cert : true,
content:'Name = JA/AM-010(JA/AM-010) peak = 1000.000000 pos = 40.4516,140.1841 diff = 197.700012'
});
data_saddle.push({
lat: 4.0441222223e+01,
lng: 1.4018622222e+02,
content:'Saddle = 802.299988 pos = 40.4412,140.1862 diff = 197.700012'
});
data_peak.push({
lat: 4.0483111111e+01,
lng: 1.4009888889e+02,
cert : false,
content:' Peak = 1012.200012 pos = 40.4831,140.0989 diff = 229.100037'
});
data_saddle.push({
lat: 4.0470000000e+01,
lng: 1.4010722222e+02,
content:'Saddle = 783.099976 pos = 40.4700,140.1072 diff = 229.100037'
});
data_peak.push({
lat: 4.0416111111e+01,
lng: 1.4010744444e+02,
cert : true,
content:'Name = JA/AT-029(JA/AT-029) peak = 1038.099976 pos = 40.4161,140.1074 diff = 186.399963'
});
data_saddle.push({
lat: 4.0427777778e+01,
lng: 1.4010255556e+02,
content:'Saddle = 851.700012 pos = 40.4278,140.1026 diff = 186.399963'
});
data_peak.push({
lat: 4.0441777778e+01,
lng: 1.4025388889e+02,
cert : true,
content:'Name = JA/AT-022(JA/AT-022) peak = 1095.099976 pos = 40.4418,140.2539 diff = 258.099976'
});
data_saddle.push({
lat: 4.0420111111e+01,
lng: 1.4024388889e+02,
content:'Saddle = 837.000000 pos = 40.4201,140.2439 diff = 258.099976'
});
data_peak.push({
lat: 4.0466222223e+01,
lng: 1.4027755556e+02,
cert : false,
content:' Peak = 1080.599976 pos = 40.4662,140.2776 diff = 157.000000'
});
data_saddle.push({
lat: 4.0462333334e+01,
lng: 1.4027966667e+02,
content:'Saddle = 923.599976 pos = 40.4623,140.2797 diff = 157.000000'
});
data_peak.push({
lat: 4.0595777778e+01,
lng: 1.4004266667e+02,
cert : true,
content:'Name = JA/AM-012(JA/AM-012) peak = 958.000000 pos = 40.5958,140.0427 diff = 282.900024'
});
data_saddle.push({
lat: 4.0562000000e+01,
lng: 1.4005733333e+02,
content:'Saddle = 675.099976 pos = 40.5620,140.0573 diff = 282.900024'
});
data_peak.push({
lat: 4.0608888889e+01,
lng: 1.4003044444e+02,
cert : false,
content:' Peak = 893.900024 pos = 40.6089,140.0304 diff = 175.400024'
});
data_saddle.push({
lat: 4.0605777778e+01,
lng: 1.4003477778e+02,
content:'Saddle = 718.500000 pos = 40.6058,140.0348 diff = 175.400024'
});
data_peak.push({
lat: 4.0507333334e+01,
lng: 1.4001822222e+02,
cert : false,
content:' Peak = 1233.800049 pos = 40.5073,140.0182 diff = 171.200073'
});
data_saddle.push({
lat: 4.0506222223e+01,
lng: 1.4003511111e+02,
content:'Saddle = 1062.599976 pos = 40.5062,140.0351 diff = 171.200073'
});
data_peak.push({
lat: 3.9859222223e+01,
lng: 1.4189188889e+02,
cert : true,
content:'Name = JA/IT-159(JA/IT-159) peak = 497.799988 pos = 39.8592,141.8919 diff = 221.299988'
});
data_saddle.push({
lat: 3.9870777778e+01,
lng: 1.4189966667e+02,
content:'Saddle = 276.500000 pos = 39.8708,141.8997 diff = 221.299988'
});
data_peak.push({
lat: 3.9861333334e+01,
lng: 1.4191111111e+02,
cert : false,
content:' Peak = 474.899994 pos = 39.8613,141.9111 diff = 153.600006'
});
data_saddle.push({
lat: 3.9859222223e+01,
lng: 1.4190100000e+02,
content:'Saddle = 321.299988 pos = 39.8592,141.9010 diff = 153.600006'
});
data_peak.push({
lat: 4.0116888889e+01,
lng: 1.4047400000e+02,
cert : true,
content:'Name = JA/AT-111(JA/AT-111) peak = 484.399994 pos = 40.1169,140.4740 diff = 207.600006'
});
data_saddle.push({
lat: 4.0122111112e+01,
lng: 1.4050222222e+02,
content:'Saddle = 276.799988 pos = 40.1221,140.5022 diff = 207.600006'
});
data_peak.push({
lat: 3.9401222223e+01,
lng: 1.4192266667e+02,
cert : true,
content:'Name = Kujirayama(JA/IT-141) peak = 610.000000 pos = 39.4012,141.9227 diff = 326.600006'
});
data_saddle.push({
lat: 3.9418444445e+01,
lng: 1.4187022222e+02,
content:'Saddle = 283.399994 pos = 39.4184,141.8702 diff = 326.600006'
});
data_peak.push({
lat: 3.9383888890e+01,
lng: 1.4191244444e+02,
cert : false,
content:' Peak = 455.200012 pos = 39.3839,141.9124 diff = 168.400024'
});
data_saddle.push({
lat: 3.9389666667e+01,
lng: 1.4190733333e+02,
content:'Saddle = 286.799988 pos = 39.3897,141.9073 diff = 168.400024'
});
data_peak.push({
lat: 3.9405888890e+01,
lng: 1.4188566667e+02,
cert : false,
content:' Peak = 572.000000 pos = 39.4059,141.8857 diff = 254.200012'
});
data_saddle.push({
lat: 3.9401111112e+01,
lng: 1.4191100000e+02,
content:'Saddle = 317.799988 pos = 39.4011,141.9110 diff = 254.200012'
});
data_peak.push({
lat: 3.9098666668e+01,
lng: 1.4051711111e+02,
cert : true,
content:'Name = JA/AT-060(JA/AT-060) peak = 772.500000 pos = 39.0987,140.5171 diff = 489.000000'
});
data_saddle.push({
lat: 3.9088666668e+01,
lng: 1.4055133333e+02,
content:'Saddle = 283.500000 pos = 39.0887,140.5513 diff = 489.000000'
});
data_peak.push({
lat: 3.9138444445e+01,
lng: 1.4052544444e+02,
cert : true,
content:'Name = JA/AT-110(JA/AT-110) peak = 490.399994 pos = 39.1384,140.5254 diff = 199.000000'
});
data_saddle.push({
lat: 3.9123555556e+01,
lng: 1.4054144444e+02,
content:'Saddle = 291.399994 pos = 39.1236,140.5414 diff = 199.000000'
});
data_peak.push({
lat: 3.8729000001e+01,
lng: 1.4073433333e+02,
cert : false,
content:' Peak = 471.200012 pos = 38.7290,140.7343 diff = 186.800018'
});
data_saddle.push({
lat: 3.8725777779e+01,
lng: 1.4071566667e+02,
content:'Saddle = 284.399994 pos = 38.7258,140.7157 diff = 186.800018'
});
data_peak.push({
lat: 3.9114000001e+01,
lng: 1.4165566667e+02,
cert : true,
content:'Name = JA/IT-164(JA/IT-164) peak = 461.799988 pos = 39.1140,141.6557 diff = 174.599976'
});
data_saddle.push({
lat: 3.9115222223e+01,
lng: 1.4164600000e+02,
content:'Saddle = 287.200012 pos = 39.1152,141.6460 diff = 174.599976'
});
data_peak.push({
lat: 3.9307000001e+01,
lng: 1.4186266667e+02,
cert : false,
content:' Peak = 462.899994 pos = 39.3070,141.8627 diff = 175.699982'
});
data_saddle.push({
lat: 3.9305222223e+01,
lng: 1.4185377778e+02,
content:'Saddle = 287.200012 pos = 39.3052,141.8538 diff = 175.699982'
});
data_peak.push({
lat: 3.9316111112e+01,
lng: 1.4134477778e+02,
cert : false,
content:' Peak = 670.000000 pos = 39.3161,141.3448 diff = 381.799988'
});
data_saddle.push({
lat: 3.9323333334e+01,
lng: 1.4136533333e+02,
content:'Saddle = 288.200012 pos = 39.3233,141.3653 diff = 381.799988'
});
data_peak.push({
lat: 3.9852666667e+01,
lng: 1.4100088889e+02,
cert : true,
content:'Name = Iwatesan(JA/IT-001) peak = 2037.000000 pos = 39.8527,141.0009 diff = 1748.000000'
});
data_saddle.push({
lat: 3.9292111112e+01,
lng: 1.4071777778e+02,
content:'Saddle = 289.000000 pos = 39.2921,140.7178 diff = 1748.000000'
});
data_peak.push({
lat: 3.9325333334e+01,
lng: 1.4184400000e+02,
cert : false,
content:' Peak = 461.200012 pos = 39.3253,141.8440 diff = 168.700012'
});
data_saddle.push({
lat: 3.9326555556e+01,
lng: 1.4183577778e+02,
content:'Saddle = 292.500000 pos = 39.3266,141.8358 diff = 168.700012'
});
data_peak.push({
lat: 4.0396333334e+01,
lng: 1.4113244444e+02,
cert : true,
content:'Name = JA/AM-062(JA/AM-062) peak = 536.200012 pos = 40.3963,141.1324 diff = 240.700012'
});
data_saddle.push({
lat: 4.0400000000e+01,
lng: 1.4109411111e+02,
content:'Saddle = 295.500000 pos = 40.4000,141.0941 diff = 240.700012'
});
data_peak.push({
lat: 3.9394666667e+01,
lng: 1.4131422222e+02,
cert : true,
content:'Name = JA/IT-145(JA/IT-145) peak = 597.900024 pos = 39.3947,141.3142 diff = 301.800018'
});
data_saddle.push({
lat: 3.9412333334e+01,
lng: 1.4132177778e+02,
content:'Saddle = 296.100006 pos = 39.4123,141.3218 diff = 301.800018'
});
data_peak.push({
lat: 3.9377000001e+01,
lng: 1.4128833333e+02,
cert : false,
content:' Peak = 531.400024 pos = 39.3770,141.2883 diff = 153.100037'
});
data_saddle.push({
lat: 3.9388444445e+01,
lng: 1.4130222222e+02,
content:'Saddle = 378.299988 pos = 39.3884,141.3022 diff = 153.100037'
});
data_peak.push({
lat: 4.0321666667e+01,
lng: 1.4070755556e+02,
cert : true,
content:'Name = JA/AT-112(JA/AT-112) peak = 481.000000 pos = 40.3217,140.7076 diff = 179.500000'
});
data_saddle.push({
lat: 4.0335444445e+01,
lng: 1.4071677778e+02,
content:'Saddle = 301.500000 pos = 40.3354,140.7168 diff = 179.500000'
});
data_peak.push({
lat: 3.9513222223e+01,
lng: 1.4188011111e+02,
cert : true,
content:'Name = JA/IT-152(JA/IT-152) peak = 546.400024 pos = 39.5132,141.8801 diff = 238.800018'
});
data_saddle.push({
lat: 3.9507000001e+01,
lng: 1.4186233333e+02,
content:'Saddle = 307.600006 pos = 39.5070,141.8623 diff = 238.800018'
});
data_peak.push({
lat: 3.9726111112e+01,
lng: 1.4061844444e+02,
cert : true,
content:'Name = JA/AT-099(JA/AT-099) peak = 583.299988 pos = 39.7261,140.6184 diff = 275.000000'
});
data_saddle.push({
lat: 3.9752777778e+01,
lng: 1.4063777778e+02,
content:'Saddle = 308.299988 pos = 39.7528,140.6378 diff = 275.000000'
});
data_peak.push({
lat: 3.9223333334e+01,
lng: 1.4189944444e+02,
cert : true,
content:'Name = JA/IT-162(JA/IT-162) peak = 481.299988 pos = 39.2233,141.8994 diff = 168.699982'
});
data_saddle.push({
lat: 3.9227888890e+01,
lng: 1.4187922222e+02,
content:'Saddle = 312.600006 pos = 39.2279,141.8792 diff = 168.699982'
});
data_peak.push({
lat: 4.0388000000e+01,
lng: 1.4130833333e+02,
cert : true,
content:'Name = Nakuidake(JA/AM-052) peak = 614.099976 pos = 40.3880,141.3083 diff = 297.799988'
});
data_saddle.push({
lat: 4.0337555556e+01,
lng: 1.4134700000e+02,
content:'Saddle = 316.299988 pos = 40.3376,141.3470 diff = 297.799988'
});
data_peak.push({
lat: 3.9363222223e+01,
lng: 1.4137222222e+02,
cert : true,
content:'Name = JA/IT-160(JA/IT-160) peak = 495.100006 pos = 39.3632,141.3722 diff = 177.800018'
});
data_saddle.push({
lat: 3.9370333334e+01,
lng: 1.4138488889e+02,
content:'Saddle = 317.299988 pos = 39.3703,141.3849 diff = 177.800018'
});
data_peak.push({
lat: 3.9562888890e+01,
lng: 1.4187466667e+02,
cert : true,
content:'Name = JA/IT-138(JA/IT-138) peak = 617.400024 pos = 39.5629,141.8747 diff = 295.000031'
});
data_saddle.push({
lat: 3.9556777778e+01,
lng: 1.4185166667e+02,
content:'Saddle = 322.399994 pos = 39.5568,141.8517 diff = 295.000031'
});
data_peak.push({
lat: 3.9357000001e+01,
lng: 1.4185533333e+02,
cert : true,
content:'Name = JA/IT-147(JA/IT-147) peak = 586.400024 pos = 39.3570,141.8553 diff = 263.000031'
});
data_saddle.push({
lat: 3.9366444445e+01,
lng: 1.4182877778e+02,
content:'Saddle = 323.399994 pos = 39.3664,141.8288 diff = 263.000031'
});
data_peak.push({
lat: 3.9632444445e+01,
lng: 1.4122711111e+02,
cert : true,
content:'Name = JA/IT-142(JA/IT-142) peak = 606.400024 pos = 39.6324,141.2271 diff = 282.700012'
});
data_saddle.push({
lat: 3.9637444445e+01,
lng: 1.4123711111e+02,
content:'Saddle = 323.700012 pos = 39.6374,141.2371 diff = 282.700012'
});
data_peak.push({
lat: 3.9055222223e+01,
lng: 1.4152011111e+02,
cert : false,
content:' Peak = 481.100006 pos = 39.0552,141.5201 diff = 153.300018'
});
data_saddle.push({
lat: 3.9056666668e+01,
lng: 1.4152388889e+02,
content:'Saddle = 327.799988 pos = 39.0567,141.5239 diff = 153.300018'
});
data_peak.push({
lat: 3.9059000001e+01,
lng: 1.4166044444e+02,
cert : true,
content:'Name = Hikamisan(JA/IT-082) peak = 874.500000 pos = 39.0590,141.6604 diff = 546.299988'
});
data_saddle.push({
lat: 3.9151888890e+01,
lng: 1.4163188889e+02,
content:'Saddle = 328.200012 pos = 39.1519,141.6319 diff = 546.299988'
});
data_peak.push({
lat: 3.9808555556e+01,
lng: 1.4189077778e+02,
cert : true,
content:'Name = JA/IT-155(JA/IT-155) peak = 536.400024 pos = 39.8086,141.8908 diff = 204.900024'
});
data_saddle.push({
lat: 3.9792777778e+01,
lng: 1.4188311111e+02,
content:'Saddle = 331.500000 pos = 39.7928,141.8831 diff = 204.900024'
});
data_peak.push({
lat: 4.0340333334e+01,
lng: 1.4071200000e+02,
cert : false,
content:' Peak = 483.399994 pos = 40.3403,140.7120 diff = 151.500000'
});
data_saddle.push({
lat: 4.0355333334e+01,
lng: 1.4070588889e+02,
content:'Saddle = 331.899994 pos = 40.3553,140.7059 diff = 151.500000'
});
data_peak.push({
lat: 3.9889555556e+01,
lng: 1.4188988889e+02,
cert : true,
content:'Name = JA/IT-156(JA/IT-156) peak = 520.599976 pos = 39.8896,141.8899 diff = 182.299988'
});
data_saddle.push({
lat: 3.9887555556e+01,
lng: 1.4186000000e+02,
content:'Saddle = 338.299988 pos = 39.8876,141.8600 diff = 182.299988'
});
data_peak.push({
lat: 3.9742333334e+01,
lng: 1.4036033333e+02,
cert : false,
content:' Peak = 531.299988 pos = 39.7423,140.3603 diff = 189.299988'
});
data_saddle.push({
lat: 3.9743777778e+01,
lng: 1.4036922222e+02,
content:'Saddle = 342.000000 pos = 39.7438,140.3692 diff = 189.299988'
});
data_peak.push({
lat: 3.9074000001e+01,
lng: 1.4124933333e+02,
cert : true,
content:'Name = JA/IT-135(JA/IT-135) peak = 631.799988 pos = 39.0740,141.2493 diff = 285.299988'
});
data_saddle.push({
lat: 3.9090777779e+01,
lng: 1.4127222222e+02,
content:'Saddle = 346.500000 pos = 39.0908,141.2722 diff = 285.299988'
});
data_peak.push({
lat: 3.9312333334e+01,
lng: 1.4129855556e+02,
cert : true,
content:'Name = JA/IT-154(JA/IT-154) peak = 540.900024 pos = 39.3123,141.2986 diff = 194.300018'
});
data_saddle.push({
lat: 3.9295777779e+01,
lng: 1.4130300000e+02,
content:'Saddle = 346.600006 pos = 39.2958,141.3030 diff = 194.300018'
});
data_peak.push({
lat: 3.9940333334e+01,
lng: 1.4043277778e+02,
cert : true,
content:'Name = JA/AT-100(JA/AT-100) peak = 570.099976 pos = 39.9403,140.4328 diff = 222.199982'
});
data_saddle.push({
lat: 3.9929666667e+01,
lng: 1.4045700000e+02,
content:'Saddle = 347.899994 pos = 39.9297,140.4570 diff = 222.199982'
});
data_peak.push({
lat: 3.9407444445e+01,
lng: 1.4182600000e+02,
cert : true,
content:'Name = JA/IT-153(JA/IT-153) peak = 545.200012 pos = 39.4074,141.8260 diff = 195.100006'
});
data_saddle.push({
lat: 3.9407222223e+01,
lng: 1.4181911111e+02,
content:'Saddle = 350.100006 pos = 39.4072,141.8191 diff = 195.100006'
});
data_peak.push({
lat: 3.9272222223e+01,
lng: 1.4130400000e+02,
cert : true,
content:'Name = JA/IT-157(JA/IT-157) peak = 521.599976 pos = 39.2722,141.3040 diff = 171.399963'
});
data_saddle.push({
lat: 3.9259000001e+01,
lng: 1.4131711111e+02,
content:'Saddle = 350.200012 pos = 39.2590,141.3171 diff = 171.399963'
});
data_peak.push({
lat: 4.0316222223e+01,
lng: 1.4081833333e+02,
cert : true,
content:'Name = Kuromoriyama(JA/AT-104) peak = 542.700012 pos = 40.3162,140.8183 diff = 180.400024'
});
data_saddle.push({
lat: 4.0336666667e+01,
lng: 1.4081444444e+02,
content:'Saddle = 362.299988 pos = 40.3367,140.8144 diff = 180.400024'
});
data_peak.push({
lat: 4.0551222223e+01,
lng: 1.4064900000e+02,
cert : true,
content:'Name = JA/AM-057(JA/AM-057) peak = 563.099976 pos = 40.5512,140.6490 diff = 191.899963'
});
data_saddle.push({
lat: 4.0533555556e+01,
lng: 1.4064811111e+02,
content:'Saddle = 371.200012 pos = 40.5336,140.6481 diff = 191.899963'
});
data_peak.push({
lat: 3.9568666667e+01,
lng: 1.4184400000e+02,
cert : false,
content:' Peak = 530.000000 pos = 39.5687,141.8440 diff = 157.899994'
});
data_saddle.push({
lat: 3.9566666667e+01,
lng: 1.4183577778e+02,
content:'Saddle = 372.100006 pos = 39.5667,141.8358 diff = 157.899994'
});
data_peak.push({
lat: 3.8992333334e+01,
lng: 1.4152611111e+02,
cert : false,
content:' Peak = 570.700012 pos = 38.9923,141.5261 diff = 197.900024'
});
data_saddle.push({
lat: 3.9000111112e+01,
lng: 1.4150488889e+02,
content:'Saddle = 372.799988 pos = 39.0001,141.5049 diff = 197.900024'
});
data_peak.push({
lat: 3.9165333334e+01,
lng: 1.4155933333e+02,
cert : true,
content:'Name = JA/IT-148(JA/IT-148) peak = 574.500000 pos = 39.1653,141.5593 diff = 201.299988'
});
data_saddle.push({
lat: 3.9176444445e+01,
lng: 1.4157044444e+02,
content:'Saddle = 373.200012 pos = 39.1764,141.5704 diff = 201.299988'
});
data_peak.push({
lat: 3.9614666667e+01,
lng: 1.4095955556e+02,
cert : true,
content:'Name = JA/IT-136(JA/IT-136) peak = 622.599976 pos = 39.6147,140.9596 diff = 246.499969'
});
data_saddle.push({
lat: 3.9609777778e+01,
lng: 1.4095866667e+02,
content:'Saddle = 376.100006 pos = 39.6098,140.9587 diff = 246.499969'
});
data_peak.push({
lat: 4.0362333334e+01,
lng: 1.4076666667e+02,
cert : false,
content:' Peak = 538.000000 pos = 40.3623,140.7667 diff = 159.500000'
});
data_saddle.push({
lat: 4.0370555556e+01,
lng: 1.4078366667e+02,
content:'Saddle = 378.500000 pos = 40.3706,140.7837 diff = 159.500000'
});
data_peak.push({
lat: 3.9588888890e+01,
lng: 1.4181966667e+02,
cert : false,
content:' Peak = 683.099976 pos = 39.5889,141.8197 diff = 301.699982'
});
data_saddle.push({
lat: 3.9582111112e+01,
lng: 1.4181411111e+02,
content:'Saddle = 381.399994 pos = 39.5821,141.8141 diff = 301.699982'
});
data_peak.push({
lat: 3.9300888890e+01,
lng: 1.4155000000e+02,
cert : true,
content:'Name = JA/IT-151(JA/IT-151) peak = 551.000000 pos = 39.3009,141.5500 diff = 168.000000'
});
data_saddle.push({
lat: 3.9284000001e+01,
lng: 1.4155800000e+02,
content:'Saddle = 383.000000 pos = 39.2840,141.5580 diff = 168.000000'
});
data_peak.push({
lat: 3.9466555556e+01,
lng: 1.4100355556e+02,
cert : false,
content:' Peak = 543.500000 pos = 39.4666,141.0036 diff = 159.299988'
});
data_saddle.push({
lat: 3.9474888890e+01,
lng: 1.4100466667e+02,
content:'Saddle = 384.200012 pos = 39.4749,141.0047 diff = 159.299988'
});
data_peak.push({
lat: 3.9927333334e+01,
lng: 1.4029255556e+02,
cert : true,
content:'Name = JA/AT-095(JA/AT-095) peak = 603.799988 pos = 39.9273,140.2926 diff = 216.199982'
});
data_saddle.push({
lat: 3.9908000001e+01,
lng: 1.4029433333e+02,
content:'Saddle = 387.600006 pos = 39.9080,140.2943 diff = 216.199982'
});
data_peak.push({
lat: 4.0358888889e+01,
lng: 1.4064488889e+02,
cert : true,
content:'Name = JA/AT-097(JA/AT-097) peak = 590.000000 pos = 40.3589,140.6449 diff = 202.299988'
});
data_saddle.push({
lat: 4.0390333334e+01,
lng: 1.4063033333e+02,
content:'Saddle = 387.700012 pos = 40.3903,140.6303 diff = 202.299988'
});
data_peak.push({
lat: 4.0383000000e+01,
lng: 1.4063655556e+02,
cert : false,
content:' Peak = 550.200012 pos = 40.3830,140.6366 diff = 161.500000'
});
data_saddle.push({
lat: 4.0376666667e+01,
lng: 1.4063733333e+02,
content:'Saddle = 388.700012 pos = 40.3767,140.6373 diff = 161.500000'
});
data_peak.push({
lat: 3.9107555556e+01,
lng: 1.4175411111e+02,
cert : true,
content:'Name = JA/IT-108(JA/IT-108) peak = 751.200012 pos = 39.1076,141.7541 diff = 363.100006'
});
data_saddle.push({
lat: 3.9123222223e+01,
lng: 1.4177355556e+02,
content:'Saddle = 388.100006 pos = 39.1232,141.7736 diff = 363.100006'
});
data_peak.push({
lat: 3.9076777779e+01,
lng: 1.4177600000e+02,
cert : true,
content:'Name = JA/IT-140(JA/IT-140) peak = 610.400024 pos = 39.0768,141.7760 diff = 166.700012'
});
data_saddle.push({
lat: 3.9095111112e+01,
lng: 1.4176711111e+02,
content:'Saddle = 443.700012 pos = 39.0951,141.7671 diff = 166.700012'
});
data_peak.push({
lat: 3.9400555556e+01,
lng: 1.4077811111e+02,
cert : false,
content:' Peak = 562.299988 pos = 39.4006,140.7781 diff = 169.699982'
});
data_saddle.push({
lat: 3.9409444445e+01,
lng: 1.4078233333e+02,
content:'Saddle = 392.600006 pos = 39.4094,140.7823 diff = 169.699982'
});
data_peak.push({
lat: 3.9616666667e+01,
lng: 1.4092922222e+02,
cert : true,
content:'Name = JA/IT-107(JA/IT-107) peak = 755.299988 pos = 39.6167,140.9292 diff = 362.399994'
});
data_saddle.push({
lat: 3.9612000001e+01,
lng: 1.4091811111e+02,
content:'Saddle = 392.899994 pos = 39.6120,140.9181 diff = 362.399994'
});
data_peak.push({
lat: 3.9715000001e+01,
lng: 1.4039988889e+02,
cert : false,
content:' Peak = 550.900024 pos = 39.7150,140.3999 diff = 153.900024'
});
data_saddle.push({
lat: 3.9729666667e+01,
lng: 1.4041288889e+02,
content:'Saddle = 397.000000 pos = 39.7297,140.4129 diff = 153.900024'
});
data_peak.push({
lat: 4.0152111112e+01,
lng: 1.4069633333e+02,
cert : true,
content:'Name = JA/AT-077(JA/AT-077) peak = 702.099976 pos = 40.1521,140.6963 diff = 300.899963'
});
data_saddle.push({
lat: 4.0156000000e+01,
lng: 1.4072155556e+02,
content:'Saddle = 401.200012 pos = 40.1560,140.7216 diff = 300.899963'
});
data_peak.push({
lat: 4.0174222223e+01,
lng: 1.4066777778e+02,
cert : true,
content:'Name = JA/AT-101(JA/AT-101) peak = 564.799988 pos = 40.1742,140.6678 diff = 162.099976'
});
data_saddle.push({
lat: 4.0163111112e+01,
lng: 1.4067911111e+02,
content:'Saddle = 402.700012 pos = 40.1631,140.6791 diff = 162.099976'
});
data_peak.push({
lat: 4.0062111112e+01,
lng: 1.4047055556e+02,
cert : false,
content:' Peak = 556.000000 pos = 40.0621,140.4706 diff = 154.000000'
});
data_saddle.push({
lat: 4.0069000000e+01,
lng: 1.4048011111e+02,
content:'Saddle = 402.000000 pos = 40.0690,140.4801 diff = 154.000000'
});
data_peak.push({
lat: 3.9670888890e+01,
lng: 1.4043300000e+02,
cert : false,
content:' Peak = 558.299988 pos = 39.6709,140.4330 diff = 156.199982'
});
data_saddle.push({
lat: 3.9668555556e+01,
lng: 1.4043522222e+02,
content:'Saddle = 402.100006 pos = 39.6686,140.4352 diff = 156.199982'
});
data_peak.push({
lat: 4.0806222222e+01,
lng: 1.4098033333e+02,
cert : true,
content:'Name = JA/AM-033(JA/AM-033) peak = 752.299988 pos = 40.8062,140.9803 diff = 350.099976'
});
data_saddle.push({
lat: 4.0777555556e+01,
lng: 1.4095955556e+02,
content:'Saddle = 402.200012 pos = 40.7776,140.9596 diff = 350.099976'
});
data_peak.push({
lat: 4.0840444445e+01,
lng: 1.4103944444e+02,
cert : true,
content:'Name = JA/AM-037(JA/AM-037) peak = 717.099976 pos = 40.8404,141.0394 diff = 304.799988'
});
data_saddle.push({
lat: 4.0822111111e+01,
lng: 1.4101688889e+02,
content:'Saddle = 412.299988 pos = 40.8221,141.0169 diff = 304.799988'
});
data_peak.push({
lat: 4.0837000000e+01,
lng: 1.4089166667e+02,
cert : true,
content:'Name = JA/AM-044(JA/AM-044) peak = 683.700012 pos = 40.8370,140.8917 diff = 231.200012'
});
data_saddle.push({
lat: 4.0833888889e+01,
lng: 1.4095311111e+02,
content:'Saddle = 452.500000 pos = 40.8339,140.9531 diff = 231.200012'
});
data_peak.push({
lat: 4.0842888889e+01,
lng: 1.4093233333e+02,
cert : false,
content:' Peak = 611.200012 pos = 40.8429,140.9323 diff = 158.000000'
});
data_saddle.push({
lat: 4.0846444445e+01,
lng: 1.4091600000e+02,
content:'Saddle = 453.200012 pos = 40.8464,140.9160 diff = 158.000000'
});
data_peak.push({
lat: 4.0813111111e+01,
lng: 1.4093700000e+02,
cert : false,
content:' Peak = 682.700012 pos = 40.8131,140.9370 diff = 150.600037'
});
data_saddle.push({
lat: 4.0815333334e+01,
lng: 1.4094066667e+02,
content:'Saddle = 532.099976 pos = 40.8153,140.9407 diff = 150.600037'
});
data_peak.push({
lat: 3.9551777778e+01,
lng: 1.4183922222e+02,
cert : false,
content:' Peak = 611.500000 pos = 39.5518,141.8392 diff = 208.799988'
});
data_saddle.push({
lat: 3.9550111112e+01,
lng: 1.4183222222e+02,
content:'Saddle = 402.700012 pos = 39.5501,141.8322 diff = 208.799988'
});
data_peak.push({
lat: 4.0340444445e+01,
lng: 1.4067522222e+02,
cert : false,
content:' Peak = 592.000000 pos = 40.3404,140.6752 diff = 188.600006'
});
data_saddle.push({
lat: 4.0356888889e+01,
lng: 1.4067722222e+02,
content:'Saddle = 403.399994 pos = 40.3569,140.6772 diff = 188.600006'
});
data_peak.push({
lat: 4.0081444445e+01,
lng: 1.4050277778e+02,
cert : false,
content:' Peak = 571.400024 pos = 40.0814,140.5028 diff = 164.600037'
});
data_saddle.push({
lat: 4.0076222223e+01,
lng: 1.4050644444e+02,
content:'Saddle = 406.799988 pos = 40.0762,140.5064 diff = 164.600037'
});
data_peak.push({
lat: 3.9986888889e+01,
lng: 1.4044900000e+02,
cert : true,
content:'Name = JA/AT-085(JA/AT-085) peak = 652.200012 pos = 39.9869,140.4490 diff = 244.700012'
});
data_saddle.push({
lat: 3.9978777778e+01,
lng: 1.4045744444e+02,
content:'Saddle = 407.500000 pos = 39.9788,140.4574 diff = 244.700012'
});
data_peak.push({
lat: 3.9458333334e+01,
lng: 1.4135944444e+02,
cert : false,
content:' Peak = 572.299988 pos = 39.4583,141.3594 diff = 163.599976'
});
data_saddle.push({
lat: 3.9461111112e+01,
lng: 1.4136855556e+02,
content:'Saddle = 408.700012 pos = 39.4611,141.3686 diff = 163.599976'
});
data_peak.push({
lat: 4.0379888889e+01,
lng: 1.4067022222e+02,
cert : true,
content:'Name = JA/AT-098(JA/AT-098) peak = 584.799988 pos = 40.3799,140.6702 diff = 173.299988'
});
data_saddle.push({
lat: 4.0389777778e+01,
lng: 1.4067722222e+02,
content:'Saddle = 411.500000 pos = 40.3898,140.6772 diff = 173.299988'
});
data_peak.push({
lat: 3.9877666667e+01,
lng: 1.4045933333e+02,
cert : false,
content:' Peak = 622.000000 pos = 39.8777,140.4593 diff = 209.000000'
});
data_saddle.push({
lat: 3.9867888889e+01,
lng: 1.4048666667e+02,
content:'Saddle = 413.000000 pos = 39.8679,140.4867 diff = 209.000000'
});
data_peak.push({
lat: 3.9522444445e+01,
lng: 1.4107444444e+02,
cert : false,
content:' Peak = 570.200012 pos = 39.5224,141.0744 diff = 157.100006'
});
data_saddle.push({
lat: 3.9528000001e+01,
lng: 1.4105511111e+02,
content:'Saddle = 413.100006 pos = 39.5280,141.0551 diff = 157.100006'
});
data_peak.push({
lat: 3.9526333334e+01,
lng: 1.4103155556e+02,
cert : true,
content:'Name = JA/IT-150(JA/IT-150) peak = 576.799988 pos = 39.5263,141.0316 diff = 163.099976'
});
data_saddle.push({
lat: 3.9526333334e+01,
lng: 1.4101855556e+02,
content:'Saddle = 413.700012 pos = 39.5263,141.0186 diff = 163.099976'
});
data_peak.push({
lat: 4.0340444445e+01,
lng: 1.4084700000e+02,
cert : false,
content:' Peak = 571.599976 pos = 40.3404,140.8470 diff = 155.199982'
});
data_saddle.push({
lat: 4.0359111111e+01,
lng: 1.4086244444e+02,
content:'Saddle = 416.399994 pos = 40.3591,140.8624 diff = 155.199982'
});
data_peak.push({
lat: 3.9176000001e+01,
lng: 1.4157700000e+02,
cert : true,
content:'Name = JA/IT-137(JA/IT-137) peak = 618.000000 pos = 39.1760,141.5770 diff = 200.399994'
});
data_saddle.push({
lat: 3.9173888890e+01,
lng: 1.4161188889e+02,
content:'Saddle = 417.600006 pos = 39.1739,141.6119 diff = 200.399994'
});
data_peak.push({
lat: 3.9863666667e+01,
lng: 1.4020933333e+02,
cert : true,
content:'Name = JA/AT-069(JA/AT-069) peak = 721.000000 pos = 39.8637,140.2093 diff = 302.799988'
});
data_saddle.push({
lat: 3.9837222223e+01,
lng: 1.4023944444e+02,
content:'Saddle = 418.200012 pos = 39.8372,140.2394 diff = 302.799988'
});
data_peak.push({
lat: 3.9882444445e+01,
lng: 1.4019522222e+02,
cert : false,
content:' Peak = 573.099976 pos = 39.8824,140.1952 diff = 154.299988'
});
data_saddle.push({
lat: 3.9880777778e+01,
lng: 1.4020433333e+02,
content:'Saddle = 418.799988 pos = 39.8808,140.2043 diff = 154.299988'
});
data_peak.push({
lat: 3.9834666667e+01,
lng: 1.4021355556e+02,
cert : true,
content:'Name = JA/AT-082(JA/AT-082) peak = 681.000000 pos = 39.8347,140.2136 diff = 193.399994'
});
data_saddle.push({
lat: 3.9840333334e+01,
lng: 1.4022166667e+02,
content:'Saddle = 487.600006 pos = 39.8403,140.2217 diff = 193.399994'
});
data_peak.push({
lat: 3.9782888889e+01,
lng: 1.4057100000e+02,
cert : true,
content:'Name = JA/AT-093(JA/AT-093) peak = 614.200012 pos = 39.7829,140.5710 diff = 191.100006'
});
data_saddle.push({
lat: 3.9788555556e+01,
lng: 1.4056055556e+02,
content:'Saddle = 423.100006 pos = 39.7886,140.5606 diff = 191.100006'
});
data_peak.push({
lat: 3.9558444445e+01,
lng: 1.4148900000e+02,
cert : true,
content:'Name = Hayachinesan(JA/IT-002) peak = 1913.000000 pos = 39.5584,141.4890 diff = 1487.800049'
});
data_saddle.push({
lat: 4.0061666667e+01,
lng: 1.4122900000e+02,
content:'Saddle = 425.200012 pos = 40.0617,141.2290 diff = 1487.800049'
});
data_peak.push({
lat: 3.9235000001e+01,
lng: 1.4181988889e+02,
cert : true,
content:'Name = JA/IT-139(JA/IT-139) peak = 615.400024 pos = 39.2350,141.8199 diff = 188.400024'
});
data_saddle.push({
lat: 3.9234111112e+01,
lng: 1.4179855556e+02,
content:'Saddle = 427.000000 pos = 39.2341,141.7986 diff = 188.400024'
});
data_peak.push({
lat: 3.9768444445e+01,
lng: 1.4190022222e+02,
cert : false,
content:' Peak = 613.299988 pos = 39.7684,141.9002 diff = 161.099976'
});
data_saddle.push({
lat: 3.9754000001e+01,
lng: 1.4188511111e+02,
content:'Saddle = 452.200012 pos = 39.7540,141.8851 diff = 161.099976'
});
data_peak.push({
lat: 3.9165666668e+01,
lng: 1.4163566667e+02,
cert : false,
content:' Peak = 652.000000 pos = 39.1657,141.6357 diff = 194.600006'
});
data_saddle.push({
lat: 3.9172333334e+01,
lng: 1.4164211111e+02,
content:'Saddle = 457.399994 pos = 39.1723,141.6421 diff = 194.600006'
});
data_peak.push({
lat: 3.9301555556e+01,
lng: 1.4144744444e+02,
cert : true,
content:'Name = JA/IT-134(JA/IT-134) peak = 634.000000 pos = 39.3016,141.4474 diff = 174.799988'
});
data_saddle.push({
lat: 3.9299777779e+01,
lng: 1.4146033333e+02,
content:'Saddle = 459.200012 pos = 39.2998,141.4603 diff = 174.799988'
});
data_peak.push({
lat: 3.8975222223e+01,
lng: 1.4144711111e+02,
cert : true,
content:'Name = Muronesan(JA/IT-075) peak = 895.000000 pos = 38.9752,141.4471 diff = 433.600006'
});
data_saddle.push({
lat: 3.9044333334e+01,
lng: 1.4146355556e+02,
content:'Saddle = 461.399994 pos = 39.0443,141.4636 diff = 433.600006'
});
data_peak.push({
lat: 3.9370111112e+01,
lng: 1.4178944444e+02,
cert : true,
content:'Name = JA/IT-131(JA/IT-131) peak = 663.000000 pos = 39.3701,141.7894 diff = 200.600006'
});
data_saddle.push({
lat: 3.9379888890e+01,
lng: 1.4178966667e+02,
content:'Saddle = 462.399994 pos = 39.3799,141.7897 diff = 200.600006'
});
data_peak.push({
lat: 3.9334222223e+01,
lng: 1.4141288889e+02,
cert : false,
content:' Peak = 864.700012 pos = 39.3342,141.4129 diff = 397.600006'
});
data_saddle.push({
lat: 3.9354111112e+01,
lng: 1.4142400000e+02,
content:'Saddle = 467.100006 pos = 39.3541,141.4240 diff = 397.600006'
});
data_peak.push({
lat: 4.0117000000e+01,
lng: 1.4162400000e+02,
cert : true,
content:'Name = JA/IT-121(JA/IT-121) peak = 720.500000 pos = 40.1170,141.6240 diff = 252.200012'
});
data_saddle.push({
lat: 4.0091777778e+01,
lng: 1.4161122222e+02,
content:'Saddle = 468.299988 pos = 40.0918,141.6112 diff = 252.200012'
});
data_peak.push({
lat: 3.9069000001e+01,
lng: 1.4147833333e+02,
cert : true,
content:'Name = JA/IT-076(JA/IT-076) peak = 891.500000 pos = 39.0690,141.4783 diff = 423.200012'
});
data_saddle.push({
lat: 3.9203777779e+01,
lng: 1.4145877778e+02,
content:'Saddle = 468.299988 pos = 39.2038,141.4588 diff = 423.200012'
});
data_peak.push({
lat: 3.9108111112e+01,
lng: 1.4155877778e+02,
cert : true,
content:'Name = JA/IT-124(JA/IT-124) peak = 691.299988 pos = 39.1081,141.5588 diff = 157.899963'
});
data_saddle.push({
lat: 3.9101444445e+01,
lng: 1.4153677778e+02,
content:'Saddle = 533.400024 pos = 39.1014,141.5368 diff = 157.899963'
});
data_peak.push({
lat: 3.9086222223e+01,
lng: 1.4131322222e+02,
cert : true,
content:'Name = JA/IT-097(JA/IT-097) peak = 786.700012 pos = 39.0862,141.3132 diff = 249.900024'
});
data_saddle.push({
lat: 3.9150000001e+01,
lng: 1.4136266667e+02,
content:'Saddle = 536.799988 pos = 39.1500,141.3627 diff = 249.900024'
});
data_peak.push({
lat: 3.9137000001e+01,
lng: 1.4133277778e+02,
cert : true,
content:'Name = JA/IT-100(JA/IT-100) peak = 781.700012 pos = 39.1370,141.3328 diff = 163.799988'
});
data_saddle.push({
lat: 3.9110555556e+01,
lng: 1.4130422222e+02,
content:'Saddle = 617.900024 pos = 39.1106,141.3042 diff = 163.799988'
});
data_peak.push({
lat: 3.9095666668e+01,
lng: 1.4152422222e+02,
cert : false,
content:' Peak = 732.400024 pos = 39.0957,141.5242 diff = 169.700012'
});
data_saddle.push({
lat: 3.9111555556e+01,
lng: 1.4150033333e+02,
content:'Saddle = 562.700012 pos = 39.1116,141.5003 diff = 169.700012'
});
data_peak.push({
lat: 3.9201222223e+01,
lng: 1.4140166667e+02,
cert : true,
content:'Name = Monomiyama(JA/IT-083) peak = 870.500000 pos = 39.2012,141.4017 diff = 237.099976'
});
data_saddle.push({
lat: 3.9180888890e+01,
lng: 1.4138855556e+02,
content:'Saddle = 633.400024 pos = 39.1809,141.3886 diff = 237.099976'
});
data_peak.push({
lat: 3.9535555556e+01,
lng: 1.4185777778e+02,
cert : true,
content:'Name = JA/IT-125(JA/IT-125) peak = 690.200012 pos = 39.5356,141.8578 diff = 218.000000'
});
data_saddle.push({
lat: 3.9533444445e+01,
lng: 1.4185155556e+02,
content:'Saddle = 472.200012 pos = 39.5334,141.8516 diff = 218.000000'
});
data_peak.push({
lat: 3.9814777778e+01,
lng: 1.4183122222e+02,
cert : true,
content:'Name = JA/IT-129(JA/IT-129) peak = 680.099976 pos = 39.8148,141.8312 diff = 203.799988'
});
data_saddle.push({
lat: 3.9800777778e+01,
lng: 1.4181666667e+02,
content:'Saddle = 476.299988 pos = 39.8008,141.8167 diff = 203.799988'
});
data_peak.push({
lat: 4.0268777778e+01,
lng: 1.4137444444e+02,
cert : true,
content:'Name = Oritsumedake(JA/IT-088) peak = 851.900024 pos = 40.2688,141.3744 diff = 373.700012'
});
data_saddle.push({
lat: 4.0237555556e+01,
lng: 1.4138522222e+02,
content:'Saddle = 478.200012 pos = 40.2376,141.3852 diff = 373.700012'
});
data_peak.push({
lat: 3.9180444445e+01,
lng: 1.4164777778e+02,
cert : true,
content:'Name = JA/IT-122(JA/IT-122) peak = 713.299988 pos = 39.1804,141.6478 diff = 211.399994'
});
data_saddle.push({
lat: 3.9174444445e+01,
lng: 1.4166488889e+02,
content:'Saddle = 501.899994 pos = 39.1744,141.6649 diff = 211.399994'
});
data_peak.push({
lat: 4.0123777778e+01,
lng: 1.4140422222e+02,
cert : false,
content:' Peak = 784.099976 pos = 40.1238,141.4042 diff = 281.099976'
});
data_saddle.push({
lat: 4.0101111112e+01,
lng: 1.4144588889e+02,
content:'Saddle = 503.000000 pos = 40.1011,141.4459 diff = 281.099976'
});
data_peak.push({
lat: 3.9546888890e+01,
lng: 1.4135288889e+02,
cert : false,
content:' Peak = 681.299988 pos = 39.5469,141.3529 diff = 174.000000'
});
data_saddle.push({
lat: 3.9551444445e+01,
lng: 1.4135655556e+02,
content:'Saddle = 507.299988 pos = 39.5514,141.3566 diff = 174.000000'
});
data_peak.push({
lat: 3.9779666667e+01,
lng: 1.4183622222e+02,
cert : true,
content:'Name = JA/IT-109(JA/IT-109) peak = 744.099976 pos = 39.7797,141.8362 diff = 235.299988'
});
data_saddle.push({
lat: 3.9764888889e+01,
lng: 1.4181344444e+02,
content:'Saddle = 508.799988 pos = 39.7649,141.8134 diff = 235.299988'
});
data_peak.push({
lat: 3.9675666667e+01,
lng: 1.4185033333e+02,
cert : true,
content:'Name = JA/IT-116(JA/IT-116) peak = 730.400024 pos = 39.6757,141.8503 diff = 218.500031'
});
data_saddle.push({
lat: 3.9679888890e+01,
lng: 1.4182855556e+02,
content:'Saddle = 511.899994 pos = 39.6799,141.8286 diff = 218.500031'
});
data_peak.push({
lat: 3.9794111112e+01,
lng: 1.4159922222e+02,
cert : true,
content:'Name = JA/IT-120(JA/IT-120) peak = 721.500000 pos = 39.7941,141.5992 diff = 199.900024'
});
data_saddle.push({
lat: 3.9791000001e+01,
lng: 1.4159366667e+02,
content:'Saddle = 521.599976 pos = 39.7910,141.5937 diff = 199.900024'
});
data_peak.push({
lat: 3.9603777778e+01,
lng: 1.4127755556e+02,
cert : true,
content:'Name = JA/IT-092(JA/IT-092) peak = 836.099976 pos = 39.6038,141.2776 diff = 306.799988'
});
data_saddle.push({
lat: 3.9576444445e+01,
lng: 1.4127377778e+02,
content:'Saddle = 529.299988 pos = 39.5764,141.2738 diff = 306.799988'
});
data_peak.push({
lat: 3.9644888890e+01,
lng: 1.4126044444e+02,
cert : true,
content:'Name = JA/IT-118(JA/IT-118) peak = 722.900024 pos = 39.6449,141.2604 diff = 184.200012'
});
data_saddle.push({
lat: 3.9635333334e+01,
lng: 1.4127377778e+02,
content:'Saddle = 538.700012 pos = 39.6353,141.2738 diff = 184.200012'
});
data_peak.push({
lat: 4.0049666667e+01,
lng: 1.4175844444e+02,
cert : true,
content:'Name = JA/IT-094(JA/IT-094) peak = 812.099976 pos = 40.0497,141.7584 diff = 274.699951'
});
data_saddle.push({
lat: 4.0025888889e+01,
lng: 1.4174344444e+02,
content:'Saddle = 537.400024 pos = 40.0259,141.7434 diff = 274.699951'
});
data_peak.push({
lat: 4.0016333334e+01,
lng: 1.4173911111e+02,
cert : false,
content:' Peak = 698.799988 pos = 40.0163,141.7391 diff = 160.899963'
});
data_saddle.push({
lat: 4.0016000000e+01,
lng: 1.4172911111e+02,
content:'Saddle = 537.900024 pos = 40.0160,141.7291 diff = 160.899963'
});
data_peak.push({
lat: 4.0065444445e+01,
lng: 1.4143177778e+02,
cert : true,
content:'Name = JA/IT-099(JA/IT-099) peak = 782.900024 pos = 40.0654,141.4318 diff = 244.500000'
});
data_saddle.push({
lat: 4.0061444445e+01,
lng: 1.4145833333e+02,
content:'Saddle = 538.400024 pos = 40.0614,141.4583 diff = 244.500000'
});
data_peak.push({
lat: 3.9654777778e+01,
lng: 1.4129611111e+02,
cert : false,
content:' Peak = 700.299988 pos = 39.6548,141.2961 diff = 157.399963'
});
data_saddle.push({
lat: 3.9647111112e+01,
lng: 1.4130444444e+02,
content:'Saddle = 542.900024 pos = 39.6471,141.3044 diff = 157.399963'
});
data_peak.push({
lat: 3.9294444445e+01,
lng: 1.4151044444e+02,
cert : true,
content:'Name = JA/IT-067(JA/IT-067) peak = 916.200012 pos = 39.2944,141.5104 diff = 372.500000'
});
data_saddle.push({
lat: 3.9267444445e+01,
lng: 1.4151200000e+02,
content:'Saddle = 543.700012 pos = 39.2674,141.5120 diff = 372.500000'
});
data_peak.push({
lat: 4.0072888889e+01,
lng: 1.4164988889e+02,
cert : true,
content:'Name = JA/IT-114(JA/IT-114) peak = 732.900024 pos = 40.0729,141.6499 diff = 186.300049'
});
data_saddle.push({
lat: 4.0064222223e+01,
lng: 1.4163688889e+02,
content:'Saddle = 546.599976 pos = 40.0642,141.6369 diff = 186.300049'
});
data_peak.push({
lat: 3.9236444445e+01,
lng: 1.4148655556e+02,
cert : true,
content:'Name = JA/IT-080(JA/IT-080) peak = 883.700012 pos = 39.2364,141.4866 diff = 336.100037'
});
data_saddle.push({
lat: 3.9243555556e+01,
lng: 1.4153722222e+02,
content:'Saddle = 547.599976 pos = 39.2436,141.5372 diff = 336.100037'
});
data_peak.push({
lat: 4.0049777778e+01,
lng: 1.4136911111e+02,
cert : true,
content:'Name = JA/IT-060(JA/IT-060) peak = 947.200012 pos = 40.0498,141.3691 diff = 385.600037'
});
data_saddle.push({
lat: 3.9969333334e+01,
lng: 1.4136622222e+02,
content:'Saddle = 561.599976 pos = 39.9693,141.3662 diff = 385.600037'
});
data_peak.push({
lat: 4.0129222223e+01,
lng: 1.4134577778e+02,
cert : true,
content:'Name = JA/IT-110(JA/IT-110) peak = 743.500000 pos = 40.1292,141.3458 diff = 171.700012'
});
data_saddle.push({
lat: 4.0114666667e+01,
lng: 1.4133755556e+02,
content:'Saddle = 571.799988 pos = 40.1147,141.3376 diff = 171.700012'
});
data_peak.push({
lat: 3.9971666667e+01,
lng: 1.4135277778e+02,
cert : true,
content:'Name = JA/IT-093(JA/IT-093) peak = 820.299988 pos = 39.9717,141.3528 diff = 181.500000'
});
data_saddle.push({
lat: 3.9976444445e+01,
lng: 1.4132677778e+02,
content:'Saddle = 638.799988 pos = 39.9764,141.3268 diff = 181.500000'
});
data_peak.push({
lat: 3.9900333334e+01,
lng: 1.4164366667e+02,
cert : true,
content:'Name = JA/IT-113(JA/IT-113) peak = 733.200012 pos = 39.9003,141.6437 diff = 170.799988'
});
data_saddle.push({
lat: 3.9912000001e+01,
lng: 1.4164400000e+02,
content:'Saddle = 562.400024 pos = 39.9120,141.6440 diff = 170.799988'
});
data_peak.push({
lat: 3.9434777779e+01,
lng: 1.4136622222e+02,
cert : true,
content:'Name = JA/IT-106(JA/IT-106) peak = 756.299988 pos = 39.4348,141.3662 diff = 178.099976'
});
data_saddle.push({
lat: 3.9431000001e+01,
lng: 1.4137866667e+02,
content:'Saddle = 578.200012 pos = 39.4310,141.3787 diff = 178.099976'
});
data_peak.push({
lat: 3.9918555556e+01,
lng: 1.4177911111e+02,
cert : true,
content:'Name = JA/IT-069(JA/IT-069) peak = 916.099976 pos = 39.9186,141.7791 diff = 333.799988'
});
data_saddle.push({
lat: 3.9914222223e+01,
lng: 1.4176122222e+02,
content:'Saddle = 582.299988 pos = 39.9142,141.7612 diff = 333.799988'
});
data_peak.push({
lat: 3.9977333334e+01,
lng: 1.4176422222e+02,
cert : true,
content:'Name = JA/IT-102(JA/IT-102) peak = 783.700012 pos = 39.9773,141.7642 diff = 191.100037'
});
data_saddle.push({
lat: 3.9963000001e+01,
lng: 1.4177344444e+02,
content:'Saddle = 592.599976 pos = 39.9630,141.7734 diff = 191.100037'
});
data_peak.push({
lat: 3.9373000001e+01,
lng: 1.4150111111e+02,
cert : true,
content:'Name = JA/IT-091(JA/IT-091) peak = 841.799988 pos = 39.3730,141.5011 diff = 257.599976'
});
data_saddle.push({
lat: 3.9377777779e+01,
lng: 1.4148022222e+02,
content:'Saddle = 584.200012 pos = 39.3778,141.4802 diff = 257.599976'
});
data_peak.push({
lat: 3.9251111112e+01,
lng: 1.4162077778e+02,
cert : false,
content:' Peak = 743.099976 pos = 39.2511,141.6208 diff = 156.799988'
});
data_saddle.push({
lat: 3.9251444445e+01,
lng: 1.4163633333e+02,
content:'Saddle = 586.299988 pos = 39.2514,141.6363 diff = 156.799988'
});
data_peak.push({
lat: 3.9537111112e+01,
lng: 1.4128833333e+02,
cert : true,
content:'Name = JA/IT-098(JA/IT-098) peak = 782.400024 pos = 39.5371,141.2883 diff = 169.700012'
});
data_saddle.push({
lat: 3.9549000001e+01,
lng: 1.4128600000e+02,
content:'Saddle = 612.700012 pos = 39.5490,141.2860 diff = 169.700012'
});
data_peak.push({
lat: 3.9178888890e+01,
lng: 1.4180788889e+02,
cert : false,
content:' Peak = 774.799988 pos = 39.1789,141.8079 diff = 151.700012'
});
data_saddle.push({
lat: 3.9180777779e+01,
lng: 1.4178833333e+02,
content:'Saddle = 623.099976 pos = 39.1808,141.7883 diff = 151.700012'
});
data_peak.push({
lat: 3.9472000001e+01,
lng: 1.4167933333e+02,
cert : true,
content:'Name = JA/IT-090(JA/IT-090) peak = 844.200012 pos = 39.4720,141.6793 diff = 206.100037'
});
data_saddle.push({
lat: 3.9466888890e+01,
lng: 1.4168677778e+02,
content:'Saddle = 638.099976 pos = 39.4669,141.6868 diff = 206.100037'
});
data_peak.push({
lat: 3.9943888889e+01,
lng: 1.4153655556e+02,
cert : false,
content:' Peak = 791.700012 pos = 39.9439,141.5366 diff = 150.400024'
});
data_saddle.push({
lat: 3.9948111112e+01,
lng: 1.4154411111e+02,
content:'Saddle = 641.299988 pos = 39.9481,141.5441 diff = 150.400024'
});
data_peak.push({
lat: 3.9727000001e+01,
lng: 1.4178100000e+02,
cert : true,
content:'Name = Tougenokamiyama(JA/IT-021) peak = 1228.900024 pos = 39.7270,141.7810 diff = 587.200012'
});
data_saddle.push({
lat: 3.9742888889e+01,
lng: 1.4168400000e+02,
content:'Saddle = 641.700012 pos = 39.7429,141.6840 diff = 587.200012'
});
data_peak.push({
lat: 3.9753666667e+01,
lng: 1.4170400000e+02,
cert : true,
content:'Name = JA/IT-038(JA/IT-038) peak = 1104.400024 pos = 39.7537,141.7040 diff = 235.700012'
});
data_saddle.push({
lat: 3.9739222223e+01,
lng: 1.4174533333e+02,
content:'Saddle = 868.700012 pos = 39.7392,141.7453 diff = 235.700012'
});
data_peak.push({
lat: 4.0020666667e+01,
lng: 1.4164411111e+02,
cert : true,
content:'Name = Tooshimayama(JA/IT-017) peak = 1262.199951 pos = 40.0207,141.6441 diff = 615.399963'
});
data_saddle.push({
lat: 3.9930333334e+01,
lng: 1.4156388889e+02,
content:'Saddle = 646.799988 pos = 39.9303,141.5639 diff = 615.399963'
});
data_peak.push({
lat: 4.0082666667e+01,
lng: 1.4149633333e+02,
cert : false,
content:' Peak = 973.799988 pos = 40.0827,141.4963 diff = 224.799988'
});
data_saddle.push({
lat: 4.0079333334e+01,
lng: 1.4150911111e+02,
content:'Saddle = 749.000000 pos = 40.0793,141.5091 diff = 224.799988'
});
data_peak.push({
lat: 3.9910777778e+01,
lng: 1.4172277778e+02,
cert : true,
content:'Name = JA/IT-036(JA/IT-036) peak = 1105.699951 pos = 39.9108,141.7228 diff = 313.899963'
});
data_saddle.push({
lat: 3.9924888889e+01,
lng: 1.4167088889e+02,
content:'Saddle = 791.799988 pos = 39.9249,141.6709 diff = 313.899963'
});
data_peak.push({
lat: 3.9898222223e+01,
lng: 1.4171111111e+02,
cert : false,
content:' Peak = 1001.400024 pos = 39.8982,141.7111 diff = 160.100037'
});
data_saddle.push({
lat: 3.9904555556e+01,
lng: 1.4171311111e+02,
content:'Saddle = 841.299988 pos = 39.9046,141.7131 diff = 160.100037'
});
data_peak.push({
lat: 3.9938444445e+01,
lng: 1.4162800000e+02,
cert : true,
content:'Name = JA/IT-029(JA/IT-029) peak = 1162.699951 pos = 39.9384,141.6280 diff = 260.999939'
});
data_saddle.push({
lat: 3.9983111112e+01,
lng: 1.4157544444e+02,
content:'Saddle = 901.700012 pos = 39.9831,141.5754 diff = 260.999939'
});
data_peak.push({
lat: 4.0038111112e+01,
lng: 1.4154088889e+02,
cert : true,
content:'Name = Akkamori(JA/IT-020) peak = 1238.099976 pos = 40.0381,141.5409 diff = 280.599976'
});
data_saddle.push({
lat: 4.0045555556e+01,
lng: 1.4155311111e+02,
content:'Saddle = 957.500000 pos = 40.0456,141.5531 diff = 280.599976'
});
data_peak.push({
lat: 4.0026000000e+01,
lng: 1.4160500000e+02,
cert : false,
content:' Peak = 1175.500000 pos = 40.0260,141.6050 diff = 168.200012'
});
data_saddle.push({
lat: 4.0020222223e+01,
lng: 1.4163211111e+02,
content:'Saddle = 1007.299988 pos = 40.0202,141.6321 diff = 168.200012'
});
data_peak.push({
lat: 3.9205555556e+01,
lng: 1.4173211111e+02,
cert : true,
content:'Name = Goyouzan(JA/IT-011) peak = 1350.500000 pos = 39.2056,141.7321 diff = 702.099976'
});
data_saddle.push({
lat: 3.9231888890e+01,
lng: 1.4170900000e+02,
content:'Saddle = 648.400024 pos = 39.2319,141.7090 diff = 702.099976'
});
data_peak.push({
lat: 3.9155222223e+01,
lng: 1.4173988889e+02,
cert : true,
content:'Name = JA/IT-079(JA/IT-079) peak = 887.200012 pos = 39.1552,141.7399 diff = 174.299988'
});
data_saddle.push({
lat: 3.9178555556e+01,
lng: 1.4174188889e+02,
content:'Saddle = 712.900024 pos = 39.1786,141.7419 diff = 174.299988'
});
data_peak.push({
lat: 3.9218555556e+01,
lng: 1.4170311111e+02,
cert : true,
content:'Name = JA/IT-022(JA/IT-022) peak = 1227.500000 pos = 39.2186,141.7031 diff = 308.000000'
});
data_saddle.push({
lat: 3.9214222223e+01,
lng: 1.4171677778e+02,
content:'Saddle = 919.500000 pos = 39.2142,141.7168 diff = 308.000000'
});
data_peak.push({
lat: 3.9624888890e+01,
lng: 1.4173688889e+02,
cert : true,
content:'Name = JA/IT-073(JA/IT-073) peak = 912.900024 pos = 39.6249,141.7369 diff = 239.500000'
});
data_saddle.push({
lat: 3.9621333334e+01,
lng: 1.4169611111e+02,
content:'Saddle = 673.400024 pos = 39.6213,141.6961 diff = 239.500000'
});
data_peak.push({
lat: 3.9325555556e+01,
lng: 1.4170922222e+02,
cert : true,
content:'Name = JA/IT-014(JA/IT-014) peak = 1311.800049 pos = 39.3256,141.7092 diff = 613.500061'
});
data_saddle.push({
lat: 3.9366888890e+01,
lng: 1.4165588889e+02,
content:'Saddle = 698.299988 pos = 39.3669,141.6559 diff = 613.500061'
});
data_peak.push({
lat: 3.9245666667e+01,
lng: 1.4170566667e+02,
cert : true,
content:'Name = JA/IT-053(JA/IT-053) peak = 992.200012 pos = 39.2457,141.7057 diff = 204.700012'
});
data_saddle.push({
lat: 3.9264888890e+01,
lng: 1.4170477778e+02,
content:'Saddle = 787.500000 pos = 39.2649,141.7048 diff = 204.700012'
});
data_peak.push({
lat: 3.9351666667e+01,
lng: 1.4166077778e+02,
cert : true,
content:'Name = JA/IT-055(JA/IT-055) peak = 970.099976 pos = 39.3517,141.6608 diff = 152.899963'
});
data_saddle.push({
lat: 3.9340333334e+01,
lng: 1.4166000000e+02,
content:'Saddle = 817.200012 pos = 39.3403,141.6600 diff = 152.899963'
});
data_peak.push({
lat: 3.9321111112e+01,
lng: 1.4178333333e+02,
cert : true,
content:'Name = JA/IT-049(JA/IT-049) peak = 1013.500000 pos = 39.3211,141.7833 diff = 172.500000'
});
data_saddle.push({
lat: 3.9320777779e+01,
lng: 1.4176755556e+02,
content:'Saddle = 841.000000 pos = 39.3208,141.7676 diff = 172.500000'
});
data_peak.push({
lat: 3.9266888890e+01,
lng: 1.4169266667e+02,
cert : false,
content:' Peak = 1014.200012 pos = 39.2669,141.6927 diff = 156.299988'
});
data_saddle.push({
lat: 3.9274666667e+01,
lng: 1.4169777778e+02,
content:'Saddle = 857.900024 pos = 39.2747,141.6978 diff = 156.299988'
});
data_peak.push({
lat: 3.9294333334e+01,
lng: 1.4168044444e+02,
cert : true,
content:'Name = JA/IT-025(JA/IT-025) peak = 1183.400024 pos = 39.2943,141.6804 diff = 222.500000'
});
data_saddle.push({
lat: 3.9305333334e+01,
lng: 1.4168833333e+02,
content:'Saddle = 960.900024 pos = 39.3053,141.6883 diff = 222.500000'
});
data_peak.push({
lat: 3.9318444445e+01,
lng: 1.4165011111e+02,
cert : true,
content:'Name = Rokkoushisan(JA/IT-016) peak = 1293.099976 pos = 39.3184,141.6501 diff = 320.299988'
});
data_saddle.push({
lat: 3.9317777779e+01,
lng: 1.4167044444e+02,
content:'Saddle = 972.799988 pos = 39.3178,141.6704 diff = 320.299988'
});
data_peak.push({
lat: 3.9844111112e+01,
lng: 1.4124677778e+02,
cert : true,
content:'Name = Himekamisan(JA/IT-032) peak = 1122.400024 pos = 39.8441,141.2468 diff = 420.900024'
});
data_saddle.push({
lat: 3.9826000001e+01,
lng: 1.4137188889e+02,
content:'Saddle = 701.500000 pos = 39.8260,141.3719 diff = 420.900024'
});
data_peak.push({
lat: 3.9848111112e+01,
lng: 1.4135800000e+02,
cert : true,
content:'Name = JA/IT-066(JA/IT-066) peak = 923.599976 pos = 39.8481,141.3580 diff = 221.699951'
});
data_saddle.push({
lat: 3.9835111112e+01,
lng: 1.4132100000e+02,
content:'Saddle = 701.900024 pos = 39.8351,141.3210 diff = 221.699951'
});
data_peak.push({
lat: 3.9802777778e+01,
lng: 1.4130966667e+02,
cert : true,
content:'Name = JA/IT-058(JA/IT-058) peak = 961.099976 pos = 39.8028,141.3097 diff = 165.399963'
});
data_saddle.push({
lat: 3.9805666667e+01,
lng: 1.4128800000e+02,
content:'Saddle = 795.700012 pos = 39.8057,141.2880 diff = 165.399963'
});
data_peak.push({
lat: 3.9650555556e+01,
lng: 1.4162777778e+02,
cert : false,
content:' Peak = 912.900024 pos = 39.6506,141.6278 diff = 210.200012'
});
data_saddle.push({
lat: 3.9661222223e+01,
lng: 1.4162266667e+02,
content:'Saddle = 702.700012 pos = 39.6612,141.6227 diff = 210.200012'
});
data_peak.push({
lat: 4.0014555556e+01,
lng: 1.4141955556e+02,
cert : true,
content:'Name = JA/IT-071(JA/IT-071) peak = 912.799988 pos = 40.0146,141.4196 diff = 181.599976'
});
data_saddle.push({
lat: 3.9989666667e+01,
lng: 1.4142666667e+02,
content:'Saddle = 731.200012 pos = 39.9897,141.4267 diff = 181.599976'
});
data_peak.push({
lat: 3.9374222223e+01,
lng: 1.4145633333e+02,
cert : true,
content:'Name = JA/IT-045(JA/IT-045) peak = 1036.900024 pos = 39.3742,141.4563 diff = 300.200012'
});
data_saddle.push({
lat: 3.9418666667e+01,
lng: 1.4143511111e+02,
content:'Saddle = 736.700012 pos = 39.4187,141.4351 diff = 300.200012'
});
data_peak.push({
lat: 3.9409555556e+01,
lng: 1.4143111111e+02,
cert : true,
content:'Name = JA/IT-051(JA/IT-051) peak = 993.200012 pos = 39.4096,141.4311 diff = 175.799988'
});
data_saddle.push({
lat: 3.9396444445e+01,
lng: 1.4144288889e+02,
content:'Saddle = 817.400024 pos = 39.3964,141.4429 diff = 175.799988'
});
data_peak.push({
lat: 3.9574444445e+01,
lng: 1.4131811111e+02,
cert : false,
content:' Peak = 907.700012 pos = 39.5744,141.3181 diff = 166.000000'
});
data_saddle.push({
lat: 3.9571111112e+01,
lng: 1.4132477778e+02,
content:'Saddle = 741.700012 pos = 39.5711,141.3248 diff = 166.000000'
});
data_peak.push({
lat: 3.9517555556e+01,
lng: 1.4176533333e+02,
cert : false,
content:' Peak = 1162.199951 pos = 39.5176,141.7653 diff = 414.799927'
});
data_saddle.push({
lat: 3.9490111112e+01,
lng: 1.4170355556e+02,
content:'Saddle = 747.400024 pos = 39.4901,141.7036 diff = 414.799927'
});
data_peak.push({
lat: 3.9507555556e+01,
lng: 1.4172733333e+02,
cert : false,
content:' Peak = 1138.500000 pos = 39.5076,141.7273 diff = 185.700012'
});
data_saddle.push({
lat: 3.9510555556e+01,
lng: 1.4173555556e+02,
content:'Saddle = 952.799988 pos = 39.5106,141.7356 diff = 185.700012'
});
data_peak.push({
lat: 3.9697555556e+01,
lng: 1.4148355556e+02,
cert : true,
content:'Name = Aomatsubayama(JA/IT-010) peak = 1365.099976 pos = 39.6976,141.4836 diff = 615.500000'
});
data_saddle.push({
lat: 3.9654333334e+01,
lng: 1.4134800000e+02,
content:'Saddle = 749.599976 pos = 39.6543,141.3480 diff = 615.500000'
});
data_peak.push({
lat: 3.9620222223e+01,
lng: 1.4167011111e+02,
cert : true,
content:'Name = JA/IT-054(JA/IT-054) peak = 984.299988 pos = 39.6202,141.6701 diff = 201.500000'
});
data_saddle.push({
lat: 3.9629777778e+01,
lng: 1.4167177778e+02,
content:'Saddle = 782.799988 pos = 39.6298,141.6718 diff = 201.500000'
});
data_peak.push({
lat: 3.9829444445e+01,
lng: 1.4158855556e+02,
cert : true,
content:'Name = JA/IT-041(JA/IT-041) peak = 1064.099976 pos = 39.8294,141.5886 diff = 196.399963'
});
data_saddle.push({
lat: 3.9817666667e+01,
lng: 1.4158055556e+02,
content:'Saddle = 867.700012 pos = 39.8177,141.5806 diff = 196.399963'
});
data_peak.push({
lat: 3.9900111112e+01,
lng: 1.4148533333e+02,
cert : true,
content:'Name = Misugodake(JA/IT-026) peak = 1181.400024 pos = 39.9001,141.4853 diff = 285.400024'
});
data_saddle.push({
lat: 3.9849000001e+01,
lng: 1.4150788889e+02,
content:'Saddle = 896.000000 pos = 39.8490,141.5079 diff = 285.400024'
});
data_peak.push({
lat: 3.9646000001e+01,
lng: 1.4167811111e+02,
cert : true,
content:'Name = JA/IT-034(JA/IT-034) peak = 1115.000000 pos = 39.6460,141.6781 diff = 191.900024'
});
data_saddle.push({
lat: 3.9658222223e+01,
lng: 1.4166655556e+02,
content:'Saddle = 923.099976 pos = 39.6582,141.6666 diff = 191.900024'
});
data_peak.push({
lat: 3.9750333334e+01,
lng: 1.4162633333e+02,
cert : true,
content:'Name = Sakainokamidake(JA/IT-013) peak = 1318.400024 pos = 39.7503,141.6263 diff = 366.400024'
});
data_saddle.push({
lat: 3.9711888890e+01,
lng: 1.4157944444e+02,
content:'Saddle = 952.000000 pos = 39.7119,141.5794 diff = 366.400024'
});
data_peak.push({
lat: 3.9676555556e+01,
lng: 1.4165811111e+02,
cert : false,
content:' Peak = 1170.500000 pos = 39.6766,141.6581 diff = 158.000000'
});
data_saddle.push({
lat: 3.9677444445e+01,
lng: 1.4164611111e+02,
content:'Saddle = 1012.500000 pos = 39.6774,141.6461 diff = 158.000000'
});
data_peak.push({
lat: 3.9711777778e+01,
lng: 1.4160444444e+02,
cert : true,
content:'Name = Gaitakamori(JA/IT-015) peak = 1303.900024 pos = 39.7118,141.6044 diff = 223.400024'
});
data_saddle.push({
lat: 3.9734444445e+01,
lng: 1.4162122222e+02,
content:'Saddle = 1080.500000 pos = 39.7344,141.6212 diff = 223.400024'
});
data_peak.push({
lat: 3.9681555556e+01,
lng: 1.4139622222e+02,
cert : false,
content:' Peak = 1173.400024 pos = 39.6816,141.3962 diff = 151.800049'
});
data_saddle.push({
lat: 3.9686777778e+01,
lng: 1.4140322222e+02,
content:'Saddle = 1021.599976 pos = 39.6868,141.4032 diff = 151.800049'
});
data_peak.push({
lat: 3.9710888890e+01,
lng: 1.4142422222e+02,
cert : true,
content:'Name = JA/IT-018(JA/IT-018) peak = 1261.300049 pos = 39.7109,141.4242 diff = 193.600098'
});
data_saddle.push({
lat: 3.9679111112e+01,
lng: 1.4145322222e+02,
content:'Saddle = 1067.699951 pos = 39.6791,141.4532 diff = 193.600098'
});
data_peak.push({
lat: 3.9756222223e+01,
lng: 1.4142266667e+02,
cert : false,
content:' Peak = 1253.500000 pos = 39.7562,141.4227 diff = 180.199951'
});
data_saddle.push({
lat: 3.9739666667e+01,
lng: 1.4140111111e+02,
content:'Saddle = 1073.300049 pos = 39.7397,141.4011 diff = 180.199951'
});
data_peak.push({
lat: 3.9479555556e+01,
lng: 1.4138911111e+02,
cert : false,
content:' Peak = 920.099976 pos = 39.4796,141.3891 diff = 162.199951'
});
data_saddle.push({
lat: 3.9481666667e+01,
lng: 1.4140255556e+02,
content:'Saddle = 757.900024 pos = 39.4817,141.4026 diff = 162.199951'
});
data_peak.push({
lat: 3.9446333334e+01,
lng: 1.4172077778e+02,
cert : true,
content:'Name = JA/IT-028(JA/IT-028) peak = 1172.000000 pos = 39.4463,141.7208 diff = 384.799988'
});
data_saddle.push({
lat: 3.9444888890e+01,
lng: 1.4167111111e+02,
content:'Saddle = 787.200012 pos = 39.4449,141.6711 diff = 384.799988'
});
data_peak.push({
lat: 3.9425444445e+01,
lng: 1.4174466667e+02,
cert : true,
content:'Name = JA/IT-047(JA/IT-047) peak = 1020.500000 pos = 39.4254,141.7447 diff = 195.799988'
});
data_saddle.push({
lat: 3.9426777779e+01,
lng: 1.4172200000e+02,
content:'Saddle = 824.700012 pos = 39.4268,141.7220 diff = 195.799988'
});
data_peak.push({
lat: 3.9456777778e+01,
lng: 1.4165944444e+02,
cert : false,
content:' Peak = 1028.000000 pos = 39.4568,141.6594 diff = 150.299988'
});
data_saddle.push({
lat: 3.9467777778e+01,
lng: 1.4162588889e+02,
content:'Saddle = 877.700012 pos = 39.4678,141.6259 diff = 150.299988'
});
data_peak.push({
lat: 3.9442222223e+01,
lng: 1.4145422222e+02,
cert : false,
content:' Peak = 1040.099976 pos = 39.4422,141.4542 diff = 152.000000'
});
data_saddle.push({
lat: 3.9456222223e+01,
lng: 1.4144100000e+02,
content:'Saddle = 888.099976 pos = 39.4562,141.4410 diff = 152.000000'
});
data_peak.push({
lat: 3.9603666667e+01,
lng: 1.4140288889e+02,
cert : true,
content:'Name = JA/IT-024(JA/IT-024) peak = 1215.400024 pos = 39.6037,141.4029 diff = 183.599976'
});
data_saddle.push({
lat: 3.9589333334e+01,
lng: 1.4141977778e+02,
content:'Saddle = 1031.800049 pos = 39.5893,141.4198 diff = 183.599976'
});
data_peak.push({
lat: 3.9510555556e+01,
lng: 1.4144588889e+02,
cert : false,
content:' Peak = 1336.400024 pos = 39.5106,141.4459 diff = 161.200073'
});
data_saddle.push({
lat: 3.9519000001e+01,
lng: 1.4144944444e+02,
content:'Saddle = 1175.199951 pos = 39.5190,141.4494 diff = 161.200073'
});
data_peak.push({
lat: 3.9530000001e+01,
lng: 1.4149566667e+02,
cert : true,
content:'Name = Yakushidake(JA/IT-003) peak = 1644.599976 pos = 39.5300,141.4957 diff = 396.000000'
});
data_saddle.push({
lat: 3.9541111112e+01,
lng: 1.4149566667e+02,
content:'Saddle = 1248.599976 pos = 39.5411,141.4957 diff = 396.000000'
});
data_peak.push({
lat: 4.0659000000e+01,
lng: 1.4087722222e+02,
cert : true,
content:'Name = Hakkoudasan (Oodake)(JA/AM-002) peak = 1583.900024 pos = 40.6590,140.8772 diff = 1137.100098'
});
data_saddle.push({
lat: 4.0137444445e+01,
lng: 1.4100244444e+02,
content:'Saddle = 446.799988 pos = 40.1374,141.0024 diff = 1137.100098'
});
data_peak.push({
lat: 4.0459444445e+01,
lng: 1.4090977778e+02,
cert : true,
content:'Name = JA/AM-043(JA/AM-043) peak = 680.599976 pos = 40.4594,140.9098 diff = 206.799988'
});
data_saddle.push({
lat: 4.0451333334e+01,
lng: 1.4091355556e+02,
content:'Saddle = 473.799988 pos = 40.4513,140.9136 diff = 206.799988'
});
data_peak.push({
lat: 4.0308777778e+01,
lng: 1.4101233333e+02,
cert : false,
content:' Peak = 651.599976 pos = 40.3088,141.0123 diff = 153.899963'
});
data_saddle.push({
lat: 4.0311333334e+01,
lng: 1.4101544444e+02,
content:'Saddle = 497.700012 pos = 40.3113,141.0154 diff = 153.899963'
});
data_peak.push({
lat: 4.0362333334e+01,
lng: 1.4105277778e+02,
cert : true,
content:'Name = JA/AM-038(JA/AM-038) peak = 717.400024 pos = 40.3623,141.0528 diff = 215.600037'
});
data_saddle.push({
lat: 4.0362777778e+01,
lng: 1.4103888889e+02,
content:'Saddle = 501.799988 pos = 40.3628,141.0389 diff = 215.600037'
});
data_peak.push({
lat: 4.0168444445e+01,
lng: 1.4086077778e+02,
cert : false,
content:' Peak = 1122.000000 pos = 40.1684,140.8608 diff = 590.900024'
});
data_saddle.push({
lat: 4.0313888889e+01,
lng: 1.4097655556e+02,
content:'Saddle = 531.099976 pos = 40.3139,140.9766 diff = 590.900024'
});
data_peak.push({
lat: 4.0133666667e+01,
lng: 1.4090477778e+02,
cert : false,
content:' Peak = 684.900024 pos = 40.1337,140.9048 diff = 151.800049'
});
data_saddle.push({
lat: 4.0140222223e+01,
lng: 1.4090533333e+02,
content:'Saddle = 533.099976 pos = 40.1402,140.9053 diff = 151.800049'
});
data_peak.push({
lat: 4.0272555556e+01,
lng: 1.4100222222e+02,
cert : true,
content:'Name = JA/AM-028(JA/AM-028) peak = 805.500000 pos = 40.2726,141.0022 diff = 257.299988'
});
data_saddle.push({
lat: 4.0271111112e+01,
lng: 1.4098777778e+02,
content:'Saddle = 548.200012 pos = 40.2711,140.9878 diff = 257.299988'
});
data_peak.push({
lat: 4.0308333334e+01,
lng: 1.4095722222e+02,
cert : true,
content:'Name = Yosukedoumori(JA/AM-023) peak = 840.599976 pos = 40.3083,140.9572 diff = 268.299988'
});
data_saddle.push({
lat: 4.0277222223e+01,
lng: 1.4095344444e+02,
content:'Saddle = 572.299988 pos = 40.2772,140.9534 diff = 268.299988'
});
data_peak.push({
lat: 4.0324666667e+01,
lng: 1.4089344444e+02,
cert : true,
content:'Name = JA/AT-063(JA/AT-063) peak = 763.500000 pos = 40.3247,140.8934 diff = 161.400024'
});
data_saddle.push({
lat: 4.0316222223e+01,
lng: 1.4091688889e+02,
content:'Saddle = 602.099976 pos = 40.3162,140.9169 diff = 161.400024'
});
data_peak.push({
lat: 4.0194888889e+01,
lng: 1.4093633333e+02,
cert : true,
content:'Name = JA/IT-081(JA/IT-081) peak = 874.000000 pos = 40.1949,140.9363 diff = 281.299988'
});
data_saddle.push({
lat: 4.0216777778e+01,
lng: 1.4093611111e+02,
content:'Saddle = 592.700012 pos = 40.2168,140.9361 diff = 281.299988'
});
data_peak.push({
lat: 4.0280333334e+01,
lng: 1.4089266667e+02,
cert : true,
content:'Name = JA/AT-059(JA/AT-059) peak = 781.500000 pos = 40.2803,140.8927 diff = 179.799988'
});
data_saddle.push({
lat: 4.0272777778e+01,
lng: 1.4090166667e+02,
content:'Saddle = 601.700012 pos = 40.2728,140.9017 diff = 179.799988'
});
data_peak.push({
lat: 4.0198666667e+01,
lng: 1.4104611111e+02,
cert : true,
content:'Name = Inaniwadake(JA/IT-040) peak = 1077.199951 pos = 40.1987,141.0461 diff = 454.599976'
});
data_saddle.push({
lat: 4.0238666667e+01,
lng: 1.4087977778e+02,
content:'Saddle = 622.599976 pos = 40.2387,140.8798 diff = 454.599976'
});
data_peak.push({
lat: 4.0243000000e+01,
lng: 1.4089900000e+02,
cert : false,
content:' Peak = 822.900024 pos = 40.2430,140.8990 diff = 150.400024'
});
data_saddle.push({
lat: 4.0247000000e+01,
lng: 1.4090500000e+02,
content:'Saddle = 672.500000 pos = 40.2470,140.9050 diff = 150.400024'
});
data_peak.push({
lat: 4.0246111112e+01,
lng: 1.4094433333e+02,
cert : true,
content:'Name = Nakadake(JA/IT-046) peak = 1023.299988 pos = 40.2461,140.9443 diff = 340.099976'
});
data_saddle.push({
lat: 4.0232111112e+01,
lng: 1.4096855556e+02,
content:'Saddle = 683.200012 pos = 40.2321,140.9686 diff = 340.099976'
});
data_peak.push({
lat: 4.0195333334e+01,
lng: 1.4085366667e+02,
cert : false,
content:' Peak = 895.099976 pos = 40.1953,140.8537 diff = 163.899963'
});
data_saddle.push({
lat: 4.0183111112e+01,
lng: 1.4085422222e+02,
content:'Saddle = 731.200012 pos = 40.1831,140.8542 diff = 163.899963'
});
data_peak.push({
lat: 4.0145777778e+01,
lng: 1.4084588889e+02,
cert : true,
content:'Name = Gonomiyadake(JA/AT-021) peak = 1111.699951 pos = 40.1458,140.8459 diff = 268.599976'
});
data_saddle.push({
lat: 4.0153666667e+01,
lng: 1.4085711111e+02,
content:'Saddle = 843.099976 pos = 40.1537,140.8571 diff = 268.599976'
});
data_peak.push({
lat: 4.0361000000e+01,
lng: 1.4097366667e+02,
cert : true,
content:'Name = Nishinomori(JA/AT-066) peak = 753.900024 pos = 40.3610,140.9737 diff = 218.100037'
});
data_saddle.push({
lat: 4.0377000000e+01,
lng: 1.4098166667e+02,
content:'Saddle = 535.799988 pos = 40.3770,140.9817 diff = 218.100037'
});
data_peak.push({
lat: 4.0599111111e+01,
lng: 1.4071577778e+02,
cert : true,
content:'Name = JA/AM-032(JA/AM-032) peak = 767.099976 pos = 40.5991,140.7158 diff = 204.099976'
});
data_saddle.push({
lat: 4.0614555556e+01,
lng: 1.4074288889e+02,
content:'Saddle = 563.000000 pos = 40.6146,140.7429 diff = 204.099976'
});
data_peak.push({
lat: 4.0328444445e+01,
lng: 1.4099488889e+02,
cert : true,
content:'Name = JA/AM-022(JA/AM-022) peak = 870.200012 pos = 40.3284,140.9949 diff = 274.100037'
});
data_saddle.push({
lat: 4.0407333334e+01,
lng: 1.4098477778e+02,
content:'Saddle = 596.099976 pos = 40.4073,140.9848 diff = 274.100037'
});
data_peak.push({
lat: 4.0385000000e+01,
lng: 1.4102622222e+02,
cert : false,
content:' Peak = 801.900024 pos = 40.3850,141.0262 diff = 204.400024'
});
data_saddle.push({
lat: 4.0356444445e+01,
lng: 1.4102800000e+02,
content:'Saddle = 597.500000 pos = 40.3564,141.0280 diff = 204.400024'
});
data_peak.push({
lat: 4.0380444445e+01,
lng: 1.4081777778e+02,
cert : false,
content:' Peak = 766.799988 pos = 40.3804,140.8178 diff = 153.599976'
});
data_saddle.push({
lat: 4.0383666667e+01,
lng: 1.4082200000e+02,
content:'Saddle = 613.200012 pos = 40.3837,140.8220 diff = 153.599976'
});
data_peak.push({
lat: 4.0695000000e+01,
lng: 1.4099155556e+02,
cert : false,
content:' Peak = 1021.500000 pos = 40.6950,140.9916 diff = 407.900024'
});
data_saddle.push({
lat: 4.0663888889e+01,
lng: 1.4095944444e+02,
content:'Saddle = 613.599976 pos = 40.6639,140.9594 diff = 407.900024'
});
data_peak.push({
lat: 4.0731666667e+01,
lng: 1.4097700000e+02,
cert : false,
content:' Peak = 831.700012 pos = 40.7317,140.9770 diff = 182.500000'
});
data_saddle.push({
lat: 4.0725111111e+01,
lng: 1.4097100000e+02,
content:'Saddle = 649.200012 pos = 40.7251,140.9710 diff = 182.500000'
});
data_peak.push({
lat: 4.0761555556e+01,
lng: 1.4091944444e+02,
cert : true,
content:'Name = JA/AM-016(JA/AM-016) peak = 921.299988 pos = 40.7616,140.9194 diff = 228.000000'
});
data_saddle.push({
lat: 4.0721555556e+01,
lng: 1.4093100000e+02,
content:'Saddle = 693.299988 pos = 40.7216,140.9310 diff = 228.000000'
});
data_peak.push({
lat: 4.0729888889e+01,
lng: 1.4091611111e+02,
cert : false,
content:' Peak = 890.299988 pos = 40.7299,140.9161 diff = 168.000000'
});
data_saddle.push({
lat: 4.0748888889e+01,
lng: 1.4090577778e+02,
content:'Saddle = 722.299988 pos = 40.7489,140.9058 diff = 168.000000'
});
data_peak.push({
lat: 4.0453000000e+01,
lng: 1.4100144444e+02,
cert : true,
content:'Name = Heraidake　 (Mitsudake)(JA/AM-005) peak = 1158.800049 pos = 40.4530,141.0014 diff = 528.600037'
});
data_saddle.push({
lat: 4.0406333334e+01,
lng: 1.4086555556e+02,
content:'Saddle = 630.200012 pos = 40.4063,140.8656 diff = 528.600037'
});
data_peak.push({
lat: 4.0427111111e+01,
lng: 1.4098522222e+02,
cert : false,
content:' Peak = 990.500000 pos = 40.4271,140.9852 diff = 157.700012'
});
data_saddle.push({
lat: 4.0436444445e+01,
lng: 1.4099600000e+02,
content:'Saddle = 832.799988 pos = 40.4364,140.9960 diff = 157.700012'
});
data_peak.push({
lat: 4.0462555556e+01,
lng: 1.4097088889e+02,
cert : false,
content:' Peak = 1050.900024 pos = 40.4626,140.9709 diff = 159.100037'
});
data_saddle.push({
lat: 4.0454333334e+01,
lng: 1.4098933333e+02,
content:'Saddle = 891.799988 pos = 40.4543,140.9893 diff = 159.100037'
});
data_peak.push({
lat: 4.0447333334e+01,
lng: 1.4078811111e+02,
cert : true,
content:'Name = Shirojiyama(JA/AT-030) peak = 1033.000000 pos = 40.4473,140.7881 diff = 339.099976'
});
data_saddle.push({
lat: 4.0496333334e+01,
lng: 1.4082111111e+02,
content:'Saddle = 693.900024 pos = 40.4963,140.8211 diff = 339.099976'
});
data_peak.push({
lat: 4.0564111111e+01,
lng: 1.4075833333e+02,
cert : true,
content:'Name = JA/AM-011(JA/AM-011) peak = 986.500000 pos = 40.5641,140.7583 diff = 179.500000'
});
data_saddle.push({
lat: 4.0567333334e+01,
lng: 1.4079211111e+02,
content:'Saddle = 807.000000 pos = 40.5673,140.7921 diff = 179.500000'
});
data_peak.push({
lat: 4.0647222222e+01,
lng: 1.4095488889e+02,
cert : true,
content:'Name = JA/AM-007(JA/AM-007) peak = 1020.799988 pos = 40.6472,140.9549 diff = 200.599976'
});
data_saddle.push({
lat: 4.0644000000e+01,
lng: 1.4094133333e+02,
content:'Saddle = 820.200012 pos = 40.6440,140.9413 diff = 200.599976'
});
data_peak.push({
lat: 4.0603222222e+01,
lng: 1.4084244444e+02,
cert : true,
content:'Name = Kushigamine (Kamidake)(JA/AM-003) peak = 1516.000000 pos = 40.6032,140.8424 diff = 491.599976'
});
data_saddle.push({
lat: 4.0633777778e+01,
lng: 1.4088300000e+02,
content:'Saddle = 1024.400024 pos = 40.6338,140.8830 diff = 491.599976'
});
data_peak.push({
lat: 4.0597888889e+01,
lng: 1.4088866667e+02,
cert : false,
content:' Peak = 1444.199951 pos = 40.5979,140.8887 diff = 178.599976'
});
data_saddle.push({
lat: 4.0605555556e+01,
lng: 1.4087755556e+02,
content:'Saddle = 1265.599976 pos = 40.6056,140.8776 diff = 178.599976'
});
data_peak.push({
lat: 4.0660666667e+01,
lng: 1.4092488889e+02,
cert : false,
content:' Peak = 1240.199951 pos = 40.6607,140.9249 diff = 171.000000'
});
data_saddle.push({
lat: 4.0658333334e+01,
lng: 1.4092066667e+02,
content:'Saddle = 1069.199951 pos = 40.6583,140.9207 diff = 171.000000'
});
data_peak.push({
lat: 4.0652777778e+01,
lng: 1.4090833333e+02,
cert : false,
content:' Peak = 1551.699951 pos = 40.6528,140.9083 diff = 269.500000'
});
data_saddle.push({
lat: 4.0654111111e+01,
lng: 1.4090000000e+02,
content:'Saddle = 1282.199951 pos = 40.6541,140.9000 diff = 269.500000'
});
data_peak.push({
lat: 4.0153222223e+01,
lng: 1.4074633333e+02,
cert : false,
content:' Peak = 622.500000 pos = 40.1532,140.7463 diff = 175.399994'
});
data_saddle.push({
lat: 4.0140222223e+01,
lng: 1.4073933333e+02,
content:'Saddle = 447.100006 pos = 40.1402,140.7393 diff = 175.399994'
});
data_peak.push({
lat: 3.9945333334e+01,
lng: 1.4045833333e+02,
cert : true,
content:'Name = JA/AT-075(JA/AT-075) peak = 701.799988 pos = 39.9453,140.4583 diff = 249.299988'
});
data_saddle.push({
lat: 3.9944888889e+01,
lng: 1.4047300000e+02,
content:'Saddle = 452.500000 pos = 39.9449,140.4730 diff = 249.299988'
});
data_peak.push({
lat: 4.0127222223e+01,
lng: 1.4094411111e+02,
cert : false,
content:' Peak = 665.799988 pos = 40.1272,140.9441 diff = 206.599976'
});
data_saddle.push({
lat: 4.0122222223e+01,
lng: 1.4094766667e+02,
content:'Saddle = 459.200012 pos = 40.1222,140.9477 diff = 206.599976'
});
data_peak.push({
lat: 3.9651888890e+01,
lng: 1.4087211111e+02,
cert : false,
content:' Peak = 683.700012 pos = 39.6519,140.8721 diff = 222.100006'
});
data_saddle.push({
lat: 3.9617222223e+01,
lng: 1.4085866667e+02,
content:'Saddle = 461.600006 pos = 39.6172,140.8587 diff = 222.100006'
});
data_peak.push({
lat: 4.0000222223e+01,
lng: 1.4037188889e+02,
cert : false,
content:' Peak = 653.700012 pos = 40.0002,140.3719 diff = 191.700012'
});
data_saddle.push({
lat: 3.9981333334e+01,
lng: 1.4036433333e+02,
content:'Saddle = 462.000000 pos = 39.9813,140.3643 diff = 191.700012'
});
data_peak.push({
lat: 3.9558111112e+01,
lng: 1.4106188889e+02,
cert : true,
content:'Name = JA/IT-133(JA/IT-133) peak = 645.500000 pos = 39.5581,141.0619 diff = 176.399994'
});
data_saddle.push({
lat: 3.9562000001e+01,
lng: 1.4105333333e+02,
content:'Saddle = 469.100006 pos = 39.5620,141.0533 diff = 176.399994'
});
data_peak.push({
lat: 4.0072000000e+01,
lng: 1.4081588889e+02,
cert : false,
content:' Peak = 623.700012 pos = 40.0720,140.8159 diff = 152.100006'
});
data_saddle.push({
lat: 4.0068888889e+01,
lng: 1.4082211111e+02,
content:'Saddle = 471.600006 pos = 40.0689,140.8221 diff = 152.100006'
});
data_peak.push({
lat: 3.9454888890e+01,
lng: 1.4091277778e+02,
cert : false,
content:' Peak = 964.400024 pos = 39.4549,140.9128 diff = 492.400024'
});
data_saddle.push({
lat: 3.9583444445e+01,
lng: 1.4085133333e+02,
content:'Saddle = 472.000000 pos = 39.5834,140.8513 diff = 492.400024'
});
data_peak.push({
lat: 3.9579333334e+01,
lng: 1.4097366667e+02,
cert : true,
content:'Name = JA/IT-062(JA/IT-062) peak = 940.900024 pos = 39.5793,140.9737 diff = 408.100037'
});
data_saddle.push({
lat: 3.9536888890e+01,
lng: 1.4093588889e+02,
content:'Saddle = 532.799988 pos = 39.5369,140.9359 diff = 408.100037'
});
data_peak.push({
lat: 3.9505777778e+01,
lng: 1.4103111111e+02,
cert : false,
content:' Peak = 686.799988 pos = 39.5058,141.0311 diff = 150.500000'
});
data_saddle.push({
lat: 3.9509444445e+01,
lng: 1.4100911111e+02,
content:'Saddle = 536.299988 pos = 39.5094,141.0091 diff = 150.500000'
});
data_peak.push({
lat: 3.9587111112e+01,
lng: 1.4105933333e+02,
cert : true,
content:'Name = Azumaneyama(JA/IT-064) peak = 928.599976 pos = 39.5871,141.0593 diff = 371.699951'
});
data_saddle.push({
lat: 3.9575444445e+01,
lng: 1.4103011111e+02,
content:'Saddle = 556.900024 pos = 39.5754,141.0301 diff = 371.699951'
});
data_peak.push({
lat: 3.9648111112e+01,
lng: 1.4104666667e+02,
cert : true,
content:'Name = JA/IT-087(JA/IT-087) peak = 866.599976 pos = 39.6481,141.0467 diff = 268.099976'
});
data_saddle.push({
lat: 3.9629000001e+01,
lng: 1.4105055556e+02,
content:'Saddle = 598.500000 pos = 39.6290,141.0506 diff = 268.099976'
});
data_peak.push({
lat: 3.9635666667e+01,
lng: 1.4104177778e+02,
cert : false,
content:' Peak = 781.299988 pos = 39.6357,141.0418 diff = 164.299988'
});
data_saddle.push({
lat: 3.9636777778e+01,
lng: 1.4104644444e+02,
content:'Saddle = 617.000000 pos = 39.6368,141.0464 diff = 164.299988'
});
data_peak.push({
lat: 3.9622666667e+01,
lng: 1.4105688889e+02,
cert : true,
content:'Name = JA/IT-089(JA/IT-089) peak = 846.400024 pos = 39.6227,141.0569 diff = 228.700012'
});
data_saddle.push({
lat: 3.9619444445e+01,
lng: 1.4105366667e+02,
content:'Saddle = 617.700012 pos = 39.6194,141.0537 diff = 228.700012'
});
data_peak.push({
lat: 3.9539333334e+01,
lng: 1.4098955556e+02,
cert : false,
content:' Peak = 772.700012 pos = 39.5393,140.9896 diff = 159.299988'
});
data_saddle.push({
lat: 3.9543111112e+01,
lng: 1.4098422222e+02,
content:'Saddle = 613.400024 pos = 39.5431,140.9842 diff = 159.299988'
});
data_peak.push({
lat: 3.9511888890e+01,
lng: 1.4098666667e+02,
cert : true,
content:'Name = JA/IT-077(JA/IT-077) peak = 892.099976 pos = 39.5119,140.9867 diff = 259.699951'
});
data_saddle.push({
lat: 3.9510222223e+01,
lng: 1.4097366667e+02,
content:'Saddle = 632.400024 pos = 39.5102,140.9737 diff = 259.699951'
});
data_peak.push({
lat: 3.9531444445e+01,
lng: 1.4096100000e+02,
cert : false,
content:' Peak = 830.900024 pos = 39.5314,140.9610 diff = 161.200012'
});
data_saddle.push({
lat: 3.9554888890e+01,
lng: 1.4096533333e+02,
content:'Saddle = 669.700012 pos = 39.5549,140.9653 diff = 161.200012'
});
data_peak.push({
lat: 3.9396333334e+01,
lng: 1.4093666667e+02,
cert : false,
content:' Peak = 753.700012 pos = 39.3963,140.9367 diff = 176.000000'
});
data_saddle.push({
lat: 3.9413000001e+01,
lng: 1.4093322222e+02,
content:'Saddle = 577.700012 pos = 39.4130,140.9332 diff = 176.000000'
});
data_peak.push({
lat: 3.9348222223e+01,
lng: 1.4086844444e+02,
cert : true,
content:'Name = Kuromori(JA/IT-061) peak = 941.599976 pos = 39.3482,140.8684 diff = 333.000000'
});
data_saddle.push({
lat: 3.9428666667e+01,
lng: 1.4082655556e+02,
content:'Saddle = 608.599976 pos = 39.4287,140.8266 diff = 333.000000'
});
data_peak.push({
lat: 3.9363222223e+01,
lng: 1.4086300000e+02,
cert : true,
content:'Name = JA/IT-068(JA/IT-068) peak = 915.900024 pos = 39.3632,140.8630 diff = 179.000000'
});
data_saddle.push({
lat: 3.9360444445e+01,
lng: 1.4086866667e+02,
content:'Saddle = 736.900024 pos = 39.3604,140.8687 diff = 179.000000'
});
data_peak.push({
lat: 3.9378777779e+01,
lng: 1.4091022222e+02,
cert : true,
content:'Name = JA/IT-078(JA/IT-078) peak = 892.799988 pos = 39.3788,140.9102 diff = 215.299988'
});
data_saddle.push({
lat: 3.9443555556e+01,
lng: 1.4090244444e+02,
content:'Saddle = 677.500000 pos = 39.4436,140.9024 diff = 215.299988'
});
data_peak.push({
lat: 3.9410000001e+01,
lng: 1.4087000000e+02,
cert : true,
content:'Name = JA/IT-084(JA/IT-084) peak = 866.700012 pos = 39.4100,140.8700 diff = 178.500000'
});
data_saddle.push({
lat: 3.9462777778e+01,
lng: 1.4087177778e+02,
content:'Saddle = 688.200012 pos = 39.4628,140.8718 diff = 178.500000'
});
data_peak.push({
lat: 3.9517888890e+01,
lng: 1.4088233333e+02,
cert : true,
content:'Name = JA/IT-074(JA/IT-074) peak = 912.500000 pos = 39.5179,140.8823 diff = 191.200012'
});
data_saddle.push({
lat: 3.9485222223e+01,
lng: 1.4088455556e+02,
content:'Saddle = 721.299988 pos = 39.4852,140.8846 diff = 191.200012'
});
data_peak.push({
lat: 3.9449555556e+01,
lng: 1.4093311111e+02,
cert : true,
content:'Name = JA/IT-057(JA/IT-057) peak = 962.700012 pos = 39.4496,140.9331 diff = 159.799988'
});
data_saddle.push({
lat: 3.9448888890e+01,
lng: 1.4092577778e+02,
content:'Saddle = 802.900024 pos = 39.4489,140.9258 diff = 159.799988'
});
data_peak.push({
lat: 3.9967888889e+01,
lng: 1.4044888889e+02,
cert : false,
content:' Peak = 711.799988 pos = 39.9679,140.4489 diff = 237.799988'
});
data_saddle.push({
lat: 3.9968888889e+01,
lng: 1.4046966667e+02,
content:'Saddle = 474.000000 pos = 39.9689,140.4697 diff = 237.799988'
});
data_peak.push({
lat: 3.9506888890e+01,
lng: 1.4078422222e+02,
cert : true,
content:'Name = JA/IT-119(JA/IT-119) peak = 721.500000 pos = 39.5069,140.7842 diff = 219.000000'
});
data_saddle.push({
lat: 3.9522555556e+01,
lng: 1.4079066667e+02,
content:'Saddle = 502.500000 pos = 39.5226,140.7907 diff = 219.000000'
});
data_peak.push({
lat: 3.9835777778e+01,
lng: 1.4040111111e+02,
cert : false,
content:' Peak = 1172.500000 pos = 39.8358,140.4011 diff = 665.299988'
});
data_saddle.push({
lat: 3.9864555556e+01,
lng: 1.4053700000e+02,
content:'Saddle = 507.200012 pos = 39.8646,140.5370 diff = 665.299988'
});
data_peak.push({
lat: 3.9704666667e+01,
lng: 1.4044444444e+02,
cert : false,
content:' Peak = 671.599976 pos = 39.7047,140.4444 diff = 160.299988'
});
data_saddle.push({
lat: 3.9708000001e+01,
lng: 1.4045133333e+02,
content:'Saddle = 511.299988 pos = 39.7080,140.4513 diff = 160.299988'
});
data_peak.push({
lat: 3.9664111112e+01,
lng: 1.4048855556e+02,
cert : true,
content:'Name = JA/AT-068(JA/AT-068) peak = 750.900024 pos = 39.6641,140.4886 diff = 217.800049'
});
data_saddle.push({
lat: 3.9679666667e+01,
lng: 1.4049400000e+02,
content:'Saddle = 533.099976 pos = 39.6797,140.4940 diff = 217.800049'
});
data_peak.push({
lat: 3.9680444445e+01,
lng: 1.4045855556e+02,
cert : true,
content:'Name = JA/AT-071(JA/AT-071) peak = 721.799988 pos = 39.6804,140.4586 diff = 159.700012'
});
data_saddle.push({
lat: 3.9667888890e+01,
lng: 1.4047700000e+02,
content:'Saddle = 562.099976 pos = 39.6679,140.4770 diff = 159.700012'
});
data_peak.push({
lat: 3.9784777778e+01,
lng: 1.4051900000e+02,
cert : false,
content:' Peak = 782.799988 pos = 39.7848,140.5190 diff = 185.799988'
});
data_saddle.push({
lat: 3.9792777778e+01,
lng: 1.4051988889e+02,
content:'Saddle = 597.000000 pos = 39.7928,140.5199 diff = 185.799988'
});
data_peak.push({
lat: 3.9851444445e+01,
lng: 1.4050400000e+02,
cert : false,
content:' Peak = 770.299988 pos = 39.8514,140.5040 diff = 162.200012'
});
data_saddle.push({
lat: 3.9847444445e+01,
lng: 1.4050911111e+02,
content:'Saddle = 608.099976 pos = 39.8474,140.5091 diff = 162.200012'
});
data_peak.push({
lat: 3.9881222223e+01,
lng: 1.4042722222e+02,
cert : false,
content:' Peak = 776.000000 pos = 39.8812,140.4272 diff = 164.099976'
});
data_saddle.push({
lat: 3.9877222223e+01,
lng: 1.4041966667e+02,
content:'Saddle = 611.900024 pos = 39.8772,140.4197 diff = 164.099976'
});
data_peak.push({
lat: 3.9927666667e+01,
lng: 1.4034200000e+02,
cert : false,
content:' Peak = 792.500000 pos = 39.9277,140.3420 diff = 171.500000'
});
data_saddle.push({
lat: 3.9928000001e+01,
lng: 1.4034755556e+02,
content:'Saddle = 621.000000 pos = 39.9280,140.3476 diff = 171.500000'
});
data_peak.push({
lat: 3.9769333334e+01,
lng: 1.4040544444e+02,
cert : false,
content:' Peak = 860.299988 pos = 39.7693,140.4054 diff = 211.599976'
});
data_saddle.push({
lat: 3.9773777778e+01,
lng: 1.4043444444e+02,
content:'Saddle = 648.700012 pos = 39.7738,140.4344 diff = 211.599976'
});
data_peak.push({
lat: 3.9936444445e+01,
lng: 1.4036155556e+02,
cert : true,
content:'Name = JA/AT-053(JA/AT-053) peak = 834.599976 pos = 39.9364,140.3616 diff = 172.099976'
});
data_saddle.push({
lat: 3.9921555556e+01,
lng: 1.4037177778e+02,
content:'Saddle = 662.500000 pos = 39.9216,140.3718 diff = 172.099976'
});
data_peak.push({
lat: 3.9729333334e+01,
lng: 1.4050711111e+02,
cert : true,
content:'Name = JA/AT-026(JA/AT-026) peak = 1057.800049 pos = 39.7293,140.5071 diff = 366.800049'
});
data_saddle.push({
lat: 3.9764888889e+01,
lng: 1.4050744444e+02,
content:'Saddle = 691.000000 pos = 39.7649,140.5074 diff = 366.800049'
});
data_peak.push({
lat: 3.9730666667e+01,
lng: 1.4046188889e+02,
cert : false,
content:' Peak = 901.299988 pos = 39.7307,140.4619 diff = 158.899963'
});
data_saddle.push({
lat: 3.9731777778e+01,
lng: 1.4047800000e+02,
content:'Saddle = 742.400024 pos = 39.7318,140.4780 diff = 158.899963'
});
data_peak.push({
lat: 3.9813777778e+01,
lng: 1.4051566667e+02,
cert : true,
content:'Name = Daibutsudake(JA/AT-018) peak = 1165.500000 pos = 39.8138,140.5157 diff = 472.000000'
});
data_saddle.push({
lat: 3.9821888889e+01,
lng: 1.4043944444e+02,
content:'Saddle = 693.500000 pos = 39.8219,140.4394 diff = 472.000000'
});
data_peak.push({
lat: 3.9787333334e+01,
lng: 1.4046744444e+02,
cert : true,
content:'Name = JA/AT-031(JA/AT-031) peak = 1032.199951 pos = 39.7873,140.4674 diff = 229.299927'
});
data_saddle.push({
lat: 3.9805777778e+01,
lng: 1.4049555556e+02,
content:'Saddle = 802.900024 pos = 39.8058,140.4956 diff = 229.299927'
});
data_peak.push({
lat: 3.9797111112e+01,
lng: 1.4031077778e+02,
cert : true,
content:'Name = Taiheizan(JA/AT-016) peak = 1170.199951 pos = 39.7971,140.3108 diff = 417.499939'
});
data_saddle.push({
lat: 3.9834111112e+01,
lng: 1.4038022222e+02,
content:'Saddle = 752.700012 pos = 39.8341,140.3802 diff = 417.499939'
});
data_peak.push({
lat: 3.9825444445e+01,
lng: 1.4035500000e+02,
cert : true,
content:'Name = JA/AT-025(JA/AT-025) peak = 1065.300049 pos = 39.8254,140.3550 diff = 193.200073'
});
data_saddle.push({
lat: 3.9806000001e+01,
lng: 1.4034177778e+02,
content:'Saddle = 872.099976 pos = 39.8060,140.3418 diff = 193.200073'
});
data_peak.push({
lat: 3.9866888889e+01,
lng: 1.4040933333e+02,
cert : false,
content:' Peak = 962.900024 pos = 39.8669,140.4093 diff = 191.100037'
});
data_saddle.push({
lat: 3.9858777778e+01,
lng: 1.4039900000e+02,
content:'Saddle = 771.799988 pos = 39.8588,140.3990 diff = 191.100037'
});
data_peak.push({
lat: 3.9378444445e+01,
lng: 1.4063200000e+02,
cert : true,
content:'Name = JA/AT-061(JA/AT-061) peak = 765.400024 pos = 39.3784,140.6320 diff = 257.800018'
});
data_saddle.push({
lat: 3.9382000001e+01,
lng: 1.4064366667e+02,
content:'Saddle = 507.600006 pos = 39.3820,140.6437 diff = 257.800018'
});
data_peak.push({
lat: 4.0069333334e+01,
lng: 1.4110555556e+02,
cert : true,
content:'Name = Nanashigureyama(JA/IT-042) peak = 1062.000000 pos = 40.0693,141.1056 diff = 544.799988'
});
data_saddle.push({
lat: 4.0015555556e+01,
lng: 1.4098966667e+02,
content:'Saddle = 517.200012 pos = 40.0156,140.9897 diff = 544.799988'
});
data_peak.push({
lat: 4.0026666667e+01,
lng: 1.4104100000e+02,
cert : true,
content:'Name = JA/IT-059(JA/IT-059) peak = 953.299988 pos = 40.0267,141.0410 diff = 390.700012'
});
data_saddle.push({
lat: 4.0043000000e+01,
lng: 1.4107355556e+02,
content:'Saddle = 562.599976 pos = 40.0430,141.0736 diff = 390.700012'
});
data_peak.push({
lat: 4.0085666667e+01,
lng: 1.4117188889e+02,
cert : true,
content:'Name = JA/IT-048(JA/IT-048) peak = 1016.900024 pos = 40.0857,141.1719 diff = 381.200012'
});
data_saddle.push({
lat: 4.0088666667e+01,
lng: 1.4111644444e+02,
content:'Saddle = 635.700012 pos = 40.0887,141.1164 diff = 381.200012'
});
data_peak.push({
lat: 4.0103888889e+01,
lng: 1.4059977778e+02,
cert : true,
content:'Name = Ryuugamori(JA/AT-027) peak = 1047.400024 pos = 40.1039,140.5998 diff = 525.500000'
});
data_saddle.push({
lat: 4.0085000000e+01,
lng: 1.4065566667e+02,
content:'Saddle = 521.900024 pos = 40.0850,140.6557 diff = 525.500000'
});
data_peak.push({
lat: 4.0130444445e+01,
lng: 1.4057788889e+02,
cert : false,
content:' Peak = 833.099976 pos = 40.1304,140.5779 diff = 181.500000'
});
data_saddle.push({
lat: 4.0129777778e+01,
lng: 1.4058944444e+02,
content:'Saddle = 651.599976 pos = 40.1298,140.5894 diff = 181.500000'
});
data_peak.push({
lat: 3.9809333334e+01,
lng: 1.4063466667e+02,
cert : true,
content:'Name = JA/AT-057(JA/AT-057) peak = 795.500000 pos = 39.8093,140.6347 diff = 258.599976'
});
data_saddle.push({
lat: 3.9839555556e+01,
lng: 1.4062222222e+02,
content:'Saddle = 536.900024 pos = 39.8396,140.6222 diff = 258.599976'
});
data_peak.push({
lat: 3.9860777778e+01,
lng: 1.4064477778e+02,
cert : true,
content:'Name = JA/AT-064(JA/AT-064) peak = 761.500000 pos = 39.8608,140.6448 diff = 220.799988'
});
data_saddle.push({
lat: 3.9864666667e+01,
lng: 1.4064755556e+02,
content:'Saddle = 540.700012 pos = 39.8647,140.6476 diff = 220.799988'
});
data_peak.push({
lat: 4.0111222223e+01,
lng: 1.4097488889e+02,
cert : true,
content:'Name = JA/IT-111(JA/IT-111) peak = 743.299988 pos = 40.1112,140.9749 diff = 200.500000'
});
data_saddle.push({
lat: 4.0100333334e+01,
lng: 1.4097577778e+02,
content:'Saddle = 542.799988 pos = 40.1003,140.9758 diff = 200.500000'
});
data_peak.push({
lat: 3.9870111112e+01,
lng: 1.4065822222e+02,
cert : false,
content:' Peak = 852.099976 pos = 39.8701,140.6582 diff = 299.500000'
});
data_saddle.push({
lat: 3.9880000001e+01,
lng: 1.4065933333e+02,
content:'Saddle = 552.599976 pos = 39.8800,140.6593 diff = 299.500000'
});
data_peak.push({
lat: 3.9329444445e+01,
lng: 1.4071022222e+02,
cert : true,
content:'Name = JA/IT-103(JA/IT-103) peak = 771.900024 pos = 39.3294,140.7102 diff = 219.200012'
});
data_saddle.push({
lat: 3.9347888890e+01,
lng: 1.4068811111e+02,
content:'Saddle = 552.700012 pos = 39.3479,140.6881 diff = 219.200012'
});
data_peak.push({
lat: 3.9883111112e+01,
lng: 1.4052055556e+02,
cert : true,
content:'Name = JA/AT-049(JA/AT-049) peak = 852.700012 pos = 39.8831,140.5206 diff = 270.000000'
});
data_saddle.push({
lat: 3.9881222223e+01,
lng: 1.4054766667e+02,
content:'Saddle = 582.700012 pos = 39.8812,140.5477 diff = 270.000000'
});
data_peak.push({
lat: 3.9879222223e+01,
lng: 1.4049222222e+02,
cert : false,
content:' Peak = 820.599976 pos = 39.8792,140.4922 diff = 158.799988'
});
data_saddle.push({
lat: 3.9880111112e+01,
lng: 1.4050222222e+02,
content:'Saddle = 661.799988 pos = 39.8801,140.5022 diff = 158.799988'
});
data_peak.push({
lat: 4.0112333334e+01,
lng: 1.4092444444e+02,
cert : true,
content:'Name = JA/IT-095(JA/IT-095) peak = 791.799988 pos = 40.1123,140.9244 diff = 189.299988'
});
data_saddle.push({
lat: 4.0100333334e+01,
lng: 1.4092766667e+02,
content:'Saddle = 602.500000 pos = 40.1003,140.9277 diff = 189.299988'
});
data_peak.push({
lat: 4.0091000000e+01,
lng: 1.4085488889e+02,
cert : false,
content:' Peak = 915.200012 pos = 40.0910,140.8549 diff = 312.500000'
});
data_saddle.push({
lat: 4.0035555556e+01,
lng: 1.4085344444e+02,
content:'Saddle = 602.700012 pos = 40.0356,140.8534 diff = 312.500000'
});
data_peak.push({
lat: 4.0112111112e+01,
lng: 1.4081911111e+02,
cert : false,
content:' Peak = 903.400024 pos = 40.1121,140.8191 diff = 159.800049'
});
data_saddle.push({
lat: 4.0081777778e+01,
lng: 1.4083044444e+02,
content:'Saddle = 743.599976 pos = 40.0818,140.8304 diff = 159.800049'
});
data_peak.push({
lat: 4.0101333334e+01,
lng: 1.4071633333e+02,
cert : true,
content:'Name = Waseyama(JA/AT-056) peak = 811.099976 pos = 40.1013,140.7163 diff = 193.299988'
});
data_saddle.push({
lat: 4.0062222223e+01,
lng: 1.4070622222e+02,
content:'Saddle = 617.799988 pos = 40.0622,140.7062 diff = 193.299988'
});
data_peak.push({
lat: 3.9906111112e+01,
lng: 1.4056377778e+02,
cert : false,
content:' Peak = 791.099976 pos = 39.9061,140.5638 diff = 158.599976'
});
data_saddle.push({
lat: 3.9900111112e+01,
lng: 1.4057277778e+02,
content:'Saddle = 632.500000 pos = 39.9001,140.5728 diff = 158.599976'
});
data_peak.push({
lat: 3.9894444445e+01,
lng: 1.4057288889e+02,
cert : false,
content:' Peak = 872.900024 pos = 39.8944,140.5729 diff = 165.400024'
});
data_saddle.push({
lat: 3.9888777778e+01,
lng: 1.4059055556e+02,
content:'Saddle = 707.500000 pos = 39.8888,140.5906 diff = 165.400024'
});
data_peak.push({
lat: 3.9683222223e+01,
lng: 1.4076900000e+02,
cert : true,
content:'Name = JA/AT-045(JA/AT-045) peak = 923.000000 pos = 39.6832,140.7690 diff = 210.799988'
});
data_saddle.push({
lat: 3.9645333334e+01,
lng: 1.4076677778e+02,
content:'Saddle = 712.200012 pos = 39.6453,140.7668 diff = 210.799988'
});
data_peak.push({
lat: 4.0068333334e+01,
lng: 1.4092288889e+02,
cert : false,
content:' Peak = 1050.900024 pos = 40.0683,140.9229 diff = 337.800049'
});
data_saddle.push({
lat: 4.0041444445e+01,
lng: 1.4089811111e+02,
content:'Saddle = 713.099976 pos = 40.0414,140.8981 diff = 337.800049'
});
data_peak.push({
lat: 4.0051888889e+01,
lng: 1.4091444444e+02,
cert : false,
content:' Peak = 1036.000000 pos = 40.0519,140.9144 diff = 152.299988'
});
data_saddle.push({
lat: 4.0060777778e+01,
lng: 1.4092511111e+02,
content:'Saddle = 883.700012 pos = 40.0608,140.9251 diff = 152.299988'
});
data_peak.push({
lat: 3.9447888890e+01,
lng: 1.4067644444e+02,
cert : true,
content:'Name = Mahirudake(JA/IT-043) peak = 1057.900024 pos = 39.4479,140.6764 diff = 305.800049'
});
data_saddle.push({
lat: 3.9470222223e+01,
lng: 1.4070166667e+02,
content:'Saddle = 752.099976 pos = 39.4702,140.7017 diff = 305.800049'
});
data_peak.push({
lat: 3.9417111112e+01,
lng: 1.4067511111e+02,
cert : false,
content:' Peak = 955.000000 pos = 39.4171,140.6751 diff = 152.000000'
});
data_saddle.push({
lat: 3.9423111112e+01,
lng: 1.4068411111e+02,
content:'Saddle = 803.000000 pos = 39.4231,140.6841 diff = 152.000000'
});
data_peak.push({
lat: 3.9481555556e+01,
lng: 1.4072788889e+02,
cert : true,
content:'Name = JA/IT-063(JA/IT-063) peak = 935.400024 pos = 39.4816,140.7279 diff = 177.300049'
});
data_saddle.push({
lat: 3.9491666667e+01,
lng: 1.4071588889e+02,
content:'Saddle = 758.099976 pos = 39.4917,140.7159 diff = 177.300049'
});
data_peak.push({
lat: 3.9570444445e+01,
lng: 1.4075422222e+02,
cert : true,
content:'Name = Wagadake(JA/IT-008) peak = 1440.000000 pos = 39.5704,140.7542 diff = 658.799988'
});
data_saddle.push({
lat: 3.9684111112e+01,
lng: 1.4081922222e+02,
content:'Saddle = 781.200012 pos = 39.6841,140.8192 diff = 658.799988'
});
data_peak.push({
lat: 3.9589000001e+01,
lng: 1.4069500000e+02,
cert : true,
content:'Name = JA/AT-015(JA/AT-015) peak = 1176.300049 pos = 39.5890,140.6950 diff = 323.400024'
});
data_saddle.push({
lat: 3.9577555556e+01,
lng: 1.4072255556e+02,
content:'Saddle = 852.900024 pos = 39.5776,140.7226 diff = 323.400024'
});
data_peak.push({
lat: 3.9610222223e+01,
lng: 1.4077277778e+02,
cert : true,
content:'Name = JA/AT-004(JA/AT-004) peak = 1375.099976 pos = 39.6102,140.7728 diff = 192.500000'
});
data_saddle.push({
lat: 3.9588444445e+01,
lng: 1.4076644444e+02,
content:'Saddle = 1182.599976 pos = 39.5884,140.7664 diff = 192.500000'
});
data_peak.push({
lat: 3.9976777778e+01,
lng: 1.4054422222e+02,
cert : true,
content:'Name = Moriyoshizan(JA/AT-002) peak = 1453.400024 pos = 39.9768,140.5442 diff = 664.100037'
});
data_saddle.push({
lat: 3.9967111112e+01,
lng: 1.4068800000e+02,
content:'Saddle = 789.299988 pos = 39.9671,140.6880 diff = 664.100037'
});
data_peak.push({
lat: 3.9930888889e+01,
lng: 1.4063400000e+02,
cert : true,
content:'Name = JA/AT-033(JA/AT-033) peak = 1015.299988 pos = 39.9309,140.6340 diff = 163.700012'
});
data_saddle.push({
lat: 3.9957555556e+01,
lng: 1.4061622222e+02,
content:'Saddle = 851.599976 pos = 39.9576,140.6162 diff = 163.700012'
});
data_peak.push({
lat: 3.9691000001e+01,
lng: 1.4081566667e+02,
cert : true,
content:'Name = JA/AT-032(JA/AT-032) peak = 1024.699951 pos = 39.6910,140.8157 diff = 197.499939'
});
data_saddle.push({
lat: 3.9713000001e+01,
lng: 1.4079433333e+02,
content:'Saddle = 827.200012 pos = 39.7130,140.7943 diff = 197.499939'
});
data_peak.push({
lat: 3.9761111112e+01,
lng: 1.4079922222e+02,
cert : true,
content:'Name = Komagatake (Onamedake)(JA/AT-001) peak = 1636.400024 pos = 39.7611,140.7992 diff = 684.500000'
});
data_saddle.push({
lat: 3.9857111112e+01,
lng: 1.4078533333e+02,
content:'Saddle = 951.900024 pos = 39.8571,140.7853 diff = 684.500000'
});
data_peak.push({
lat: 3.9806444445e+01,
lng: 1.4073077778e+02,
cert : true,
content:'Name = JA/AT-009(JA/AT-009) peak = 1252.800049 pos = 39.8064,140.7308 diff = 246.500061'
});
data_saddle.push({
lat: 3.9816666667e+01,
lng: 1.4074855556e+02,
content:'Saddle = 1006.299988 pos = 39.8167,140.7486 diff = 246.500061'
});
data_peak.push({
lat: 3.9842222223e+01,
lng: 1.4078522222e+02,
cert : true,
content:'Name = Ooshiromori(JA/IT-023) peak = 1214.599976 pos = 39.8422,140.7852 diff = 192.000000'
});
data_saddle.push({
lat: 3.9820333334e+01,
lng: 1.4079577778e+02,
content:'Saddle = 1022.599976 pos = 39.8203,140.7958 diff = 192.000000'
});
data_peak.push({
lat: 3.9799000001e+01,
lng: 1.4090277778e+02,
cert : false,
content:' Peak = 1234.000000 pos = 39.7990,140.9028 diff = 152.800049'
});
data_saddle.push({
lat: 3.9797888889e+01,
lng: 1.4089477778e+02,
content:'Saddle = 1081.199951 pos = 39.7979,140.8948 diff = 152.800049'
});
data_peak.push({
lat: 3.9786777778e+01,
lng: 1.4089000000e+02,
cert : false,
content:' Peak = 1413.099976 pos = 39.7868,140.8900 diff = 250.599976'
});
data_saddle.push({
lat: 3.9790444445e+01,
lng: 1.4087844444e+02,
content:'Saddle = 1162.500000 pos = 39.7904,140.8784 diff = 250.599976'
});
data_peak.push({
lat: 3.9791555556e+01,
lng: 1.4084533333e+02,
cert : true,
content:'Name = JA/IT-007(JA/IT-007) peak = 1540.800049 pos = 39.7916,140.8453 diff = 183.200073'
});
data_saddle.push({
lat: 3.9778444445e+01,
lng: 1.4083144444e+02,
content:'Saddle = 1357.599976 pos = 39.7784,140.8314 diff = 183.200073'
});
data_peak.push({
lat: 4.0020333334e+01,
lng: 1.4076033333e+02,
cert : true,
content:'Name = Sanboukou(JA/AT-010) peak = 1221.800049 pos = 40.0203,140.7603 diff = 249.000061'
});
data_saddle.push({
lat: 3.9988444445e+01,
lng: 1.4074711111e+02,
content:'Saddle = 972.799988 pos = 39.9884,140.7471 diff = 249.000061'
});
data_peak.push({
lat: 3.9995555556e+01,
lng: 1.4071355556e+02,
cert : false,
content:' Peak = 1201.699951 pos = 39.9956,140.7136 diff = 158.099976'
});
data_saddle.push({
lat: 3.9997555556e+01,
lng: 1.4072766667e+02,
content:'Saddle = 1043.599976 pos = 39.9976,140.7277 diff = 158.099976'
});
data_peak.push({
lat: 3.9963666667e+01,
lng: 1.4075766667e+02,
cert : true,
content:'Name = Yakeyama(JA/AT-005) peak = 1366.300049 pos = 39.9637,140.7577 diff = 359.800049'
});
data_saddle.push({
lat: 3.9969555556e+01,
lng: 1.4080044444e+02,
content:'Saddle = 1006.500000 pos = 39.9696,140.8004 diff = 359.800049'
});
data_peak.push({
lat: 3.9900222223e+01,
lng: 1.4077733333e+02,
cert : true,
content:'Name = JA/AT-008(JA/AT-008) peak = 1291.500000 pos = 39.9002,140.7773 diff = 261.099976'
});
data_saddle.push({
lat: 3.9892444445e+01,
lng: 1.4079977778e+02,
content:'Saddle = 1030.400024 pos = 39.8924,140.7998 diff = 261.099976'
});
data_peak.push({
lat: 3.9881666667e+01,
lng: 1.4079977778e+02,
cert : true,
content:'Name = JA/IT-012(JA/IT-012) peak = 1333.300049 pos = 39.8817,140.7998 diff = 219.900024'
});
data_saddle.push({
lat: 3.9879444445e+01,
lng: 1.4081388889e+02,
content:'Saddle = 1113.400024 pos = 39.8794,140.8139 diff = 219.900024'
});
data_peak.push({
lat: 3.9977666667e+01,
lng: 1.4095822222e+02,
cert : false,
content:' Peak = 1303.400024 pos = 39.9777,140.9582 diff = 155.599976'
});
data_saddle.push({
lat: 3.9977333334e+01,
lng: 1.4094911111e+02,
content:'Saddle = 1147.800049 pos = 39.9773,140.9491 diff = 155.599976'
});
data_peak.push({
lat: 3.9956000001e+01,
lng: 1.4085500000e+02,
cert : false,
content:' Peak = 1614.000000 pos = 39.9560,140.8550 diff = 331.599976'
});
data_saddle.push({
lat: 3.9842333334e+01,
lng: 1.4092955556e+02,
content:'Saddle = 1282.400024 pos = 39.8423,140.9296 diff = 331.599976'
});
data_peak.push({
lat: 3.9880888889e+01,
lng: 1.4089066667e+02,
cert : true,
content:'Name = JA/IT-004(JA/IT-004) peak = 1544.800049 pos = 39.8809,140.8907 diff = 187.600098'
});
data_saddle.push({
lat: 3.9904777778e+01,
lng: 1.4086788889e+02,
content:'Saddle = 1357.199951 pos = 39.9048,140.8679 diff = 187.600098'
});
data_peak.push({
lat: 3.9226666667e+01,
lng: 1.4058922222e+02,
cert : true,
content:'Name = JA/AT-113(JA/AT-113) peak = 478.399994 pos = 39.2267,140.5892 diff = 176.500000'
});
data_saddle.push({
lat: 3.9202888890e+01,
lng: 1.4062177778e+02,
content:'Saddle = 301.899994 pos = 39.2029,140.6218 diff = 176.500000'
});
data_peak.push({
lat: 3.9272111112e+01,
lng: 1.4067888889e+02,
cert : false,
content:' Peak = 482.399994 pos = 39.2721,140.6789 diff = 174.399994'
});
data_saddle.push({
lat: 3.9264111112e+01,
lng: 1.4069366667e+02,
content:'Saddle = 308.000000 pos = 39.2641,140.6937 diff = 174.399994'
});
data_peak.push({
lat: 3.9236666667e+01,
lng: 1.4022766667e+02,
cert : true,
content:'Name = Yashioyama(JA/AT-073) peak = 713.000000 pos = 39.2367,140.2277 diff = 396.299988'
});
data_saddle.push({
lat: 3.9185333334e+01,
lng: 1.4025711111e+02,
content:'Saddle = 316.700012 pos = 39.1853,140.2571 diff = 396.299988'
});
data_peak.push({
lat: 3.9288333334e+01,
lng: 1.4085577778e+02,
cert : false,
content:' Peak = 515.900024 pos = 39.2883,140.8558 diff = 188.700012'
});
data_saddle.push({
lat: 3.9281555556e+01,
lng: 1.4085511111e+02,
content:'Saddle = 327.200012 pos = 39.2816,140.8551 diff = 188.700012'
});
data_peak.push({
lat: 3.9158111112e+01,
lng: 1.4028044444e+02,
cert : true,
content:'Name = JA/AT-094(JA/AT-094) peak = 603.500000 pos = 39.1581,140.2804 diff = 274.299988'
});
data_saddle.push({
lat: 3.9135666668e+01,
lng: 1.4030000000e+02,
content:'Saddle = 329.200012 pos = 39.1357,140.3000 diff = 274.299988'
});
data_peak.push({
lat: 3.9175222223e+01,
lng: 1.4060544444e+02,
cert : true,
content:'Name = JA/AT-109(JA/AT-109) peak = 493.600006 pos = 39.1752,140.6054 diff = 162.100006'
});
data_saddle.push({
lat: 3.9160111112e+01,
lng: 1.4061444444e+02,
content:'Saddle = 331.500000 pos = 39.1601,140.6144 diff = 162.100006'
});
data_peak.push({
lat: 3.8670444445e+01,
lng: 1.4055488889e+02,
cert : false,
content:' Peak = 895.299988 pos = 38.6704,140.5549 diff = 557.299988'
});
data_saddle.push({
lat: 3.8736222223e+01,
lng: 1.4060988889e+02,
content:'Saddle = 338.000000 pos = 38.7362,140.6099 diff = 557.299988'
});
data_peak.push({
lat: 3.8699777779e+01,
lng: 1.4062355556e+02,
cert : true,
content:'Name = JA/MG-023(JA/MG-023) peak = 861.099976 pos = 38.6998,140.6236 diff = 482.199982'
});
data_saddle.push({
lat: 3.8666777779e+01,
lng: 1.4058866667e+02,
content:'Saddle = 378.899994 pos = 38.6668,140.5887 diff = 482.199982'
});
data_peak.push({
lat: 3.8666888890e+01,
lng: 1.4063722222e+02,
cert : false,
content:' Peak = 690.000000 pos = 38.6669,140.6372 diff = 172.799988'
});
data_saddle.push({
lat: 3.8666777779e+01,
lng: 1.4062988889e+02,
content:'Saddle = 517.200012 pos = 38.6668,140.6299 diff = 172.799988'
});
data_peak.push({
lat: 3.8667222223e+01,
lng: 1.4062144444e+02,
cert : false,
content:' Peak = 691.000000 pos = 38.6672,140.6214 diff = 173.400024'
});
data_saddle.push({
lat: 3.8666777779e+01,
lng: 1.4061533333e+02,
content:'Saddle = 517.599976 pos = 38.6668,140.6153 diff = 173.400024'
});
data_peak.push({
lat: 3.8721333334e+01,
lng: 1.4045988889e+02,
cert : false,
content:' Peak = 820.900024 pos = 38.7213,140.4599 diff = 349.600037'
});
data_saddle.push({
lat: 3.8691555557e+01,
lng: 1.4051977778e+02,
content:'Saddle = 471.299988 pos = 38.6916,140.5198 diff = 349.600037'
});
data_peak.push({
lat: 3.8679222223e+01,
lng: 1.4044422222e+02,
cert : true,
content:'Name = JA/YM-088(JA/YM-088) peak = 641.700012 pos = 38.6792,140.4442 diff = 161.100006'
});
data_saddle.push({
lat: 3.8690444445e+01,
lng: 1.4045055556e+02,
content:'Saddle = 480.600006 pos = 38.6904,140.4506 diff = 161.100006'
});
data_peak.push({
lat: 3.8691666668e+01,
lng: 1.4049088889e+02,
cert : true,
content:'Name = JA/YM-070(JA/YM-070) peak = 763.799988 pos = 38.6917,140.4909 diff = 217.599976'
});
data_saddle.push({
lat: 3.8701333334e+01,
lng: 1.4047177778e+02,
content:'Saddle = 546.200012 pos = 38.7013,140.4718 diff = 217.599976'
});
data_peak.push({
lat: 3.8741333334e+01,
lng: 1.4043555556e+02,
cert : false,
content:' Peak = 820.200012 pos = 38.7413,140.4356 diff = 198.000000'
});
data_saddle.push({
lat: 3.8731111112e+01,
lng: 1.4045155556e+02,
content:'Saddle = 622.200012 pos = 38.7311,140.4516 diff = 198.000000'
});
data_peak.push({
lat: 3.8827222223e+01,
lng: 1.4087022222e+02,
cert : true,
content:'Name = JA/MG-039(JA/MG-039) peak = 580.099976 pos = 38.8272,140.8702 diff = 218.599976'
});
data_saddle.push({
lat: 3.8832777779e+01,
lng: 1.4086066667e+02,
content:'Saddle = 361.500000 pos = 38.8328,140.8607 diff = 218.599976'
});
data_peak.push({
lat: 3.8951222223e+01,
lng: 1.4030011111e+02,
cert : false,
content:' Peak = 530.700012 pos = 38.9512,140.3001 diff = 157.300018'
});
data_saddle.push({
lat: 3.8954555556e+01,
lng: 1.4030655556e+02,
content:'Saddle = 373.399994 pos = 38.9546,140.3066 diff = 157.300018'
});
data_peak.push({
lat: 3.8978333334e+01,
lng: 1.4017711111e+02,
cert : true,
content:'Name = JA/YM-097(JA/YM-097) peak = 550.900024 pos = 38.9783,140.1771 diff = 173.400024'
});
data_saddle.push({
lat: 3.8986111112e+01,
lng: 1.4020433333e+02,
content:'Saddle = 377.500000 pos = 38.9861,140.2043 diff = 173.400024'
});
data_peak.push({
lat: 3.8923000001e+01,
lng: 1.4037033333e+02,
cert : false,
content:' Peak = 551.000000 pos = 38.9230,140.3703 diff = 159.600006'
});
data_saddle.push({
lat: 3.8927222223e+01,
lng: 1.4038411111e+02,
content:'Saddle = 391.399994 pos = 38.9272,140.3841 diff = 159.600006'
});
data_peak.push({
lat: 3.9099666668e+01,
lng: 1.4043288889e+02,
cert : false,
content:' Peak = 633.799988 pos = 39.0997,140.4329 diff = 235.399994'
});
data_saddle.push({
lat: 3.9111777779e+01,
lng: 1.4040922222e+02,
content:'Saddle = 398.399994 pos = 39.1118,140.4092 diff = 235.399994'
});
data_peak.push({
lat: 3.8949555556e+01,
lng: 1.4031177778e+02,
cert : false,
content:' Peak = 573.200012 pos = 38.9496,140.3118 diff = 172.000000'
});
data_saddle.push({
lat: 3.8955777779e+01,
lng: 1.4031944444e+02,
content:'Saddle = 401.200012 pos = 38.9558,140.3194 diff = 172.000000'
});
data_peak.push({
lat: 3.8945222223e+01,
lng: 1.4036333333e+02,
cert : false,
content:' Peak = 560.400024 pos = 38.9452,140.3633 diff = 158.100037'
});
data_saddle.push({
lat: 3.8948222223e+01,
lng: 1.4036966667e+02,
content:'Saddle = 402.299988 pos = 38.9482,140.3697 diff = 158.100037'
});
data_peak.push({
lat: 3.9288555556e+01,
lng: 1.4093622222e+02,
cert : true,
content:'Name = JA/IT-144(JA/IT-144) peak = 599.299988 pos = 39.2886,140.9362 diff = 191.199982'
});
data_saddle.push({
lat: 3.9283111112e+01,
lng: 1.4093366667e+02,
content:'Saddle = 408.100006 pos = 39.2831,140.9337 diff = 191.199982'
});
data_peak.push({
lat: 3.8921222223e+01,
lng: 1.4012400000e+02,
cert : true,
content:'Name = JA/YM-055(JA/YM-055) peak = 884.400024 pos = 38.9212,140.1240 diff = 473.400024'
});
data_saddle.push({
lat: 3.8977666668e+01,
lng: 1.4014322222e+02,
content:'Saddle = 411.000000 pos = 38.9777,140.1432 diff = 473.400024'
});
data_peak.push({
lat: 3.8792888890e+01,
lng: 1.4006933333e+02,
cert : true,
content:'Name = JA/YM-083(JA/YM-083) peak = 661.000000 pos = 38.7929,140.0693 diff = 197.000000'
});
data_saddle.push({
lat: 3.8801888890e+01,
lng: 1.4008511111e+02,
content:'Saddle = 464.000000 pos = 38.8019,140.0851 diff = 197.000000'
});
data_peak.push({
lat: 3.8814555557e+01,
lng: 1.4007933333e+02,
cert : true,
content:'Name = JA/YM-069(JA/YM-069) peak = 781.099976 pos = 38.8146,140.0793 diff = 310.499969'
});
data_saddle.push({
lat: 3.8909000001e+01,
lng: 1.4013622222e+02,
content:'Saddle = 470.600006 pos = 38.9090,140.1362 diff = 310.499969'
});
data_peak.push({
lat: 3.8866666668e+01,
lng: 1.4010411111e+02,
cert : false,
content:' Peak = 733.700012 pos = 38.8667,140.1041 diff = 181.100037'
});
data_saddle.push({
lat: 3.8821555557e+01,
lng: 1.4011744444e+02,
content:'Saddle = 552.599976 pos = 38.8216,140.1174 diff = 181.100037'
});
data_peak.push({
lat: 3.8883000001e+01,
lng: 1.4006211111e+02,
cert : false,
content:' Peak = 733.400024 pos = 38.8830,140.0621 diff = 162.100037'
});
data_saddle.push({
lat: 3.8870111112e+01,
lng: 1.4008666667e+02,
content:'Saddle = 571.299988 pos = 38.8701,140.0867 diff = 162.100037'
});
data_peak.push({
lat: 3.8955555556e+01,
lng: 1.4009244444e+02,
cert : false,
content:' Peak = 672.299988 pos = 38.9556,140.0924 diff = 159.000000'
});
data_saddle.push({
lat: 3.8957333334e+01,
lng: 1.4010422222e+02,
content:'Saddle = 513.299988 pos = 38.9573,140.1042 diff = 159.000000'
});
data_peak.push({
lat: 3.9130777779e+01,
lng: 1.4022800000e+02,
cert : false,
content:' Peak = 571.799988 pos = 39.1308,140.2280 diff = 153.799988'
});
data_saddle.push({
lat: 3.9119444445e+01,
lng: 1.4024177778e+02,
content:'Saddle = 418.000000 pos = 39.1194,140.2418 diff = 153.799988'
});
data_peak.push({
lat: 3.9275111112e+01,
lng: 1.4092977778e+02,
cert : true,
content:'Name = JA/IT-143(JA/IT-143) peak = 602.500000 pos = 39.2751,140.9298 diff = 184.399994'
});
data_saddle.push({
lat: 3.9271222223e+01,
lng: 1.4091633333e+02,
content:'Saddle = 418.100006 pos = 39.2712,140.9163 diff = 184.399994'
});
data_peak.push({
lat: 3.8954333334e+01,
lng: 1.4034377778e+02,
cert : true,
content:'Name = JA/YM-086(JA/YM-086) peak = 646.500000 pos = 38.9543,140.3438 diff = 228.399994'
});
data_saddle.push({
lat: 3.8963555556e+01,
lng: 1.4035622222e+02,
content:'Saddle = 418.100006 pos = 38.9636,140.3562 diff = 228.399994'
});
data_peak.push({
lat: 3.9066555556e+01,
lng: 1.4055866667e+02,
cert : true,
content:'Name = JA/AT-078(JA/AT-078) peak = 697.900024 pos = 39.0666,140.5587 diff = 278.800018'
});
data_saddle.push({
lat: 3.9053222223e+01,
lng: 1.4057733333e+02,
content:'Saddle = 419.100006 pos = 39.0532,140.5773 diff = 278.800018'
});
data_peak.push({
lat: 3.8961000001e+01,
lng: 1.4078833333e+02,
cert : true,
content:'Name = Kurikomayama(JA/MG-002) peak = 1627.099976 pos = 38.9610,140.7883 diff = 1197.699951'
});
data_saddle.push({
lat: 3.9005111112e+01,
lng: 1.4036844444e+02,
content:'Saddle = 429.399994 pos = 39.0051,140.3684 diff = 1197.699951'
});
data_peak.push({
lat: 3.9233444445e+01,
lng: 1.4067344444e+02,
cert : false,
content:' Peak = 680.799988 pos = 39.2334,140.6734 diff = 232.000000'
});
data_saddle.push({
lat: 3.9227666667e+01,
lng: 1.4066900000e+02,
content:'Saddle = 448.799988 pos = 39.2277,140.6690 diff = 232.000000'
});
data_peak.push({
lat: 3.8744444445e+01,
lng: 1.4057011111e+02,
cert : false,
content:' Peak = 620.799988 pos = 38.7444,140.5701 diff = 168.199982'
});
data_saddle.push({
lat: 3.8752666668e+01,
lng: 1.4057622222e+02,
content:'Saddle = 452.600006 pos = 38.7527,140.5762 diff = 168.199982'
});
data_peak.push({
lat: 3.9097111112e+01,
lng: 1.4090444444e+02,
cert : true,
content:'Name = JA/IT-128(JA/IT-128) peak = 683.099976 pos = 39.0971,140.9044 diff = 211.899963'
});
data_saddle.push({
lat: 3.9084333334e+01,
lng: 1.4090211111e+02,
content:'Saddle = 471.200012 pos = 39.0843,140.9021 diff = 211.899963'
});
data_peak.push({
lat: 3.9102000001e+01,
lng: 1.4060444444e+02,
cert : true,
content:'Name = JA/AT-076(JA/AT-076) peak = 703.000000 pos = 39.1020,140.6044 diff = 231.600006'
});
data_saddle.push({
lat: 3.9107000001e+01,
lng: 1.4064022222e+02,
content:'Saddle = 471.399994 pos = 39.1070,140.6402 diff = 231.600006'
});
data_peak.push({
lat: 3.9126111112e+01,
lng: 1.4062366667e+02,
cert : false,
content:' Peak = 640.599976 pos = 39.1261,140.6237 diff = 152.299988'
});
data_saddle.push({
lat: 3.9121888890e+01,
lng: 1.4061577778e+02,
content:'Saddle = 488.299988 pos = 39.1219,140.6158 diff = 152.299988'
});
data_peak.push({
lat: 3.9209111112e+01,
lng: 1.4066566667e+02,
cert : true,
content:'Name = JA/AT-058(JA/AT-058) peak = 780.500000 pos = 39.2091,140.6657 diff = 292.899994'
});
data_saddle.push({
lat: 3.9188444445e+01,
lng: 1.4069477778e+02,
content:'Saddle = 487.600006 pos = 39.1884,140.6948 diff = 292.899994'
});
data_peak.push({
lat: 3.9037111112e+01,
lng: 1.4059155556e+02,
cert : true,
content:'Name = JA/AT-065(JA/AT-065) peak = 760.299988 pos = 39.0371,140.5916 diff = 258.399994'
});
data_saddle.push({
lat: 3.9023000001e+01,
lng: 1.4061588889e+02,
content:'Saddle = 501.899994 pos = 39.0230,140.6159 diff = 258.399994'
});
data_peak.push({
lat: 3.9061333334e+01,
lng: 1.4090466667e+02,
cert : true,
content:'Name = JA/IT-065(JA/IT-065) peak = 926.200012 pos = 39.0613,140.9047 diff = 414.100037'
});
data_saddle.push({
lat: 3.9038666668e+01,
lng: 1.4085588889e+02,
content:'Saddle = 512.099976 pos = 39.0387,140.8559 diff = 414.100037'
});
data_peak.push({
lat: 3.9048666668e+01,
lng: 1.4094977778e+02,
cert : true,
content:'Name = JA/IT-096(JA/IT-096) peak = 787.000000 pos = 39.0487,140.9498 diff = 196.900024'
});
data_saddle.push({
lat: 3.9050888890e+01,
lng: 1.4093000000e+02,
content:'Saddle = 590.099976 pos = 39.0509,140.9300 diff = 196.900024'
});
data_peak.push({
lat: 3.9047222223e+01,
lng: 1.4086000000e+02,
cert : false,
content:' Peak = 762.299988 pos = 39.0472,140.8600 diff = 154.200012'
});
data_saddle.push({
lat: 3.9044000001e+01,
lng: 1.4086966667e+02,
content:'Saddle = 608.099976 pos = 39.0440,140.8697 diff = 154.200012'
});
data_peak.push({
lat: 3.9029444445e+01,
lng: 1.4089811111e+02,
cert : true,
content:'Name = JA/IT-086(JA/IT-086) peak = 861.700012 pos = 39.0294,140.8981 diff = 235.200012'
});
data_saddle.push({
lat: 3.9043333334e+01,
lng: 1.4090111111e+02,
content:'Saddle = 626.500000 pos = 39.0433,140.9011 diff = 235.200012'
});
data_peak.push({
lat: 3.8849888890e+01,
lng: 1.4079277778e+02,
cert : false,
content:' Peak = 671.900024 pos = 38.8499,140.7928 diff = 151.300049'
});
data_saddle.push({
lat: 3.8855777779e+01,
lng: 1.4080877778e+02,
content:'Saddle = 520.599976 pos = 38.8558,140.8088 diff = 151.300049'
});
data_peak.push({
lat: 3.8843777779e+01,
lng: 1.4068733333e+02,
cert : true,
content:'Name = JA/MG-018(JA/MG-018) peak = 988.200012 pos = 38.8438,140.6873 diff = 450.000000'
});
data_saddle.push({
lat: 3.8821222223e+01,
lng: 1.4074288889e+02,
content:'Saddle = 538.200012 pos = 38.8212,140.7429 diff = 450.000000'
});
data_peak.push({
lat: 3.8994555556e+01,
lng: 1.4037611111e+02,
cert : false,
content:' Peak = 750.599976 pos = 38.9946,140.3761 diff = 207.799988'
});
data_saddle.push({
lat: 3.8994111112e+01,
lng: 1.4038455556e+02,
content:'Saddle = 542.799988 pos = 38.9941,140.3846 diff = 207.799988'
});
data_peak.push({
lat: 3.8834444445e+01,
lng: 1.4076388889e+02,
cert : true,
content:'Name = JA/MG-028(JA/MG-028) peak = 792.299988 pos = 38.8344,140.7639 diff = 206.099976'
});
data_saddle.push({
lat: 3.8874222223e+01,
lng: 1.4074655556e+02,
content:'Saddle = 586.200012 pos = 38.8742,140.7466 diff = 206.099976'
});
data_peak.push({
lat: 3.8858333334e+01,
lng: 1.4073211111e+02,
cert : true,
content:'Name = JA/MG-030(JA/MG-030) peak = 773.299988 pos = 38.8583,140.7321 diff = 185.399963'
});
data_saddle.push({
lat: 3.8840666668e+01,
lng: 1.4074744444e+02,
content:'Saddle = 587.900024 pos = 38.8407,140.7474 diff = 185.399963'
});
data_peak.push({
lat: 3.8847222223e+01,
lng: 1.4073366667e+02,
cert : true,
content:'Name = JA/MG-031(JA/MG-031) peak = 770.400024 pos = 38.8472,140.7337 diff = 168.200012'
});
data_saddle.push({
lat: 3.8863888890e+01,
lng: 1.4074877778e+02,
content:'Saddle = 602.200012 pos = 38.8639,140.7488 diff = 168.200012'
});
data_peak.push({
lat: 3.8851333334e+01,
lng: 1.4074900000e+02,
cert : false,
content:' Peak = 761.299988 pos = 38.8513,140.7490 diff = 154.399963'
});
data_saddle.push({
lat: 3.8846111112e+01,
lng: 1.4074055556e+02,
content:'Saddle = 606.900024 pos = 38.8461,140.7406 diff = 154.399963'
});
data_peak.push({
lat: 3.9140555556e+01,
lng: 1.4068722222e+02,
cert : true,
content:'Name = JA/AT-062(JA/AT-062) peak = 766.000000 pos = 39.1406,140.6872 diff = 168.700012'
});
data_saddle.push({
lat: 3.9120777779e+01,
lng: 1.4068477778e+02,
content:'Saddle = 597.299988 pos = 39.1208,140.6848 diff = 168.700012'
});
data_peak.push({
lat: 3.9003777779e+01,
lng: 1.4040544444e+02,
cert : true,
content:'Name = JA/AT-041(JA/AT-041) peak = 953.099976 pos = 39.0038,140.4054 diff = 290.699951'
});
data_saddle.push({
lat: 3.8991777779e+01,
lng: 1.4041866667e+02,
content:'Saddle = 662.400024 pos = 38.9918,140.4187 diff = 290.699951'
});
data_peak.push({
lat: 3.9247444445e+01,
lng: 1.4091500000e+02,
cert : false,
content:' Peak = 913.099976 pos = 39.2474,140.9150 diff = 243.599976'
});
data_saddle.push({
lat: 3.9246555556e+01,
lng: 1.4090700000e+02,
content:'Saddle = 669.500000 pos = 39.2466,140.9070 diff = 243.599976'
});
data_peak.push({
lat: 3.9250333334e+01,
lng: 1.4093166667e+02,
cert : true,
content:'Name = JA/IT-070(JA/IT-070) peak = 910.599976 pos = 39.2503,140.9317 diff = 168.799988'
});
data_saddle.push({
lat: 3.9248333334e+01,
lng: 1.4092155556e+02,
content:'Saddle = 741.799988 pos = 39.2483,140.9216 diff = 168.799988'
});
data_peak.push({
lat: 3.8899000001e+01,
lng: 1.4080466667e+02,
cert : false,
content:' Peak = 866.900024 pos = 38.8990,140.8047 diff = 196.100037'
});
data_saddle.push({
lat: 3.8909333334e+01,
lng: 1.4080900000e+02,
content:'Saddle = 670.799988 pos = 38.9093,140.8090 diff = 196.100037'
});
data_peak.push({
lat: 3.9260222223e+01,
lng: 1.4082366667e+02,
cert : false,
content:' Peak = 842.900024 pos = 39.2602,140.8237 diff = 171.700012'
});
data_saddle.push({
lat: 3.9250111112e+01,
lng: 1.4081855556e+02,
content:'Saddle = 671.200012 pos = 39.2501,140.8186 diff = 171.700012'
});
data_peak.push({
lat: 3.8889555556e+01,
lng: 1.4069811111e+02,
cert : true,
content:'Name = JA/MG-019(JA/MG-019) peak = 950.500000 pos = 38.8896,140.6981 diff = 259.500000'
});
data_saddle.push({
lat: 3.8895444445e+01,
lng: 1.4069422222e+02,
content:'Saddle = 691.000000 pos = 38.8954,140.6942 diff = 259.500000'
});
data_peak.push({
lat: 3.9026555556e+01,
lng: 1.4070355556e+02,
cert : true,
content:'Name = JA/AT-024(JA/AT-024) peak = 1083.000000 pos = 39.0266,140.7036 diff = 390.200012'
});
data_saddle.push({
lat: 3.9003888890e+01,
lng: 1.4071777778e+02,
content:'Saddle = 692.799988 pos = 39.0039,140.7178 diff = 390.200012'
});
data_peak.push({
lat: 3.9020333334e+01,
lng: 1.4084300000e+02,
cert : true,
content:'Name = JA/IT-052(JA/IT-052) peak = 989.000000 pos = 39.0203,140.8430 diff = 286.000000'
});
data_saddle.push({
lat: 3.9019777779e+01,
lng: 1.4082077778e+02,
content:'Saddle = 703.000000 pos = 39.0198,140.8208 diff = 286.000000'
});
data_peak.push({
lat: 3.8904444445e+01,
lng: 1.4061866667e+02,
cert : false,
content:' Peak = 1435.800049 pos = 38.9044,140.6187 diff = 703.800049'
});
data_saddle.push({
lat: 3.8918777779e+01,
lng: 1.4069100000e+02,
content:'Saddle = 732.000000 pos = 38.9188,140.6910 diff = 703.800049'
});
data_peak.push({
lat: 3.9020888890e+01,
lng: 1.4052055556e+02,
cert : true,
content:'Name = JA/AT-036(JA/AT-036) peak = 1001.900024 pos = 39.0209,140.5206 diff = 259.300049'
});
data_saddle.push({
lat: 3.9010111112e+01,
lng: 1.4053100000e+02,
content:'Saddle = 742.599976 pos = 39.0101,140.5310 diff = 259.300049'
});
data_peak.push({
lat: 3.8819555557e+01,
lng: 1.4049422222e+02,
cert : false,
content:' Peak = 930.799988 pos = 38.8196,140.4942 diff = 183.399963'
});
data_saddle.push({
lat: 3.8829555557e+01,
lng: 1.4048211111e+02,
content:'Saddle = 747.400024 pos = 38.8296,140.4821 diff = 183.399963'
});
data_peak.push({
lat: 3.8767000001e+01,
lng: 1.4064933333e+02,
cert : true,
content:'Name = JA/MG-014(JA/MG-014) peak = 1104.300049 pos = 38.7670,140.6493 diff = 308.400024'
});
data_saddle.push({
lat: 3.8790777779e+01,
lng: 1.4060088889e+02,
content:'Saddle = 795.900024 pos = 38.7908,140.6009 diff = 308.400024'
});
data_peak.push({
lat: 3.8775000001e+01,
lng: 1.4062466667e+02,
cert : true,
content:'Name = JA/YM-029(JA/YM-029) peak = 1054.199951 pos = 38.7750,140.6247 diff = 239.499939'
});
data_saddle.push({
lat: 3.8777444445e+01,
lng: 1.4063677778e+02,
content:'Saddle = 814.700012 pos = 38.7774,140.6368 diff = 239.499939'
});
data_peak.push({
lat: 3.8789666668e+01,
lng: 1.4040122222e+02,
cert : false,
content:' Peak = 1021.700012 pos = 38.7897,140.4012 diff = 209.900024'
});
data_saddle.push({
lat: 3.8800333334e+01,
lng: 1.4040333333e+02,
content:'Saddle = 811.799988 pos = 38.8003,140.4033 diff = 209.900024'
});
data_peak.push({
lat: 3.8902333334e+01,
lng: 1.4049222222e+02,
cert : true,
content:'Name = Kamurosan(JA/AT-006) peak = 1363.000000 pos = 38.9023,140.4922 diff = 545.700012'
});
data_saddle.push({
lat: 3.8878222223e+01,
lng: 1.4057411111e+02,
content:'Saddle = 817.299988 pos = 38.8782,140.5741 diff = 545.700012'
});
data_peak.push({
lat: 3.8811000001e+01,
lng: 1.4059500000e+02,
cert : true,
content:'Name = Kamurodake (Kokaburayama)(JA/MG-010) peak = 1261.500000 pos = 38.8110,140.5950 diff = 372.099976'
});
data_saddle.push({
lat: 3.8877333334e+01,
lng: 1.4054377778e+02,
content:'Saddle = 889.400024 pos = 38.8773,140.5438 diff = 372.099976'
});
data_peak.push({
lat: 3.8860222223e+01,
lng: 1.4054944444e+02,
cert : true,
content:'Name = JA/YM-021(JA/YM-021) peak = 1117.099976 pos = 38.8602,140.5494 diff = 224.599976'
});
data_saddle.push({
lat: 3.8840555557e+01,
lng: 1.4058177778e+02,
content:'Saddle = 892.500000 pos = 38.8406,140.5818 diff = 224.599976'
});
data_peak.push({
lat: 3.8801666668e+01,
lng: 1.4041855556e+02,
cert : true,
content:'Name = JA/YM-025(JA/YM-025) peak = 1097.699951 pos = 38.8017,140.4186 diff = 157.699951'
});
data_saddle.push({
lat: 3.8815000001e+01,
lng: 1.4042644444e+02,
content:'Saddle = 940.000000 pos = 38.8150,140.4264 diff = 157.699951'
});
data_peak.push({
lat: 3.8892777779e+01,
lng: 1.4054511111e+02,
cert : false,
content:' Peak = 1192.699951 pos = 38.8928,140.5451 diff = 242.399963'
});
data_saddle.push({
lat: 3.8899666668e+01,
lng: 1.4051366667e+02,
content:'Saddle = 950.299988 pos = 38.8997,140.5137 diff = 242.399963'
});
data_peak.push({
lat: 3.8840222223e+01,
lng: 1.4044844444e+02,
cert : false,
content:' Peak = 1232.599976 pos = 38.8402,140.4484 diff = 231.299988'
});
data_saddle.push({
lat: 3.8845666668e+01,
lng: 1.4045977778e+02,
content:'Saddle = 1001.299988 pos = 38.8457,140.4598 diff = 231.299988'
});
data_peak.push({
lat: 3.8862888890e+01,
lng: 1.4048555556e+02,
cert : false,
content:' Peak = 1361.900024 pos = 38.8629,140.4856 diff = 241.200073'
});
data_saddle.push({
lat: 3.8886444445e+01,
lng: 1.4048722222e+02,
content:'Saddle = 1120.699951 pos = 38.8864,140.4872 diff = 241.200073'
});
data_peak.push({
lat: 3.8866333334e+01,
lng: 1.4060488889e+02,
cert : true,
content:'Name = JA/MG-017(JA/MG-017) peak = 1043.099976 pos = 38.8663,140.6049 diff = 214.399963'
});
data_saddle.push({
lat: 3.8870333334e+01,
lng: 1.4059455556e+02,
content:'Saddle = 828.700012 pos = 38.8703,140.5946 diff = 214.399963'
});
data_peak.push({
lat: 3.8967777779e+01,
lng: 1.4060622222e+02,
cert : true,
content:'Name = Takamatsudake(JA/AT-007) peak = 1347.500000 pos = 38.9678,140.6062 diff = 460.200012'
});
data_saddle.push({
lat: 3.8933555556e+01,
lng: 1.4060011111e+02,
content:'Saddle = 887.299988 pos = 38.9336,140.6001 diff = 460.200012'
});
data_peak.push({
lat: 3.8964777779e+01,
lng: 1.4065011111e+02,
cert : false,
content:' Peak = 1221.199951 pos = 38.9648,140.6501 diff = 190.699951'
});
data_saddle.push({
lat: 3.8964222223e+01,
lng: 1.4063877778e+02,
content:'Saddle = 1030.500000 pos = 38.9642,140.6388 diff = 190.699951'
});
data_peak.push({
lat: 3.8922111112e+01,
lng: 1.4061877778e+02,
cert : false,
content:' Peak = 1186.699951 pos = 38.9221,140.6188 diff = 253.599976'
});
data_saddle.push({
lat: 3.8912444445e+01,
lng: 1.4062555556e+02,
content:'Saddle = 933.099976 pos = 38.9124,140.6256 diff = 253.599976'
});
data_peak.push({
lat: 3.8933111112e+01,
lng: 1.4070288889e+02,
cert : false,
content:' Peak = 953.299988 pos = 38.9331,140.7029 diff = 212.700012'
});
data_saddle.push({
lat: 3.8934000001e+01,
lng: 1.4072344444e+02,
content:'Saddle = 740.599976 pos = 38.9340,140.7234 diff = 212.700012'
});
data_peak.push({
lat: 3.9235888890e+01,
lng: 1.4085122222e+02,
cert : false,
content:' Peak = 941.099976 pos = 39.2359,140.8512 diff = 182.699951'
});
data_saddle.push({
lat: 3.9232777779e+01,
lng: 1.4085288889e+02,
content:'Saddle = 758.400024 pos = 39.2328,140.8529 diff = 182.699951'
});
data_peak.push({
lat: 3.9020555556e+01,
lng: 1.4074011111e+02,
cert : true,
content:'Name = JA/AT-034(JA/AT-034) peak = 1014.700012 pos = 39.0206,140.7401 diff = 219.799988'
});
data_saddle.push({
lat: 3.9012555556e+01,
lng: 1.4074300000e+02,
content:'Saddle = 794.900024 pos = 39.0126,140.7430 diff = 219.799988'
});
data_peak.push({
lat: 3.9163777779e+01,
lng: 1.4082877778e+02,
cert : true,
content:'Name = Yakeishidake(JA/IT-006) peak = 1546.300049 pos = 39.1638,140.8288 diff = 723.400024'
});
data_saddle.push({
lat: 3.9117333334e+01,
lng: 1.4075588889e+02,
content:'Saddle = 822.900024 pos = 39.1173,140.7559 diff = 723.400024'
});
data_peak.push({
lat: 3.9124000001e+01,
lng: 1.4079922222e+02,
cert : false,
content:' Peak = 1091.300049 pos = 39.1240,140.7992 diff = 228.900024'
});
data_saddle.push({
lat: 3.9136777779e+01,
lng: 1.4074977778e+02,
content:'Saddle = 862.400024 pos = 39.1368,140.7498 diff = 228.900024'
});
data_peak.push({
lat: 3.9209222223e+01,
lng: 1.4076733333e+02,
cert : true,
content:'Name = JA/IT-037(JA/IT-037) peak = 1105.599976 pos = 39.2092,140.7673 diff = 227.399963'
});
data_saddle.push({
lat: 3.9200222223e+01,
lng: 1.4076644444e+02,
content:'Saddle = 878.200012 pos = 39.2002,140.7664 diff = 227.399963'
});
data_peak.push({
lat: 3.9230000001e+01,
lng: 1.4088188889e+02,
cert : false,
content:' Peak = 1097.800049 pos = 39.2300,140.8819 diff = 160.000061'
});
data_saddle.push({
lat: 3.9224666667e+01,
lng: 1.4087633333e+02,
content:'Saddle = 937.799988 pos = 39.2247,140.8763 diff = 160.000061'
});
data_peak.push({
lat: 3.9194777779e+01,
lng: 1.4077866667e+02,
cert : true,
content:'Name = JA/AT-019(JA/AT-019) peak = 1161.599976 pos = 39.1948,140.7787 diff = 159.899963'
});
data_saddle.push({
lat: 3.9188666667e+01,
lng: 1.4078922222e+02,
content:'Saddle = 1001.700012 pos = 39.1887,140.7892 diff = 159.899963'
});
data_peak.push({
lat: 3.9181000001e+01,
lng: 1.4088877778e+02,
cert : true,
content:'Name = JA/IT-009(JA/IT-009) peak = 1370.900024 pos = 39.1810,140.8888 diff = 198.000000'
});
data_saddle.push({
lat: 3.9177555556e+01,
lng: 1.4088111111e+02,
content:'Saddle = 1172.900024 pos = 39.1776,140.8811 diff = 198.000000'
});
data_peak.push({
lat: 3.9201777779e+01,
lng: 1.4086022222e+02,
cert : false,
content:' Peak = 1338.900024 pos = 39.2018,140.8602 diff = 150.900024'
});
data_saddle.push({
lat: 3.9189111112e+01,
lng: 1.4085533333e+02,
content:'Saddle = 1188.000000 pos = 39.1891,140.8553 diff = 150.900024'
});
data_peak.push({
lat: 3.9085555556e+01,
lng: 1.4075855556e+02,
cert : false,
content:' Peak = 1122.800049 pos = 39.0856,140.7586 diff = 240.600037'
});
data_saddle.push({
lat: 3.9082111112e+01,
lng: 1.4077866667e+02,
content:'Saddle = 882.200012 pos = 39.0821,140.7787 diff = 240.600037'
});
data_peak.push({
lat: 3.9038777779e+01,
lng: 1.4077800000e+02,
cert : true,
content:'Name = JA/AT-017(JA/AT-017) peak = 1164.099976 pos = 39.0388,140.7780 diff = 243.899963'
});
data_saddle.push({
lat: 3.9035888890e+01,
lng: 1.4079600000e+02,
content:'Saddle = 920.200012 pos = 39.0359,140.7960 diff = 243.899963'
});
data_peak.push({
lat: 3.9021666668e+01,
lng: 1.4078555556e+02,
cert : true,
content:'Name = JA/IT-030(JA/IT-030) peak = 1164.099976 pos = 39.0217,140.7856 diff = 196.199951'
});
data_saddle.push({
lat: 3.8994666668e+01,
lng: 1.4076688889e+02,
content:'Saddle = 967.900024 pos = 38.9947,140.7669 diff = 196.199951'
});
data_peak.push({
lat: 3.9127555556e+01,
lng: 1.4017388889e+02,
cert : true,
content:'Name = JA/AT-091(JA/AT-091) peak = 618.299988 pos = 39.1276,140.1739 diff = 180.399994'
});
data_saddle.push({
lat: 3.9123444445e+01,
lng: 1.4020011111e+02,
content:'Saddle = 437.899994 pos = 39.1234,140.2001 diff = 180.399994'
});
data_peak.push({
lat: 3.9025888890e+01,
lng: 1.4036233333e+02,
cert : true,
content:'Name = JA/AT-079(JA/AT-079) peak = 696.099976 pos = 39.0259,140.3623 diff = 182.699951'
});
data_saddle.push({
lat: 3.9026333334e+01,
lng: 1.4034322222e+02,
content:'Saddle = 513.400024 pos = 39.0263,140.3432 diff = 182.699951'
});
data_peak.push({
lat: 3.8987888890e+01,
lng: 1.4008422222e+02,
cert : true,
content:'Name = JA/YM-068(JA/YM-068) peak = 780.299988 pos = 38.9879,140.0842 diff = 207.099976'
});
data_saddle.push({
lat: 3.9000111112e+01,
lng: 1.4011800000e+02,
content:'Saddle = 573.200012 pos = 39.0001,140.1180 diff = 207.099976'
});
data_peak.push({
lat: 3.8983888890e+01,
lng: 1.4024977778e+02,
cert : false,
content:' Peak = 783.799988 pos = 38.9839,140.2498 diff = 171.099976'
});
data_saddle.push({
lat: 3.8985444445e+01,
lng: 1.4025488889e+02,
content:'Saddle = 612.700012 pos = 38.9854,140.2549 diff = 171.099976'
});
data_peak.push({
lat: 3.9006888890e+01,
lng: 1.4033211111e+02,
cert : false,
content:' Peak = 783.599976 pos = 39.0069,140.3321 diff = 160.699951'
});
data_saddle.push({
lat: 3.9008888890e+01,
lng: 1.4032500000e+02,
content:'Saddle = 622.900024 pos = 39.0089,140.3250 diff = 160.699951'
});
data_peak.push({
lat: 3.9083888890e+01,
lng: 1.4034177778e+02,
cert : true,
content:'Name = JA/AT-043(JA/AT-043) peak = 925.900024 pos = 39.0839,140.3418 diff = 297.500000'
});
data_saddle.push({
lat: 3.9065222223e+01,
lng: 1.4033488889e+02,
content:'Saddle = 628.400024 pos = 39.0652,140.3349 diff = 297.500000'
});
data_peak.push({
lat: 3.9014777779e+01,
lng: 1.4011288889e+02,
cert : true,
content:'Name = JA/YM-058(JA/YM-058) peak = 864.200012 pos = 39.0148,140.1129 diff = 211.900024'
});
data_saddle.push({
lat: 3.9024333334e+01,
lng: 1.4011833333e+02,
content:'Saddle = 652.299988 pos = 39.0243,140.1183 diff = 211.900024'
});
data_peak.push({
lat: 3.9045666668e+01,
lng: 1.4034266667e+02,
cert : true,
content:'Name = JA/AT-044(JA/AT-044) peak = 920.400024 pos = 39.0457,140.3427 diff = 258.400024'
});
data_saddle.push({
lat: 3.9032333334e+01,
lng: 1.4032133333e+02,
content:'Saddle = 662.000000 pos = 39.0323,140.3213 diff = 258.400024'
});
data_peak.push({
lat: 3.9032111112e+01,
lng: 1.4021922222e+02,
cert : true,
content:'Name = Hinotodake(JA/YM-019) peak = 1145.099976 pos = 39.0321,140.2192 diff = 462.000000'
});
data_saddle.push({
lat: 3.9043777779e+01,
lng: 1.4020255556e+02,
content:'Saddle = 683.099976 pos = 39.0438,140.2026 diff = 462.000000'
});
data_peak.push({
lat: 3.9012111112e+01,
lng: 1.4031044444e+02,
cert : true,
content:'Name = Koshikiyama (Otokokoshikiyama)(JA/YM-047) peak = 980.500000 pos = 39.0121,140.3104 diff = 258.400024'
});
data_saddle.push({
lat: 3.9015111112e+01,
lng: 1.4030377778e+02,
content:'Saddle = 722.099976 pos = 39.0151,140.3038 diff = 258.400024'
});
data_peak.push({
lat: 3.9001222223e+01,
lng: 1.4025911111e+02,
cert : false,
content:' Peak = 922.099976 pos = 39.0012,140.2591 diff = 161.299988'
});
data_saddle.push({
lat: 3.9004666668e+01,
lng: 1.4025966667e+02,
content:'Saddle = 760.799988 pos = 39.0047,140.2597 diff = 161.299988'
});
data_peak.push({
lat: 3.9028111112e+01,
lng: 1.4028644444e+02,
cert : false,
content:' Peak = 941.900024 pos = 39.0281,140.2864 diff = 159.300049'
});
data_saddle.push({
lat: 3.9029888890e+01,
lng: 1.4027900000e+02,
content:'Saddle = 782.599976 pos = 39.0299,140.2790 diff = 159.300049'
});
data_peak.push({
lat: 3.9000000001e+01,
lng: 1.4022155556e+02,
cert : false,
content:' Peak = 963.700012 pos = 39.0000,140.2216 diff = 150.100037'
});
data_saddle.push({
lat: 3.9006777779e+01,
lng: 1.4022377778e+02,
content:'Saddle = 813.599976 pos = 39.0068,140.2238 diff = 150.100037'
});
data_peak.push({
lat: 3.9009777779e+01,
lng: 1.4025944444e+02,
cert : false,
content:' Peak = 994.200012 pos = 39.0098,140.2594 diff = 157.799988'
});
data_saddle.push({
lat: 3.9018000001e+01,
lng: 1.4026044444e+02,
content:'Saddle = 836.400024 pos = 39.0180,140.2604 diff = 157.799988'
});
data_peak.push({
lat: 3.9016666668e+01,
lng: 1.4022600000e+02,
cert : true,
content:'Name = JA/YM-030(JA/YM-030) peak = 1043.800049 pos = 39.0167,140.2260 diff = 200.500061'
});
data_saddle.push({
lat: 3.9022777779e+01,
lng: 1.4022755556e+02,
content:'Saddle = 843.299988 pos = 39.0228,140.2276 diff = 200.500061'
});
data_peak.push({
lat: 3.9030666668e+01,
lng: 1.4024411111e+02,
cert : false,
content:' Peak = 1103.699951 pos = 39.0307,140.2441 diff = 212.299927'
});
data_saddle.push({
lat: 3.9027666668e+01,
lng: 1.4023555556e+02,
content:'Saddle = 891.400024 pos = 39.0277,140.2356 diff = 212.299927'
});
data_peak.push({
lat: 3.9032777779e+01,
lng: 1.4012966667e+02,
cert : false,
content:' Peak = 933.200012 pos = 39.0328,140.1297 diff = 150.600037'
});
data_saddle.push({
lat: 3.9040777779e+01,
lng: 1.4013411111e+02,
content:'Saddle = 782.599976 pos = 39.0408,140.1341 diff = 150.600037'
});
data_peak.push({
lat: 3.9081666668e+01,
lng: 1.4019177778e+02,
cert : true,
content:'Name = JA/AT-035(JA/AT-035) peak = 1007.799988 pos = 39.0817,140.1918 diff = 209.399963'
});
data_saddle.push({
lat: 3.9062666668e+01,
lng: 1.4014077778e+02,
content:'Saddle = 798.400024 pos = 39.0627,140.1408 diff = 209.399963'
});
data_peak.push({
lat: 3.9051111112e+01,
lng: 1.4017111111e+02,
cert : true,
content:'Name = JA/YM-043(JA/YM-043) peak = 981.299988 pos = 39.0511,140.1711 diff = 180.899963'
});
data_saddle.push({
lat: 3.9074222223e+01,
lng: 1.4018833333e+02,
content:'Saddle = 800.400024 pos = 39.0742,140.1883 diff = 180.899963'
});
data_peak.push({
lat: 3.9054111112e+01,
lng: 1.4011444444e+02,
cert : true,
content:'Name = JA/YM-042(JA/YM-042) peak = 994.400024 pos = 39.0541,140.1144 diff = 193.200012'
});
data_saddle.push({
lat: 3.9079333334e+01,
lng: 1.4011133333e+02,
content:'Saddle = 801.200012 pos = 39.0793,140.1113 diff = 193.200012'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:41.3333,
       south:38.6667,
       east:142,
       west:140}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
