function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.6758555556e+01,
lng: 1.3775855556e+02,
cert : true,
content:'Name = Shiroumadake(JA/NN-007) peak = 2931.699951 pos = 36.7586,137.7586 diff = 2931.699951'
});
data_saddle.push({
lat: 3.8000000000e+01,
lng: 1.3700000000e+02,
content:'Saddle = 0.000000 pos = 38.0000,137.0000 diff = 2931.699951'
});
data_peak.push({
lat: 3.7001888889e+01,
lng: 1.3700188889e+02,
cert : false,
content:' Peak = 421.299988 pos = 37.0019,137.0019 diff = 421.299988'
});
data_saddle.push({
lat: 3.6888555556e+01,
lng: 1.3700244444e+02,
content:'Saddle = 0.000000 pos = 36.8886,137.0024 diff = 421.299988'
});
data_peak.push({
lat: 3.6937000000e+01,
lng: 1.3700066667e+02,
cert : false,
content:' Peak = 200.399994 pos = 36.9370,137.0007 diff = 155.599991'
});
data_saddle.push({
lat: 3.6939333334e+01,
lng: 1.3700044444e+02,
content:'Saddle = 44.799999 pos = 36.9393,137.0004 diff = 155.599991'
});
data_peak.push({
lat: 3.6963444445e+01,
lng: 1.3700000000e+02,
cert : false,
content:' Peak = 395.299988 pos = 36.9634,137.0000 diff = 283.699982'
});
data_saddle.push({
lat: 3.6982222223e+01,
lng: 1.3700011111e+02,
content:'Saddle = 111.599998 pos = 36.9822,137.0001 diff = 283.699982'
});
data_peak.push({
lat: 3.7428555556e+01,
lng: 1.3716255556e+02,
cert : true,
content:'Name = Houryuuzan(JA/IK-020) peak = 470.399994 pos = 37.4286,137.1626 diff = 470.399994'
});
data_saddle.push({
lat: 3.7183222223e+01,
lng: 1.3701088889e+02,
content:'Saddle = 0.000000 pos = 37.1832,137.0109 diff = 470.399994'
});
data_peak.push({
lat: 3.7395111111e+01,
lng: 1.3700000000e+02,
cert : false,
content:' Peak = 427.500000 pos = 37.3951,137.0000 diff = 289.299988'
});
data_saddle.push({
lat: 3.7304888889e+01,
lng: 1.3709755556e+02,
content:'Saddle = 138.199997 pos = 37.3049,137.0976 diff = 289.299988'
});
data_peak.push({
lat: 3.7473333334e+01,
lng: 1.3713288889e+02,
cert : true,
content:'Name = Nekogadake(JA/IK-021) peak = 412.000000 pos = 37.4733,137.1329 diff = 192.300003'
});
data_saddle.push({
lat: 3.7438888889e+01,
lng: 1.3713055556e+02,
content:'Saddle = 219.699997 pos = 37.4389,137.1306 diff = 192.300003'
});
data_peak.push({
lat: 3.7996000000e+01,
lng: 1.3824988889e+02,
cert : false,
content:' Peak = 164.500000 pos = 37.9960,138.2499 diff = 164.500000'
});
data_saddle.push({
lat: 3.7964222222e+01,
lng: 1.3825322222e+02,
content:'Saddle = 0.000000 pos = 37.9642,138.2532 diff = 164.500000'
});
data_peak.push({
lat: 3.7961111111e+01,
lng: 1.3848811111e+02,
cert : false,
content:' Peak = 643.900024 pos = 37.9611,138.4881 diff = 643.900024'
});
data_saddle.push({
lat: 3.7802444445e+01,
lng: 1.3824500000e+02,
content:'Saddle = 0.000000 pos = 37.8024,138.2450 diff = 643.900024'
});
data_peak.push({
lat: 3.7932777778e+01,
lng: 1.3839855556e+02,
cert : true,
content:'Name = JA/NI-097(JA/NI-097) peak = 634.599976 pos = 37.9328,138.3986 diff = 241.499969'
});
data_saddle.push({
lat: 3.7937111111e+01,
lng: 1.3845833333e+02,
content:'Saddle = 393.100006 pos = 37.9371,138.4583 diff = 241.499969'
});
data_peak.push({
lat: 3.6790000000e+01,
lng: 1.3701533333e+02,
cert : true,
content:'Name = Futagamiyama(JA/TY-055) peak = 272.799988 pos = 36.7900,137.0153 diff = 267.299988'
});
data_saddle.push({
lat: 3.6771444445e+01,
lng: 1.3700411111e+02,
content:'Saddle = 5.500000 pos = 36.7714,137.0041 diff = 267.299988'
});
data_peak.push({
lat: 3.7718666667e+01,
lng: 1.3881622222e+02,
cert : false,
content:' Peak = 632.799988 pos = 37.7187,138.8162 diff = 622.899963'
});
data_saddle.push({
lat: 3.7620000000e+01,
lng: 1.3883700000e+02,
content:'Saddle = 9.900000 pos = 37.6200,138.8370 diff = 622.899963'
});
data_peak.push({
lat: 3.7670444445e+01,
lng: 1.3881555556e+02,
cert : true,
content:'Name = JA/NI-138(JA/NI-138) peak = 312.500000 pos = 37.6704,138.8156 diff = 203.199997'
});
data_saddle.push({
lat: 3.7682333333e+01,
lng: 1.3880122222e+02,
content:'Saddle = 109.300003 pos = 37.6823,138.8012 diff = 203.199997'
});
data_peak.push({
lat: 3.7780555556e+01,
lng: 1.3883655556e+02,
cert : true,
content:'Name = JA/NI-127(JA/NI-127) peak = 481.200012 pos = 37.7806,138.8366 diff = 353.000000'
});
data_saddle.push({
lat: 3.7738222222e+01,
lng: 1.3881977778e+02,
content:'Saddle = 128.199997 pos = 37.7382,138.8198 diff = 353.000000'
});
data_peak.push({
lat: 3.8000000000e+01,
lng: 1.3942100000e+02,
cert : false,
content:' Peak = 382.500000 pos = 38.0000,139.4210 diff = 326.000000'
});
data_saddle.push({
lat: 3.8000000000e+01,
lng: 1.3944822222e+02,
content:'Saddle = 56.500000 pos = 38.0000,139.4482 diff = 326.000000'
});
data_peak.push({
lat: 3.7974666667e+01,
lng: 1.3940011111e+02,
cert : false,
content:' Peak = 272.799988 pos = 37.9747,139.4001 diff = 156.199982'
});
data_saddle.push({
lat: 3.7980333333e+01,
lng: 1.3940344444e+02,
content:'Saddle = 116.599998 pos = 37.9803,139.4034 diff = 156.199982'
});
data_peak.push({
lat: 3.7644888889e+01,
lng: 1.3910566667e+02,
cert : true,
content:'Name = JA/NI-137(JA/NI-137) peak = 325.500000 pos = 37.6449,139.1057 diff = 238.000000'
});
data_saddle.push({
lat: 3.7642444445e+01,
lng: 1.3911522222e+02,
content:'Saddle = 87.500000 pos = 37.6424,139.1152 diff = 238.000000'
});
data_peak.push({
lat: 3.7725777778e+01,
lng: 1.3910788889e+02,
cert : false,
content:' Peak = 280.500000 pos = 37.7258,139.1079 diff = 151.699997'
});
data_saddle.push({
lat: 3.7713555556e+01,
lng: 1.3911144444e+02,
content:'Saddle = 128.800003 pos = 37.7136,139.1114 diff = 151.699997'
});
data_peak.push({
lat: 3.7702666667e+01,
lng: 1.3937455556e+02,
cert : false,
content:' Peak = 291.100006 pos = 37.7027,139.3746 diff = 196.400009'
});
data_saddle.push({
lat: 3.7702000000e+01,
lng: 1.3937133333e+02,
content:'Saddle = 94.699997 pos = 37.7020,139.3713 diff = 196.400009'
});
data_peak.push({
lat: 3.7560000000e+01,
lng: 1.3898122222e+02,
cert : true,
content:'Name = JA/NI-139(JA/NI-139) peak = 297.200012 pos = 37.5600,138.9812 diff = 200.300018'
});
data_saddle.push({
lat: 3.7534444445e+01,
lng: 1.3899611111e+02,
content:'Saddle = 96.900002 pos = 37.5344,138.9961 diff = 200.300018'
});
data_peak.push({
lat: 3.7490777778e+01,
lng: 1.3872722222e+02,
cert : true,
content:'Name = JA/NI-136(JA/NI-136) peak = 356.500000 pos = 37.4908,138.7272 diff = 253.399994'
});
data_saddle.push({
lat: 3.7386333334e+01,
lng: 1.3867811111e+02,
content:'Saddle = 103.099998 pos = 37.3863,138.6781 diff = 253.399994'
});
data_peak.push({
lat: 3.7523444445e+01,
lng: 1.3906088889e+02,
cert : false,
content:' Peak = 300.799988 pos = 37.5234,139.0609 diff = 151.799988'
});
data_saddle.push({
lat: 3.7519111111e+01,
lng: 1.3909666667e+02,
content:'Saddle = 149.000000 pos = 37.5191,139.0967 diff = 151.799988'
});
data_peak.push({
lat: 3.7631111111e+01,
lng: 1.3913588889e+02,
cert : false,
content:' Peak = 320.600006 pos = 37.6311,139.1359 diff = 161.700012'
});
data_saddle.push({
lat: 3.7627555556e+01,
lng: 1.3914911111e+02,
content:'Saddle = 158.899994 pos = 37.6276,139.1491 diff = 161.700012'
});
data_peak.push({
lat: 3.7277666667e+01,
lng: 1.3881111111e+02,
cert : false,
content:' Peak = 335.500000 pos = 37.2777,138.8111 diff = 159.699997'
});
data_saddle.push({
lat: 3.7267777778e+01,
lng: 1.3879155556e+02,
content:'Saddle = 175.800003 pos = 37.2678,138.7916 diff = 159.699997'
});
data_peak.push({
lat: 3.7307777778e+01,
lng: 1.3865933333e+02,
cert : true,
content:'Name = JA/NI-119(JA/NI-119) peak = 515.299988 pos = 37.3078,138.6593 diff = 336.799988'
});
data_saddle.push({
lat: 3.7273555556e+01,
lng: 1.3865288889e+02,
content:'Saddle = 178.500000 pos = 37.2736,138.6529 diff = 336.799988'
});
data_peak.push({
lat: 3.7317888889e+01,
lng: 1.3845144444e+02,
cert : true,
content:'Name = JA/NI-135(JA/NI-135) peak = 364.600006 pos = 37.3179,138.4514 diff = 185.100006'
});
data_saddle.push({
lat: 3.7310333334e+01,
lng: 1.3845300000e+02,
content:'Saddle = 179.500000 pos = 37.3103,138.4530 diff = 185.100006'
});
data_peak.push({
lat: 3.7140666667e+01,
lng: 1.3845088889e+02,
cert : false,
content:' Peak = 343.299988 pos = 37.1407,138.4509 diff = 161.899994'
});
data_saddle.push({
lat: 3.7135666667e+01,
lng: 1.3845244444e+02,
content:'Saddle = 181.399994 pos = 37.1357,138.4524 diff = 161.899994'
});
data_peak.push({
lat: 3.7563666667e+01,
lng: 1.3910755556e+02,
cert : false,
content:' Peak = 349.500000 pos = 37.5637,139.1076 diff = 152.399994'
});
data_saddle.push({
lat: 3.7568000000e+01,
lng: 1.3911266667e+02,
content:'Saddle = 197.100006 pos = 37.5680,139.1127 diff = 152.399994'
});
data_peak.push({
lat: 3.7177444445e+01,
lng: 1.3846000000e+02,
cert : true,
content:'Name = JA/NI-134(JA/NI-134) peak = 396.000000 pos = 37.1774,138.4600 diff = 194.300003'
});
data_saddle.push({
lat: 3.7186444445e+01,
lng: 1.3848900000e+02,
content:'Saddle = 201.699997 pos = 37.1864,138.4890 diff = 194.300003'
});
data_peak.push({
lat: 3.7715000000e+01,
lng: 1.3948888889e+02,
cert : true,
content:'Name = JA/NI-124(JA/NI-124) peak = 501.700012 pos = 37.7150,139.4889 diff = 295.400024'
});
data_saddle.push({
lat: 3.7710888889e+01,
lng: 1.3949977778e+02,
content:'Saddle = 206.300003 pos = 37.7109,139.4998 diff = 295.400024'
});
data_peak.push({
lat: 3.7779222222e+01,
lng: 1.3932888889e+02,
cert : true,
content:'Name = JA/NI-065(JA/NI-065) peak = 980.299988 pos = 37.7792,139.3289 diff = 765.199951'
});
data_saddle.push({
lat: 3.7814444445e+01,
lng: 1.3941222222e+02,
content:'Saddle = 215.100006 pos = 37.8144,139.4122 diff = 765.199951'
});
data_peak.push({
lat: 3.7735777778e+01,
lng: 1.3935144444e+02,
cert : true,
content:'Name = JA/NI-117(JA/NI-117) peak = 527.099976 pos = 37.7358,139.3514 diff = 255.099976'
});
data_saddle.push({
lat: 3.7752666667e+01,
lng: 1.3935000000e+02,
content:'Saddle = 272.000000 pos = 37.7527,139.3500 diff = 255.099976'
});
data_peak.push({
lat: 3.7763111111e+01,
lng: 1.3938833333e+02,
cert : true,
content:'Name = JA/NI-104(JA/NI-104) peak = 612.900024 pos = 37.7631,139.3883 diff = 265.100037'
});
data_saddle.push({
lat: 3.7782444445e+01,
lng: 1.3939011111e+02,
content:'Saddle = 347.799988 pos = 37.7824,139.3901 diff = 265.100037'
});
data_peak.push({
lat: 3.7654222222e+01,
lng: 1.3923655556e+02,
cert : false,
content:' Peak = 390.799988 pos = 37.6542,139.2366 diff = 158.199982'
});
data_saddle.push({
lat: 3.7635333333e+01,
lng: 1.3923844444e+02,
content:'Saddle = 232.600006 pos = 37.6353,139.2384 diff = 158.199982'
});
data_peak.push({
lat: 3.7319111111e+01,
lng: 1.3851900000e+02,
cert : true,
content:'Name = JA/NI-128(JA/NI-128) peak = 461.200012 pos = 37.3191,138.5190 diff = 206.300018'
});
data_saddle.push({
lat: 3.7308777778e+01,
lng: 1.3853311111e+02,
content:'Saddle = 254.899994 pos = 37.3088,138.5331 diff = 206.300018'
});
data_peak.push({
lat: 3.7714111111e+01,
lng: 1.3933422222e+02,
cert : true,
content:'Name = JA/NI-115(JA/NI-115) peak = 533.500000 pos = 37.7141,139.3342 diff = 276.899994'
});
data_saddle.push({
lat: 3.7697555556e+01,
lng: 1.3931577778e+02,
content:'Saddle = 256.600006 pos = 37.6976,139.3158 diff = 276.899994'
});
data_peak.push({
lat: 3.6666777778e+01,
lng: 1.3741333333e+02,
cert : false,
content:' Peak = 472.100006 pos = 36.6668,137.4133 diff = 189.500000'
});
data_saddle.push({
lat: 3.6666777778e+01,
lng: 1.3743688889e+02,
content:'Saddle = 282.600006 pos = 36.6668,137.4369 diff = 189.500000'
});
data_peak.push({
lat: 3.7672000000e+01,
lng: 1.3950922222e+02,
cert : false,
content:' Peak = 465.600006 pos = 37.6720,139.5092 diff = 177.100006'
});
data_saddle.push({
lat: 3.7677222222e+01,
lng: 1.3951700000e+02,
content:'Saddle = 288.500000 pos = 37.6772,139.5170 diff = 177.100006'
});
data_peak.push({
lat: 3.7160555556e+01,
lng: 1.3863100000e+02,
cert : true,
content:'Name = JA/NI-126(JA/NI-126) peak = 483.399994 pos = 37.1606,138.6310 diff = 184.899994'
});
data_saddle.push({
lat: 3.7142555556e+01,
lng: 1.3860477778e+02,
content:'Saddle = 298.500000 pos = 37.1426,138.6048 diff = 184.899994'
});
data_peak.push({
lat: 3.7149555556e+01,
lng: 1.3847488889e+02,
cert : true,
content:'Name = JA/NI-122(JA/NI-122) peak = 505.200012 pos = 37.1496,138.4749 diff = 206.200012'
});
data_saddle.push({
lat: 3.7113666667e+01,
lng: 1.3848522222e+02,
content:'Saddle = 299.000000 pos = 37.1137,138.4852 diff = 206.200012'
});
data_peak.push({
lat: 3.7260333334e+01,
lng: 1.3848833333e+02,
cert : false,
content:' Peak = 477.299988 pos = 37.2603,138.4883 diff = 171.899994'
});
data_saddle.push({
lat: 3.7260222223e+01,
lng: 1.3849300000e+02,
content:'Saddle = 305.399994 pos = 37.2602,138.4930 diff = 171.899994'
});
data_peak.push({
lat: 3.6975777778e+01,
lng: 1.3824766667e+02,
cert : true,
content:'Name = JA/NI-116(JA/NI-116) peak = 527.099976 pos = 36.9758,138.2477 diff = 216.599976'
});
data_saddle.push({
lat: 3.6942555556e+01,
lng: 1.3823000000e+02,
content:'Saddle = 310.500000 pos = 36.9426,138.2300 diff = 216.599976'
});
data_peak.push({
lat: 3.7501888889e+01,
lng: 1.3969255556e+02,
cert : false,
content:' Peak = 464.100006 pos = 37.5019,139.6926 diff = 151.700012'
});
data_saddle.push({
lat: 3.7485222222e+01,
lng: 1.3968777778e+02,
content:'Saddle = 312.399994 pos = 37.4852,139.6878 diff = 151.700012'
});
data_peak.push({
lat: 3.7289555556e+01,
lng: 1.3848388889e+02,
cert : true,
content:'Name = Yoneyama(JA/NI-064) peak = 991.799988 pos = 37.2896,138.4839 diff = 674.500000'
});
data_saddle.push({
lat: 3.7154222223e+01,
lng: 1.3854622222e+02,
content:'Saddle = 317.299988 pos = 37.1542,138.5462 diff = 674.500000'
});
data_peak.push({
lat: 3.7226111111e+01,
lng: 1.3859211111e+02,
cert : true,
content:'Name = Kurohimesan(JA/NI-076) peak = 891.700012 pos = 37.2261,138.5921 diff = 570.700012'
});
data_saddle.push({
lat: 3.7268777778e+01,
lng: 1.3853288889e+02,
content:'Saddle = 321.000000 pos = 37.2688,138.5329 diff = 570.700012'
});
data_peak.push({
lat: 3.7225111111e+01,
lng: 1.3850133333e+02,
cert : true,
content:'Name = JA/NI-086(JA/NI-086) peak = 756.200012 pos = 37.2251,138.5013 diff = 339.000000'
});
data_saddle.push({
lat: 3.7206222223e+01,
lng: 1.3852733333e+02,
content:'Saddle = 417.200012 pos = 37.2062,138.5273 diff = 339.000000'
});
data_peak.push({
lat: 3.7219555556e+01,
lng: 1.3852500000e+02,
cert : true,
content:'Name = JA/NI-091(JA/NI-091) peak = 675.099976 pos = 37.2196,138.5250 diff = 220.699982'
});
data_saddle.push({
lat: 3.7223888889e+01,
lng: 1.3851511111e+02,
content:'Saddle = 454.399994 pos = 37.2239,138.5151 diff = 220.699982'
});
data_peak.push({
lat: 3.7348333334e+01,
lng: 1.3887077778e+02,
cert : true,
content:'Name = JA/NI-108(JA/NI-108) peak = 581.099976 pos = 37.3483,138.8708 diff = 252.599976'
});
data_saddle.push({
lat: 3.7342777778e+01,
lng: 1.3888566667e+02,
content:'Saddle = 328.500000 pos = 37.3428,138.8857 diff = 252.599976'
});
data_peak.push({
lat: 3.7553666667e+01,
lng: 1.3912233333e+02,
cert : true,
content:'Name = JA/NI-118(JA/NI-118) peak = 523.200012 pos = 37.5537,139.1223 diff = 190.400024'
});
data_saddle.push({
lat: 3.7559000000e+01,
lng: 1.3914688889e+02,
content:'Saddle = 332.799988 pos = 37.5590,139.1469 diff = 190.400024'
});
data_peak.push({
lat: 3.6798555556e+01,
lng: 1.3937588889e+02,
cert : true,
content:'Name = Shiranesan(JA/TG-001) peak = 2575.800049 pos = 36.7986,139.3759 diff = 2243.000000'
});
data_saddle.push({
lat: 3.6666777778e+01,
lng: 1.3827211111e+02,
content:'Saddle = 332.799988 pos = 36.6668,138.2721 diff = 2243.000000'
});
data_peak.push({
lat: 3.7683888889e+01,
lng: 1.3954333333e+02,
cert : true,
content:'Name = JA/NI-089(JA/NI-089) peak = 696.700012 pos = 37.6839,139.5433 diff = 339.300018'
});
data_saddle.push({
lat: 3.7661333333e+01,
lng: 1.3955288889e+02,
content:'Saddle = 357.399994 pos = 37.6613,139.5529 diff = 339.300018'
});
data_peak.push({
lat: 3.7692111111e+01,
lng: 1.3952866667e+02,
cert : false,
content:' Peak = 630.900024 pos = 37.6921,139.5287 diff = 178.100037'
});
data_saddle.push({
lat: 3.7685555556e+01,
lng: 1.3953344444e+02,
content:'Saddle = 452.799988 pos = 37.6856,139.5334 diff = 178.100037'
});
data_peak.push({
lat: 3.7694777778e+01,
lng: 1.3927111111e+02,
cert : false,
content:' Peak = 910.099976 pos = 37.6948,139.2711 diff = 547.500000'
});
data_saddle.push({
lat: 3.7691333333e+01,
lng: 1.3930688889e+02,
content:'Saddle = 362.600006 pos = 37.6913,139.3069 diff = 547.500000'
});
data_peak.push({
lat: 3.7650333333e+01,
lng: 1.3926411111e+02,
cert : true,
content:'Name = JA/NI-101(JA/NI-101) peak = 630.299988 pos = 37.6503,139.2641 diff = 266.500000'
});
data_saddle.push({
lat: 3.7635666667e+01,
lng: 1.3927000000e+02,
content:'Saddle = 363.799988 pos = 37.6357,139.2700 diff = 266.500000'
});
data_peak.push({
lat: 3.7716111111e+01,
lng: 1.3942311111e+02,
cert : true,
content:'Name = JA/NI-092(JA/NI-092) peak = 656.599976 pos = 37.7161,139.4231 diff = 290.099976'
});
data_saddle.push({
lat: 3.7736333333e+01,
lng: 1.3945600000e+02,
content:'Saddle = 366.500000 pos = 37.7363,139.4560 diff = 290.099976'
});
data_peak.push({
lat: 3.7584555556e+01,
lng: 1.3970955556e+02,
cert : true,
content:'Name = JA/FS-162(JA/FS-162) peak = 580.400024 pos = 37.5846,139.7096 diff = 195.600037'
});
data_saddle.push({
lat: 3.7560666667e+01,
lng: 1.3970911111e+02,
content:'Saddle = 384.799988 pos = 37.5607,139.7091 diff = 195.600037'
});
data_peak.push({
lat: 3.7583222222e+01,
lng: 1.3954177778e+02,
cert : false,
content:' Peak = 580.299988 pos = 37.5832,139.5418 diff = 178.899994'
});
data_saddle.push({
lat: 3.7561444445e+01,
lng: 1.3955233333e+02,
content:'Saddle = 401.399994 pos = 37.5614,139.5523 diff = 178.899994'
});
data_peak.push({
lat: 3.7625888889e+01,
lng: 1.3954655556e+02,
cert : true,
content:'Name = JA/FS-149(JA/FS-149) peak = 695.400024 pos = 37.6259,139.5466 diff = 288.000031'
});
data_saddle.push({
lat: 3.7589333333e+01,
lng: 1.3956533333e+02,
content:'Saddle = 407.399994 pos = 37.5893,139.5653 diff = 288.000031'
});
data_peak.push({
lat: 3.7398666667e+01,
lng: 1.3893522222e+02,
cert : true,
content:'Name = JA/NI-085(JA/NI-085) peak = 763.799988 pos = 37.3987,138.9352 diff = 345.899994'
});
data_saddle.push({
lat: 3.7367888889e+01,
lng: 1.3894844444e+02,
content:'Saddle = 417.899994 pos = 37.3679,138.9484 diff = 345.899994'
});
data_peak.push({
lat: 3.7319777778e+01,
lng: 1.3898622222e+02,
cert : true,
content:'Name = JA/NI-090(JA/NI-090) peak = 680.799988 pos = 37.3198,138.9862 diff = 261.099976'
});
data_saddle.push({
lat: 3.7382777778e+01,
lng: 1.3901588889e+02,
content:'Saddle = 419.700012 pos = 37.3828,139.0159 diff = 261.099976'
});
data_peak.push({
lat: 3.7378888889e+01,
lng: 1.3896588889e+02,
cert : true,
content:'Name = JA/NI-106(JA/NI-106) peak = 605.099976 pos = 37.3789,138.9659 diff = 176.899963'
});
data_saddle.push({
lat: 3.7373777778e+01,
lng: 1.3900755556e+02,
content:'Saddle = 428.200012 pos = 37.3738,139.0076 diff = 176.899963'
});
data_peak.push({
lat: 3.7480222222e+01,
lng: 1.3912955556e+02,
cert : true,
content:'Name = JA/NI-095(JA/NI-095) peak = 642.299988 pos = 37.4802,139.1296 diff = 220.099976'
});
data_saddle.push({
lat: 3.7465222222e+01,
lng: 1.3913233333e+02,
content:'Saddle = 422.200012 pos = 37.4652,139.1323 diff = 220.099976'
});
data_peak.push({
lat: 3.7529000000e+01,
lng: 1.3968577778e+02,
cert : true,
content:'Name = JA/FS-135(JA/FS-135) peak = 782.200012 pos = 37.5290,139.6858 diff = 353.900024'
});
data_saddle.push({
lat: 3.7505777778e+01,
lng: 1.3965777778e+02,
content:'Saddle = 428.299988 pos = 37.5058,139.6578 diff = 353.900024'
});
data_peak.push({
lat: 3.7332444445e+01,
lng: 1.3906911111e+02,
cert : true,
content:'Name = JA/NI-103(JA/NI-103) peak = 630.299988 pos = 37.3324,139.0691 diff = 187.500000'
});
data_saddle.push({
lat: 3.7312666667e+01,
lng: 1.3905977778e+02,
content:'Saddle = 442.799988 pos = 37.3127,139.0598 diff = 187.500000'
});
data_peak.push({
lat: 3.7457333334e+01,
lng: 1.3968377778e+02,
cert : true,
content:'Name = JA/FS-141(JA/FS-141) peak = 724.299988 pos = 37.4573,139.6838 diff = 247.099976'
});
data_saddle.push({
lat: 3.7436333334e+01,
lng: 1.3966411111e+02,
content:'Saddle = 477.200012 pos = 37.4363,139.6641 diff = 247.099976'
});
data_peak.push({
lat: 3.7386444445e+01,
lng: 1.3980733333e+02,
cert : false,
content:' Peak = 644.500000 pos = 37.3864,139.8073 diff = 166.299988'
});
data_saddle.push({
lat: 3.7376000000e+01,
lng: 1.3980644444e+02,
content:'Saddle = 478.200012 pos = 37.3760,139.8064 diff = 166.299988'
});
data_peak.push({
lat: 3.7195111111e+01,
lng: 1.3905377778e+02,
cert : true,
content:'Name = JA/NI-093(JA/NI-093) peak = 652.599976 pos = 37.1951,139.0538 diff = 169.899963'
});
data_saddle.push({
lat: 3.7196111111e+01,
lng: 1.3904188889e+02,
content:'Saddle = 482.700012 pos = 37.1961,139.0419 diff = 169.899963'
});
data_peak.push({
lat: 3.7693777778e+01,
lng: 1.3992811111e+02,
cert : false,
content:' Peak = 711.700012 pos = 37.6938,139.9281 diff = 177.000000'
});
data_saddle.push({
lat: 3.7702888889e+01,
lng: 1.3993400000e+02,
content:'Saddle = 534.700012 pos = 37.7029,139.9340 diff = 177.000000'
});
data_peak.push({
lat: 3.7833222222e+01,
lng: 1.3966055556e+02,
cert : true,
content:'Name = Dainichidake(JA/NI-007) peak = 2125.899902 pos = 37.8332,139.6606 diff = 1587.999878'
});
data_saddle.push({
lat: 3.7484777778e+01,
lng: 1.4019722222e+02,
content:'Saddle = 537.900024 pos = 37.4848,140.1972 diff = 1587.999878'
});
data_peak.push({
lat: 3.7502222222e+01,
lng: 1.4023033333e+02,
cert : false,
content:' Peak = 705.000000 pos = 37.5022,140.2303 diff = 166.400024'
});
data_saddle.push({
lat: 3.7505888889e+01,
lng: 1.4022000000e+02,
content:'Saddle = 538.599976 pos = 37.5059,140.2200 diff = 166.400024'
});
data_peak.push({
lat: 3.7523111111e+01,
lng: 1.4028477778e+02,
cert : true,
content:'Name = JA/FS-138(JA/FS-138) peak = 764.299988 pos = 37.5231,140.2848 diff = 224.200012'
});
data_saddle.push({
lat: 3.7536000000e+01,
lng: 1.4028655556e+02,
content:'Saddle = 540.099976 pos = 37.5360,140.2866 diff = 224.200012'
});
data_peak.push({
lat: 3.7745777778e+01,
lng: 1.3950255556e+02,
cert : true,
content:'Name = JA/NI-058(JA/NI-058) peak = 1024.500000 pos = 37.7458,139.5026 diff = 441.799988'
});
data_saddle.push({
lat: 3.7751333333e+01,
lng: 1.3953000000e+02,
content:'Saddle = 582.700012 pos = 37.7513,139.5300 diff = 441.799988'
});
data_peak.push({
lat: 3.7946888889e+01,
lng: 1.4047477778e+02,
cert : false,
content:' Peak = 835.200012 pos = 37.9469,140.4748 diff = 252.400024'
});
data_saddle.push({
lat: 3.7951111111e+01,
lng: 1.4044966667e+02,
content:'Saddle = 582.799988 pos = 37.9511,140.4497 diff = 252.400024'
});
data_peak.push({
lat: 3.7938222222e+01,
lng: 1.4046733333e+02,
cert : true,
content:'Name = JA/MG-024(JA/MG-024) peak = 828.599976 pos = 37.9382,140.4673 diff = 165.699951'
});
data_saddle.push({
lat: 3.7943444444e+01,
lng: 1.4047144444e+02,
content:'Saddle = 662.900024 pos = 37.9434,140.4714 diff = 165.699951'
});
data_peak.push({
lat: 3.7538666667e+01,
lng: 1.4029866667e+02,
cert : true,
content:'Name = JA/FS-133(JA/FS-133) peak = 792.599976 pos = 37.5387,140.2987 diff = 180.699951'
});
data_saddle.push({
lat: 3.7542333334e+01,
lng: 1.4029155556e+02,
content:'Saddle = 611.900024 pos = 37.5423,140.2916 diff = 180.699951'
});
data_peak.push({
lat: 3.7728777778e+01,
lng: 1.3960000000e+02,
cert : false,
content:' Peak = 785.500000 pos = 37.7288,139.6000 diff = 171.900024'
});
data_saddle.push({
lat: 3.7728777778e+01,
lng: 1.3960900000e+02,
content:'Saddle = 613.599976 pos = 37.7288,139.6090 diff = 171.900024'
});
data_peak.push({
lat: 3.7994666667e+01,
lng: 1.4038900000e+02,
cert : true,
content:'Name = JA/MG-015(JA/MG-015) peak = 1083.900024 pos = 37.9947,140.3890 diff = 445.800049'
});
data_saddle.push({
lat: 3.7987666667e+01,
lng: 1.4031755556e+02,
content:'Saddle = 638.099976 pos = 37.9877,140.3176 diff = 445.800049'
});
data_peak.push({
lat: 3.7972333333e+01,
lng: 1.4037177778e+02,
cert : true,
content:'Name = JA/MG-021(JA/MG-021) peak = 902.400024 pos = 37.9723,140.3718 diff = 262.200012'
});
data_saddle.push({
lat: 3.7980444444e+01,
lng: 1.4037377778e+02,
content:'Saddle = 640.200012 pos = 37.9804,140.3738 diff = 262.200012'
});
data_peak.push({
lat: 3.7960333333e+01,
lng: 1.4042077778e+02,
cert : true,
content:'Name = JA/FS-118(JA/FS-118) peak = 863.900024 pos = 37.9603,140.4208 diff = 186.900024'
});
data_saddle.push({
lat: 3.7961888889e+01,
lng: 1.4041655556e+02,
content:'Saddle = 677.000000 pos = 37.9619,140.4166 diff = 186.900024'
});
data_peak.push({
lat: 3.7496777778e+01,
lng: 1.4017288889e+02,
cert : false,
content:' Peak = 854.099976 pos = 37.4968,140.1729 diff = 191.000000'
});
data_saddle.push({
lat: 3.7494000000e+01,
lng: 1.4018411111e+02,
content:'Saddle = 663.099976 pos = 37.4940,140.1841 diff = 191.000000'
});
data_peak.push({
lat: 3.7886444444e+01,
lng: 1.4038188889e+02,
cert : false,
content:' Peak = 893.000000 pos = 37.8864,140.3819 diff = 221.500000'
});
data_saddle.push({
lat: 3.7884888889e+01,
lng: 1.4036955556e+02,
content:'Saddle = 671.500000 pos = 37.8849,140.3696 diff = 221.500000'
});
data_peak.push({
lat: 3.7961111111e+01,
lng: 1.3951411111e+02,
cert : true,
content:'Name = JA/NI-072(JA/NI-072) peak = 930.599976 pos = 37.9611,139.5141 diff = 253.699951'
});
data_saddle.push({
lat: 3.7948666667e+01,
lng: 1.3951833333e+02,
content:'Saddle = 676.900024 pos = 37.9487,139.5183 diff = 253.699951'
});
data_peak.push({
lat: 3.7736555556e+01,
lng: 1.3972711111e+02,
cert : true,
content:'Name = JA/FS-094(JA/FS-094) peak = 952.700012 pos = 37.7366,139.7271 diff = 263.799988'
});
data_saddle.push({
lat: 3.7765222222e+01,
lng: 1.3973533333e+02,
content:'Saddle = 688.900024 pos = 37.7652,139.7353 diff = 263.799988'
});
data_peak.push({
lat: 3.7501000000e+01,
lng: 1.4018933333e+02,
cert : false,
content:' Peak = 862.000000 pos = 37.5010,140.1893 diff = 169.900024'
});
data_saddle.push({
lat: 3.7506333334e+01,
lng: 1.4018833333e+02,
content:'Saddle = 692.099976 pos = 37.5063,140.1883 diff = 169.900024'
});
data_peak.push({
lat: 3.7797000000e+01,
lng: 1.3948155556e+02,
cert : true,
content:'Name = JA/NI-078(JA/NI-078) peak = 856.299988 pos = 37.7970,139.4816 diff = 163.599976'
});
data_saddle.push({
lat: 3.7795555556e+01,
lng: 1.3948766667e+02,
content:'Saddle = 692.700012 pos = 37.7956,139.4877 diff = 163.599976'
});
data_peak.push({
lat: 3.7767555556e+01,
lng: 1.3977522222e+02,
cert : false,
content:' Peak = 893.500000 pos = 37.7676,139.7752 diff = 175.900024'
});
data_saddle.push({
lat: 3.7777555556e+01,
lng: 1.3976844444e+02,
content:'Saddle = 717.599976 pos = 37.7776,139.7684 diff = 175.900024'
});
data_peak.push({
lat: 3.7873888889e+01,
lng: 1.4033988889e+02,
cert : false,
content:' Peak = 900.500000 pos = 37.8739,140.3399 diff = 168.099976'
});
data_saddle.push({
lat: 3.7861888889e+01,
lng: 1.4032977778e+02,
content:'Saddle = 732.400024 pos = 37.8619,140.3298 diff = 168.099976'
});
data_peak.push({
lat: 3.7746111111e+01,
lng: 1.3965855556e+02,
cert : true,
content:'Name = JA/FS-054(JA/FS-054) peak = 1150.599976 pos = 37.7461,139.6586 diff = 402.799988'
});
data_saddle.push({
lat: 3.7771222222e+01,
lng: 1.3967788889e+02,
content:'Saddle = 747.799988 pos = 37.7712,139.6779 diff = 402.799988'
});
data_peak.push({
lat: 3.7901222222e+01,
lng: 1.4029833333e+02,
cert : false,
content:' Peak = 1216.800049 pos = 37.9012,140.2983 diff = 460.700073'
});
data_saddle.push({
lat: 3.7809555556e+01,
lng: 1.4025066667e+02,
content:'Saddle = 756.099976 pos = 37.8096,140.2507 diff = 460.700073'
});
data_peak.push({
lat: 3.7864000000e+01,
lng: 1.4029500000e+02,
cert : false,
content:' Peak = 962.599976 pos = 37.8640,140.2950 diff = 192.199951'
});
data_saddle.push({
lat: 3.7858111111e+01,
lng: 1.4028422222e+02,
content:'Saddle = 770.400024 pos = 37.8581,140.2842 diff = 192.199951'
});
data_peak.push({
lat: 3.7853666667e+01,
lng: 1.4030622222e+02,
cert : true,
content:'Name = JA/FS-075(JA/FS-075) peak = 988.200012 pos = 37.8537,140.3062 diff = 206.100037'
});
data_saddle.push({
lat: 3.7845000000e+01,
lng: 1.4029677778e+02,
content:'Saddle = 782.099976 pos = 37.8450,140.2968 diff = 206.100037'
});
data_peak.push({
lat: 3.7978555556e+01,
lng: 1.4027866667e+02,
cert : true,
content:'Name = JA/FS-072(JA/FS-072) peak = 993.200012 pos = 37.9786,140.2787 diff = 200.000000'
});
data_saddle.push({
lat: 3.7970555556e+01,
lng: 1.4027300000e+02,
content:'Saddle = 793.200012 pos = 37.9706,140.2730 diff = 200.000000'
});
data_peak.push({
lat: 3.7830111111e+01,
lng: 1.4024655556e+02,
cert : false,
content:' Peak = 1004.799988 pos = 37.8301,140.2466 diff = 157.599976'
});
data_saddle.push({
lat: 3.7835666667e+01,
lng: 1.4025511111e+02,
content:'Saddle = 847.200012 pos = 37.8357,140.2551 diff = 157.599976'
});
data_peak.push({
lat: 3.7874444444e+01,
lng: 1.4026988889e+02,
cert : false,
content:' Peak = 1216.400024 pos = 37.8744,140.2699 diff = 164.800049'
});
data_saddle.push({
lat: 3.7896000000e+01,
lng: 1.4029111111e+02,
content:'Saddle = 1051.599976 pos = 37.8960,140.2911 diff = 164.800049'
});
data_peak.push({
lat: 3.7975777778e+01,
lng: 1.3964188889e+02,
cert : true,
content:'Name = JA/YM-022(JA/YM-022) peak = 1113.000000 pos = 37.9758,139.6419 diff = 320.900024'
});
data_saddle.push({
lat: 3.7956888889e+01,
lng: 1.3964200000e+02,
content:'Saddle = 792.099976 pos = 37.9569,139.6420 diff = 320.900024'
});
data_peak.push({
lat: 3.7995222222e+01,
lng: 1.3964344444e+02,
cert : true,
content:'Name = JA/YM-023(JA/YM-023) peak = 1101.300049 pos = 37.9952,139.6434 diff = 244.300049'
});
data_saddle.push({
lat: 3.7985888889e+01,
lng: 1.3963933333e+02,
content:'Saddle = 857.000000 pos = 37.9859,139.6393 diff = 244.300049'
});
data_peak.push({
lat: 3.7776333333e+01,
lng: 1.3958811111e+02,
cert : true,
content:'Name = JA/NI-053(JA/NI-053) peak = 1066.500000 pos = 37.7763,139.5881 diff = 273.599976'
});
data_saddle.push({
lat: 3.7785222222e+01,
lng: 1.3959255556e+02,
content:'Saddle = 792.900024 pos = 37.7852,139.5926 diff = 273.599976'
});
data_peak.push({
lat: 3.7955444444e+01,
lng: 1.3956244444e+02,
cert : false,
content:' Peak = 972.900024 pos = 37.9554,139.5624 diff = 160.700012'
});
data_saddle.push({
lat: 3.7947111111e+01,
lng: 1.3956266667e+02,
content:'Saddle = 812.200012 pos = 37.9471,139.5627 diff = 160.700012'
});
data_peak.push({
lat: 3.7646222222e+01,
lng: 1.4013444444e+02,
cert : true,
content:'Name = JA/FS-046(JA/FS-046) peak = 1220.300049 pos = 37.6462,140.1344 diff = 402.300049'
});
data_saddle.push({
lat: 3.7639555556e+01,
lng: 1.4017044444e+02,
content:'Saddle = 818.000000 pos = 37.6396,140.1704 diff = 402.300049'
});
data_peak.push({
lat: 3.7601000000e+01,
lng: 1.4007211111e+02,
cert : false,
content:' Peak = 1814.800049 pos = 37.6010,140.0721 diff = 947.200073'
});
data_saddle.push({
lat: 3.7676444445e+01,
lng: 1.4003800000e+02,
content:'Saddle = 867.599976 pos = 37.6764,140.0380 diff = 947.200073'
});
data_peak.push({
lat: 3.7611666667e+01,
lng: 1.4002833333e+02,
cert : true,
content:'Name = JA/FS-033(JA/FS-033) peak = 1402.699951 pos = 37.6117,140.0283 diff = 208.099976'
});
data_saddle.push({
lat: 3.7614888889e+01,
lng: 1.4004811111e+02,
content:'Saddle = 1194.599976 pos = 37.6149,140.0481 diff = 208.099976'
});
data_peak.push({
lat: 3.7609666667e+01,
lng: 1.4008544444e+02,
cert : false,
content:' Peak = 1634.599976 pos = 37.6097,140.0854 diff = 182.900024'
});
data_saddle.push({
lat: 3.7609333333e+01,
lng: 1.4008044444e+02,
content:'Saddle = 1451.699951 pos = 37.6093,140.0804 diff = 182.900024'
});
data_peak.push({
lat: 3.7600444445e+01,
lng: 1.4022000000e+02,
cert : false,
content:' Peak = 1074.500000 pos = 37.6004,140.2200 diff = 163.200012'
});
data_saddle.push({
lat: 3.7601000000e+01,
lng: 1.4023155556e+02,
content:'Saddle = 911.299988 pos = 37.6010,140.2316 diff = 163.200012'
});
data_peak.push({
lat: 3.7598444445e+01,
lng: 1.4019422222e+02,
cert : true,
content:'Name = JA/FS-050(JA/FS-050) peak = 1171.099976 pos = 37.5984,140.1942 diff = 229.399963'
});
data_saddle.push({
lat: 3.7593555556e+01,
lng: 1.4019933333e+02,
content:'Saddle = 941.700012 pos = 37.5936,140.1993 diff = 229.399963'
});
data_peak.push({
lat: 3.7691555556e+01,
lng: 1.4002411111e+02,
cert : true,
content:'Name = JA/FS-055(JA/FS-055) peak = 1144.599976 pos = 37.6916,140.0241 diff = 196.899963'
});
data_saddle.push({
lat: 3.7702777778e+01,
lng: 1.4002344444e+02,
content:'Saddle = 947.700012 pos = 37.7028,140.0234 diff = 196.899963'
});
data_peak.push({
lat: 3.7807666667e+01,
lng: 1.4002122222e+02,
cert : true,
content:'Name = JA/YM-020(JA/YM-020) peak = 1137.400024 pos = 37.8077,140.0212 diff = 185.200012'
});
data_saddle.push({
lat: 3.7804333333e+01,
lng: 1.4001544444e+02,
content:'Saddle = 952.200012 pos = 37.8043,140.0154 diff = 185.200012'
});
data_peak.push({
lat: 3.7558222222e+01,
lng: 1.4017711111e+02,
cert : true,
content:'Name = JA/FS-032(JA/FS-032) peak = 1412.300049 pos = 37.5582,140.1771 diff = 445.700073'
});
data_saddle.push({
lat: 3.7593444445e+01,
lng: 1.4024277778e+02,
content:'Saddle = 966.599976 pos = 37.5934,140.2428 diff = 445.700073'
});
data_peak.push({
lat: 3.7557444445e+01,
lng: 1.4020133333e+02,
cert : true,
content:'Name = JA/FS-036(JA/FS-036) peak = 1370.199951 pos = 37.5574,140.2013 diff = 213.799927'
});
data_saddle.push({
lat: 3.7555000000e+01,
lng: 1.4018177778e+02,
content:'Saddle = 1156.400024 pos = 37.5550,140.1818 diff = 213.799927'
});
data_peak.push({
lat: 3.7795555556e+01,
lng: 1.3952788889e+02,
cert : true,
content:'Name = JA/NI-034(JA/NI-034) peak = 1360.900024 pos = 37.7956,139.5279 diff = 392.900024'
});
data_saddle.push({
lat: 3.7805777778e+01,
lng: 1.3955277778e+02,
content:'Saddle = 968.000000 pos = 37.8058,139.5528 diff = 392.900024'
});
data_peak.push({
lat: 3.7738111111e+01,
lng: 1.4014077778e+02,
cert : true,
content:'Name = Nishiadumayama(JA/FS-003) peak = 2034.599976 pos = 37.7381,140.1408 diff = 1062.099976'
});
data_saddle.push({
lat: 3.7803888889e+01,
lng: 1.3981211111e+02,
content:'Saddle = 972.500000 pos = 37.8039,139.8121 diff = 1062.099976'
});
data_peak.push({
lat: 3.7755888889e+01,
lng: 1.3995677778e+02,
cert : false,
content:' Peak = 1153.300049 pos = 37.7559,139.9568 diff = 152.200073'
});
data_saddle.push({
lat: 3.7756000000e+01,
lng: 1.3996277778e+02,
content:'Saddle = 1001.099976 pos = 37.7560,139.9628 diff = 152.200073'
});
data_peak.push({
lat: 3.7825777778e+01,
lng: 1.3998400000e+02,
cert : false,
content:' Peak = 1226.599976 pos = 37.8258,139.9840 diff = 175.599976'
});
data_saddle.push({
lat: 3.7824111111e+01,
lng: 1.3997822222e+02,
content:'Saddle = 1051.000000 pos = 37.8241,139.9782 diff = 175.599976'
});
data_peak.push({
lat: 3.7813888889e+01,
lng: 1.3992544444e+02,
cert : true,
content:'Name = Iimorisan(JA/FS-018) peak = 1594.500000 pos = 37.8139,139.9254 diff = 528.699951'
});
data_saddle.push({
lat: 3.7770555556e+01,
lng: 1.4004077778e+02,
content:'Saddle = 1065.800049 pos = 37.7706,140.0408 diff = 528.699951'
});
data_peak.push({
lat: 3.7820444445e+01,
lng: 1.3984688889e+02,
cert : false,
content:' Peak = 1321.599976 pos = 37.8204,139.8469 diff = 208.900024'
});
data_saddle.push({
lat: 3.7825111111e+01,
lng: 1.3986300000e+02,
content:'Saddle = 1112.699951 pos = 37.8251,139.8630 diff = 208.900024'
});
data_peak.push({
lat: 3.7722444445e+01,
lng: 1.3999755556e+02,
cert : true,
content:'Name = JA/FS-028(JA/FS-028) peak = 1442.199951 pos = 37.7224,139.9976 diff = 320.799927'
});
data_saddle.push({
lat: 3.7805777778e+01,
lng: 1.3996211111e+02,
content:'Saddle = 1121.400024 pos = 37.8058,139.9621 diff = 320.799927'
});
data_peak.push({
lat: 3.7657888889e+01,
lng: 1.4022688889e+02,
cert : false,
content:' Peak = 1248.699951 pos = 37.6579,140.2269 diff = 181.099976'
});
data_saddle.push({
lat: 3.7661555556e+01,
lng: 1.4023188889e+02,
content:'Saddle = 1067.599976 pos = 37.6616,140.2319 diff = 181.099976'
});
data_peak.push({
lat: 3.7647111111e+01,
lng: 1.4028077778e+02,
cert : true,
content:'Name = Minowayama(JA/FS-012) peak = 1727.500000 pos = 37.6471,140.2808 diff = 489.900024'
});
data_saddle.push({
lat: 3.7668333333e+01,
lng: 1.4025600000e+02,
content:'Saddle = 1237.599976 pos = 37.6683,140.2560 diff = 489.900024'
});
data_peak.push({
lat: 3.7700444445e+01,
lng: 1.4025711111e+02,
cert : true,
content:'Name = JA/FS-010(JA/FS-010) peak = 1806.300049 pos = 37.7004,140.2571 diff = 202.300049'
});
data_saddle.push({
lat: 3.7705000000e+01,
lng: 1.4024877778e+02,
content:'Saddle = 1604.000000 pos = 37.7050,140.2488 diff = 202.300049'
});
data_peak.push({
lat: 3.7724666667e+01,
lng: 1.4018711111e+02,
cert : false,
content:' Peak = 1931.699951 pos = 37.7247,140.1871 diff = 172.899902'
});
data_saddle.push({
lat: 3.7742000000e+01,
lng: 1.4018666667e+02,
content:'Saddle = 1758.800049 pos = 37.7420,140.1867 diff = 172.899902'
});
data_peak.push({
lat: 3.7711777778e+01,
lng: 1.4023022222e+02,
cert : true,
content:'Name = Higashiadumayama(JA/FS-004) peak = 1974.199951 pos = 37.7118,140.2302 diff = 200.799927'
});
data_saddle.push({
lat: 3.7740111111e+01,
lng: 1.4024022222e+02,
content:'Saddle = 1773.400024 pos = 37.7401,140.2402 diff = 200.799927'
});
data_peak.push({
lat: 3.7735444445e+01,
lng: 1.4024433333e+02,
cert : false,
content:' Peak = 1948.099976 pos = 37.7354,140.2443 diff = 170.799927'
});
data_saddle.push({
lat: 3.7721555556e+01,
lng: 1.4023044444e+02,
content:'Saddle = 1777.300049 pos = 37.7216,140.2304 diff = 170.799927'
});
data_peak.push({
lat: 3.7838777778e+01,
lng: 1.3984277778e+02,
cert : false,
content:' Peak = 1162.599976 pos = 37.8388,139.8428 diff = 161.399963'
});
data_saddle.push({
lat: 3.7825111111e+01,
lng: 1.3981822222e+02,
content:'Saddle = 1001.200012 pos = 37.8251,139.8182 diff = 161.399963'
});
data_peak.push({
lat: 3.7839111111e+01,
lng: 1.3950722222e+02,
cert : false,
content:' Peak = 1167.800049 pos = 37.8391,139.5072 diff = 155.400024'
});
data_saddle.push({
lat: 3.7841555556e+01,
lng: 1.3951344444e+02,
content:'Saddle = 1012.400024 pos = 37.8416,139.5134 diff = 155.400024'
});
data_peak.push({
lat: 3.7892111111e+01,
lng: 1.3950444444e+02,
cert : true,
content:'Name = JA/NI-031(JA/NI-031) peak = 1423.000000 pos = 37.8921,139.5044 diff = 400.900024'
});
data_saddle.push({
lat: 3.7887222222e+01,
lng: 1.3952366667e+02,
content:'Saddle = 1022.099976 pos = 37.8872,139.5237 diff = 400.900024'
});
data_peak.push({
lat: 3.7803111111e+01,
lng: 1.3961822222e+02,
cert : false,
content:' Peak = 1235.300049 pos = 37.8031,139.6182 diff = 162.900024'
});
data_saddle.push({
lat: 3.7805555556e+01,
lng: 1.3961033333e+02,
content:'Saddle = 1072.400024 pos = 37.8056,139.6103 diff = 162.900024'
});
data_peak.push({
lat: 3.7863444444e+01,
lng: 1.3955455556e+02,
cert : false,
content:' Peak = 1402.900024 pos = 37.8634,139.5546 diff = 176.700073'
});
data_saddle.push({
lat: 3.7862444444e+01,
lng: 1.3957766667e+02,
content:'Saddle = 1226.199951 pos = 37.8624,139.5777 diff = 176.700073'
});
data_peak.push({
lat: 3.7813777778e+01,
lng: 1.3959722222e+02,
cert : false,
content:' Peak = 1572.000000 pos = 37.8138,139.5972 diff = 162.000000'
});
data_saddle.push({
lat: 3.7824444445e+01,
lng: 1.3961022222e+02,
content:'Saddle = 1410.000000 pos = 37.8244,139.6102 diff = 162.000000'
});
data_peak.push({
lat: 3.7942666667e+01,
lng: 1.3960877778e+02,
cert : true,
content:'Name = Eburisashidake(JA/NI-019) peak = 1636.099976 pos = 37.9427,139.6088 diff = 213.000000'
});
data_saddle.push({
lat: 3.7931333333e+01,
lng: 1.3960888889e+02,
content:'Saddle = 1423.099976 pos = 37.9313,139.6089 diff = 213.000000'
});
data_peak.push({
lat: 3.7880000000e+01,
lng: 1.3963855556e+02,
cert : true,
content:'Name = Kitamatadake(JA/NI-011) peak = 2023.699951 pos = 37.8800,139.6386 diff = 221.399902'
});
data_saddle.push({
lat: 3.7857222222e+01,
lng: 1.3966855556e+02,
content:'Saddle = 1802.300049 pos = 37.8572,139.6686 diff = 221.399902'
});
data_peak.push({
lat: 3.7872444444e+01,
lng: 1.3965477778e+02,
cert : false,
content:' Peak = 2012.800049 pos = 37.8724,139.6548 diff = 159.700073'
});
data_saddle.push({
lat: 3.7877888889e+01,
lng: 1.3964400000e+02,
content:'Saddle = 1853.099976 pos = 37.8779,139.6440 diff = 159.700073'
});
data_peak.push({
lat: 3.7854888889e+01,
lng: 1.3970700000e+02,
cert : true,
content:'Name = Iidesan(JA/NI-008) peak = 2104.300049 pos = 37.8549,139.7070 diff = 226.200073'
});
data_saddle.push({
lat: 3.7842222222e+01,
lng: 1.3967722222e+02,
content:'Saddle = 1878.099976 pos = 37.8422,139.6772 diff = 226.200073'
});
data_peak.push({
lat: 3.7402111111e+01,
lng: 1.4007788889e+02,
cert : false,
content:' Peak = 710.799988 pos = 37.4021,140.0779 diff = 168.000000'
});
data_saddle.push({
lat: 3.7395666667e+01,
lng: 1.4007611111e+02,
content:'Saddle = 542.799988 pos = 37.3957,140.0761 diff = 168.000000'
});
data_peak.push({
lat: 3.7350222222e+01,
lng: 1.4021877778e+02,
cert : true,
content:'Name = JA/FS-137(JA/FS-137) peak = 774.299988 pos = 37.3502,140.2188 diff = 227.200012'
});
data_saddle.push({
lat: 3.7358555556e+01,
lng: 1.4022222222e+02,
content:'Saddle = 547.099976 pos = 37.3586,140.2222 diff = 227.200012'
});
data_peak.push({
lat: 3.7471666667e+01,
lng: 1.3961544444e+02,
cert : true,
content:'Name = JA/FS-124(JA/FS-124) peak = 831.700012 pos = 37.4717,139.6154 diff = 265.299988'
});
data_saddle.push({
lat: 3.7494333334e+01,
lng: 1.3961877778e+02,
content:'Saddle = 566.400024 pos = 37.4943,139.6188 diff = 265.299988'
});
data_peak.push({
lat: 3.7388555556e+01,
lng: 1.3933544444e+02,
cert : false,
content:' Peak = 827.000000 pos = 37.3886,139.3354 diff = 244.400024'
});
data_saddle.push({
lat: 3.7403666667e+01,
lng: 1.3933188889e+02,
content:'Saddle = 582.599976 pos = 37.4037,139.3319 diff = 244.400024'
});
data_peak.push({
lat: 3.7664666667e+01,
lng: 1.3932244444e+02,
cert : true,
content:'Name = JA/NI-077(JA/NI-077) peak = 864.799988 pos = 37.6647,139.3224 diff = 275.000000'
});
data_saddle.push({
lat: 3.7639000000e+01,
lng: 1.3932877778e+02,
content:'Saddle = 589.799988 pos = 37.6390,139.3288 diff = 275.000000'
});
data_peak.push({
lat: 3.7350222222e+01,
lng: 1.3930033333e+02,
cert : false,
content:' Peak = 760.599976 pos = 37.3502,139.3003 diff = 168.500000'
});
data_saddle.push({
lat: 3.7346000000e+01,
lng: 1.3929211111e+02,
content:'Saddle = 592.099976 pos = 37.3460,139.2921 diff = 168.500000'
});
data_peak.push({
lat: 3.7334111111e+01,
lng: 1.3942555556e+02,
cert : false,
content:' Peak = 963.500000 pos = 37.3341,139.4256 diff = 370.700012'
});
data_saddle.push({
lat: 3.7350111111e+01,
lng: 1.3947877778e+02,
content:'Saddle = 592.799988 pos = 37.3501,139.4788 diff = 370.700012'
});
data_peak.push({
lat: 3.7362000000e+01,
lng: 1.3933522222e+02,
cert : true,
content:'Name = JA/FS-117(JA/FS-117) peak = 870.700012 pos = 37.3620,139.3352 diff = 242.200012'
});
data_saddle.push({
lat: 3.7355111111e+01,
lng: 1.3935555556e+02,
content:'Saddle = 628.500000 pos = 37.3551,139.3556 diff = 242.200012'
});
data_peak.push({
lat: 3.7381555556e+01,
lng: 1.3936144444e+02,
cert : false,
content:' Peak = 912.700012 pos = 37.3816,139.3614 diff = 210.200012'
});
data_saddle.push({
lat: 3.7375555556e+01,
lng: 1.3936933333e+02,
content:'Saddle = 702.500000 pos = 37.3756,139.3693 diff = 210.200012'
});
data_peak.push({
lat: 3.7356555556e+01,
lng: 1.3939411111e+02,
cert : true,
content:'Name = JA/FS-103(JA/FS-103) peak = 911.500000 pos = 37.3566,139.3941 diff = 179.900024'
});
data_saddle.push({
lat: 3.7350111111e+01,
lng: 1.3940600000e+02,
content:'Saddle = 731.599976 pos = 37.3501,139.4060 diff = 179.900024'
});
data_peak.push({
lat: 3.7391111111e+01,
lng: 1.4011255556e+02,
cert : false,
content:' Peak = 752.599976 pos = 37.3911,140.1126 diff = 154.399963'
});
data_saddle.push({
lat: 3.7386888889e+01,
lng: 1.4010077778e+02,
content:'Saddle = 598.200012 pos = 37.3869,140.1008 diff = 154.399963'
});
data_peak.push({
lat: 3.7387222222e+01,
lng: 1.3994644444e+02,
cert : false,
content:' Peak = 770.799988 pos = 37.3872,139.9464 diff = 171.399963'
});
data_saddle.push({
lat: 3.7394666667e+01,
lng: 1.3995555556e+02,
content:'Saddle = 599.400024 pos = 37.3947,139.9556 diff = 171.399963'
});
data_peak.push({
lat: 3.7614444445e+01,
lng: 1.3919500000e+02,
cert : true,
content:'Name = JA/NI-061(JA/NI-061) peak = 1011.900024 pos = 37.6144,139.1950 diff = 410.000000'
});
data_saddle.push({
lat: 3.7586444445e+01,
lng: 1.3917700000e+02,
content:'Saddle = 601.900024 pos = 37.5864,139.1770 diff = 410.000000'
});
data_peak.push({
lat: 3.7409888889e+01,
lng: 1.3994900000e+02,
cert : false,
content:' Peak = 760.500000 pos = 37.4099,139.9490 diff = 157.299988'
});
data_saddle.push({
lat: 3.7413111111e+01,
lng: 1.3995622222e+02,
content:'Saddle = 603.200012 pos = 37.4131,139.9562 diff = 157.299988'
});
data_peak.push({
lat: 3.7460444445e+01,
lng: 1.3955811111e+02,
cert : true,
content:'Name = JA/FS-130(JA/FS-130) peak = 812.900024 pos = 37.4604,139.5581 diff = 209.600037'
});
data_saddle.push({
lat: 3.7450666667e+01,
lng: 1.3955822222e+02,
content:'Saddle = 603.299988 pos = 37.4507,139.5582 diff = 209.600037'
});
data_peak.push({
lat: 3.6823111112e+01,
lng: 1.3974966667e+02,
cert : false,
content:' Peak = 773.500000 pos = 36.8231,139.7497 diff = 170.099976'
});
data_saddle.push({
lat: 3.6827777778e+01,
lng: 1.3974188889e+02,
content:'Saddle = 603.400024 pos = 36.8278,139.7419 diff = 170.099976'
});
data_peak.push({
lat: 3.7422333334e+01,
lng: 1.3958633333e+02,
cert : true,
content:'Name = JA/FS-059(JA/FS-059) peak = 1091.900024 pos = 37.4223,139.5863 diff = 480.000000'
});
data_saddle.push({
lat: 3.7392444445e+01,
lng: 1.3960088889e+02,
content:'Saddle = 611.900024 pos = 37.3924,139.6009 diff = 480.000000'
});
data_peak.push({
lat: 3.7444666667e+01,
lng: 1.3956611111e+02,
cert : true,
content:'Name = JA/FS-123(JA/FS-123) peak = 834.299988 pos = 37.4447,139.5661 diff = 202.700012'
});
data_saddle.push({
lat: 3.7438444445e+01,
lng: 1.3956855556e+02,
content:'Saddle = 631.599976 pos = 37.4384,139.5686 diff = 202.700012'
});
data_peak.push({
lat: 3.7261444445e+01,
lng: 1.3907477778e+02,
cert : true,
content:'Name = JA/NI-052(JA/NI-052) peak = 1076.000000 pos = 37.2614,139.0748 diff = 455.000000'
});
data_saddle.push({
lat: 3.7227222223e+01,
lng: 1.3911811111e+02,
content:'Saddle = 621.000000 pos = 37.2272,139.1181 diff = 455.000000'
});
data_peak.push({
lat: 3.7300666667e+01,
lng: 1.3908922222e+02,
cert : true,
content:'Name = JA/NI-071(JA/NI-071) peak = 933.200012 pos = 37.3007,139.0892 diff = 201.200012'
});
data_saddle.push({
lat: 3.7267000000e+01,
lng: 1.3908855556e+02,
content:'Saddle = 732.000000 pos = 37.2670,139.0886 diff = 201.200012'
});
data_peak.push({
lat: 3.7269000000e+01,
lng: 1.3904255556e+02,
cert : true,
content:'Name = JA/NI-063(JA/NI-063) peak = 996.700012 pos = 37.2690,139.0426 diff = 243.799988'
});
data_saddle.push({
lat: 3.7266111111e+01,
lng: 1.3905044444e+02,
content:'Saddle = 752.900024 pos = 37.2661,139.0504 diff = 243.799988'
});
data_peak.push({
lat: 3.7427111111e+01,
lng: 1.4006188889e+02,
cert : false,
content:' Peak = 802.200012 pos = 37.4271,140.0619 diff = 175.500000'
});
data_saddle.push({
lat: 3.7413000000e+01,
lng: 1.4005077778e+02,
content:'Saddle = 626.700012 pos = 37.4130,140.0508 diff = 175.500000'
});
data_peak.push({
lat: 3.7374666667e+01,
lng: 1.3948533333e+02,
cert : false,
content:' Peak = 960.599976 pos = 37.3747,139.4853 diff = 329.399963'
});
data_saddle.push({
lat: 3.7355333334e+01,
lng: 1.3954733333e+02,
content:'Saddle = 631.200012 pos = 37.3553,139.5473 diff = 329.399963'
});
data_peak.push({
lat: 3.7408000000e+01,
lng: 1.3950077778e+02,
cert : true,
content:'Name = JA/FS-107(JA/FS-107) peak = 893.700012 pos = 37.4080,139.5008 diff = 211.100037'
});
data_saddle.push({
lat: 3.7394777778e+01,
lng: 1.3951255556e+02,
content:'Saddle = 682.599976 pos = 37.3948,139.5126 diff = 211.100037'
});
data_peak.push({
lat: 3.7392222222e+01,
lng: 1.3953666667e+02,
cert : true,
content:'Name = JA/FS-095(JA/FS-095) peak = 942.500000 pos = 37.3922,139.5367 diff = 225.099976'
});
data_saddle.push({
lat: 3.7369222222e+01,
lng: 1.3950255556e+02,
content:'Saddle = 717.400024 pos = 37.3692,139.5026 diff = 225.099976'
});
data_peak.push({
lat: 3.7317000000e+01,
lng: 1.3947244444e+02,
cert : false,
content:' Peak = 792.200012 pos = 37.3170,139.4724 diff = 150.400024'
});
data_saddle.push({
lat: 3.7316888889e+01,
lng: 1.3947911111e+02,
content:'Saddle = 641.799988 pos = 37.3169,139.4791 diff = 150.400024'
});
data_peak.push({
lat: 3.7438555556e+01,
lng: 1.3995544444e+02,
cert : true,
content:'Name = JA/FS-128(JA/FS-128) peak = 818.000000 pos = 37.4386,139.9554 diff = 176.000000'
});
data_saddle.push({
lat: 3.7426444445e+01,
lng: 1.3995966667e+02,
content:'Saddle = 642.000000 pos = 37.4264,139.9597 diff = 176.000000'
});
data_peak.push({
lat: 3.7376444445e+01,
lng: 1.3997322222e+02,
cert : true,
content:'Name = JA/FS-116(JA/FS-116) peak = 872.400024 pos = 37.3764,139.9732 diff = 228.400024'
});
data_saddle.push({
lat: 3.7380000000e+01,
lng: 1.3997655556e+02,
content:'Saddle = 644.000000 pos = 37.3800,139.9766 diff = 228.400024'
});
data_peak.push({
lat: 3.7308444445e+01,
lng: 1.3963344444e+02,
cert : false,
content:' Peak = 810.000000 pos = 37.3084,139.6334 diff = 161.700012'
});
data_saddle.push({
lat: 3.7307222222e+01,
lng: 1.3964044444e+02,
content:'Saddle = 648.299988 pos = 37.3072,139.6404 diff = 161.700012'
});
data_peak.push({
lat: 3.7285555556e+01,
lng: 1.3989588889e+02,
cert : false,
content:' Peak = 853.799988 pos = 37.2856,139.8959 diff = 184.899963'
});
data_saddle.push({
lat: 3.7284777778e+01,
lng: 1.3988500000e+02,
content:'Saddle = 668.900024 pos = 37.2848,139.8850 diff = 184.899963'
});
data_peak.push({
lat: 3.7402555556e+01,
lng: 1.3968677778e+02,
cert : true,
content:'Name = JA/FS-102(JA/FS-102) peak = 910.500000 pos = 37.4026,139.6868 diff = 239.299988'
});
data_saddle.push({
lat: 3.7395888889e+01,
lng: 1.3967422222e+02,
content:'Saddle = 671.200012 pos = 37.3959,139.6742 diff = 239.299988'
});
data_peak.push({
lat: 3.7430666667e+01,
lng: 1.3929800000e+02,
cert : false,
content:' Peak = 823.400024 pos = 37.4307,139.2980 diff = 151.000000'
});
data_saddle.push({
lat: 3.7432222222e+01,
lng: 1.3928933333e+02,
content:'Saddle = 672.400024 pos = 37.4322,139.2893 diff = 151.000000'
});
data_peak.push({
lat: 3.7383666667e+01,
lng: 1.3957522222e+02,
cert : true,
content:'Name = JA/FS-097(JA/FS-097) peak = 925.299988 pos = 37.3837,139.5752 diff = 251.899963'
});
data_saddle.push({
lat: 3.7377000000e+01,
lng: 1.3957944444e+02,
content:'Saddle = 673.400024 pos = 37.3770,139.5794 diff = 251.899963'
});
data_peak.push({
lat: 3.7296888889e+01,
lng: 1.3992133333e+02,
cert : true,
content:'Name = JA/FS-096(JA/FS-096) peak = 940.500000 pos = 37.2969,139.9213 diff = 266.799988'
});
data_saddle.push({
lat: 3.7294333334e+01,
lng: 1.3992711111e+02,
content:'Saddle = 673.700012 pos = 37.2943,139.9271 diff = 266.799988'
});
data_peak.push({
lat: 3.6839333334e+01,
lng: 1.3979333333e+02,
cert : true,
content:'Name = JA/TG-054(JA/TG-054) peak = 891.099976 pos = 36.8393,139.7933 diff = 208.699951'
});
data_saddle.push({
lat: 3.6851444445e+01,
lng: 1.3978888889e+02,
content:'Saddle = 682.400024 pos = 36.8514,139.7889 diff = 208.699951'
});
data_peak.push({
lat: 3.7301222223e+01,
lng: 1.3932500000e+02,
cert : false,
content:' Peak = 842.700012 pos = 37.3012,139.3250 diff = 159.799988'
});
data_saddle.push({
lat: 3.7290111111e+01,
lng: 1.3933288889e+02,
content:'Saddle = 682.900024 pos = 37.2901,139.3329 diff = 159.799988'
});
data_peak.push({
lat: 3.7387333334e+01,
lng: 1.3930311111e+02,
cert : true,
content:'Name = JA/FS-104(JA/FS-104) peak = 902.099976 pos = 37.3873,139.3031 diff = 219.099976'
});
data_saddle.push({
lat: 3.7391888889e+01,
lng: 1.3928377778e+02,
content:'Saddle = 683.000000 pos = 37.3919,139.2838 diff = 219.099976'
});
data_peak.push({
lat: 3.7266555556e+01,
lng: 1.3992822222e+02,
cert : false,
content:' Peak = 843.400024 pos = 37.2666,139.9282 diff = 150.500000'
});
data_saddle.push({
lat: 3.7265333334e+01,
lng: 1.3993266667e+02,
content:'Saddle = 692.900024 pos = 37.2653,139.9327 diff = 150.500000'
});
data_peak.push({
lat: 3.7555222222e+01,
lng: 1.3918866667e+02,
cert : true,
content:'Name = Awagatake(JA/NI-037) peak = 1291.900024 pos = 37.5552,139.1887 diff = 594.400024'
});
data_saddle.push({
lat: 3.7469333334e+01,
lng: 1.3926388889e+02,
content:'Saddle = 697.500000 pos = 37.4693,139.2639 diff = 594.400024'
});
data_peak.push({
lat: 3.7599888889e+01,
lng: 1.3936555556e+02,
cert : true,
content:'Name = JA/NI-048(JA/NI-048) peak = 1105.300049 pos = 37.5999,139.3656 diff = 402.200073'
});
data_saddle.push({
lat: 3.7539333334e+01,
lng: 1.3932788889e+02,
content:'Saddle = 703.099976 pos = 37.5393,139.3279 diff = 402.200073'
});
data_peak.push({
lat: 3.7560000000e+01,
lng: 1.3931922222e+02,
cert : true,
content:'Name = JA/NI-073(JA/NI-073) peak = 916.500000 pos = 37.5600,139.3192 diff = 174.299988'
});
data_saddle.push({
lat: 3.7564222222e+01,
lng: 1.3934688889e+02,
content:'Saddle = 742.200012 pos = 37.5642,139.3469 diff = 174.299988'
});
data_peak.push({
lat: 3.7622444445e+01,
lng: 1.3934533333e+02,
cert : true,
content:'Name = JA/NI-051(JA/NI-051) peak = 1080.500000 pos = 37.6224,139.3453 diff = 261.500000'
});
data_saddle.push({
lat: 3.7596555556e+01,
lng: 1.3935100000e+02,
content:'Saddle = 819.000000 pos = 37.5966,139.3510 diff = 261.500000'
});
data_peak.push({
lat: 3.7541888889e+01,
lng: 1.3930666667e+02,
cert : true,
content:'Name = JA/NI-074(JA/NI-074) peak = 915.200012 pos = 37.5419,139.3067 diff = 195.799988'
});
data_saddle.push({
lat: 3.7533444445e+01,
lng: 1.3929900000e+02,
content:'Saddle = 719.400024 pos = 37.5334,139.2990 diff = 195.799988'
});
data_peak.push({
lat: 3.7512555556e+01,
lng: 1.3926633333e+02,
cert : true,
content:'Name = Yahazudake(JA/NI-039) peak = 1253.300049 pos = 37.5126,139.2663 diff = 414.800049'
});
data_saddle.push({
lat: 3.7554888889e+01,
lng: 1.3923400000e+02,
content:'Saddle = 838.500000 pos = 37.5549,139.2340 diff = 414.800049'
});
data_peak.push({
lat: 3.7485000000e+01,
lng: 1.3929833333e+02,
cert : true,
content:'Name = JA/NI-049(JA/NI-049) peak = 1094.900024 pos = 37.4850,139.2983 diff = 212.900024'
});
data_saddle.push({
lat: 3.7496555556e+01,
lng: 1.3929077778e+02,
content:'Saddle = 882.000000 pos = 37.4966,139.2908 diff = 212.900024'
});
data_peak.push({
lat: 3.7539888889e+01,
lng: 1.3928222222e+02,
cert : false,
content:' Peak = 1112.500000 pos = 37.5399,139.2822 diff = 200.400024'
});
data_saddle.push({
lat: 3.7542222222e+01,
lng: 1.3927666667e+02,
content:'Saddle = 912.099976 pos = 37.5422,139.2767 diff = 200.400024'
});
data_peak.push({
lat: 3.7537333334e+01,
lng: 1.3925733333e+02,
cert : true,
content:'Name = JA/NI-041(JA/NI-041) peak = 1214.099976 pos = 37.5373,139.2573 diff = 272.099976'
});
data_saddle.push({
lat: 3.7529666667e+01,
lng: 1.3925633333e+02,
content:'Saddle = 942.000000 pos = 37.5297,139.2563 diff = 272.099976'
});
data_peak.push({
lat: 3.7513000000e+01,
lng: 1.3930300000e+02,
cert : false,
content:' Peak = 1120.699951 pos = 37.5130,139.3030 diff = 167.799927'
});
data_saddle.push({
lat: 3.7507666667e+01,
lng: 1.3928177778e+02,
content:'Saddle = 952.900024 pos = 37.5077,139.2818 diff = 167.799927'
});
data_peak.push({
lat: 3.7563888889e+01,
lng: 1.3924311111e+02,
cert : true,
content:'Name = JA/NI-055(JA/NI-055) peak = 1042.300049 pos = 37.5639,139.2431 diff = 183.300049'
});
data_saddle.push({
lat: 3.7556222222e+01,
lng: 1.3922444444e+02,
content:'Saddle = 859.000000 pos = 37.5562,139.2244 diff = 183.300049'
});
data_peak.push({
lat: 3.7544666667e+01,
lng: 1.3956877778e+02,
cert : true,
content:'Name = JA/FS-093(JA/FS-093) peak = 950.099976 pos = 37.5447,139.5688 diff = 242.799988'
});
data_saddle.push({
lat: 3.7518888889e+01,
lng: 1.3958655556e+02,
content:'Saddle = 707.299988 pos = 37.5189,139.5866 diff = 242.799988'
});
data_peak.push({
lat: 3.7477555556e+01,
lng: 1.3921933333e+02,
cert : false,
content:' Peak = 875.700012 pos = 37.4776,139.2193 diff = 160.200012'
});
data_saddle.push({
lat: 3.7473666667e+01,
lng: 1.3922266667e+02,
content:'Saddle = 715.500000 pos = 37.4737,139.2227 diff = 160.200012'
});
data_peak.push({
lat: 3.7509666667e+01,
lng: 1.3960311111e+02,
cert : true,
content:'Name = JA/FS-080(JA/FS-080) peak = 980.200012 pos = 37.5097,139.6031 diff = 257.600037'
});
data_saddle.push({
lat: 3.7511333334e+01,
lng: 1.3954100000e+02,
content:'Saddle = 722.599976 pos = 37.5113,139.5410 diff = 257.600037'
});
data_peak.push({
lat: 3.6719444445e+01,
lng: 1.3961677778e+02,
cert : true,
content:'Name = JA/TG-053(JA/TG-053) peak = 891.700012 pos = 36.7194,139.6168 diff = 168.500000'
});
data_saddle.push({
lat: 3.6721222223e+01,
lng: 1.3961022222e+02,
content:'Saddle = 723.200012 pos = 36.7212,139.6102 diff = 168.500000'
});
data_peak.push({
lat: 3.7401444445e+01,
lng: 1.3965811111e+02,
cert : false,
content:' Peak = 875.000000 pos = 37.4014,139.6581 diff = 151.700012'
});
data_saddle.push({
lat: 3.7399111111e+01,
lng: 1.3965900000e+02,
content:'Saddle = 723.299988 pos = 37.3991,139.6590 diff = 151.700012'
});
data_peak.push({
lat: 3.7010333334e+01,
lng: 1.3877355556e+02,
cert : true,
content:'Name = JA/NI-059(JA/NI-059) peak = 1021.599976 pos = 37.0103,138.7736 diff = 294.399963'
});
data_saddle.push({
lat: 3.6991111112e+01,
lng: 1.3877166667e+02,
content:'Saddle = 727.200012 pos = 36.9911,138.7717 diff = 294.399963'
});
data_peak.push({
lat: 3.7165888889e+01,
lng: 1.3978222222e+02,
cert : true,
content:'Name = JA/FS-078(JA/FS-078) peak = 982.700012 pos = 37.1659,139.7822 diff = 254.900024'
});
data_saddle.push({
lat: 3.7158555556e+01,
lng: 1.3977888889e+02,
content:'Saddle = 727.799988 pos = 37.1586,139.7789 diff = 254.900024'
});
data_peak.push({
lat: 3.7175333334e+01,
lng: 1.3978000000e+02,
cert : true,
content:'Name = JA/FS-090(JA/FS-090) peak = 961.599976 pos = 37.1753,139.7800 diff = 165.500000'
});
data_saddle.push({
lat: 3.7172222223e+01,
lng: 1.3977811111e+02,
content:'Saddle = 796.099976 pos = 37.1722,139.7781 diff = 165.500000'
});
data_peak.push({
lat: 3.7475888889e+01,
lng: 1.3946444444e+02,
cert : true,
content:'Name = JA/FS-099(JA/FS-099) peak = 921.400024 pos = 37.4759,139.4644 diff = 189.500000'
});
data_saddle.push({
lat: 3.7484111111e+01,
lng: 1.3946888889e+02,
content:'Saddle = 731.900024 pos = 37.4841,139.4689 diff = 189.500000'
});
data_peak.push({
lat: 3.7336888889e+01,
lng: 1.3995300000e+02,
cert : true,
content:'Name = JA/FS-030(JA/FS-030) peak = 1414.000000 pos = 37.3369,139.9530 diff = 680.099976'
});
data_saddle.push({
lat: 3.7214444445e+01,
lng: 1.4007011111e+02,
content:'Saddle = 733.900024 pos = 37.2144,140.0701 diff = 680.099976'
});
data_peak.push({
lat: 3.7338444445e+01,
lng: 1.4016688889e+02,
cert : true,
content:'Name = JA/FS-058(JA/FS-058) peak = 1101.400024 pos = 37.3384,140.1669 diff = 364.400024'
});
data_saddle.push({
lat: 3.7331888889e+01,
lng: 1.4012533333e+02,
content:'Saddle = 737.000000 pos = 37.3319,140.1253 diff = 364.400024'
});
data_peak.push({
lat: 3.7441888889e+01,
lng: 1.4020377778e+02,
cert : true,
content:'Name = JA/FS-065(JA/FS-065) peak = 1055.099976 pos = 37.4419,140.2038 diff = 277.000000'
});
data_saddle.push({
lat: 3.7360111111e+01,
lng: 1.4017966667e+02,
content:'Saddle = 778.099976 pos = 37.3601,140.1797 diff = 277.000000'
});
data_peak.push({
lat: 3.7374111111e+01,
lng: 1.4020422222e+02,
cert : false,
content:' Peak = 967.000000 pos = 37.3741,140.2042 diff = 157.700012'
});
data_saddle.push({
lat: 3.7378777778e+01,
lng: 1.4019855556e+02,
content:'Saddle = 809.299988 pos = 37.3788,140.1986 diff = 157.700012'
});
data_peak.push({
lat: 3.7447333334e+01,
lng: 1.4017877778e+02,
cert : false,
content:' Peak = 1034.199951 pos = 37.4473,140.1788 diff = 162.599976'
});
data_saddle.push({
lat: 3.7454000000e+01,
lng: 1.4020411111e+02,
content:'Saddle = 871.599976 pos = 37.4540,140.2041 diff = 162.599976'
});
data_peak.push({
lat: 3.7338777778e+01,
lng: 1.4009588889e+02,
cert : true,
content:'Name = JA/FS-079(JA/FS-079) peak = 980.700012 pos = 37.3388,140.0959 diff = 237.500000'
});
data_saddle.push({
lat: 3.7329000000e+01,
lng: 1.4009911111e+02,
content:'Saddle = 743.200012 pos = 37.3290,140.0991 diff = 237.500000'
});
data_peak.push({
lat: 3.7257000000e+01,
lng: 1.4012855556e+02,
cert : false,
content:' Peak = 975.599976 pos = 37.2570,140.1286 diff = 158.599976'
});
data_saddle.push({
lat: 3.7264111111e+01,
lng: 1.4011311111e+02,
content:'Saddle = 817.000000 pos = 37.2641,140.1131 diff = 158.599976'
});
data_peak.push({
lat: 3.7271888889e+01,
lng: 1.4011555556e+02,
cert : true,
content:'Name = JA/FS-076(JA/FS-076) peak = 986.400024 pos = 37.2719,140.1156 diff = 168.500000'
});
data_saddle.push({
lat: 3.7301555556e+01,
lng: 1.4009722222e+02,
content:'Saddle = 817.900024 pos = 37.3016,140.0972 diff = 168.500000'
});
data_peak.push({
lat: 3.7302000000e+01,
lng: 1.3996977778e+02,
cert : false,
content:' Peak = 996.700012 pos = 37.3020,139.9698 diff = 174.000000'
});
data_saddle.push({
lat: 3.7303000000e+01,
lng: 1.3998355556e+02,
content:'Saddle = 822.700012 pos = 37.3030,139.9836 diff = 174.000000'
});
data_peak.push({
lat: 3.7305666667e+01,
lng: 1.4011722222e+02,
cert : false,
content:' Peak = 1020.799988 pos = 37.3057,140.1172 diff = 171.200012'
});
data_saddle.push({
lat: 3.7311111111e+01,
lng: 1.4011133333e+02,
content:'Saddle = 849.599976 pos = 37.3111,140.1113 diff = 171.200012'
});
data_peak.push({
lat: 3.7328000000e+01,
lng: 1.4000677778e+02,
cert : true,
content:'Name = JA/FS-056(JA/FS-056) peak = 1145.000000 pos = 37.3280,140.0068 diff = 282.700012'
});
data_saddle.push({
lat: 3.7329111111e+01,
lng: 1.3999566667e+02,
content:'Saddle = 862.299988 pos = 37.3291,139.9957 diff = 282.700012'
});
data_peak.push({
lat: 3.7285333334e+01,
lng: 1.4003244444e+02,
cert : false,
content:' Peak = 1022.500000 pos = 37.2853,140.0324 diff = 156.700012'
});
data_saddle.push({
lat: 3.7295222223e+01,
lng: 1.4003188889e+02,
content:'Saddle = 865.799988 pos = 37.2952,140.0319 diff = 156.700012'
});
data_peak.push({
lat: 3.6943777778e+01,
lng: 1.3876944444e+02,
cert : true,
content:'Name = JA/NI-043(JA/NI-043) peak = 1180.699951 pos = 36.9438,138.7694 diff = 443.199951'
});
data_saddle.push({
lat: 3.6908666667e+01,
lng: 1.3879111111e+02,
content:'Saddle = 737.500000 pos = 36.9087,138.7911 diff = 443.199951'
});
data_peak.push({
lat: 3.6929111112e+01,
lng: 1.3878311111e+02,
cert : true,
content:'Name = JA/NI-045(JA/NI-045) peak = 1171.300049 pos = 36.9291,138.7831 diff = 179.700073'
});
data_saddle.push({
lat: 3.6936000000e+01,
lng: 1.3877544444e+02,
content:'Saddle = 991.599976 pos = 36.9360,138.7754 diff = 179.700073'
});
data_peak.push({
lat: 3.7417222222e+01,
lng: 1.3971333333e+02,
cert : false,
content:' Peak = 901.500000 pos = 37.4172,139.7133 diff = 158.799988'
});
data_saddle.push({
lat: 3.7396888889e+01,
lng: 1.3972611111e+02,
content:'Saddle = 742.700012 pos = 37.3969,139.7261 diff = 158.799988'
});
data_peak.push({
lat: 3.7305000000e+01,
lng: 1.3986455556e+02,
cert : true,
content:'Name = JA/FS-071(JA/FS-071) peak = 1000.799988 pos = 37.3050,139.8646 diff = 255.899963'
});
data_saddle.push({
lat: 3.7310555556e+01,
lng: 1.3985188889e+02,
content:'Saddle = 744.900024 pos = 37.3106,139.8519 diff = 255.899963'
});
data_peak.push({
lat: 3.7428000000e+01,
lng: 1.3975966667e+02,
cert : true,
content:'Name = JA/FS-061(JA/FS-061) peak = 1070.400024 pos = 37.4280,139.7597 diff = 322.800049'
});
data_saddle.push({
lat: 3.7403111111e+01,
lng: 1.3976322222e+02,
content:'Saddle = 747.599976 pos = 37.4031,139.7632 diff = 322.800049'
});
data_peak.push({
lat: 3.7293777778e+01,
lng: 1.3966977778e+02,
cert : true,
content:'Name = JA/FS-088(JA/FS-088) peak = 962.799988 pos = 37.2938,139.6698 diff = 213.799988'
});
data_saddle.push({
lat: 3.7280111111e+01,
lng: 1.3968388889e+02,
content:'Saddle = 749.000000 pos = 37.2801,139.6839 diff = 213.799988'
});
data_peak.push({
lat: 3.6847000000e+01,
lng: 1.3975622222e+02,
cert : false,
content:' Peak = 902.700012 pos = 36.8470,139.7562 diff = 153.600037'
});
data_saddle.push({
lat: 3.6855222223e+01,
lng: 1.3976166667e+02,
content:'Saddle = 749.099976 pos = 36.8552,139.7617 diff = 153.600037'
});
data_peak.push({
lat: 3.6833444445e+01,
lng: 1.3969288889e+02,
cert : true,
content:'Name = JA/TG-051(JA/TG-051) peak = 963.700012 pos = 36.8334,139.6929 diff = 211.200012'
});
data_saddle.push({
lat: 3.6840333334e+01,
lng: 1.3968100000e+02,
content:'Saddle = 752.500000 pos = 36.8403,139.6810 diff = 211.200012'
});
data_peak.push({
lat: 3.7213666667e+01,
lng: 1.3913944444e+02,
cert : true,
content:'Name = JA/NI-070(JA/NI-070) peak = 938.400024 pos = 37.2137,139.1394 diff = 185.000000'
});
data_saddle.push({
lat: 3.7204777778e+01,
lng: 1.3912488889e+02,
content:'Saddle = 753.400024 pos = 37.2048,139.1249 diff = 185.000000'
});
data_peak.push({
lat: 3.6799333334e+01,
lng: 1.3840377778e+02,
cert : true,
content:'Name = Koushasan (Takaifuji)(JA/NN-145) peak = 1350.800049 pos = 36.7993,138.4038 diff = 591.600037'
});
data_saddle.push({
lat: 3.6781444445e+01,
lng: 1.3843022222e+02,
content:'Saddle = 759.200012 pos = 36.7814,138.4302 diff = 591.600037'
});
data_peak.push({
lat: 3.6790888889e+01,
lng: 1.3842177778e+02,
cert : false,
content:' Peak = 1060.300049 pos = 36.7909,138.4218 diff = 183.300049'
});
data_saddle.push({
lat: 3.6789444445e+01,
lng: 1.3841544444e+02,
content:'Saddle = 877.000000 pos = 36.7894,138.4154 diff = 183.300049'
});
data_peak.push({
lat: 3.6873888889e+01,
lng: 1.3971300000e+02,
cert : false,
content:' Peak = 950.900024 pos = 36.8739,139.7130 diff = 184.000000'
});
data_saddle.push({
lat: 3.6886111112e+01,
lng: 1.3972355556e+02,
content:'Saddle = 766.900024 pos = 36.8861,139.7236 diff = 184.000000'
});
data_peak.push({
lat: 3.6956333334e+01,
lng: 1.3883300000e+02,
cert : true,
content:'Name = JA/NI-047(JA/NI-047) peak = 1110.500000 pos = 36.9563,138.8330 diff = 337.599976'
});
data_saddle.push({
lat: 3.6963333334e+01,
lng: 1.3885700000e+02,
content:'Saddle = 772.900024 pos = 36.9633,138.8570 diff = 337.599976'
});
data_peak.push({
lat: 3.6974222223e+01,
lng: 1.3885466667e+02,
cert : false,
content:' Peak = 944.599976 pos = 36.9742,138.8547 diff = 161.899963'
});
data_saddle.push({
lat: 3.6967222223e+01,
lng: 1.3884411111e+02,
content:'Saddle = 782.700012 pos = 36.9672,138.8441 diff = 161.899963'
});
data_peak.push({
lat: 3.7194777778e+01,
lng: 1.3913200000e+02,
cert : true,
content:'Name = JA/NI-056(JA/NI-056) peak = 1031.699951 pos = 37.1948,139.1320 diff = 256.099976'
});
data_saddle.push({
lat: 3.7176333334e+01,
lng: 1.3912533333e+02,
content:'Saddle = 775.599976 pos = 37.1763,139.1253 diff = 256.099976'
});
data_peak.push({
lat: 3.7512444445e+01,
lng: 1.3949744444e+02,
cert : false,
content:' Peak = 1133.099976 pos = 37.5124,139.4974 diff = 355.000000'
});
data_saddle.push({
lat: 3.7505333334e+01,
lng: 1.3947255556e+02,
content:'Saddle = 778.099976 pos = 37.5053,139.4726 diff = 355.000000'
});
data_peak.push({
lat: 3.7429888889e+01,
lng: 1.3935977778e+02,
cert : false,
content:' Peak = 991.500000 pos = 37.4299,139.3598 diff = 208.200012'
});
data_saddle.push({
lat: 3.7433222222e+01,
lng: 1.3935666667e+02,
content:'Saddle = 783.299988 pos = 37.4332,139.3567 diff = 208.200012'
});
data_peak.push({
lat: 3.7521888889e+01,
lng: 1.3942577778e+02,
cert : false,
content:' Peak = 1384.900024 pos = 37.5219,139.4258 diff = 593.100037'
});
data_saddle.push({
lat: 3.7455222222e+01,
lng: 1.3929655556e+02,
content:'Saddle = 791.799988 pos = 37.4552,139.2966 diff = 593.100037'
});
data_peak.push({
lat: 3.7466555556e+01,
lng: 1.3940633333e+02,
cert : true,
content:'Name = JA/FS-040(JA/FS-040) peak = 1313.900024 pos = 37.4666,139.4063 diff = 465.900024'
});
data_saddle.push({
lat: 3.7500000000e+01,
lng: 1.3941200000e+02,
content:'Saddle = 848.000000 pos = 37.5000,139.4120 diff = 465.900024'
});
data_peak.push({
lat: 3.7521222222e+01,
lng: 1.3945744444e+02,
cert : true,
content:'Name = JA/NI-046(JA/NI-046) peak = 1141.800049 pos = 37.5212,139.4574 diff = 260.400024'
});
data_saddle.push({
lat: 3.7517333334e+01,
lng: 1.3945088889e+02,
content:'Saddle = 881.400024 pos = 37.5173,139.4509 diff = 260.400024'
});
data_peak.push({
lat: 3.7406555556e+01,
lng: 1.3974911111e+02,
cert : true,
content:'Name = JA/FS-066(JA/FS-066) peak = 1043.199951 pos = 37.4066,139.7491 diff = 241.099976'
});
data_saddle.push({
lat: 3.7400777778e+01,
lng: 1.3974933333e+02,
content:'Saddle = 802.099976 pos = 37.4008,139.7493 diff = 241.099976'
});
data_peak.push({
lat: 3.7299888889e+01,
lng: 1.3951533333e+02,
cert : false,
content:' Peak = 953.400024 pos = 37.2999,139.5153 diff = 150.400024'
});
data_saddle.push({
lat: 3.7304000000e+01,
lng: 1.3951811111e+02,
content:'Saddle = 803.000000 pos = 37.3040,139.5181 diff = 150.400024'
});
data_peak.push({
lat: 3.7328222222e+01,
lng: 1.3955722222e+02,
cert : false,
content:' Peak = 971.700012 pos = 37.3282,139.5572 diff = 163.000000'
});
data_saddle.push({
lat: 3.7322666667e+01,
lng: 1.3957533333e+02,
content:'Saddle = 808.700012 pos = 37.3227,139.5753 diff = 163.000000'
});
data_peak.push({
lat: 3.7424777778e+01,
lng: 1.3925855556e+02,
cert : true,
content:'Name = JA/FS-067(JA/FS-067) peak = 1033.300049 pos = 37.4248,139.2586 diff = 221.500061'
});
data_saddle.push({
lat: 3.7440222222e+01,
lng: 1.3926033333e+02,
content:'Saddle = 811.799988 pos = 37.4402,139.2603 diff = 221.500061'
});
data_peak.push({
lat: 3.7403222222e+01,
lng: 1.3928511111e+02,
cert : false,
content:' Peak = 983.400024 pos = 37.4032,139.2851 diff = 170.600037'
});
data_saddle.push({
lat: 3.7410111111e+01,
lng: 1.3927055556e+02,
content:'Saddle = 812.799988 pos = 37.4101,139.2706 diff = 170.600037'
});
data_peak.push({
lat: 3.7411444445e+01,
lng: 1.3925488889e+02,
cert : false,
content:' Peak = 1031.400024 pos = 37.4114,139.2549 diff = 159.300049'
});
data_saddle.push({
lat: 3.7417888889e+01,
lng: 1.3925733333e+02,
content:'Saddle = 872.099976 pos = 37.4179,139.2573 diff = 159.300049'
});
data_peak.push({
lat: 3.7368333334e+01,
lng: 1.3962711111e+02,
cert : true,
content:'Name = JA/FS-044(JA/FS-044) peak = 1232.400024 pos = 37.3683,139.6271 diff = 420.600037'
});
data_saddle.push({
lat: 3.7348666667e+01,
lng: 1.3965922222e+02,
content:'Saddle = 811.799988 pos = 37.3487,139.6592 diff = 420.600037'
});
data_peak.push({
lat: 3.7224666667e+01,
lng: 1.3972233333e+02,
cert : true,
content:'Name = JA/FS-070(JA/FS-070) peak = 1023.799988 pos = 37.2247,139.7223 diff = 211.000000'
});
data_saddle.push({
lat: 3.7231222223e+01,
lng: 1.3971466667e+02,
content:'Saddle = 812.799988 pos = 37.2312,139.7147 diff = 211.000000'
});
data_peak.push({
lat: 3.7194666667e+01,
lng: 1.3950611111e+02,
cert : false,
content:' Peak = 993.700012 pos = 37.1947,139.5061 diff = 170.600037'
});
data_saddle.push({
lat: 3.7196333334e+01,
lng: 1.3949633333e+02,
content:'Saddle = 823.099976 pos = 37.1963,139.4963 diff = 170.600037'
});
data_peak.push({
lat: 3.7256333334e+01,
lng: 1.3957011111e+02,
cert : false,
content:' Peak = 999.200012 pos = 37.2563,139.5701 diff = 171.299988'
});
data_saddle.push({
lat: 3.7251777778e+01,
lng: 1.3956377778e+02,
content:'Saddle = 827.900024 pos = 37.2518,139.5638 diff = 171.299988'
});
data_peak.push({
lat: 3.7475111111e+01,
lng: 1.3924900000e+02,
cert : true,
content:'Name = JA/NI-054(JA/NI-054) peak = 1041.199951 pos = 37.4751,139.2490 diff = 208.599976'
});
data_saddle.push({
lat: 3.7468555556e+01,
lng: 1.3925155556e+02,
content:'Saddle = 832.599976 pos = 37.4686,139.2516 diff = 208.599976'
});
data_peak.push({
lat: 3.7428111111e+01,
lng: 1.3923577778e+02,
cert : false,
content:' Peak = 1032.699951 pos = 37.4281,139.2358 diff = 199.799927'
});
data_saddle.push({
lat: 3.7436666667e+01,
lng: 1.3923388889e+02,
content:'Saddle = 832.900024 pos = 37.4367,139.2339 diff = 199.799927'
});
data_peak.push({
lat: 3.6730333334e+01,
lng: 1.3959644444e+02,
cert : true,
content:'Name = JA/TG-048(JA/TG-048) peak = 1102.599976 pos = 36.7303,139.5964 diff = 269.500000'
});
data_saddle.push({
lat: 3.6730333334e+01,
lng: 1.3957977778e+02,
content:'Saddle = 833.099976 pos = 36.7303,139.5798 diff = 269.500000'
});
data_peak.push({
lat: 3.7248000000e+01,
lng: 1.3982200000e+02,
cert : true,
content:'Name = JA/FS-051(JA/FS-051) peak = 1160.400024 pos = 37.2480,139.8220 diff = 322.800049'
});
data_saddle.push({
lat: 3.7235444445e+01,
lng: 1.3976344444e+02,
content:'Saddle = 837.599976 pos = 37.2354,139.7634 diff = 322.800049'
});
data_peak.push({
lat: 3.7292777778e+01,
lng: 1.3957888889e+02,
cert : false,
content:' Peak = 1058.000000 pos = 37.2928,139.5789 diff = 216.099976'
});
data_saddle.push({
lat: 3.7259666667e+01,
lng: 1.3959422222e+02,
content:'Saddle = 841.900024 pos = 37.2597,139.5942 diff = 216.099976'
});
data_peak.push({
lat: 3.7397666667e+01,
lng: 1.3913644444e+02,
cert : true,
content:'Name = Sumondake(JA/NI-024) peak = 1535.599976 pos = 37.3977,139.1364 diff = 683.399963'
});
data_saddle.push({
lat: 3.7396777778e+01,
lng: 1.3920744444e+02,
content:'Saddle = 852.200012 pos = 37.3968,139.2074 diff = 683.399963'
});
data_peak.push({
lat: 3.7452444445e+01,
lng: 1.3925122222e+02,
cert : true,
content:'Name = JA/FS-062(JA/FS-062) peak = 1062.400024 pos = 37.4524,139.2512 diff = 200.700012'
});
data_saddle.push({
lat: 3.7448222222e+01,
lng: 1.3922277778e+02,
content:'Saddle = 861.700012 pos = 37.4482,139.2228 diff = 200.700012'
});
data_peak.push({
lat: 3.7418444445e+01,
lng: 1.3920766667e+02,
cert : true,
content:'Name = JA/FS-049(JA/FS-049) peak = 1195.300049 pos = 37.4184,139.2077 diff = 227.500061'
});
data_saddle.push({
lat: 3.7411555556e+01,
lng: 1.3918277778e+02,
content:'Saddle = 967.799988 pos = 37.4116,139.1828 diff = 227.500061'
});
data_peak.push({
lat: 3.7248888889e+01,
lng: 1.3975277778e+02,
cert : false,
content:' Peak = 1010.900024 pos = 37.2489,139.7528 diff = 158.400024'
});
data_saddle.push({
lat: 3.7249333334e+01,
lng: 1.3974188889e+02,
content:'Saddle = 852.500000 pos = 37.2493,139.7419 diff = 158.400024'
});
data_peak.push({
lat: 3.7390333334e+01,
lng: 1.3972788889e+02,
cert : false,
content:' Peak = 1037.199951 pos = 37.3903,139.7279 diff = 183.199951'
});
data_saddle.push({
lat: 3.7384777778e+01,
lng: 1.3973222222e+02,
content:'Saddle = 854.000000 pos = 37.3848,139.7322 diff = 183.199951'
});
data_peak.push({
lat: 3.7326000000e+01,
lng: 1.3988655556e+02,
cert : true,
content:'Name = Onodake(JA/FS-034) peak = 1382.699951 pos = 37.3260,139.8866 diff = 520.799927'
});
data_saddle.push({
lat: 3.7361222222e+01,
lng: 1.3986822222e+02,
content:'Saddle = 861.900024 pos = 37.3612,139.8682 diff = 520.799927'
});
data_peak.push({
lat: 3.7343666667e+01,
lng: 1.3923355556e+02,
cert : true,
content:'Name = Asakusadake(JA/FS-019) peak = 1584.800049 pos = 37.3437,139.2336 diff = 707.200073'
});
data_saddle.push({
lat: 3.7304444445e+01,
lng: 1.3921711111e+02,
content:'Saddle = 877.599976 pos = 37.3044,139.2171 diff = 707.200073'
});
data_peak.push({
lat: 3.7033333334e+01,
lng: 1.3900911111e+02,
cert : false,
content:' Peak = 1080.500000 pos = 37.0333,139.0091 diff = 199.099976'
});
data_saddle.push({
lat: 3.7022111112e+01,
lng: 1.3900755556e+02,
content:'Saddle = 881.400024 pos = 37.0221,139.0076 diff = 199.099976'
});
data_peak.push({
lat: 3.7106333334e+01,
lng: 1.3950444444e+02,
cert : true,
content:'Name = JA/FS-052(JA/FS-052) peak = 1154.900024 pos = 37.1063,139.5044 diff = 271.500000'
});
data_saddle.push({
lat: 3.7080555556e+01,
lng: 1.3951344444e+02,
content:'Saddle = 883.400024 pos = 37.0806,139.5134 diff = 271.500000'
});
data_peak.push({
lat: 3.6666777778e+01,
lng: 1.3841355556e+02,
cert : false,
content:' Peak = 1170.199951 pos = 36.6668,138.4136 diff = 284.599976'
});
data_saddle.push({
lat: 3.6666888889e+01,
lng: 1.3843222222e+02,
content:'Saddle = 885.599976 pos = 36.6669,138.4322 diff = 284.599976'
});
data_peak.push({
lat: 3.7252444445e+01,
lng: 1.3930722222e+02,
cert : false,
content:' Peak = 1067.599976 pos = 37.2524,139.3072 diff = 165.399963'
});
data_saddle.push({
lat: 3.7248111111e+01,
lng: 1.3930433333e+02,
content:'Saddle = 902.200012 pos = 37.2481,139.3043 diff = 165.399963'
});
data_peak.push({
lat: 3.6702555556e+01,
lng: 1.3957433333e+02,
cert : true,
content:'Name = JA/TG-049(JA/TG-049) peak = 1100.400024 pos = 36.7026,139.5743 diff = 193.600037'
});
data_saddle.push({
lat: 3.6710111112e+01,
lng: 1.3956833333e+02,
content:'Saddle = 906.799988 pos = 36.7101,139.5683 diff = 193.600037'
});
data_peak.push({
lat: 3.7150222223e+01,
lng: 1.3996133333e+02,
cert : true,
content:'Name = Sanbonyaridake(JA/TG-015) peak = 1915.500000 pos = 37.1502,139.9613 diff = 1007.299988'
});
data_saddle.push({
lat: 3.7071000000e+01,
lng: 1.3974666667e+02,
content:'Saddle = 908.200012 pos = 37.0710,139.7467 diff = 1007.299988'
});
data_peak.push({
lat: 3.7001333334e+01,
lng: 1.3977388889e+02,
cert : false,
content:' Peak = 1123.500000 pos = 37.0013,139.7739 diff = 160.200012'
});
data_saddle.push({
lat: 3.7005333334e+01,
lng: 1.3976422222e+02,
content:'Saddle = 963.299988 pos = 37.0053,139.7642 diff = 160.200012'
});
data_peak.push({
lat: 3.7088444445e+01,
lng: 1.3973855556e+02,
cert : true,
content:'Name = JA/FS-045(JA/FS-045) peak = 1221.000000 pos = 37.0884,139.7386 diff = 207.799988'
});
data_saddle.push({
lat: 3.7084333334e+01,
lng: 1.3975733333e+02,
content:'Saddle = 1013.200012 pos = 37.0843,139.7573 diff = 207.799988'
});
data_peak.push({
lat: 3.7129777778e+01,
lng: 1.3978588889e+02,
cert : false,
content:' Peak = 1214.199951 pos = 37.1298,139.7859 diff = 191.999939'
});
data_saddle.push({
lat: 3.7123222223e+01,
lng: 1.3978066667e+02,
content:'Saddle = 1022.200012 pos = 37.1232,139.7807 diff = 191.999939'
});
data_peak.push({
lat: 3.6995000000e+01,
lng: 1.3983211111e+02,
cert : true,
content:'Name = JA/TG-031(JA/TG-031) peak = 1391.599976 pos = 36.9950,139.8321 diff = 368.299988'
});
data_saddle.push({
lat: 3.7016777778e+01,
lng: 1.3980566667e+02,
content:'Saddle = 1023.299988 pos = 37.0168,139.8057 diff = 368.299988'
});
data_peak.push({
lat: 3.6953444445e+01,
lng: 1.3978855556e+02,
cert : false,
content:' Peak = 1182.199951 pos = 36.9534,139.7886 diff = 155.500000'
});
data_saddle.push({
lat: 3.6950444445e+01,
lng: 1.3978433333e+02,
content:'Saddle = 1026.699951 pos = 36.9504,139.7843 diff = 155.500000'
});
data_peak.push({
lat: 3.7008333334e+01,
lng: 1.3979222222e+02,
cert : false,
content:' Peak = 1200.800049 pos = 37.0083,139.7922 diff = 173.200073'
});
data_saddle.push({
lat: 3.7013888889e+01,
lng: 1.3979266667e+02,
content:'Saddle = 1027.599976 pos = 37.0139,139.7927 diff = 173.200073'
});
data_peak.push({
lat: 3.6900000000e+01,
lng: 1.3977666667e+02,
cert : true,
content:'Name = Takaharayama (Shakagadake)(JA/TG-019) peak = 1793.699951 pos = 36.9000,139.7767 diff = 746.299927'
});
data_saddle.push({
lat: 3.6975000000e+01,
lng: 1.3974477778e+02,
content:'Saddle = 1047.400024 pos = 36.9750,139.7448 diff = 746.299927'
});
data_peak.push({
lat: 3.6927444445e+01,
lng: 1.3978755556e+02,
cert : true,
content:'Name = JA/TG-021(JA/TG-021) peak = 1700.599976 pos = 36.9274,139.7876 diff = 192.900024'
});
data_saddle.push({
lat: 3.6914666667e+01,
lng: 1.3977033333e+02,
content:'Saddle = 1507.699951 pos = 36.9147,139.7703 diff = 192.900024'
});
data_peak.push({
lat: 3.7222888889e+01,
lng: 1.3992944444e+02,
cert : false,
content:' Peak = 1283.599976 pos = 37.2229,139.9294 diff = 212.000000'
});
data_saddle.push({
lat: 3.7222888889e+01,
lng: 1.3993355556e+02,
content:'Saddle = 1071.599976 pos = 37.2229,139.9336 diff = 212.000000'
});
data_peak.push({
lat: 3.7110777778e+01,
lng: 1.3975622222e+02,
cert : false,
content:' Peak = 1414.000000 pos = 37.1108,139.7562 diff = 313.300049'
});
data_saddle.push({
lat: 3.7099111111e+01,
lng: 1.3977333333e+02,
content:'Saddle = 1100.699951 pos = 37.0991,139.7733 diff = 313.300049'
});
data_peak.push({
lat: 3.7111000000e+01,
lng: 1.3977611111e+02,
cert : false,
content:' Peak = 1295.800049 pos = 37.1110,139.7761 diff = 152.800049'
});
data_saddle.push({
lat: 3.7110222223e+01,
lng: 1.3976388889e+02,
content:'Saddle = 1143.000000 pos = 37.1102,139.7639 diff = 152.800049'
});
data_peak.push({
lat: 3.7246555556e+01,
lng: 1.3996722222e+02,
cert : true,
content:'Name = Futamatayama(JA/FS-021) peak = 1542.400024 pos = 37.2466,139.9672 diff = 430.500000'
});
data_saddle.push({
lat: 3.7236666667e+01,
lng: 1.3995444444e+02,
content:'Saddle = 1111.900024 pos = 37.2367,139.9544 diff = 430.500000'
});
data_peak.push({
lat: 3.6986000000e+01,
lng: 1.3972866667e+02,
cert : false,
content:' Peak = 1304.000000 pos = 36.9860,139.7287 diff = 156.000000'
});
data_saddle.push({
lat: 3.6995666667e+01,
lng: 1.3975000000e+02,
content:'Saddle = 1148.000000 pos = 36.9957,139.7500 diff = 156.000000'
});
data_peak.push({
lat: 3.7107555556e+01,
lng: 1.3988711111e+02,
cert : false,
content:' Peak = 1356.099976 pos = 37.1076,139.8871 diff = 184.500000'
});
data_saddle.push({
lat: 3.7110555556e+01,
lng: 1.3988000000e+02,
content:'Saddle = 1171.599976 pos = 37.1106,139.8800 diff = 184.500000'
});
data_peak.push({
lat: 3.7024222223e+01,
lng: 1.3975577778e+02,
cert : true,
content:'Name = JA/TG-028(JA/TG-028) peak = 1462.599976 pos = 37.0242,139.7558 diff = 255.500000'
});
data_saddle.push({
lat: 3.7039888889e+01,
lng: 1.3976500000e+02,
content:'Saddle = 1207.099976 pos = 37.0399,139.7650 diff = 255.500000'
});
data_peak.push({
lat: 3.7112888889e+01,
lng: 1.3984000000e+02,
cert : true,
content:'Name = JA/TG-027(JA/TG-027) peak = 1481.900024 pos = 37.1129,139.8400 diff = 271.099976'
});
data_saddle.push({
lat: 3.7106333334e+01,
lng: 1.3983088889e+02,
content:'Saddle = 1210.800049 pos = 37.1063,139.8309 diff = 271.099976'
});
data_peak.push({
lat: 3.7084000000e+01,
lng: 1.3987466667e+02,
cert : false,
content:' Peak = 1403.500000 pos = 37.0840,139.8747 diff = 160.199951'
});
data_saddle.push({
lat: 3.7091111111e+01,
lng: 1.3986388889e+02,
content:'Saddle = 1243.300049 pos = 37.0911,139.8639 diff = 160.199951'
});
data_peak.push({
lat: 3.7112555556e+01,
lng: 1.3991800000e+02,
cert : false,
content:' Peak = 1411.599976 pos = 37.1126,139.9180 diff = 158.900024'
});
data_saddle.push({
lat: 3.7115666667e+01,
lng: 1.3992422222e+02,
content:'Saddle = 1252.699951 pos = 37.1157,139.9242 diff = 158.900024'
});
data_peak.push({
lat: 3.7063555556e+01,
lng: 1.3984444444e+02,
cert : true,
content:'Name = Oosabiyama(JA/TG-017) peak = 1905.199951 pos = 37.0636,139.8444 diff = 642.799927'
});
data_saddle.push({
lat: 3.7101111111e+01,
lng: 1.3981911111e+02,
content:'Saddle = 1262.400024 pos = 37.1011,139.8191 diff = 642.799927'
});
data_peak.push({
lat: 3.7031333334e+01,
lng: 1.3982522222e+02,
cert : false,
content:' Peak = 1640.099976 pos = 37.0313,139.8252 diff = 151.299927'
});
data_saddle.push({
lat: 3.7034222223e+01,
lng: 1.3982088889e+02,
content:'Saddle = 1488.800049 pos = 37.0342,139.8209 diff = 151.299927'
});
data_peak.push({
lat: 3.7038888889e+01,
lng: 1.3979300000e+02,
cert : true,
content:'Name = JA/TG-018(JA/TG-018) peak = 1846.599976 pos = 37.0389,139.7930 diff = 245.099976'
});
data_saddle.push({
lat: 3.7068000000e+01,
lng: 1.3982255556e+02,
content:'Saddle = 1601.500000 pos = 37.0680,139.8226 diff = 245.099976'
});
data_peak.push({
lat: 3.7117888889e+01,
lng: 1.3981588889e+02,
cert : true,
content:'Name = JA/TG-026(JA/TG-026) peak = 1500.699951 pos = 37.1179,139.8159 diff = 219.500000'
});
data_saddle.push({
lat: 3.7124111111e+01,
lng: 1.3982366667e+02,
content:'Saddle = 1281.199951 pos = 37.1241,139.8237 diff = 219.500000'
});
data_peak.push({
lat: 3.7202000000e+01,
lng: 1.3998322222e+02,
cert : true,
content:'Name = JA/FS-013(JA/FS-013) peak = 1641.300049 pos = 37.2020,139.9832 diff = 259.200073'
});
data_saddle.push({
lat: 3.7193555556e+01,
lng: 1.3997400000e+02,
content:'Saddle = 1382.099976 pos = 37.1936,139.9740 diff = 259.200073'
});
data_peak.push({
lat: 3.7157777778e+01,
lng: 1.3990277778e+02,
cert : true,
content:'Name = JA/FS-006(JA/FS-006) peak = 1885.699951 pos = 37.1578,139.9028 diff = 428.399902'
});
data_saddle.push({
lat: 3.7153333334e+01,
lng: 1.3994155556e+02,
content:'Saddle = 1457.300049 pos = 37.1533,139.9416 diff = 428.399902'
});
data_peak.push({
lat: 3.7180444445e+01,
lng: 1.3995977778e+02,
cert : true,
content:'Name = JA/FS-007(JA/FS-007) peak = 1830.699951 pos = 37.1804,139.9598 diff = 272.199951'
});
data_saddle.push({
lat: 3.7169111111e+01,
lng: 1.3996266667e+02,
content:'Saddle = 1558.500000 pos = 37.1691,139.9627 diff = 272.199951'
});
data_peak.push({
lat: 3.7124888889e+01,
lng: 1.3996311111e+02,
cert : true,
content:'Name = Nasudake (Chausudake)(JA/TG-016) peak = 1914.099976 pos = 37.1249,139.9631 diff = 191.699951'
});
data_saddle.push({
lat: 3.7131222223e+01,
lng: 1.3996233333e+02,
content:'Saddle = 1722.400024 pos = 37.1312,139.9623 diff = 191.699951'
});
data_peak.push({
lat: 3.7087888889e+01,
lng: 1.3958466667e+02,
cert : false,
content:' Peak = 1070.300049 pos = 37.0879,139.5847 diff = 157.600037'
});
data_saddle.push({
lat: 3.7079666667e+01,
lng: 1.3958677778e+02,
content:'Saddle = 912.700012 pos = 37.0797,139.5868 diff = 157.600037'
});
data_peak.push({
lat: 3.7347000000e+01,
lng: 1.3983833333e+02,
cert : false,
content:' Peak = 1093.000000 pos = 37.3470,139.8383 diff = 175.299988'
});
data_saddle.push({
lat: 3.7338666667e+01,
lng: 1.3983211111e+02,
content:'Saddle = 917.700012 pos = 37.3387,139.8321 diff = 175.299988'
});
data_peak.push({
lat: 3.6921111112e+01,
lng: 1.3967522222e+02,
cert : true,
content:'Name = JA/TG-047(JA/TG-047) peak = 1122.800049 pos = 36.9211,139.6752 diff = 204.500061'
});
data_saddle.push({
lat: 3.6921111112e+01,
lng: 1.3966822222e+02,
content:'Saddle = 918.299988 pos = 36.9211,139.6682 diff = 204.500061'
});
data_peak.push({
lat: 3.6830000000e+01,
lng: 1.3963322222e+02,
cert : true,
content:'Name = JA/TG-046(JA/TG-046) peak = 1130.599976 pos = 36.8300,139.6332 diff = 202.799988'
});
data_saddle.push({
lat: 3.6834777778e+01,
lng: 1.3962288889e+02,
content:'Saddle = 927.799988 pos = 36.8348,139.6229 diff = 202.799988'
});
data_peak.push({
lat: 3.7222555556e+01,
lng: 1.3949322222e+02,
cert : true,
content:'Name = JA/FS-039(JA/FS-039) peak = 1313.900024 pos = 37.2226,139.4932 diff = 382.000000'
});
data_saddle.push({
lat: 3.7203000000e+01,
lng: 1.3947688889e+02,
content:'Saddle = 931.900024 pos = 37.2030,139.4769 diff = 382.000000'
});
data_peak.push({
lat: 3.6982111112e+01,
lng: 1.3960888889e+02,
cert : false,
content:' Peak = 1106.000000 pos = 36.9821,139.6089 diff = 165.900024'
});
data_saddle.push({
lat: 3.6982555556e+01,
lng: 1.3961577778e+02,
content:'Saddle = 940.099976 pos = 36.9826,139.6158 diff = 165.900024'
});
data_peak.push({
lat: 3.7284888889e+01,
lng: 1.3920955556e+02,
cert : true,
content:'Name = JA/FS-043(JA/FS-043) peak = 1233.300049 pos = 37.2849,139.2096 diff = 271.100037'
});
data_saddle.push({
lat: 3.7278888889e+01,
lng: 1.3920133333e+02,
content:'Saddle = 962.200012 pos = 37.2789,139.2013 diff = 271.100037'
});
data_peak.push({
lat: 3.6872444445e+01,
lng: 1.3966111111e+02,
cert : false,
content:' Peak = 1174.500000 pos = 36.8724,139.6611 diff = 212.000000'
});
data_saddle.push({
lat: 3.6864777778e+01,
lng: 1.3966166667e+02,
content:'Saddle = 962.500000 pos = 36.8648,139.6617 diff = 212.000000'
});
data_peak.push({
lat: 3.7127111111e+01,
lng: 1.3953455556e+02,
cert : true,
content:'Name = JA/FS-053(JA/FS-053) peak = 1153.300049 pos = 37.1271,139.5346 diff = 190.500061'
});
data_saddle.push({
lat: 3.7131666667e+01,
lng: 1.3954266667e+02,
content:'Saddle = 962.799988 pos = 37.1317,139.5427 diff = 190.500061'
});
data_peak.push({
lat: 3.7183444445e+01,
lng: 1.3918944444e+02,
cert : true,
content:'Name = Mijyougatake(JA/NI-023) peak = 1552.099976 pos = 37.1834,139.1894 diff = 589.099976'
});
data_saddle.push({
lat: 3.7142222223e+01,
lng: 1.3914455556e+02,
content:'Saddle = 963.000000 pos = 37.1422,139.1446 diff = 589.099976'
});
data_peak.push({
lat: 3.7136111111e+01,
lng: 1.3921500000e+02,
cert : false,
content:' Peak = 1182.699951 pos = 37.1361,139.2150 diff = 170.399963'
});
data_saddle.push({
lat: 3.7133000000e+01,
lng: 1.3920655556e+02,
content:'Saddle = 1012.299988 pos = 37.1330,139.2066 diff = 170.399963'
});
data_peak.push({
lat: 3.7256777778e+01,
lng: 1.3917511111e+02,
cert : true,
content:'Name = Kemouyama(JA/FS-024) peak = 1515.000000 pos = 37.2568,139.1751 diff = 432.099976'
});
data_saddle.push({
lat: 3.7237000000e+01,
lng: 1.3916466667e+02,
content:'Saddle = 1082.900024 pos = 37.2370,139.1647 diff = 432.099976'
});
data_peak.push({
lat: 3.7203888889e+01,
lng: 1.3919477778e+02,
cert : false,
content:' Peak = 1351.300049 pos = 37.2039,139.1948 diff = 168.400024'
});
data_saddle.push({
lat: 3.7199888889e+01,
lng: 1.3919633333e+02,
content:'Saddle = 1182.900024 pos = 37.1999,139.1963 diff = 168.400024'
});
data_peak.push({
lat: 3.7147555556e+01,
lng: 1.3918544444e+02,
cert : true,
content:'Name = JA/NI-029(JA/NI-029) peak = 1431.300049 pos = 37.1476,139.1854 diff = 198.900024'
});
data_saddle.push({
lat: 3.7160444445e+01,
lng: 1.3918644444e+02,
content:'Saddle = 1232.400024 pos = 37.1604,139.1864 diff = 198.900024'
});
data_peak.push({
lat: 3.7229666667e+01,
lng: 1.3944344444e+02,
cert : false,
content:' Peak = 1123.500000 pos = 37.2297,139.4434 diff = 160.400024'
});
data_saddle.push({
lat: 3.7216777778e+01,
lng: 1.3944400000e+02,
content:'Saddle = 963.099976 pos = 37.2168,139.4440 diff = 160.400024'
});
data_peak.push({
lat: 3.7072333334e+01,
lng: 1.3898555556e+02,
cert : false,
content:' Peak = 1143.099976 pos = 37.0723,138.9856 diff = 171.500000'
});
data_saddle.push({
lat: 3.7073888889e+01,
lng: 1.3899577778e+02,
content:'Saddle = 971.599976 pos = 37.0739,138.9958 diff = 171.500000'
});
data_peak.push({
lat: 3.7082777778e+01,
lng: 1.3971044444e+02,
cert : false,
content:' Peak = 1136.900024 pos = 37.0828,139.7104 diff = 164.800049'
});
data_saddle.push({
lat: 3.7070000000e+01,
lng: 1.3971000000e+02,
content:'Saddle = 972.099976 pos = 37.0700,139.7100 diff = 164.800049'
});
data_peak.push({
lat: 3.6973111112e+01,
lng: 1.3964222222e+02,
cert : true,
content:'Name = JA/TG-033(JA/TG-033) peak = 1364.699951 pos = 36.9731,139.6422 diff = 391.599976'
});
data_saddle.push({
lat: 3.6995000000e+01,
lng: 1.3962222222e+02,
content:'Saddle = 973.099976 pos = 36.9950,139.6222 diff = 391.599976'
});
data_peak.push({
lat: 3.7074444445e+01,
lng: 1.3971544444e+02,
cert : false,
content:' Peak = 1141.000000 pos = 37.0744,139.7154 diff = 152.900024'
});
data_saddle.push({
lat: 3.7065666667e+01,
lng: 1.3970911111e+02,
content:'Saddle = 988.099976 pos = 37.0657,139.7091 diff = 152.900024'
});
data_peak.push({
lat: 3.7190000000e+01,
lng: 1.3957077778e+02,
cert : false,
content:' Peak = 1173.300049 pos = 37.1900,139.5708 diff = 184.500061'
});
data_saddle.push({
lat: 3.7189222223e+01,
lng: 1.3957477778e+02,
content:'Saddle = 988.799988 pos = 37.1892,139.5748 diff = 184.500061'
});
data_peak.push({
lat: 3.6911111112e+01,
lng: 1.3965955556e+02,
cert : false,
content:' Peak = 1175.900024 pos = 36.9111,139.6596 diff = 173.600037'
});
data_saddle.push({
lat: 3.6914777778e+01,
lng: 1.3965077778e+02,
content:'Saddle = 1002.299988 pos = 36.9148,139.6508 diff = 173.600037'
});
data_peak.push({
lat: 3.7363222222e+01,
lng: 1.3971466667e+02,
cert : true,
content:'Name = Hakaseyama(JA/FS-026) peak = 1481.800049 pos = 37.3632,139.7147 diff = 467.200073'
});
data_saddle.push({
lat: 3.7280777778e+01,
lng: 1.3973111111e+02,
content:'Saddle = 1014.599976 pos = 37.2808,139.7311 diff = 467.200073'
});
data_peak.push({
lat: 3.7318111111e+01,
lng: 1.3983200000e+02,
cert : false,
content:' Peak = 1380.500000 pos = 37.3181,139.8320 diff = 343.400024'
});
data_saddle.push({
lat: 3.7328111111e+01,
lng: 1.3973566667e+02,
content:'Saddle = 1037.099976 pos = 37.3281,139.7357 diff = 343.400024'
});
data_peak.push({
lat: 3.6857222223e+01,
lng: 1.3964055556e+02,
cert : true,
content:'Name = JA/TG-035(JA/TG-035) peak = 1341.400024 pos = 36.8572,139.6406 diff = 321.200012'
});
data_saddle.push({
lat: 3.6845555556e+01,
lng: 1.3961644444e+02,
content:'Saddle = 1020.200012 pos = 36.8456,139.6164 diff = 321.200012'
});
data_peak.push({
lat: 3.6852777778e+01,
lng: 1.3961866667e+02,
cert : true,
content:'Name = JA/TG-037(JA/TG-037) peak = 1295.199951 pos = 36.8528,139.6187 diff = 263.500000'
});
data_saddle.push({
lat: 3.6851111112e+01,
lng: 1.3963377778e+02,
content:'Saddle = 1031.699951 pos = 36.8511,139.6338 diff = 263.500000'
});
data_peak.push({
lat: 3.6846222223e+01,
lng: 1.3965911111e+02,
cert : true,
content:'Name = JA/TG-038(JA/TG-038) peak = 1283.900024 pos = 36.8462,139.6591 diff = 175.700073'
});
data_saddle.push({
lat: 3.6858222223e+01,
lng: 1.3966155556e+02,
content:'Saddle = 1108.199951 pos = 36.8582,139.6616 diff = 175.700073'
});
data_peak.push({
lat: 3.6923666667e+01,
lng: 1.3964544444e+02,
cert : true,
content:'Name = JA/TG-041(JA/TG-041) peak = 1223.599976 pos = 36.9237,139.6454 diff = 200.399963'
});
data_saddle.push({
lat: 3.6924666667e+01,
lng: 1.3963577778e+02,
content:'Saddle = 1023.200012 pos = 36.9247,139.6358 diff = 200.399963'
});
data_peak.push({
lat: 3.7213444445e+01,
lng: 1.3925433333e+02,
cert : true,
content:'Name = JA/FS-022(JA/FS-022) peak = 1534.199951 pos = 37.2134,139.2543 diff = 510.799927'
});
data_saddle.push({
lat: 3.7161888889e+01,
lng: 1.3928544444e+02,
content:'Saddle = 1023.400024 pos = 37.1619,139.2854 diff = 510.799927'
});
data_peak.push({
lat: 3.7253000000e+01,
lng: 1.3926522222e+02,
cert : false,
content:' Peak = 1453.199951 pos = 37.2530,139.2652 diff = 214.899902'
});
data_saddle.push({
lat: 3.7235666667e+01,
lng: 1.3925366667e+02,
content:'Saddle = 1238.300049 pos = 37.2357,139.2537 diff = 214.899902'
});
data_peak.push({
lat: 3.7242555556e+01,
lng: 1.3925444444e+02,
cert : true,
content:'Name = JA/FS-027(JA/FS-027) peak = 1452.199951 pos = 37.2426,139.2544 diff = 199.799927'
});
data_saddle.push({
lat: 3.7249555556e+01,
lng: 1.3925988889e+02,
content:'Saddle = 1252.400024 pos = 37.2496,139.2599 diff = 199.799927'
});
data_peak.push({
lat: 3.7173111111e+01,
lng: 1.3968000000e+02,
cert : false,
content:' Peak = 1211.500000 pos = 37.1731,139.6800 diff = 166.500000'
});
data_saddle.push({
lat: 3.7159333334e+01,
lng: 1.3968000000e+02,
content:'Saddle = 1045.000000 pos = 37.1593,139.6800 diff = 166.500000'
});
data_peak.push({
lat: 3.7110555556e+01,
lng: 1.3954077778e+02,
cert : true,
content:'Name = JA/FS-038(JA/FS-038) peak = 1338.599976 pos = 37.1106,139.5408 diff = 274.799927'
});
data_saddle.push({
lat: 3.7121000000e+01,
lng: 1.3954944444e+02,
content:'Saddle = 1063.800049 pos = 37.1210,139.5494 diff = 274.799927'
});
data_peak.push({
lat: 3.7246333334e+01,
lng: 1.3969611111e+02,
cert : false,
content:' Peak = 1237.900024 pos = 37.2463,139.6961 diff = 169.800049'
});
data_saddle.push({
lat: 3.7241777778e+01,
lng: 1.3967033333e+02,
content:'Saddle = 1068.099976 pos = 37.2418,139.6703 diff = 169.800049'
});
data_peak.push({
lat: 3.7114444445e+01,
lng: 1.3947600000e+02,
cert : false,
content:' Peak = 1314.199951 pos = 37.1144,139.4760 diff = 244.199951'
});
data_saddle.push({
lat: 3.7096444445e+01,
lng: 1.3947155556e+02,
content:'Saddle = 1070.000000 pos = 37.0964,139.4716 diff = 244.199951'
});
data_peak.push({
lat: 3.7124555556e+01,
lng: 1.3964922222e+02,
cert : true,
content:'Name = JA/FS-014(JA/FS-014) peak = 1637.800049 pos = 37.1246,139.6492 diff = 563.600098'
});
data_saddle.push({
lat: 3.7086666667e+01,
lng: 1.3965377778e+02,
content:'Saddle = 1074.199951 pos = 37.0867,139.6538 diff = 563.600098'
});
data_peak.push({
lat: 3.6902888889e+01,
lng: 1.3861055556e+02,
cert : false,
content:' Peak = 1333.000000 pos = 36.9029,138.6106 diff = 255.199951'
});
data_saddle.push({
lat: 3.6892111112e+01,
lng: 1.3861311111e+02,
content:'Saddle = 1077.800049 pos = 36.8921,138.6131 diff = 255.199951'
});
data_peak.push({
lat: 3.7021222223e+01,
lng: 1.3967855556e+02,
cert : false,
content:' Peak = 1342.099976 pos = 37.0212,139.6786 diff = 259.099976'
});
data_saddle.push({
lat: 3.7043111111e+01,
lng: 1.3967866667e+02,
content:'Saddle = 1083.000000 pos = 37.0431,139.6787 diff = 259.099976'
});
data_peak.push({
lat: 3.7090666667e+01,
lng: 1.3946588889e+02,
cert : true,
content:'Name = JA/FS-042(JA/FS-042) peak = 1295.400024 pos = 37.0907,139.4659 diff = 202.599976'
});
data_saddle.push({
lat: 3.7073666667e+01,
lng: 1.3945855556e+02,
content:'Saddle = 1092.800049 pos = 37.0737,139.4586 diff = 202.599976'
});
data_peak.push({
lat: 3.6711888889e+01,
lng: 1.3955455556e+02,
cert : true,
content:'Name = JA/TG-039(JA/TG-039) peak = 1285.400024 pos = 36.7119,139.5546 diff = 177.900024'
});
data_saddle.push({
lat: 3.6712888889e+01,
lng: 1.3954344444e+02,
content:'Saddle = 1107.500000 pos = 36.7129,139.5434 diff = 177.900024'
});
data_peak.push({
lat: 3.7131666667e+01,
lng: 1.3925711111e+02,
cert : false,
content:' Peak = 1264.300049 pos = 37.1317,139.2571 diff = 151.600098'
});
data_saddle.push({
lat: 3.7114888889e+01,
lng: 1.3927344444e+02,
content:'Saddle = 1112.699951 pos = 37.1149,139.2734 diff = 151.600098'
});
data_peak.push({
lat: 3.7070111111e+01,
lng: 1.3943288889e+02,
cert : false,
content:' Peak = 1291.099976 pos = 37.0701,139.4329 diff = 173.500000'
});
data_saddle.push({
lat: 3.7058222223e+01,
lng: 1.3944200000e+02,
content:'Saddle = 1117.599976 pos = 37.0582,139.4420 diff = 173.500000'
});
data_peak.push({
lat: 3.7071777778e+01,
lng: 1.3956822222e+02,
cert : false,
content:' Peak = 1300.800049 pos = 37.0718,139.5682 diff = 158.300049'
});
data_saddle.push({
lat: 3.7068333334e+01,
lng: 1.3957344444e+02,
content:'Saddle = 1142.500000 pos = 37.0683,139.5734 diff = 158.300049'
});
data_peak.push({
lat: 3.7012444445e+01,
lng: 1.3898888889e+02,
cert : true,
content:'Name = JA/NI-035(JA/NI-035) peak = 1341.099976 pos = 37.0124,138.9889 diff = 180.099976'
});
data_saddle.push({
lat: 3.7004444445e+01,
lng: 1.3900200000e+02,
content:'Saddle = 1161.000000 pos = 37.0044,139.0020 diff = 180.099976'
});
data_peak.push({
lat: 3.7004888889e+01,
lng: 1.3964788889e+02,
cert : false,
content:' Peak = 1343.900024 pos = 37.0049,139.6479 diff = 181.599976'
});
data_saddle.push({
lat: 3.7012000000e+01,
lng: 1.3964200000e+02,
content:'Saddle = 1162.300049 pos = 37.0120,139.6420 diff = 181.599976'
});
data_peak.push({
lat: 3.7036111111e+01,
lng: 1.3964366667e+02,
cert : false,
content:' Peak = 1580.699951 pos = 37.0361,139.6437 diff = 417.899902'
});
data_saddle.push({
lat: 3.7013666667e+01,
lng: 1.3959277778e+02,
content:'Saddle = 1162.800049 pos = 37.0137,139.5928 diff = 417.899902'
});
data_peak.push({
lat: 3.7049111111e+01,
lng: 1.3958800000e+02,
cert : true,
content:'Name = JA/FS-020(JA/FS-020) peak = 1551.000000 pos = 37.0491,139.5880 diff = 282.900024'
});
data_saddle.push({
lat: 3.7035777778e+01,
lng: 1.3961522222e+02,
content:'Saddle = 1268.099976 pos = 37.0358,139.6152 diff = 282.900024'
});
data_peak.push({
lat: 3.7092222223e+01,
lng: 1.3928122222e+02,
cert : true,
content:'Name = JA/FS-037(JA/FS-037) peak = 1363.199951 pos = 37.0922,139.2812 diff = 192.699951'
});
data_saddle.push({
lat: 3.7094666667e+01,
lng: 1.3929866667e+02,
content:'Saddle = 1170.500000 pos = 37.0947,139.2987 diff = 192.699951'
});
data_peak.push({
lat: 3.7050222223e+01,
lng: 1.3941755556e+02,
cert : false,
content:' Peak = 1342.199951 pos = 37.0502,139.4176 diff = 154.599976'
});
data_saddle.push({
lat: 3.7044555556e+01,
lng: 1.3942144444e+02,
content:'Saddle = 1187.599976 pos = 37.0446,139.4214 diff = 154.599976'
});
data_peak.push({
lat: 3.6929444445e+01,
lng: 1.3960000000e+02,
cert : true,
content:'Name = JA/TG-023(JA/TG-023) peak = 1593.000000 pos = 36.9294,139.6000 diff = 402.199951'
});
data_saddle.push({
lat: 3.6913222223e+01,
lng: 1.3954433333e+02,
content:'Saddle = 1190.800049 pos = 36.9132,139.5443 diff = 402.199951'
});
data_peak.push({
lat: 3.6919777778e+01,
lng: 1.3957655556e+02,
cert : true,
content:'Name = JA/TG-029(JA/TG-029) peak = 1460.099976 pos = 36.9198,139.5766 diff = 248.099976'
});
data_saddle.push({
lat: 3.6912777778e+01,
lng: 1.3958466667e+02,
content:'Saddle = 1212.000000 pos = 36.9128,139.5847 diff = 248.099976'
});
data_peak.push({
lat: 3.7014888889e+01,
lng: 1.3958177778e+02,
cert : true,
content:'Name = JA/TG-030(JA/TG-030) peak = 1397.400024 pos = 37.0149,139.5818 diff = 200.200073'
});
data_saddle.push({
lat: 3.7001888889e+01,
lng: 1.3957411111e+02,
content:'Saddle = 1197.199951 pos = 37.0019,139.5741 diff = 200.200073'
});
data_peak.push({
lat: 3.6689777778e+01,
lng: 1.3953300000e+02,
cert : true,
content:'Name = JA/TG-025(JA/TG-025) peak = 1525.099976 pos = 36.6898,139.5330 diff = 327.599976'
});
data_saddle.push({
lat: 3.6710666667e+01,
lng: 1.3951411111e+02,
content:'Saddle = 1197.500000 pos = 36.7107,139.5141 diff = 327.599976'
});
data_peak.push({
lat: 3.7104000000e+01,
lng: 1.3902400000e+02,
cert : true,
content:'Name = Hakkaisan (Nyuudoudake)(JA/NI-017) peak = 1776.400024 pos = 37.1040,139.0240 diff = 528.700073'
});
data_saddle.push({
lat: 3.7095444445e+01,
lng: 1.3904733333e+02,
content:'Saddle = 1247.699951 pos = 37.0954,139.0473 diff = 528.700073'
});
data_peak.push({
lat: 3.7048000000e+01,
lng: 1.3944944444e+02,
cert : true,
content:'Name = JA/FS-029(JA/FS-029) peak = 1423.400024 pos = 37.0480,139.4494 diff = 169.800049'
});
data_saddle.push({
lat: 3.7033777778e+01,
lng: 1.3944400000e+02,
content:'Saddle = 1253.599976 pos = 37.0338,139.4440 diff = 169.800049'
});
data_peak.push({
lat: 3.7008777778e+01,
lng: 1.3893888889e+02,
cert : true,
content:'Name = JA/NI-028(JA/NI-028) peak = 1472.800049 pos = 37.0088,138.9389 diff = 210.000000'
});
data_saddle.push({
lat: 3.7002000000e+01,
lng: 1.3893844444e+02,
content:'Saddle = 1262.800049 pos = 37.0020,138.9384 diff = 210.000000'
});
data_peak.push({
lat: 3.6753000000e+01,
lng: 1.3856777778e+02,
cert : true,
content:'Name = Iwasugeyama (Uraiwasugeyama)(JA/NN-043) peak = 2340.600098 pos = 36.7530,138.5678 diff = 1039.200073'
});
data_saddle.push({
lat: 3.6766444445e+01,
lng: 1.3882233333e+02,
content:'Saddle = 1301.400024 pos = 36.7664,138.8223 diff = 1039.200073'
});
data_peak.push({
lat: 3.6869777778e+01,
lng: 1.3861355556e+02,
cert : false,
content:' Peak = 1494.699951 pos = 36.8698,138.6136 diff = 174.000000'
});
data_saddle.push({
lat: 3.6861666667e+01,
lng: 1.3860888889e+02,
content:'Saddle = 1320.699951 pos = 36.8617,138.6089 diff = 174.000000'
});
data_peak.push({
lat: 3.6860555556e+01,
lng: 1.3874811111e+02,
cert : false,
content:' Peak = 1498.900024 pos = 36.8606,138.7481 diff = 156.300049'
});
data_saddle.push({
lat: 3.6845222223e+01,
lng: 1.3874944444e+02,
content:'Saddle = 1342.599976 pos = 36.8452,138.7494 diff = 156.300049'
});
data_peak.push({
lat: 3.6839222223e+01,
lng: 1.3858388889e+02,
cert : true,
content:'Name = Torikabutoyama(JA/NN-066) peak = 2036.699951 pos = 36.8392,138.5839 diff = 628.199951'
});
data_saddle.push({
lat: 3.6859555556e+01,
lng: 1.3852855556e+02,
content:'Saddle = 1408.500000 pos = 36.8596,138.5286 diff = 628.199951'
});
data_peak.push({
lat: 3.6857555556e+01,
lng: 1.3855088889e+02,
cert : true,
content:'Name = JA/NN-083(JA/NN-083) peak = 1851.599976 pos = 36.8576,138.5509 diff = 238.900024'
});
data_saddle.push({
lat: 3.6852000000e+01,
lng: 1.3855655556e+02,
content:'Saddle = 1612.699951 pos = 36.8520,138.5566 diff = 238.900024'
});
data_peak.push({
lat: 3.6855333334e+01,
lng: 1.3849022222e+02,
cert : true,
content:'Name = JA/NN-100(JA/NN-100) peak = 1675.699951 pos = 36.8553,138.4902 diff = 216.599976'
});
data_saddle.push({
lat: 3.6833222223e+01,
lng: 1.3850311111e+02,
content:'Saddle = 1459.099976 pos = 36.8332,138.5031 diff = 216.599976'
});
data_peak.push({
lat: 3.6897888889e+01,
lng: 1.3848644444e+02,
cert : true,
content:'Name = JA/NN-107(JA/NN-107) peak = 1646.199951 pos = 36.8979,138.4864 diff = 163.699951'
});
data_saddle.push({
lat: 3.6888666667e+01,
lng: 1.3849266667e+02,
content:'Saddle = 1482.500000 pos = 36.8887,138.4927 diff = 163.699951'
});
data_peak.push({
lat: 3.6804777778e+01,
lng: 1.3873211111e+02,
cert : true,
content:'Name = JA/NI-018(JA/NI-018) peak = 1655.900024 pos = 36.8048,138.7321 diff = 192.700073'
});
data_saddle.push({
lat: 3.6797111112e+01,
lng: 1.3873633333e+02,
content:'Saddle = 1463.199951 pos = 36.7971,138.7363 diff = 192.700073'
});
data_peak.push({
lat: 3.6810666667e+01,
lng: 1.3849511111e+02,
cert : true,
content:'Name = JA/NN-091(JA/NN-091) peak = 1745.000000 pos = 36.8107,138.4951 diff = 223.500000'
});
data_saddle.push({
lat: 3.6799555556e+01,
lng: 1.3849444444e+02,
content:'Saddle = 1521.500000 pos = 36.7996,138.4944 diff = 223.500000'
});
data_peak.push({
lat: 3.6772333334e+01,
lng: 1.3867055556e+02,
cert : true,
content:'Name = Saburyuuyama(JA/NN-052) peak = 2191.199951 pos = 36.7723,138.6706 diff = 645.399902'
});
data_saddle.push({
lat: 3.6696333334e+01,
lng: 1.3863588889e+02,
content:'Saddle = 1545.800049 pos = 36.6963,138.6359 diff = 645.399902'
});
data_peak.push({
lat: 3.6846000000e+01,
lng: 1.3869022222e+02,
cert : true,
content:'Name = Naebasan(JA/NI-005) peak = 2144.699951 pos = 36.8460,138.6902 diff = 401.699951'
});
data_saddle.push({
lat: 3.6815777778e+01,
lng: 1.3868766667e+02,
content:'Saddle = 1743.000000 pos = 36.8158,138.6877 diff = 401.699951'
});
data_peak.push({
lat: 3.6852222223e+01,
lng: 1.3870388889e+02,
cert : false,
content:' Peak = 2027.800049 pos = 36.8522,138.7039 diff = 152.800049'
});
data_saddle.push({
lat: 3.6849333334e+01,
lng: 1.3870011111e+02,
content:'Saddle = 1875.000000 pos = 36.8493,138.7001 diff = 152.800049'
});
data_peak.push({
lat: 3.6793777778e+01,
lng: 1.3868933333e+02,
cert : true,
content:'Name = JA/NI-010(JA/NI-010) peak = 2050.800049 pos = 36.7938,138.6893 diff = 238.600098'
});
data_saddle.push({
lat: 3.6785111112e+01,
lng: 1.3867500000e+02,
content:'Saddle = 1812.199951 pos = 36.7851,138.6750 diff = 238.600098'
});
data_peak.push({
lat: 3.6738111112e+01,
lng: 1.3869344444e+02,
cert : true,
content:'Name = Shirasunayama(JA/GM-007) peak = 2138.500000 pos = 36.7381,138.6934 diff = 212.599976'
});
data_saddle.push({
lat: 3.6750444445e+01,
lng: 1.3869177778e+02,
content:'Saddle = 1925.900024 pos = 36.7504,138.6918 diff = 212.599976'
});
data_peak.push({
lat: 3.6759333334e+01,
lng: 1.3872133333e+02,
cert : false,
content:' Peak = 2121.500000 pos = 36.7593,138.7213 diff = 194.099976'
});
data_saddle.push({
lat: 3.6743888889e+01,
lng: 1.3871488889e+02,
content:'Saddle = 1927.400024 pos = 36.7439,138.7149 diff = 194.099976'
});
data_peak.push({
lat: 3.6762333334e+01,
lng: 1.3851000000e+02,
cert : true,
content:'Name = Yakebitaiyama(JA/NN-069) peak = 2014.300049 pos = 36.7623,138.5100 diff = 364.700073'
});
data_saddle.push({
lat: 3.6736888889e+01,
lng: 1.3850888889e+02,
content:'Saddle = 1649.599976 pos = 36.7369,138.5089 diff = 364.700073'
});
data_peak.push({
lat: 3.6705888889e+01,
lng: 1.3847933333e+02,
cert : false,
content:' Peak = 1833.000000 pos = 36.7059,138.4793 diff = 150.099976'
});
data_saddle.push({
lat: 3.6692111112e+01,
lng: 1.3848488889e+02,
content:'Saddle = 1682.900024 pos = 36.6921,138.4849 diff = 150.099976'
});
data_peak.push({
lat: 3.6719000001e+01,
lng: 1.3862088889e+02,
cert : true,
content:'Name = JA/GM-015(JA/GM-015) peak = 1971.599976 pos = 36.7190,138.6209 diff = 205.799927'
});
data_saddle.push({
lat: 3.6708444445e+01,
lng: 1.3861200000e+02,
content:'Saddle = 1765.800049 pos = 36.7084,138.6120 diff = 205.799927'
});
data_peak.push({
lat: 3.6676666667e+01,
lng: 1.3848144444e+02,
cert : true,
content:'Name = Kasagatake(JA/NN-060) peak = 2074.800049 pos = 36.6767,138.4814 diff = 242.600098'
});
data_saddle.push({
lat: 3.6677555556e+01,
lng: 1.3848855556e+02,
content:'Saddle = 1832.199951 pos = 36.6776,138.4886 diff = 242.600098'
});
data_peak.push({
lat: 3.6720111112e+01,
lng: 1.3859800000e+02,
cert : true,
content:'Name = JA/NN-055(JA/NN-055) peak = 2083.199951 pos = 36.7201,138.5980 diff = 230.399902'
});
data_saddle.push({
lat: 3.6703111112e+01,
lng: 1.3858566667e+02,
content:'Saddle = 1852.800049 pos = 36.7031,138.5857 diff = 230.399902'
});
data_peak.push({
lat: 3.6670333334e+01,
lng: 1.3852400000e+02,
cert : false,
content:' Peak = 2306.899902 pos = 36.6703,138.5240 diff = 374.999878'
});
data_saddle.push({
lat: 3.6697000001e+01,
lng: 1.3852811111e+02,
content:'Saddle = 1931.900024 pos = 36.6970,138.5281 diff = 374.999878'
});
data_peak.push({
lat: 3.6703777778e+01,
lng: 1.3854344444e+02,
cert : true,
content:'Name = JA/GM-009(JA/GM-009) peak = 2106.600098 pos = 36.7038,138.5434 diff = 155.100098'
});
data_saddle.push({
lat: 3.6713333334e+01,
lng: 1.3853577778e+02,
content:'Saddle = 1951.500000 pos = 36.7133,138.5358 diff = 155.100098'
});
data_peak.push({
lat: 3.7181000000e+01,
lng: 1.3946866667e+02,
cert : true,
content:'Name = JA/FS-025(JA/FS-025) peak = 1484.300049 pos = 37.1810,139.4687 diff = 182.300049'
});
data_saddle.push({
lat: 3.7170222223e+01,
lng: 1.3945844444e+02,
content:'Saddle = 1302.000000 pos = 37.1702,139.4584 diff = 182.300049'
});
data_peak.push({
lat: 3.7030000000e+01,
lng: 1.3927544444e+02,
cert : false,
content:' Peak = 1497.000000 pos = 37.0300,139.2754 diff = 183.800049'
});
data_saddle.push({
lat: 3.7008000000e+01,
lng: 1.3927977778e+02,
content:'Saddle = 1313.199951 pos = 37.0080,139.2798 diff = 183.800049'
});
data_peak.push({
lat: 3.7156333334e+01,
lng: 1.3944588889e+02,
cert : true,
content:'Name = JA/FS-023(JA/FS-023) peak = 1524.900024 pos = 37.1563,139.4459 diff = 204.700073'
});
data_saddle.push({
lat: 3.7133111111e+01,
lng: 1.3941544444e+02,
content:'Saddle = 1320.199951 pos = 37.1331,139.4154 diff = 204.700073'
});
data_peak.push({
lat: 3.7063333334e+01,
lng: 1.3917400000e+02,
cert : true,
content:'Name = JA/NI-025(JA/NI-025) peak = 1520.800049 pos = 37.0633,139.1740 diff = 178.500000'
});
data_saddle.push({
lat: 3.7057555556e+01,
lng: 1.3917233333e+02,
content:'Saddle = 1342.300049 pos = 37.0576,139.1723 diff = 178.500000'
});
data_peak.push({
lat: 3.6961222223e+01,
lng: 1.3907655556e+02,
cert : true,
content:'Name = JA/GM-028(JA/GM-028) peak = 1594.300049 pos = 36.9612,139.0766 diff = 241.000000'
});
data_saddle.push({
lat: 3.6965777778e+01,
lng: 1.3907288889e+02,
content:'Saddle = 1353.300049 pos = 36.9658,139.0729 diff = 241.000000'
});
data_peak.push({
lat: 3.6737666667e+01,
lng: 1.3931788889e+02,
cert : false,
content:' Peak = 1556.599976 pos = 36.7377,139.3179 diff = 185.099976'
});
data_saddle.push({
lat: 3.6740333334e+01,
lng: 1.3932522222e+02,
content:'Saddle = 1371.500000 pos = 36.7403,139.3252 diff = 185.099976'
});
data_peak.push({
lat: 3.6710777778e+01,
lng: 1.3947577778e+02,
cert : true,
content:'Name = JA/TG-020(JA/TG-020) peak = 1752.199951 pos = 36.7108,139.4758 diff = 344.599976'
});
data_saddle.push({
lat: 3.6717111112e+01,
lng: 1.3945911111e+02,
content:'Saddle = 1407.599976 pos = 36.7171,139.4591 diff = 344.599976'
});
data_peak.push({
lat: 3.7138666667e+01,
lng: 1.3940811111e+02,
cert : true,
content:'Name = JA/FS-017(JA/FS-017) peak = 1602.099976 pos = 37.1387,139.4081 diff = 190.599976'
});
data_saddle.push({
lat: 3.7122111111e+01,
lng: 1.3939122222e+02,
content:'Saddle = 1411.500000 pos = 37.1221,139.3912 diff = 190.599976'
});
data_peak.push({
lat: 3.7221222223e+01,
lng: 1.3933955556e+02,
cert : true,
content:'Name = Asahidake(JA/FS-016) peak = 1622.800049 pos = 37.2212,139.3396 diff = 201.200073'
});
data_saddle.push({
lat: 3.7194333334e+01,
lng: 1.3933477778e+02,
content:'Saddle = 1421.599976 pos = 37.1943,139.3348 diff = 201.200073'
});
data_peak.push({
lat: 3.7046888889e+01,
lng: 1.3955088889e+02,
cert : true,
content:'Name = JA/FS-015(JA/FS-015) peak = 1630.000000 pos = 37.0469,139.5509 diff = 198.599976'
});
data_saddle.push({
lat: 3.7023444445e+01,
lng: 1.3955111111e+02,
content:'Saddle = 1431.400024 pos = 37.0234,139.5511 diff = 198.599976'
});
data_peak.push({
lat: 3.6760444445e+01,
lng: 1.3943033333e+02,
cert : true,
content:'Name = JA/TG-022(JA/TG-022) peak = 1666.900024 pos = 36.7604,139.4303 diff = 227.800049'
});
data_saddle.push({
lat: 3.6772888889e+01,
lng: 1.3941755556e+02,
content:'Saddle = 1439.099976 pos = 36.7729,139.4176 diff = 227.800049'
});
data_peak.push({
lat: 3.6817555556e+01,
lng: 1.3883944444e+02,
cert : true,
content:'Name = Sennokurayama(JA/GM-010) peak = 2025.300049 pos = 36.8176,138.8394 diff = 583.000000'
});
data_saddle.push({
lat: 3.6983333334e+01,
lng: 1.3900644444e+02,
content:'Saddle = 1442.300049 pos = 36.9833,139.0064 diff = 583.000000'
});
data_peak.push({
lat: 3.6978555556e+01,
lng: 1.3896444444e+02,
cert : true,
content:'Name = Makihatayama(JA/GM-016) peak = 1965.400024 pos = 36.9786,138.9644 diff = 522.099976'
});
data_saddle.push({
lat: 3.6894555556e+01,
lng: 1.3894744444e+02,
content:'Saddle = 1443.300049 pos = 36.8946,138.9474 diff = 522.099976'
});
data_peak.push({
lat: 3.6884666667e+01,
lng: 1.3897244444e+02,
cert : false,
content:' Peak = 1944.599976 pos = 36.8847,138.9724 diff = 391.799927'
});
data_saddle.push({
lat: 3.6923777778e+01,
lng: 1.3897444444e+02,
content:'Saddle = 1552.800049 pos = 36.9238,138.9744 diff = 391.799927'
});
data_peak.push({
lat: 3.6935777778e+01,
lng: 1.3896655556e+02,
cert : true,
content:'Name = JA/GM-021(JA/GM-021) peak = 1901.400024 pos = 36.9358,138.9666 diff = 254.900024'
});
data_saddle.push({
lat: 3.6963222223e+01,
lng: 1.3896555556e+02,
content:'Saddle = 1646.500000 pos = 36.9632,138.9656 diff = 254.900024'
});
data_peak.push({
lat: 3.6854444445e+01,
lng: 1.3881588889e+02,
cert : true,
content:'Name = JA/NI-021(JA/NI-021) peak = 1630.599976 pos = 36.8544,138.8159 diff = 177.699951'
});
data_saddle.push({
lat: 3.6838666667e+01,
lng: 1.3880988889e+02,
content:'Saddle = 1452.900024 pos = 36.8387,138.8099 diff = 177.699951'
});
data_peak.push({
lat: 3.6797444445e+01,
lng: 1.3888933333e+02,
cert : true,
content:'Name = JA/GM-025(JA/GM-025) peak = 1746.199951 pos = 36.7974,138.8893 diff = 194.899902'
});
data_saddle.push({
lat: 3.6804555556e+01,
lng: 1.3889188889e+02,
content:'Saddle = 1551.300049 pos = 36.8046,138.8919 diff = 194.899902'
});
data_peak.push({
lat: 3.6849222223e+01,
lng: 1.3891677778e+02,
cert : true,
content:'Name = Tanigawadake (Shigekuradake)(JA/NI-013) peak = 1977.300049 pos = 36.8492,138.9168 diff = 410.400024'
});
data_saddle.push({
lat: 3.6816555556e+01,
lng: 1.3886522222e+02,
content:'Saddle = 1566.900024 pos = 36.8166,138.8652 diff = 410.400024'
});
data_peak.push({
lat: 3.6867111112e+01,
lng: 1.3891955556e+02,
cert : false,
content:' Peak = 1758.300049 pos = 36.8671,138.9196 diff = 165.600098'
});
data_saddle.push({
lat: 3.6860111112e+01,
lng: 1.3892166667e+02,
content:'Saddle = 1592.699951 pos = 36.8601,138.9217 diff = 165.600098'
});
data_peak.push({
lat: 3.6824222223e+01,
lng: 1.3887922222e+02,
cert : true,
content:'Name = Mantarousan(JA/GM-017) peak = 1953.000000 pos = 36.8242,138.8792 diff = 281.699951'
});
data_saddle.push({
lat: 3.6827666667e+01,
lng: 1.3890533333e+02,
content:'Saddle = 1671.300049 pos = 36.8277,138.9053 diff = 281.699951'
});
data_peak.push({
lat: 3.7172666667e+01,
lng: 1.3933488889e+02,
cert : true,
content:'Name = Maruyamadake(JA/FS-008) peak = 1816.300049 pos = 37.1727,139.3349 diff = 342.800049'
});
data_saddle.push({
lat: 3.7119222223e+01,
lng: 1.3934600000e+02,
content:'Saddle = 1473.500000 pos = 37.1192,139.3460 diff = 342.800049'
});
data_peak.push({
lat: 3.7132777778e+01,
lng: 1.3933944444e+02,
cert : false,
content:' Peak = 1741.800049 pos = 37.1328,139.3394 diff = 179.300049'
});
data_saddle.push({
lat: 3.7145222223e+01,
lng: 1.3933600000e+02,
content:'Saddle = 1562.500000 pos = 37.1452,139.3360 diff = 179.300049'
});
data_peak.push({
lat: 3.7047666667e+01,
lng: 1.3935366667e+02,
cert : true,
content:'Name = Komagatake(JA/FS-002) peak = 2132.100098 pos = 37.0477,139.3537 diff = 623.400146'
});
data_saddle.push({
lat: 3.6983666667e+01,
lng: 1.3930377778e+02,
content:'Saddle = 1508.699951 pos = 36.9837,139.3038 diff = 623.400146'
});
data_peak.push({
lat: 3.7118333334e+01,
lng: 1.3937444444e+02,
cert : false,
content:' Peak = 1770.500000 pos = 37.1183,139.3744 diff = 159.199951'
});
data_saddle.push({
lat: 3.7112222223e+01,
lng: 1.3938066667e+02,
content:'Saddle = 1611.300049 pos = 37.1122,139.3807 diff = 159.199951'
});
data_peak.push({
lat: 3.6998444445e+01,
lng: 1.3930388889e+02,
cert : false,
content:' Peak = 1921.099976 pos = 36.9984,139.3039 diff = 173.199951'
});
data_saddle.push({
lat: 3.7014000000e+01,
lng: 1.3932955556e+02,
content:'Saddle = 1747.900024 pos = 37.0140,139.3296 diff = 173.199951'
});
data_peak.push({
lat: 3.7080888889e+01,
lng: 1.3937711111e+02,
cert : false,
content:' Peak = 2071.600098 pos = 37.0809,139.3771 diff = 152.700073'
});
data_saddle.push({
lat: 3.7063333334e+01,
lng: 1.3937233333e+02,
content:'Saddle = 1918.900024 pos = 37.0633,139.3723 diff = 152.700073'
});
data_peak.push({
lat: 3.6998000000e+01,
lng: 1.3954622222e+02,
cert : true,
content:'Name = JA/FS-011(JA/FS-011) peak = 1752.599976 pos = 36.9980,139.5462 diff = 223.400024'
});
data_saddle.push({
lat: 3.6980555556e+01,
lng: 1.3952788889e+02,
content:'Saddle = 1529.199951 pos = 36.9806,139.5279 diff = 223.400024'
});
data_peak.push({
lat: 3.6805222223e+01,
lng: 1.3913255556e+02,
cert : true,
content:'Name = Hotakayama(JA/GM-005) peak = 2156.600098 pos = 36.8052,139.1326 diff = 614.800049'
});
data_saddle.push({
lat: 3.6837000000e+01,
lng: 1.3918177778e+02,
content:'Saddle = 1541.800049 pos = 36.8370,139.1818 diff = 614.800049'
});
data_peak.push({
lat: 3.7085333334e+01,
lng: 1.3907755556e+02,
cert : true,
content:'Name = Nakanodake(JA/NI-009) peak = 2082.899902 pos = 37.0853,139.0776 diff = 530.199951'
});
data_saddle.push({
lat: 3.7050888889e+01,
lng: 1.3911322222e+02,
content:'Saddle = 1552.699951 pos = 37.0509,139.1132 diff = 530.199951'
});
data_peak.push({
lat: 3.7100444445e+01,
lng: 1.3914811111e+02,
cert : true,
content:'Name = Arasawadake(JA/NI-014) peak = 1966.400024 pos = 37.1004,139.1481 diff = 324.500000'
});
data_saddle.push({
lat: 3.7069444445e+01,
lng: 1.3911577778e+02,
content:'Saddle = 1641.900024 pos = 37.0694,139.1158 diff = 324.500000'
});
data_peak.push({
lat: 3.7078444445e+01,
lng: 1.3913766667e+02,
cert : false,
content:' Peak = 1852.199951 pos = 37.0784,139.1377 diff = 154.699951'
});
data_saddle.push({
lat: 3.7089444445e+01,
lng: 1.3913844444e+02,
content:'Saddle = 1697.500000 pos = 37.0894,139.1384 diff = 154.699951'
});
data_peak.push({
lat: 3.6987333334e+01,
lng: 1.3904722222e+02,
cert : true,
content:'Name = JA/GM-018(JA/GM-018) peak = 1945.199951 pos = 36.9873,139.0472 diff = 292.699951'
});
data_saddle.push({
lat: 3.7006111112e+01,
lng: 1.3906966667e+02,
content:'Saddle = 1652.500000 pos = 37.0061,139.0697 diff = 292.699951'
});
data_peak.push({
lat: 3.7008666667e+01,
lng: 1.3908044444e+02,
cert : false,
content:' Peak = 1862.500000 pos = 37.0087,139.0804 diff = 190.300049'
});
data_saddle.push({
lat: 3.7035111111e+01,
lng: 1.3908977778e+02,
content:'Saddle = 1672.199951 pos = 37.0351,139.0898 diff = 190.300049'
});
data_peak.push({
lat: 3.7123666667e+01,
lng: 1.3907522222e+02,
cert : true,
content:'Name = Komagatake(JA/NI-012) peak = 2002.400024 pos = 37.1237,139.0752 diff = 288.200073'
});
data_saddle.push({
lat: 3.7108777778e+01,
lng: 1.3907766667e+02,
content:'Saddle = 1714.199951 pos = 37.1088,139.0777 diff = 288.200073'
});
data_peak.push({
lat: 3.7066333334e+01,
lng: 1.3909788889e+02,
cert : true,
content:'Name = JA/NI-016(JA/NI-016) peak = 1924.000000 pos = 37.0663,139.0979 diff = 195.300049'
});
data_saddle.push({
lat: 3.7075222223e+01,
lng: 1.3908255556e+02,
content:'Saddle = 1728.699951 pos = 37.0752,139.0826 diff = 195.300049'
});
data_peak.push({
lat: 3.6903555556e+01,
lng: 1.3917322222e+02,
cert : true,
content:'Name = Shibutsusan(JA/GM-002) peak = 2226.000000 pos = 36.9036,139.1732 diff = 635.000000'
});
data_saddle.push({
lat: 3.6890222223e+01,
lng: 1.3920033333e+02,
content:'Saddle = 1591.000000 pos = 36.8902,139.2003 diff = 635.000000'
});
data_peak.push({
lat: 3.6841333334e+01,
lng: 1.3919811111e+02,
cert : true,
content:'Name = JA/GM-022(JA/GM-022) peak = 1897.199951 pos = 36.8413,139.1981 diff = 284.699951'
});
data_saddle.push({
lat: 3.6860444445e+01,
lng: 1.3918277778e+02,
content:'Saddle = 1612.500000 pos = 36.8604,139.1828 diff = 284.699951'
});
data_peak.push({
lat: 3.7002111112e+01,
lng: 1.3917077778e+02,
cert : true,
content:'Name = Hiragatake(JA/NI-006) peak = 2140.800049 pos = 37.0021,139.1708 diff = 514.500000'
});
data_saddle.push({
lat: 3.6931444445e+01,
lng: 1.3917044444e+02,
content:'Saddle = 1626.300049 pos = 36.9314,139.1704 diff = 514.500000'
});
data_peak.push({
lat: 3.6960555556e+01,
lng: 1.3914522222e+02,
cert : false,
content:' Peak = 1951.699951 pos = 36.9606,139.1452 diff = 190.699951'
});
data_saddle.push({
lat: 3.6957888889e+01,
lng: 1.3915677778e+02,
content:'Saddle = 1761.000000 pos = 36.9579,139.1568 diff = 190.699951'
});
data_peak.push({
lat: 3.6956888889e+01,
lng: 1.3921055556e+02,
cert : true,
content:'Name = Keiduruyama(JA/GM-012) peak = 2002.400024 pos = 36.9569,139.2106 diff = 210.300049'
});
data_saddle.push({
lat: 3.6972555556e+01,
lng: 1.3917533333e+02,
content:'Saddle = 1792.099976 pos = 36.9726,139.1753 diff = 210.300049'
});
data_peak.push({
lat: 3.6689888889e+01,
lng: 1.3933688889e+02,
cert : true,
content:'Name = Sukaisan(JA/TG-009) peak = 2141.600098 pos = 36.6899,139.3369 diff = 548.700073'
});
data_saddle.push({
lat: 3.6701444445e+01,
lng: 1.3935022222e+02,
content:'Saddle = 1592.900024 pos = 36.7014,139.3502 diff = 548.700073'
});
data_peak.push({
lat: 3.6844444445e+01,
lng: 1.3947666667e+02,
cert : false,
content:' Peak = 1791.300049 pos = 36.8444,139.4767 diff = 188.600098'
});
data_saddle.push({
lat: 3.6834222223e+01,
lng: 1.3947688889e+02,
content:'Saddle = 1602.699951 pos = 36.8342,139.4769 diff = 188.600098'
});
data_peak.push({
lat: 3.6987444445e+01,
lng: 1.3941333333e+02,
cert : false,
content:' Peak = 1844.199951 pos = 36.9874,139.4133 diff = 176.299927'
});
data_saddle.push({
lat: 3.6991555556e+01,
lng: 1.3943177778e+02,
content:'Saddle = 1667.900024 pos = 36.9916,139.4318 diff = 176.299927'
});
data_peak.push({
lat: 3.6724666667e+01,
lng: 1.3936677778e+02,
cert : true,
content:'Name = JA/TG-012(JA/TG-012) peak = 1980.099976 pos = 36.7247,139.3668 diff = 276.900024'
});
data_saddle.push({
lat: 3.6736444445e+01,
lng: 1.3936700000e+02,
content:'Saddle = 1703.199951 pos = 36.7364,139.3670 diff = 276.900024'
});
data_peak.push({
lat: 3.6724444445e+01,
lng: 1.3941155556e+02,
cert : true,
content:'Name = JA/TG-013(JA/TG-013) peak = 1974.900024 pos = 36.7244,139.4116 diff = 183.200073'
});
data_saddle.push({
lat: 3.6724000001e+01,
lng: 1.3938955556e+02,
content:'Saddle = 1791.699951 pos = 36.7240,139.3896 diff = 183.200073'
});
data_peak.push({
lat: 3.6811333334e+01,
lng: 1.3943988889e+02,
cert : true,
content:'Name = JA/TG-014(JA/TG-014) peak = 1943.900024 pos = 36.8113,139.4399 diff = 227.400024'
});
data_saddle.push({
lat: 3.6813333334e+01,
lng: 1.3945044444e+02,
content:'Saddle = 1716.500000 pos = 36.8133,139.4504 diff = 227.400024'
});
data_peak.push({
lat: 3.6886444445e+01,
lng: 1.3927177778e+02,
cert : true,
content:'Name = JA/GM-011(JA/GM-011) peak = 2023.400024 pos = 36.8864,139.2718 diff = 301.400024'
});
data_saddle.push({
lat: 3.6920444445e+01,
lng: 1.3929466667e+02,
content:'Saddle = 1722.000000 pos = 36.9204,139.2947 diff = 301.400024'
});
data_peak.push({
lat: 3.6914777778e+01,
lng: 1.3927788889e+02,
cert : false,
content:' Peak = 1916.099976 pos = 36.9148,139.2779 diff = 168.299927'
});
data_saddle.push({
lat: 3.6907666667e+01,
lng: 1.3927488889e+02,
content:'Saddle = 1747.800049 pos = 36.9077,139.2749 diff = 168.299927'
});
data_peak.push({
lat: 3.6765222223e+01,
lng: 1.3949077778e+02,
cert : true,
content:'Name = Nantaisan(JA/TG-002) peak = 2483.300049 pos = 36.7652,139.4908 diff = 755.600098'
});
data_saddle.push({
lat: 3.6823888889e+01,
lng: 1.3945855556e+02,
content:'Saddle = 1727.699951 pos = 36.8239,139.4586 diff = 755.600098'
});
data_peak.push({
lat: 3.6811555556e+01,
lng: 1.3953644444e+02,
cert : true,
content:'Name = Nyohousan(JA/TG-003) peak = 2480.100098 pos = 36.8116,139.5364 diff = 695.300049'
});
data_saddle.push({
lat: 3.6784555556e+01,
lng: 1.3950133333e+02,
content:'Saddle = 1784.800049 pos = 36.7846,139.5013 diff = 695.300049'
});
data_peak.push({
lat: 3.6817888889e+01,
lng: 1.3948277778e+02,
cert : true,
content:'Name = Tarousan(JA/TG-006) peak = 2365.699951 pos = 36.8179,139.4828 diff = 486.399902'
});
data_saddle.push({
lat: 3.6813888889e+01,
lng: 1.3949500000e+02,
content:'Saddle = 1879.300049 pos = 36.8139,139.4950 diff = 486.399902'
});
data_peak.push({
lat: 3.6818000000e+01,
lng: 1.3946300000e+02,
cert : false,
content:' Peak = 2075.300049 pos = 36.8180,139.4630 diff = 156.900024'
});
data_saddle.push({
lat: 3.6817222223e+01,
lng: 1.3946855556e+02,
content:'Saddle = 1918.400024 pos = 36.8172,139.4686 diff = 156.900024'
});
data_peak.push({
lat: 3.6795333334e+01,
lng: 1.3950700000e+02,
cert : true,
content:'Name = Nyohousan (Oomanagosan)(JA/TG-005) peak = 2374.699951 pos = 36.7953,139.5070 diff = 335.899902'
});
data_saddle.push({
lat: 3.6810333334e+01,
lng: 1.3951555556e+02,
content:'Saddle = 2038.800049 pos = 36.8103,139.5156 diff = 335.899902'
});
data_peak.push({
lat: 3.6807333334e+01,
lng: 1.3951077778e+02,
cert : false,
content:' Peak = 2322.500000 pos = 36.8073,139.5108 diff = 210.100098'
});
data_saddle.push({
lat: 3.6802888889e+01,
lng: 1.3951088889e+02,
content:'Saddle = 2112.399902 pos = 36.8029,139.5109 diff = 210.100098'
});
data_peak.push({
lat: 3.6955222223e+01,
lng: 1.3928522222e+02,
cert : true,
content:'Name = Hiuchigatake (Shibayasugura)(JA/FS-001) peak = 2353.100098 pos = 36.9552,139.2852 diff = 620.000122'
});
data_saddle.push({
lat: 3.6942444445e+01,
lng: 1.3931311111e+02,
content:'Saddle = 1733.099976 pos = 36.9424,139.3131 diff = 620.000122'
});
data_peak.push({
lat: 3.6969888889e+01,
lng: 1.3946000000e+02,
cert : true,
content:'Name = Taishakuzan(JA/TG-011) peak = 2056.800049 pos = 36.9699,139.4600 diff = 269.500000'
});
data_saddle.push({
lat: 3.6963888889e+01,
lng: 1.3945866667e+02,
content:'Saddle = 1787.300049 pos = 36.9639,139.4587 diff = 269.500000'
});
data_peak.push({
lat: 3.6844111112e+01,
lng: 1.3932977778e+02,
cert : true,
content:'Name = JA/GM-006(JA/GM-006) peak = 2155.100098 pos = 36.8441,139.3298 diff = 333.600098'
});
data_saddle.push({
lat: 3.6847888889e+01,
lng: 1.3933588889e+02,
content:'Saddle = 1821.500000 pos = 36.8479,139.3359 diff = 333.600098'
});
data_peak.push({
lat: 3.6827111112e+01,
lng: 1.3944766667e+02,
cert : false,
content:' Peak = 2020.199951 pos = 36.8271,139.4477 diff = 168.699951'
});
data_saddle.push({
lat: 3.6829444445e+01,
lng: 1.3943888889e+02,
content:'Saddle = 1851.500000 pos = 36.8294,139.4389 diff = 168.699951'
});
data_peak.push({
lat: 3.6947555556e+01,
lng: 1.3944177778e+02,
cert : false,
content:' Peak = 2060.399902 pos = 36.9476,139.4418 diff = 187.899902'
});
data_saddle.push({
lat: 3.6939444445e+01,
lng: 1.3943466667e+02,
content:'Saddle = 1872.500000 pos = 36.9394,139.4347 diff = 187.899902'
});
data_peak.push({
lat: 3.6913000000e+01,
lng: 1.3934922222e+02,
cert : false,
content:' Peak = 2041.699951 pos = 36.9130,139.3492 diff = 163.299927'
});
data_saddle.push({
lat: 3.6916333334e+01,
lng: 1.3936033333e+02,
content:'Saddle = 1878.400024 pos = 36.9163,139.3603 diff = 163.299927'
});
data_peak.push({
lat: 3.6852777778e+01,
lng: 1.3934844444e+02,
cert : true,
content:'Name = JA/GM-003(JA/GM-003) peak = 2220.800049 pos = 36.8528,139.3484 diff = 278.600098'
});
data_saddle.push({
lat: 3.6840333334e+01,
lng: 1.3937066667e+02,
content:'Saddle = 1942.199951 pos = 36.8403,139.3707 diff = 278.600098'
});
data_peak.push({
lat: 3.6908777778e+01,
lng: 1.3939366667e+02,
cert : true,
content:'Name = Kuroiwayama(JA/TG-008) peak = 2161.600098 pos = 36.9088,139.3937 diff = 189.900146'
});
data_saddle.push({
lat: 3.6901888889e+01,
lng: 1.3938922222e+02,
content:'Saddle = 1971.699951 pos = 36.9019,139.3892 diff = 189.900146'
});
data_peak.push({
lat: 3.6824555556e+01,
lng: 1.3940377778e+02,
cert : true,
content:'Name = JA/TG-007(JA/TG-007) peak = 2331.399902 pos = 36.8246,139.4038 diff = 320.099854'
});
data_saddle.push({
lat: 3.6819000000e+01,
lng: 1.3939500000e+02,
content:'Saddle = 2011.300049 pos = 36.8190,139.3950 diff = 320.099854'
});
data_peak.push({
lat: 3.6773666667e+01,
lng: 1.3935300000e+02,
cert : true,
content:'Name = JA/TG-004(JA/TG-004) peak = 2386.199951 pos = 36.7737,139.3530 diff = 218.500000'
});
data_saddle.push({
lat: 3.6777555556e+01,
lng: 1.3936144444e+02,
content:'Saddle = 2167.699951 pos = 36.7776,139.3614 diff = 218.500000'
});
data_peak.push({
lat: 3.7136888889e+01,
lng: 1.3852711111e+02,
cert : true,
content:'Name = JA/NI-113(JA/NI-113) peak = 540.299988 pos = 37.1369,138.5271 diff = 183.500000'
});
data_saddle.push({
lat: 3.7118000000e+01,
lng: 1.3852722222e+02,
content:'Saddle = 356.799988 pos = 37.1180,138.5272 diff = 183.500000'
});
data_peak.push({
lat: 3.7091333334e+01,
lng: 1.3807411111e+02,
cert : true,
content:'Name = JA/NI-107(JA/NI-107) peak = 597.700012 pos = 37.0913,138.0741 diff = 225.900024'
});
data_saddle.push({
lat: 3.7073444445e+01,
lng: 1.3808688889e+02,
content:'Saddle = 371.799988 pos = 37.0734,138.0869 diff = 225.900024'
});
data_peak.push({
lat: 3.6669222223e+01,
lng: 1.3745322222e+02,
cert : false,
content:' Peak = 754.900024 pos = 36.6692,137.4532 diff = 377.400024'
});
data_saddle.push({
lat: 3.6666777778e+01,
lng: 1.3746855556e+02,
content:'Saddle = 377.500000 pos = 36.6668,137.4686 diff = 377.400024'
});
data_peak.push({
lat: 3.6888666667e+01,
lng: 1.3759200000e+02,
cert : false,
content:' Peak = 557.799988 pos = 36.8887,137.5920 diff = 168.799988'
});
data_saddle.push({
lat: 3.6885000000e+01,
lng: 1.3759366667e+02,
content:'Saddle = 389.000000 pos = 36.8850,137.5937 diff = 168.799988'
});
data_peak.push({
lat: 3.6995888889e+01,
lng: 1.3775544444e+02,
cert : false,
content:' Peak = 593.700012 pos = 36.9959,137.7554 diff = 176.400024'
});
data_saddle.push({
lat: 3.6990333334e+01,
lng: 1.3775411111e+02,
content:'Saddle = 417.299988 pos = 36.9903,137.7541 diff = 176.400024'
});
data_peak.push({
lat: 3.7082444445e+01,
lng: 1.3867233333e+02,
cert : true,
content:'Name = JA/NI-096(JA/NI-096) peak = 640.299988 pos = 37.0824,138.6723 diff = 185.699982'
});
data_saddle.push({
lat: 3.7061111111e+01,
lng: 1.3865422222e+02,
content:'Saddle = 454.600006 pos = 37.0611,138.6542 diff = 185.699982'
});
data_peak.push({
lat: 3.6740222223e+01,
lng: 1.3764900000e+02,
cert : false,
content:' Peak = 757.200012 pos = 36.7402,137.6490 diff = 162.600037'
});
data_saddle.push({
lat: 3.6741111112e+01,
lng: 1.3765144444e+02,
content:'Saddle = 594.599976 pos = 36.7411,137.6514 diff = 162.600037'
});
data_peak.push({
lat: 3.6976555556e+01,
lng: 1.3838233333e+02,
cert : true,
content:'Name = JA/NN-157(JA/NN-157) peak = 1287.500000 pos = 36.9766,138.3823 diff = 657.099976'
});
data_saddle.push({
lat: 3.6878666667e+01,
lng: 1.3832333333e+02,
content:'Saddle = 630.400024 pos = 36.8787,138.3233 diff = 657.099976'
});
data_peak.push({
lat: 3.7025111112e+01,
lng: 1.3850122222e+02,
cert : true,
content:'Name = JA/NN-167(JA/NN-167) peak = 1155.699951 pos = 37.0251,138.5012 diff = 192.699951'
});
data_saddle.push({
lat: 3.7006000000e+01,
lng: 1.3842700000e+02,
content:'Saddle = 963.000000 pos = 37.0060,138.4270 diff = 192.699951'
});
data_peak.push({
lat: 3.6837444445e+01,
lng: 1.3827422222e+02,
cert : true,
content:'Name = Madaraoyama(JA/NN-141) peak = 1381.400024 pos = 36.8374,138.2742 diff = 707.400024'
});
data_saddle.push({
lat: 3.6808000000e+01,
lng: 1.3819700000e+02,
content:'Saddle = 674.000000 pos = 36.8080,138.1970 diff = 707.400024'
});
data_peak.push({
lat: 3.6880888889e+01,
lng: 1.3829444444e+02,
cert : false,
content:' Peak = 1025.699951 pos = 36.8809,138.2944 diff = 162.099976'
});
data_saddle.push({
lat: 3.6872444445e+01,
lng: 1.3829377778e+02,
content:'Saddle = 863.599976 pos = 36.8724,138.2938 diff = 162.099976'
});
data_peak.push({
lat: 3.6865444445e+01,
lng: 1.3825766667e+02,
cert : true,
content:'Name = JA/NN-173(JA/NN-173) peak = 1134.900024 pos = 36.8654,138.2577 diff = 228.100037'
});
data_saddle.push({
lat: 3.6859777778e+01,
lng: 1.3827055556e+02,
content:'Saddle = 906.799988 pos = 36.8598,138.2706 diff = 228.100037'
});
data_peak.push({
lat: 3.6703444445e+01,
lng: 1.3747022222e+02,
cert : false,
content:' Peak = 877.599976 pos = 36.7034,137.4702 diff = 179.799988'
});
data_saddle.push({
lat: 3.6696444445e+01,
lng: 1.3747277778e+02,
content:'Saddle = 697.799988 pos = 36.6964,137.4728 diff = 179.799988'
});
data_peak.push({
lat: 3.6666777778e+01,
lng: 1.3805211111e+02,
cert : false,
content:' Peak = 871.799988 pos = 36.6668,138.0521 diff = 154.799988'
});
data_saddle.push({
lat: 3.6666777778e+01,
lng: 1.3804722222e+02,
content:'Saddle = 717.000000 pos = 36.6668,138.0472 diff = 154.799988'
});
data_peak.push({
lat: 3.6922777778e+01,
lng: 1.3806811111e+02,
cert : true,
content:'Name = Hiuchiyama(JA/NI-002) peak = 2461.399902 pos = 36.9228,138.0681 diff = 1739.999878'
});
data_saddle.push({
lat: 3.6666777778e+01,
lng: 1.3785177778e+02,
content:'Saddle = 721.400024 pos = 36.6668,137.8518 diff = 1739.999878'
});
data_peak.push({
lat: 3.6666777778e+01,
lng: 1.3803377778e+02,
cert : false,
content:' Peak = 974.599976 pos = 36.6668,138.0338 diff = 235.500000'
});
data_saddle.push({
lat: 3.6666777778e+01,
lng: 1.3802944444e+02,
content:'Saddle = 739.099976 pos = 36.6668,138.0294 diff = 235.500000'
});
data_peak.push({
lat: 3.6808555556e+01,
lng: 1.3791822222e+02,
cert : false,
content:' Peak = 936.799988 pos = 36.8086,137.9182 diff = 188.899963'
});
data_saddle.push({
lat: 3.6811333334e+01,
lng: 1.3792577778e+02,
content:'Saddle = 747.900024 pos = 36.8113,137.9258 diff = 188.899963'
});
data_peak.push({
lat: 3.6914111112e+01,
lng: 1.3789344444e+02,
cert : true,
content:'Name = JA/NN-186(JA/NN-186) peak = 974.299988 pos = 36.9141,137.8934 diff = 225.399963'
});
data_saddle.push({
lat: 3.6902444445e+01,
lng: 1.3791022222e+02,
content:'Saddle = 748.900024 pos = 36.9024,137.9102 diff = 225.399963'
});
data_peak.push({
lat: 3.6666777778e+01,
lng: 1.3801077778e+02,
cert : false,
content:' Peak = 1178.800049 pos = 36.6668,138.0108 diff = 386.100037'
});
data_saddle.push({
lat: 3.6666777778e+01,
lng: 1.3798122222e+02,
content:'Saddle = 792.700012 pos = 36.6668,137.9812 diff = 386.100037'
});
data_peak.push({
lat: 3.6666777778e+01,
lng: 1.3802422222e+02,
cert : false,
content:' Peak = 1031.000000 pos = 36.6668,138.0242 diff = 192.900024'
});
data_saddle.push({
lat: 3.6666777778e+01,
lng: 1.3801700000e+02,
content:'Saddle = 838.099976 pos = 36.6668,138.0170 diff = 192.900024'
});
data_peak.push({
lat: 3.7028666667e+01,
lng: 1.3802633333e+02,
cert : true,
content:'Name = Hokogatake(JA/NI-036) peak = 1315.199951 pos = 37.0287,138.0263 diff = 516.699951'
});
data_saddle.push({
lat: 3.7000777778e+01,
lng: 1.3803922222e+02,
content:'Saddle = 798.500000 pos = 37.0008,138.0392 diff = 516.699951'
});
data_peak.push({
lat: 3.6674222223e+01,
lng: 1.3787122222e+02,
cert : false,
content:' Peak = 1058.500000 pos = 36.6742,137.8712 diff = 244.000000'
});
data_saddle.push({
lat: 3.6666777778e+01,
lng: 1.3788155556e+02,
content:'Saddle = 814.500000 pos = 36.6668,137.8816 diff = 244.000000'
});
data_peak.push({
lat: 3.7044111111e+01,
lng: 1.3815944444e+02,
cert : true,
content:'Name = JA/NI-057(JA/NI-057) peak = 1028.500000 pos = 37.0441,138.1594 diff = 191.000000'
});
data_saddle.push({
lat: 3.7036444445e+01,
lng: 1.3815888889e+02,
content:'Saddle = 837.500000 pos = 37.0364,138.1589 diff = 191.000000'
});
data_peak.push({
lat: 3.6670666667e+01,
lng: 1.3795700000e+02,
cert : false,
content:' Peak = 1113.800049 pos = 36.6707,137.9570 diff = 262.100037'
});
data_saddle.push({
lat: 3.6666777778e+01,
lng: 1.3792688889e+02,
content:'Saddle = 851.700012 pos = 36.6668,137.9269 diff = 262.100037'
});
data_peak.push({
lat: 3.6738777778e+01,
lng: 1.3790566667e+02,
cert : true,
content:'Name = JA/NN-144(JA/NN-144) peak = 1354.900024 pos = 36.7388,137.9057 diff = 325.800049'
});
data_saddle.push({
lat: 3.6737222223e+01,
lng: 1.3791644444e+02,
content:'Saddle = 1029.099976 pos = 36.7372,137.9164 diff = 325.800049'
});
data_peak.push({
lat: 3.7031333334e+01,
lng: 1.3813600000e+02,
cert : true,
content:'Name = JA/NI-042(JA/NI-042) peak = 1203.400024 pos = 37.0313,138.1360 diff = 164.599976'
});
data_saddle.push({
lat: 3.7012666667e+01,
lng: 1.3814022222e+02,
content:'Saddle = 1038.800049 pos = 37.0127,138.1402 diff = 164.599976'
});
data_peak.push({
lat: 3.6699111112e+01,
lng: 1.3803977778e+02,
cert : true,
content:'Name = JA/NN-136(JA/NN-136) peak = 1430.800049 pos = 36.6991,138.0398 diff = 354.100098'
});
data_saddle.push({
lat: 3.6719666667e+01,
lng: 1.3804422222e+02,
content:'Saddle = 1076.699951 pos = 36.7197,138.0442 diff = 354.100098'
});
data_peak.push({
lat: 3.6989444445e+01,
lng: 1.3813155556e+02,
cert : true,
content:'Name = JA/NI-030(JA/NI-030) peak = 1430.900024 pos = 36.9894,138.1316 diff = 350.000000'
});
data_saddle.push({
lat: 3.6976333334e+01,
lng: 1.3810777778e+02,
content:'Saddle = 1080.900024 pos = 36.9763,138.1078 diff = 350.000000'
});
data_peak.push({
lat: 3.6870444445e+01,
lng: 1.3791888889e+02,
cert : true,
content:'Name = JA/NN-149(JA/NN-149) peak = 1321.000000 pos = 36.8704,137.9189 diff = 166.900024'
});
data_saddle.push({
lat: 3.6870333334e+01,
lng: 1.3793655556e+02,
content:'Saddle = 1154.099976 pos = 36.8703,137.9366 diff = 166.900024'
});
data_peak.push({
lat: 3.6963111112e+01,
lng: 1.3797477778e+02,
cert : true,
content:'Name = JA/NI-026(JA/NI-026) peak = 1510.400024 pos = 36.9631,137.9748 diff = 302.900024'
});
data_saddle.push({
lat: 3.6953333334e+01,
lng: 1.3797900000e+02,
content:'Saddle = 1207.500000 pos = 36.9533,137.9790 diff = 302.900024'
});
data_peak.push({
lat: 3.6971222223e+01,
lng: 1.3810244444e+02,
cert : false,
content:' Peak = 1430.000000 pos = 36.9712,138.1024 diff = 217.500000'
});
data_saddle.push({
lat: 3.6964333334e+01,
lng: 1.3810566667e+02,
content:'Saddle = 1212.500000 pos = 36.9643,138.1057 diff = 217.500000'
});
data_peak.push({
lat: 3.6739555556e+01,
lng: 1.3813366667e+02,
cert : true,
content:'Name = Iidunayama (Iidunayama)(JA/NN-077) peak = 1916.000000 pos = 36.7396,138.1337 diff = 697.199951'
});
data_saddle.push({
lat: 3.6755666667e+01,
lng: 1.3806911111e+02,
content:'Saddle = 1218.800049 pos = 36.7557,138.0691 diff = 697.199951'
});
data_peak.push({
lat: 3.6931888889e+01,
lng: 1.3796877778e+02,
cert : true,
content:'Name = Nokogiridake(JA/NI-020) peak = 1630.400024 pos = 36.9319,137.9688 diff = 361.700073'
});
data_saddle.push({
lat: 3.6924777778e+01,
lng: 1.3797188889e+02,
content:'Saddle = 1268.699951 pos = 36.9248,137.9719 diff = 361.700073'
});
data_peak.push({
lat: 3.6938777778e+01,
lng: 1.3795388889e+02,
cert : true,
content:'Name = JA/NI-022(JA/NI-022) peak = 1590.099976 pos = 36.9388,137.9539 diff = 171.799927'
});
data_saddle.push({
lat: 3.6937000000e+01,
lng: 1.3795966667e+02,
content:'Saddle = 1418.300049 pos = 36.9370,137.9597 diff = 171.799927'
});
data_peak.push({
lat: 3.6862333334e+01,
lng: 1.3795488889e+02,
cert : false,
content:' Peak = 1570.099976 pos = 36.8623,137.9549 diff = 287.599976'
});
data_saddle.push({
lat: 3.6869555556e+01,
lng: 1.3796100000e+02,
content:'Saddle = 1282.500000 pos = 36.8696,137.9610 diff = 287.599976'
});
data_peak.push({
lat: 3.6952555556e+01,
lng: 1.3811177778e+02,
cert : true,
content:'Name = JA/NI-027(JA/NI-027) peak = 1493.699951 pos = 36.9526,138.1118 diff = 185.299927'
});
data_saddle.push({
lat: 3.6946222223e+01,
lng: 1.3810644444e+02,
content:'Saddle = 1308.400024 pos = 36.9462,138.1064 diff = 185.299927'
});
data_peak.push({
lat: 3.6878444445e+01,
lng: 1.3796711111e+02,
cert : false,
content:' Peak = 1482.300049 pos = 36.8784,137.9671 diff = 160.600098'
});
data_saddle.push({
lat: 3.6884444445e+01,
lng: 1.3796277778e+02,
content:'Saddle = 1321.699951 pos = 36.8844,137.9628 diff = 160.600098'
});
data_peak.push({
lat: 3.6722888889e+01,
lng: 1.3798933333e+02,
cert : false,
content:' Peak = 1561.900024 pos = 36.7229,137.9893 diff = 199.599976'
});
data_saddle.push({
lat: 3.6730666667e+01,
lng: 1.3798922222e+02,
content:'Saddle = 1362.300049 pos = 36.7307,137.9892 diff = 199.599976'
});
data_peak.push({
lat: 3.6902000000e+01,
lng: 1.3796255556e+02,
cert : true,
content:'Name = Amakazariyama(JA/NN-072) peak = 1961.099976 pos = 36.9020,137.9626 diff = 442.299927'
});
data_saddle.push({
lat: 3.6909444445e+01,
lng: 1.3797777778e+02,
content:'Saddle = 1518.800049 pos = 36.9094,137.9778 diff = 442.299927'
});
data_peak.push({
lat: 3.6813555556e+01,
lng: 1.3812711111e+02,
cert : true,
content:'Name = Kurohimeyama(JA/NN-062) peak = 2052.199951 pos = 36.8136,138.1271 diff = 499.899902'
});
data_saddle.push({
lat: 3.6797555556e+01,
lng: 1.3808077778e+02,
content:'Saddle = 1552.300049 pos = 36.7976,138.0808 diff = 499.899902'
});
data_peak.push({
lat: 3.6813555556e+01,
lng: 1.3808777778e+02,
cert : true,
content:'Name = JA/NN-086(JA/NN-086) peak = 1822.599976 pos = 36.8136,138.0878 diff = 224.500000'
});
data_saddle.push({
lat: 3.6813111112e+01,
lng: 1.3810144444e+02,
content:'Saddle = 1598.099976 pos = 36.8131,138.1014 diff = 224.500000'
});
data_peak.push({
lat: 3.6817444445e+01,
lng: 1.3811688889e+02,
cert : true,
content:'Name = JA/NN-064(JA/NN-064) peak = 2045.199951 pos = 36.8174,138.1169 diff = 188.599976'
});
data_saddle.push({
lat: 3.6813777778e+01,
lng: 1.3811566667e+02,
content:'Saddle = 1856.599976 pos = 36.8138,138.1157 diff = 188.599976'
});
data_peak.push({
lat: 3.6800111112e+01,
lng: 1.3805188889e+02,
cert : true,
content:'Name = Takatsumayama(JA/NN-042) peak = 2352.300049 pos = 36.8001,138.0519 diff = 799.900024'
});
data_saddle.push({
lat: 3.6867111112e+01,
lng: 1.3802200000e+02,
content:'Saddle = 1552.400024 pos = 36.8671,138.0220 diff = 799.900024'
});
data_peak.push({
lat: 3.6770444445e+01,
lng: 1.3796455556e+02,
cert : true,
content:'Name = JA/NN-084(JA/NN-084) peak = 1845.800049 pos = 36.7704,137.9646 diff = 284.100098'
});
data_saddle.push({
lat: 3.6798000000e+01,
lng: 1.3797833333e+02,
content:'Saddle = 1561.699951 pos = 36.7980,137.9783 diff = 284.100098'
});
data_peak.push({
lat: 3.6828111112e+01,
lng: 1.3800400000e+02,
cert : true,
content:'Name = JA/NI-015(JA/NI-015) peak = 1925.400024 pos = 36.8281,138.0040 diff = 322.500000'
});
data_saddle.push({
lat: 3.6820444445e+01,
lng: 1.3801522222e+02,
content:'Saddle = 1602.900024 pos = 36.8204,138.0152 diff = 322.500000'
});
data_peak.push({
lat: 3.6761888889e+01,
lng: 1.3803022222e+02,
cert : true,
content:'Name = JA/NN-061(JA/NN-061) peak = 2051.000000 pos = 36.7619,138.0302 diff = 333.800049'
});
data_saddle.push({
lat: 3.6768333334e+01,
lng: 1.3804311111e+02,
content:'Saddle = 1717.199951 pos = 36.7683,138.0431 diff = 333.800049'
});
data_peak.push({
lat: 3.6770444445e+01,
lng: 1.3805500000e+02,
cert : false,
content:' Peak = 1902.599976 pos = 36.7704,138.0550 diff = 156.299927'
});
data_saddle.push({
lat: 3.6782666667e+01,
lng: 1.3806311111e+02,
content:'Saddle = 1746.300049 pos = 36.7827,138.0631 diff = 156.299927'
});
data_peak.push({
lat: 3.6833000000e+01,
lng: 1.3805255556e+02,
cert : false,
content:' Peak = 2073.199951 pos = 36.8330,138.0526 diff = 181.899902'
});
data_saddle.push({
lat: 3.6822333334e+01,
lng: 1.3805488889e+02,
content:'Saddle = 1891.300049 pos = 36.8223,138.0549 diff = 181.899902'
});
data_peak.push({
lat: 3.6940444445e+01,
lng: 1.3800755556e+02,
cert : false,
content:' Peak = 1840.800049 pos = 36.9404,138.0076 diff = 168.800049'
});
data_saddle.push({
lat: 3.6935222223e+01,
lng: 1.3802300000e+02,
content:'Saddle = 1672.000000 pos = 36.9352,138.0230 diff = 168.800049'
});
data_peak.push({
lat: 3.6920888889e+01,
lng: 1.3803577778e+02,
cert : true,
content:'Name = Yakeyama(JA/NI-004) peak = 2401.600098 pos = 36.9209,138.0358 diff = 400.300049'
});
data_saddle.push({
lat: 3.6919777778e+01,
lng: 1.3804733333e+02,
content:'Saddle = 2001.300049 pos = 36.9198,138.0473 diff = 400.300049'
});
data_peak.push({
lat: 3.6904333334e+01,
lng: 1.3801388889e+02,
cert : false,
content:' Peak = 2243.699951 pos = 36.9043,138.0139 diff = 191.800049'
});
data_saddle.push({
lat: 3.6911555556e+01,
lng: 1.3802033333e+02,
content:'Saddle = 2051.899902 pos = 36.9116,138.0203 diff = 191.800049'
});
data_peak.push({
lat: 3.6891333334e+01,
lng: 1.3811344444e+02,
cert : true,
content:'Name = Myoukousan(JA/NI-003) peak = 2451.899902 pos = 36.8913,138.1134 diff = 432.999878'
});
data_saddle.push({
lat: 3.6905444445e+01,
lng: 1.3809644444e+02,
content:'Saddle = 2018.900024 pos = 36.9054,138.0964 diff = 432.999878'
});
data_peak.push({
lat: 3.6892222223e+01,
lng: 1.3810277778e+02,
cert : false,
content:' Peak = 2360.000000 pos = 36.8922,138.1028 diff = 249.000000'
});
data_saddle.push({
lat: 3.6892888889e+01,
lng: 1.3810655556e+02,
content:'Saddle = 2111.000000 pos = 36.8929,138.1066 diff = 249.000000'
});
data_peak.push({
lat: 3.6689555556e+01,
lng: 1.3758588889e+02,
cert : true,
content:'Name = Kekachisanzan(JA/TY-014) peak = 2411.899902 pos = 36.6896,137.5859 diff = 1682.999878'
});
data_saddle.push({
lat: 3.6666777778e+01,
lng: 1.3767988889e+02,
content:'Saddle = 728.900024 pos = 36.6668,137.6799 diff = 1682.999878'
});
data_peak.push({
lat: 3.6671111112e+01,
lng: 1.3765122222e+02,
cert : false,
content:' Peak = 1763.900024 pos = 36.6711,137.6512 diff = 678.599976'
});
data_saddle.push({
lat: 3.6666777778e+01,
lng: 1.3763866667e+02,
content:'Saddle = 1085.300049 pos = 36.6668,137.6387 diff = 678.599976'
});
data_peak.push({
lat: 3.6759666667e+01,
lng: 1.3761011111e+02,
cert : false,
content:' Peak = 1394.099976 pos = 36.7597,137.6101 diff = 183.199951'
});
data_saddle.push({
lat: 3.6758000000e+01,
lng: 1.3760611111e+02,
content:'Saddle = 1210.900024 pos = 36.7580,137.6061 diff = 183.199951'
});
data_peak.push({
lat: 3.6689777778e+01,
lng: 1.3750455556e+02,
cert : false,
content:' Peak = 1444.300049 pos = 36.6898,137.5046 diff = 206.700073'
});
data_saddle.push({
lat: 3.6679777778e+01,
lng: 1.3753011111e+02,
content:'Saddle = 1237.599976 pos = 36.6798,137.5301 diff = 206.700073'
});
data_peak.push({
lat: 3.6666777778e+01,
lng: 1.3762611111e+02,
cert : false,
content:' Peak = 1655.199951 pos = 36.6668,137.6261 diff = 150.599976'
});
data_saddle.push({
lat: 3.6666777778e+01,
lng: 1.3761955556e+02,
content:'Saddle = 1504.599976 pos = 36.6668,137.6196 diff = 150.599976'
});
data_peak.push({
lat: 3.6752000000e+01,
lng: 1.3758433333e+02,
cert : true,
content:'Name = Ecchuukomagatake(JA/TY-020) peak = 2001.099976 pos = 36.7520,137.5843 diff = 298.799927'
});
data_saddle.push({
lat: 3.6739333334e+01,
lng: 1.3759022222e+02,
content:'Saddle = 1702.300049 pos = 36.7393,137.5902 diff = 298.799927'
});
data_peak.push({
lat: 3.6723888889e+01,
lng: 1.3761111111e+02,
cert : true,
content:'Name = Sannabikiyama  (Takikurayama)(JA/TY-019) peak = 2026.500000 pos = 36.7239,137.6111 diff = 279.199951'
});
data_saddle.push({
lat: 3.6711666667e+01,
lng: 1.3760344444e+02,
content:'Saddle = 1747.300049 pos = 36.7117,137.6034 diff = 279.199951'
});
data_peak.push({
lat: 3.6831666667e+01,
lng: 1.3764733333e+02,
cert : true,
content:'Name = JA/TY-032(JA/TY-032) peak = 1395.599976 pos = 36.8317,137.6473 diff = 513.399963'
});
data_saddle.push({
lat: 3.6854666667e+01,
lng: 1.3765611111e+02,
content:'Saddle = 882.200012 pos = 36.8547,137.6561 diff = 513.399963'
});
data_peak.push({
lat: 3.6801111112e+01,
lng: 1.3763544444e+02,
cert : false,
content:' Peak = 1351.500000 pos = 36.8011,137.6354 diff = 176.199951'
});
data_saddle.push({
lat: 3.6808777778e+01,
lng: 1.3763866667e+02,
content:'Saddle = 1175.300049 pos = 36.8088,137.6387 diff = 176.199951'
});
data_peak.push({
lat: 3.6976666667e+01,
lng: 1.3779000000e+02,
cert : true,
content:'Name = Kurohimeyama(JA/NI-040) peak = 1221.099976 pos = 36.9767,137.7900 diff = 299.899963'
});
data_saddle.push({
lat: 3.6964777778e+01,
lng: 1.3779044444e+02,
content:'Saddle = 921.200012 pos = 36.9648,137.7904 diff = 299.899963'
});
data_peak.push({
lat: 3.6940888889e+01,
lng: 1.3782177778e+02,
cert : false,
content:' Peak = 1186.400024 pos = 36.9409,137.8218 diff = 262.700012'
});
data_saddle.push({
lat: 3.6947555556e+01,
lng: 1.3781288889e+02,
content:'Saddle = 923.700012 pos = 36.9476,137.8129 diff = 262.700012'
});
data_peak.push({
lat: 3.6944444445e+01,
lng: 1.3771100000e+02,
cert : true,
content:'Name = Shiratoriyama(JA/NI-038) peak = 1285.800049 pos = 36.9444,137.7110 diff = 194.400024'
});
data_saddle.push({
lat: 3.6937777778e+01,
lng: 1.3771366667e+02,
content:'Saddle = 1091.400024 pos = 36.9378,137.7137 diff = 194.400024'
});
data_peak.push({
lat: 3.6666777778e+01,
lng: 1.3781466667e+02,
cert : false,
content:' Peak = 1500.000000 pos = 36.6668,137.8147 diff = 295.000000'
});
data_saddle.push({
lat: 3.6666777778e+01,
lng: 1.3779511111e+02,
content:'Saddle = 1205.000000 pos = 36.6668,137.7951 diff = 295.000000'
});
data_peak.push({
lat: 3.6666777778e+01,
lng: 1.3780133333e+02,
cert : false,
content:' Peak = 1380.800049 pos = 36.6668,137.8013 diff = 163.200073'
});
data_saddle.push({
lat: 3.6666777778e+01,
lng: 1.3780422222e+02,
content:'Saddle = 1217.599976 pos = 36.6668,137.8042 diff = 163.200073'
});
data_peak.push({
lat: 3.6896666667e+01,
lng: 1.3768788889e+02,
cert : true,
content:'Name = Hatsuyukiyama(JA/TY-027) peak = 1610.699951 pos = 36.8967,137.6879 diff = 339.699951'
});
data_saddle.push({
lat: 3.6907888889e+01,
lng: 1.3770644444e+02,
content:'Saddle = 1271.000000 pos = 36.9079,137.7064 diff = 339.699951'
});
data_peak.push({
lat: 3.6666777778e+01,
lng: 1.3779011111e+02,
cert : false,
content:' Peak = 1620.500000 pos = 36.6668,137.7901 diff = 300.599976'
});
data_saddle.push({
lat: 3.6666777778e+01,
lng: 1.3778488889e+02,
content:'Saddle = 1319.900024 pos = 36.6668,137.7849 diff = 300.599976'
});
data_peak.push({
lat: 3.6725888889e+01,
lng: 1.3767755556e+02,
cert : true,
content:'Name = Hyakukanyama(JA/TY-021) peak = 1961.300049 pos = 36.7259,137.6776 diff = 280.900024'
});
data_saddle.push({
lat: 3.6729888889e+01,
lng: 1.3768744444e+02,
content:'Saddle = 1680.400024 pos = 36.7299,137.6874 diff = 280.900024'
});
data_peak.push({
lat: 3.6681111112e+01,
lng: 1.3771844444e+02,
cert : true,
content:'Name = Gakiyama(JA/TY-017) peak = 2126.899902 pos = 36.6811,137.7184 diff = 254.699951'
});
data_saddle.push({
lat: 3.6676666667e+01,
lng: 1.3772811111e+02,
content:'Saddle = 1872.199951 pos = 36.6767,137.7281 diff = 254.699951'
});
data_peak.push({
lat: 3.6666777778e+01,
lng: 1.3773144444e+02,
cert : false,
content:' Peak = 2200.300049 pos = 36.6668,137.7314 diff = 214.400024'
});
data_saddle.push({
lat: 3.6666777778e+01,
lng: 1.3773900000e+02,
content:'Saddle = 1985.900024 pos = 36.6668,137.7390 diff = 214.400024'
});
data_peak.push({
lat: 3.6826777778e+01,
lng: 1.3772977778e+02,
cert : true,
content:'Name = Asahidake(JA/TY-013) peak = 2417.100098 pos = 36.8268,137.7298 diff = 383.800049'
});
data_saddle.push({
lat: 3.6819000000e+01,
lng: 1.3773866667e+02,
content:'Saddle = 2033.300049 pos = 36.8190,137.7387 diff = 383.800049'
});
data_peak.push({
lat: 3.6666777778e+01,
lng: 1.3774366667e+02,
cert : false,
content:' Peak = 2334.600098 pos = 36.6668,137.7437 diff = 195.600098'
});
data_saddle.push({
lat: 3.6666777778e+01,
lng: 1.3775333333e+02,
content:'Saddle = 2139.000000 pos = 36.6668,137.7533 diff = 195.600098'
});
data_peak.push({
lat: 3.6666777778e+01,
lng: 1.3776166667e+02,
cert : false,
content:' Peak = 2468.199951 pos = 36.6668,137.7617 diff = 150.699951'
});
data_saddle.push({
lat: 3.6674222223e+01,
lng: 1.3775855556e+02,
content:'Saddle = 2317.500000 pos = 36.6742,137.7586 diff = 150.699951'
});
data_peak.push({
lat: 3.6794777778e+01,
lng: 1.3775400000e+02,
cert : true,
content:'Name = Yukikuradake(JA/NI-001) peak = 2610.500000 pos = 36.7948,137.7540 diff = 218.600098'
});
data_saddle.push({
lat: 3.6787555556e+01,
lng: 1.3775055556e+02,
content:'Saddle = 2391.899902 pos = 36.7876,137.7506 diff = 218.600098'
});
data_peak.push({
lat: 3.6687222223e+01,
lng: 1.3775455556e+02,
cert : true,
content:'Name = Karamatsudake(JA/TY-008) peak = 2693.000000 pos = 36.6872,137.7546 diff = 276.399902'
});
data_saddle.push({
lat: 3.6700555556e+01,
lng: 1.3775111111e+02,
content:'Saddle = 2416.600098 pos = 36.7006,137.7511 diff = 276.399902'
});
data_peak.push({
lat: 3.6731444445e+01,
lng: 1.3775522222e+02,
cert : true,
content:'Name = Yarigatake(JA/NN-011) peak = 2901.800049 pos = 36.7314,137.7552 diff = 298.900146'
});
data_saddle.push({
lat: 3.6746111112e+01,
lng: 1.3775511111e+02,
content:'Saddle = 2602.899902 pos = 36.7461,137.7551 diff = 298.900146'
});
data_peak.push({
lat: 3.6757666667e+01,
lng: 1.3774577778e+02,
cert : true,
content:'Name = Asahidake(JA/TY-006) peak = 2866.500000 pos = 36.7577,137.7458 diff = 159.100098'
});
data_saddle.push({
lat: 3.6755666667e+01,
lng: 1.3775133333e+02,
content:'Saddle = 2707.399902 pos = 36.7557,137.7513 diff = 159.100098'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:38,
       south:36.6667,
       east:141,
       west:137}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
