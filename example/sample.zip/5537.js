function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.6289222226e+01,
lng: 1.3764788889e+02,
cert : false,
content:' Peak = 3192.300049 pos = 36.2892,137.6479 diff = 3152.500000'
});
data_saddle.push({
lat: 3.7333111111e+01,
lng: 1.3882211111e+02,
content:'Saddle = 39.799999 pos = 37.3331,138.8221 diff = 3152.500000'
});
data_peak.push({
lat: 3.7319777777e+01,
lng: 1.3898622222e+02,
cert : true,
content:'Name = JA/NI-090(JA/NI-090) peak = 680.799988 pos = 37.3198,138.9862 diff = 527.699951'
});
data_saddle.push({
lat: 3.7333333333e+01,
lng: 1.3902888889e+02,
content:'Saddle = 153.100006 pos = 37.3333,139.0289 diff = 527.699951'
});
data_peak.push({
lat: 3.7333333333e+01,
lng: 1.3890544444e+02,
cert : false,
content:' Peak = 454.299988 pos = 37.3333,138.9054 diff = 254.799988'
});
data_saddle.push({
lat: 3.7333222222e+01,
lng: 1.3891744444e+02,
content:'Saddle = 199.500000 pos = 37.3332,138.9174 diff = 254.799988'
});
data_peak.push({
lat: 3.7321888889e+01,
lng: 1.3894400000e+02,
cert : false,
content:' Peak = 458.600006 pos = 37.3219,138.9440 diff = 197.100006'
});
data_saddle.push({
lat: 3.7333000000e+01,
lng: 1.3894755556e+02,
content:'Saddle = 261.500000 pos = 37.3330,138.9476 diff = 197.100006'
});
data_peak.push({
lat: 3.7277666667e+01,
lng: 1.3881111111e+02,
cert : false,
content:' Peak = 335.500000 pos = 37.2777,138.8111 diff = 159.699997'
});
data_saddle.push({
lat: 3.7267777778e+01,
lng: 1.3879155556e+02,
content:'Saddle = 175.800003 pos = 37.2678,138.7916 diff = 159.699997'
});
data_peak.push({
lat: 3.7319111111e+01,
lng: 1.3851900000e+02,
cert : true,
content:'Name = JA/NI-128(JA/NI-128) peak = 461.200012 pos = 37.3191,138.5190 diff = 206.300018'
});
data_saddle.push({
lat: 3.7308777778e+01,
lng: 1.3853311111e+02,
content:'Saddle = 254.899994 pos = 37.3088,138.5331 diff = 206.300018'
});
data_peak.push({
lat: 3.7160555556e+01,
lng: 1.3863100000e+02,
cert : true,
content:'Name = JA/NI-126(JA/NI-126) peak = 483.399994 pos = 37.1606,138.6310 diff = 184.899994'
});
data_saddle.push({
lat: 3.7142555556e+01,
lng: 1.3860477778e+02,
content:'Saddle = 298.500000 pos = 37.1426,138.6048 diff = 184.899994'
});
data_peak.push({
lat: 3.7149555556e+01,
lng: 1.3847488889e+02,
cert : true,
content:'Name = JA/NI-122(JA/NI-122) peak = 505.200012 pos = 37.1496,138.4749 diff = 206.200012'
});
data_saddle.push({
lat: 3.7113666667e+01,
lng: 1.3848522222e+02,
content:'Saddle = 299.000000 pos = 37.1137,138.4852 diff = 206.200012'
});
data_peak.push({
lat: 3.7260333333e+01,
lng: 1.3848833333e+02,
cert : false,
content:' Peak = 477.299988 pos = 37.2603,138.4883 diff = 171.899994'
});
data_saddle.push({
lat: 3.7260222222e+01,
lng: 1.3849300000e+02,
content:'Saddle = 305.399994 pos = 37.2602,138.4930 diff = 171.899994'
});
data_peak.push({
lat: 3.6975777779e+01,
lng: 1.3824766667e+02,
cert : true,
content:'Name = JA/NI-116(JA/NI-116) peak = 527.099976 pos = 36.9758,138.2477 diff = 216.599976'
});
data_saddle.push({
lat: 3.6942555557e+01,
lng: 1.3823000000e+02,
content:'Saddle = 310.500000 pos = 36.9426,138.2300 diff = 216.599976'
});
data_peak.push({
lat: 3.7289555555e+01,
lng: 1.3848388889e+02,
cert : true,
content:'Name = Yoneyama(JA/NI-064) peak = 991.799988 pos = 37.2896,138.4839 diff = 674.500000'
});
data_saddle.push({
lat: 3.7154222223e+01,
lng: 1.3854622222e+02,
content:'Saddle = 317.299988 pos = 37.1542,138.5462 diff = 674.500000'
});
data_peak.push({
lat: 3.7226111111e+01,
lng: 1.3859211111e+02,
cert : true,
content:'Name = Kurohimesan(JA/NI-076) peak = 891.700012 pos = 37.2261,138.5921 diff = 570.700012'
});
data_saddle.push({
lat: 3.7268777778e+01,
lng: 1.3853288889e+02,
content:'Saddle = 321.000000 pos = 37.2688,138.5329 diff = 570.700012'
});
data_peak.push({
lat: 3.7225111111e+01,
lng: 1.3850133333e+02,
cert : true,
content:'Name = JA/NI-086(JA/NI-086) peak = 756.200012 pos = 37.2251,138.5013 diff = 339.000000'
});
data_saddle.push({
lat: 3.7206222222e+01,
lng: 1.3852733333e+02,
content:'Saddle = 417.200012 pos = 37.2062,138.5273 diff = 339.000000'
});
data_peak.push({
lat: 3.7219555556e+01,
lng: 1.3852500000e+02,
cert : true,
content:'Name = JA/NI-091(JA/NI-091) peak = 675.099976 pos = 37.2196,138.5250 diff = 220.699982'
});
data_saddle.push({
lat: 3.7223888889e+01,
lng: 1.3851511111e+02,
content:'Saddle = 454.399994 pos = 37.2239,138.5151 diff = 220.699982'
});
data_peak.push({
lat: 3.6545333336e+01,
lng: 1.3710166667e+02,
cert : false,
content:' Peak = 481.200012 pos = 36.5453,137.1017 diff = 154.100006'
});
data_saddle.push({
lat: 3.6531000003e+01,
lng: 1.3709666667e+02,
content:'Saddle = 327.100006 pos = 36.5310,137.0967 diff = 154.100006'
});
data_peak.push({
lat: 3.7136888889e+01,
lng: 1.3852711111e+02,
cert : true,
content:'Name = JA/NI-113(JA/NI-113) peak = 540.299988 pos = 37.1369,138.5271 diff = 183.500000'
});
data_saddle.push({
lat: 3.7118000001e+01,
lng: 1.3852722222e+02,
content:'Saddle = 356.799988 pos = 37.1180,138.5272 diff = 183.500000'
});
data_peak.push({
lat: 3.7091333334e+01,
lng: 1.3807411111e+02,
cert : true,
content:'Name = JA/NI-107(JA/NI-107) peak = 597.700012 pos = 37.0913,138.0741 diff = 225.900024'
});
data_saddle.push({
lat: 3.7073444445e+01,
lng: 1.3808688889e+02,
content:'Saddle = 371.799988 pos = 37.0734,138.0869 diff = 225.900024'
});
data_peak.push({
lat: 3.6888666668e+01,
lng: 1.3759200000e+02,
cert : false,
content:' Peak = 557.799988 pos = 36.8887,137.5920 diff = 168.799988'
});
data_saddle.push({
lat: 3.6885000001e+01,
lng: 1.3759366667e+02,
content:'Saddle = 389.000000 pos = 36.8850,137.5937 diff = 168.799988'
});
data_peak.push({
lat: 3.6995888890e+01,
lng: 1.3775544444e+02,
cert : false,
content:' Peak = 593.700012 pos = 36.9959,137.7554 diff = 176.400024'
});
data_saddle.push({
lat: 3.6990333334e+01,
lng: 1.3775411111e+02,
content:'Saddle = 417.299988 pos = 36.9903,137.7541 diff = 176.400024'
});
data_peak.push({
lat: 3.7332444444e+01,
lng: 1.3906911111e+02,
cert : true,
content:'Name = JA/NI-103(JA/NI-103) peak = 630.299988 pos = 37.3324,139.0691 diff = 187.500000'
});
data_saddle.push({
lat: 3.7312666666e+01,
lng: 1.3905977778e+02,
content:'Saddle = 442.799988 pos = 37.3127,139.0598 diff = 187.500000'
});
data_peak.push({
lat: 3.7082444445e+01,
lng: 1.3867233333e+02,
cert : true,
content:'Name = JA/NI-096(JA/NI-096) peak = 640.299988 pos = 37.0824,138.6723 diff = 185.699982'
});
data_saddle.push({
lat: 3.7061111112e+01,
lng: 1.3865422222e+02,
content:'Saddle = 454.600006 pos = 37.0611,138.6542 diff = 185.699982'
});
data_peak.push({
lat: 3.6552666669e+01,
lng: 1.3822411111e+02,
cert : false,
content:' Peak = 663.599976 pos = 36.5527,138.2241 diff = 205.099976'
});
data_saddle.push({
lat: 3.6551666669e+01,
lng: 1.3822922222e+02,
content:'Saddle = 458.500000 pos = 36.5517,138.2292 diff = 205.099976'
});
data_peak.push({
lat: 3.7195111111e+01,
lng: 1.3905377778e+02,
cert : true,
content:'Name = JA/NI-093(JA/NI-093) peak = 652.599976 pos = 37.1951,139.0538 diff = 169.899963'
});
data_saddle.push({
lat: 3.7196111111e+01,
lng: 1.3904188889e+02,
content:'Saddle = 482.700012 pos = 37.1961,139.0419 diff = 169.899963'
});
data_peak.push({
lat: 3.6448444448e+01,
lng: 1.3700000000e+02,
cert : false,
content:' Peak = 1083.900024 pos = 36.4484,137.0000 diff = 574.300049'
});
data_saddle.push({
lat: 3.6415888892e+01,
lng: 1.3700000000e+02,
content:'Saddle = 509.600006 pos = 36.4159,137.0000 diff = 574.300049'
});
data_peak.push({
lat: 3.6519555558e+01,
lng: 1.3700866667e+02,
cert : true,
content:'Name = JA/TY-048(JA/TY-048) peak = 860.799988 pos = 36.5196,137.0087 diff = 287.899963'
});
data_saddle.push({
lat: 3.6509111114e+01,
lng: 1.3701055556e+02,
content:'Saddle = 572.900024 pos = 36.5091,137.0106 diff = 287.899963'
});
data_peak.push({
lat: 3.6481888892e+01,
lng: 1.3700733333e+02,
cert : true,
content:'Name = JA/TY-043(JA/TY-043) peak = 1005.400024 pos = 36.4819,137.0073 diff = 182.500000'
});
data_saddle.push({
lat: 3.6469888892e+01,
lng: 1.3700866667e+02,
content:'Saddle = 822.900024 pos = 36.4699,137.0087 diff = 182.500000'
});
data_peak.push({
lat: 3.6540666670e+01,
lng: 1.3725633333e+02,
cert : true,
content:'Name = Kosanami Onmaeyama(JA/TY-052) peak = 756.900024 pos = 36.5407,137.2563 diff = 228.800049'
});
data_saddle.push({
lat: 3.6531111114e+01,
lng: 1.3725922222e+02,
content:'Saddle = 528.099976 pos = 36.5311,137.2592 diff = 228.800049'
});
data_peak.push({
lat: 3.6517555558e+01,
lng: 1.3726611111e+02,
cert : true,
content:'Name = JA/TY-053(JA/TY-053) peak = 751.299988 pos = 36.5176,137.2661 diff = 221.000000'
});
data_saddle.push({
lat: 3.6514111114e+01,
lng: 1.3727611111e+02,
content:'Saddle = 530.299988 pos = 36.5141,137.2761 diff = 221.000000'
});
data_peak.push({
lat: 3.6363333337e+01,
lng: 1.3826133333e+02,
cert : true,
content:'Name = JA/NN-191(JA/NN-191) peak = 800.400024 pos = 36.3633,138.2613 diff = 244.900024'
});
data_saddle.push({
lat: 3.6348111115e+01,
lng: 1.3824922222e+02,
content:'Saddle = 555.500000 pos = 36.3481,138.2492 diff = 244.900024'
});
data_peak.push({
lat: 3.6514000003e+01,
lng: 1.3720088889e+02,
cert : true,
content:'Name = JA/TY-051(JA/TY-051) peak = 781.700012 pos = 36.5140,137.2009 diff = 218.600037'
});
data_saddle.push({
lat: 3.6502777781e+01,
lng: 1.3720244444e+02,
content:'Saddle = 563.099976 pos = 36.5028,137.2024 diff = 218.600037'
});
data_peak.push({
lat: 3.6740222224e+01,
lng: 1.3764900000e+02,
cert : false,
content:' Peak = 757.200012 pos = 36.7402,137.6490 diff = 162.600037'
});
data_saddle.push({
lat: 3.6741111113e+01,
lng: 1.3765144444e+02,
content:'Saddle = 594.599976 pos = 36.7411,137.6514 diff = 162.600037'
});
data_peak.push({
lat: 3.6579111114e+01,
lng: 1.3808633333e+02,
cert : false,
content:' Peak = 774.900024 pos = 36.5791,138.0863 diff = 157.000000'
});
data_saddle.push({
lat: 3.6572222225e+01,
lng: 1.3807288889e+02,
content:'Saddle = 617.900024 pos = 36.5722,138.0729 diff = 157.000000'
});
data_peak.push({
lat: 3.7261444444e+01,
lng: 1.3907477778e+02,
cert : true,
content:'Name = JA/NI-052(JA/NI-052) peak = 1076.000000 pos = 37.2614,139.0748 diff = 455.000000'
});
data_saddle.push({
lat: 3.7227222222e+01,
lng: 1.3911811111e+02,
content:'Saddle = 621.000000 pos = 37.2272,139.1181 diff = 455.000000'
});
data_peak.push({
lat: 3.7300666666e+01,
lng: 1.3908922222e+02,
cert : true,
content:'Name = JA/NI-071(JA/NI-071) peak = 933.200012 pos = 37.3007,139.0892 diff = 201.200012'
});
data_saddle.push({
lat: 3.7267000000e+01,
lng: 1.3908855556e+02,
content:'Saddle = 732.000000 pos = 37.2670,139.0886 diff = 201.200012'
});
data_peak.push({
lat: 3.7269000000e+01,
lng: 1.3904255556e+02,
cert : true,
content:'Name = JA/NI-063(JA/NI-063) peak = 996.700012 pos = 37.2690,139.0426 diff = 243.799988'
});
data_saddle.push({
lat: 3.7266111111e+01,
lng: 1.3905044444e+02,
content:'Saddle = 752.900024 pos = 37.2661,139.0504 diff = 243.799988'
});
data_peak.push({
lat: 3.6506333336e+01,
lng: 1.3704600000e+02,
cert : true,
content:'Name = JA/TY-049(JA/TY-049) peak = 853.200012 pos = 36.5063,137.0460 diff = 229.700012'
});
data_saddle.push({
lat: 3.6500333336e+01,
lng: 1.3705055556e+02,
content:'Saddle = 623.500000 pos = 36.5003,137.0506 diff = 229.700012'
});
data_peak.push({
lat: 3.6530000003e+01,
lng: 1.3706488889e+02,
cert : false,
content:' Peak = 806.400024 pos = 36.5300,137.0649 diff = 153.700012'
});
data_saddle.push({
lat: 3.6526222225e+01,
lng: 1.3706233333e+02,
content:'Saddle = 652.700012 pos = 36.5262,137.0623 diff = 153.700012'
});
data_peak.push({
lat: 3.6537888892e+01,
lng: 1.3730688889e+02,
cert : false,
content:' Peak = 782.299988 pos = 36.5379,137.3069 diff = 155.099976'
});
data_saddle.push({
lat: 3.6533222225e+01,
lng: 1.3730977778e+02,
content:'Saddle = 627.200012 pos = 36.5332,137.3098 diff = 155.099976'
});
data_peak.push({
lat: 3.6976555557e+01,
lng: 1.3838233333e+02,
cert : true,
content:'Name = JA/NN-157(JA/NN-157) peak = 1287.500000 pos = 36.9766,138.3823 diff = 657.099976'
});
data_saddle.push({
lat: 3.6878666668e+01,
lng: 1.3832333333e+02,
content:'Saddle = 630.400024 pos = 36.8787,138.3233 diff = 657.099976'
});
data_peak.push({
lat: 3.7025111112e+01,
lng: 1.3850122222e+02,
cert : true,
content:'Name = JA/NN-167(JA/NN-167) peak = 1155.699951 pos = 37.0251,138.5012 diff = 192.699951'
});
data_saddle.push({
lat: 3.7006000001e+01,
lng: 1.3842700000e+02,
content:'Saddle = 963.000000 pos = 37.0060,138.4270 diff = 192.699951'
});
data_peak.push({
lat: 3.6180444449e+01,
lng: 1.3723033333e+02,
cert : true,
content:'Name = JA/GF-154(JA/GF-154) peak = 823.299988 pos = 36.1804,137.2303 diff = 162.599976'
});
data_saddle.push({
lat: 3.6181111115e+01,
lng: 1.3721888889e+02,
content:'Saddle = 660.700012 pos = 36.1811,137.2189 diff = 162.599976'
});
data_peak.push({
lat: 3.6493444447e+01,
lng: 1.3707977778e+02,
cert : true,
content:'Name = Sodeyama(JA/TY-050) peak = 855.799988 pos = 36.4934,137.0798 diff = 182.799988'
});
data_saddle.push({
lat: 3.6489777781e+01,
lng: 1.3709911111e+02,
content:'Saddle = 673.000000 pos = 36.4898,137.0991 diff = 182.799988'
});
data_peak.push({
lat: 3.6837444446e+01,
lng: 1.3827422222e+02,
cert : true,
content:'Name = Madaraoyama(JA/NN-141) peak = 1381.400024 pos = 36.8374,138.2742 diff = 707.400024'
});
data_saddle.push({
lat: 3.6808000002e+01,
lng: 1.3819700000e+02,
content:'Saddle = 674.000000 pos = 36.8080,138.1970 diff = 707.400024'
});
data_peak.push({
lat: 3.6880888890e+01,
lng: 1.3829444444e+02,
cert : false,
content:' Peak = 1025.699951 pos = 36.8809,138.2944 diff = 162.099976'
});
data_saddle.push({
lat: 3.6872444446e+01,
lng: 1.3829377778e+02,
content:'Saddle = 863.599976 pos = 36.8724,138.2938 diff = 162.099976'
});
data_peak.push({
lat: 3.6865444446e+01,
lng: 1.3825766667e+02,
cert : true,
content:'Name = JA/NN-173(JA/NN-173) peak = 1134.900024 pos = 36.8654,138.2577 diff = 228.100037'
});
data_saddle.push({
lat: 3.6859777779e+01,
lng: 1.3827055556e+02,
content:'Saddle = 906.799988 pos = 36.8598,138.2706 diff = 228.100037'
});
data_peak.push({
lat: 3.6271333337e+01,
lng: 1.3711533333e+02,
cert : true,
content:'Name = JA/GF-127(JA/GF-127) peak = 994.099976 pos = 36.2713,137.1153 diff = 311.599976'
});
data_saddle.push({
lat: 3.6255777782e+01,
lng: 1.3710144444e+02,
content:'Saddle = 682.500000 pos = 36.2558,137.1014 diff = 311.599976'
});
data_peak.push({
lat: 3.6703444447e+01,
lng: 1.3747022222e+02,
cert : false,
content:' Peak = 877.599976 pos = 36.7034,137.4702 diff = 179.799988'
});
data_saddle.push({
lat: 3.6696444447e+01,
lng: 1.3747277778e+02,
content:'Saddle = 697.799988 pos = 36.6964,137.4728 diff = 179.799988'
});
data_peak.push({
lat: 3.6539777781e+01,
lng: 1.3795033333e+02,
cert : false,
content:' Peak = 893.099976 pos = 36.5398,137.9503 diff = 169.000000'
});
data_saddle.push({
lat: 3.6552888892e+01,
lng: 1.3794344444e+02,
content:'Saddle = 724.099976 pos = 36.5529,137.9434 diff = 169.000000'
});
data_peak.push({
lat: 3.6483555559e+01,
lng: 1.3721233333e+02,
cert : true,
content:'Name = JA/TY-046(JA/TY-046) peak = 960.700012 pos = 36.4836,137.2123 diff = 233.900024'
});
data_saddle.push({
lat: 3.6477111114e+01,
lng: 1.3721100000e+02,
content:'Saddle = 726.799988 pos = 36.4771,137.2110 diff = 233.900024'
});
data_peak.push({
lat: 3.6541333336e+01,
lng: 1.3703166667e+02,
cert : true,
content:'Name = Ushidake(JA/TY-044) peak = 985.200012 pos = 36.5413,137.0317 diff = 258.000000'
});
data_saddle.push({
lat: 3.6529444447e+01,
lng: 1.3703355556e+02,
content:'Saddle = 727.200012 pos = 36.5294,137.0336 diff = 258.000000'
});
data_peak.push({
lat: 3.7010333334e+01,
lng: 1.3877355556e+02,
cert : true,
content:'Name = JA/NI-059(JA/NI-059) peak = 1021.599976 pos = 37.0103,138.7736 diff = 294.399963'
});
data_saddle.push({
lat: 3.6991111112e+01,
lng: 1.3877166667e+02,
content:'Saddle = 727.200012 pos = 36.9911,138.7717 diff = 294.399963'
});
data_peak.push({
lat: 3.6378888892e+01,
lng: 1.3704888889e+02,
cert : true,
content:'Name = Kongoudouzan(JA/TY-026) peak = 1647.800049 pos = 36.3789,137.0489 diff = 918.200073'
});
data_saddle.push({
lat: 3.6223111115e+01,
lng: 1.3700022222e+02,
content:'Saddle = 729.599976 pos = 36.2231,137.0002 diff = 918.200073'
});
data_peak.push({
lat: 3.6493111114e+01,
lng: 1.3703911111e+02,
cert : true,
content:'Name = Takamine(JA/TY-038) peak = 1071.000000 pos = 36.4931,137.0391 diff = 299.200012'
});
data_saddle.push({
lat: 3.6449888892e+01,
lng: 1.3703144444e+02,
content:'Saddle = 771.799988 pos = 36.4499,137.0314 diff = 299.200012'
});
data_peak.push({
lat: 3.6256555560e+01,
lng: 1.3700244444e+02,
cert : false,
content:' Peak = 1180.400024 pos = 36.2566,137.0024 diff = 402.100037'
});
data_saddle.push({
lat: 3.6264666671e+01,
lng: 1.3700000000e+02,
content:'Saddle = 778.299988 pos = 36.2647,137.0000 diff = 402.100037'
});
data_peak.push({
lat: 3.6473111114e+01,
lng: 1.3705800000e+02,
cert : true,
content:'Name = JA/TY-042(JA/TY-042) peak = 1010.000000 pos = 36.4731,137.0580 diff = 172.099976'
});
data_saddle.push({
lat: 3.6458444448e+01,
lng: 1.3706200000e+02,
content:'Saddle = 837.900024 pos = 36.4584,137.0620 diff = 172.099976'
});
data_peak.push({
lat: 3.6467555559e+01,
lng: 1.3719577778e+02,
cert : true,
content:'Name = JA/TY-035(JA/TY-035) peak = 1127.800049 pos = 36.4676,137.1958 diff = 225.300049'
});
data_saddle.push({
lat: 3.6455111114e+01,
lng: 1.3719166667e+02,
content:'Saddle = 902.500000 pos = 36.4551,137.1917 diff = 225.300049'
});
data_peak.push({
lat: 3.6446222225e+01,
lng: 1.3719566667e+02,
cert : false,
content:' Peak = 1158.300049 pos = 36.4462,137.1957 diff = 166.000061'
});
data_saddle.push({
lat: 3.6438000003e+01,
lng: 1.3718266667e+02,
content:'Saddle = 992.299988 pos = 36.4380,137.1827 diff = 166.000061'
});
data_peak.push({
lat: 3.6421666670e+01,
lng: 1.3716411111e+02,
cert : true,
content:'Name = JA/GF-092(JA/GF-092) peak = 1206.199951 pos = 36.4217,137.1641 diff = 169.599976'
});
data_saddle.push({
lat: 3.6403000003e+01,
lng: 1.3714755556e+02,
content:'Saddle = 1036.599976 pos = 36.4030,137.1476 diff = 169.599976'
});
data_peak.push({
lat: 3.6415555559e+01,
lng: 1.3711200000e+02,
cert : true,
content:'Name = Shirakimine(JA/GF-032) peak = 1594.500000 pos = 36.4156,137.1120 diff = 530.500000'
});
data_saddle.push({
lat: 3.6381444448e+01,
lng: 1.3709455556e+02,
content:'Saddle = 1064.000000 pos = 36.3814,137.0946 diff = 530.500000'
});
data_peak.push({
lat: 3.6351333337e+01,
lng: 1.3707988889e+02,
cert : true,
content:'Name = JA/GF-047(JA/GF-047) peak = 1438.400024 pos = 36.3513,137.0799 diff = 211.599976'
});
data_saddle.push({
lat: 3.6347444448e+01,
lng: 1.3706677778e+02,
content:'Saddle = 1226.800049 pos = 36.3474,137.0668 diff = 211.599976'
});
data_peak.push({
lat: 3.6350444448e+01,
lng: 1.3701555556e+02,
cert : true,
content:'Name = JA/TY-029(JA/TY-029) peak = 1453.900024 pos = 36.3504,137.0156 diff = 206.500000'
});
data_saddle.push({
lat: 3.6347666670e+01,
lng: 1.3702944444e+02,
content:'Saddle = 1247.400024 pos = 36.3477,137.0294 diff = 206.500000'
});
data_peak.push({
lat: 3.6298000004e+01,
lng: 1.3701000000e+02,
cert : false,
content:' Peak = 1504.400024 pos = 36.2980,137.0100 diff = 247.599976'
});
data_saddle.push({
lat: 3.6348444448e+01,
lng: 1.3705066667e+02,
content:'Saddle = 1256.800049 pos = 36.3484,137.0507 diff = 247.599976'
});
data_peak.push({
lat: 3.6334444448e+01,
lng: 1.3705200000e+02,
cert : true,
content:'Name = JA/GF-045(JA/GF-045) peak = 1443.900024 pos = 36.3344,137.0520 diff = 182.300049'
});
data_saddle.push({
lat: 3.6317222226e+01,
lng: 1.3702688889e+02,
content:'Saddle = 1261.599976 pos = 36.3172,137.0269 diff = 182.300049'
});
data_peak.push({
lat: 3.6943777779e+01,
lng: 1.3876944444e+02,
cert : true,
content:'Name = JA/NI-043(JA/NI-043) peak = 1180.699951 pos = 36.9438,138.7694 diff = 443.199951'
});
data_saddle.push({
lat: 3.6908666668e+01,
lng: 1.3879111111e+02,
content:'Saddle = 737.500000 pos = 36.9087,138.7911 diff = 443.199951'
});
data_peak.push({
lat: 3.6929111112e+01,
lng: 1.3878311111e+02,
cert : true,
content:'Name = JA/NI-045(JA/NI-045) peak = 1171.300049 pos = 36.9291,138.7831 diff = 179.700073'
});
data_saddle.push({
lat: 3.6936000001e+01,
lng: 1.3877544444e+02,
content:'Saddle = 991.599976 pos = 36.9360,138.7754 diff = 179.700073'
});
data_peak.push({
lat: 3.6339222226e+01,
lng: 1.3816255556e+02,
cert : false,
content:' Peak = 933.700012 pos = 36.3392,138.1626 diff = 192.799988'
});
data_saddle.push({
lat: 3.6338222226e+01,
lng: 1.3815822222e+02,
content:'Saddle = 740.900024 pos = 36.3382,138.1582 diff = 192.799988'
});
data_peak.push({
lat: 3.6808555557e+01,
lng: 1.3791822222e+02,
cert : false,
content:' Peak = 936.799988 pos = 36.8086,137.9182 diff = 188.899963'
});
data_saddle.push({
lat: 3.6811333335e+01,
lng: 1.3792577778e+02,
content:'Saddle = 747.900024 pos = 36.8113,137.9258 diff = 188.899963'
});
data_peak.push({
lat: 3.6229333337e+01,
lng: 1.3715544444e+02,
cert : false,
content:' Peak = 911.299988 pos = 36.2293,137.1554 diff = 163.099976'
});
data_saddle.push({
lat: 3.6225111115e+01,
lng: 1.3715566667e+02,
content:'Saddle = 748.200012 pos = 36.2251,137.1557 diff = 163.099976'
});
data_peak.push({
lat: 3.6914111112e+01,
lng: 1.3789344444e+02,
cert : true,
content:'Name = JA/NN-186(JA/NN-186) peak = 974.299988 pos = 36.9141,137.8934 diff = 225.399963'
});
data_saddle.push({
lat: 3.6902444446e+01,
lng: 1.3791022222e+02,
content:'Saddle = 748.900024 pos = 36.9024,137.9102 diff = 225.399963'
});
data_peak.push({
lat: 3.6433111114e+01,
lng: 1.3795122222e+02,
cert : true,
content:'Name = JA/NN-185(JA/NN-185) peak = 980.599976 pos = 36.4331,137.9512 diff = 228.299988'
});
data_saddle.push({
lat: 3.6413111114e+01,
lng: 1.3795811111e+02,
content:'Saddle = 752.299988 pos = 36.4131,137.9581 diff = 228.299988'
});
data_peak.push({
lat: 3.6407222226e+01,
lng: 1.3818211111e+02,
cert : true,
content:'Name = JA/NN-188(JA/NN-188) peak = 932.900024 pos = 36.4072,138.1821 diff = 179.700012'
});
data_saddle.push({
lat: 3.6426111114e+01,
lng: 1.3815266667e+02,
content:'Saddle = 753.200012 pos = 36.4261,138.1527 diff = 179.700012'
});
data_peak.push({
lat: 3.7213666667e+01,
lng: 1.3913944444e+02,
cert : true,
content:'Name = JA/NI-070(JA/NI-070) peak = 938.400024 pos = 37.2137,139.1394 diff = 185.000000'
});
data_saddle.push({
lat: 3.7204777778e+01,
lng: 1.3912488889e+02,
content:'Saddle = 753.400024 pos = 37.2048,139.1249 diff = 185.000000'
});
data_peak.push({
lat: 3.6799333335e+01,
lng: 1.3840377778e+02,
cert : true,
content:'Name = Koushasan (Takaifuji)(JA/NN-145) peak = 1350.800049 pos = 36.7993,138.4038 diff = 591.600037'
});
data_saddle.push({
lat: 3.6781444446e+01,
lng: 1.3843022222e+02,
content:'Saddle = 759.200012 pos = 36.7814,138.4302 diff = 591.600037'
});
data_peak.push({
lat: 3.6790888891e+01,
lng: 1.3842177778e+02,
cert : false,
content:' Peak = 1060.300049 pos = 36.7909,138.4218 diff = 183.300049'
});
data_saddle.push({
lat: 3.6789444446e+01,
lng: 1.3841544444e+02,
content:'Saddle = 877.000000 pos = 36.7894,138.4154 diff = 183.300049'
});
data_peak.push({
lat: 3.6392222226e+01,
lng: 1.3815022222e+02,
cert : true,
content:'Name = JA/NN-189(JA/NN-189) peak = 932.400024 pos = 36.3922,138.1502 diff = 169.500000'
});
data_saddle.push({
lat: 3.6395666670e+01,
lng: 1.3813855556e+02,
content:'Saddle = 762.900024 pos = 36.3957,138.1386 diff = 169.500000'
});
data_peak.push({
lat: 3.6540333336e+01,
lng: 1.3806311111e+02,
cert : true,
content:'Name = JA/NN-190(JA/NN-190) peak = 924.299988 pos = 36.5403,138.0631 diff = 160.399963'
});
data_saddle.push({
lat: 3.6535333336e+01,
lng: 1.3806066667e+02,
content:'Saddle = 763.900024 pos = 36.5353,138.0607 diff = 160.399963'
});
data_peak.push({
lat: 3.6131888893e+01,
lng: 1.3733855556e+02,
cert : true,
content:'Name = JA/GF-130(JA/GF-130) peak = 961.500000 pos = 36.1319,137.3386 diff = 194.599976'
});
data_saddle.push({
lat: 3.6132222227e+01,
lng: 1.3734666667e+02,
content:'Saddle = 766.900024 pos = 36.1322,137.3467 diff = 194.599976'
});
data_peak.push({
lat: 3.6335888893e+01,
lng: 1.3794066667e+02,
cert : false,
content:' Peak = 932.700012 pos = 36.3359,137.9407 diff = 161.799988'
});
data_saddle.push({
lat: 3.6313222226e+01,
lng: 1.3796811111e+02,
content:'Saddle = 770.900024 pos = 36.3132,137.9681 diff = 161.799988'
});
data_peak.push({
lat: 3.6956333335e+01,
lng: 1.3883300000e+02,
cert : true,
content:'Name = JA/NI-047(JA/NI-047) peak = 1110.500000 pos = 36.9563,138.8330 diff = 337.599976'
});
data_saddle.push({
lat: 3.6963333334e+01,
lng: 1.3885700000e+02,
content:'Saddle = 772.900024 pos = 36.9633,138.8570 diff = 337.599976'
});
data_peak.push({
lat: 3.6974222223e+01,
lng: 1.3885466667e+02,
cert : false,
content:' Peak = 944.599976 pos = 36.9742,138.8547 diff = 161.899963'
});
data_saddle.push({
lat: 3.6967222223e+01,
lng: 1.3884411111e+02,
content:'Saddle = 782.700012 pos = 36.9672,138.8441 diff = 161.899963'
});
data_peak.push({
lat: 3.7194777778e+01,
lng: 1.3913200000e+02,
cert : true,
content:'Name = JA/NI-056(JA/NI-056) peak = 1031.699951 pos = 37.1948,139.1320 diff = 256.099976'
});
data_saddle.push({
lat: 3.7176333334e+01,
lng: 1.3912533333e+02,
content:'Saddle = 775.599976 pos = 37.1763,139.1253 diff = 256.099976'
});
data_peak.push({
lat: 3.6493222225e+01,
lng: 1.3792655556e+02,
cert : true,
content:'Name = JA/NN-187(JA/NN-187) peak = 950.900024 pos = 36.4932,137.9266 diff = 173.100037'
});
data_saddle.push({
lat: 3.6504666670e+01,
lng: 1.3793022222e+02,
content:'Saddle = 777.799988 pos = 36.5047,137.9302 diff = 173.100037'
});
data_peak.push({
lat: 3.6649000002e+01,
lng: 1.3813477778e+02,
cert : true,
content:'Name = JA/NN-184(JA/NN-184) peak = 991.299988 pos = 36.6490,138.1348 diff = 213.399963'
});
data_saddle.push({
lat: 3.6651444447e+01,
lng: 1.3812255556e+02,
content:'Saddle = 777.900024 pos = 36.6514,138.1226 diff = 213.399963'
});
data_peak.push({
lat: 3.6193000004e+01,
lng: 1.3728422222e+02,
cert : false,
content:' Peak = 944.200012 pos = 36.1930,137.2842 diff = 154.400024'
});
data_saddle.push({
lat: 3.6198222226e+01,
lng: 1.3733444444e+02,
content:'Saddle = 789.799988 pos = 36.1982,137.3344 diff = 154.400024'
});
data_peak.push({
lat: 3.6008333338e+01,
lng: 1.3714955556e+02,
cert : true,
content:'Name = Kaoredake(JA/GF-030) peak = 1625.099976 pos = 36.0083,137.1496 diff = 835.099976'
});
data_saddle.push({
lat: 3.6080333338e+01,
lng: 1.3726455556e+02,
content:'Saddle = 790.000000 pos = 36.0803,137.2646 diff = 835.099976'
});
data_peak.push({
lat: 3.6271111115e+01,
lng: 1.3706311111e+02,
cert : true,
content:'Name = JA/GF-074(JA/GF-074) peak = 1296.199951 pos = 36.2711,137.0631 diff = 447.599976'
});
data_saddle.push({
lat: 3.6244111115e+01,
lng: 1.3704511111e+02,
content:'Saddle = 848.599976 pos = 36.2441,137.0451 diff = 447.599976'
});
data_peak.push({
lat: 3.6102444449e+01,
lng: 1.3720366667e+02,
cert : true,
content:'Name = JA/GF-102(JA/GF-102) peak = 1141.800049 pos = 36.1024,137.2037 diff = 249.900024'
});
data_saddle.push({
lat: 3.6060777783e+01,
lng: 1.3717377778e+02,
content:'Saddle = 891.900024 pos = 36.0608,137.1738 diff = 249.900024'
});
data_peak.push({
lat: 3.6086222227e+01,
lng: 1.3721377778e+02,
cert : true,
content:'Name = JA/GF-106(JA/GF-106) peak = 1130.800049 pos = 36.0862,137.2138 diff = 192.900024'
});
data_saddle.push({
lat: 3.6095000005e+01,
lng: 1.3721344444e+02,
content:'Saddle = 937.900024 pos = 36.0950,137.2134 diff = 192.900024'
});
data_peak.push({
lat: 3.6066444449e+01,
lng: 1.3724800000e+02,
cert : false,
content:' Peak = 1086.599976 pos = 36.0664,137.2480 diff = 189.199951'
});
data_saddle.push({
lat: 3.6061777783e+01,
lng: 1.3722633333e+02,
content:'Saddle = 897.400024 pos = 36.0618,137.2263 diff = 189.199951'
});
data_peak.push({
lat: 3.6189888893e+01,
lng: 1.3711255556e+02,
cert : true,
content:'Name = JA/GF-038(JA/GF-038) peak = 1518.300049 pos = 36.1899,137.1126 diff = 515.600037'
});
data_saddle.push({
lat: 3.6142444449e+01,
lng: 1.3711955556e+02,
content:'Saddle = 1002.700012 pos = 36.1424,137.1196 diff = 515.600037'
});
data_peak.push({
lat: 3.6216555560e+01,
lng: 1.3705000000e+02,
cert : false,
content:' Peak = 1383.000000 pos = 36.2166,137.0500 diff = 263.699951'
});
data_saddle.push({
lat: 3.6206222226e+01,
lng: 1.3710533333e+02,
content:'Saddle = 1119.300049 pos = 36.2062,137.1053 diff = 263.699951'
});
data_peak.push({
lat: 3.6219666671e+01,
lng: 1.3710044444e+02,
cert : true,
content:'Name = JA/GF-061(JA/GF-061) peak = 1366.099976 pos = 36.2197,137.1004 diff = 164.199951'
});
data_saddle.push({
lat: 3.6220444449e+01,
lng: 1.3707733333e+02,
content:'Saddle = 1201.900024 pos = 36.2204,137.0773 diff = 164.199951'
});
data_peak.push({
lat: 3.6141777782e+01,
lng: 1.3705566667e+02,
cert : false,
content:' Peak = 1236.199951 pos = 36.1418,137.0557 diff = 153.000000'
});
data_saddle.push({
lat: 3.6120444449e+01,
lng: 1.3704444444e+02,
content:'Saddle = 1083.199951 pos = 36.1204,137.0444 diff = 153.000000'
});
data_peak.push({
lat: 3.6024222227e+01,
lng: 1.3723944444e+02,
cert : true,
content:'Name = JA/GF-042(JA/GF-042) peak = 1478.699951 pos = 36.0242,137.2394 diff = 390.799927'
});
data_saddle.push({
lat: 3.6012777783e+01,
lng: 1.3721300000e+02,
content:'Saddle = 1087.900024 pos = 36.0128,137.2130 diff = 390.799927'
});
data_peak.push({
lat: 3.6137111116e+01,
lng: 1.3700355556e+02,
cert : true,
content:'Name = JA/GF-036(JA/GF-036) peak = 1534.500000 pos = 36.1371,137.0036 diff = 445.900024'
});
data_saddle.push({
lat: 3.6068888894e+01,
lng: 1.3705277778e+02,
content:'Saddle = 1088.599976 pos = 36.0689,137.0528 diff = 445.900024'
});
data_peak.push({
lat: 3.6196222226e+01,
lng: 1.3700000000e+02,
cert : false,
content:' Peak = 1483.000000 pos = 36.1962,137.0000 diff = 365.599976'
});
data_saddle.push({
lat: 3.6178111115e+01,
lng: 1.3701955556e+02,
content:'Saddle = 1117.400024 pos = 36.1781,137.0196 diff = 365.599976'
});
data_peak.push({
lat: 3.6097000005e+01,
lng: 1.3704488889e+02,
cert : true,
content:'Name = JA/GF-043(JA/GF-043) peak = 1464.800049 pos = 36.0970,137.0449 diff = 249.700073'
});
data_saddle.push({
lat: 3.6110888893e+01,
lng: 1.3702633333e+02,
content:'Saddle = 1215.099976 pos = 36.1109,137.0263 diff = 249.700073'
});
data_peak.push({
lat: 3.6044222227e+01,
lng: 1.3704866667e+02,
cert : true,
content:'Name = JA/GF-058(JA/GF-058) peak = 1378.599976 pos = 36.0442,137.0487 diff = 271.400024'
});
data_saddle.push({
lat: 3.6026111116e+01,
lng: 1.3707088889e+02,
content:'Saddle = 1107.199951 pos = 36.0261,137.0709 diff = 271.400024'
});
data_peak.push({
lat: 3.6012000005e+01,
lng: 1.3719433333e+02,
cert : true,
content:'Name = JA/GF-052(JA/GF-052) peak = 1402.199951 pos = 36.0120,137.1943 diff = 224.899902'
});
data_saddle.push({
lat: 3.6025777783e+01,
lng: 1.3719966667e+02,
content:'Saddle = 1177.300049 pos = 36.0258,137.1997 diff = 224.899902'
});
data_peak.push({
lat: 3.6017222227e+01,
lng: 1.3712900000e+02,
cert : false,
content:' Peak = 1397.699951 pos = 36.0172,137.1290 diff = 168.500000'
});
data_saddle.push({
lat: 3.6013666672e+01,
lng: 1.3713800000e+02,
content:'Saddle = 1229.199951 pos = 36.0137,137.1380 diff = 168.500000'
});
data_peak.push({
lat: 3.6517888892e+01,
lng: 1.3793322222e+02,
cert : true,
content:'Name = JA/NN-183(JA/NN-183) peak = 1002.500000 pos = 36.5179,137.9332 diff = 205.799988'
});
data_saddle.push({
lat: 3.6528555558e+01,
lng: 1.3792977778e+02,
content:'Saddle = 796.700012 pos = 36.5286,137.9298 diff = 205.799988'
});
data_peak.push({
lat: 3.7028666668e+01,
lng: 1.3802633333e+02,
cert : true,
content:'Name = Hokogatake(JA/NI-036) peak = 1315.199951 pos = 37.0287,138.0263 diff = 516.699951'
});
data_saddle.push({
lat: 3.7000777779e+01,
lng: 1.3803922222e+02,
content:'Saddle = 798.500000 pos = 37.0008,138.0392 diff = 516.699951'
});
data_peak.push({
lat: 3.6597222225e+01,
lng: 1.3827488889e+02,
cert : false,
content:' Peak = 994.599976 pos = 36.5972,138.2749 diff = 177.199951'
});
data_saddle.push({
lat: 3.6594000003e+01,
lng: 1.3828411111e+02,
content:'Saddle = 817.400024 pos = 36.5940,138.2841 diff = 177.199951'
});
data_peak.push({
lat: 3.6320222226e+01,
lng: 1.3822266667e+02,
cert : true,
content:'Name = JA/NN-181(JA/NN-181) peak = 1032.800049 pos = 36.3202,138.2227 diff = 210.400024'
});
data_saddle.push({
lat: 3.6317222226e+01,
lng: 1.3821922222e+02,
content:'Saddle = 822.400024 pos = 36.3172,138.2192 diff = 210.400024'
});
data_peak.push({
lat: 3.6922777779e+01,
lng: 1.3806811111e+02,
cert : true,
content:'Name = Hiuchiyama(JA/NI-002) peak = 2461.399902 pos = 36.9228,138.0681 diff = 1634.799927'
});
data_saddle.push({
lat: 3.6629444447e+01,
lng: 1.3787677778e+02,
content:'Saddle = 826.599976 pos = 36.6294,137.8768 diff = 1634.799927'
});
data_peak.push({
lat: 3.7044111112e+01,
lng: 1.3815944444e+02,
cert : true,
content:'Name = JA/NI-057(JA/NI-057) peak = 1028.500000 pos = 37.0441,138.1594 diff = 191.000000'
});
data_saddle.push({
lat: 3.7036444445e+01,
lng: 1.3815888889e+02,
content:'Saddle = 837.500000 pos = 37.0364,138.1589 diff = 191.000000'
});
data_peak.push({
lat: 3.6656222225e+01,
lng: 1.3801411111e+02,
cert : true,
content:'Name = JA/NN-140(JA/NN-140) peak = 1390.699951 pos = 36.6562,138.0141 diff = 532.599976'
});
data_saddle.push({
lat: 3.6662444447e+01,
lng: 1.3797055556e+02,
content:'Saddle = 858.099976 pos = 36.6624,137.9706 diff = 532.599976'
});
data_peak.push({
lat: 3.6637222225e+01,
lng: 1.3792233333e+02,
cert : true,
content:'Name = JA/NN-179(JA/NN-179) peak = 1053.900024 pos = 36.6372,137.9223 diff = 180.500000'
});
data_saddle.push({
lat: 3.6639666669e+01,
lng: 1.3791611111e+02,
content:'Saddle = 873.400024 pos = 36.6397,137.9161 diff = 180.500000'
});
data_peak.push({
lat: 3.6674222225e+01,
lng: 1.3787122222e+02,
cert : false,
content:' Peak = 1058.500000 pos = 36.6742,137.8712 diff = 150.900024'
});
data_saddle.push({
lat: 3.6658333336e+01,
lng: 1.3788133333e+02,
content:'Saddle = 907.599976 pos = 36.6583,137.8813 diff = 150.900024'
});
data_peak.push({
lat: 3.6670666669e+01,
lng: 1.3795700000e+02,
cert : false,
content:' Peak = 1113.800049 pos = 36.6707,137.9570 diff = 166.100037'
});
data_saddle.push({
lat: 3.6659000002e+01,
lng: 1.3792711111e+02,
content:'Saddle = 947.700012 pos = 36.6590,137.9271 diff = 166.100037'
});
data_peak.push({
lat: 3.6738777780e+01,
lng: 1.3790566667e+02,
cert : true,
content:'Name = JA/NN-144(JA/NN-144) peak = 1354.900024 pos = 36.7388,137.9057 diff = 325.800049'
});
data_saddle.push({
lat: 3.6737222224e+01,
lng: 1.3791644444e+02,
content:'Saddle = 1029.099976 pos = 36.7372,137.9164 diff = 325.800049'
});
data_peak.push({
lat: 3.7031333334e+01,
lng: 1.3813600000e+02,
cert : true,
content:'Name = JA/NI-042(JA/NI-042) peak = 1203.400024 pos = 37.0313,138.1360 diff = 164.599976'
});
data_saddle.push({
lat: 3.7012666668e+01,
lng: 1.3814022222e+02,
content:'Saddle = 1038.800049 pos = 37.0127,138.1402 diff = 164.599976'
});
data_peak.push({
lat: 3.6699111113e+01,
lng: 1.3803977778e+02,
cert : true,
content:'Name = JA/NN-136(JA/NN-136) peak = 1430.800049 pos = 36.6991,138.0398 diff = 354.100098'
});
data_saddle.push({
lat: 3.6719666669e+01,
lng: 1.3804422222e+02,
content:'Saddle = 1076.699951 pos = 36.7197,138.0442 diff = 354.100098'
});
data_peak.push({
lat: 3.6989444445e+01,
lng: 1.3813155556e+02,
cert : true,
content:'Name = JA/NI-030(JA/NI-030) peak = 1430.900024 pos = 36.9894,138.1316 diff = 350.000000'
});
data_saddle.push({
lat: 3.6976333334e+01,
lng: 1.3810777778e+02,
content:'Saddle = 1080.900024 pos = 36.9763,138.1078 diff = 350.000000'
});
data_peak.push({
lat: 3.6870444446e+01,
lng: 1.3791888889e+02,
cert : true,
content:'Name = JA/NN-149(JA/NN-149) peak = 1321.000000 pos = 36.8704,137.9189 diff = 166.900024'
});
data_saddle.push({
lat: 3.6870333335e+01,
lng: 1.3793655556e+02,
content:'Saddle = 1154.099976 pos = 36.8703,137.9366 diff = 166.900024'
});
data_peak.push({
lat: 3.6963111112e+01,
lng: 1.3797477778e+02,
cert : true,
content:'Name = JA/NI-026(JA/NI-026) peak = 1510.400024 pos = 36.9631,137.9748 diff = 302.900024'
});
data_saddle.push({
lat: 3.6953333335e+01,
lng: 1.3797900000e+02,
content:'Saddle = 1207.500000 pos = 36.9533,137.9790 diff = 302.900024'
});
data_peak.push({
lat: 3.6971222223e+01,
lng: 1.3810244444e+02,
cert : false,
content:' Peak = 1430.000000 pos = 36.9712,138.1024 diff = 217.500000'
});
data_saddle.push({
lat: 3.6964333334e+01,
lng: 1.3810566667e+02,
content:'Saddle = 1212.500000 pos = 36.9643,138.1057 diff = 217.500000'
});
data_peak.push({
lat: 3.6739555558e+01,
lng: 1.3813366667e+02,
cert : true,
content:'Name = Iidunayama (Iidunayama)(JA/NN-077) peak = 1916.000000 pos = 36.7396,138.1337 diff = 697.199951'
});
data_saddle.push({
lat: 3.6755666669e+01,
lng: 1.3806911111e+02,
content:'Saddle = 1218.800049 pos = 36.7557,138.0691 diff = 697.199951'
});
data_peak.push({
lat: 3.6931888890e+01,
lng: 1.3796877778e+02,
cert : true,
content:'Name = Nokogiridake(JA/NI-020) peak = 1630.400024 pos = 36.9319,137.9688 diff = 361.700073'
});
data_saddle.push({
lat: 3.6924777779e+01,
lng: 1.3797188889e+02,
content:'Saddle = 1268.699951 pos = 36.9248,137.9719 diff = 361.700073'
});
data_peak.push({
lat: 3.6938777779e+01,
lng: 1.3795388889e+02,
cert : true,
content:'Name = JA/NI-022(JA/NI-022) peak = 1590.099976 pos = 36.9388,137.9539 diff = 171.799927'
});
data_saddle.push({
lat: 3.6937000001e+01,
lng: 1.3795966667e+02,
content:'Saddle = 1418.300049 pos = 36.9370,137.9597 diff = 171.799927'
});
data_peak.push({
lat: 3.6862333335e+01,
lng: 1.3795488889e+02,
cert : false,
content:' Peak = 1570.099976 pos = 36.8623,137.9549 diff = 287.599976'
});
data_saddle.push({
lat: 3.6869555557e+01,
lng: 1.3796100000e+02,
content:'Saddle = 1282.500000 pos = 36.8696,137.9610 diff = 287.599976'
});
data_peak.push({
lat: 3.6952555557e+01,
lng: 1.3811177778e+02,
cert : true,
content:'Name = JA/NI-027(JA/NI-027) peak = 1493.699951 pos = 36.9526,138.1118 diff = 185.299927'
});
data_saddle.push({
lat: 3.6946222223e+01,
lng: 1.3810644444e+02,
content:'Saddle = 1308.400024 pos = 36.9462,138.1064 diff = 185.299927'
});
data_peak.push({
lat: 3.6878444446e+01,
lng: 1.3796711111e+02,
cert : false,
content:' Peak = 1482.300049 pos = 36.8784,137.9671 diff = 160.600098'
});
data_saddle.push({
lat: 3.6884444446e+01,
lng: 1.3796277778e+02,
content:'Saddle = 1321.699951 pos = 36.8844,137.9628 diff = 160.600098'
});
data_peak.push({
lat: 3.6722888891e+01,
lng: 1.3798933333e+02,
cert : false,
content:' Peak = 1561.900024 pos = 36.7229,137.9893 diff = 199.599976'
});
data_saddle.push({
lat: 3.6730666669e+01,
lng: 1.3798922222e+02,
content:'Saddle = 1362.300049 pos = 36.7307,137.9892 diff = 199.599976'
});
data_peak.push({
lat: 3.6902000001e+01,
lng: 1.3796255556e+02,
cert : true,
content:'Name = Amakazariyama(JA/NN-072) peak = 1961.099976 pos = 36.9020,137.9626 diff = 442.299927'
});
data_saddle.push({
lat: 3.6909444446e+01,
lng: 1.3797777778e+02,
content:'Saddle = 1518.800049 pos = 36.9094,137.9778 diff = 442.299927'
});
data_peak.push({
lat: 3.6813555557e+01,
lng: 1.3812711111e+02,
cert : true,
content:'Name = Kurohimeyama(JA/NN-062) peak = 2052.199951 pos = 36.8136,138.1271 diff = 499.899902'
});
data_saddle.push({
lat: 3.6797555557e+01,
lng: 1.3808077778e+02,
content:'Saddle = 1552.300049 pos = 36.7976,138.0808 diff = 499.899902'
});
data_peak.push({
lat: 3.6813555557e+01,
lng: 1.3808777778e+02,
cert : true,
content:'Name = JA/NN-086(JA/NN-086) peak = 1822.599976 pos = 36.8136,138.0878 diff = 224.500000'
});
data_saddle.push({
lat: 3.6813111113e+01,
lng: 1.3810144444e+02,
content:'Saddle = 1598.099976 pos = 36.8131,138.1014 diff = 224.500000'
});
data_peak.push({
lat: 3.6817444446e+01,
lng: 1.3811688889e+02,
cert : true,
content:'Name = JA/NN-064(JA/NN-064) peak = 2045.199951 pos = 36.8174,138.1169 diff = 188.599976'
});
data_saddle.push({
lat: 3.6813777780e+01,
lng: 1.3811566667e+02,
content:'Saddle = 1856.599976 pos = 36.8138,138.1157 diff = 188.599976'
});
data_peak.push({
lat: 3.6800111113e+01,
lng: 1.3805188889e+02,
cert : true,
content:'Name = Takatsumayama(JA/NN-042) peak = 2352.300049 pos = 36.8001,138.0519 diff = 799.900024'
});
data_saddle.push({
lat: 3.6867111113e+01,
lng: 1.3802200000e+02,
content:'Saddle = 1552.400024 pos = 36.8671,138.0220 diff = 799.900024'
});
data_peak.push({
lat: 3.6770444446e+01,
lng: 1.3796455556e+02,
cert : true,
content:'Name = JA/NN-084(JA/NN-084) peak = 1845.800049 pos = 36.7704,137.9646 diff = 284.100098'
});
data_saddle.push({
lat: 3.6798000002e+01,
lng: 1.3797833333e+02,
content:'Saddle = 1561.699951 pos = 36.7980,137.9783 diff = 284.100098'
});
data_peak.push({
lat: 3.6828111113e+01,
lng: 1.3800400000e+02,
cert : true,
content:'Name = JA/NI-015(JA/NI-015) peak = 1925.400024 pos = 36.8281,138.0040 diff = 322.500000'
});
data_saddle.push({
lat: 3.6820444446e+01,
lng: 1.3801522222e+02,
content:'Saddle = 1602.900024 pos = 36.8204,138.0152 diff = 322.500000'
});
data_peak.push({
lat: 3.6761888891e+01,
lng: 1.3803022222e+02,
cert : true,
content:'Name = JA/NN-061(JA/NN-061) peak = 2051.000000 pos = 36.7619,138.0302 diff = 333.800049'
});
data_saddle.push({
lat: 3.6768333335e+01,
lng: 1.3804311111e+02,
content:'Saddle = 1717.199951 pos = 36.7683,138.0431 diff = 333.800049'
});
data_peak.push({
lat: 3.6770444446e+01,
lng: 1.3805500000e+02,
cert : false,
content:' Peak = 1902.599976 pos = 36.7704,138.0550 diff = 156.299927'
});
data_saddle.push({
lat: 3.6782666669e+01,
lng: 1.3806311111e+02,
content:'Saddle = 1746.300049 pos = 36.7827,138.0631 diff = 156.299927'
});
data_peak.push({
lat: 3.6833000002e+01,
lng: 1.3805255556e+02,
cert : false,
content:' Peak = 2073.199951 pos = 36.8330,138.0526 diff = 181.899902'
});
data_saddle.push({
lat: 3.6822333335e+01,
lng: 1.3805488889e+02,
content:'Saddle = 1891.300049 pos = 36.8223,138.0549 diff = 181.899902'
});
data_peak.push({
lat: 3.6940444446e+01,
lng: 1.3800755556e+02,
cert : false,
content:' Peak = 1840.800049 pos = 36.9404,138.0076 diff = 168.800049'
});
data_saddle.push({
lat: 3.6935222223e+01,
lng: 1.3802300000e+02,
content:'Saddle = 1672.000000 pos = 36.9352,138.0230 diff = 168.800049'
});
data_peak.push({
lat: 3.6920888890e+01,
lng: 1.3803577778e+02,
cert : true,
content:'Name = Yakeyama(JA/NI-004) peak = 2401.600098 pos = 36.9209,138.0358 diff = 400.300049'
});
data_saddle.push({
lat: 3.6919777779e+01,
lng: 1.3804733333e+02,
content:'Saddle = 2001.300049 pos = 36.9198,138.0473 diff = 400.300049'
});
data_peak.push({
lat: 3.6904333335e+01,
lng: 1.3801388889e+02,
cert : false,
content:' Peak = 2243.699951 pos = 36.9043,138.0139 diff = 191.800049'
});
data_saddle.push({
lat: 3.6911555557e+01,
lng: 1.3802033333e+02,
content:'Saddle = 2051.899902 pos = 36.9116,138.0203 diff = 191.800049'
});
data_peak.push({
lat: 3.6891333335e+01,
lng: 1.3811344444e+02,
cert : true,
content:'Name = Myoukousan(JA/NI-003) peak = 2451.899902 pos = 36.8913,138.1134 diff = 432.999878'
});
data_saddle.push({
lat: 3.6905444446e+01,
lng: 1.3809644444e+02,
content:'Saddle = 2018.900024 pos = 36.9054,138.0964 diff = 432.999878'
});
data_peak.push({
lat: 3.6892222224e+01,
lng: 1.3810277778e+02,
cert : false,
content:' Peak = 2360.000000 pos = 36.8922,138.1028 diff = 249.000000'
});
data_saddle.push({
lat: 3.6892888890e+01,
lng: 1.3810655556e+02,
content:'Saddle = 2111.000000 pos = 36.8929,138.1066 diff = 249.000000'
});
data_peak.push({
lat: 3.6590333336e+01,
lng: 1.3786611111e+02,
cert : true,
content:'Name = JA/NN-164(JA/NN-164) peak = 1221.199951 pos = 36.5903,137.8661 diff = 383.499939'
});
data_saddle.push({
lat: 3.6620555558e+01,
lng: 1.3785800000e+02,
content:'Saddle = 837.700012 pos = 36.6206,137.8580 diff = 383.499939'
});
data_peak.push({
lat: 3.6506666670e+01,
lng: 1.3788677778e+02,
cert : true,
content:'Name = JA/NN-171(JA/NN-171) peak = 1165.400024 pos = 36.5067,137.8868 diff = 267.300049'
});
data_saddle.push({
lat: 3.6534666670e+01,
lng: 1.3787122222e+02,
content:'Saddle = 898.099976 pos = 36.5347,137.8712 diff = 267.300049'
});
data_peak.push({
lat: 3.6541222225e+01,
lng: 1.3792288889e+02,
cert : true,
content:'Name = JA/NN-172(JA/NN-172) peak = 1151.300049 pos = 36.5412,137.9229 diff = 244.100037'
});
data_saddle.push({
lat: 3.6544555558e+01,
lng: 1.3790955556e+02,
content:'Saddle = 907.200012 pos = 36.5446,137.9096 diff = 244.100037'
});
data_peak.push({
lat: 3.6000111116e+01,
lng: 1.3837111111e+02,
cert : false,
content:' Peak = 2745.800049 pos = 36.0001,138.3711 diff = 1886.700073'
});
data_saddle.push({
lat: 3.6000111116e+01,
lng: 1.3785644444e+02,
content:'Saddle = 859.099976 pos = 36.0001,137.8564 diff = 1886.700073'
});
data_peak.push({
lat: 3.6347444448e+01,
lng: 1.3812955556e+02,
cert : true,
content:'Name = JA/NN-162(JA/NN-162) peak = 1250.699951 pos = 36.3474,138.1296 diff = 377.799927'
});
data_saddle.push({
lat: 3.6327555559e+01,
lng: 1.3812111111e+02,
content:'Saddle = 872.900024 pos = 36.3276,138.1211 diff = 377.799927'
});
data_peak.push({
lat: 3.7329888889e+01,
lng: 1.3921966667e+02,
cert : false,
content:' Peak = 1464.599976 pos = 37.3299,139.2197 diff = 587.000000'
});
data_saddle.push({
lat: 3.7304444444e+01,
lng: 1.3921711111e+02,
content:'Saddle = 877.599976 pos = 37.3044,139.2171 diff = 587.000000'
});
data_peak.push({
lat: 3.7033333334e+01,
lng: 1.3900911111e+02,
cert : false,
content:' Peak = 1080.500000 pos = 37.0333,139.0091 diff = 199.099976'
});
data_saddle.push({
lat: 3.7022111112e+01,
lng: 1.3900755556e+02,
content:'Saddle = 881.400024 pos = 37.0221,139.0076 diff = 199.099976'
});
data_peak.push({
lat: 3.7106333334e+01,
lng: 1.3950444444e+02,
cert : true,
content:'Name = JA/FS-052(JA/FS-052) peak = 1154.900024 pos = 37.1063,139.5044 diff = 271.500000'
});
data_saddle.push({
lat: 3.7080555556e+01,
lng: 1.3951344444e+02,
content:'Saddle = 883.400024 pos = 37.0806,139.5134 diff = 271.500000'
});
data_peak.push({
lat: 3.6000333338e+01,
lng: 1.3787933333e+02,
cert : false,
content:' Peak = 1540.599976 pos = 36.0003,137.8793 diff = 657.000000'
});
data_saddle.push({
lat: 3.6074666671e+01,
lng: 1.3797922222e+02,
content:'Saddle = 883.599976 pos = 36.0747,137.9792 diff = 657.000000'
});
data_peak.push({
lat: 3.6084222227e+01,
lng: 1.3794222222e+02,
cert : false,
content:' Peak = 1160.500000 pos = 36.0842,137.9422 diff = 188.299988'
});
data_saddle.push({
lat: 3.6078888894e+01,
lng: 1.3794411111e+02,
content:'Saddle = 972.200012 pos = 36.0789,137.9441 diff = 188.299988'
});
data_peak.push({
lat: 3.6027333338e+01,
lng: 1.3796133333e+02,
cert : true,
content:'Name = JA/NN-166(JA/NN-166) peak = 1201.900024 pos = 36.0273,137.9613 diff = 190.800049'
});
data_saddle.push({
lat: 3.6027444449e+01,
lng: 1.3793666667e+02,
content:'Saddle = 1011.099976 pos = 36.0274,137.9367 diff = 190.800049'
});
data_peak.push({
lat: 3.6034555560e+01,
lng: 1.3790444444e+02,
cert : true,
content:'Name = JA/NN-139(JA/NN-139) peak = 1392.199951 pos = 36.0346,137.9044 diff = 323.699951'
});
data_saddle.push({
lat: 3.6026222227e+01,
lng: 1.3791011111e+02,
content:'Saddle = 1068.500000 pos = 36.0262,137.9101 diff = 323.699951'
});
data_peak.push({
lat: 3.6320111115e+01,
lng: 1.3818733333e+02,
cert : true,
content:'Name = JA/NN-159(JA/NN-159) peak = 1265.400024 pos = 36.3201,138.1873 diff = 373.300049'
});
data_saddle.push({
lat: 3.6315666670e+01,
lng: 1.3813177778e+02,
content:'Saddle = 892.099976 pos = 36.3157,138.1318 diff = 373.300049'
});
data_peak.push({
lat: 3.6484222225e+01,
lng: 1.3802133333e+02,
cert : true,
content:'Name = Hijiriyama(JA/NN-134) peak = 1445.099976 pos = 36.4842,138.0213 diff = 552.699951'
});
data_saddle.push({
lat: 3.6473666670e+01,
lng: 1.3808644444e+02,
content:'Saddle = 892.400024 pos = 36.4737,138.0864 diff = 552.699951'
});
data_peak.push({
lat: 3.6485555559e+01,
lng: 1.3807300000e+02,
cert : true,
content:'Name = JA/NN-175(JA/NN-175) peak = 1130.900024 pos = 36.4856,138.0730 diff = 163.900024'
});
data_saddle.push({
lat: 3.6487222225e+01,
lng: 1.3806522222e+02,
content:'Saddle = 967.000000 pos = 36.4872,138.0652 diff = 163.900024'
});
data_peak.push({
lat: 3.7252444444e+01,
lng: 1.3930722222e+02,
cert : false,
content:' Peak = 1067.599976 pos = 37.2524,139.3072 diff = 165.399963'
});
data_saddle.push({
lat: 3.7248111111e+01,
lng: 1.3930433333e+02,
content:'Saddle = 902.200012 pos = 37.2481,139.3043 diff = 165.399963'
});
data_peak.push({
lat: 3.7087888890e+01,
lng: 1.3958466667e+02,
cert : false,
content:' Peak = 1070.300049 pos = 37.0879,139.5847 diff = 157.600037'
});
data_saddle.push({
lat: 3.7079666667e+01,
lng: 1.3958677778e+02,
content:'Saddle = 912.700012 pos = 37.0797,139.5868 diff = 157.600037'
});
data_peak.push({
lat: 3.6436888892e+01,
lng: 1.3812155556e+02,
cert : true,
content:'Name = JA/NN-147(JA/NN-147) peak = 1331.699951 pos = 36.4369,138.1216 diff = 413.999939'
});
data_saddle.push({
lat: 3.6405000003e+01,
lng: 1.3810144444e+02,
content:'Saddle = 917.700012 pos = 36.4050,138.1014 diff = 413.999939'
});
data_peak.push({
lat: 3.6392333337e+01,
lng: 1.3811633333e+02,
cert : true,
content:'Name = JA/NN-165(JA/NN-165) peak = 1222.400024 pos = 36.3923,138.1163 diff = 240.100037'
});
data_saddle.push({
lat: 3.6412222226e+01,
lng: 1.3811388889e+02,
content:'Saddle = 982.299988 pos = 36.4122,138.1139 diff = 240.100037'
});
data_peak.push({
lat: 3.6468888892e+01,
lng: 1.3810666667e+02,
cert : true,
content:'Name = Kamurikiyama (Obasuteyama)(JA/NN-161) peak = 1251.099976 pos = 36.4689,138.1067 diff = 237.799988'
});
data_saddle.push({
lat: 3.6455777781e+01,
lng: 1.3811166667e+02,
content:'Saddle = 1013.299988 pos = 36.4558,138.1117 diff = 237.799988'
});
data_peak.push({
lat: 3.7332777777e+01,
lng: 1.3970733333e+02,
cert : false,
content:' Peak = 1071.699951 pos = 37.3328,139.7073 diff = 153.299927'
});
data_saddle.push({
lat: 3.7333333333e+01,
lng: 1.3971711111e+02,
content:'Saddle = 918.400024 pos = 37.3333,139.7171 diff = 153.299927'
});
data_peak.push({
lat: 3.6486333336e+01,
lng: 1.3817577778e+02,
cert : true,
content:'Name = JA/NN-177(JA/NN-177) peak = 1093.199951 pos = 36.4863,138.1758 diff = 170.999939'
});
data_saddle.push({
lat: 3.6489888892e+01,
lng: 1.3818988889e+02,
content:'Saddle = 922.200012 pos = 36.4899,138.1899 diff = 170.999939'
});
data_peak.push({
lat: 3.7222555556e+01,
lng: 1.3949322222e+02,
cert : true,
content:'Name = JA/FS-039(JA/FS-039) peak = 1313.900024 pos = 37.2226,139.4932 diff = 382.000000'
});
data_saddle.push({
lat: 3.7203000000e+01,
lng: 1.3947688889e+02,
content:'Saddle = 931.900024 pos = 37.2030,139.4769 diff = 382.000000'
});
data_peak.push({
lat: 3.7284888889e+01,
lng: 1.3920955556e+02,
cert : true,
content:'Name = JA/FS-043(JA/FS-043) peak = 1233.300049 pos = 37.2849,139.2096 diff = 271.100037'
});
data_saddle.push({
lat: 3.7278888889e+01,
lng: 1.3920133333e+02,
content:'Saddle = 962.200012 pos = 37.2789,139.2013 diff = 271.100037'
});
data_peak.push({
lat: 3.6368111115e+01,
lng: 1.3801188889e+02,
cert : false,
content:' Peak = 1137.400024 pos = 36.3681,138.0119 diff = 174.600037'
});
data_saddle.push({
lat: 3.6374666670e+01,
lng: 1.3801788889e+02,
content:'Saddle = 962.799988 pos = 36.3747,138.0179 diff = 174.600037'
});
data_peak.push({
lat: 3.7127111112e+01,
lng: 1.3953455556e+02,
cert : true,
content:'Name = JA/FS-053(JA/FS-053) peak = 1153.300049 pos = 37.1271,139.5346 diff = 190.500061'
});
data_saddle.push({
lat: 3.7131666667e+01,
lng: 1.3954266667e+02,
content:'Saddle = 962.799988 pos = 37.1317,139.5427 diff = 190.500061'
});
data_peak.push({
lat: 3.7183444445e+01,
lng: 1.3918944444e+02,
cert : true,
content:'Name = Mijyougatake(JA/NI-023) peak = 1552.099976 pos = 37.1834,139.1894 diff = 589.099976'
});
data_saddle.push({
lat: 3.7142222223e+01,
lng: 1.3914455556e+02,
content:'Saddle = 963.000000 pos = 37.1422,139.1446 diff = 589.099976'
});
data_peak.push({
lat: 3.7136111112e+01,
lng: 1.3921500000e+02,
cert : false,
content:' Peak = 1182.699951 pos = 37.1361,139.2150 diff = 170.399963'
});
data_saddle.push({
lat: 3.7133000000e+01,
lng: 1.3920655556e+02,
content:'Saddle = 1012.299988 pos = 37.1330,139.2066 diff = 170.399963'
});
data_peak.push({
lat: 3.7256777778e+01,
lng: 1.3917511111e+02,
cert : true,
content:'Name = Kemouyama(JA/FS-024) peak = 1515.000000 pos = 37.2568,139.1751 diff = 432.099976'
});
data_saddle.push({
lat: 3.7237000000e+01,
lng: 1.3916466667e+02,
content:'Saddle = 1082.900024 pos = 37.2370,139.1647 diff = 432.099976'
});
data_peak.push({
lat: 3.7203888889e+01,
lng: 1.3919477778e+02,
cert : false,
content:' Peak = 1351.300049 pos = 37.2039,139.1948 diff = 168.400024'
});
data_saddle.push({
lat: 3.7199888889e+01,
lng: 1.3919633333e+02,
content:'Saddle = 1182.900024 pos = 37.1999,139.1963 diff = 168.400024'
});
data_peak.push({
lat: 3.7147555556e+01,
lng: 1.3918544444e+02,
cert : true,
content:'Name = JA/NI-029(JA/NI-029) peak = 1431.300049 pos = 37.1476,139.1854 diff = 198.900024'
});
data_saddle.push({
lat: 3.7160444445e+01,
lng: 1.3918644444e+02,
content:'Saddle = 1232.400024 pos = 37.1604,139.1864 diff = 198.900024'
});
data_peak.push({
lat: 3.7229666667e+01,
lng: 1.3944344444e+02,
cert : false,
content:' Peak = 1123.500000 pos = 37.2297,139.4434 diff = 160.400024'
});
data_saddle.push({
lat: 3.7216777778e+01,
lng: 1.3944400000e+02,
content:'Saddle = 963.099976 pos = 37.2168,139.4440 diff = 160.400024'
});
data_peak.push({
lat: 3.6798555557e+01,
lng: 1.3937588889e+02,
cert : true,
content:'Name = Shiranesan(JA/TG-001) peak = 2575.800049 pos = 36.7986,139.3759 diff = 1608.900024'
});
data_saddle.push({
lat: 3.6344555559e+01,
lng: 1.3865066667e+02,
content:'Saddle = 966.900024 pos = 36.3446,138.6507 diff = 1608.900024'
});
data_peak.push({
lat: 3.7072333334e+01,
lng: 1.3898555556e+02,
cert : false,
content:' Peak = 1143.099976 pos = 37.0723,138.9856 diff = 171.500000'
});
data_saddle.push({
lat: 3.7073888890e+01,
lng: 1.3899577778e+02,
content:'Saddle = 971.599976 pos = 37.0739,138.9958 diff = 171.500000'
});
data_peak.push({
lat: 3.7082777778e+01,
lng: 1.3971044444e+02,
cert : false,
content:' Peak = 1136.900024 pos = 37.0828,139.7104 diff = 164.800049'
});
data_saddle.push({
lat: 3.7070000001e+01,
lng: 1.3971000000e+02,
content:'Saddle = 972.099976 pos = 37.0700,139.7100 diff = 164.800049'
});
data_peak.push({
lat: 3.6973111112e+01,
lng: 1.3964222222e+02,
cert : true,
content:'Name = JA/TG-033(JA/TG-033) peak = 1364.699951 pos = 36.9731,139.6422 diff = 391.599976'
});
data_saddle.push({
lat: 3.6995000001e+01,
lng: 1.3962222222e+02,
content:'Saddle = 973.099976 pos = 36.9950,139.6222 diff = 391.599976'
});
data_peak.push({
lat: 3.6599333336e+01,
lng: 1.3830544444e+02,
cert : true,
content:'Name = JA/NN-155(JA/NN-155) peak = 1293.300049 pos = 36.5993,138.3054 diff = 305.900024'
});
data_saddle.push({
lat: 3.6581222225e+01,
lng: 1.3830800000e+02,
content:'Saddle = 987.400024 pos = 36.5812,138.3080 diff = 305.900024'
});
data_peak.push({
lat: 3.7074444445e+01,
lng: 1.3971544444e+02,
cert : false,
content:' Peak = 1141.000000 pos = 37.0744,139.7154 diff = 152.900024'
});
data_saddle.push({
lat: 3.7065666667e+01,
lng: 1.3970911111e+02,
content:'Saddle = 988.099976 pos = 37.0657,139.7091 diff = 152.900024'
});
data_peak.push({
lat: 3.7190000000e+01,
lng: 1.3957077778e+02,
cert : false,
content:' Peak = 1173.300049 pos = 37.1900,139.5708 diff = 184.500061'
});
data_saddle.push({
lat: 3.7189222222e+01,
lng: 1.3957477778e+02,
content:'Saddle = 988.799988 pos = 37.1892,139.5748 diff = 184.500061'
});
data_peak.push({
lat: 3.6911111112e+01,
lng: 1.3965955556e+02,
cert : false,
content:' Peak = 1175.900024 pos = 36.9111,139.6596 diff = 173.600037'
});
data_saddle.push({
lat: 3.6914777779e+01,
lng: 1.3965077778e+02,
content:'Saddle = 1002.299988 pos = 36.9148,139.6508 diff = 173.600037'
});
data_peak.push({
lat: 3.6746555558e+01,
lng: 1.3892722222e+02,
cert : true,
content:'Name = Adumayasan(JA/GM-043) peak = 1340.599976 pos = 36.7466,138.9272 diff = 338.000000'
});
data_saddle.push({
lat: 3.6756666669e+01,
lng: 1.3891777778e+02,
content:'Saddle = 1002.599976 pos = 36.7567,138.9178 diff = 338.000000'
});
data_peak.push({
lat: 3.7318111111e+01,
lng: 1.3983200000e+02,
cert : false,
content:' Peak = 1380.500000 pos = 37.3181,139.8320 diff = 365.900024'
});
data_saddle.push({
lat: 3.7280777778e+01,
lng: 1.3973111111e+02,
content:'Saddle = 1014.599976 pos = 37.2808,139.7311 diff = 365.900024'
});
data_peak.push({
lat: 3.6857222224e+01,
lng: 1.3964055556e+02,
cert : true,
content:'Name = JA/TG-035(JA/TG-035) peak = 1341.400024 pos = 36.8572,139.6406 diff = 321.200012'
});
data_saddle.push({
lat: 3.6845555557e+01,
lng: 1.3961644444e+02,
content:'Saddle = 1020.200012 pos = 36.8456,139.6164 diff = 321.200012'
});
data_peak.push({
lat: 3.6852777779e+01,
lng: 1.3961866667e+02,
cert : true,
content:'Name = JA/TG-037(JA/TG-037) peak = 1295.199951 pos = 36.8528,139.6187 diff = 263.500000'
});
data_saddle.push({
lat: 3.6851111113e+01,
lng: 1.3963377778e+02,
content:'Saddle = 1031.699951 pos = 36.8511,139.6338 diff = 263.500000'
});
data_peak.push({
lat: 3.6846222224e+01,
lng: 1.3965911111e+02,
cert : true,
content:'Name = JA/TG-038(JA/TG-038) peak = 1283.900024 pos = 36.8462,139.6591 diff = 175.700073'
});
data_saddle.push({
lat: 3.6858222224e+01,
lng: 1.3966155556e+02,
content:'Saddle = 1108.199951 pos = 36.8582,139.6616 diff = 175.700073'
});
data_peak.push({
lat: 3.6560444447e+01,
lng: 1.3919322222e+02,
cert : true,
content:'Name = Akagisan (Kurobisan)(JA/GM-023) peak = 1827.199951 pos = 36.5604,139.1932 diff = 804.699951'
});
data_saddle.push({
lat: 3.6582000003e+01,
lng: 1.3923355556e+02,
content:'Saddle = 1022.500000 pos = 36.5820,139.2336 diff = 804.699951'
});
data_peak.push({
lat: 3.6541000003e+01,
lng: 1.3917722222e+02,
cert : true,
content:'Name = Akagisan (Jizoudake)(JA/GM-026) peak = 1672.800049 pos = 36.5410,139.1772 diff = 282.400024'
});
data_saddle.push({
lat: 3.6540888892e+01,
lng: 1.3919300000e+02,
content:'Saddle = 1390.400024 pos = 36.5409,139.1930 diff = 282.400024'
});
data_peak.push({
lat: 3.6525888892e+01,
lng: 1.3916544444e+02,
cert : false,
content:' Peak = 1571.800049 pos = 36.5259,139.1654 diff = 159.400024'
});
data_saddle.push({
lat: 3.6534222225e+01,
lng: 1.3917088889e+02,
content:'Saddle = 1412.400024 pos = 36.5342,139.1709 diff = 159.400024'
});
data_peak.push({
lat: 3.6923666668e+01,
lng: 1.3964544444e+02,
cert : true,
content:'Name = JA/TG-041(JA/TG-041) peak = 1223.599976 pos = 36.9237,139.6454 diff = 200.399963'
});
data_saddle.push({
lat: 3.6924666668e+01,
lng: 1.3963577778e+02,
content:'Saddle = 1023.200012 pos = 36.9247,139.6358 diff = 200.399963'
});
data_peak.push({
lat: 3.7213444445e+01,
lng: 1.3925433333e+02,
cert : true,
content:'Name = JA/FS-022(JA/FS-022) peak = 1534.199951 pos = 37.2134,139.2543 diff = 510.799927'
});
data_saddle.push({
lat: 3.7161888889e+01,
lng: 1.3928544444e+02,
content:'Saddle = 1023.400024 pos = 37.1619,139.2854 diff = 510.799927'
});
data_peak.push({
lat: 3.7253000000e+01,
lng: 1.3926522222e+02,
cert : false,
content:' Peak = 1453.199951 pos = 37.2530,139.2652 diff = 214.899902'
});
data_saddle.push({
lat: 3.7235666667e+01,
lng: 1.3925366667e+02,
content:'Saddle = 1238.300049 pos = 37.2357,139.2537 diff = 214.899902'
});
data_peak.push({
lat: 3.7242555556e+01,
lng: 1.3925444444e+02,
cert : true,
content:'Name = JA/FS-027(JA/FS-027) peak = 1452.199951 pos = 37.2426,139.2544 diff = 199.799927'
});
data_saddle.push({
lat: 3.7249555556e+01,
lng: 1.3925988889e+02,
content:'Saddle = 1252.400024 pos = 37.2496,139.2599 diff = 199.799927'
});
data_peak.push({
lat: 3.6655777780e+01,
lng: 1.3942722222e+02,
cert : true,
content:'Name = JA/TG-040(JA/TG-040) peak = 1270.599976 pos = 36.6558,139.4272 diff = 237.599976'
});
data_saddle.push({
lat: 3.6660444447e+01,
lng: 1.3941877778e+02,
content:'Saddle = 1033.000000 pos = 36.6604,139.4188 diff = 237.599976'
});
data_peak.push({
lat: 3.6633000002e+01,
lng: 1.3921122222e+02,
cert : true,
content:'Name = JA/GM-050(JA/GM-050) peak = 1270.800049 pos = 36.6330,139.2112 diff = 233.200073'
});
data_saddle.push({
lat: 3.6641111114e+01,
lng: 1.3921722222e+02,
content:'Saddle = 1037.599976 pos = 36.6411,139.2172 diff = 233.200073'
});
data_peak.push({
lat: 3.6522000003e+01,
lng: 1.3867511111e+02,
cert : true,
content:'Name = JA/GM-052(JA/GM-052) peak = 1206.000000 pos = 36.5220,138.6751 diff = 167.500000'
});
data_saddle.push({
lat: 3.6520888892e+01,
lng: 1.3866177778e+02,
content:'Saddle = 1038.500000 pos = 36.5209,138.6618 diff = 167.500000'
});
data_peak.push({
lat: 3.6450888892e+01,
lng: 1.3824188889e+02,
cert : false,
content:' Peak = 1326.199951 pos = 36.4509,138.2419 diff = 287.399902'
});
data_saddle.push({
lat: 3.6512888892e+01,
lng: 1.3823611111e+02,
content:'Saddle = 1038.800049 pos = 36.5129,138.2361 diff = 287.399902'
});
data_peak.push({
lat: 3.6440555559e+01,
lng: 1.3826877778e+02,
cert : false,
content:' Peak = 1300.400024 pos = 36.4406,138.2688 diff = 259.700073'
});
data_saddle.push({
lat: 3.6440444448e+01,
lng: 1.3825777778e+02,
content:'Saddle = 1040.699951 pos = 36.4404,138.2578 diff = 259.700073'
});
data_peak.push({
lat: 3.6501111114e+01,
lng: 1.3820177778e+02,
cert : true,
content:'Name = JA/NN-158(JA/NN-158) peak = 1268.400024 pos = 36.5011,138.2018 diff = 180.200073'
});
data_saddle.push({
lat: 3.6491111114e+01,
lng: 1.3821788889e+02,
content:'Saddle = 1088.199951 pos = 36.4911,138.2179 diff = 180.200073'
});
data_peak.push({
lat: 3.6479000003e+01,
lng: 1.3823044444e+02,
cert : true,
content:'Name = JA/NN-150(JA/NN-150) peak = 1324.300049 pos = 36.4790,138.2304 diff = 155.500000'
});
data_saddle.push({
lat: 3.6460111114e+01,
lng: 1.3823622222e+02,
content:'Saddle = 1168.800049 pos = 36.4601,138.2362 diff = 155.500000'
});
data_peak.push({
lat: 3.7173111111e+01,
lng: 1.3968000000e+02,
cert : false,
content:' Peak = 1211.500000 pos = 37.1731,139.6800 diff = 166.500000'
});
data_saddle.push({
lat: 3.7159333334e+01,
lng: 1.3968000000e+02,
content:'Saddle = 1045.000000 pos = 37.1593,139.6800 diff = 166.500000'
});
data_peak.push({
lat: 3.6353888892e+01,
lng: 1.3861188889e+02,
cert : false,
content:' Peak = 1255.000000 pos = 36.3539,138.6119 diff = 197.199951'
});
data_saddle.push({
lat: 3.6357444448e+01,
lng: 1.3861022222e+02,
content:'Saddle = 1057.800049 pos = 36.3574,138.6102 diff = 197.199951'
});
data_peak.push({
lat: 3.7110555556e+01,
lng: 1.3954077778e+02,
cert : true,
content:'Name = JA/FS-038(JA/FS-038) peak = 1338.599976 pos = 37.1106,139.5408 diff = 274.799927'
});
data_saddle.push({
lat: 3.7121000001e+01,
lng: 1.3954944444e+02,
content:'Saddle = 1063.800049 pos = 37.1210,139.5494 diff = 274.799927'
});
data_peak.push({
lat: 3.6666111113e+01,
lng: 1.3881544444e+02,
cert : false,
content:' Peak = 1292.300049 pos = 36.6661,138.8154 diff = 224.300049'
});
data_saddle.push({
lat: 3.6677333336e+01,
lng: 1.3882133333e+02,
content:'Saddle = 1068.000000 pos = 36.6773,138.8213 diff = 224.300049'
});
data_peak.push({
lat: 3.7246333333e+01,
lng: 1.3969611111e+02,
cert : false,
content:' Peak = 1237.900024 pos = 37.2463,139.6961 diff = 169.800049'
});
data_saddle.push({
lat: 3.7241777778e+01,
lng: 1.3967033333e+02,
content:'Saddle = 1068.099976 pos = 37.2418,139.6703 diff = 169.800049'
});
data_peak.push({
lat: 3.7114444445e+01,
lng: 1.3947600000e+02,
cert : false,
content:' Peak = 1314.199951 pos = 37.1144,139.4760 diff = 244.199951'
});
data_saddle.push({
lat: 3.7096444445e+01,
lng: 1.3947155556e+02,
content:'Saddle = 1070.000000 pos = 37.0964,139.4716 diff = 244.199951'
});
data_peak.push({
lat: 3.7124555556e+01,
lng: 1.3964922222e+02,
cert : true,
content:'Name = JA/FS-014(JA/FS-014) peak = 1637.800049 pos = 37.1246,139.6492 diff = 563.600098'
});
data_saddle.push({
lat: 3.7086666667e+01,
lng: 1.3965377778e+02,
content:'Saddle = 1074.199951 pos = 37.0867,139.6538 diff = 563.600098'
});
data_peak.push({
lat: 3.6902888890e+01,
lng: 1.3861055556e+02,
cert : false,
content:' Peak = 1333.000000 pos = 36.9029,138.6106 diff = 255.199951'
});
data_saddle.push({
lat: 3.6892111113e+01,
lng: 1.3861311111e+02,
content:'Saddle = 1077.800049 pos = 36.8921,138.6131 diff = 255.199951'
});
data_peak.push({
lat: 3.7021222223e+01,
lng: 1.3967855556e+02,
cert : false,
content:' Peak = 1342.099976 pos = 37.0212,139.6786 diff = 259.099976'
});
data_saddle.push({
lat: 3.7043111112e+01,
lng: 1.3967866667e+02,
content:'Saddle = 1083.000000 pos = 37.0431,139.6787 diff = 259.099976'
});
data_peak.push({
lat: 3.6712555558e+01,
lng: 1.3916755556e+02,
cert : false,
content:' Peak = 1351.900024 pos = 36.7126,139.1676 diff = 264.400024'
});
data_saddle.push({
lat: 3.6734555558e+01,
lng: 1.3918477778e+02,
content:'Saddle = 1087.500000 pos = 36.7346,139.1848 diff = 264.400024'
});
data_peak.push({
lat: 3.6575111114e+01,
lng: 1.3868144444e+02,
cert : true,
content:'Name = JA/GM-042(JA/GM-042) peak = 1341.599976 pos = 36.5751,138.6814 diff = 252.599976'
});
data_saddle.push({
lat: 3.6603000003e+01,
lng: 1.3868444444e+02,
content:'Saddle = 1089.000000 pos = 36.6030,138.6844 diff = 252.599976'
});
data_peak.push({
lat: 3.7090666667e+01,
lng: 1.3946588889e+02,
cert : true,
content:'Name = JA/FS-042(JA/FS-042) peak = 1295.400024 pos = 37.0907,139.4659 diff = 202.599976'
});
data_saddle.push({
lat: 3.7073666667e+01,
lng: 1.3945855556e+02,
content:'Saddle = 1092.800049 pos = 37.0737,139.4586 diff = 202.599976'
});
data_peak.push({
lat: 3.6711888891e+01,
lng: 1.3955455556e+02,
cert : true,
content:'Name = JA/TG-039(JA/TG-039) peak = 1285.400024 pos = 36.7119,139.5546 diff = 177.900024'
});
data_saddle.push({
lat: 3.6712888891e+01,
lng: 1.3954344444e+02,
content:'Saddle = 1107.500000 pos = 36.7129,139.5434 diff = 177.900024'
});
data_peak.push({
lat: 3.6608777780e+01,
lng: 1.3946522222e+02,
cert : false,
content:' Peak = 1272.800049 pos = 36.6088,139.4652 diff = 164.400024'
});
data_saddle.push({
lat: 3.6615888891e+01,
lng: 1.3947222222e+02,
content:'Saddle = 1108.400024 pos = 36.6159,139.4722 diff = 164.400024'
});
data_peak.push({
lat: 3.7131666667e+01,
lng: 1.3925711111e+02,
cert : false,
content:' Peak = 1264.300049 pos = 37.1317,139.2571 diff = 151.600098'
});
data_saddle.push({
lat: 3.7114888889e+01,
lng: 1.3927344444e+02,
content:'Saddle = 1112.699951 pos = 37.1149,139.2734 diff = 151.600098'
});
data_peak.push({
lat: 3.7070111112e+01,
lng: 1.3943288889e+02,
cert : false,
content:' Peak = 1291.099976 pos = 37.0701,139.4329 diff = 173.500000'
});
data_saddle.push({
lat: 3.7058222223e+01,
lng: 1.3944200000e+02,
content:'Saddle = 1117.599976 pos = 37.0582,139.4420 diff = 173.500000'
});
data_peak.push({
lat: 3.6631222225e+01,
lng: 1.3950833333e+02,
cert : true,
content:'Name = JA/TG-032(JA/TG-032) peak = 1387.599976 pos = 36.6312,139.5083 diff = 245.900024'
});
data_saddle.push({
lat: 3.6650444447e+01,
lng: 1.3950177778e+02,
content:'Saddle = 1141.699951 pos = 36.6504,139.5018 diff = 245.900024'
});
data_peak.push({
lat: 3.7071777778e+01,
lng: 1.3956822222e+02,
cert : false,
content:' Peak = 1300.800049 pos = 37.0718,139.5682 diff = 158.300049'
});
data_saddle.push({
lat: 3.7068333334e+01,
lng: 1.3957344444e+02,
content:'Saddle = 1142.500000 pos = 37.0683,139.5734 diff = 158.300049'
});
data_peak.push({
lat: 3.7012444445e+01,
lng: 1.3898888889e+02,
cert : true,
content:'Name = JA/NI-035(JA/NI-035) peak = 1341.099976 pos = 37.0124,138.9889 diff = 180.099976'
});
data_saddle.push({
lat: 3.7004444445e+01,
lng: 1.3900200000e+02,
content:'Saddle = 1161.000000 pos = 37.0044,139.0020 diff = 180.099976'
});
data_peak.push({
lat: 3.7004888890e+01,
lng: 1.3964788889e+02,
cert : false,
content:' Peak = 1343.900024 pos = 37.0049,139.6479 diff = 181.599976'
});
data_saddle.push({
lat: 3.7012000001e+01,
lng: 1.3964200000e+02,
content:'Saddle = 1162.300049 pos = 37.0120,139.6420 diff = 181.599976'
});
data_peak.push({
lat: 3.7036111112e+01,
lng: 1.3964366667e+02,
cert : false,
content:' Peak = 1580.699951 pos = 37.0361,139.6437 diff = 417.899902'
});
data_saddle.push({
lat: 3.7013666668e+01,
lng: 1.3959277778e+02,
content:'Saddle = 1162.800049 pos = 37.0137,139.5928 diff = 417.899902'
});
data_peak.push({
lat: 3.7049111112e+01,
lng: 1.3958800000e+02,
cert : true,
content:'Name = JA/FS-020(JA/FS-020) peak = 1551.000000 pos = 37.0491,139.5880 diff = 282.900024'
});
data_saddle.push({
lat: 3.7035777779e+01,
lng: 1.3961522222e+02,
content:'Saddle = 1268.099976 pos = 37.0358,139.6152 diff = 282.900024'
});
data_peak.push({
lat: 3.6783111113e+01,
lng: 1.3902077778e+02,
cert : true,
content:'Name = JA/GM-044(JA/GM-044) peak = 1323.000000 pos = 36.7831,139.0208 diff = 157.000000'
});
data_saddle.push({
lat: 3.6766777780e+01,
lng: 1.3902255556e+02,
content:'Saddle = 1166.000000 pos = 36.7668,139.0226 diff = 157.000000'
});
data_peak.push({
lat: 3.7092222223e+01,
lng: 1.3928122222e+02,
cert : true,
content:'Name = JA/FS-037(JA/FS-037) peak = 1363.199951 pos = 37.0922,139.2812 diff = 192.699951'
});
data_saddle.push({
lat: 3.7094666667e+01,
lng: 1.3929866667e+02,
content:'Saddle = 1170.500000 pos = 37.0947,139.2987 diff = 192.699951'
});
data_peak.push({
lat: 3.6465444448e+01,
lng: 1.3868188889e+02,
cert : true,
content:'Name = JA/GM-037(JA/GM-037) peak = 1410.199951 pos = 36.4654,138.6819 diff = 226.500000'
});
data_saddle.push({
lat: 3.6463111114e+01,
lng: 1.3867311111e+02,
content:'Saddle = 1183.699951 pos = 36.4631,138.6731 diff = 226.500000'
});
data_peak.push({
lat: 3.6473888892e+01,
lng: 1.3869255556e+02,
cert : false,
content:' Peak = 1401.599976 pos = 36.4739,138.6926 diff = 150.099976'
});
data_saddle.push({
lat: 3.6471111114e+01,
lng: 1.3868422222e+02,
content:'Saddle = 1251.500000 pos = 36.4711,138.6842 diff = 150.099976'
});
data_peak.push({
lat: 3.7050222223e+01,
lng: 1.3941755556e+02,
cert : false,
content:' Peak = 1342.199951 pos = 37.0502,139.4176 diff = 154.599976'
});
data_saddle.push({
lat: 3.7044555556e+01,
lng: 1.3942144444e+02,
content:'Saddle = 1187.599976 pos = 37.0446,139.4214 diff = 154.599976'
});
data_peak.push({
lat: 3.6929444446e+01,
lng: 1.3960000000e+02,
cert : true,
content:'Name = JA/TG-023(JA/TG-023) peak = 1593.000000 pos = 36.9294,139.6000 diff = 402.199951'
});
data_saddle.push({
lat: 3.6913222224e+01,
lng: 1.3954433333e+02,
content:'Saddle = 1190.800049 pos = 36.9132,139.5443 diff = 402.199951'
});
data_peak.push({
lat: 3.6919777779e+01,
lng: 1.3957655556e+02,
cert : true,
content:'Name = JA/TG-029(JA/TG-029) peak = 1460.099976 pos = 36.9198,139.5766 diff = 248.099976'
});
data_saddle.push({
lat: 3.6912777779e+01,
lng: 1.3958466667e+02,
content:'Saddle = 1212.000000 pos = 36.9128,139.5847 diff = 248.099976'
});
data_peak.push({
lat: 3.6638444447e+01,
lng: 1.3869044444e+02,
cert : true,
content:'Name = JA/GM-031(JA/GM-031) peak = 1511.400024 pos = 36.6384,138.6904 diff = 320.300049'
});
data_saddle.push({
lat: 3.6662111113e+01,
lng: 1.3870111111e+02,
content:'Saddle = 1191.099976 pos = 36.6621,138.7011 diff = 320.300049'
});
data_peak.push({
lat: 3.7014888890e+01,
lng: 1.3958177778e+02,
cert : true,
content:'Name = JA/TG-030(JA/TG-030) peak = 1397.400024 pos = 37.0149,139.5818 diff = 200.200073'
});
data_saddle.push({
lat: 3.7001888890e+01,
lng: 1.3957411111e+02,
content:'Saddle = 1197.199951 pos = 37.0019,139.5741 diff = 200.200073'
});
data_peak.push({
lat: 3.6689777780e+01,
lng: 1.3953300000e+02,
cert : true,
content:'Name = JA/TG-025(JA/TG-025) peak = 1525.099976 pos = 36.6898,139.5330 diff = 327.599976'
});
data_saddle.push({
lat: 3.6710666669e+01,
lng: 1.3951411111e+02,
content:'Saddle = 1197.500000 pos = 36.7107,139.5141 diff = 327.599976'
});
data_peak.push({
lat: 3.6782666669e+01,
lng: 1.3904388889e+02,
cert : true,
content:'Name = JA/GM-032(JA/GM-032) peak = 1461.800049 pos = 36.7827,139.0439 diff = 249.400024'
});
data_saddle.push({
lat: 3.6790222224e+01,
lng: 1.3905766667e+02,
content:'Saddle = 1212.400024 pos = 36.7902,139.0577 diff = 249.400024'
});
data_peak.push({
lat: 3.6421777781e+01,
lng: 1.3868811111e+02,
cert : false,
content:' Peak = 1391.400024 pos = 36.4218,138.6881 diff = 164.700073'
});
data_saddle.push({
lat: 3.6419333337e+01,
lng: 1.3868533333e+02,
content:'Saddle = 1226.699951 pos = 36.4193,138.6853 diff = 164.700073'
});
data_peak.push({
lat: 3.7104000001e+01,
lng: 1.3902400000e+02,
cert : true,
content:'Name = Hakkaisan (Nyuudoudake)(JA/NI-017) peak = 1776.400024 pos = 37.1040,139.0240 diff = 528.700073'
});
data_saddle.push({
lat: 3.7095444445e+01,
lng: 1.3904733333e+02,
content:'Saddle = 1247.699951 pos = 37.0954,139.0473 diff = 528.700073'
});
data_peak.push({
lat: 3.7048000001e+01,
lng: 1.3944944444e+02,
cert : true,
content:'Name = JA/FS-029(JA/FS-029) peak = 1423.400024 pos = 37.0480,139.4494 diff = 169.800049'
});
data_saddle.push({
lat: 3.7033777779e+01,
lng: 1.3944400000e+02,
content:'Saddle = 1253.599976 pos = 37.0338,139.4440 diff = 169.800049'
});
data_peak.push({
lat: 3.6504222225e+01,
lng: 1.3827011111e+02,
cert : true,
content:'Name = JA/NN-131(JA/NN-131) peak = 1457.199951 pos = 36.5042,138.2701 diff = 195.199951'
});
data_saddle.push({
lat: 3.6523888892e+01,
lng: 1.3827111111e+02,
content:'Saddle = 1262.000000 pos = 36.5239,138.2711 diff = 195.199951'
});
data_peak.push({
lat: 3.7008777779e+01,
lng: 1.3893888889e+02,
cert : true,
content:'Name = JA/NI-028(JA/NI-028) peak = 1472.800049 pos = 37.0088,138.9389 diff = 210.000000'
});
data_saddle.push({
lat: 3.7002000001e+01,
lng: 1.3893844444e+02,
content:'Saddle = 1262.800049 pos = 37.0020,138.9384 diff = 210.000000'
});
data_peak.push({
lat: 3.6415777781e+01,
lng: 1.3868133333e+02,
cert : false,
content:' Peak = 1428.300049 pos = 36.4158,138.6813 diff = 161.200073'
});
data_saddle.push({
lat: 3.6411777781e+01,
lng: 1.3867000000e+02,
content:'Saddle = 1267.099976 pos = 36.4118,138.6700 diff = 161.200073'
});
data_peak.push({
lat: 3.6512333336e+01,
lng: 1.3830544444e+02,
cert : true,
content:'Name = JA/NN-109(JA/NN-109) peak = 1646.900024 pos = 36.5123,138.3054 diff = 379.200073'
});
data_saddle.push({
lat: 3.6540888892e+01,
lng: 1.3830288889e+02,
content:'Saddle = 1267.699951 pos = 36.5409,138.3029 diff = 379.200073'
});
data_peak.push({
lat: 3.6453777781e+01,
lng: 1.3865244444e+02,
cert : true,
content:'Name = Asamakakushiyama(JA/GM-024) peak = 1755.900024 pos = 36.4538,138.6524 diff = 480.400024'
});
data_saddle.push({
lat: 3.6420000003e+01,
lng: 1.3861866667e+02,
content:'Saddle = 1275.500000 pos = 36.4200,138.6187 diff = 480.400024'
});
data_peak.push({
lat: 3.6515222225e+01,
lng: 1.3864455556e+02,
cert : false,
content:' Peak = 1472.500000 pos = 36.5152,138.6446 diff = 191.900024'
});
data_saddle.push({
lat: 3.6507222225e+01,
lng: 1.3864088889e+02,
content:'Saddle = 1280.599976 pos = 36.5072,138.6409 diff = 191.900024'
});
data_peak.push({
lat: 3.6410888892e+01,
lng: 1.3864633333e+02,
cert : false,
content:' Peak = 1652.300049 pos = 36.4109,138.6463 diff = 270.900024'
});
data_saddle.push({
lat: 3.6435333337e+01,
lng: 1.3864333333e+02,
content:'Saddle = 1381.400024 pos = 36.4353,138.6433 diff = 270.900024'
});
data_peak.push({
lat: 3.6693444447e+01,
lng: 1.3926611111e+02,
cert : true,
content:'Name = JA/GM-034(JA/GM-034) peak = 1446.199951 pos = 36.6934,139.2661 diff = 159.500000'
});
data_saddle.push({
lat: 3.6687888891e+01,
lng: 1.3927466667e+02,
content:'Saddle = 1286.699951 pos = 36.6879,139.2747 diff = 159.500000'
});
data_peak.push({
lat: 3.6406555559e+01,
lng: 1.3852288889e+02,
cert : true,
content:'Name = Asamayama(JA/NN-026) peak = 2567.600098 pos = 36.4066,138.5229 diff = 1266.200073'
});
data_saddle.push({
lat: 3.6766444446e+01,
lng: 1.3882233333e+02,
content:'Saddle = 1301.400024 pos = 36.7664,138.8223 diff = 1266.200073'
});
data_peak.push({
lat: 3.6546333336e+01,
lng: 1.3832344444e+02,
cert : true,
content:'Name = JA/NN-124(JA/NN-124) peak = 1483.099976 pos = 36.5463,138.3234 diff = 164.599976'
});
data_saddle.push({
lat: 3.6539777781e+01,
lng: 1.3833844444e+02,
content:'Saddle = 1318.500000 pos = 36.5398,138.3384 diff = 164.599976'
});
data_peak.push({
lat: 3.6869777779e+01,
lng: 1.3861355556e+02,
cert : false,
content:' Peak = 1494.699951 pos = 36.8698,138.6136 diff = 174.000000'
});
data_saddle.push({
lat: 3.6861666668e+01,
lng: 1.3860888889e+02,
content:'Saddle = 1320.699951 pos = 36.8617,138.6089 diff = 174.000000'
});
data_peak.push({
lat: 3.6860555557e+01,
lng: 1.3874811111e+02,
cert : false,
content:' Peak = 1498.900024 pos = 36.8606,138.7481 diff = 156.300049'
});
data_saddle.push({
lat: 3.6845222224e+01,
lng: 1.3874944444e+02,
content:'Saddle = 1342.599976 pos = 36.8452,138.7494 diff = 156.300049'
});
data_peak.push({
lat: 3.6541777781e+01,
lng: 1.3841288889e+02,
cert : true,
content:'Name = Azumayasan(JA/GM-001) peak = 2351.699951 pos = 36.5418,138.4129 diff = 983.699951'
});
data_saddle.push({
lat: 3.6490000003e+01,
lng: 1.3839766667e+02,
content:'Saddle = 1368.000000 pos = 36.4900,138.3977 diff = 983.699951'
});
data_peak.push({
lat: 3.6839222224e+01,
lng: 1.3858388889e+02,
cert : true,
content:'Name = Torikabutoyama(JA/NN-066) peak = 2036.699951 pos = 36.8392,138.5839 diff = 628.199951'
});
data_saddle.push({
lat: 3.6859555557e+01,
lng: 1.3852855556e+02,
content:'Saddle = 1408.500000 pos = 36.8596,138.5286 diff = 628.199951'
});
data_peak.push({
lat: 3.6857555557e+01,
lng: 1.3855088889e+02,
cert : true,
content:'Name = JA/NN-083(JA/NN-083) peak = 1851.599976 pos = 36.8576,138.5509 diff = 238.900024'
});
data_saddle.push({
lat: 3.6852000002e+01,
lng: 1.3855655556e+02,
content:'Saddle = 1612.699951 pos = 36.8520,138.5566 diff = 238.900024'
});
data_peak.push({
lat: 3.6855333335e+01,
lng: 1.3849022222e+02,
cert : true,
content:'Name = JA/NN-100(JA/NN-100) peak = 1675.699951 pos = 36.8553,138.4902 diff = 216.599976'
});
data_saddle.push({
lat: 3.6833222224e+01,
lng: 1.3850311111e+02,
content:'Saddle = 1459.099976 pos = 36.8332,138.5031 diff = 216.599976'
});
data_peak.push({
lat: 3.6897888890e+01,
lng: 1.3848644444e+02,
cert : true,
content:'Name = JA/NN-107(JA/NN-107) peak = 1646.199951 pos = 36.8979,138.4864 diff = 163.699951'
});
data_saddle.push({
lat: 3.6888666668e+01,
lng: 1.3849266667e+02,
content:'Saddle = 1482.500000 pos = 36.8887,138.4927 diff = 163.699951'
});
data_peak.push({
lat: 3.6804777780e+01,
lng: 1.3873211111e+02,
cert : true,
content:'Name = JA/NI-018(JA/NI-018) peak = 1655.900024 pos = 36.8048,138.7321 diff = 192.700073'
});
data_saddle.push({
lat: 3.6797111113e+01,
lng: 1.3873633333e+02,
content:'Saddle = 1463.199951 pos = 36.7971,138.7363 diff = 192.700073'
});
data_peak.push({
lat: 3.6810666668e+01,
lng: 1.3849511111e+02,
cert : true,
content:'Name = JA/NN-091(JA/NN-091) peak = 1745.000000 pos = 36.8107,138.4951 diff = 223.500000'
});
data_saddle.push({
lat: 3.6799555557e+01,
lng: 1.3849444444e+02,
content:'Saddle = 1521.500000 pos = 36.7996,138.4944 diff = 223.500000'
});
data_peak.push({
lat: 3.6772333335e+01,
lng: 1.3867055556e+02,
cert : true,
content:'Name = Saburyuuyama(JA/NN-052) peak = 2191.199951 pos = 36.7723,138.6706 diff = 645.399902'
});
data_saddle.push({
lat: 3.6696333336e+01,
lng: 1.3863588889e+02,
content:'Saddle = 1545.800049 pos = 36.6963,138.6359 diff = 645.399902'
});
data_peak.push({
lat: 3.6846000002e+01,
lng: 1.3869022222e+02,
cert : true,
content:'Name = Naebasan(JA/NI-005) peak = 2144.699951 pos = 36.8460,138.6902 diff = 401.699951'
});
data_saddle.push({
lat: 3.6815777780e+01,
lng: 1.3868766667e+02,
content:'Saddle = 1743.000000 pos = 36.8158,138.6877 diff = 401.699951'
});
data_peak.push({
lat: 3.6852222224e+01,
lng: 1.3870388889e+02,
cert : false,
content:' Peak = 2027.800049 pos = 36.8522,138.7039 diff = 152.800049'
});
data_saddle.push({
lat: 3.6849333335e+01,
lng: 1.3870011111e+02,
content:'Saddle = 1875.000000 pos = 36.8493,138.7001 diff = 152.800049'
});
data_peak.push({
lat: 3.6793777780e+01,
lng: 1.3868933333e+02,
cert : true,
content:'Name = JA/NI-010(JA/NI-010) peak = 2050.800049 pos = 36.7938,138.6893 diff = 238.600098'
});
data_saddle.push({
lat: 3.6785111113e+01,
lng: 1.3867500000e+02,
content:'Saddle = 1812.199951 pos = 36.7851,138.6750 diff = 238.600098'
});
data_peak.push({
lat: 3.6738111113e+01,
lng: 1.3869344444e+02,
cert : true,
content:'Name = Shirasunayama(JA/GM-007) peak = 2138.500000 pos = 36.7381,138.6934 diff = 212.599976'
});
data_saddle.push({
lat: 3.6750444446e+01,
lng: 1.3869177778e+02,
content:'Saddle = 1925.900024 pos = 36.7504,138.6918 diff = 212.599976'
});
data_peak.push({
lat: 3.6759333335e+01,
lng: 1.3872133333e+02,
cert : false,
content:' Peak = 2121.500000 pos = 36.7593,138.7213 diff = 194.099976'
});
data_saddle.push({
lat: 3.6743888891e+01,
lng: 1.3871488889e+02,
content:'Saddle = 1927.400024 pos = 36.7439,138.7149 diff = 194.099976'
});
data_peak.push({
lat: 3.6762333335e+01,
lng: 1.3851000000e+02,
cert : true,
content:'Name = Yakebitaiyama(JA/NN-069) peak = 2014.300049 pos = 36.7623,138.5100 diff = 364.700073'
});
data_saddle.push({
lat: 3.6736888891e+01,
lng: 1.3850888889e+02,
content:'Saddle = 1649.599976 pos = 36.7369,138.5089 diff = 364.700073'
});
data_peak.push({
lat: 3.6705888891e+01,
lng: 1.3847933333e+02,
cert : false,
content:' Peak = 1833.000000 pos = 36.7059,138.4793 diff = 150.099976'
});
data_saddle.push({
lat: 3.6692111113e+01,
lng: 1.3848488889e+02,
content:'Saddle = 1682.900024 pos = 36.6921,138.4849 diff = 150.099976'
});
data_peak.push({
lat: 3.6719000002e+01,
lng: 1.3862088889e+02,
cert : true,
content:'Name = JA/GM-015(JA/GM-015) peak = 1971.599976 pos = 36.7190,138.6209 diff = 205.799927'
});
data_saddle.push({
lat: 3.6708444447e+01,
lng: 1.3861200000e+02,
content:'Saddle = 1765.800049 pos = 36.7084,138.6120 diff = 205.799927'
});
data_peak.push({
lat: 3.6753000002e+01,
lng: 1.3856777778e+02,
cert : true,
content:'Name = Iwasugeyama (Uraiwasugeyama)(JA/NN-043) peak = 2340.600098 pos = 36.7530,138.5678 diff = 562.000122'
});
data_saddle.push({
lat: 3.6588444447e+01,
lng: 1.3842711111e+02,
content:'Saddle = 1778.599976 pos = 36.5884,138.4271 diff = 562.000122'
});
data_peak.push({
lat: 3.6601222225e+01,
lng: 1.3844066667e+02,
cert : true,
content:'Name = JA/GM-013(JA/GM-013) peak = 2004.199951 pos = 36.6012,138.4407 diff = 182.899902'
});
data_saddle.push({
lat: 3.6610888891e+01,
lng: 1.3844866667e+02,
content:'Saddle = 1821.300049 pos = 36.6109,138.4487 diff = 182.899902'
});
data_peak.push({
lat: 3.6628777780e+01,
lng: 1.3845855556e+02,
cert : true,
content:'Name = JA/GM-004(JA/GM-004) peak = 2163.800049 pos = 36.6288,138.4586 diff = 341.400024'
});
data_saddle.push({
lat: 3.6642222225e+01,
lng: 1.3849377778e+02,
content:'Saddle = 1822.400024 pos = 36.6422,138.4938 diff = 341.400024'
});
data_peak.push({
lat: 3.6676666669e+01,
lng: 1.3848144444e+02,
cert : true,
content:'Name = Kasagatake(JA/NN-060) peak = 2074.800049 pos = 36.6767,138.4814 diff = 242.600098'
});
data_saddle.push({
lat: 3.6677555558e+01,
lng: 1.3848855556e+02,
content:'Saddle = 1832.199951 pos = 36.6776,138.4886 diff = 242.600098'
});
data_peak.push({
lat: 3.6720111113e+01,
lng: 1.3859800000e+02,
cert : true,
content:'Name = JA/NN-055(JA/NN-055) peak = 2083.199951 pos = 36.7201,138.5980 diff = 230.399902'
});
data_saddle.push({
lat: 3.6703111113e+01,
lng: 1.3858566667e+02,
content:'Saddle = 1852.800049 pos = 36.7031,138.5857 diff = 230.399902'
});
data_peak.push({
lat: 3.6670333336e+01,
lng: 1.3852400000e+02,
cert : false,
content:' Peak = 2306.899902 pos = 36.6703,138.5240 diff = 374.999878'
});
data_saddle.push({
lat: 3.6697000002e+01,
lng: 1.3852811111e+02,
content:'Saddle = 1931.900024 pos = 36.6970,138.5281 diff = 374.999878'
});
data_peak.push({
lat: 3.6623000003e+01,
lng: 1.3853166667e+02,
cert : false,
content:' Peak = 2170.699951 pos = 36.6230,138.5317 diff = 159.299927'
});
data_saddle.push({
lat: 3.6637777780e+01,
lng: 1.3853300000e+02,
content:'Saddle = 2011.400024 pos = 36.6378,138.5330 diff = 159.299927'
});
data_peak.push({
lat: 3.6703777780e+01,
lng: 1.3854344444e+02,
cert : true,
content:'Name = JA/GM-009(JA/GM-009) peak = 2106.600098 pos = 36.7038,138.5434 diff = 155.100098'
});
data_saddle.push({
lat: 3.6713333335e+01,
lng: 1.3853577778e+02,
content:'Saddle = 1951.500000 pos = 36.7133,138.5358 diff = 155.100098'
});
data_peak.push({
lat: 3.6549222225e+01,
lng: 1.3839511111e+02,
cert : false,
content:' Peak = 2205.800049 pos = 36.5492,138.3951 diff = 166.700073'
});
data_saddle.push({
lat: 3.6546000003e+01,
lng: 1.3840311111e+02,
content:'Saddle = 2039.099976 pos = 36.5460,138.4031 diff = 166.700073'
});
data_peak.push({
lat: 3.6464777781e+01,
lng: 1.3837088889e+02,
cert : true,
content:'Name = JA/NN-110(JA/NN-110) peak = 1643.900024 pos = 36.4648,138.3709 diff = 192.500000'
});
data_saddle.push({
lat: 3.6462777781e+01,
lng: 1.3838166667e+02,
content:'Saddle = 1451.400024 pos = 36.4628,138.3817 diff = 192.500000'
});
data_peak.push({
lat: 3.6455000003e+01,
lng: 1.3844855556e+02,
cert : false,
content:' Peak = 1745.199951 pos = 36.4550,138.4486 diff = 221.299927'
});
data_saddle.push({
lat: 3.6447666670e+01,
lng: 1.3844066667e+02,
content:'Saddle = 1523.900024 pos = 36.4477,138.4407 diff = 221.299927'
});
data_peak.push({
lat: 3.6434777781e+01,
lng: 1.3840088889e+02,
cert : true,
content:'Name = Yunomaruyama(JA/NN-059) peak = 2100.899902 pos = 36.4348,138.4009 diff = 370.499878'
});
data_saddle.push({
lat: 3.6427111114e+01,
lng: 1.3841966667e+02,
content:'Saddle = 1730.400024 pos = 36.4271,138.4197 diff = 370.499878'
});
data_peak.push({
lat: 3.6453000003e+01,
lng: 1.3840844444e+02,
cert : true,
content:'Name = JA/GM-014(JA/GM-014) peak = 1980.099976 pos = 36.4530,138.4084 diff = 172.699951'
});
data_saddle.push({
lat: 3.6448555559e+01,
lng: 1.3840200000e+02,
content:'Saddle = 1807.400024 pos = 36.4486,138.4020 diff = 172.699951'
});
data_peak.push({
lat: 3.6433444448e+01,
lng: 1.3838711111e+02,
cert : false,
content:' Peak = 2063.699951 pos = 36.4334,138.3871 diff = 210.899902'
});
data_saddle.push({
lat: 3.6432555559e+01,
lng: 1.3839411111e+02,
content:'Saddle = 1852.800049 pos = 36.4326,138.3941 diff = 210.899902'
});
data_peak.push({
lat: 3.6442444448e+01,
lng: 1.3842700000e+02,
cert : true,
content:'Name = JA/GM-020(JA/GM-020) peak = 1930.800049 pos = 36.4424,138.4270 diff = 197.200073'
});
data_saddle.push({
lat: 3.6437888892e+01,
lng: 1.3843088889e+02,
content:'Saddle = 1733.599976 pos = 36.4379,138.4309 diff = 197.200073'
});
data_peak.push({
lat: 3.6419333337e+01,
lng: 1.3844711111e+02,
cert : true,
content:'Name = Kagonotoyama (Higashikagonotoyama)(JA/NN-051) peak = 2226.399902 pos = 36.4193,138.4471 diff = 284.199951'
});
data_saddle.push({
lat: 3.6410444448e+01,
lng: 1.3845911111e+02,
content:'Saddle = 1942.199951 pos = 36.4104,138.4591 diff = 284.199951'
});
data_peak.push({
lat: 3.6392444448e+01,
lng: 1.3850344444e+02,
cert : false,
content:' Peak = 2281.600098 pos = 36.3924,138.5034 diff = 201.100098'
});
data_saddle.push({
lat: 3.6395444448e+01,
lng: 1.3850622222e+02,
content:'Saddle = 2080.500000 pos = 36.3954,138.5062 diff = 201.100098'
});
data_peak.push({
lat: 3.6405222226e+01,
lng: 1.3848855556e+02,
cert : false,
content:' Peak = 2402.800049 pos = 36.4052,138.4886 diff = 271.500000'
});
data_saddle.push({
lat: 3.6413777781e+01,
lng: 1.3850700000e+02,
content:'Saddle = 2131.300049 pos = 36.4138,138.5070 diff = 271.500000'
});
data_peak.push({
lat: 3.7181000000e+01,
lng: 1.3946866667e+02,
cert : true,
content:'Name = JA/FS-025(JA/FS-025) peak = 1484.300049 pos = 37.1810,139.4687 diff = 182.300049'
});
data_saddle.push({
lat: 3.7170222223e+01,
lng: 1.3945844444e+02,
content:'Saddle = 1302.000000 pos = 37.1702,139.4584 diff = 182.300049'
});
data_peak.push({
lat: 3.7030000001e+01,
lng: 1.3927544444e+02,
cert : false,
content:' Peak = 1497.000000 pos = 37.0300,139.2754 diff = 183.800049'
});
data_saddle.push({
lat: 3.7008000001e+01,
lng: 1.3927977778e+02,
content:'Saddle = 1313.199951 pos = 37.0080,139.2798 diff = 183.800049'
});
data_peak.push({
lat: 3.7156333334e+01,
lng: 1.3944588889e+02,
cert : true,
content:'Name = JA/FS-023(JA/FS-023) peak = 1524.900024 pos = 37.1563,139.4459 diff = 204.700073'
});
data_saddle.push({
lat: 3.7133111112e+01,
lng: 1.3941544444e+02,
content:'Saddle = 1320.199951 pos = 37.1331,139.4154 diff = 204.700073'
});
data_peak.push({
lat: 3.7063333334e+01,
lng: 1.3917400000e+02,
cert : true,
content:'Name = JA/NI-025(JA/NI-025) peak = 1520.800049 pos = 37.0633,139.1740 diff = 178.500000'
});
data_saddle.push({
lat: 3.7057555556e+01,
lng: 1.3917233333e+02,
content:'Saddle = 1342.300049 pos = 37.0576,139.1723 diff = 178.500000'
});
data_peak.push({
lat: 3.6961222223e+01,
lng: 1.3907655556e+02,
cert : true,
content:'Name = JA/GM-028(JA/GM-028) peak = 1594.300049 pos = 36.9612,139.0766 diff = 241.000000'
});
data_saddle.push({
lat: 3.6965777779e+01,
lng: 1.3907288889e+02,
content:'Saddle = 1353.300049 pos = 36.9658,139.0729 diff = 241.000000'
});
data_peak.push({
lat: 3.6737666669e+01,
lng: 1.3931788889e+02,
cert : false,
content:' Peak = 1556.599976 pos = 36.7377,139.3179 diff = 185.099976'
});
data_saddle.push({
lat: 3.6740333335e+01,
lng: 1.3932522222e+02,
content:'Saddle = 1371.500000 pos = 36.7403,139.3252 diff = 185.099976'
});
data_peak.push({
lat: 3.6710777780e+01,
lng: 1.3947577778e+02,
cert : true,
content:'Name = JA/TG-020(JA/TG-020) peak = 1752.199951 pos = 36.7108,139.4758 diff = 344.599976'
});
data_saddle.push({
lat: 3.6717111113e+01,
lng: 1.3945911111e+02,
content:'Saddle = 1407.599976 pos = 36.7171,139.4591 diff = 344.599976'
});
data_peak.push({
lat: 3.7138666667e+01,
lng: 1.3940811111e+02,
cert : true,
content:'Name = JA/FS-017(JA/FS-017) peak = 1602.099976 pos = 37.1387,139.4081 diff = 190.599976'
});
data_saddle.push({
lat: 3.7122111112e+01,
lng: 1.3939122222e+02,
content:'Saddle = 1411.500000 pos = 37.1221,139.3912 diff = 190.599976'
});
data_peak.push({
lat: 3.7221222222e+01,
lng: 1.3933955556e+02,
cert : true,
content:'Name = Asahidake(JA/FS-016) peak = 1622.800049 pos = 37.2212,139.3396 diff = 201.200073'
});
data_saddle.push({
lat: 3.7194333334e+01,
lng: 1.3933477778e+02,
content:'Saddle = 1421.599976 pos = 37.1943,139.3348 diff = 201.200073'
});
data_peak.push({
lat: 3.7046888890e+01,
lng: 1.3955088889e+02,
cert : true,
content:'Name = JA/FS-015(JA/FS-015) peak = 1630.000000 pos = 37.0469,139.5509 diff = 198.599976'
});
data_saddle.push({
lat: 3.7023444445e+01,
lng: 1.3955111111e+02,
content:'Saddle = 1431.400024 pos = 37.0234,139.5511 diff = 198.599976'
});
data_peak.push({
lat: 3.6760444446e+01,
lng: 1.3943033333e+02,
cert : true,
content:'Name = JA/TG-022(JA/TG-022) peak = 1666.900024 pos = 36.7604,139.4303 diff = 227.800049'
});
data_saddle.push({
lat: 3.6772888891e+01,
lng: 1.3941755556e+02,
content:'Saddle = 1439.099976 pos = 36.7729,139.4176 diff = 227.800049'
});
data_peak.push({
lat: 3.6817555557e+01,
lng: 1.3883944444e+02,
cert : true,
content:'Name = Sennokurayama(JA/GM-010) peak = 2025.300049 pos = 36.8176,138.8394 diff = 583.000000'
});
data_saddle.push({
lat: 3.6983333334e+01,
lng: 1.3900644444e+02,
content:'Saddle = 1442.300049 pos = 36.9833,139.0064 diff = 583.000000'
});
data_peak.push({
lat: 3.6978555557e+01,
lng: 1.3896444444e+02,
cert : true,
content:'Name = Makihatayama(JA/GM-016) peak = 1965.400024 pos = 36.9786,138.9644 diff = 522.099976'
});
data_saddle.push({
lat: 3.6894555557e+01,
lng: 1.3894744444e+02,
content:'Saddle = 1443.300049 pos = 36.8946,138.9474 diff = 522.099976'
});
data_peak.push({
lat: 3.6884666668e+01,
lng: 1.3897244444e+02,
cert : false,
content:' Peak = 1944.599976 pos = 36.8847,138.9724 diff = 391.799927'
});
data_saddle.push({
lat: 3.6923777779e+01,
lng: 1.3897444444e+02,
content:'Saddle = 1552.800049 pos = 36.9238,138.9744 diff = 391.799927'
});
data_peak.push({
lat: 3.6935777779e+01,
lng: 1.3896655556e+02,
cert : true,
content:'Name = JA/GM-021(JA/GM-021) peak = 1901.400024 pos = 36.9358,138.9666 diff = 254.900024'
});
data_saddle.push({
lat: 3.6963222223e+01,
lng: 1.3896555556e+02,
content:'Saddle = 1646.500000 pos = 36.9632,138.9656 diff = 254.900024'
});
data_peak.push({
lat: 3.6854444446e+01,
lng: 1.3881588889e+02,
cert : true,
content:'Name = JA/NI-021(JA/NI-021) peak = 1630.599976 pos = 36.8544,138.8159 diff = 177.699951'
});
data_saddle.push({
lat: 3.6838666668e+01,
lng: 1.3880988889e+02,
content:'Saddle = 1452.900024 pos = 36.8387,138.8099 diff = 177.699951'
});
data_peak.push({
lat: 3.6797444446e+01,
lng: 1.3888933333e+02,
cert : true,
content:'Name = JA/GM-025(JA/GM-025) peak = 1746.199951 pos = 36.7974,138.8893 diff = 194.899902'
});
data_saddle.push({
lat: 3.6804555557e+01,
lng: 1.3889188889e+02,
content:'Saddle = 1551.300049 pos = 36.8046,138.8919 diff = 194.899902'
});
data_peak.push({
lat: 3.6849222224e+01,
lng: 1.3891677778e+02,
cert : true,
content:'Name = Tanigawadake (Shigekuradake)(JA/NI-013) peak = 1977.300049 pos = 36.8492,138.9168 diff = 410.400024'
});
data_saddle.push({
lat: 3.6816555557e+01,
lng: 1.3886522222e+02,
content:'Saddle = 1566.900024 pos = 36.8166,138.8652 diff = 410.400024'
});
data_peak.push({
lat: 3.6867111113e+01,
lng: 1.3891955556e+02,
cert : false,
content:' Peak = 1758.300049 pos = 36.8671,138.9196 diff = 165.600098'
});
data_saddle.push({
lat: 3.6860111113e+01,
lng: 1.3892166667e+02,
content:'Saddle = 1592.699951 pos = 36.8601,138.9217 diff = 165.600098'
});
data_peak.push({
lat: 3.6824222224e+01,
lng: 1.3887922222e+02,
cert : true,
content:'Name = Mantarousan(JA/GM-017) peak = 1953.000000 pos = 36.8242,138.8792 diff = 281.699951'
});
data_saddle.push({
lat: 3.6827666668e+01,
lng: 1.3890533333e+02,
content:'Saddle = 1671.300049 pos = 36.8277,138.9053 diff = 281.699951'
});
data_peak.push({
lat: 3.7172666667e+01,
lng: 1.3933488889e+02,
cert : true,
content:'Name = Maruyamadake(JA/FS-008) peak = 1816.300049 pos = 37.1727,139.3349 diff = 342.800049'
});
data_saddle.push({
lat: 3.7119222223e+01,
lng: 1.3934600000e+02,
content:'Saddle = 1473.500000 pos = 37.1192,139.3460 diff = 342.800049'
});
data_peak.push({
lat: 3.7132777778e+01,
lng: 1.3933944444e+02,
cert : false,
content:' Peak = 1741.800049 pos = 37.1328,139.3394 diff = 179.300049'
});
data_saddle.push({
lat: 3.7145222223e+01,
lng: 1.3933600000e+02,
content:'Saddle = 1562.500000 pos = 37.1452,139.3360 diff = 179.300049'
});
data_peak.push({
lat: 3.7047666667e+01,
lng: 1.3935366667e+02,
cert : true,
content:'Name = Komagatake(JA/FS-002) peak = 2132.100098 pos = 37.0477,139.3537 diff = 623.400146'
});
data_saddle.push({
lat: 3.6983666668e+01,
lng: 1.3930377778e+02,
content:'Saddle = 1508.699951 pos = 36.9837,139.3038 diff = 623.400146'
});
data_peak.push({
lat: 3.7118333334e+01,
lng: 1.3937444444e+02,
cert : false,
content:' Peak = 1770.500000 pos = 37.1183,139.3744 diff = 159.199951'
});
data_saddle.push({
lat: 3.7112222223e+01,
lng: 1.3938066667e+02,
content:'Saddle = 1611.300049 pos = 37.1122,139.3807 diff = 159.199951'
});
data_peak.push({
lat: 3.6998444445e+01,
lng: 1.3930388889e+02,
cert : false,
content:' Peak = 1921.099976 pos = 36.9984,139.3039 diff = 173.199951'
});
data_saddle.push({
lat: 3.7014000001e+01,
lng: 1.3932955556e+02,
content:'Saddle = 1747.900024 pos = 37.0140,139.3296 diff = 173.199951'
});
data_peak.push({
lat: 3.7080888890e+01,
lng: 1.3937711111e+02,
cert : false,
content:' Peak = 2071.600098 pos = 37.0809,139.3771 diff = 152.700073'
});
data_saddle.push({
lat: 3.7063333334e+01,
lng: 1.3937233333e+02,
content:'Saddle = 1918.900024 pos = 37.0633,139.3723 diff = 152.700073'
});
data_peak.push({
lat: 3.6998000001e+01,
lng: 1.3954622222e+02,
cert : true,
content:'Name = JA/FS-011(JA/FS-011) peak = 1752.599976 pos = 36.9980,139.5462 diff = 223.400024'
});
data_saddle.push({
lat: 3.6980555557e+01,
lng: 1.3952788889e+02,
content:'Saddle = 1529.199951 pos = 36.9806,139.5279 diff = 223.400024'
});
data_peak.push({
lat: 3.6805222224e+01,
lng: 1.3913255556e+02,
cert : true,
content:'Name = Hotakayama(JA/GM-005) peak = 2156.600098 pos = 36.8052,139.1326 diff = 614.800049'
});
data_saddle.push({
lat: 3.6837000002e+01,
lng: 1.3918177778e+02,
content:'Saddle = 1541.800049 pos = 36.8370,139.1818 diff = 614.800049'
});
data_peak.push({
lat: 3.7085333334e+01,
lng: 1.3907755556e+02,
cert : true,
content:'Name = Nakanodake(JA/NI-009) peak = 2082.899902 pos = 37.0853,139.0776 diff = 530.199951'
});
data_saddle.push({
lat: 3.7050888890e+01,
lng: 1.3911322222e+02,
content:'Saddle = 1552.699951 pos = 37.0509,139.1132 diff = 530.199951'
});
data_peak.push({
lat: 3.7100444445e+01,
lng: 1.3914811111e+02,
cert : true,
content:'Name = Arasawadake(JA/NI-014) peak = 1966.400024 pos = 37.1004,139.1481 diff = 324.500000'
});
data_saddle.push({
lat: 3.7069444445e+01,
lng: 1.3911577778e+02,
content:'Saddle = 1641.900024 pos = 37.0694,139.1158 diff = 324.500000'
});
data_peak.push({
lat: 3.7078444445e+01,
lng: 1.3913766667e+02,
cert : false,
content:' Peak = 1852.199951 pos = 37.0784,139.1377 diff = 154.699951'
});
data_saddle.push({
lat: 3.7089444445e+01,
lng: 1.3913844444e+02,
content:'Saddle = 1697.500000 pos = 37.0894,139.1384 diff = 154.699951'
});
data_peak.push({
lat: 3.6987333334e+01,
lng: 1.3904722222e+02,
cert : true,
content:'Name = JA/GM-018(JA/GM-018) peak = 1945.199951 pos = 36.9873,139.0472 diff = 292.699951'
});
data_saddle.push({
lat: 3.7006111112e+01,
lng: 1.3906966667e+02,
content:'Saddle = 1652.500000 pos = 37.0061,139.0697 diff = 292.699951'
});
data_peak.push({
lat: 3.7008666668e+01,
lng: 1.3908044444e+02,
cert : false,
content:' Peak = 1862.500000 pos = 37.0087,139.0804 diff = 190.300049'
});
data_saddle.push({
lat: 3.7035111112e+01,
lng: 1.3908977778e+02,
content:'Saddle = 1672.199951 pos = 37.0351,139.0898 diff = 190.300049'
});
data_peak.push({
lat: 3.7123666667e+01,
lng: 1.3907522222e+02,
cert : true,
content:'Name = Komagatake(JA/NI-012) peak = 2002.400024 pos = 37.1237,139.0752 diff = 288.200073'
});
data_saddle.push({
lat: 3.7108777778e+01,
lng: 1.3907766667e+02,
content:'Saddle = 1714.199951 pos = 37.1088,139.0777 diff = 288.200073'
});
data_peak.push({
lat: 3.7066333334e+01,
lng: 1.3909788889e+02,
cert : true,
content:'Name = JA/NI-016(JA/NI-016) peak = 1924.000000 pos = 37.0663,139.0979 diff = 195.300049'
});
data_saddle.push({
lat: 3.7075222223e+01,
lng: 1.3908255556e+02,
content:'Saddle = 1728.699951 pos = 37.0752,139.0826 diff = 195.300049'
});
data_peak.push({
lat: 3.6903555557e+01,
lng: 1.3917322222e+02,
cert : true,
content:'Name = Shibutsusan(JA/GM-002) peak = 2226.000000 pos = 36.9036,139.1732 diff = 635.000000'
});
data_saddle.push({
lat: 3.6890222224e+01,
lng: 1.3920033333e+02,
content:'Saddle = 1591.000000 pos = 36.8902,139.2003 diff = 635.000000'
});
data_peak.push({
lat: 3.6841333335e+01,
lng: 1.3919811111e+02,
cert : true,
content:'Name = JA/GM-022(JA/GM-022) peak = 1897.199951 pos = 36.8413,139.1981 diff = 284.699951'
});
data_saddle.push({
lat: 3.6860444446e+01,
lng: 1.3918277778e+02,
content:'Saddle = 1612.500000 pos = 36.8604,139.1828 diff = 284.699951'
});
data_peak.push({
lat: 3.7002111112e+01,
lng: 1.3917077778e+02,
cert : true,
content:'Name = Hiragatake(JA/NI-006) peak = 2140.800049 pos = 37.0021,139.1708 diff = 514.500000'
});
data_saddle.push({
lat: 3.6931444446e+01,
lng: 1.3917044444e+02,
content:'Saddle = 1626.300049 pos = 36.9314,139.1704 diff = 514.500000'
});
data_peak.push({
lat: 3.6960555557e+01,
lng: 1.3914522222e+02,
cert : false,
content:' Peak = 1951.699951 pos = 36.9606,139.1452 diff = 190.699951'
});
data_saddle.push({
lat: 3.6957888890e+01,
lng: 1.3915677778e+02,
content:'Saddle = 1761.000000 pos = 36.9579,139.1568 diff = 190.699951'
});
data_peak.push({
lat: 3.6956888890e+01,
lng: 1.3921055556e+02,
cert : true,
content:'Name = Keiduruyama(JA/GM-012) peak = 2002.400024 pos = 36.9569,139.2106 diff = 210.300049'
});
data_saddle.push({
lat: 3.6972555557e+01,
lng: 1.3917533333e+02,
content:'Saddle = 1792.099976 pos = 36.9726,139.1753 diff = 210.300049'
});
data_peak.push({
lat: 3.6689888891e+01,
lng: 1.3933688889e+02,
cert : true,
content:'Name = Sukaisan(JA/TG-009) peak = 2141.600098 pos = 36.6899,139.3369 diff = 548.700073'
});
data_saddle.push({
lat: 3.6701444447e+01,
lng: 1.3935022222e+02,
content:'Saddle = 1592.900024 pos = 36.7014,139.3502 diff = 548.700073'
});
data_peak.push({
lat: 3.6649444447e+01,
lng: 1.3932744444e+02,
cert : false,
content:' Peak = 1960.800049 pos = 36.6494,139.3274 diff = 158.200073'
});
data_saddle.push({
lat: 3.6666777780e+01,
lng: 1.3933411111e+02,
content:'Saddle = 1802.599976 pos = 36.6668,139.3341 diff = 158.200073'
});
data_peak.push({
lat: 3.6844444446e+01,
lng: 1.3947666667e+02,
cert : false,
content:' Peak = 1791.300049 pos = 36.8444,139.4767 diff = 188.600098'
});
data_saddle.push({
lat: 3.6834222224e+01,
lng: 1.3947688889e+02,
content:'Saddle = 1602.699951 pos = 36.8342,139.4769 diff = 188.600098'
});
data_peak.push({
lat: 3.6987444445e+01,
lng: 1.3941333333e+02,
cert : false,
content:' Peak = 1844.199951 pos = 36.9874,139.4133 diff = 176.299927'
});
data_saddle.push({
lat: 3.6991555557e+01,
lng: 1.3943177778e+02,
content:'Saddle = 1667.900024 pos = 36.9916,139.4318 diff = 176.299927'
});
data_peak.push({
lat: 3.6724666669e+01,
lng: 1.3936677778e+02,
cert : true,
content:'Name = JA/TG-012(JA/TG-012) peak = 1980.099976 pos = 36.7247,139.3668 diff = 276.900024'
});
data_saddle.push({
lat: 3.6736444446e+01,
lng: 1.3936700000e+02,
content:'Saddle = 1703.199951 pos = 36.7364,139.3670 diff = 276.900024'
});
data_peak.push({
lat: 3.6724444447e+01,
lng: 1.3941155556e+02,
cert : true,
content:'Name = JA/TG-013(JA/TG-013) peak = 1974.900024 pos = 36.7244,139.4116 diff = 183.200073'
});
data_saddle.push({
lat: 3.6724000002e+01,
lng: 1.3938955556e+02,
content:'Saddle = 1791.699951 pos = 36.7240,139.3896 diff = 183.200073'
});
data_peak.push({
lat: 3.6811333335e+01,
lng: 1.3943988889e+02,
cert : true,
content:'Name = JA/TG-014(JA/TG-014) peak = 1943.900024 pos = 36.8113,139.4399 diff = 227.400024'
});
data_saddle.push({
lat: 3.6813333335e+01,
lng: 1.3945044444e+02,
content:'Saddle = 1716.500000 pos = 36.8133,139.4504 diff = 227.400024'
});
data_peak.push({
lat: 3.6886444446e+01,
lng: 1.3927177778e+02,
cert : true,
content:'Name = JA/GM-011(JA/GM-011) peak = 2023.400024 pos = 36.8864,139.2718 diff = 301.400024'
});
data_saddle.push({
lat: 3.6920444446e+01,
lng: 1.3929466667e+02,
content:'Saddle = 1722.000000 pos = 36.9204,139.2947 diff = 301.400024'
});
data_peak.push({
lat: 3.6914777779e+01,
lng: 1.3927788889e+02,
cert : false,
content:' Peak = 1916.099976 pos = 36.9148,139.2779 diff = 168.299927'
});
data_saddle.push({
lat: 3.6907666668e+01,
lng: 1.3927488889e+02,
content:'Saddle = 1747.800049 pos = 36.9077,139.2749 diff = 168.299927'
});
data_peak.push({
lat: 3.6765222224e+01,
lng: 1.3949077778e+02,
cert : true,
content:'Name = Nantaisan(JA/TG-002) peak = 2483.300049 pos = 36.7652,139.4908 diff = 755.600098'
});
data_saddle.push({
lat: 3.6823888891e+01,
lng: 1.3945855556e+02,
content:'Saddle = 1727.699951 pos = 36.8239,139.4586 diff = 755.600098'
});
data_peak.push({
lat: 3.6811555557e+01,
lng: 1.3953644444e+02,
cert : true,
content:'Name = Nyohousan(JA/TG-003) peak = 2480.100098 pos = 36.8116,139.5364 diff = 695.300049'
});
data_saddle.push({
lat: 3.6784555557e+01,
lng: 1.3950133333e+02,
content:'Saddle = 1784.800049 pos = 36.7846,139.5013 diff = 695.300049'
});
data_peak.push({
lat: 3.6817888891e+01,
lng: 1.3948277778e+02,
cert : true,
content:'Name = Tarousan(JA/TG-006) peak = 2365.699951 pos = 36.8179,139.4828 diff = 486.399902'
});
data_saddle.push({
lat: 3.6813888891e+01,
lng: 1.3949500000e+02,
content:'Saddle = 1879.300049 pos = 36.8139,139.4950 diff = 486.399902'
});
data_peak.push({
lat: 3.6818000002e+01,
lng: 1.3946300000e+02,
cert : false,
content:' Peak = 2075.300049 pos = 36.8180,139.4630 diff = 156.900024'
});
data_saddle.push({
lat: 3.6817222224e+01,
lng: 1.3946855556e+02,
content:'Saddle = 1918.400024 pos = 36.8172,139.4686 diff = 156.900024'
});
data_peak.push({
lat: 3.6795333335e+01,
lng: 1.3950700000e+02,
cert : true,
content:'Name = Nyohousan (Oomanagosan)(JA/TG-005) peak = 2374.699951 pos = 36.7953,139.5070 diff = 335.899902'
});
data_saddle.push({
lat: 3.6810333335e+01,
lng: 1.3951555556e+02,
content:'Saddle = 2038.800049 pos = 36.8103,139.5156 diff = 335.899902'
});
data_peak.push({
lat: 3.6807333335e+01,
lng: 1.3951077778e+02,
cert : false,
content:' Peak = 2322.500000 pos = 36.8073,139.5108 diff = 210.100098'
});
data_saddle.push({
lat: 3.6802888891e+01,
lng: 1.3951088889e+02,
content:'Saddle = 2112.399902 pos = 36.8029,139.5109 diff = 210.100098'
});
data_peak.push({
lat: 3.6955222223e+01,
lng: 1.3928522222e+02,
cert : true,
content:'Name = Hiuchigatake (Shibayasugura)(JA/FS-001) peak = 2353.100098 pos = 36.9552,139.2852 diff = 620.000122'
});
data_saddle.push({
lat: 3.6942444446e+01,
lng: 1.3931311111e+02,
content:'Saddle = 1733.099976 pos = 36.9424,139.3131 diff = 620.000122'
});
data_peak.push({
lat: 3.6969888890e+01,
lng: 1.3946000000e+02,
cert : true,
content:'Name = Taishakuzan(JA/TG-011) peak = 2056.800049 pos = 36.9699,139.4600 diff = 269.500000'
});
data_saddle.push({
lat: 3.6963888890e+01,
lng: 1.3945866667e+02,
content:'Saddle = 1787.300049 pos = 36.9639,139.4587 diff = 269.500000'
});
data_peak.push({
lat: 3.6844111113e+01,
lng: 1.3932977778e+02,
cert : true,
content:'Name = JA/GM-006(JA/GM-006) peak = 2155.100098 pos = 36.8441,139.3298 diff = 333.600098'
});
data_saddle.push({
lat: 3.6847888890e+01,
lng: 1.3933588889e+02,
content:'Saddle = 1821.500000 pos = 36.8479,139.3359 diff = 333.600098'
});
data_peak.push({
lat: 3.6827111113e+01,
lng: 1.3944766667e+02,
cert : false,
content:' Peak = 2020.199951 pos = 36.8271,139.4477 diff = 168.699951'
});
data_saddle.push({
lat: 3.6829444446e+01,
lng: 1.3943888889e+02,
content:'Saddle = 1851.500000 pos = 36.8294,139.4389 diff = 168.699951'
});
data_peak.push({
lat: 3.6947555557e+01,
lng: 1.3944177778e+02,
cert : false,
content:' Peak = 2060.399902 pos = 36.9476,139.4418 diff = 187.899902'
});
data_saddle.push({
lat: 3.6939444446e+01,
lng: 1.3943466667e+02,
content:'Saddle = 1872.500000 pos = 36.9394,139.4347 diff = 187.899902'
});
data_peak.push({
lat: 3.6913000001e+01,
lng: 1.3934922222e+02,
cert : false,
content:' Peak = 2041.699951 pos = 36.9130,139.3492 diff = 163.299927'
});
data_saddle.push({
lat: 3.6916333335e+01,
lng: 1.3936033333e+02,
content:'Saddle = 1878.400024 pos = 36.9163,139.3603 diff = 163.299927'
});
data_peak.push({
lat: 3.6852777779e+01,
lng: 1.3934844444e+02,
cert : true,
content:'Name = JA/GM-003(JA/GM-003) peak = 2220.800049 pos = 36.8528,139.3484 diff = 278.600098'
});
data_saddle.push({
lat: 3.6840333335e+01,
lng: 1.3937066667e+02,
content:'Saddle = 1942.199951 pos = 36.8403,139.3707 diff = 278.600098'
});
data_peak.push({
lat: 3.6908777779e+01,
lng: 1.3939366667e+02,
cert : true,
content:'Name = Kuroiwayama(JA/TG-008) peak = 2161.600098 pos = 36.9088,139.3937 diff = 189.900146'
});
data_saddle.push({
lat: 3.6901888890e+01,
lng: 1.3938922222e+02,
content:'Saddle = 1971.699951 pos = 36.9019,139.3892 diff = 189.900146'
});
data_peak.push({
lat: 3.6824555557e+01,
lng: 1.3940377778e+02,
cert : true,
content:'Name = JA/TG-007(JA/TG-007) peak = 2331.399902 pos = 36.8246,139.4038 diff = 320.099854'
});
data_saddle.push({
lat: 3.6819000002e+01,
lng: 1.3939500000e+02,
content:'Saddle = 2011.300049 pos = 36.8190,139.3950 diff = 320.099854'
});
data_peak.push({
lat: 3.6773666669e+01,
lng: 1.3935300000e+02,
cert : true,
content:'Name = JA/TG-004(JA/TG-004) peak = 2386.199951 pos = 36.7737,139.3530 diff = 218.500000'
});
data_saddle.push({
lat: 3.6777555557e+01,
lng: 1.3936144444e+02,
content:'Saddle = 2167.699951 pos = 36.7776,139.3614 diff = 218.500000'
});
data_peak.push({
lat: 3.6094888894e+01,
lng: 1.3878333333e+02,
cert : false,
content:' Peak = 1130.199951 pos = 36.0949,138.7833 diff = 158.599976'
});
data_saddle.push({
lat: 3.6110555560e+01,
lng: 1.3878055556e+02,
content:'Saddle = 971.599976 pos = 36.1106,138.7806 diff = 158.599976'
});
data_peak.push({
lat: 3.6322333337e+01,
lng: 1.3811466667e+02,
cert : true,
content:'Name = JA/NN-163(JA/NN-163) peak = 1231.500000 pos = 36.3223,138.1147 diff = 259.000000'
});
data_saddle.push({
lat: 3.6324777781e+01,
lng: 1.3810188889e+02,
content:'Saddle = 972.500000 pos = 36.3248,138.1019 diff = 259.000000'
});
data_peak.push({
lat: 3.6300333337e+01,
lng: 1.3865855556e+02,
cert : true,
content:'Name = JA/GM-055(JA/GM-055) peak = 1190.400024 pos = 36.3003,138.6586 diff = 214.400024'
});
data_saddle.push({
lat: 3.6297777782e+01,
lng: 1.3864666667e+02,
content:'Saddle = 976.000000 pos = 36.2978,138.6467 diff = 214.400024'
});
data_peak.push({
lat: 3.6334222226e+01,
lng: 1.3865044444e+02,
cert : false,
content:' Peak = 1182.000000 pos = 36.3342,138.6504 diff = 150.400024'
});
data_saddle.push({
lat: 3.6320222226e+01,
lng: 1.3865100000e+02,
content:'Saddle = 1031.599976 pos = 36.3202,138.6510 diff = 150.400024'
});
data_peak.push({
lat: 3.6284555559e+01,
lng: 1.3863266667e+02,
cert : true,
content:'Name = JA/GM-054(JA/GM-054) peak = 1206.000000 pos = 36.2846,138.6327 diff = 213.799988'
});
data_saddle.push({
lat: 3.6288222226e+01,
lng: 1.3862611111e+02,
content:'Saddle = 992.200012 pos = 36.2882,138.6261 diff = 213.799988'
});
data_peak.push({
lat: 3.6018777783e+01,
lng: 1.3799266667e+02,
cert : true,
content:'Name = JA/NN-156(JA/NN-156) peak = 1290.599976 pos = 36.0188,137.9927 diff = 273.699951'
});
data_saddle.push({
lat: 3.6086222227e+01,
lng: 1.3802911111e+02,
content:'Saddle = 1016.900024 pos = 36.0862,138.0291 diff = 273.699951'
});
data_peak.push({
lat: 3.6149222227e+01,
lng: 1.3894144444e+02,
cert : false,
content:' Peak = 1245.900024 pos = 36.1492,138.9414 diff = 223.100037'
});
data_saddle.push({
lat: 3.6151000004e+01,
lng: 1.3892644444e+02,
content:'Saddle = 1022.799988 pos = 36.1510,138.9264 diff = 223.100037'
});
data_peak.push({
lat: 3.6377666670e+01,
lng: 1.3803955556e+02,
cert : true,
content:'Name = JA/NN-154(JA/NN-154) peak = 1312.900024 pos = 36.3777,138.0396 diff = 281.099976'
});
data_saddle.push({
lat: 3.6378444448e+01,
lng: 1.3804966667e+02,
content:'Saddle = 1031.800049 pos = 36.3784,138.0497 diff = 281.099976'
});
data_peak.push({
lat: 3.6143777782e+01,
lng: 1.3884322222e+02,
cert : true,
content:'Name = Akagunayama(JA/GM-030) peak = 1521.800049 pos = 36.1438,138.8432 diff = 469.200073'
});
data_saddle.push({
lat: 3.6121888893e+01,
lng: 1.3873933333e+02,
content:'Saddle = 1052.599976 pos = 36.1219,138.7393 diff = 469.200073'
});
data_peak.push({
lat: 3.6152333338e+01,
lng: 1.3891844444e+02,
cert : true,
content:'Name = Mikaboyama (Nishimikaboyama)(JA/GM-047) peak = 1284.800049 pos = 36.1523,138.9184 diff = 223.200073'
});
data_saddle.push({
lat: 3.6146333338e+01,
lng: 1.3889655556e+02,
content:'Saddle = 1061.599976 pos = 36.1463,138.8966 diff = 223.200073'
});
data_peak.push({
lat: 3.6169555560e+01,
lng: 1.3882511111e+02,
cert : false,
content:' Peak = 1365.500000 pos = 36.1696,138.8251 diff = 193.900024'
});
data_saddle.push({
lat: 3.6164555560e+01,
lng: 1.3882711111e+02,
content:'Saddle = 1171.599976 pos = 36.1646,138.8271 diff = 193.900024'
});
data_peak.push({
lat: 3.6398555559e+01,
lng: 1.3806344444e+02,
cert : false,
content:' Peak = 1437.699951 pos = 36.3986,138.0634 diff = 375.000000'
});
data_saddle.push({
lat: 3.6380000003e+01,
lng: 1.3807266667e+02,
content:'Saddle = 1062.699951 pos = 36.3800,138.0727 diff = 375.000000'
});
data_peak.push({
lat: 3.6247444448e+01,
lng: 1.3860444444e+02,
cert : true,
content:'Name = JA/NN-142(JA/NN-142) peak = 1373.800049 pos = 36.2474,138.6044 diff = 305.700073'
});
data_saddle.push({
lat: 3.6222666671e+01,
lng: 1.3861588889e+02,
content:'Saddle = 1068.099976 pos = 36.2227,138.6159 diff = 305.700073'
});
data_peak.push({
lat: 3.6278333337e+01,
lng: 1.3860044444e+02,
cert : false,
content:' Peak = 1322.900024 pos = 36.2783,138.6004 diff = 181.400024'
});
data_saddle.push({
lat: 3.6264888893e+01,
lng: 1.3860444444e+02,
content:'Saddle = 1141.500000 pos = 36.2649,138.6044 diff = 181.400024'
});
data_peak.push({
lat: 3.6033888894e+01,
lng: 1.3860733333e+02,
cert : true,
content:'Name = Ogurasan(JA/NN-058) peak = 2112.100098 pos = 36.0339,138.6073 diff = 1042.700073'
});
data_saddle.push({
lat: 3.6000111116e+01,
lng: 1.3852011111e+02,
content:'Saddle = 1069.400024 pos = 36.0001,138.5201 diff = 1042.700073'
});
data_peak.push({
lat: 3.6139888893e+01,
lng: 1.3859311111e+02,
cert : true,
content:'Name = JA/NN-125(JA/NN-125) peak = 1480.199951 pos = 36.1399,138.5931 diff = 372.799927'
});
data_saddle.push({
lat: 3.6136111116e+01,
lng: 1.3860777778e+02,
content:'Saddle = 1107.400024 pos = 36.1361,138.6078 diff = 372.799927'
});
data_peak.push({
lat: 3.6204000004e+01,
lng: 1.3863711111e+02,
cert : true,
content:'Name = Arafuneyama(JA/GM-035) peak = 1421.699951 pos = 36.2040,138.6371 diff = 289.799927'
});
data_saddle.push({
lat: 3.6188666671e+01,
lng: 1.3860566667e+02,
content:'Saddle = 1131.900024 pos = 36.1887,138.6057 diff = 289.799927'
});
data_peak.push({
lat: 3.6176666671e+01,
lng: 1.3859322222e+02,
cert : false,
content:' Peak = 1301.599976 pos = 36.1767,138.5932 diff = 157.599976'
});
data_saddle.push({
lat: 3.6177888893e+01,
lng: 1.3859055556e+02,
content:'Saddle = 1144.000000 pos = 36.1779,138.5906 diff = 157.599976'
});
data_peak.push({
lat: 3.6023444449e+01,
lng: 1.3884122222e+02,
cert : true,
content:'Name = Ryoukamisan(JA/ST-002) peak = 1722.500000 pos = 36.0234,138.8412 diff = 504.300049'
});
data_saddle.push({
lat: 3.6000111116e+01,
lng: 1.3871000000e+02,
content:'Saddle = 1218.199951 pos = 36.0001,138.7100 diff = 504.300049'
});
data_peak.push({
lat: 3.6000222227e+01,
lng: 1.3872133333e+02,
cert : false,
content:' Peak = 1511.699951 pos = 36.0002,138.7213 diff = 216.099976'
});
data_saddle.push({
lat: 3.6000111116e+01,
lng: 1.3872600000e+02,
content:'Saddle = 1295.599976 pos = 36.0001,138.7260 diff = 216.099976'
});
data_peak.push({
lat: 3.6024000005e+01,
lng: 1.3875077778e+02,
cert : false,
content:' Peak = 1656.599976 pos = 36.0240,138.7508 diff = 294.099976'
});
data_saddle.push({
lat: 3.6033888894e+01,
lng: 1.3878266667e+02,
content:'Saddle = 1362.500000 pos = 36.0339,138.7827 diff = 294.099976'
});
data_peak.push({
lat: 3.6002777783e+01,
lng: 1.3855711111e+02,
cert : false,
content:' Peak = 1700.599976 pos = 36.0028,138.5571 diff = 390.799927'
});
data_saddle.push({
lat: 3.6000111116e+01,
lng: 1.3862333333e+02,
content:'Saddle = 1309.800049 pos = 36.0001,138.6233 diff = 390.799927'
});
data_peak.push({
lat: 3.6000111116e+01,
lng: 1.3860233333e+02,
cert : false,
content:' Peak = 1542.900024 pos = 36.0001,138.6023 diff = 217.400024'
});
data_saddle.push({
lat: 3.6000111116e+01,
lng: 1.3857711111e+02,
content:'Saddle = 1325.500000 pos = 36.0001,138.5771 diff = 217.400024'
});
data_peak.push({
lat: 3.6012777783e+01,
lng: 1.3858655556e+02,
cert : true,
content:'Name = JA/NN-112(JA/NN-112) peak = 1631.800049 pos = 36.0128,138.5866 diff = 234.900024'
});
data_saddle.push({
lat: 3.6010333338e+01,
lng: 1.3860044444e+02,
content:'Saddle = 1396.900024 pos = 36.0103,138.6004 diff = 234.900024'
});
data_peak.push({
lat: 3.6111888893e+01,
lng: 1.3854766667e+02,
cert : true,
content:'Name = JA/NN-094(JA/NN-094) peak = 1716.699951 pos = 36.1119,138.5477 diff = 212.699951'
});
data_saddle.push({
lat: 3.6064000005e+01,
lng: 1.3864244444e+02,
content:'Saddle = 1504.000000 pos = 36.0640,138.6424 diff = 212.699951'
});
data_peak.push({
lat: 3.6094888894e+01,
lng: 1.3862488889e+02,
cert : false,
content:' Peak = 1683.599976 pos = 36.0949,138.6249 diff = 150.799927'
});
data_saddle.push({
lat: 3.6096777782e+01,
lng: 1.3860633333e+02,
content:'Saddle = 1532.800049 pos = 36.0968,138.6063 diff = 150.799927'
});
data_peak.push({
lat: 3.6004222227e+01,
lng: 1.3868100000e+02,
cert : false,
content:' Peak = 1960.599976 pos = 36.0042,138.6810 diff = 267.599976'
});
data_saddle.push({
lat: 3.6016555560e+01,
lng: 1.3865822222e+02,
content:'Saddle = 1693.000000 pos = 36.0166,138.6582 diff = 267.599976'
});
data_peak.push({
lat: 3.6333222226e+01,
lng: 1.3806288889e+02,
cert : true,
content:'Name = JA/NN-113(JA/NN-113) peak = 1624.300049 pos = 36.3332,138.0629 diff = 311.400024'
});
data_saddle.push({
lat: 3.6302777782e+01,
lng: 1.3807822222e+02,
content:'Saddle = 1312.900024 pos = 36.3028,138.0782 diff = 311.400024'
});
data_peak.push({
lat: 3.6225888893e+01,
lng: 1.3810744444e+02,
cert : true,
content:'Name = Utsukushigahara (Ougatou)(JA/NN-067) peak = 2033.699951 pos = 36.2259,138.1074 diff = 602.599976'
});
data_saddle.push({
lat: 3.6112666671e+01,
lng: 1.3824144444e+02,
content:'Saddle = 1431.099976 pos = 36.1127,138.2414 diff = 602.599976'
});
data_peak.push({
lat: 3.6287111115e+01,
lng: 1.3803988889e+02,
cert : false,
content:' Peak = 1628.300049 pos = 36.2871,138.0399 diff = 194.500000'
});
data_saddle.push({
lat: 3.6286333337e+01,
lng: 1.3805433333e+02,
content:'Saddle = 1433.800049 pos = 36.2863,138.0543 diff = 194.500000'
});
data_peak.push({
lat: 3.6158555560e+01,
lng: 1.3819377778e+02,
cert : true,
content:'Name = JA/NN-101(JA/NN-101) peak = 1671.500000 pos = 36.1586,138.1938 diff = 214.800049'
});
data_saddle.push({
lat: 3.6151666671e+01,
lng: 1.3818733333e+02,
content:'Saddle = 1456.699951 pos = 36.1517,138.1873 diff = 214.800049'
});
data_peak.push({
lat: 3.6151333338e+01,
lng: 1.3821933333e+02,
cert : false,
content:' Peak = 1657.199951 pos = 36.1513,138.2193 diff = 176.299927'
});
data_saddle.push({
lat: 3.6153222227e+01,
lng: 1.3820966667e+02,
content:'Saddle = 1480.900024 pos = 36.1532,138.2097 diff = 176.299927'
});
data_peak.push({
lat: 3.6163111115e+01,
lng: 1.3805911111e+02,
cert : true,
content:'Name = Hachibuseyama(JA/NN-075) peak = 1928.300049 pos = 36.1631,138.0591 diff = 415.800049'
});
data_saddle.push({
lat: 3.6163111115e+01,
lng: 1.3810000000e+02,
content:'Saddle = 1512.500000 pos = 36.1631,138.1000 diff = 415.800049'
});
data_peak.push({
lat: 3.6103000005e+01,
lng: 1.3819655556e+02,
cert : true,
content:'Name = Kirigamine (Kurumayama)(JA/NN-076) peak = 1924.699951 pos = 36.1030,138.1966 diff = 408.299927'
});
data_saddle.push({
lat: 3.6145222227e+01,
lng: 1.3814388889e+02,
content:'Saddle = 1516.400024 pos = 36.1452,138.1439 diff = 408.299927'
});
data_peak.push({
lat: 3.6130111116e+01,
lng: 1.3815433333e+02,
cert : true,
content:'Name = JA/NN-089(JA/NN-089) peak = 1794.300049 pos = 36.1301,138.1543 diff = 161.800049'
});
data_saddle.push({
lat: 3.6122000005e+01,
lng: 1.3816500000e+02,
content:'Saddle = 1632.500000 pos = 36.1220,138.1650 diff = 161.800049'
});
data_peak.push({
lat: 3.6166444449e+01,
lng: 1.3812800000e+02,
cert : true,
content:'Name = JA/NN-080(JA/NN-080) peak = 1883.300049 pos = 36.1664,138.1280 diff = 279.300049'
});
data_saddle.push({
lat: 3.6181111115e+01,
lng: 1.3812788889e+02,
content:'Saddle = 1604.000000 pos = 36.1811,138.1279 diff = 279.300049'
});
data_peak.push({
lat: 3.6103777782e+01,
lng: 1.3829500000e+02,
cert : true,
content:'Name = Tateshinayama(JA/NN-031) peak = 2530.300049 pos = 36.1038,138.2950 diff = 443.300049'
});
data_saddle.push({
lat: 3.6112000005e+01,
lng: 1.3831922222e+02,
content:'Saddle = 2087.000000 pos = 36.1120,138.3192 diff = 443.300049'
});
data_peak.push({
lat: 3.6087555560e+01,
lng: 1.3832000000e+02,
cert : true,
content:'Name = Yokodake(JA/NN-032) peak = 2481.899902 pos = 36.0876,138.3200 diff = 362.799805'
});
data_saddle.push({
lat: 3.6059555560e+01,
lng: 1.3834677778e+02,
content:'Saddle = 2119.100098 pos = 36.0596,138.3468 diff = 362.799805'
});
data_peak.push({
lat: 3.6075333338e+01,
lng: 1.3833144444e+02,
cert : true,
content:'Name = Shimagareyama(JA/NN-037) peak = 2402.399902 pos = 36.0753,138.3314 diff = 153.599854'
});
data_saddle.push({
lat: 3.6079333338e+01,
lng: 1.3832600000e+02,
content:'Saddle = 2248.800049 pos = 36.0793,138.3260 diff = 153.599854'
});
data_peak.push({
lat: 3.6019222227e+01,
lng: 1.3835544444e+02,
cert : true,
content:'Name = Tengudake(JA/NN-024) peak = 2644.699951 pos = 36.0192,138.3554 diff = 212.099854'
});
data_saddle.push({
lat: 3.6006444449e+01,
lng: 1.3836477778e+02,
content:'Saddle = 2432.600098 pos = 36.0064,138.3648 diff = 212.099854'
});
data_peak.push({
lat: 3.6096777782e+01,
lng: 1.3727811111e+02,
cert : true,
content:'Name = JA/GF-117(JA/GF-117) peak = 1052.199951 pos = 36.0968,137.2781 diff = 185.199951'
});
data_saddle.push({
lat: 3.6105222227e+01,
lng: 1.3731722222e+02,
content:'Saddle = 867.000000 pos = 36.1052,137.3172 diff = 185.199951'
});
data_peak.push({
lat: 3.6323333337e+01,
lng: 1.3723577778e+02,
cert : true,
content:'Name = JA/GF-049(JA/GF-049) peak = 1422.599976 pos = 36.3233,137.2358 diff = 542.799988'
});
data_saddle.push({
lat: 3.6265333337e+01,
lng: 1.3722166667e+02,
content:'Saddle = 879.799988 pos = 36.2653,137.2217 diff = 542.799988'
});
data_peak.push({
lat: 3.6278888893e+01,
lng: 1.3719244444e+02,
cert : false,
content:' Peak = 1142.000000 pos = 36.2789,137.1924 diff = 243.900024'
});
data_saddle.push({
lat: 3.6302111115e+01,
lng: 1.3722166667e+02,
content:'Saddle = 898.099976 pos = 36.3021,137.2217 diff = 243.900024'
});
data_peak.push({
lat: 3.6368888892e+01,
lng: 1.3722366667e+02,
cert : true,
content:'Name = JA/GF-089(JA/GF-089) peak = 1221.699951 pos = 36.3689,137.2237 diff = 229.799927'
});
data_saddle.push({
lat: 3.6363888892e+01,
lng: 1.3723444444e+02,
content:'Saddle = 991.900024 pos = 36.3639,137.2344 diff = 229.799927'
});
data_peak.push({
lat: 3.6401444448e+01,
lng: 1.3725800000e+02,
cert : true,
content:'Name = JA/GF-054(JA/GF-054) peak = 1392.599976 pos = 36.4014,137.2580 diff = 270.500000'
});
data_saddle.push({
lat: 3.6363555559e+01,
lng: 1.3724233333e+02,
content:'Saddle = 1122.099976 pos = 36.3636,137.2423 diff = 270.500000'
});
data_peak.push({
lat: 3.6308222226e+01,
lng: 1.3717544444e+02,
cert : true,
content:'Name = JA/GF-067(JA/GF-067) peak = 1334.699951 pos = 36.3082,137.1754 diff = 187.899902'
});
data_saddle.push({
lat: 3.6310222226e+01,
lng: 1.3720677778e+02,
content:'Saddle = 1146.800049 pos = 36.3102,137.2068 diff = 187.899902'
});
data_peak.push({
lat: 3.6337888893e+01,
lng: 1.3726800000e+02,
cert : false,
content:' Peak = 1350.400024 pos = 36.3379,137.2680 diff = 170.099976'
});
data_saddle.push({
lat: 3.6328555559e+01,
lng: 1.3725344444e+02,
content:'Saddle = 1180.300049 pos = 36.3286,137.2534 diff = 170.099976'
});
data_peak.push({
lat: 3.6831666668e+01,
lng: 1.3764733333e+02,
cert : true,
content:'Name = JA/TY-032(JA/TY-032) peak = 1395.599976 pos = 36.8317,137.6473 diff = 513.399963'
});
data_saddle.push({
lat: 3.6854666668e+01,
lng: 1.3765611111e+02,
content:'Saddle = 882.200012 pos = 36.8547,137.6561 diff = 513.399963'
});
data_peak.push({
lat: 3.6801111113e+01,
lng: 1.3763544444e+02,
cert : false,
content:' Peak = 1351.500000 pos = 36.8011,137.6354 diff = 176.199951'
});
data_saddle.push({
lat: 3.6808777780e+01,
lng: 1.3763866667e+02,
content:'Saddle = 1175.300049 pos = 36.8088,137.6387 diff = 176.199951'
});
data_peak.push({
lat: 3.6976666668e+01,
lng: 1.3779000000e+02,
cert : true,
content:'Name = Kurohimeyama(JA/NI-040) peak = 1221.099976 pos = 36.9767,137.7900 diff = 299.899963'
});
data_saddle.push({
lat: 3.6964777779e+01,
lng: 1.3779044444e+02,
content:'Saddle = 921.200012 pos = 36.9648,137.7904 diff = 299.899963'
});
data_peak.push({
lat: 3.6442777781e+01,
lng: 1.3781822222e+02,
cert : true,
content:'Name = JA/NN-178(JA/NN-178) peak = 1092.400024 pos = 36.4428,137.8182 diff = 170.200012'
});
data_saddle.push({
lat: 3.6441000003e+01,
lng: 1.3781477778e+02,
content:'Saddle = 922.200012 pos = 36.4410,137.8148 diff = 170.200012'
});
data_peak.push({
lat: 3.6940888890e+01,
lng: 1.3782177778e+02,
cert : false,
content:' Peak = 1186.400024 pos = 36.9409,137.8218 diff = 262.700012'
});
data_saddle.push({
lat: 3.6947555557e+01,
lng: 1.3781288889e+02,
content:'Saddle = 923.700012 pos = 36.9476,137.8129 diff = 262.700012'
});
data_peak.push({
lat: 3.6283222226e+01,
lng: 1.3727477778e+02,
cert : false,
content:' Peak = 1144.000000 pos = 36.2832,137.2748 diff = 219.500000'
});
data_saddle.push({
lat: 3.6276000004e+01,
lng: 1.3726900000e+02,
content:'Saddle = 924.500000 pos = 36.2760,137.2690 diff = 219.500000'
});
data_peak.push({
lat: 3.6019555560e+01,
lng: 1.3735022222e+02,
cert : true,
content:'Name = JA/GF-040(JA/GF-040) peak = 1484.099976 pos = 36.0196,137.3502 diff = 517.699951'
});
data_saddle.push({
lat: 3.6000111116e+01,
lng: 1.3739166667e+02,
content:'Saddle = 966.400024 pos = 36.0001,137.3917 diff = 517.699951'
});
data_peak.push({
lat: 3.6000444449e+01,
lng: 1.3738388889e+02,
cert : false,
content:' Peak = 1226.500000 pos = 36.0004,137.3839 diff = 203.400024'
});
data_saddle.push({
lat: 3.6000111116e+01,
lng: 1.3736900000e+02,
content:'Saddle = 1023.099976 pos = 36.0001,137.3690 diff = 203.400024'
});
data_peak.push({
lat: 3.6064444449e+01,
lng: 1.3733655556e+02,
cert : false,
content:' Peak = 1314.699951 pos = 36.0644,137.3366 diff = 157.799927'
});
data_saddle.push({
lat: 3.6061555560e+01,
lng: 1.3734677778e+02,
content:'Saddle = 1156.900024 pos = 36.0616,137.3468 diff = 157.799927'
});
data_peak.push({
lat: 3.6044222227e+01,
lng: 1.3735255556e+02,
cert : true,
content:'Name = JA/GF-048(JA/GF-048) peak = 1432.199951 pos = 36.0442,137.3526 diff = 224.099976'
});
data_saddle.push({
lat: 3.6037888894e+01,
lng: 1.3736577778e+02,
content:'Saddle = 1208.099976 pos = 36.0379,137.3658 diff = 224.099976'
});
data_peak.push({
lat: 3.6463666670e+01,
lng: 1.3730855556e+02,
cert : true,
content:'Name = JA/GF-053(JA/GF-053) peak = 1391.199951 pos = 36.4637,137.3086 diff = 322.699951'
});
data_saddle.push({
lat: 3.6452777781e+01,
lng: 1.3731722222e+02,
content:'Saddle = 1068.500000 pos = 36.4528,137.3172 diff = 322.699951'
});
data_peak.push({
lat: 3.6253444448e+01,
lng: 1.3729844444e+02,
cert : true,
content:'Name = Ooamamiyama(JA/GF-068) peak = 1335.800049 pos = 36.2534,137.2984 diff = 263.300049'
});
data_saddle.push({
lat: 3.6226333337e+01,
lng: 1.3737744444e+02,
content:'Saddle = 1072.500000 pos = 36.2263,137.3774 diff = 263.300049'
});
data_peak.push({
lat: 3.6251444448e+01,
lng: 1.3736266667e+02,
cert : true,
content:'Name = JA/GF-071(JA/GF-071) peak = 1316.699951 pos = 36.2514,137.3627 diff = 185.699951'
});
data_saddle.push({
lat: 3.6251222226e+01,
lng: 1.3733533333e+02,
content:'Saddle = 1131.000000 pos = 36.2512,137.3353 diff = 185.699951'
});
data_peak.push({
lat: 3.6944444446e+01,
lng: 1.3771100000e+02,
cert : true,
content:'Name = Shiratoriyama(JA/NI-038) peak = 1285.800049 pos = 36.9444,137.7110 diff = 194.400024'
});
data_saddle.push({
lat: 3.6937777779e+01,
lng: 1.3771366667e+02,
content:'Saddle = 1091.400024 pos = 36.9378,137.7137 diff = 194.400024'
});
data_peak.push({
lat: 3.6010000005e+01,
lng: 1.3745633333e+02,
cert : false,
content:' Peak = 1594.199951 pos = 36.0100,137.4563 diff = 469.699951'
});
data_saddle.push({
lat: 3.6000222227e+01,
lng: 1.3751455556e+02,
content:'Saddle = 1124.500000 pos = 36.0002,137.5146 diff = 469.699951'
});
data_peak.push({
lat: 3.6063666671e+01,
lng: 1.3741611111e+02,
cert : false,
content:' Peak = 1414.099976 pos = 36.0637,137.4161 diff = 282.299927'
});
data_saddle.push({
lat: 3.6052888894e+01,
lng: 1.3742155556e+02,
content:'Saddle = 1131.800049 pos = 36.0529,137.4216 diff = 282.299927'
});
data_peak.push({
lat: 3.6049444449e+01,
lng: 1.3740855556e+02,
cert : false,
content:' Peak = 1322.699951 pos = 36.0494,137.4086 diff = 180.299927'
});
data_saddle.push({
lat: 3.6041111116e+01,
lng: 1.3740900000e+02,
content:'Saddle = 1142.400024 pos = 36.0411,137.4090 diff = 180.299927'
});
data_peak.push({
lat: 3.6005777783e+01,
lng: 1.3749855556e+02,
cert : false,
content:' Peak = 1490.400024 pos = 36.0058,137.4986 diff = 308.800049'
});
data_saddle.push({
lat: 3.6000111116e+01,
lng: 1.3747588889e+02,
content:'Saddle = 1181.599976 pos = 36.0001,137.4759 diff = 308.800049'
});
data_peak.push({
lat: 3.6602444447e+01,
lng: 1.3745200000e+02,
cert : false,
content:' Peak = 1360.599976 pos = 36.6024,137.4520 diff = 232.599976'
});
data_saddle.push({
lat: 3.6608000003e+01,
lng: 1.3747888889e+02,
content:'Saddle = 1128.000000 pos = 36.6080,137.4789 diff = 232.599976'
});
data_peak.push({
lat: 3.6592888892e+01,
lng: 1.3781955556e+02,
cert : true,
content:'Name = JA/NN-146(JA/NN-146) peak = 1336.400024 pos = 36.5929,137.8196 diff = 207.500000'
});
data_saddle.push({
lat: 3.6597111114e+01,
lng: 1.3782566667e+02,
content:'Saddle = 1128.900024 pos = 36.5971,137.8257 diff = 207.500000'
});
data_peak.push({
lat: 3.6427000003e+01,
lng: 1.3731100000e+02,
cert : true,
content:'Name = Ikenoyama(JA/GF-059) peak = 1366.300049 pos = 36.4270,137.3110 diff = 229.700073'
});
data_saddle.push({
lat: 3.6430444448e+01,
lng: 1.3732877778e+02,
content:'Saddle = 1136.599976 pos = 36.4304,137.3288 diff = 229.700073'
});
data_peak.push({
lat: 3.6433333337e+01,
lng: 1.3734022222e+02,
cert : true,
content:'Name = JA/GF-070(JA/GF-070) peak = 1332.000000 pos = 36.4333,137.3402 diff = 178.599976'
});
data_saddle.push({
lat: 3.6433111114e+01,
lng: 1.3734977778e+02,
content:'Saddle = 1153.400024 pos = 36.4331,137.3498 diff = 178.599976'
});
data_peak.push({
lat: 3.6113000005e+01,
lng: 1.3737633333e+02,
cert : false,
content:' Peak = 1315.199951 pos = 36.1130,137.3763 diff = 158.500000'
});
data_saddle.push({
lat: 3.6115888893e+01,
lng: 1.3738422222e+02,
content:'Saddle = 1156.699951 pos = 36.1159,137.3842 diff = 158.500000'
});
data_peak.push({
lat: 3.6491777781e+01,
lng: 1.3776122222e+02,
cert : false,
content:' Peak = 1353.900024 pos = 36.4918,137.7612 diff = 196.000000'
});
data_saddle.push({
lat: 3.6487777781e+01,
lng: 1.3776077778e+02,
content:'Saddle = 1157.900024 pos = 36.4878,137.7608 diff = 196.000000'
});
data_peak.push({
lat: 3.6037888894e+01,
lng: 1.3746566667e+02,
cert : false,
content:' Peak = 1343.400024 pos = 36.0379,137.4657 diff = 165.599976'
});
data_saddle.push({
lat: 3.6043111116e+01,
lng: 1.3747433333e+02,
content:'Saddle = 1177.800049 pos = 36.0431,137.4743 diff = 165.599976'
});
data_peak.push({
lat: 3.6350333337e+01,
lng: 1.3736244444e+02,
cert : true,
content:'Name = JA/GF-037(JA/GF-037) peak = 1522.000000 pos = 36.3503,137.3624 diff = 333.699951'
});
data_saddle.push({
lat: 3.6343000004e+01,
lng: 1.3739588889e+02,
content:'Saddle = 1188.300049 pos = 36.3430,137.3959 diff = 333.699951'
});
data_peak.push({
lat: 3.6759666669e+01,
lng: 1.3761011111e+02,
cert : false,
content:' Peak = 1394.099976 pos = 36.7597,137.6101 diff = 183.199951'
});
data_saddle.push({
lat: 3.6758000002e+01,
lng: 1.3760611111e+02,
content:'Saddle = 1210.900024 pos = 36.7580,137.6061 diff = 183.199951'
});
data_peak.push({
lat: 3.6689777780e+01,
lng: 1.3750455556e+02,
cert : false,
content:' Peak = 1444.300049 pos = 36.6898,137.5046 diff = 206.700073'
});
data_saddle.push({
lat: 3.6679777780e+01,
lng: 1.3753011111e+02,
content:'Saddle = 1237.599976 pos = 36.6798,137.5301 diff = 206.700073'
});
data_peak.push({
lat: 3.6111777782e+01,
lng: 1.3739955556e+02,
cert : false,
content:' Peak = 1402.099976 pos = 36.1118,137.3996 diff = 160.599976'
});
data_saddle.push({
lat: 3.6125111116e+01,
lng: 1.3740833333e+02,
content:'Saddle = 1241.500000 pos = 36.1251,137.4083 diff = 160.599976'
});
data_peak.push({
lat: 3.6304000004e+01,
lng: 1.3742344444e+02,
cert : true,
content:'Name = JA/GF-046(JA/GF-046) peak = 1442.400024 pos = 36.3040,137.4234 diff = 180.800049'
});
data_saddle.push({
lat: 3.6303111115e+01,
lng: 1.3743822222e+02,
content:'Saddle = 1261.599976 pos = 36.3031,137.4382 diff = 180.800049'
});
data_peak.push({
lat: 3.6896666668e+01,
lng: 1.3768788889e+02,
cert : true,
content:'Name = Hatsuyukiyama(JA/TY-027) peak = 1610.699951 pos = 36.8967,137.6879 diff = 339.699951'
});
data_saddle.push({
lat: 3.6907888890e+01,
lng: 1.3770644444e+02,
content:'Saddle = 1271.000000 pos = 36.9079,137.7064 diff = 339.699951'
});
data_peak.push({
lat: 3.6514666670e+01,
lng: 1.3742677778e+02,
cert : true,
content:'Name = Hachibuseyama(JA/TY-023) peak = 1782.099976 pos = 36.5147,137.4268 diff = 483.699951'
});
data_saddle.push({
lat: 3.6448000003e+01,
lng: 1.3739488889e+02,
content:'Saddle = 1298.400024 pos = 36.4480,137.3949 diff = 483.699951'
});
data_peak.push({
lat: 3.6470444448e+01,
lng: 1.3740622222e+02,
cert : true,
content:'Name = JA/TY-024(JA/TY-024) peak = 1698.000000 pos = 36.4704,137.4062 diff = 220.400024'
});
data_saddle.push({
lat: 3.6490000003e+01,
lng: 1.3741177778e+02,
content:'Saddle = 1477.599976 pos = 36.4900,137.4118 diff = 220.400024'
});
data_peak.push({
lat: 3.6486111114e+01,
lng: 1.3737788889e+02,
cert : true,
content:'Name = Nishikasayama(JA/TY-025) peak = 1697.400024 pos = 36.4861,137.3779 diff = 199.599976'
});
data_saddle.push({
lat: 3.6475000003e+01,
lng: 1.3738088889e+02,
content:'Saddle = 1497.800049 pos = 36.4750,137.3809 diff = 199.599976'
});
data_peak.push({
lat: 3.6497555559e+01,
lng: 1.3741166667e+02,
cert : false,
content:' Peak = 1687.099976 pos = 36.4976,137.4117 diff = 208.799927'
});
data_saddle.push({
lat: 3.6497555559e+01,
lng: 1.3742288889e+02,
content:'Saddle = 1478.300049 pos = 36.4976,137.4229 diff = 208.799927'
});
data_peak.push({
lat: 3.6130222227e+01,
lng: 1.3768800000e+02,
cert : false,
content:' Peak = 1572.900024 pos = 36.1302,137.6880 diff = 239.599976'
});
data_saddle.push({
lat: 3.6124111116e+01,
lng: 1.3768244444e+02,
content:'Saddle = 1333.300049 pos = 36.1241,137.6824 diff = 239.599976'
});
data_peak.push({
lat: 3.6484888892e+01,
lng: 1.3779488889e+02,
cert : true,
content:'Name = JA/NN-114(JA/NN-114) peak = 1622.699951 pos = 36.4849,137.7949 diff = 286.899902'
});
data_saddle.push({
lat: 3.6482777781e+01,
lng: 1.3778166667e+02,
content:'Saddle = 1335.800049 pos = 36.4828,137.7817 diff = 286.899902'
});
data_peak.push({
lat: 3.6036555560e+01,
lng: 1.3751000000e+02,
cert : true,
content:'Name = JA/GF-033(JA/GF-033) peak = 1591.800049 pos = 36.0366,137.5100 diff = 239.800049'
});
data_saddle.push({
lat: 3.6044666671e+01,
lng: 1.3751888889e+02,
content:'Saddle = 1352.000000 pos = 36.0447,137.5189 diff = 239.800049'
});
data_peak.push({
lat: 3.6540222225e+01,
lng: 1.3747800000e+02,
cert : true,
content:'Name = Kuwasakiyama(JA/TY-018) peak = 2084.399902 pos = 36.5402,137.4780 diff = 692.299927'
});
data_saddle.push({
lat: 3.6488888892e+01,
lng: 1.3747466667e+02,
content:'Saddle = 1392.099976 pos = 36.4889,137.4747 diff = 692.299927'
});
data_peak.push({
lat: 3.6351111115e+01,
lng: 1.3741833333e+02,
cert : true,
content:'Name = JA/GF-021(JA/GF-021) peak = 1726.900024 pos = 36.3511,137.4183 diff = 255.400024'
});
data_saddle.push({
lat: 3.6371666670e+01,
lng: 1.3742900000e+02,
content:'Saddle = 1471.500000 pos = 36.3717,137.4290 diff = 255.400024'
});
data_peak.push({
lat: 3.6086666671e+01,
lng: 1.3775477778e+02,
cert : false,
content:' Peak = 2445.600098 pos = 36.0867,137.7548 diff = 959.100098'
});
data_saddle.push({
lat: 3.6025444449e+01,
lng: 1.3771966667e+02,
content:'Saddle = 1486.500000 pos = 36.0254,137.7197 diff = 959.100098'
});
data_peak.push({
lat: 3.6016444449e+01,
lng: 1.3779044444e+02,
cert : true,
content:'Name = JA/NN-090(JA/NN-090) peak = 1783.000000 pos = 36.0164,137.7904 diff = 209.800049'
});
data_saddle.push({
lat: 3.6033000005e+01,
lng: 1.3781111111e+02,
content:'Saddle = 1573.199951 pos = 36.0330,137.8111 diff = 209.800049'
});
data_peak.push({
lat: 3.6073222227e+01,
lng: 1.3778200000e+02,
cert : false,
content:' Peak = 2021.199951 pos = 36.0732,137.7820 diff = 159.299927'
});
data_saddle.push({
lat: 3.6077888894e+01,
lng: 1.3777322222e+02,
content:'Saddle = 1861.900024 pos = 36.0779,137.7732 diff = 159.299927'
});
data_peak.push({
lat: 3.6071000005e+01,
lng: 1.3773733333e+02,
cert : false,
content:' Peak = 2371.000000 pos = 36.0710,137.7373 diff = 173.600098'
});
data_saddle.push({
lat: 3.6076555560e+01,
lng: 1.3774433333e+02,
content:'Saddle = 2197.399902 pos = 36.0766,137.7443 diff = 173.600098'
});
data_peak.push({
lat: 3.6420000003e+01,
lng: 1.3742700000e+02,
cert : true,
content:'Name = JA/GF-020(JA/GF-020) peak = 1730.500000 pos = 36.4200,137.4270 diff = 188.300049'
});
data_saddle.push({
lat: 3.6417666670e+01,
lng: 1.3743822222e+02,
content:'Saddle = 1542.199951 pos = 36.4177,137.4382 diff = 188.300049'
});
data_peak.push({
lat: 3.6398111115e+01,
lng: 1.3745644444e+02,
cert : true,
content:'Name = JA/GF-017(JA/GF-017) peak = 1792.800049 pos = 36.3981,137.4564 diff = 229.600098'
});
data_saddle.push({
lat: 3.6406000003e+01,
lng: 1.3744811111e+02,
content:'Saddle = 1563.199951 pos = 36.4060,137.4481 diff = 229.600098'
});
data_peak.push({
lat: 3.6338777781e+01,
lng: 1.3747744444e+02,
cert : true,
content:'Name = JA/GF-012(JA/GF-012) peak = 2005.699951 pos = 36.3388,137.4774 diff = 364.399902'
});
data_saddle.push({
lat: 3.6332444448e+01,
lng: 1.3749800000e+02,
content:'Saddle = 1641.300049 pos = 36.3324,137.4980 diff = 364.399902'
});
data_peak.push({
lat: 3.6058666671e+01,
lng: 1.3766677778e+02,
cert : true,
content:'Name = JA/NN-088(JA/NN-088) peak = 1811.400024 pos = 36.0587,137.6668 diff = 159.200073'
});
data_saddle.push({
lat: 3.6054888894e+01,
lng: 1.3762177778e+02,
content:'Saddle = 1652.199951 pos = 36.0549,137.6218 diff = 159.200073'
});
data_peak.push({
lat: 3.6026666672e+01,
lng: 1.3759900000e+02,
cert : true,
content:'Name = Kamagamine(JA/NN-057) peak = 2120.699951 pos = 36.0267,137.5990 diff = 449.799927'
});
data_saddle.push({
lat: 3.6052555560e+01,
lng: 1.3760544444e+02,
content:'Saddle = 1670.900024 pos = 36.0526,137.6054 diff = 449.799927'
});
data_peak.push({
lat: 3.6014888894e+01,
lng: 1.3767800000e+02,
cert : false,
content:' Peak = 2032.199951 pos = 36.0149,137.6780 diff = 340.199951'
});
data_saddle.push({
lat: 3.6024444449e+01,
lng: 1.3763833333e+02,
content:'Saddle = 1692.000000 pos = 36.0244,137.6383 diff = 340.199951'
});
data_peak.push({
lat: 3.6020666672e+01,
lng: 1.3765155556e+02,
cert : false,
content:' Peak = 1936.000000 pos = 36.0207,137.6516 diff = 167.000000'
});
data_saddle.push({
lat: 3.6016222227e+01,
lng: 1.3765544444e+02,
content:'Saddle = 1769.000000 pos = 36.0162,137.6554 diff = 167.000000'
});
data_peak.push({
lat: 3.6725888891e+01,
lng: 1.3767755556e+02,
cert : true,
content:'Name = Hyakukanyama(JA/TY-021) peak = 1961.300049 pos = 36.7259,137.6776 diff = 280.900024'
});
data_saddle.push({
lat: 3.6729888891e+01,
lng: 1.3768744444e+02,
content:'Saddle = 1680.400024 pos = 36.7299,137.6874 diff = 280.900024'
});
data_peak.push({
lat: 3.6194111115e+01,
lng: 1.3752200000e+02,
cert : true,
content:'Name = Terashiyama(JA/GF-011) peak = 2062.300049 pos = 36.1941,137.5220 diff = 381.300049'
});
data_saddle.push({
lat: 3.6180555560e+01,
lng: 1.3753011111e+02,
content:'Saddle = 1681.000000 pos = 36.1806,137.5301 diff = 381.300049'
});
data_peak.push({
lat: 3.6752000002e+01,
lng: 1.3758433333e+02,
cert : true,
content:'Name = Ecchuukomagatake(JA/TY-020) peak = 2001.099976 pos = 36.7520,137.5843 diff = 298.799927'
});
data_saddle.push({
lat: 3.6739333335e+01,
lng: 1.3759022222e+02,
content:'Saddle = 1702.300049 pos = 36.7393,137.5902 diff = 298.799927'
});
data_peak.push({
lat: 3.6243222226e+01,
lng: 1.3778788889e+02,
cert : true,
content:'Name = JA/NN-063(JA/NN-063) peak = 2052.000000 pos = 36.2432,137.7879 diff = 330.099976'
});
data_saddle.push({
lat: 3.6272111115e+01,
lng: 1.3779522222e+02,
content:'Saddle = 1721.900024 pos = 36.2721,137.7952 diff = 330.099976'
});
data_peak.push({
lat: 3.6689555558e+01,
lng: 1.3758588889e+02,
cert : true,
content:'Name = Kekachisanzan(JA/TY-014) peak = 2411.899902 pos = 36.6896,137.5859 diff = 664.699951'
});
data_saddle.push({
lat: 3.6670888891e+01,
lng: 1.3760122222e+02,
content:'Saddle = 1747.199951 pos = 36.6709,137.6012 diff = 664.699951'
});
data_peak.push({
lat: 3.6723888891e+01,
lng: 1.3761111111e+02,
cert : true,
content:'Name = Sannabikiyama  (Takikurayama)(JA/TY-019) peak = 2026.500000 pos = 36.7239,137.6111 diff = 279.199951'
});
data_saddle.push({
lat: 3.6711666669e+01,
lng: 1.3760344444e+02,
content:'Saddle = 1747.300049 pos = 36.7117,137.6034 diff = 279.199951'
});
data_peak.push({
lat: 3.6106555560e+01,
lng: 1.3755355556e+02,
cert : true,
content:'Name = Norikuradake (Kengamine)(JA/GF-001) peak = 3024.300049 pos = 36.1066,137.5536 diff = 1226.000000'
});
data_saddle.push({
lat: 3.6194222226e+01,
lng: 1.3758377778e+02,
content:'Saddle = 1798.300049 pos = 36.1942,137.5838 diff = 1226.000000'
});
data_peak.push({
lat: 3.6190666671e+01,
lng: 1.3759511111e+02,
cert : false,
content:' Peak = 2221.300049 pos = 36.1907,137.5951 diff = 160.100098'
});
data_saddle.push({
lat: 3.6186333338e+01,
lng: 1.3759133333e+02,
content:'Saddle = 2061.199951 pos = 36.1863,137.5913 diff = 160.100098'
});
data_peak.push({
lat: 3.6160000004e+01,
lng: 1.3758044444e+02,
cert : true,
content:'Name = JA/NN-030(JA/NN-030) peak = 2531.300049 pos = 36.1600,137.5804 diff = 219.400146'
});
data_saddle.push({
lat: 3.6157222227e+01,
lng: 1.3757377778e+02,
content:'Saddle = 2311.899902 pos = 36.1572,137.5738 diff = 219.400146'
});
data_peak.push({
lat: 3.6147111116e+01,
lng: 1.3755288889e+02,
cert : true,
content:'Name = JA/GF-006(JA/GF-006) peak = 2751.000000 pos = 36.1471,137.5529 diff = 173.300049'
});
data_saddle.push({
lat: 3.6142555560e+01,
lng: 1.3755111111e+02,
content:'Saddle = 2577.699951 pos = 36.1426,137.5511 diff = 173.300049'
});
data_peak.push({
lat: 3.6681111113e+01,
lng: 1.3771844444e+02,
cert : true,
content:'Name = Gakiyama(JA/TY-017) peak = 2126.899902 pos = 36.6811,137.7184 diff = 254.699951'
});
data_saddle.push({
lat: 3.6676666669e+01,
lng: 1.3772811111e+02,
content:'Saddle = 1872.199951 pos = 36.6767,137.7281 diff = 254.699951'
});
data_peak.push({
lat: 3.6210666671e+01,
lng: 1.3757322222e+02,
cert : true,
content:'Name = JA/NN-054(JA/NN-054) peak = 2185.500000 pos = 36.2107,137.5732 diff = 278.000000'
});
data_saddle.push({
lat: 3.6218444449e+01,
lng: 1.3757344444e+02,
content:'Saddle = 1907.500000 pos = 36.2184,137.5734 diff = 278.000000'
});
data_peak.push({
lat: 3.6272555559e+01,
lng: 1.3754211111e+02,
cert : true,
content:'Name = JA/GF-009(JA/GF-009) peak = 2230.699951 pos = 36.2726,137.5421 diff = 237.099976'
});
data_saddle.push({
lat: 3.6278333337e+01,
lng: 1.3754633333e+02,
content:'Saddle = 1993.599976 pos = 36.2783,137.5463 diff = 237.099976'
});
data_peak.push({
lat: 3.6611888891e+01,
lng: 1.3766100000e+02,
cert : true,
content:'Name = Kurobebetsusan(JA/TY-016) peak = 2352.500000 pos = 36.6119,137.6610 diff = 342.000000'
});
data_saddle.push({
lat: 3.6606777780e+01,
lng: 1.3765244444e+02,
content:'Saddle = 2010.500000 pos = 36.6068,137.6524 diff = 342.000000'
});
data_peak.push({
lat: 3.6826777779e+01,
lng: 1.3772977778e+02,
cert : true,
content:'Name = Asahidake(JA/TY-013) peak = 2417.100098 pos = 36.8268,137.7298 diff = 383.800049'
});
data_saddle.push({
lat: 3.6819000002e+01,
lng: 1.3773866667e+02,
content:'Saddle = 2033.300049 pos = 36.8190,137.7387 diff = 383.800049'
});
data_peak.push({
lat: 3.6640444447e+01,
lng: 1.3764488889e+02,
cert : false,
content:' Peak = 2212.500000 pos = 36.6404,137.6449 diff = 170.500000'
});
data_saddle.push({
lat: 3.6639111114e+01,
lng: 1.3763988889e+02,
content:'Saddle = 2042.000000 pos = 36.6391,137.6399 diff = 170.500000'
});
data_peak.push({
lat: 3.6395666670e+01,
lng: 1.3776222222e+02,
cert : true,
content:'Name = JA/NN-048(JA/NN-048) peak = 2281.899902 pos = 36.3957,137.7622 diff = 198.899902'
});
data_saddle.push({
lat: 3.6406777781e+01,
lng: 1.3775266667e+02,
content:'Saddle = 2083.000000 pos = 36.4068,137.7527 diff = 198.899902'
});
data_peak.push({
lat: 3.6226888893e+01,
lng: 1.3758733333e+02,
cert : false,
content:' Peak = 2452.800049 pos = 36.2269,137.5873 diff = 365.800049'
});
data_saddle.push({
lat: 3.6236333337e+01,
lng: 1.3759388889e+02,
content:'Saddle = 2087.000000 pos = 36.2363,137.5939 diff = 365.800049'
});
data_peak.push({
lat: 3.6207666671e+01,
lng: 1.3771166667e+02,
cert : true,
content:'Name = JA/NN-038(JA/NN-038) peak = 2387.199951 pos = 36.2077,137.7117 diff = 259.500000'
});
data_saddle.push({
lat: 3.6212222226e+01,
lng: 1.3768866667e+02,
content:'Saddle = 2127.699951 pos = 36.2122,137.6887 diff = 259.500000'
});
data_peak.push({
lat: 3.6221222226e+01,
lng: 1.3764055556e+02,
cert : true,
content:'Name = Kasumizawadake(JA/NN-025) peak = 2643.800049 pos = 36.2212,137.6406 diff = 513.400146'
});
data_saddle.push({
lat: 3.6226222226e+01,
lng: 1.3767611111e+02,
content:'Saddle = 2130.399902 pos = 36.2262,137.6761 diff = 513.400146'
});
data_peak.push({
lat: 3.6222666671e+01,
lng: 1.3767033333e+02,
cert : false,
content:' Peak = 2427.199951 pos = 36.2227,137.6703 diff = 166.500000'
});
data_saddle.push({
lat: 3.6225444449e+01,
lng: 1.3766111111e+02,
content:'Saddle = 2260.699951 pos = 36.2254,137.6611 diff = 166.500000'
});
data_peak.push({
lat: 3.6576000003e+01,
lng: 1.3761966667e+02,
cert : true,
content:'Name = Tateyama(JA/TY-001) peak = 3012.500000 pos = 36.5760,137.6197 diff = 865.800049'
});
data_saddle.push({
lat: 3.6505555559e+01,
lng: 1.3757488889e+02,
content:'Saddle = 2146.699951 pos = 36.5056,137.5749 diff = 865.800049'
});
data_peak.push({
lat: 3.6650333336e+01,
lng: 1.3762077778e+02,
cert : true,
content:'Name = Shirohage(JA/TY-015) peak = 2382.699951 pos = 36.6503,137.6208 diff = 204.800049'
});
data_saddle.push({
lat: 3.6646888891e+01,
lng: 1.3762244444e+02,
content:'Saddle = 2177.899902 pos = 36.6469,137.6224 diff = 204.800049'
});
data_peak.push({
lat: 3.6641444447e+01,
lng: 1.3762533333e+02,
cert : false,
content:' Peak = 2560.100098 pos = 36.6414,137.6253 diff = 219.800049'
});
data_saddle.push({
lat: 3.6636333336e+01,
lng: 1.3762355556e+02,
content:'Saddle = 2340.300049 pos = 36.6363,137.6236 diff = 219.800049'
});
data_peak.push({
lat: 3.6541888892e+01,
lng: 1.3758711111e+02,
cert : true,
content:'Name = Washidake(JA/TY-010) peak = 2615.600098 pos = 36.5419,137.5871 diff = 273.900146'
});
data_saddle.push({
lat: 3.6548000003e+01,
lng: 1.3759977778e+02,
content:'Saddle = 2341.699951 pos = 36.5480,137.5998 diff = 273.900146'
});
data_peak.push({
lat: 3.6515111114e+01,
lng: 1.3758288889e+02,
cert : true,
content:'Name = Ecchuuzawadake(JA/TY-012) peak = 2591.500000 pos = 36.5151,137.5829 diff = 239.699951'
});
data_saddle.push({
lat: 3.6526000003e+01,
lng: 1.3758255556e+02,
content:'Saddle = 2351.800049 pos = 36.5260,137.5826 diff = 239.699951'
});
data_peak.push({
lat: 3.6598444447e+01,
lng: 1.3758088889e+02,
cert : true,
content:'Name = Okudainichidake(JA/TY-011) peak = 2610.800049 pos = 36.5984,137.5809 diff = 258.500000'
});
data_saddle.push({
lat: 3.6591888892e+01,
lng: 1.3759300000e+02,
content:'Saddle = 2352.300049 pos = 36.5919,137.5930 diff = 258.500000'
});
data_peak.push({
lat: 3.6623333336e+01,
lng: 1.3761700000e+02,
cert : true,
content:'Name = Tsurugidake(JA/TY-002) peak = 2995.800049 pos = 36.6233,137.6170 diff = 466.000000'
});
data_saddle.push({
lat: 3.6609444447e+01,
lng: 1.3761000000e+02,
content:'Saddle = 2529.800049 pos = 36.6094,137.6100 diff = 466.000000'
});
data_peak.push({
lat: 3.6564777781e+01,
lng: 1.3760711111e+02,
cert : true,
content:'Name = Ryuuoudake(JA/TY-005) peak = 2871.600098 pos = 36.5648,137.6071 diff = 189.600098'
});
data_saddle.push({
lat: 3.6569666669e+01,
lng: 1.3761066667e+02,
content:'Saddle = 2682.000000 pos = 36.5697,137.6107 diff = 189.600098'
});
data_peak.push({
lat: 3.6758555558e+01,
lng: 1.3775855556e+02,
cert : true,
content:'Name = Shiroumadake(JA/NN-007) peak = 2931.699951 pos = 36.7586,137.7586 diff = 750.000000'
});
data_saddle.push({
lat: 3.6513777781e+01,
lng: 1.3768755556e+02,
content:'Saddle = 2181.699951 pos = 36.5138,137.6876 diff = 750.000000'
});
data_peak.push({
lat: 3.6517666670e+01,
lng: 1.3770544444e+02,
cert : true,
content:'Name = Kitakuzudake(JA/NN-029) peak = 2550.100098 pos = 36.5177,137.7054 diff = 272.200195'
});
data_saddle.push({
lat: 3.6526333336e+01,
lng: 1.3770366667e+02,
content:'Saddle = 2277.899902 pos = 36.5263,137.7037 diff = 272.200195'
});
data_peak.push({
lat: 3.6510666670e+01,
lng: 1.3769444444e+02,
cert : false,
content:' Peak = 2508.500000 pos = 36.5107,137.6944 diff = 176.300049'
});
data_saddle.push({
lat: 3.6515444447e+01,
lng: 1.3769922222e+02,
content:'Saddle = 2332.199951 pos = 36.5154,137.6992 diff = 176.300049'
});
data_peak.push({
lat: 3.6624555558e+01,
lng: 1.3774700000e+02,
cert : true,
content:'Name = Kashimayarigatake(JA/NN-012) peak = 2880.600098 pos = 36.6246,137.7470 diff = 563.100098'
});
data_saddle.push({
lat: 3.6674222225e+01,
lng: 1.3775855556e+02,
content:'Saddle = 2317.500000 pos = 36.6742,137.7586 diff = 563.100098'
});
data_peak.push({
lat: 3.6538111114e+01,
lng: 1.3768444444e+02,
cert : true,
content:'Name = Harinokidake(JA/TY-007) peak = 2820.199951 pos = 36.5381,137.6844 diff = 433.599854'
});
data_saddle.push({
lat: 3.6601777780e+01,
lng: 1.3774922222e+02,
content:'Saddle = 2386.600098 pos = 36.6018,137.7492 diff = 433.599854'
});
data_peak.push({
lat: 3.6588333336e+01,
lng: 1.3775088889e+02,
cert : true,
content:'Name = Jiigatake(JA/NN-022) peak = 2667.800049 pos = 36.5883,137.7509 diff = 271.600098'
});
data_saddle.push({
lat: 3.6587333336e+01,
lng: 1.3772944444e+02,
content:'Saddle = 2396.199951 pos = 36.5873,137.7294 diff = 271.600098'
});
data_peak.push({
lat: 3.6577000003e+01,
lng: 1.3771333333e+02,
cert : false,
content:' Peak = 2628.800049 pos = 36.5770,137.7133 diff = 168.199951'
});
data_saddle.push({
lat: 3.6571000003e+01,
lng: 1.3770177778e+02,
content:'Saddle = 2460.600098 pos = 36.5710,137.7018 diff = 168.199951'
});
data_peak.push({
lat: 3.6562000003e+01,
lng: 1.3768744444e+02,
cert : true,
content:'Name = Akazawadake(JA/NN-020) peak = 2676.300049 pos = 36.5620,137.6874 diff = 185.100098'
});
data_saddle.push({
lat: 3.6554555558e+01,
lng: 1.3768922222e+02,
content:'Saddle = 2491.199951 pos = 36.5546,137.6892 diff = 185.100098'
});
data_peak.push({
lat: 3.6535888892e+01,
lng: 1.3771022222e+02,
cert : false,
content:' Peak = 2795.699951 pos = 36.5359,137.7102 diff = 260.699951'
});
data_saddle.push({
lat: 3.6537222225e+01,
lng: 1.3769422222e+02,
content:'Saddle = 2535.000000 pos = 36.5372,137.6942 diff = 260.699951'
});
data_peak.push({
lat: 3.6658444447e+01,
lng: 1.3775266667e+02,
cert : true,
content:'Name = Goryuudake(JA/NN-016) peak = 2812.100098 pos = 36.6584,137.7527 diff = 390.300049'
});
data_saddle.push({
lat: 3.6641444447e+01,
lng: 1.3775377778e+02,
content:'Saddle = 2421.800049 pos = 36.6414,137.7538 diff = 390.300049'
});
data_peak.push({
lat: 3.6794777780e+01,
lng: 1.3775400000e+02,
cert : true,
content:'Name = Yukikuradake(JA/NI-001) peak = 2610.500000 pos = 36.7948,137.7540 diff = 218.600098'
});
data_saddle.push({
lat: 3.6787555557e+01,
lng: 1.3775055556e+02,
content:'Saddle = 2391.899902 pos = 36.7876,137.7506 diff = 218.600098'
});
data_peak.push({
lat: 3.6687222224e+01,
lng: 1.3775455556e+02,
cert : true,
content:'Name = Karamatsudake(JA/TY-008) peak = 2693.000000 pos = 36.6872,137.7546 diff = 276.399902'
});
data_saddle.push({
lat: 3.6700555558e+01,
lng: 1.3775111111e+02,
content:'Saddle = 2416.600098 pos = 36.7006,137.7511 diff = 276.399902'
});
data_peak.push({
lat: 3.6731444447e+01,
lng: 1.3775522222e+02,
cert : true,
content:'Name = Yarigatake(JA/NN-011) peak = 2901.800049 pos = 36.7314,137.7552 diff = 298.900146'
});
data_saddle.push({
lat: 3.6746111113e+01,
lng: 1.3775511111e+02,
content:'Saddle = 2602.899902 pos = 36.7461,137.7551 diff = 298.900146'
});
data_peak.push({
lat: 3.6757666669e+01,
lng: 1.3774577778e+02,
cert : true,
content:'Name = Asahidake(JA/TY-006) peak = 2866.500000 pos = 36.7577,137.7458 diff = 159.100098'
});
data_saddle.push({
lat: 3.6755666669e+01,
lng: 1.3775133333e+02,
content:'Saddle = 2707.399902 pos = 36.7557,137.7513 diff = 159.100098'
});
data_peak.push({
lat: 3.6514555558e+01,
lng: 1.3767700000e+02,
cert : true,
content:'Name = JA/NN-034(JA/NN-034) peak = 2456.899902 pos = 36.5146,137.6770 diff = 225.199951'
});
data_saddle.push({
lat: 3.6509111114e+01,
lng: 1.3766866667e+02,
content:'Saddle = 2231.699951 pos = 36.5091,137.6687 diff = 225.199951'
});
data_peak.push({
lat: 3.6447222225e+01,
lng: 1.3773588889e+02,
cert : true,
content:'Name = Gakidake(JA/NN-023) peak = 2645.000000 pos = 36.4472,137.7359 diff = 393.399902'
});
data_saddle.push({
lat: 3.6421777781e+01,
lng: 1.3772244444e+02,
content:'Saddle = 2251.600098 pos = 36.4218,137.7224 diff = 393.399902'
});
data_peak.push({
lat: 3.6461222225e+01,
lng: 1.3771666667e+02,
cert : false,
content:' Peak = 2634.100098 pos = 36.4612,137.7167 diff = 241.600098'
});
data_saddle.push({
lat: 3.6456444448e+01,
lng: 1.3772544444e+02,
content:'Saddle = 2392.500000 pos = 36.4564,137.7254 diff = 241.600098'
});
data_peak.push({
lat: 3.6325222226e+01,
lng: 1.3770455556e+02,
cert : false,
content:' Peak = 2490.800049 pos = 36.3252,137.7046 diff = 228.500000'
});
data_saddle.push({
lat: 3.6331333337e+01,
lng: 1.3770655556e+02,
content:'Saddle = 2262.300049 pos = 36.3313,137.7066 diff = 228.500000'
});
data_peak.push({
lat: 3.6468888892e+01,
lng: 1.3754477778e+02,
cert : true,
content:'Name = Yakushidake(JA/TY-004) peak = 2924.500000 pos = 36.4689,137.5448 diff = 630.199951'
});
data_saddle.push({
lat: 3.6453333337e+01,
lng: 1.3752500000e+02,
content:'Saddle = 2294.300049 pos = 36.4533,137.5250 diff = 630.199951'
});
data_peak.push({
lat: 3.6380666670e+01,
lng: 1.3765044444e+02,
cert : true,
content:'Name = Ioudake(JA/NN-028) peak = 2550.500000 pos = 36.3807,137.6504 diff = 217.800049'
});
data_saddle.push({
lat: 3.6370666670e+01,
lng: 1.3763511111e+02,
content:'Saddle = 2332.699951 pos = 36.3707,137.6351 diff = 217.800049'
});
data_peak.push({
lat: 3.6392666670e+01,
lng: 1.3753988889e+02,
cert : true,
content:'Name = Kurobegoroudake (Nakanomatadake)(JA/GF-005) peak = 2833.300049 pos = 36.3927,137.5399 diff = 486.900146'
});
data_saddle.push({
lat: 3.6388777781e+01,
lng: 1.3756544444e+02,
content:'Saddle = 2346.399902 pos = 36.3888,137.5654 diff = 486.900146'
});
data_peak.push({
lat: 3.6421111114e+01,
lng: 1.3751233333e+02,
cert : true,
content:'Name = Kitanomatadake (Kaminodake)(JA/TY-009) peak = 2661.399902 pos = 36.4211,137.5123 diff = 204.099854'
});
data_saddle.push({
lat: 3.6404888892e+01,
lng: 1.3752477778e+02,
content:'Saddle = 2457.300049 pos = 36.4049,137.5248 diff = 204.099854'
});
data_peak.push({
lat: 3.6495444447e+01,
lng: 1.3766733333e+02,
cert : false,
content:' Peak = 2600.199951 pos = 36.4954,137.6673 diff = 204.599854'
});
data_saddle.push({
lat: 3.6493333336e+01,
lng: 1.3765933333e+02,
content:'Saddle = 2395.600098 pos = 36.4933,137.6593 diff = 204.599854'
});
data_peak.push({
lat: 3.6299444448e+01,
lng: 1.3767822222e+02,
cert : true,
content:'Name = JA/NN-027(JA/NN-027) peak = 2573.899902 pos = 36.2994,137.6782 diff = 167.000000'
});
data_saddle.push({
lat: 3.6293888893e+01,
lng: 1.3767477778e+02,
content:'Saddle = 2406.899902 pos = 36.2939,137.6748 diff = 167.000000'
});
data_peak.push({
lat: 3.6325555559e+01,
lng: 1.3772755556e+02,
cert : true,
content:'Name = Jyounendake(JA/NN-014) peak = 2856.399902 pos = 36.3256,137.7276 diff = 398.799805'
});
data_saddle.push({
lat: 3.6333222226e+01,
lng: 1.3772766667e+02,
content:'Saddle = 2457.600098 pos = 36.3332,137.7277 diff = 398.799805'
});
data_peak.push({
lat: 3.6287444448e+01,
lng: 1.3772600000e+02,
cert : true,
content:'Name = Chyougatake(JA/NN-021) peak = 2676.500000 pos = 36.2874,137.7260 diff = 215.800049'
});
data_saddle.push({
lat: 3.6312000004e+01,
lng: 1.3772500000e+02,
content:'Saddle = 2460.699951 pos = 36.3120,137.7250 diff = 215.800049'
});
data_peak.push({
lat: 3.6315555559e+01,
lng: 1.3755033333e+02,
cert : true,
content:'Name = Kasagatake(JA/GF-003) peak = 2897.000000 pos = 36.3156,137.5503 diff = 439.199951'
});
data_saddle.push({
lat: 3.6347666670e+01,
lng: 1.3759122222e+02,
content:'Saddle = 2457.800049 pos = 36.3477,137.5912 diff = 439.199951'
});
data_peak.push({
lat: 3.6365000004e+01,
lng: 1.3770111111e+02,
cert : true,
content:'Name = Daitenjyoudake(JA/NN-010) peak = 2921.300049 pos = 36.3650,137.7011 diff = 448.600098'
});
data_saddle.push({
lat: 3.6337000004e+01,
lng: 1.3767011111e+02,
content:'Saddle = 2472.699951 pos = 36.3370,137.6701 diff = 448.600098'
});
data_peak.push({
lat: 3.6343444448e+01,
lng: 1.3768400000e+02,
cert : true,
content:'Name = Akaiwadake(JA/NN-018) peak = 2764.300049 pos = 36.3434,137.6840 diff = 217.100098'
});
data_saddle.push({
lat: 3.6357111115e+01,
lng: 1.3769022222e+02,
content:'Saddle = 2547.199951 pos = 36.3571,137.6902 diff = 217.100098'
});
data_peak.push({
lat: 3.6406888892e+01,
lng: 1.3771266667e+02,
cert : true,
content:'Name = Tsubakurodake(JA/NN-019) peak = 2762.000000 pos = 36.4069,137.7127 diff = 199.100098'
});
data_saddle.push({
lat: 3.6382333337e+01,
lng: 1.3770733333e+02,
content:'Saddle = 2562.899902 pos = 36.3823,137.7073 diff = 199.100098'
});
data_peak.push({
lat: 3.6426333337e+01,
lng: 1.3760277778e+02,
cert : true,
content:'Name = Suishoudake (Kurodake)(JA/TY-003) peak = 2979.699951 pos = 36.4263,137.6028 diff = 448.199951'
});
data_saddle.push({
lat: 3.6396888892e+01,
lng: 1.3759822222e+02,
content:'Saddle = 2531.500000 pos = 36.3969,137.5982 diff = 448.199951'
});
data_peak.push({
lat: 3.6432777781e+01,
lng: 1.3763777778e+02,
cert : true,
content:'Name = Noguchigoroudake(JA/NN-009) peak = 2923.699951 pos = 36.4328,137.6378 diff = 192.500000'
});
data_saddle.push({
lat: 3.6418666670e+01,
lng: 1.3761633333e+02,
content:'Saddle = 2731.199951 pos = 36.4187,137.6163 diff = 192.500000'
});
data_peak.push({
lat: 3.6371888892e+01,
lng: 1.3758711111e+02,
cert : true,
content:'Name = Sugorokudake(JA/GF-004) peak = 2860.100098 pos = 36.3719,137.5871 diff = 312.500000'
});
data_saddle.push({
lat: 3.6369666670e+01,
lng: 1.3760166667e+02,
content:'Saddle = 2547.600098 pos = 36.3697,137.6017 diff = 312.500000'
});
data_peak.push({
lat: 3.6366555559e+01,
lng: 1.3760777778e+02,
cert : false,
content:' Peak = 2752.600098 pos = 36.3666,137.6078 diff = 159.500000'
});
data_saddle.push({
lat: 3.6354111115e+01,
lng: 1.3762477778e+02,
content:'Saddle = 2593.100098 pos = 36.3541,137.6248 diff = 159.500000'
});
data_peak.push({
lat: 3.6342000004e+01,
lng: 1.3764766667e+02,
cert : true,
content:'Name = Yarigatake(JA/NN-002) peak = 3181.399902 pos = 36.3420,137.6477 diff = 434.699951'
});
data_saddle.push({
lat: 3.6310777782e+01,
lng: 1.3764922222e+02,
content:'Saddle = 2746.699951 pos = 36.3108,137.6492 diff = 434.699951'
});
data_peak.push({
lat: 3.6282000004e+01,
lng: 1.3766055556e+02,
cert : true,
content:'Name = Maehotakadake(JA/NN-004) peak = 3090.100098 pos = 36.2820,137.6606 diff = 158.700195'
});
data_saddle.push({
lat: 3.6284000004e+01,
lng: 1.3765655556e+02,
content:'Saddle = 2931.399902 pos = 36.2840,137.6566 diff = 158.700195'
});
data_peak.push({
lat: 3.6302555559e+01,
lng: 1.3765200000e+02,
cert : true,
content:'Name = Kitahotakadake(JA/NN-003) peak = 3103.600098 pos = 36.3026,137.6520 diff = 158.900146'
});
data_saddle.push({
lat: 3.6299000004e+01,
lng: 1.3764811111e+02,
content:'Saddle = 2944.699951 pos = 36.2990,137.6481 diff = 158.900146'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:37.3333,
       south:36,
       east:141,
       west:137}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
