function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 4.4075888888e+01,
lng: 1.4512222222e+02,
cert : true,
content:'Name = Rausudake(JA8/OH-001) peak = 1660.199951 pos = 44.0759,145.1222 diff = 1660.199951'
});
data_saddle.push({
lat: 4.4666666667e+01,
lng: 1.4400000000e+02,
content:'Saddle = 0.000000 pos = 44.6667,144.0000 diff = 1660.199951'
});
data_peak.push({
lat: 4.4084000000e+01,
lng: 1.4422988889e+02,
cert : false,
content:' Peak = 263.799988 pos = 44.0840,144.2299 diff = 254.499985'
});
data_saddle.push({
lat: 4.3986333333e+01,
lng: 1.4415400000e+02,
content:'Saddle = 9.300000 pos = 43.9863,144.1540 diff = 254.499985'
});
data_peak.push({
lat: 4.4052666666e+01,
lng: 1.4400000000e+02,
cert : false,
content:' Peak = 287.299988 pos = 44.0527,144.0000 diff = 277.399994'
});
data_saddle.push({
lat: 4.4044666666e+01,
lng: 1.4401177778e+02,
content:'Saddle = 9.900000 pos = 44.0447,144.0118 diff = 277.399994'
});
data_peak.push({
lat: 4.2980666665e+01,
lng: 1.4401644444e+02,
cert : true,
content:'Name = JA8/KR-036(JA8/KR-036) peak = 250.899994 pos = 42.9807,144.0164 diff = 218.199997'
});
data_saddle.push({
lat: 4.3014666665e+01,
lng: 1.4400022222e+02,
content:'Saddle = 32.700001 pos = 43.0147,144.0002 diff = 218.199997'
});
data_peak.push({
lat: 4.3023777776e+01,
lng: 1.4400411111e+02,
cert : false,
content:' Peak = 190.600006 pos = 43.0238,144.0041 diff = 155.500000'
});
data_saddle.push({
lat: 4.3043111110e+01,
lng: 1.4400088889e+02,
content:'Saddle = 35.099998 pos = 43.0431,144.0009 diff = 155.500000'
});
data_peak.push({
lat: 4.3981555555e+01,
lng: 1.4401722222e+02,
cert : true,
content:'Name = JA8/OH-094(JA8/OH-094) peak = 480.399994 pos = 43.9816,144.0172 diff = 406.200012'
});
data_saddle.push({
lat: 4.3708777777e+01,
lng: 1.4400000000e+02,
content:'Saddle = 74.199997 pos = 43.7088,144.0000 diff = 406.200012'
});
data_peak.push({
lat: 4.4005555555e+01,
lng: 1.4400566667e+02,
cert : false,
content:' Peak = 336.500000 pos = 44.0056,144.0057 diff = 258.500000'
});
data_saddle.push({
lat: 4.3995333333e+01,
lng: 1.4400011111e+02,
content:'Saddle = 78.000000 pos = 43.9953,144.0001 diff = 258.500000'
});
data_peak.push({
lat: 4.3797222222e+01,
lng: 1.4400455556e+02,
cert : false,
content:' Peak = 259.100006 pos = 43.7972,144.0046 diff = 177.400009'
});
data_saddle.push({
lat: 4.3868111111e+01,
lng: 1.4402944444e+02,
content:'Saddle = 81.699997 pos = 43.8681,144.0294 diff = 177.400009'
});
data_peak.push({
lat: 4.3675999999e+01,
lng: 1.4400044444e+02,
cert : false,
content:' Peak = 261.799988 pos = 43.6760,144.0004 diff = 158.299988'
});
data_saddle.push({
lat: 4.3664333333e+01,
lng: 1.4400011111e+02,
content:'Saddle = 103.500000 pos = 43.6643,144.0001 diff = 158.299988'
});
data_peak.push({
lat: 4.3111666665e+01,
lng: 1.4400600000e+02,
cert : false,
content:' Peak = 400.700012 pos = 43.1117,144.0060 diff = 287.100006'
});
data_saddle.push({
lat: 4.3162777777e+01,
lng: 1.4400100000e+02,
content:'Saddle = 113.599998 pos = 43.1628,144.0010 diff = 287.100006'
});
data_peak.push({
lat: 4.3144666665e+01,
lng: 1.4400300000e+02,
cert : false,
content:' Peak = 284.100006 pos = 43.1447,144.0030 diff = 169.400009'
});
data_saddle.push({
lat: 4.3135777777e+01,
lng: 1.4400000000e+02,
content:'Saddle = 114.699997 pos = 43.1358,144.0000 diff = 169.400009'
});
data_peak.push({
lat: 4.3177555554e+01,
lng: 1.4400211111e+02,
cert : false,
content:' Peak = 503.399994 pos = 43.1776,144.0021 diff = 299.099976'
});
data_saddle.push({
lat: 4.3190999999e+01,
lng: 1.4400011111e+02,
content:'Saddle = 204.300003 pos = 43.1910,144.0001 diff = 299.099976'
});
data_peak.push({
lat: 4.3615111110e+01,
lng: 1.4442711111e+02,
cert : true,
content:'Name = JA8/KR-028(JA8/KR-028) peak = 574.099976 pos = 43.6151,144.4271 diff = 369.299988'
});
data_saddle.push({
lat: 4.3583888888e+01,
lng: 1.4445488889e+02,
content:'Saddle = 204.800003 pos = 43.5839,144.4549 diff = 369.299988'
});
data_peak.push({
lat: 4.3628888888e+01,
lng: 1.4441822222e+02,
cert : true,
content:'Name = JA8/KR-031(JA8/KR-031) peak = 519.299988 pos = 43.6289,144.4182 diff = 296.199982'
});
data_saddle.push({
lat: 4.3621666666e+01,
lng: 1.4442388889e+02,
content:'Saddle = 223.100006 pos = 43.6217,144.4239 diff = 296.199982'
});
data_peak.push({
lat: 4.3585111110e+01,
lng: 1.4440788889e+02,
cert : true,
content:'Name = JA8/KR-034(JA8/KR-034) peak = 395.799988 pos = 43.5851,144.4079 diff = 162.699982'
});
data_saddle.push({
lat: 4.3587111110e+01,
lng: 1.4439400000e+02,
content:'Saddle = 233.100006 pos = 43.5871,144.3940 diff = 162.699982'
});
data_peak.push({
lat: 4.3567555555e+01,
lng: 1.4438144444e+02,
cert : true,
content:'Name = JA8/KR-032(JA8/KR-032) peak = 504.700012 pos = 43.5676,144.3814 diff = 254.000015'
});
data_saddle.push({
lat: 4.3600666666e+01,
lng: 1.4438100000e+02,
content:'Saddle = 250.699997 pos = 43.6007,144.3810 diff = 254.000015'
});
data_peak.push({
lat: 4.3589333333e+01,
lng: 1.4438922222e+02,
cert : true,
content:'Name = JA8/KR-033(JA8/KR-033) peak = 460.000000 pos = 43.5893,144.3892 diff = 155.100006'
});
data_saddle.push({
lat: 4.3572444444e+01,
lng: 1.4438633333e+02,
content:'Saddle = 304.899994 pos = 43.5724,144.3863 diff = 155.100006'
});
data_peak.push({
lat: 4.3500666666e+01,
lng: 1.4440377778e+02,
cert : true,
content:'Name = JA8/KR-030(JA8/KR-030) peak = 553.400024 pos = 43.5007,144.4038 diff = 288.500031'
});
data_saddle.push({
lat: 4.3503777777e+01,
lng: 1.4437311111e+02,
content:'Saddle = 264.899994 pos = 43.5038,144.3731 diff = 288.500031'
});
data_peak.push({
lat: 4.4235777777e+01,
lng: 1.4527355556e+02,
cert : true,
content:'Name = Shiretokodake(JA8/OH-014) peak = 1251.500000 pos = 44.2358,145.2736 diff = 974.000000'
});
data_saddle.push({
lat: 4.4167111111e+01,
lng: 1.4525788889e+02,
content:'Saddle = 277.500000 pos = 44.1671,145.2579 diff = 974.000000'
});
data_peak.push({
lat: 4.4165888889e+01,
lng: 1.4527833333e+02,
cert : true,
content:'Name = JA8/NM-017(JA8/NM-017) peak = 564.700012 pos = 44.1659,145.2783 diff = 160.300018'
});
data_saddle.push({
lat: 4.4172444444e+01,
lng: 1.4527322222e+02,
content:'Saddle = 404.399994 pos = 44.1724,145.2732 diff = 160.300018'
});
data_peak.push({
lat: 4.3214222221e+01,
lng: 1.4400000000e+02,
cert : false,
content:' Peak = 497.000000 pos = 43.2142,144.0000 diff = 207.799988'
});
data_saddle.push({
lat: 4.3220222221e+01,
lng: 1.4400000000e+02,
content:'Saddle = 289.200012 pos = 43.2202,144.0000 diff = 207.799988'
});
data_peak.push({
lat: 4.4019000000e+01,
lng: 1.4516455556e+02,
cert : true,
content:'Name = JA8/NM-021(JA8/NM-021) peak = 460.600006 pos = 44.0190,145.1646 diff = 167.800018'
});
data_saddle.push({
lat: 4.4016777777e+01,
lng: 1.4515277778e+02,
content:'Saddle = 292.799988 pos = 44.0168,145.1528 diff = 167.800018'
});
data_peak.push({
lat: 4.3386444443e+01,
lng: 1.4400855556e+02,
cert : true,
content:'Name = Meakandake(JA8/KR-001) peak = 1497.000000 pos = 43.3864,144.0086 diff = 1185.699951'
});
data_saddle.push({
lat: 4.3655555555e+01,
lng: 1.4450833333e+02,
content:'Saddle = 311.299988 pos = 43.6556,144.5083 diff = 1185.699951'
});
data_peak.push({
lat: 4.3453333332e+01,
lng: 1.4433755556e+02,
cert : true,
content:'Name = JA8/KR-027(JA8/KR-027) peak = 580.299988 pos = 43.4533,144.3376 diff = 167.500000'
});
data_saddle.push({
lat: 4.3451333332e+01,
lng: 1.4433044444e+02,
content:'Saddle = 412.799988 pos = 43.4513,144.3304 diff = 167.500000'
});
data_peak.push({
lat: 4.3491555555e+01,
lng: 1.4433955556e+02,
cert : true,
content:'Name = JA8/KR-017(JA8/KR-017) peak = 731.700012 pos = 43.4916,144.3396 diff = 305.000000'
});
data_saddle.push({
lat: 4.3499444444e+01,
lng: 1.4432922222e+02,
content:'Saddle = 426.700012 pos = 43.4994,144.3292 diff = 305.000000'
});
data_peak.push({
lat: 4.3522333332e+01,
lng: 1.4432788889e+02,
cert : true,
content:'Name = JA8/KR-015(JA8/KR-015) peak = 751.000000 pos = 43.5223,144.3279 diff = 318.100006'
});
data_saddle.push({
lat: 4.3509777777e+01,
lng: 1.4428700000e+02,
content:'Saddle = 432.899994 pos = 43.5098,144.2870 diff = 318.100006'
});
data_peak.push({
lat: 4.3513888888e+01,
lng: 1.4430833333e+02,
cert : false,
content:' Peak = 737.700012 pos = 43.5139,144.3083 diff = 155.799988'
});
data_saddle.push({
lat: 4.3519555555e+01,
lng: 1.4431911111e+02,
content:'Saddle = 581.900024 pos = 43.5196,144.3191 diff = 155.799988'
});
data_peak.push({
lat: 4.3704333333e+01,
lng: 1.4433100000e+02,
cert : true,
content:'Name = Mokotoyama(JA8/OH-035) peak = 1000.000000 pos = 43.7043,144.3310 diff = 545.000000'
});
data_saddle.push({
lat: 4.3677666666e+01,
lng: 1.4427322222e+02,
content:'Saddle = 455.000000 pos = 43.6777,144.2732 diff = 545.000000'
});
data_peak.push({
lat: 4.3454111110e+01,
lng: 1.4416455556e+02,
cert : true,
content:'Name = Oakandake(JA8/KR-002) peak = 1370.400024 pos = 43.4541,144.1646 diff = 778.900024'
});
data_saddle.push({
lat: 4.3462777777e+01,
lng: 1.4401255556e+02,
content:'Saddle = 591.500000 pos = 43.4628,144.0126 diff = 778.900024'
});
data_peak.push({
lat: 4.3529999999e+01,
lng: 1.4407722222e+02,
cert : true,
content:'Name = JA8/OH-036(JA8/OH-036) peak = 993.799988 pos = 43.5300,144.0772 diff = 396.200012'
});
data_saddle.push({
lat: 4.3445888888e+01,
lng: 1.4418933333e+02,
content:'Saddle = 597.599976 pos = 43.4459,144.1893 diff = 396.200012'
});
data_peak.push({
lat: 4.3537222221e+01,
lng: 1.4425833333e+02,
cert : true,
content:'Name = JA8/KR-013(JA8/KR-013) peak = 820.700012 pos = 43.5372,144.2583 diff = 218.700012'
});
data_saddle.push({
lat: 4.3536777777e+01,
lng: 1.4425055556e+02,
content:'Saddle = 602.000000 pos = 43.5368,144.2506 diff = 218.700012'
});
data_peak.push({
lat: 4.3353777777e+01,
lng: 1.4415611111e+02,
cert : false,
content:' Peak = 767.599976 pos = 43.3538,144.1561 diff = 155.000000'
});
data_saddle.push({
lat: 4.3361111110e+01,
lng: 1.4415544444e+02,
content:'Saddle = 612.599976 pos = 43.3611,144.1554 diff = 155.000000'
});
data_peak.push({
lat: 4.3588111110e+01,
lng: 1.4421822222e+02,
cert : true,
content:'Name = JA8/KR-006(JA8/KR-006) peak = 971.400024 pos = 43.5881,144.2182 diff = 310.200012'
});
data_saddle.push({
lat: 4.3527888888e+01,
lng: 1.4413666667e+02,
content:'Saddle = 661.200012 pos = 43.5279,144.1367 diff = 310.200012'
});
data_peak.push({
lat: 4.3451222221e+01,
lng: 1.4423411111e+02,
cert : true,
content:'Name = JA8/KR-010(JA8/KR-010) peak = 857.500000 pos = 43.4512,144.2341 diff = 179.900024'
});
data_saddle.push({
lat: 4.3495222221e+01,
lng: 1.4423422222e+02,
content:'Saddle = 677.599976 pos = 43.4952,144.2342 diff = 179.900024'
});
data_peak.push({
lat: 4.3510333332e+01,
lng: 1.4418022222e+02,
cert : true,
content:'Name = JA8/KR-008(JA8/KR-008) peak = 934.900024 pos = 43.5103,144.1802 diff = 222.900024'
});
data_saddle.push({
lat: 4.3537444444e+01,
lng: 1.4423244444e+02,
content:'Saddle = 712.000000 pos = 43.5374,144.2324 diff = 222.900024'
});
data_peak.push({
lat: 4.3530555555e+01,
lng: 1.4423222222e+02,
cert : true,
content:'Name = JA8/OH-048(JA8/OH-048) peak = 896.900024 pos = 43.5306,144.2322 diff = 174.200012'
});
data_saddle.push({
lat: 4.3524444444e+01,
lng: 1.4422466667e+02,
content:'Saddle = 722.700012 pos = 43.5244,144.2247 diff = 174.200012'
});
data_peak.push({
lat: 4.3560444444e+01,
lng: 1.4423877778e+02,
cert : true,
content:'Name = JA8/KR-007(JA8/KR-007) peak = 951.599976 pos = 43.5604,144.2388 diff = 207.399963'
});
data_saddle.push({
lat: 4.3566111110e+01,
lng: 1.4422633333e+02,
content:'Saddle = 744.200012 pos = 43.5661,144.2263 diff = 207.399963'
});
data_peak.push({
lat: 4.3408222221e+01,
lng: 1.4410733333e+02,
cert : true,
content:'Name = JA8/KR-012(JA8/KR-012) peak = 831.799988 pos = 43.4082,144.1073 diff = 184.700012'
});
data_saddle.push({
lat: 4.3408444443e+01,
lng: 1.4409822222e+02,
content:'Saddle = 647.099976 pos = 43.4084,144.0982 diff = 184.700012'
});
data_peak.push({
lat: 4.3324333332e+01,
lng: 1.4402733333e+02,
cert : true,
content:'Name = JA8/KR-009(JA8/KR-009) peak = 872.700012 pos = 43.3243,144.0273 diff = 199.700012'
});
data_saddle.push({
lat: 4.3336222221e+01,
lng: 1.4402155556e+02,
content:'Saddle = 673.000000 pos = 43.3362,144.0216 diff = 199.700012'
});
data_peak.push({
lat: 4.3351555555e+01,
lng: 1.4406300000e+02,
cert : true,
content:'Name = JA8/KR-005(JA8/KR-005) peak = 1009.299988 pos = 43.3516,144.0630 diff = 269.899963'
});
data_saddle.push({
lat: 4.3354999999e+01,
lng: 1.4403977778e+02,
content:'Saddle = 739.400024 pos = 43.3550,144.0398 diff = 269.899963'
});
data_peak.push({
lat: 4.3428666666e+01,
lng: 1.4402344444e+02,
cert : true,
content:'Name = JA8/KR-003(JA8/KR-003) peak = 1220.699951 pos = 43.4287,144.0234 diff = 422.699951'
});
data_saddle.push({
lat: 4.3417999999e+01,
lng: 1.4403166667e+02,
content:'Saddle = 798.000000 pos = 43.4180,144.0317 diff = 422.699951'
});
data_peak.push({
lat: 4.3392777777e+01,
lng: 1.4407266667e+02,
cert : true,
content:'Name = JA8/KR-004(JA8/KR-004) peak = 1093.199951 pos = 43.3928,144.0727 diff = 171.599976'
});
data_saddle.push({
lat: 4.3389888888e+01,
lng: 1.4405033333e+02,
content:'Saddle = 921.599976 pos = 43.3899,144.0503 diff = 171.599976'
});
data_peak.push({
lat: 4.3374111110e+01,
lng: 1.4400644444e+02,
cert : true,
content:'Name = Meakandake (Akanfuji)(JA8/TC-030) peak = 1476.099976 pos = 43.3741,144.0064 diff = 219.699951'
});
data_saddle.push({
lat: 4.3377888888e+01,
lng: 1.4400866667e+02,
content:'Saddle = 1256.400024 pos = 43.3779,144.0087 diff = 219.699951'
});
data_peak.push({
lat: 4.3916222222e+01,
lng: 1.4506766667e+02,
cert : true,
content:'Name = JA8/NM-019(JA8/NM-019) peak = 551.599976 pos = 43.9162,145.0677 diff = 228.399963'
});
data_saddle.push({
lat: 4.3928999999e+01,
lng: 1.4504622222e+02,
content:'Saddle = 323.200012 pos = 43.9290,145.0462 diff = 228.399963'
});
data_peak.push({
lat: 4.3908666666e+01,
lng: 1.4502055556e+02,
cert : true,
content:'Name = JA8/NM-020(JA8/NM-020) peak = 546.299988 pos = 43.9087,145.0206 diff = 178.799988'
});
data_saddle.push({
lat: 4.3911444444e+01,
lng: 1.4501511111e+02,
content:'Saddle = 367.500000 pos = 43.9114,145.0151 diff = 178.799988'
});
data_peak.push({
lat: 4.3656222221e+01,
lng: 1.4480188889e+02,
cert : true,
content:'Name = JA8/NM-018(JA8/NM-018) peak = 560.000000 pos = 43.6562,144.8019 diff = 188.100006'
});
data_saddle.push({
lat: 4.3661111110e+01,
lng: 1.4478788889e+02,
content:'Saddle = 371.899994 pos = 43.6611,144.7879 diff = 188.100006'
});
data_peak.push({
lat: 4.3696777777e+01,
lng: 1.4492722222e+02,
cert : true,
content:'Name = JA8/NM-015(JA8/NM-015) peak = 573.500000 pos = 43.6968,144.9272 diff = 165.700012'
});
data_saddle.push({
lat: 4.3693777777e+01,
lng: 1.4491711111e+02,
content:'Saddle = 407.799988 pos = 43.6938,144.9171 diff = 165.700012'
});
data_peak.push({
lat: 4.3905999999e+01,
lng: 1.4498944444e+02,
cert : true,
content:'Name = JA8/NM-010(JA8/NM-010) peak = 711.000000 pos = 43.9060,144.9894 diff = 275.899994'
});
data_saddle.push({
lat: 4.3910888888e+01,
lng: 1.4498444444e+02,
content:'Saddle = 435.100006 pos = 43.9109,144.9844 diff = 275.899994'
});
data_peak.push({
lat: 4.3974888888e+01,
lng: 1.4497400000e+02,
cert : true,
content:'Name = JA8/OH-081(JA8/OH-081) peak = 617.599976 pos = 43.9749,144.9740 diff = 181.199982'
});
data_saddle.push({
lat: 4.3974555555e+01,
lng: 1.4497900000e+02,
content:'Saddle = 436.399994 pos = 43.9746,144.9790 diff = 181.199982'
});
data_peak.push({
lat: 4.3572333332e+01,
lng: 1.4456088889e+02,
cert : true,
content:'Name = Kamuinupuri (Mashyuudake)(JA8/KR-011) peak = 855.500000 pos = 43.5723,144.5609 diff = 417.200012'
});
data_saddle.push({
lat: 4.3610888888e+01,
lng: 1.4459166667e+02,
content:'Saddle = 438.299988 pos = 43.6109,144.5917 diff = 417.200012'
});
data_peak.push({
lat: 4.3580555555e+01,
lng: 1.4450100000e+02,
cert : false,
content:' Peak = 701.400024 pos = 43.5806,144.5010 diff = 219.900024'
});
data_saddle.push({
lat: 4.3611111110e+01,
lng: 1.4455355556e+02,
content:'Saddle = 481.500000 pos = 43.6111,144.5536 diff = 219.900024'
});
data_peak.push({
lat: 4.3553555555e+01,
lng: 1.4458166667e+02,
cert : true,
content:'Name = JA8/KR-014(JA8/KR-014) peak = 792.500000 pos = 43.5536,144.5817 diff = 160.900024'
});
data_saddle.push({
lat: 4.3562888888e+01,
lng: 1.4457055556e+02,
content:'Saddle = 631.599976 pos = 43.5629,144.5706 diff = 160.900024'
});
data_peak.push({
lat: 4.3615999999e+01,
lng: 1.4468600000e+02,
cert : true,
content:'Name = JA8/NM-013(JA8/NM-013) peak = 638.799988 pos = 43.6160,144.6860 diff = 196.099976'
});
data_saddle.push({
lat: 4.3619777777e+01,
lng: 1.4468044444e+02,
content:'Saddle = 442.700012 pos = 43.6198,144.6804 diff = 196.099976'
});
data_peak.push({
lat: 4.3765666666e+01,
lng: 1.4471766667e+02,
cert : true,
content:'Name = Sharidake(JA8/OH-005) peak = 1540.000000 pos = 43.7657,144.7177 diff = 1087.699951'
});
data_saddle.push({
lat: 4.3766888888e+01,
lng: 1.4480255556e+02,
content:'Saddle = 452.299988 pos = 43.7669,144.8026 diff = 1087.699951'
});
data_peak.push({
lat: 4.3599777777e+01,
lng: 1.4464477778e+02,
cert : true,
content:'Name = JA8/NM-012(JA8/NM-012) peak = 662.500000 pos = 43.5998,144.6448 diff = 163.500000'
});
data_saddle.push({
lat: 4.3605333333e+01,
lng: 1.4464055556e+02,
content:'Saddle = 499.000000 pos = 43.6053,144.6406 diff = 163.500000'
});
data_peak.push({
lat: 4.3629888888e+01,
lng: 1.4474333333e+02,
cert : true,
content:'Name = JA8/NM-011(JA8/NM-011) peak = 692.700012 pos = 43.6299,144.7433 diff = 181.700012'
});
data_saddle.push({
lat: 4.3647777777e+01,
lng: 1.4473411111e+02,
content:'Saddle = 511.000000 pos = 43.6478,144.7341 diff = 181.700012'
});
data_peak.push({
lat: 4.3698222221e+01,
lng: 1.4483833333e+02,
cert : true,
content:'Name = JA8/NM-003(JA8/NM-003) peak = 1023.799988 pos = 43.6982,144.8383 diff = 477.399963'
});
data_saddle.push({
lat: 4.3694666666e+01,
lng: 1.4475844444e+02,
content:'Saddle = 546.400024 pos = 43.6947,144.7584 diff = 477.399963'
});
data_peak.push({
lat: 4.3720777777e+01,
lng: 1.4487833333e+02,
cert : true,
content:'Name = JA8/NM-008(JA8/NM-008) peak = 841.799988 pos = 43.7208,144.8783 diff = 213.399963'
});
data_saddle.push({
lat: 4.3708666666e+01,
lng: 1.4487911111e+02,
content:'Saddle = 628.400024 pos = 43.7087,144.8791 diff = 213.399963'
});
data_peak.push({
lat: 4.3701999999e+01,
lng: 1.4488188889e+02,
cert : true,
content:'Name = JA8/NM-006(JA8/NM-006) peak = 952.000000 pos = 43.7020,144.8819 diff = 209.799988'
});
data_saddle.push({
lat: 4.3696777777e+01,
lng: 1.4487644444e+02,
content:'Saddle = 742.200012 pos = 43.6968,144.8764 diff = 209.799988'
});
data_peak.push({
lat: 4.3679777777e+01,
lng: 1.4487877778e+02,
cert : false,
content:' Peak = 1002.200012 pos = 43.6798,144.8788 diff = 217.900024'
});
data_saddle.push({
lat: 4.3691999999e+01,
lng: 1.4486088889e+02,
content:'Saddle = 784.299988 pos = 43.6920,144.8609 diff = 217.900024'
});
data_peak.push({
lat: 4.3693777777e+01,
lng: 1.4480877778e+02,
cert : true,
content:'Name = JA8/NM-005(JA8/NM-005) peak = 1000.400024 pos = 43.6938,144.8088 diff = 178.900024'
});
data_saddle.push({
lat: 4.3700666666e+01,
lng: 1.4481855556e+02,
content:'Saddle = 821.500000 pos = 43.7007,144.8186 diff = 178.900024'
});
data_peak.push({
lat: 4.3634888888e+01,
lng: 1.4464788889e+02,
cert : true,
content:'Name = JA8/NM-007(JA8/NM-007) peak = 850.900024 pos = 43.6349,144.6479 diff = 303.500000'
});
data_saddle.push({
lat: 4.3651222221e+01,
lng: 1.4467666667e+02,
content:'Saddle = 547.400024 pos = 43.6512,144.6767 diff = 303.500000'
});
data_peak.push({
lat: 4.3655999999e+01,
lng: 1.4459622222e+02,
cert : true,
content:'Name = JA8/OH-063(JA8/OH-063) peak = 740.799988 pos = 43.6560,144.5962 diff = 188.200012'
});
data_saddle.push({
lat: 4.3639444444e+01,
lng: 1.4460922222e+02,
content:'Saddle = 552.599976 pos = 43.6394,144.6092 diff = 188.200012'
});
data_peak.push({
lat: 4.3683777777e+01,
lng: 1.4473111111e+02,
cert : true,
content:'Name = JA8/OH-026(JA8/OH-026) peak = 1062.000000 pos = 43.6838,144.7311 diff = 453.799988'
});
data_saddle.push({
lat: 4.3713666666e+01,
lng: 1.4472555556e+02,
content:'Saddle = 608.200012 pos = 43.7137,144.7256 diff = 453.799988'
});
data_peak.push({
lat: 4.3668222221e+01,
lng: 1.4470477778e+02,
cert : true,
content:'Name = Shibetsudake(JA8/OH-027) peak = 1060.599976 pos = 43.6682,144.7048 diff = 257.299988'
});
data_saddle.push({
lat: 4.3674555555e+01,
lng: 1.4471144444e+02,
content:'Saddle = 803.299988 pos = 43.6746,144.7114 diff = 257.299988'
});
data_peak.push({
lat: 4.3774888888e+01,
lng: 1.4481011111e+02,
cert : true,
content:'Name = JA8/OH-073(JA8/OH-073) peak = 657.299988 pos = 43.7749,144.8101 diff = 201.299988'
});
data_saddle.push({
lat: 4.3788444444e+01,
lng: 1.4481011111e+02,
content:'Saddle = 456.000000 pos = 43.7884,144.8101 diff = 201.299988'
});
data_peak.push({
lat: 4.3876888888e+01,
lng: 1.4487644444e+02,
cert : true,
content:'Name = Unabetsudake(JA8/OH-007) peak = 1418.699951 pos = 43.8769,144.8764 diff = 891.599976'
});
data_saddle.push({
lat: 4.3939999999e+01,
lng: 1.4498955556e+02,
content:'Saddle = 527.099976 pos = 43.9400,144.9896 diff = 891.599976'
});
data_peak.push({
lat: 4.3801444444e+01,
lng: 1.4486655556e+02,
cert : false,
content:' Peak = 760.799988 pos = 43.8014,144.8666 diff = 220.500000'
});
data_saddle.push({
lat: 4.3815777777e+01,
lng: 1.4486744444e+02,
content:'Saddle = 540.299988 pos = 43.8158,144.8674 diff = 220.500000'
});
data_peak.push({
lat: 4.3926999999e+01,
lng: 1.4497300000e+02,
cert : true,
content:'Name = JA8/OH-033(JA8/OH-033) peak = 1011.599976 pos = 43.9270,144.9730 diff = 423.799988'
});
data_saddle.push({
lat: 4.3920111111e+01,
lng: 1.4493722222e+02,
content:'Saddle = 587.799988 pos = 43.9201,144.9372 diff = 423.799988'
});
data_peak.push({
lat: 4.3941666666e+01,
lng: 1.4496933333e+02,
cert : false,
content:' Peak = 892.500000 pos = 43.9417,144.9693 diff = 160.299988'
});
data_saddle.push({
lat: 4.3934222222e+01,
lng: 1.4497411111e+02,
content:'Saddle = 732.200012 pos = 43.9342,144.9741 diff = 160.299988'
});
data_peak.push({
lat: 4.3832999999e+01,
lng: 1.4487522222e+02,
cert : false,
content:' Peak = 773.900024 pos = 43.8330,144.8752 diff = 181.700012'
});
data_saddle.push({
lat: 4.3833222222e+01,
lng: 1.4488566667e+02,
content:'Saddle = 592.200012 pos = 43.8332,144.8857 diff = 181.700012'
});
data_peak.push({
lat: 4.3873333333e+01,
lng: 1.4483355556e+02,
cert : true,
content:'Name = JA8/OH-047(JA8/OH-047) peak = 901.200012 pos = 43.8733,144.8336 diff = 179.700012'
});
data_saddle.push({
lat: 4.3874111111e+01,
lng: 1.4484100000e+02,
content:'Saddle = 721.500000 pos = 43.8741,144.8410 diff = 179.700012'
});
data_peak.push({
lat: 4.3905888888e+01,
lng: 1.4490611111e+02,
cert : false,
content:' Peak = 899.799988 pos = 43.9059,144.9061 diff = 151.599976'
});
data_saddle.push({
lat: 4.3892333333e+01,
lng: 1.4489922222e+02,
content:'Saddle = 748.200012 pos = 43.8923,144.8992 diff = 151.599976'
});
data_peak.push({
lat: 4.3993444444e+01,
lng: 1.4501322222e+02,
cert : true,
content:'Name = Onnebetsudake(JA8/NM-002) peak = 1330.400024 pos = 43.9934,145.0132 diff = 590.400024'
});
data_saddle.push({
lat: 4.4054444444e+01,
lng: 1.4510511111e+02,
content:'Saddle = 740.000000 pos = 44.0544,145.1051 diff = 590.400024'
});
data_peak.push({
lat: 4.4044444444e+01,
lng: 1.4508577778e+02,
cert : true,
content:'Name = JA8/OH-029(JA8/OH-029) peak = 1044.199951 pos = 44.0444,145.0858 diff = 196.899963'
});
data_saddle.push({
lat: 4.4042222222e+01,
lng: 1.4506411111e+02,
content:'Saddle = 847.299988 pos = 44.0422,145.0641 diff = 196.899963'
});
data_peak.push({
lat: 4.4022333333e+01,
lng: 1.4505111111e+02,
cert : true,
content:'Name = JA8/OH-009(JA8/OH-009) peak = 1316.500000 pos = 44.0223,145.0511 diff = 283.599976'
});
data_saddle.push({
lat: 4.4005666666e+01,
lng: 1.4502911111e+02,
content:'Saddle = 1032.900024 pos = 44.0057,145.0291 diff = 283.599976'
});
data_peak.push({
lat: 4.4133333333e+01,
lng: 1.4516122222e+02,
cert : true,
content:'Name = Iouzan(JA8/OH-003) peak = 1562.000000 pos = 44.1333,145.1612 diff = 245.400024'
});
data_saddle.push({
lat: 4.4102555555e+01,
lng: 1.4514255556e+02,
content:'Saddle = 1316.599976 pos = 44.1026,145.1426 diff = 245.400024'
});
data_peak.push({
lat: 4.4095333333e+01,
lng: 1.4514355556e+02,
cert : true,
content:'Name = Sashiruidake(JA8/NM-001) peak = 1562.699951 pos = 44.0953,145.1436 diff = 215.000000'
});
data_saddle.push({
lat: 4.4081222222e+01,
lng: 1.4512855556e+02,
content:'Saddle = 1347.699951 pos = 44.0812,145.1286 diff = 215.000000'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:44.6667,
       south:42.6667,
       east:146,
       west:144}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
