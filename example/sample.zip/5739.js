function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.6798555554e+01,
lng: 1.3937588889e+02,
cert : true,
content:'Name = Shiranesan(JA/TG-001) peak = 2575.800049 pos = 36.7986,139.3759 diff = 2575.800049'
});
data_saddle.push({
lat: 3.8664000000e+01,
lng: 1.3960966667e+02,
content:'Saddle = 0.000000 pos = 38.6640,139.6097 diff = 2575.800049'
});
data_peak.push({
lat: 3.8453888889e+01,
lng: 1.3923844444e+02,
cert : false,
content:' Peak = 264.799988 pos = 38.4539,139.2384 diff = 264.799988'
});
data_saddle.push({
lat: 3.8436000000e+01,
lng: 1.3922300000e+02,
content:'Saddle = 0.000000 pos = 38.4360,139.2230 diff = 264.799988'
});
data_peak.push({
lat: 3.7644888888e+01,
lng: 1.3910566667e+02,
cert : true,
content:'Name = JA/NI-137(JA/NI-137) peak = 325.500000 pos = 37.6449,139.1057 diff = 238.000000'
});
data_saddle.push({
lat: 3.7642444444e+01,
lng: 1.3911522222e+02,
content:'Saddle = 87.500000 pos = 37.6424,139.1152 diff = 238.000000'
});
data_peak.push({
lat: 3.7725777777e+01,
lng: 1.3910788889e+02,
cert : false,
content:' Peak = 280.500000 pos = 37.7258,139.1079 diff = 151.699997'
});
data_saddle.push({
lat: 3.7713555555e+01,
lng: 1.3911144444e+02,
content:'Saddle = 128.800003 pos = 37.7136,139.1114 diff = 151.699997'
});
data_peak.push({
lat: 3.7702666666e+01,
lng: 1.3937455556e+02,
cert : false,
content:' Peak = 291.100006 pos = 37.7027,139.3746 diff = 196.400009'
});
data_saddle.push({
lat: 3.7701999999e+01,
lng: 1.3937133333e+02,
content:'Saddle = 94.699997 pos = 37.7020,139.3713 diff = 196.400009'
});
data_peak.push({
lat: 3.8127777777e+01,
lng: 1.3951433333e+02,
cert : true,
content:'Name = JA/NI-131(JA/NI-131) peak = 437.299988 pos = 38.1278,139.5143 diff = 331.000000'
});
data_saddle.push({
lat: 3.8147777777e+01,
lng: 1.3952644444e+02,
content:'Saddle = 106.300003 pos = 38.1478,139.5264 diff = 331.000000'
});
data_peak.push({
lat: 3.8020666666e+01,
lng: 1.3942755556e+02,
cert : true,
content:'Name = JA/NI-111(JA/NI-111) peak = 567.000000 pos = 38.0207,139.4276 diff = 452.500000'
});
data_saddle.push({
lat: 3.8030666666e+01,
lng: 1.3946966667e+02,
content:'Saddle = 114.500000 pos = 38.0307,139.4697 diff = 452.500000'
});
data_peak.push({
lat: 3.7974666666e+01,
lng: 1.3940011111e+02,
cert : false,
content:' Peak = 272.799988 pos = 37.9747,139.4001 diff = 156.199982'
});
data_saddle.push({
lat: 3.7980333333e+01,
lng: 1.3940344444e+02,
content:'Saddle = 116.599998 pos = 37.9803,139.4034 diff = 156.199982'
});
data_peak.push({
lat: 3.8079000000e+01,
lng: 1.3948322222e+02,
cert : false,
content:' Peak = 573.500000 pos = 38.0790,139.4832 diff = 445.100006'
});
data_saddle.push({
lat: 3.8049111111e+01,
lng: 1.3949077778e+02,
content:'Saddle = 128.399994 pos = 38.0491,139.4908 diff = 445.100006'
});
data_peak.push({
lat: 3.8613111111e+01,
lng: 1.3958811111e+02,
cert : false,
content:' Peak = 290.299988 pos = 38.6131,139.5881 diff = 152.099991'
});
data_saddle.push({
lat: 3.8608444444e+01,
lng: 1.3959733333e+02,
content:'Saddle = 138.199997 pos = 38.6084,139.5973 diff = 152.099991'
});
data_peak.push({
lat: 3.7523444444e+01,
lng: 1.3906088889e+02,
cert : false,
content:' Peak = 300.799988 pos = 37.5234,139.0609 diff = 151.799988'
});
data_saddle.push({
lat: 3.7519111110e+01,
lng: 1.3909666667e+02,
content:'Saddle = 149.000000 pos = 37.5191,139.0967 diff = 151.799988'
});
data_peak.push({
lat: 3.7631111110e+01,
lng: 1.3913588889e+02,
cert : false,
content:' Peak = 320.600006 pos = 37.6311,139.1359 diff = 161.700012'
});
data_saddle.push({
lat: 3.7627555555e+01,
lng: 1.3914911111e+02,
content:'Saddle = 158.899994 pos = 37.6276,139.1491 diff = 161.700012'
});
data_peak.push({
lat: 3.8459444444e+01,
lng: 1.3958411111e+02,
cert : true,
content:'Name = JA/NI-132(JA/NI-132) peak = 410.799988 pos = 38.4594,139.5841 diff = 232.399994'
});
data_saddle.push({
lat: 3.8453444444e+01,
lng: 1.3959633333e+02,
content:'Saddle = 178.399994 pos = 38.4534,139.5963 diff = 232.399994'
});
data_peak.push({
lat: 3.8471000000e+01,
lng: 1.3957588889e+02,
cert : false,
content:' Peak = 403.799988 pos = 38.4710,139.5759 diff = 151.099991'
});
data_saddle.push({
lat: 3.8467333333e+01,
lng: 1.3958133333e+02,
content:'Saddle = 252.699997 pos = 38.4673,139.5813 diff = 151.099991'
});
data_peak.push({
lat: 3.8503111111e+01,
lng: 1.3958566667e+02,
cert : true,
content:'Name = JA/NI-121(JA/NI-121) peak = 512.000000 pos = 38.5031,139.5857 diff = 325.600006'
});
data_saddle.push({
lat: 3.8495000000e+01,
lng: 1.3960477778e+02,
content:'Saddle = 186.399994 pos = 38.4950,139.6048 diff = 325.600006'
});
data_peak.push({
lat: 3.8525222222e+01,
lng: 1.3959677778e+02,
cert : true,
content:'Name = JA/NI-112(JA/NI-112) peak = 553.599976 pos = 38.5252,139.5968 diff = 357.199982'
});
data_saddle.push({
lat: 3.8524777778e+01,
lng: 1.3960755556e+02,
content:'Saddle = 196.399994 pos = 38.5248,139.6076 diff = 357.199982'
});
data_peak.push({
lat: 3.7563666666e+01,
lng: 1.3910755556e+02,
cert : false,
content:' Peak = 349.500000 pos = 37.5637,139.1076 diff = 152.399994'
});
data_saddle.push({
lat: 3.7567999999e+01,
lng: 1.3911266667e+02,
content:'Saddle = 197.100006 pos = 37.5680,139.1127 diff = 152.399994'
});
data_peak.push({
lat: 3.8458333333e+01,
lng: 1.3953233333e+02,
cert : true,
content:'Name = JA/NI-125(JA/NI-125) peak = 488.200012 pos = 38.4583,139.5323 diff = 286.700012'
});
data_saddle.push({
lat: 3.8427444444e+01,
lng: 1.3957911111e+02,
content:'Saddle = 201.500000 pos = 38.4274,139.5791 diff = 286.700012'
});
data_peak.push({
lat: 3.8306777778e+01,
lng: 1.3958477778e+02,
cert : true,
content:'Name = JA/NI-133(JA/NI-133) peak = 410.500000 pos = 38.3068,139.5848 diff = 208.000000'
});
data_saddle.push({
lat: 3.8303222222e+01,
lng: 1.3959922222e+02,
content:'Saddle = 202.500000 pos = 38.3032,139.5992 diff = 208.000000'
});
data_peak.push({
lat: 3.7714999999e+01,
lng: 1.3948888889e+02,
cert : true,
content:'Name = JA/NI-124(JA/NI-124) peak = 501.700012 pos = 37.7150,139.4889 diff = 295.400024'
});
data_saddle.push({
lat: 3.7710888888e+01,
lng: 1.3949977778e+02,
content:'Saddle = 206.300003 pos = 37.7109,139.4998 diff = 295.400024'
});
data_peak.push({
lat: 3.8361222222e+01,
lng: 1.3951077778e+02,
cert : true,
content:'Name = Shinbodake(JA/NI-080) peak = 851.799988 pos = 38.3612,139.5108 diff = 642.199951'
});
data_saddle.push({
lat: 3.8382666666e+01,
lng: 1.3955611111e+02,
content:'Saddle = 209.600006 pos = 38.3827,139.5561 diff = 642.199951'
});
data_peak.push({
lat: 3.8272777777e+01,
lng: 1.3948788889e+02,
cert : true,
content:'Name = JA/NI-130(JA/NI-130) peak = 441.600006 pos = 38.2728,139.4879 diff = 177.500000'
});
data_saddle.push({
lat: 3.8284777778e+01,
lng: 1.3949800000e+02,
content:'Saddle = 264.100006 pos = 38.2848,139.4980 diff = 177.500000'
});
data_peak.push({
lat: 3.8345000000e+01,
lng: 1.3950277778e+02,
cert : true,
content:'Name = JA/NI-083(JA/NI-083) peak = 818.099976 pos = 38.3450,139.5028 diff = 236.099976'
});
data_saddle.push({
lat: 3.8354222222e+01,
lng: 1.3950855556e+02,
content:'Saddle = 582.000000 pos = 38.3542,139.5086 diff = 236.099976'
});
data_peak.push({
lat: 3.8396888889e+01,
lng: 1.3953322222e+02,
cert : false,
content:' Peak = 794.700012 pos = 38.3969,139.5332 diff = 178.000000'
});
data_saddle.push({
lat: 3.8374444444e+01,
lng: 1.3952677778e+02,
content:'Saddle = 616.700012 pos = 38.3744,139.5268 diff = 178.000000'
});
data_peak.push({
lat: 3.7779222222e+01,
lng: 1.3932888889e+02,
cert : true,
content:'Name = JA/NI-065(JA/NI-065) peak = 980.299988 pos = 37.7792,139.3289 diff = 765.199951'
});
data_saddle.push({
lat: 3.7814444444e+01,
lng: 1.3941222222e+02,
content:'Saddle = 215.100006 pos = 37.8144,139.4122 diff = 765.199951'
});
data_peak.push({
lat: 3.7735777777e+01,
lng: 1.3935144444e+02,
cert : true,
content:'Name = JA/NI-117(JA/NI-117) peak = 527.099976 pos = 37.7358,139.3514 diff = 255.099976'
});
data_saddle.push({
lat: 3.7752666666e+01,
lng: 1.3935000000e+02,
content:'Saddle = 272.000000 pos = 37.7527,139.3500 diff = 255.099976'
});
data_peak.push({
lat: 3.7763111110e+01,
lng: 1.3938833333e+02,
cert : true,
content:'Name = JA/NI-104(JA/NI-104) peak = 612.900024 pos = 37.7631,139.3883 diff = 265.100037'
});
data_saddle.push({
lat: 3.7782444444e+01,
lng: 1.3939011111e+02,
content:'Saddle = 347.799988 pos = 37.7824,139.3901 diff = 265.100037'
});
data_peak.push({
lat: 3.8474111111e+01,
lng: 1.3959366667e+02,
cert : false,
content:' Peak = 385.200012 pos = 38.4741,139.5937 diff = 157.500015'
});
data_saddle.push({
lat: 3.8472222222e+01,
lng: 1.3959888889e+02,
content:'Saddle = 227.699997 pos = 38.4722,139.5989 diff = 157.500015'
});
data_peak.push({
lat: 3.8493777778e+01,
lng: 1.3962622222e+02,
cert : true,
content:'Name = JA/NI-129(JA/NI-129) peak = 452.200012 pos = 38.4938,139.6262 diff = 220.900009'
});
data_saddle.push({
lat: 3.8492777778e+01,
lng: 1.3963444444e+02,
content:'Saddle = 231.300003 pos = 38.4928,139.6344 diff = 220.900009'
});
data_peak.push({
lat: 3.7654222221e+01,
lng: 1.3923655556e+02,
cert : false,
content:' Peak = 390.799988 pos = 37.6542,139.2366 diff = 158.199982'
});
data_saddle.push({
lat: 3.7635333333e+01,
lng: 1.3923844444e+02,
content:'Saddle = 232.600006 pos = 37.6353,139.2384 diff = 158.199982'
});
data_peak.push({
lat: 3.8165000000e+01,
lng: 1.3957944444e+02,
cert : false,
content:' Peak = 578.099976 pos = 38.1650,139.5794 diff = 331.099976'
});
data_saddle.push({
lat: 3.8165111111e+01,
lng: 1.3962166667e+02,
content:'Saddle = 247.000000 pos = 38.1651,139.6217 diff = 331.099976'
});
data_peak.push({
lat: 3.8583111111e+01,
lng: 1.3966500000e+02,
cert : true,
content:'Name = JA/YM-081(JA/YM-081) peak = 681.099976 pos = 38.5831,139.6650 diff = 429.099976'
});
data_saddle.push({
lat: 3.8577555556e+01,
lng: 1.3970122222e+02,
content:'Saddle = 252.000000 pos = 38.5776,139.7012 diff = 429.099976'
});
data_peak.push({
lat: 3.8591777778e+01,
lng: 1.3963555556e+02,
cert : true,
content:'Name = JA/YM-092(JA/YM-092) peak = 610.000000 pos = 38.5918,139.6356 diff = 276.299988'
});
data_saddle.push({
lat: 3.8589888889e+01,
lng: 1.3964266667e+02,
content:'Saddle = 333.700012 pos = 38.5899,139.6427 diff = 276.299988'
});
data_peak.push({
lat: 3.7714111110e+01,
lng: 1.3933422222e+02,
cert : true,
content:'Name = JA/NI-115(JA/NI-115) peak = 533.500000 pos = 37.7141,139.3342 diff = 276.899994'
});
data_saddle.push({
lat: 3.7697555555e+01,
lng: 1.3931577778e+02,
content:'Saddle = 256.600006 pos = 37.6976,139.3158 diff = 276.899994'
});
data_peak.push({
lat: 3.8522111111e+01,
lng: 1.3963133333e+02,
cert : true,
content:'Name = JA/YM-105(JA/YM-105) peak = 482.399994 pos = 38.5221,139.6313 diff = 201.799988'
});
data_saddle.push({
lat: 3.8510888889e+01,
lng: 1.3964022222e+02,
content:'Saddle = 280.600006 pos = 38.5109,139.6402 diff = 201.799988'
});
data_peak.push({
lat: 3.8207333333e+01,
lng: 1.3961544444e+02,
cert : true,
content:'Name = JA/NI-123(JA/NI-123) peak = 503.700012 pos = 38.2073,139.6154 diff = 222.000000'
});
data_saddle.push({
lat: 3.8204444444e+01,
lng: 1.3962155556e+02,
content:'Saddle = 281.700012 pos = 38.2044,139.6216 diff = 222.000000'
});
data_peak.push({
lat: 3.8548000000e+01,
lng: 1.3964533333e+02,
cert : true,
content:'Name = JA/YM-091(JA/YM-091) peak = 610.500000 pos = 38.5480,139.6453 diff = 322.100006'
});
data_saddle.push({
lat: 3.8531111111e+01,
lng: 1.3968533333e+02,
content:'Saddle = 288.399994 pos = 38.5311,139.6853 diff = 322.100006'
});
data_peak.push({
lat: 3.8572666667e+01,
lng: 1.3959388889e+02,
cert : true,
content:'Name = JA/YM-100(JA/YM-100) peak = 533.299988 pos = 38.5727,139.5939 diff = 230.399994'
});
data_saddle.push({
lat: 3.8566444444e+01,
lng: 1.3959844444e+02,
content:'Saddle = 302.899994 pos = 38.5664,139.5984 diff = 230.399994'
});
data_peak.push({
lat: 3.8562666667e+01,
lng: 1.3960944444e+02,
cert : true,
content:'Name = JA/YM-094(JA/YM-094) peak = 593.500000 pos = 38.5627,139.6094 diff = 289.899994'
});
data_saddle.push({
lat: 3.8554888889e+01,
lng: 1.3962888889e+02,
content:'Saddle = 303.600006 pos = 38.5549,139.6289 diff = 289.899994'
});
data_peak.push({
lat: 3.8620222222e+01,
lng: 1.3963055556e+02,
cert : true,
content:'Name = Atsumidake(JA/YM-073) peak = 734.299988 pos = 38.6202,139.6306 diff = 445.899994'
});
data_saddle.push({
lat: 3.8605888889e+01,
lng: 1.3972122222e+02,
content:'Saddle = 288.399994 pos = 38.6059,139.7212 diff = 445.899994'
});
data_peak.push({
lat: 3.8617666667e+01,
lng: 1.3966466667e+02,
cert : true,
content:'Name = JA/YM-079(JA/YM-079) peak = 683.700012 pos = 38.6177,139.6647 diff = 341.400024'
});
data_saddle.push({
lat: 3.8620333333e+01,
lng: 1.3964333333e+02,
content:'Saddle = 342.299988 pos = 38.6203,139.6433 diff = 341.400024'
});
data_peak.push({
lat: 3.8608333333e+01,
lng: 1.3969088889e+02,
cert : true,
content:'Name = JA/YM-093(JA/YM-093) peak = 605.799988 pos = 38.6083,139.6909 diff = 173.799988'
});
data_saddle.push({
lat: 3.8607000000e+01,
lng: 1.3967322222e+02,
content:'Saddle = 432.000000 pos = 38.6070,139.6732 diff = 173.799988'
});
data_peak.push({
lat: 3.7671999999e+01,
lng: 1.3950922222e+02,
cert : false,
content:' Peak = 465.600006 pos = 37.6720,139.5092 diff = 177.100006'
});
data_saddle.push({
lat: 3.7677222221e+01,
lng: 1.3951700000e+02,
content:'Saddle = 288.500000 pos = 37.6772,139.5170 diff = 177.100006'
});
data_peak.push({
lat: 3.8194555555e+01,
lng: 1.3960455556e+02,
cert : true,
content:'Name = JA/NI-114(JA/NI-114) peak = 536.900024 pos = 38.1946,139.6046 diff = 248.000031'
});
data_saddle.push({
lat: 3.8191333333e+01,
lng: 1.3961777778e+02,
content:'Saddle = 288.899994 pos = 38.1913,139.6178 diff = 248.000031'
});
data_peak.push({
lat: 3.8508666667e+01,
lng: 1.3966377778e+02,
cert : true,
content:'Name = JA/NI-120(JA/NI-120) peak = 512.200012 pos = 38.5087,139.6638 diff = 214.600006'
});
data_saddle.push({
lat: 3.8505222222e+01,
lng: 1.3967888889e+02,
content:'Saddle = 297.600006 pos = 38.5052,139.6789 diff = 214.600006'
});
data_peak.push({
lat: 3.7501888888e+01,
lng: 1.3969255556e+02,
cert : false,
content:' Peak = 464.100006 pos = 37.5019,139.6926 diff = 151.700012'
});
data_saddle.push({
lat: 3.7485222221e+01,
lng: 1.3968777778e+02,
content:'Saddle = 312.399994 pos = 37.4852,139.6878 diff = 151.700012'
});
data_peak.push({
lat: 3.8662666667e+01,
lng: 1.3968555556e+02,
cert : true,
content:'Name = JA/YM-085(JA/YM-085) peak = 651.299988 pos = 38.6627,139.6856 diff = 328.399994'
});
data_saddle.push({
lat: 3.8634666667e+01,
lng: 1.3973488889e+02,
content:'Saddle = 322.899994 pos = 38.6347,139.7349 diff = 328.399994'
});
data_peak.push({
lat: 3.7553666666e+01,
lng: 1.3912233333e+02,
cert : true,
content:'Name = JA/NI-118(JA/NI-118) peak = 523.200012 pos = 37.5537,139.1223 diff = 190.400024'
});
data_saddle.push({
lat: 3.7558999999e+01,
lng: 1.3914688889e+02,
content:'Saddle = 332.799988 pos = 37.5590,139.1469 diff = 190.400024'
});
data_peak.push({
lat: 3.8350444444e+01,
lng: 1.3962188889e+02,
cert : false,
content:' Peak = 500.000000 pos = 38.3504,139.6219 diff = 166.500000'
});
data_saddle.push({
lat: 3.8356888889e+01,
lng: 1.3962022222e+02,
content:'Saddle = 333.500000 pos = 38.3569,139.6202 diff = 166.500000'
});
data_peak.push({
lat: 3.8129333333e+01,
lng: 1.3977733333e+02,
cert : true,
content:'Name = JA/YM-099(JA/YM-099) peak = 542.799988 pos = 38.1293,139.7773 diff = 201.299988'
});
data_saddle.push({
lat: 3.8135555555e+01,
lng: 1.3978755556e+02,
content:'Saddle = 341.500000 pos = 38.1356,139.7876 diff = 201.299988'
});
data_peak.push({
lat: 3.8393444444e+01,
lng: 1.3960455556e+02,
cert : true,
content:'Name = JA/NI-088(JA/NI-088) peak = 707.700012 pos = 38.3934,139.6046 diff = 360.600006'
});
data_saddle.push({
lat: 3.8396666666e+01,
lng: 1.3963000000e+02,
content:'Saddle = 347.100006 pos = 38.3967,139.6300 diff = 360.600006'
});
data_peak.push({
lat: 3.8392222222e+01,
lng: 1.3963266667e+02,
cert : false,
content:' Peak = 544.099976 pos = 38.3922,139.6327 diff = 171.699982'
});
data_saddle.push({
lat: 3.8391666666e+01,
lng: 1.3962577778e+02,
content:'Saddle = 372.399994 pos = 38.3917,139.6258 diff = 171.699982'
});
data_peak.push({
lat: 3.8375444444e+01,
lng: 1.3961833333e+02,
cert : true,
content:'Name = JA/NI-099(JA/NI-099) peak = 630.299988 pos = 38.3754,139.6183 diff = 182.899994'
});
data_saddle.push({
lat: 3.8377000000e+01,
lng: 1.3961488889e+02,
content:'Saddle = 447.399994 pos = 38.3770,139.6149 diff = 182.899994'
});
data_peak.push({
lat: 3.7683888888e+01,
lng: 1.3954333333e+02,
cert : true,
content:'Name = JA/NI-089(JA/NI-089) peak = 696.700012 pos = 37.6839,139.5433 diff = 339.300018'
});
data_saddle.push({
lat: 3.7661333333e+01,
lng: 1.3955288889e+02,
content:'Saddle = 357.399994 pos = 37.6613,139.5529 diff = 339.300018'
});
data_peak.push({
lat: 3.7692333333e+01,
lng: 1.3952677778e+02,
cert : false,
content:' Peak = 630.900024 pos = 37.6923,139.5268 diff = 178.100037'
});
data_saddle.push({
lat: 3.7685555555e+01,
lng: 1.3953344444e+02,
content:'Saddle = 452.799988 pos = 37.6856,139.5334 diff = 178.100037'
});
data_peak.push({
lat: 3.8061222222e+01,
lng: 1.3971900000e+02,
cert : true,
content:'Name = JA/YM-096(JA/YM-096) peak = 550.400024 pos = 38.0612,139.7190 diff = 187.800018'
});
data_saddle.push({
lat: 3.8008888888e+01,
lng: 1.3974633333e+02,
content:'Saddle = 362.600006 pos = 38.0089,139.7463 diff = 187.800018'
});
data_peak.push({
lat: 3.7694777777e+01,
lng: 1.3927111111e+02,
cert : false,
content:' Peak = 910.099976 pos = 37.6948,139.2711 diff = 547.500000'
});
data_saddle.push({
lat: 3.7691333333e+01,
lng: 1.3930688889e+02,
content:'Saddle = 362.600006 pos = 37.6913,139.3069 diff = 547.500000'
});
data_peak.push({
lat: 3.7650333333e+01,
lng: 1.3926411111e+02,
cert : true,
content:'Name = JA/NI-101(JA/NI-101) peak = 630.299988 pos = 37.6503,139.2641 diff = 266.500000'
});
data_saddle.push({
lat: 3.7635666666e+01,
lng: 1.3927000000e+02,
content:'Saddle = 363.799988 pos = 37.6357,139.2700 diff = 266.500000'
});
data_peak.push({
lat: 3.7716111110e+01,
lng: 1.3942311111e+02,
cert : true,
content:'Name = JA/NI-092(JA/NI-092) peak = 656.599976 pos = 37.7161,139.4231 diff = 290.099976'
});
data_saddle.push({
lat: 3.7736333333e+01,
lng: 1.3945600000e+02,
content:'Saddle = 366.500000 pos = 37.7363,139.4560 diff = 290.099976'
});
data_peak.push({
lat: 3.8038666666e+01,
lng: 1.3981022222e+02,
cert : false,
content:' Peak = 522.799988 pos = 38.0387,139.8102 diff = 154.899994'
});
data_saddle.push({
lat: 3.7999555555e+01,
lng: 1.3977833333e+02,
content:'Saddle = 367.899994 pos = 37.9996,139.7783 diff = 154.899994'
});
data_peak.push({
lat: 3.8451333333e+01,
lng: 1.3963422222e+02,
cert : false,
content:' Peak = 541.700012 pos = 38.4513,139.6342 diff = 163.600006'
});
data_saddle.push({
lat: 3.8453111111e+01,
lng: 1.3964155556e+02,
content:'Saddle = 378.100006 pos = 38.4531,139.6416 diff = 163.600006'
});
data_peak.push({
lat: 3.7584555555e+01,
lng: 1.3970955556e+02,
cert : true,
content:'Name = JA/FS-162(JA/FS-162) peak = 580.400024 pos = 37.5846,139.7096 diff = 195.600037'
});
data_saddle.push({
lat: 3.7560666666e+01,
lng: 1.3970911111e+02,
content:'Saddle = 384.799988 pos = 37.5607,139.7091 diff = 195.600037'
});
data_peak.push({
lat: 3.8260111111e+01,
lng: 1.3967644444e+02,
cert : false,
content:' Peak = 551.799988 pos = 38.2601,139.6764 diff = 154.899994'
});
data_saddle.push({
lat: 3.8256222222e+01,
lng: 1.3967900000e+02,
content:'Saddle = 396.899994 pos = 38.2562,139.6790 diff = 154.899994'
});
data_peak.push({
lat: 3.7583222221e+01,
lng: 1.3954177778e+02,
cert : false,
content:' Peak = 580.299988 pos = 37.5832,139.5418 diff = 178.899994'
});
data_saddle.push({
lat: 3.7561444444e+01,
lng: 1.3955233333e+02,
content:'Saddle = 401.399994 pos = 37.5614,139.5523 diff = 178.899994'
});
data_peak.push({
lat: 3.7625888888e+01,
lng: 1.3954655556e+02,
cert : true,
content:'Name = JA/FS-149(JA/FS-149) peak = 695.400024 pos = 37.6259,139.5466 diff = 288.000031'
});
data_saddle.push({
lat: 3.7589333333e+01,
lng: 1.3956533333e+02,
content:'Saddle = 407.399994 pos = 37.5893,139.5653 diff = 288.000031'
});
data_peak.push({
lat: 3.8065777777e+01,
lng: 1.3981644444e+02,
cert : false,
content:' Peak = 565.200012 pos = 38.0658,139.8164 diff = 153.500000'
});
data_saddle.push({
lat: 3.8081333333e+01,
lng: 1.3983655556e+02,
content:'Saddle = 411.700012 pos = 38.0813,139.8366 diff = 153.500000'
});
data_peak.push({
lat: 3.8222000000e+01,
lng: 1.3966900000e+02,
cert : true,
content:'Name = Washigasuyama(JA/NI-050) peak = 1091.699951 pos = 38.2220,139.6690 diff = 678.599976'
});
data_saddle.push({
lat: 3.8201888889e+01,
lng: 1.3973444444e+02,
content:'Saddle = 413.100006 pos = 38.2019,139.7344 diff = 678.599976'
});
data_peak.push({
lat: 3.8103888888e+01,
lng: 1.3964544444e+02,
cert : true,
content:'Name = JA/NI-082(JA/NI-082) peak = 821.700012 pos = 38.1039,139.6454 diff = 283.500000'
});
data_saddle.push({
lat: 3.8111888888e+01,
lng: 1.3966066667e+02,
content:'Saddle = 538.200012 pos = 38.1119,139.6607 diff = 283.500000'
});
data_peak.push({
lat: 3.8114666666e+01,
lng: 1.3962455556e+02,
cert : true,
content:'Name = JA/NI-087(JA/NI-087) peak = 724.299988 pos = 38.1147,139.6246 diff = 161.099976'
});
data_saddle.push({
lat: 3.8109222222e+01,
lng: 1.3963422222e+02,
content:'Saddle = 563.200012 pos = 38.1092,139.6342 diff = 161.099976'
});
data_peak.push({
lat: 3.8145777777e+01,
lng: 1.3966255556e+02,
cert : true,
content:'Name = JA/NI-060(JA/NI-060) peak = 1010.099976 pos = 38.1458,139.6626 diff = 467.199951'
});
data_saddle.push({
lat: 3.8184666666e+01,
lng: 1.3969344444e+02,
content:'Saddle = 542.900024 pos = 38.1847,139.6934 diff = 467.199951'
});
data_peak.push({
lat: 3.8119111111e+01,
lng: 1.3969055556e+02,
cert : true,
content:'Name = JA/YM-059(JA/YM-059) peak = 840.299988 pos = 38.1191,139.6906 diff = 257.599976'
});
data_saddle.push({
lat: 3.8140111111e+01,
lng: 1.3971044444e+02,
content:'Saddle = 582.700012 pos = 38.1401,139.7104 diff = 257.599976'
});
data_peak.push({
lat: 3.8149111111e+01,
lng: 1.3963566667e+02,
cert : true,
content:'Name = JA/NI-067(JA/NI-067) peak = 964.900024 pos = 38.1491,139.6357 diff = 323.100037'
});
data_saddle.push({
lat: 3.8150111111e+01,
lng: 1.3964233333e+02,
content:'Saddle = 641.799988 pos = 38.1501,139.6423 diff = 323.100037'
});
data_peak.push({
lat: 3.8150000000e+01,
lng: 1.3969044444e+02,
cert : true,
content:'Name = JA/YM-049(JA/YM-049) peak = 961.500000 pos = 38.1500,139.6904 diff = 239.400024'
});
data_saddle.push({
lat: 3.8159000000e+01,
lng: 1.3967488889e+02,
content:'Saddle = 722.099976 pos = 38.1590,139.6749 diff = 239.400024'
});
data_peak.push({
lat: 3.7480222221e+01,
lng: 1.3912955556e+02,
cert : true,
content:'Name = JA/NI-095(JA/NI-095) peak = 642.299988 pos = 37.4802,139.1296 diff = 220.099976'
});
data_saddle.push({
lat: 3.7465222221e+01,
lng: 1.3913233333e+02,
content:'Saddle = 422.200012 pos = 37.4652,139.1323 diff = 220.099976'
});
data_peak.push({
lat: 3.8260444444e+01,
lng: 1.3972622222e+02,
cert : true,
content:'Name = JA/NI-102(JA/NI-102) peak = 628.700012 pos = 38.2604,139.7262 diff = 205.700012'
});
data_saddle.push({
lat: 3.8251888889e+01,
lng: 1.3973866667e+02,
content:'Saddle = 423.000000 pos = 38.2519,139.7387 diff = 205.700012'
});
data_peak.push({
lat: 3.7528999999e+01,
lng: 1.3968577778e+02,
cert : true,
content:'Name = JA/FS-135(JA/FS-135) peak = 782.200012 pos = 37.5290,139.6858 diff = 353.900024'
});
data_saddle.push({
lat: 3.7505777777e+01,
lng: 1.3965777778e+02,
content:'Saddle = 428.299988 pos = 37.5058,139.6578 diff = 353.900024'
});
data_peak.push({
lat: 3.8192888889e+01,
lng: 1.3975588889e+02,
cert : true,
content:'Name = JA/YM-072(JA/YM-072) peak = 740.799988 pos = 38.1929,139.7559 diff = 308.899994'
});
data_saddle.push({
lat: 3.8198111111e+01,
lng: 1.3976788889e+02,
content:'Saddle = 431.899994 pos = 38.1981,139.7679 diff = 308.899994'
});
data_peak.push({
lat: 3.8039888888e+01,
lng: 1.3985166667e+02,
cert : true,
content:'Name = JA/YM-089(JA/YM-089) peak = 640.099976 pos = 38.0399,139.8517 diff = 207.899963'
});
data_saddle.push({
lat: 3.7999777777e+01,
lng: 1.3982777778e+02,
content:'Saddle = 432.200012 pos = 37.9998,139.8278 diff = 207.899963'
});
data_peak.push({
lat: 3.8411444444e+01,
lng: 1.3963644444e+02,
cert : true,
content:'Name = JA/NI-100(JA/NI-100) peak = 632.400024 pos = 38.4114,139.6364 diff = 190.000031'
});
data_saddle.push({
lat: 3.8401888889e+01,
lng: 1.3965722222e+02,
content:'Saddle = 442.399994 pos = 38.4019,139.6572 diff = 190.000031'
});
data_peak.push({
lat: 3.7332444443e+01,
lng: 1.3906911111e+02,
cert : true,
content:'Name = JA/NI-103(JA/NI-103) peak = 630.299988 pos = 37.3324,139.0691 diff = 187.500000'
});
data_saddle.push({
lat: 3.7312666666e+01,
lng: 1.3905977778e+02,
content:'Saddle = 442.799988 pos = 37.3127,139.0598 diff = 187.500000'
});
data_peak.push({
lat: 3.8058333333e+01,
lng: 1.3983144444e+02,
cert : false,
content:' Peak = 597.900024 pos = 38.0583,139.8314 diff = 150.500031'
});
data_saddle.push({
lat: 3.8065333333e+01,
lng: 1.3983877778e+02,
content:'Saddle = 447.399994 pos = 38.0653,139.8388 diff = 150.500031'
});
data_peak.push({
lat: 3.7457333332e+01,
lng: 1.3968377778e+02,
cert : true,
content:'Name = JA/FS-141(JA/FS-141) peak = 724.299988 pos = 37.4573,139.6838 diff = 247.099976'
});
data_saddle.push({
lat: 3.7436333332e+01,
lng: 1.3966411111e+02,
content:'Saddle = 477.200012 pos = 37.4363,139.6641 diff = 247.099976'
});
data_peak.push({
lat: 3.8051333333e+01,
lng: 1.3964855556e+02,
cert : false,
content:' Peak = 628.099976 pos = 38.0513,139.6486 diff = 150.699982'
});
data_saddle.push({
lat: 3.8036666666e+01,
lng: 1.3965722222e+02,
content:'Saddle = 477.399994 pos = 38.0367,139.6572 diff = 150.699982'
});
data_peak.push({
lat: 3.7386444443e+01,
lng: 1.3980733333e+02,
cert : false,
content:' Peak = 644.500000 pos = 37.3864,139.8073 diff = 166.299988'
});
data_saddle.push({
lat: 3.7375999999e+01,
lng: 1.3980644444e+02,
content:'Saddle = 478.200012 pos = 37.3760,139.8064 diff = 166.299988'
});
data_peak.push({
lat: 3.7195111110e+01,
lng: 1.3905377778e+02,
cert : true,
content:'Name = JA/NI-093(JA/NI-093) peak = 652.599976 pos = 37.1951,139.0538 diff = 169.899963'
});
data_saddle.push({
lat: 3.7196111110e+01,
lng: 1.3904188889e+02,
content:'Saddle = 482.700012 pos = 37.1961,139.0419 diff = 169.899963'
});
data_peak.push({
lat: 3.7980222222e+01,
lng: 1.3969500000e+02,
cert : true,
content:'Name = JA/YM-066(JA/YM-066) peak = 791.799988 pos = 37.9802,139.6950 diff = 299.199982'
});
data_saddle.push({
lat: 3.7963888888e+01,
lng: 1.3970377778e+02,
content:'Saddle = 492.600006 pos = 37.9639,139.7038 diff = 299.199982'
});
data_peak.push({
lat: 3.7995888888e+01,
lng: 1.3969522222e+02,
cert : false,
content:' Peak = 757.200012 pos = 37.9959,139.6952 diff = 196.400024'
});
data_saddle.push({
lat: 3.7986555555e+01,
lng: 1.3969577778e+02,
content:'Saddle = 560.799988 pos = 37.9866,139.6958 diff = 196.400024'
});
data_peak.push({
lat: 3.8549222222e+01,
lng: 1.4002688889e+02,
cert : true,
content:'Name = Gassan(JA/YM-002) peak = 1983.199951 pos = 38.5492,140.0269 diff = 1485.500000'
});
data_saddle.push({
lat: 3.8011444444e+01,
lng: 1.3992033333e+02,
content:'Saddle = 497.700012 pos = 38.0114,139.9203 diff = 1485.500000'
});
data_peak.push({
lat: 3.8429111111e+01,
lng: 1.3965011111e+02,
cert : false,
content:' Peak = 691.900024 pos = 38.4291,139.6501 diff = 171.500000'
});
data_saddle.push({
lat: 3.8426555555e+01,
lng: 1.3965588889e+02,
content:'Saddle = 520.400024 pos = 38.4266,139.6559 diff = 171.500000'
});
data_peak.push({
lat: 3.8318666666e+01,
lng: 1.4009322222e+02,
cert : false,
content:' Peak = 702.799988 pos = 38.3187,140.0932 diff = 165.299988'
});
data_saddle.push({
lat: 3.8316555555e+01,
lng: 1.4008177778e+02,
content:'Saddle = 537.500000 pos = 38.3166,140.0818 diff = 165.299988'
});
data_peak.push({
lat: 3.8369111111e+01,
lng: 1.3967077778e+02,
cert : false,
content:' Peak = 774.700012 pos = 38.3691,139.6708 diff = 236.000000'
});
data_saddle.push({
lat: 3.8367000000e+01,
lng: 1.3967600000e+02,
content:'Saddle = 538.700012 pos = 38.3670,139.6760 diff = 236.000000'
});
data_peak.push({
lat: 3.8129666666e+01,
lng: 1.3993355556e+02,
cert : false,
content:' Peak = 707.500000 pos = 38.1297,139.9336 diff = 160.400024'
});
data_saddle.push({
lat: 3.8133333333e+01,
lng: 1.3992333333e+02,
content:'Saddle = 547.099976 pos = 38.1333,139.9233 diff = 160.400024'
});
data_peak.push({
lat: 3.8187888889e+01,
lng: 1.3978933333e+02,
cert : true,
content:'Name = JA/YM-067(JA/YM-067) peak = 786.299988 pos = 38.1879,139.7893 diff = 233.599976'
});
data_saddle.push({
lat: 3.8197111111e+01,
lng: 1.3978933333e+02,
content:'Saddle = 552.700012 pos = 38.1971,139.7893 diff = 233.599976'
});
data_peak.push({
lat: 3.8278000000e+01,
lng: 1.3968988889e+02,
cert : false,
content:' Peak = 773.200012 pos = 38.2780,139.6899 diff = 154.799988'
});
data_saddle.push({
lat: 3.8282333333e+01,
lng: 1.3969577778e+02,
content:'Saddle = 618.400024 pos = 38.2823,139.6958 diff = 154.799988'
});
data_peak.push({
lat: 3.8354111111e+01,
lng: 1.4000700000e+02,
cert : true,
content:'Name = JA/YM-044(JA/YM-044) peak = 984.400024 pos = 38.3541,140.0070 diff = 337.200012'
});
data_saddle.push({
lat: 3.8332888889e+01,
lng: 1.3999288889e+02,
content:'Saddle = 647.200012 pos = 38.3329,139.9929 diff = 337.200012'
});
data_peak.push({
lat: 3.8206777777e+01,
lng: 1.3980533333e+02,
cert : true,
content:'Name = JA/YM-056(JA/YM-056) peak = 870.500000 pos = 38.2068,139.8053 diff = 217.099976'
});
data_saddle.push({
lat: 3.8212777777e+01,
lng: 1.3981566667e+02,
content:'Saddle = 653.400024 pos = 38.2128,139.8157 diff = 217.099976'
});
data_peak.push({
lat: 3.8273333333e+01,
lng: 1.3965088889e+02,
cert : true,
content:'Name = JA/NI-081(JA/NI-081) peak = 832.000000 pos = 38.2733,139.6509 diff = 168.599976'
});
data_saddle.push({
lat: 3.8293666666e+01,
lng: 1.3966211111e+02,
content:'Saddle = 663.400024 pos = 38.2937,139.6621 diff = 168.599976'
});
data_peak.push({
lat: 3.8506666667e+01,
lng: 1.3984633333e+02,
cert : true,
content:'Name = JA/YM-040(JA/YM-040) peak = 991.099976 pos = 38.5067,139.8463 diff = 319.699951'
});
data_saddle.push({
lat: 3.8488666667e+01,
lng: 1.3982133333e+02,
content:'Saddle = 671.400024 pos = 38.4887,139.8213 diff = 319.699951'
});
data_peak.push({
lat: 3.8300000000e+01,
lng: 1.3969266667e+02,
cert : true,
content:'Name = JA/NI-066(JA/NI-066) peak = 966.299988 pos = 38.3000,139.6927 diff = 276.000000'
});
data_saddle.push({
lat: 3.8330111111e+01,
lng: 1.3968400000e+02,
content:'Saddle = 690.299988 pos = 38.3301,139.6840 diff = 276.000000'
});
data_peak.push({
lat: 3.8315555555e+01,
lng: 1.3965622222e+02,
cert : true,
content:'Name = JA/NI-068(JA/NI-068) peak = 953.000000 pos = 38.3156,139.6562 diff = 230.599976'
});
data_saddle.push({
lat: 3.8317555555e+01,
lng: 1.3967422222e+02,
content:'Saddle = 722.400024 pos = 38.3176,139.6742 diff = 230.599976'
});
data_peak.push({
lat: 3.8468000000e+01,
lng: 1.4007588889e+02,
cert : true,
content:'Name = JA/YM-057(JA/YM-057) peak = 867.299988 pos = 38.4680,140.0759 diff = 174.599976'
});
data_saddle.push({
lat: 3.8473000000e+01,
lng: 1.4008011111e+02,
content:'Saddle = 692.700012 pos = 38.4730,140.0801 diff = 174.599976'
});
data_peak.push({
lat: 3.8355555555e+01,
lng: 1.3969555556e+02,
cert : false,
content:' Peak = 852.200012 pos = 38.3556,139.6956 diff = 154.600037'
});
data_saddle.push({
lat: 3.8372111111e+01,
lng: 1.3969422222e+02,
content:'Saddle = 697.599976 pos = 38.3721,139.6942 diff = 154.600037'
});
data_peak.push({
lat: 3.8520444444e+01,
lng: 1.3972788889e+02,
cert : true,
content:'Name = Mayasan(JA/YM-034) peak = 1013.299988 pos = 38.5204,139.7279 diff = 301.000000'
});
data_saddle.push({
lat: 3.8447666667e+01,
lng: 1.3971777778e+02,
content:'Saddle = 712.299988 pos = 38.4477,139.7178 diff = 301.000000'
});
data_peak.push({
lat: 3.8605777778e+01,
lng: 1.3977877778e+02,
cert : true,
content:'Name = JA/YM-048(JA/YM-048) peak = 961.099976 pos = 38.6058,139.7788 diff = 228.799988'
});
data_saddle.push({
lat: 3.8577444444e+01,
lng: 1.3976066667e+02,
content:'Saddle = 732.299988 pos = 38.5774,139.7607 diff = 228.799988'
});
data_peak.push({
lat: 3.8314555555e+01,
lng: 1.4001944444e+02,
cert : false,
content:' Peak = 1014.900024 pos = 38.3146,140.0194 diff = 297.000000'
});
data_saddle.push({
lat: 3.8302777778e+01,
lng: 1.4000688889e+02,
content:'Saddle = 717.900024 pos = 38.3028,140.0069 diff = 297.000000'
});
data_peak.push({
lat: 3.8485888889e+01,
lng: 1.4018022222e+02,
cert : true,
content:'Name = JA/YM-051(JA/YM-051) peak = 922.400024 pos = 38.4859,140.1802 diff = 200.500000'
});
data_saddle.push({
lat: 3.8501111111e+01,
lng: 1.4016866667e+02,
content:'Saddle = 721.900024 pos = 38.5011,140.1687 diff = 200.500000'
});
data_peak.push({
lat: 3.8653000000e+01,
lng: 1.4003988889e+02,
cert : true,
content:'Name = JA/YM-026(JA/YM-026) peak = 1091.099976 pos = 38.6530,140.0399 diff = 340.599976'
});
data_saddle.push({
lat: 3.8640666667e+01,
lng: 1.4006655556e+02,
content:'Saddle = 750.500000 pos = 38.6407,140.0666 diff = 340.599976'
});
data_peak.push({
lat: 3.8192666666e+01,
lng: 1.3983200000e+02,
cert : true,
content:'Name = JA/YM-036(JA/YM-036) peak = 1009.500000 pos = 38.1927,139.8320 diff = 256.299988'
});
data_saddle.push({
lat: 3.8193222222e+01,
lng: 1.3983977778e+02,
content:'Saddle = 753.200012 pos = 38.1932,139.8398 diff = 256.299988'
});
data_peak.push({
lat: 3.8416222222e+01,
lng: 1.3971333333e+02,
cert : true,
content:'Name = JA/YM-031(JA/YM-031) peak = 1026.500000 pos = 38.4162,139.7133 diff = 249.599976'
});
data_saddle.push({
lat: 3.8389222222e+01,
lng: 1.3971500000e+02,
content:'Saddle = 776.900024 pos = 38.3892,139.7150 diff = 249.599976'
});
data_peak.push({
lat: 3.8401888889e+01,
lng: 1.3973400000e+02,
cert : true,
content:'Name = JA/YM-033(JA/YM-033) peak = 1020.099976 pos = 38.4019,139.7340 diff = 237.000000'
});
data_saddle.push({
lat: 3.8375444444e+01,
lng: 1.3972988889e+02,
content:'Saddle = 783.099976 pos = 38.3754,139.7299 diff = 237.000000'
});
data_peak.push({
lat: 3.8140000000e+01,
lng: 1.3996077778e+02,
cert : true,
content:'Name = JA/YM-046(JA/YM-046) peak = 980.599976 pos = 38.1400,139.9608 diff = 190.500000'
});
data_saddle.push({
lat: 3.8153444444e+01,
lng: 1.3998500000e+02,
content:'Saddle = 790.099976 pos = 38.1534,139.9850 diff = 190.500000'
});
data_peak.push({
lat: 3.8621444444e+01,
lng: 1.4010266667e+02,
cert : true,
content:'Name = JA/YM-028(JA/YM-028) peak = 1080.000000 pos = 38.6214,140.1027 diff = 267.200012'
});
data_saddle.push({
lat: 3.8606777778e+01,
lng: 1.4010655556e+02,
content:'Saddle = 812.799988 pos = 38.6068,140.1066 diff = 267.200012'
});
data_peak.push({
lat: 3.8176444444e+01,
lng: 1.3984277778e+02,
cert : false,
content:' Peak = 1053.800049 pos = 38.1764,139.8428 diff = 230.700073'
});
data_saddle.push({
lat: 3.8181777777e+01,
lng: 1.3985000000e+02,
content:'Saddle = 823.099976 pos = 38.1818,139.8500 diff = 230.700073'
});
data_peak.push({
lat: 3.8270111111e+01,
lng: 1.4007044444e+02,
cert : false,
content:' Peak = 991.000000 pos = 38.2701,140.0704 diff = 159.299988'
});
data_saddle.push({
lat: 3.8251777777e+01,
lng: 1.4004755556e+02,
content:'Saddle = 831.700012 pos = 38.2518,140.0476 diff = 159.299988'
});
data_peak.push({
lat: 3.8439444444e+01,
lng: 1.3987000000e+02,
cert : false,
content:' Peak = 1023.799988 pos = 38.4394,139.8700 diff = 172.899963'
});
data_saddle.push({
lat: 3.8440777778e+01,
lng: 1.3987755556e+02,
content:'Saddle = 850.900024 pos = 38.4408,139.8776 diff = 172.899963'
});
data_peak.push({
lat: 3.8529333333e+01,
lng: 1.4021044444e+02,
cert : true,
content:'Name = Hayama(JA/YM-007) peak = 1461.599976 pos = 38.5293,140.2104 diff = 594.000000'
});
data_saddle.push({
lat: 3.8496555555e+01,
lng: 1.4011088889e+02,
content:'Saddle = 867.599976 pos = 38.4966,140.1109 diff = 594.000000'
});
data_peak.push({
lat: 3.8519777778e+01,
lng: 1.4015344444e+02,
cert : true,
content:'Name = JA/YM-027(JA/YM-027) peak = 1082.599976 pos = 38.5198,140.1534 diff = 209.599976'
});
data_saddle.push({
lat: 3.8525444444e+01,
lng: 1.4015888889e+02,
content:'Saddle = 873.000000 pos = 38.5254,140.1589 diff = 209.599976'
});
data_peak.push({
lat: 3.8563000000e+01,
lng: 1.4012044444e+02,
cert : false,
content:' Peak = 1060.900024 pos = 38.5630,140.1204 diff = 158.100037'
});
data_saddle.push({
lat: 3.8568888889e+01,
lng: 1.4011722222e+02,
content:'Saddle = 902.799988 pos = 38.5689,140.1172 diff = 158.100037'
});
data_peak.push({
lat: 3.8260555555e+01,
lng: 1.3992233333e+02,
cert : true,
content:'Name = Asahidake (Ooasahidake)(JA/YM-003) peak = 1870.099976 pos = 38.2606,139.9223 diff = 953.299988'
});
data_saddle.push({
lat: 3.8514444444e+01,
lng: 1.3995344444e+02,
content:'Saddle = 916.799988 pos = 38.5144,139.9534 diff = 953.299988'
});
data_peak.push({
lat: 3.8241444444e+01,
lng: 1.3981566667e+02,
cert : false,
content:' Peak = 1214.500000 pos = 38.2414,139.8157 diff = 282.700012'
});
data_saddle.push({
lat: 3.8251666666e+01,
lng: 1.3983577778e+02,
content:'Saddle = 931.799988 pos = 38.2517,139.8358 diff = 282.700012'
});
data_peak.push({
lat: 3.8197666666e+01,
lng: 1.3987955556e+02,
cert : true,
content:'Name = Iwaigameyama(JA/YM-009) peak = 1416.199951 pos = 38.1977,139.8796 diff = 454.099976'
});
data_saddle.push({
lat: 3.8209888889e+01,
lng: 1.3988844444e+02,
content:'Saddle = 962.099976 pos = 38.2099,139.8884 diff = 454.099976'
});
data_peak.push({
lat: 3.8137000000e+01,
lng: 1.3988722222e+02,
cert : true,
content:'Name = JA/YM-011(JA/YM-011) peak = 1292.900024 pos = 38.1370,139.8872 diff = 302.400024'
});
data_saddle.push({
lat: 3.8180666666e+01,
lng: 1.3988000000e+02,
content:'Saddle = 990.500000 pos = 38.1807,139.8800 diff = 302.400024'
});
data_peak.push({
lat: 3.8156333333e+01,
lng: 1.3988277778e+02,
cert : true,
content:'Name = JA/YM-015(JA/YM-015) peak = 1260.099976 pos = 38.1563,139.8828 diff = 267.500000'
});
data_saddle.push({
lat: 3.8149555555e+01,
lng: 1.3989533333e+02,
content:'Saddle = 992.599976 pos = 38.1496,139.8953 diff = 267.500000'
});
data_peak.push({
lat: 3.8453777778e+01,
lng: 1.3983611111e+02,
cert : true,
content:'Name = JA/YM-016(JA/YM-016) peak = 1243.800049 pos = 38.4538,139.8361 diff = 250.700073'
});
data_saddle.push({
lat: 3.8441777778e+01,
lng: 1.3983166667e+02,
content:'Saddle = 993.099976 pos = 38.4418,139.8317 diff = 250.700073'
});
data_peak.push({
lat: 3.8244555555e+01,
lng: 1.4002288889e+02,
cert : true,
content:'Name = JA/YM-018(JA/YM-018) peak = 1204.000000 pos = 38.2446,140.0229 diff = 187.299988'
});
data_saddle.push({
lat: 3.8230111111e+01,
lng: 1.4000733333e+02,
content:'Saddle = 1016.700012 pos = 38.2301,140.0073 diff = 187.299988'
});
data_peak.push({
lat: 3.8191555555e+01,
lng: 1.3996833333e+02,
cert : true,
content:'Name = JA/YM-012(JA/YM-012) peak = 1288.199951 pos = 38.1916,139.9683 diff = 195.599976'
});
data_saddle.push({
lat: 3.8205777777e+01,
lng: 1.3995344444e+02,
content:'Saddle = 1092.599976 pos = 38.2058,139.9534 diff = 195.599976'
});
data_peak.push({
lat: 3.8361000000e+01,
lng: 1.3976166667e+02,
cert : false,
content:' Peak = 1330.000000 pos = 38.3610,139.7617 diff = 171.400024'
});
data_saddle.push({
lat: 3.8353333333e+01,
lng: 1.3978066667e+02,
content:'Saddle = 1158.599976 pos = 38.3533,139.7807 diff = 171.400024'
});
data_peak.push({
lat: 3.8381000000e+01,
lng: 1.3991077778e+02,
cert : true,
content:'Name = JA/YM-006(JA/YM-006) peak = 1482.900024 pos = 38.3810,139.9108 diff = 310.800049'
});
data_saddle.push({
lat: 3.8351222222e+01,
lng: 1.3990477778e+02,
content:'Saddle = 1172.099976 pos = 38.3512,139.9048 diff = 310.800049'
});
data_peak.push({
lat: 3.8448222222e+01,
lng: 1.3993344444e+02,
cert : true,
content:'Name = JA/YM-008(JA/YM-008) peak = 1441.300049 pos = 38.4482,139.9334 diff = 213.400024'
});
data_saddle.push({
lat: 3.8398000000e+01,
lng: 1.3991900000e+02,
content:'Saddle = 1227.900024 pos = 38.3980,139.9190 diff = 213.400024'
});
data_peak.push({
lat: 3.8418444444e+01,
lng: 1.3991722222e+02,
cert : false,
content:' Peak = 1402.099976 pos = 38.4184,139.9172 diff = 170.900024'
});
data_saddle.push({
lat: 3.8424000000e+01,
lng: 1.3992966667e+02,
content:'Saddle = 1231.199951 pos = 38.4240,139.9297 diff = 170.900024'
});
data_peak.push({
lat: 3.8208777777e+01,
lng: 1.3994044444e+02,
cert : false,
content:' Peak = 1341.000000 pos = 38.2088,139.9404 diff = 160.300049'
});
data_saddle.push({
lat: 3.8213333333e+01,
lng: 1.3994166667e+02,
content:'Saddle = 1180.699951 pos = 38.2133,139.9417 diff = 160.300049'
});
data_peak.push({
lat: 3.8355222222e+01,
lng: 1.3980444444e+02,
cert : false,
content:' Peak = 1501.099976 pos = 38.3552,139.8044 diff = 187.900024'
});
data_saddle.push({
lat: 3.8352222222e+01,
lng: 1.3981944444e+02,
content:'Saddle = 1313.199951 pos = 38.3522,139.8194 diff = 187.900024'
});
data_peak.push({
lat: 3.8343000000e+01,
lng: 1.3984900000e+02,
cert : true,
content:'Name = Itoudake(JA/YM-005) peak = 1771.099976 pos = 38.3430,139.8490 diff = 333.299927'
});
data_saddle.push({
lat: 3.8321555555e+01,
lng: 1.3986722222e+02,
content:'Saddle = 1437.800049 pos = 38.3216,139.8672 diff = 333.299927'
});
data_peak.push({
lat: 3.8273555555e+01,
lng: 1.3994500000e+02,
cert : false,
content:' Peak = 1645.800049 pos = 38.2736,139.9450 diff = 173.800049'
});
data_saddle.push({
lat: 3.8272000000e+01,
lng: 1.3994022222e+02,
content:'Saddle = 1472.000000 pos = 38.2720,139.9402 diff = 173.800049'
});
data_peak.push({
lat: 3.8306333333e+01,
lng: 1.3987900000e+02,
cert : false,
content:' Peak = 1693.400024 pos = 38.3063,139.8790 diff = 160.700073'
});
data_saddle.push({
lat: 3.8301333333e+01,
lng: 1.3988655556e+02,
content:'Saddle = 1532.699951 pos = 38.3013,139.8866 diff = 160.700073'
});
data_peak.push({
lat: 3.8609111111e+01,
lng: 1.4008455556e+02,
cert : false,
content:' Peak = 1181.099976 pos = 38.6091,140.0846 diff = 168.399963'
});
data_saddle.push({
lat: 3.8590222222e+01,
lng: 1.4009533333e+02,
content:'Saddle = 1012.700012 pos = 38.5902,140.0953 diff = 168.399963'
});
data_peak.push({
lat: 3.8567666667e+01,
lng: 1.4009666667e+02,
cert : false,
content:' Peak = 1223.300049 pos = 38.5677,140.0967 diff = 151.900024'
});
data_saddle.push({
lat: 3.8552000000e+01,
lng: 1.4008233333e+02,
content:'Saddle = 1071.400024 pos = 38.5520,140.0823 diff = 151.900024'
});
data_peak.push({
lat: 3.8531000000e+01,
lng: 1.3998477778e+02,
cert : false,
content:' Peak = 1498.699951 pos = 38.5310,139.9848 diff = 155.000000'
});
data_saddle.push({
lat: 3.8538888889e+01,
lng: 1.3999433333e+02,
content:'Saddle = 1343.699951 pos = 38.5389,139.9943 diff = 155.000000'
});
data_peak.push({
lat: 3.8080888888e+01,
lng: 1.4023011111e+02,
cert : false,
content:' Peak = 800.599976 pos = 38.0809,140.2301 diff = 302.399963'
});
data_saddle.push({
lat: 3.8074000000e+01,
lng: 1.4025844444e+02,
content:'Saddle = 498.200012 pos = 38.0740,140.2584 diff = 302.399963'
});
data_peak.push({
lat: 3.8650888889e+01,
lng: 1.4054477778e+02,
cert : false,
content:' Peak = 1074.199951 pos = 38.6509,140.5448 diff = 560.099976'
});
data_saddle.push({
lat: 3.8603777778e+01,
lng: 1.4056000000e+02,
content:'Saddle = 514.099976 pos = 38.6038,140.5600 diff = 560.099976'
});
data_peak.push({
lat: 3.8636777778e+01,
lng: 1.4059388889e+02,
cert : true,
content:'Name = JA/MG-025(JA/MG-025) peak = 823.099976 pos = 38.6368,140.5939 diff = 180.500000'
});
data_saddle.push({
lat: 3.8637444444e+01,
lng: 1.4057311111e+02,
content:'Saddle = 642.599976 pos = 38.6374,140.5731 diff = 180.500000'
});
data_peak.push({
lat: 3.7989111111e+01,
lng: 1.3989955556e+02,
cert : true,
content:'Name = JA/YM-077(JA/YM-077) peak = 692.099976 pos = 37.9891,139.8996 diff = 169.699951'
});
data_saddle.push({
lat: 3.7955777777e+01,
lng: 1.3988077778e+02,
content:'Saddle = 522.400024 pos = 37.9558,139.8808 diff = 169.699951'
});
data_peak.push({
lat: 3.8248000000e+01,
lng: 1.4057722222e+02,
cert : true,
content:'Name = JA/MG-033(JA/MG-033) peak = 710.700012 pos = 38.2480,140.5772 diff = 179.100037'
});
data_saddle.push({
lat: 3.8253111111e+01,
lng: 1.4057411111e+02,
content:'Saddle = 531.599976 pos = 38.2531,140.5741 diff = 179.100037'
});
data_peak.push({
lat: 3.7693777777e+01,
lng: 1.3992811111e+02,
cert : false,
content:' Peak = 711.700012 pos = 37.6938,139.9281 diff = 177.000000'
});
data_saddle.push({
lat: 3.7702888888e+01,
lng: 1.3993400000e+02,
content:'Saddle = 534.700012 pos = 37.7029,139.9340 diff = 177.000000'
});
data_peak.push({
lat: 3.7833222222e+01,
lng: 1.3966055556e+02,
cert : true,
content:'Name = Dainichidake(JA/NI-007) peak = 2125.899902 pos = 37.8332,139.6606 diff = 1587.999878'
});
data_saddle.push({
lat: 3.7484777777e+01,
lng: 1.4019722222e+02,
content:'Saddle = 537.900024 pos = 37.4848,140.1972 diff = 1587.999878'
});
data_peak.push({
lat: 3.7502222221e+01,
lng: 1.4023033333e+02,
cert : false,
content:' Peak = 705.000000 pos = 37.5022,140.2303 diff = 166.400024'
});
data_saddle.push({
lat: 3.7505888888e+01,
lng: 1.4022000000e+02,
content:'Saddle = 538.599976 pos = 37.5059,140.2200 diff = 166.400024'
});
data_peak.push({
lat: 3.7523111110e+01,
lng: 1.4028477778e+02,
cert : true,
content:'Name = JA/FS-138(JA/FS-138) peak = 764.299988 pos = 37.5231,140.2848 diff = 224.200012'
});
data_saddle.push({
lat: 3.7535999999e+01,
lng: 1.4028655556e+02,
content:'Saddle = 540.099976 pos = 37.5360,140.2866 diff = 224.200012'
});
data_peak.push({
lat: 3.8004888888e+01,
lng: 1.4052622222e+02,
cert : false,
content:' Peak = 818.500000 pos = 38.0049,140.5262 diff = 275.500000'
});
data_saddle.push({
lat: 3.8010000000e+01,
lng: 1.4051311111e+02,
content:'Saddle = 543.000000 pos = 38.0100,140.5131 diff = 275.500000'
});
data_peak.push({
lat: 3.8359666666e+01,
lng: 1.4062666667e+02,
cert : true,
content:'Name = JA/MG-029(JA/MG-029) peak = 780.799988 pos = 38.3597,140.6267 diff = 232.500000'
});
data_saddle.push({
lat: 3.8368333333e+01,
lng: 1.4062955556e+02,
content:'Saddle = 548.299988 pos = 38.3683,140.6296 diff = 232.500000'
});
data_peak.push({
lat: 3.8143777777e+01,
lng: 1.4043988889e+02,
cert : true,
content:'Name = Zaouzan (Kumanodake)(JA/YM-004) peak = 1840.699951 pos = 38.1438,140.4399 diff = 1292.399902'
});
data_saddle.push({
lat: 3.8017555555e+01,
lng: 1.4028800000e+02,
content:'Saddle = 548.299988 pos = 38.0176,140.2880 diff = 1292.399902'
});
data_peak.push({
lat: 3.8340555555e+01,
lng: 1.4044655556e+02,
cert : false,
content:' Peak = 906.200012 pos = 38.3406,140.4466 diff = 314.700012'
});
data_saddle.push({
lat: 3.8337000000e+01,
lng: 1.4046833333e+02,
content:'Saddle = 591.500000 pos = 38.3370,140.4683 diff = 314.700012'
});
data_peak.push({
lat: 3.8526777778e+01,
lng: 1.4056244444e+02,
cert : true,
content:'Name = JA/YM-065(JA/YM-065) peak = 790.799988 pos = 38.5268,140.5624 diff = 193.700012'
});
data_saddle.push({
lat: 3.8521666667e+01,
lng: 1.4056855556e+02,
content:'Saddle = 597.099976 pos = 38.5217,140.5686 diff = 193.700012'
});
data_peak.push({
lat: 3.8285888889e+01,
lng: 1.4043822222e+02,
cert : false,
content:' Peak = 782.599976 pos = 38.2859,140.4382 diff = 180.500000'
});
data_saddle.push({
lat: 3.8282666666e+01,
lng: 1.4044500000e+02,
content:'Saddle = 602.099976 pos = 38.2827,140.4450 diff = 180.500000'
});
data_peak.push({
lat: 3.8416777778e+01,
lng: 1.4074211111e+02,
cert : false,
content:' Peak = 789.099976 pos = 38.4168,140.7421 diff = 165.500000'
});
data_saddle.push({
lat: 3.8418777778e+01,
lng: 1.4073944444e+02,
content:'Saddle = 623.599976 pos = 38.4188,140.7394 diff = 165.500000'
});
data_peak.push({
lat: 3.8388888889e+01,
lng: 1.4051111111e+02,
cert : false,
content:' Peak = 1002.799988 pos = 38.3889,140.5111 diff = 379.000000'
});
data_saddle.push({
lat: 3.8382888889e+01,
lng: 1.4051355556e+02,
content:'Saddle = 623.799988 pos = 38.3829,140.5136 diff = 379.000000'
});
data_peak.push({
lat: 3.8056222222e+01,
lng: 1.4027700000e+02,
cert : false,
content:' Peak = 805.000000 pos = 38.0562,140.2770 diff = 177.000000'
});
data_saddle.push({
lat: 3.8056555555e+01,
lng: 1.4029688889e+02,
content:'Saddle = 628.000000 pos = 38.0566,140.2969 diff = 177.000000'
});
data_peak.push({
lat: 3.8403333333e+01,
lng: 1.4054622222e+02,
cert : true,
content:'Name = JA/YM-052(JA/YM-052) peak = 905.000000 pos = 38.4033,140.5462 diff = 253.500000'
});
data_saddle.push({
lat: 3.8408111111e+01,
lng: 1.4055500000e+02,
content:'Saddle = 651.500000 pos = 38.4081,140.5550 diff = 253.500000'
});
data_peak.push({
lat: 3.8297777778e+01,
lng: 1.4058522222e+02,
cert : false,
content:' Peak = 862.900024 pos = 38.2978,140.5852 diff = 179.800049'
});
data_saddle.push({
lat: 3.8304000000e+01,
lng: 1.4057455556e+02,
content:'Saddle = 683.099976 pos = 38.3040,140.5746 diff = 179.800049'
});
data_peak.push({
lat: 3.8455333333e+01,
lng: 1.4061966667e+02,
cert : false,
content:' Peak = 1500.099976 pos = 38.4553,140.6197 diff = 799.299988'
});
data_saddle.push({
lat: 3.8389111111e+01,
lng: 1.4057244444e+02,
content:'Saddle = 700.799988 pos = 38.3891,140.5724 diff = 799.299988'
});
data_peak.push({
lat: 3.8487111111e+01,
lng: 1.4044733333e+02,
cert : false,
content:' Peak = 1013.500000 pos = 38.4871,140.4473 diff = 181.700012'
});
data_saddle.push({
lat: 3.8486777778e+01,
lng: 1.4045644444e+02,
content:'Saddle = 831.799988 pos = 38.4868,140.4564 diff = 181.700012'
});
data_peak.push({
lat: 3.8499888889e+01,
lng: 1.4050466667e+02,
cert : false,
content:' Peak = 1056.000000 pos = 38.4999,140.5047 diff = 183.200012'
});
data_saddle.push({
lat: 3.8497666667e+01,
lng: 1.4050833333e+02,
content:'Saddle = 872.799988 pos = 38.4977,140.5083 diff = 183.200012'
});
data_peak.push({
lat: 3.8501111111e+01,
lng: 1.4056577778e+02,
cert : false,
content:' Peak = 1083.099976 pos = 38.5011,140.5658 diff = 176.399963'
});
data_saddle.push({
lat: 3.8495000000e+01,
lng: 1.4057400000e+02,
content:'Saddle = 906.700012 pos = 38.4950,140.5740 diff = 176.399963'
});
data_peak.push({
lat: 3.8491777778e+01,
lng: 1.4058488889e+02,
cert : true,
content:'Name = JA/YM-014(JA/YM-014) peak = 1270.500000 pos = 38.4918,140.5849 diff = 322.900024'
});
data_saddle.push({
lat: 3.8476666667e+01,
lng: 1.4060366667e+02,
content:'Saddle = 947.599976 pos = 38.4767,140.6037 diff = 322.900024'
});
data_peak.push({
lat: 3.8422222222e+01,
lng: 1.4069722222e+02,
cert : false,
content:' Peak = 1252.599976 pos = 38.4222,140.6972 diff = 295.699951'
});
data_saddle.push({
lat: 3.8428888889e+01,
lng: 1.4067988889e+02,
content:'Saddle = 956.900024 pos = 38.4289,140.6799 diff = 295.699951'
});
data_peak.push({
lat: 3.8412111111e+01,
lng: 1.4070866667e+02,
cert : false,
content:' Peak = 1174.500000 pos = 38.4121,140.7087 diff = 152.200012'
});
data_saddle.push({
lat: 3.8415000000e+01,
lng: 1.4070088889e+02,
content:'Saddle = 1022.299988 pos = 38.4150,140.7009 diff = 152.200012'
});
data_peak.push({
lat: 3.8435666667e+01,
lng: 1.4058055556e+02,
cert : true,
content:'Name = JA/MG-008(JA/MG-008) peak = 1294.000000 pos = 38.4357,140.5806 diff = 291.299988'
});
data_saddle.push({
lat: 3.8444444444e+01,
lng: 1.4060600000e+02,
content:'Saddle = 1002.700012 pos = 38.4444,140.6060 diff = 291.299988'
});
data_peak.push({
lat: 3.8451888889e+01,
lng: 1.4056077778e+02,
cert : true,
content:'Name = JA/YM-013(JA/YM-013) peak = 1274.400024 pos = 38.4519,140.5608 diff = 181.599976'
});
data_saddle.push({
lat: 3.8451333333e+01,
lng: 1.4056400000e+02,
content:'Saddle = 1092.800049 pos = 38.4513,140.5640 diff = 181.599976'
});
data_peak.push({
lat: 3.8263333333e+01,
lng: 1.4053966667e+02,
cert : false,
content:' Peak = 970.700012 pos = 38.2633,140.5397 diff = 189.500000'
});
data_saddle.push({
lat: 3.8260555555e+01,
lng: 1.4053555556e+02,
content:'Saddle = 781.200012 pos = 38.2606,140.5356 diff = 189.500000'
});
data_peak.push({
lat: 3.8043444444e+01,
lng: 1.4032677778e+02,
cert : false,
content:' Peak = 1020.500000 pos = 38.0434,140.3268 diff = 157.200012'
});
data_saddle.push({
lat: 3.8047222222e+01,
lng: 1.4031633333e+02,
content:'Saddle = 863.299988 pos = 38.0472,140.3163 diff = 157.200012'
});
data_peak.push({
lat: 3.8302111111e+01,
lng: 1.4052344444e+02,
cert : true,
content:'Name = Daitoudake(JA/MG-005) peak = 1365.400024 pos = 38.3021,140.5234 diff = 456.200012'
});
data_saddle.push({
lat: 3.8228000000e+01,
lng: 1.4046911111e+02,
content:'Saddle = 909.200012 pos = 38.2280,140.4691 diff = 456.200012'
});
data_peak.push({
lat: 3.8348777778e+01,
lng: 1.4052211111e+02,
cert : true,
content:'Name = Omoshiroyama(JA/MG-009) peak = 1263.199951 pos = 38.3488,140.5221 diff = 350.599976'
});
data_saddle.push({
lat: 3.8334666666e+01,
lng: 1.4052533333e+02,
content:'Saddle = 912.599976 pos = 38.3347,140.5253 diff = 350.599976'
});
data_peak.push({
lat: 3.8255666666e+01,
lng: 1.4048544444e+02,
cert : true,
content:'Name = Kamurodake(JA/MG-006) peak = 1353.400024 pos = 38.2557,140.4854 diff = 420.600037'
});
data_saddle.push({
lat: 3.8275888889e+01,
lng: 1.4049011111e+02,
content:'Saddle = 932.799988 pos = 38.2759,140.4901 diff = 420.600037'
});
data_peak.push({
lat: 3.8250888889e+01,
lng: 1.4047111111e+02,
cert : false,
content:' Peak = 1342.900024 pos = 38.2509,140.4711 diff = 160.599976'
});
data_saddle.push({
lat: 3.8253444444e+01,
lng: 1.4047900000e+02,
content:'Saddle = 1182.300049 pos = 38.2534,140.4790 diff = 160.599976'
});
data_peak.push({
lat: 3.8283444444e+01,
lng: 1.4049688889e+02,
cert : true,
content:'Name = JA/MG-012(JA/MG-012) peak = 1226.300049 pos = 38.2834,140.4969 diff = 255.200073'
});
data_saddle.push({
lat: 3.8311111111e+01,
lng: 1.4051277778e+02,
content:'Saddle = 971.099976 pos = 38.3111,140.5128 diff = 255.200073'
});
data_peak.push({
lat: 3.8314222222e+01,
lng: 1.4050400000e+02,
cert : true,
content:'Name = JA/MG-013(JA/MG-013) peak = 1221.699951 pos = 38.3142,140.5040 diff = 238.899963'
});
data_saddle.push({
lat: 3.8298333333e+01,
lng: 1.4049244444e+02,
content:'Saddle = 982.799988 pos = 38.2983,140.4924 diff = 238.899963'
});
data_peak.push({
lat: 3.8057666666e+01,
lng: 1.4037511111e+02,
cert : true,
content:'Name = JA/MG-007(JA/MG-007) peak = 1324.099976 pos = 38.0577,140.3751 diff = 331.299988'
});
data_saddle.push({
lat: 3.8071111111e+01,
lng: 1.4038533333e+02,
content:'Saddle = 992.799988 pos = 38.0711,140.3853 diff = 331.299988'
});
data_peak.push({
lat: 3.8194555555e+01,
lng: 1.4047877778e+02,
cert : true,
content:'Name = JA/MG-004(JA/MG-004) peak = 1484.199951 pos = 38.1946,140.4788 diff = 292.799927'
});
data_saddle.push({
lat: 3.8172666666e+01,
lng: 1.4047144444e+02,
content:'Saddle = 1191.400024 pos = 38.1727,140.4714 diff = 292.799927'
});
data_peak.push({
lat: 3.8183000000e+01,
lng: 1.4039477778e+02,
cert : false,
content:' Peak = 1363.000000 pos = 38.1830,140.3948 diff = 170.000000'
});
data_saddle.push({
lat: 3.8181111111e+01,
lng: 1.4040422222e+02,
content:'Saddle = 1193.000000 pos = 38.1811,140.4042 diff = 170.000000'
});
data_peak.push({
lat: 3.8110111111e+01,
lng: 1.4048966667e+02,
cert : false,
content:' Peak = 1680.199951 pos = 38.1101,140.4897 diff = 175.299927'
});
data_saddle.push({
lat: 3.8107555555e+01,
lng: 1.4048344444e+02,
content:'Saddle = 1504.900024 pos = 38.1076,140.4834 diff = 175.299927'
});
data_peak.push({
lat: 3.8095777777e+01,
lng: 1.4047600000e+02,
cert : true,
content:'Name = Zaouzan (Byoubudake)(JA/MG-001) peak = 1824.300049 pos = 38.0958,140.4760 diff = 287.500000'
});
data_saddle.push({
lat: 3.8117777777e+01,
lng: 1.4045366667e+02,
content:'Saddle = 1536.800049 pos = 38.1178,140.4537 diff = 287.500000'
});
data_peak.push({
lat: 3.7745777777e+01,
lng: 1.3950255556e+02,
cert : true,
content:'Name = JA/NI-058(JA/NI-058) peak = 1024.500000 pos = 37.7458,139.5026 diff = 441.799988'
});
data_saddle.push({
lat: 3.7751333333e+01,
lng: 1.3953000000e+02,
content:'Saddle = 582.700012 pos = 37.7513,139.5300 diff = 441.799988'
});
data_peak.push({
lat: 3.7946888888e+01,
lng: 1.4047477778e+02,
cert : false,
content:' Peak = 835.200012 pos = 37.9469,140.4748 diff = 252.400024'
});
data_saddle.push({
lat: 3.7951111111e+01,
lng: 1.4044966667e+02,
content:'Saddle = 582.799988 pos = 37.9511,140.4497 diff = 252.400024'
});
data_peak.push({
lat: 3.7938222222e+01,
lng: 1.4046733333e+02,
cert : true,
content:'Name = JA/MG-024(JA/MG-024) peak = 828.599976 pos = 37.9382,140.4673 diff = 165.699951'
});
data_saddle.push({
lat: 3.7943444444e+01,
lng: 1.4047144444e+02,
content:'Saddle = 662.900024 pos = 37.9434,140.4714 diff = 165.699951'
});
data_peak.push({
lat: 3.8022000000e+01,
lng: 1.3960744444e+02,
cert : false,
content:' Peak = 800.400024 pos = 38.0220,139.6074 diff = 212.600037'
});
data_saddle.push({
lat: 3.8014000000e+01,
lng: 1.3961333333e+02,
content:'Saddle = 587.799988 pos = 38.0140,139.6133 diff = 212.600037'
});
data_peak.push({
lat: 3.7960555555e+01,
lng: 1.3978955556e+02,
cert : false,
content:' Peak = 770.299988 pos = 37.9606,139.7896 diff = 177.200012'
});
data_saddle.push({
lat: 3.7953999999e+01,
lng: 1.3979233333e+02,
content:'Saddle = 593.099976 pos = 37.9540,139.7923 diff = 177.200012'
});
data_peak.push({
lat: 3.7538666666e+01,
lng: 1.4029866667e+02,
cert : true,
content:'Name = JA/FS-133(JA/FS-133) peak = 792.599976 pos = 37.5387,140.2987 diff = 180.699951'
});
data_saddle.push({
lat: 3.7542333332e+01,
lng: 1.4029155556e+02,
content:'Saddle = 611.900024 pos = 37.5423,140.2916 diff = 180.699951'
});
data_peak.push({
lat: 3.7728777777e+01,
lng: 1.3960000000e+02,
cert : false,
content:' Peak = 785.500000 pos = 37.7288,139.6000 diff = 171.900024'
});
data_saddle.push({
lat: 3.7728777777e+01,
lng: 1.3960900000e+02,
content:'Saddle = 613.599976 pos = 37.7288,139.6090 diff = 171.900024'
});
data_peak.push({
lat: 3.7994666666e+01,
lng: 1.4038900000e+02,
cert : true,
content:'Name = JA/MG-015(JA/MG-015) peak = 1083.900024 pos = 37.9947,140.3890 diff = 445.800049'
});
data_saddle.push({
lat: 3.7987666666e+01,
lng: 1.4031755556e+02,
content:'Saddle = 638.099976 pos = 37.9877,140.3176 diff = 445.800049'
});
data_peak.push({
lat: 3.7972333333e+01,
lng: 1.4037177778e+02,
cert : true,
content:'Name = JA/MG-021(JA/MG-021) peak = 902.400024 pos = 37.9723,140.3718 diff = 262.200012'
});
data_saddle.push({
lat: 3.7980444444e+01,
lng: 1.4037377778e+02,
content:'Saddle = 640.200012 pos = 37.9804,140.3738 diff = 262.200012'
});
data_peak.push({
lat: 3.7960333333e+01,
lng: 1.4042077778e+02,
cert : true,
content:'Name = JA/FS-118(JA/FS-118) peak = 863.900024 pos = 37.9603,140.4208 diff = 186.900024'
});
data_saddle.push({
lat: 3.7961888888e+01,
lng: 1.4041655556e+02,
content:'Saddle = 677.000000 pos = 37.9619,140.4166 diff = 186.900024'
});
data_peak.push({
lat: 3.7911999999e+01,
lng: 1.3981200000e+02,
cert : true,
content:'Name = JA/YM-054(JA/YM-054) peak = 897.900024 pos = 37.9120,139.8120 diff = 251.000000'
});
data_saddle.push({
lat: 3.7905333333e+01,
lng: 1.3980755556e+02,
content:'Saddle = 646.900024 pos = 37.9053,139.8076 diff = 251.000000'
});
data_peak.push({
lat: 3.7937333333e+01,
lng: 1.3967322222e+02,
cert : true,
content:'Name = JA/YM-050(JA/YM-050) peak = 952.099976 pos = 37.9373,139.6732 diff = 300.000000'
});
data_saddle.push({
lat: 3.7926333333e+01,
lng: 1.3968466667e+02,
content:'Saddle = 652.099976 pos = 37.9263,139.6847 diff = 300.000000'
});
data_peak.push({
lat: 3.7496777777e+01,
lng: 1.4017288889e+02,
cert : false,
content:' Peak = 854.099976 pos = 37.4968,140.1729 diff = 191.000000'
});
data_saddle.push({
lat: 3.7493999999e+01,
lng: 1.4018411111e+02,
content:'Saddle = 663.099976 pos = 37.4940,140.1841 diff = 191.000000'
});
data_peak.push({
lat: 3.7886444444e+01,
lng: 1.4038188889e+02,
cert : false,
content:' Peak = 893.000000 pos = 37.8864,140.3819 diff = 221.500000'
});
data_saddle.push({
lat: 3.7884888888e+01,
lng: 1.4036955556e+02,
content:'Saddle = 671.500000 pos = 37.8849,140.3696 diff = 221.500000'
});
data_peak.push({
lat: 3.7961111111e+01,
lng: 1.3951411111e+02,
cert : true,
content:'Name = JA/NI-072(JA/NI-072) peak = 930.599976 pos = 37.9611,139.5141 diff = 253.699951'
});
data_saddle.push({
lat: 3.7948666666e+01,
lng: 1.3951833333e+02,
content:'Saddle = 676.900024 pos = 37.9487,139.5183 diff = 253.699951'
});
data_peak.push({
lat: 3.7736555555e+01,
lng: 1.3972711111e+02,
cert : true,
content:'Name = JA/FS-094(JA/FS-094) peak = 952.700012 pos = 37.7366,139.7271 diff = 263.799988'
});
data_saddle.push({
lat: 3.7765222222e+01,
lng: 1.3973533333e+02,
content:'Saddle = 688.900024 pos = 37.7652,139.7353 diff = 263.799988'
});
data_peak.push({
lat: 3.7501111110e+01,
lng: 1.4018944444e+02,
cert : false,
content:' Peak = 862.000000 pos = 37.5011,140.1894 diff = 169.900024'
});
data_saddle.push({
lat: 3.7506333332e+01,
lng: 1.4018833333e+02,
content:'Saddle = 692.099976 pos = 37.5063,140.1883 diff = 169.900024'
});
data_peak.push({
lat: 3.7796999999e+01,
lng: 1.3948155556e+02,
cert : true,
content:'Name = JA/NI-078(JA/NI-078) peak = 856.299988 pos = 37.7970,139.4816 diff = 163.599976'
});
data_saddle.push({
lat: 3.7795555555e+01,
lng: 1.3948766667e+02,
content:'Saddle = 692.700012 pos = 37.7956,139.4877 diff = 163.599976'
});
data_peak.push({
lat: 3.7953999999e+01,
lng: 1.3976211111e+02,
cert : false,
content:' Peak = 931.200012 pos = 37.9540,139.7621 diff = 218.500000'
});
data_saddle.push({
lat: 3.7954222222e+01,
lng: 1.3975588889e+02,
content:'Saddle = 712.700012 pos = 37.9542,139.7559 diff = 218.500000'
});
data_peak.push({
lat: 3.7968111111e+01,
lng: 1.3974877778e+02,
cert : true,
content:'Name = JA/YM-045(JA/YM-045) peak = 980.200012 pos = 37.9681,139.7488 diff = 263.799988'
});
data_saddle.push({
lat: 3.7932111111e+01,
lng: 1.3975055556e+02,
content:'Saddle = 716.400024 pos = 37.9321,139.7506 diff = 263.799988'
});
data_peak.push({
lat: 3.7767555555e+01,
lng: 1.3977522222e+02,
cert : false,
content:' Peak = 893.500000 pos = 37.7676,139.7752 diff = 175.900024'
});
data_saddle.push({
lat: 3.7777555555e+01,
lng: 1.3976844444e+02,
content:'Saddle = 717.599976 pos = 37.7776,139.7684 diff = 175.900024'
});
data_peak.push({
lat: 3.7873888888e+01,
lng: 1.4033988889e+02,
cert : false,
content:' Peak = 900.500000 pos = 37.8739,140.3399 diff = 168.099976'
});
data_saddle.push({
lat: 3.7861888888e+01,
lng: 1.4032977778e+02,
content:'Saddle = 732.400024 pos = 37.8619,140.3298 diff = 168.099976'
});
data_peak.push({
lat: 3.7746111110e+01,
lng: 1.3965855556e+02,
cert : true,
content:'Name = JA/FS-054(JA/FS-054) peak = 1150.599976 pos = 37.7461,139.6586 diff = 402.799988'
});
data_saddle.push({
lat: 3.7771222222e+01,
lng: 1.3967788889e+02,
content:'Saddle = 747.799988 pos = 37.7712,139.6779 diff = 402.799988'
});
data_peak.push({
lat: 3.7901222222e+01,
lng: 1.4029833333e+02,
cert : false,
content:' Peak = 1216.800049 pos = 37.9012,140.2983 diff = 460.700073'
});
data_saddle.push({
lat: 3.7809555555e+01,
lng: 1.4025066667e+02,
content:'Saddle = 756.099976 pos = 37.8096,140.2507 diff = 460.700073'
});
data_peak.push({
lat: 3.7864555555e+01,
lng: 1.4029044444e+02,
cert : true,
content:'Name = JA/FS-089(JA/FS-089) peak = 962.599976 pos = 37.8646,140.2904 diff = 192.199951'
});
data_saddle.push({
lat: 3.7858111110e+01,
lng: 1.4028422222e+02,
content:'Saddle = 770.400024 pos = 37.8581,140.2842 diff = 192.199951'
});
data_peak.push({
lat: 3.7853666666e+01,
lng: 1.4030622222e+02,
cert : true,
content:'Name = JA/FS-075(JA/FS-075) peak = 988.200012 pos = 37.8537,140.3062 diff = 206.100037'
});
data_saddle.push({
lat: 3.7844999999e+01,
lng: 1.4029677778e+02,
content:'Saddle = 782.099976 pos = 37.8450,140.2968 diff = 206.100037'
});
data_peak.push({
lat: 3.7978555555e+01,
lng: 1.4027866667e+02,
cert : true,
content:'Name = JA/FS-072(JA/FS-072) peak = 993.200012 pos = 37.9786,140.2787 diff = 200.000000'
});
data_saddle.push({
lat: 3.7970555555e+01,
lng: 1.4027300000e+02,
content:'Saddle = 793.200012 pos = 37.9706,140.2730 diff = 200.000000'
});
data_peak.push({
lat: 3.7830111110e+01,
lng: 1.4024655556e+02,
cert : false,
content:' Peak = 1004.799988 pos = 37.8301,140.2466 diff = 157.599976'
});
data_saddle.push({
lat: 3.7835666666e+01,
lng: 1.4025511111e+02,
content:'Saddle = 847.200012 pos = 37.8357,140.2551 diff = 157.599976'
});
data_peak.push({
lat: 3.7874444444e+01,
lng: 1.4026988889e+02,
cert : false,
content:' Peak = 1216.400024 pos = 37.8744,140.2699 diff = 164.800049'
});
data_saddle.push({
lat: 3.7895999999e+01,
lng: 1.4029111111e+02,
content:'Saddle = 1051.599976 pos = 37.8960,140.2911 diff = 164.800049'
});
data_peak.push({
lat: 3.7975777777e+01,
lng: 1.3964188889e+02,
cert : true,
content:'Name = JA/YM-022(JA/YM-022) peak = 1113.000000 pos = 37.9758,139.6419 diff = 320.900024'
});
data_saddle.push({
lat: 3.7956888888e+01,
lng: 1.3964200000e+02,
content:'Saddle = 792.099976 pos = 37.9569,139.6420 diff = 320.900024'
});
data_peak.push({
lat: 3.7995222222e+01,
lng: 1.3964344444e+02,
cert : true,
content:'Name = JA/YM-023(JA/YM-023) peak = 1101.300049 pos = 37.9952,139.6434 diff = 244.300049'
});
data_saddle.push({
lat: 3.7985888888e+01,
lng: 1.3963933333e+02,
content:'Saddle = 857.000000 pos = 37.9859,139.6393 diff = 244.300049'
});
data_peak.push({
lat: 3.7776333333e+01,
lng: 1.3958811111e+02,
cert : true,
content:'Name = JA/NI-053(JA/NI-053) peak = 1066.500000 pos = 37.7763,139.5881 diff = 273.599976'
});
data_saddle.push({
lat: 3.7785222222e+01,
lng: 1.3959255556e+02,
content:'Saddle = 792.900024 pos = 37.7852,139.5926 diff = 273.599976'
});
data_peak.push({
lat: 3.7955444444e+01,
lng: 1.3956244444e+02,
cert : false,
content:' Peak = 972.900024 pos = 37.9554,139.5624 diff = 160.700012'
});
data_saddle.push({
lat: 3.7947111111e+01,
lng: 1.3956266667e+02,
content:'Saddle = 812.200012 pos = 37.9471,139.5627 diff = 160.700012'
});
data_peak.push({
lat: 3.7646222221e+01,
lng: 1.4013444444e+02,
cert : true,
content:'Name = JA/FS-046(JA/FS-046) peak = 1220.300049 pos = 37.6462,140.1344 diff = 402.300049'
});
data_saddle.push({
lat: 3.7639555555e+01,
lng: 1.4017044444e+02,
content:'Saddle = 818.000000 pos = 37.6396,140.1704 diff = 402.300049'
});
data_peak.push({
lat: 3.7600999999e+01,
lng: 1.4007211111e+02,
cert : false,
content:' Peak = 1814.800049 pos = 37.6010,140.0721 diff = 947.200073'
});
data_saddle.push({
lat: 3.7676444444e+01,
lng: 1.4003800000e+02,
content:'Saddle = 867.599976 pos = 37.6764,140.0380 diff = 947.200073'
});
data_peak.push({
lat: 3.7611666666e+01,
lng: 1.4002833333e+02,
cert : true,
content:'Name = JA/FS-033(JA/FS-033) peak = 1402.699951 pos = 37.6117,140.0283 diff = 208.099976'
});
data_saddle.push({
lat: 3.7614888888e+01,
lng: 1.4004811111e+02,
content:'Saddle = 1194.599976 pos = 37.6149,140.0481 diff = 208.099976'
});
data_peak.push({
lat: 3.7609666666e+01,
lng: 1.4008544444e+02,
cert : false,
content:' Peak = 1634.599976 pos = 37.6097,140.0854 diff = 182.900024'
});
data_saddle.push({
lat: 3.7609333333e+01,
lng: 1.4008044444e+02,
content:'Saddle = 1451.699951 pos = 37.6093,140.0804 diff = 182.900024'
});
data_peak.push({
lat: 3.7600444444e+01,
lng: 1.4022000000e+02,
cert : false,
content:' Peak = 1074.500000 pos = 37.6004,140.2200 diff = 163.200012'
});
data_saddle.push({
lat: 3.7600999999e+01,
lng: 1.4023155556e+02,
content:'Saddle = 911.299988 pos = 37.6010,140.2316 diff = 163.200012'
});
data_peak.push({
lat: 3.7598444444e+01,
lng: 1.4019422222e+02,
cert : true,
content:'Name = JA/FS-050(JA/FS-050) peak = 1171.099976 pos = 37.5984,140.1942 diff = 229.399963'
});
data_saddle.push({
lat: 3.7593555555e+01,
lng: 1.4019933333e+02,
content:'Saddle = 941.700012 pos = 37.5936,140.1993 diff = 229.399963'
});
data_peak.push({
lat: 3.7691555555e+01,
lng: 1.4002411111e+02,
cert : true,
content:'Name = JA/FS-055(JA/FS-055) peak = 1144.599976 pos = 37.6916,140.0241 diff = 196.899963'
});
data_saddle.push({
lat: 3.7702777777e+01,
lng: 1.4002344444e+02,
content:'Saddle = 947.700012 pos = 37.7028,140.0234 diff = 196.899963'
});
data_peak.push({
lat: 3.7807666666e+01,
lng: 1.4002122222e+02,
cert : true,
content:'Name = JA/YM-020(JA/YM-020) peak = 1137.400024 pos = 37.8077,140.0212 diff = 185.200012'
});
data_saddle.push({
lat: 3.7804333333e+01,
lng: 1.4001544444e+02,
content:'Saddle = 952.200012 pos = 37.8043,140.0154 diff = 185.200012'
});
data_peak.push({
lat: 3.7558222221e+01,
lng: 1.4017711111e+02,
cert : true,
content:'Name = JA/FS-032(JA/FS-032) peak = 1412.300049 pos = 37.5582,140.1771 diff = 445.700073'
});
data_saddle.push({
lat: 3.7593444444e+01,
lng: 1.4024277778e+02,
content:'Saddle = 966.599976 pos = 37.5934,140.2428 diff = 445.700073'
});
data_peak.push({
lat: 3.7557444444e+01,
lng: 1.4020133333e+02,
cert : true,
content:'Name = JA/FS-036(JA/FS-036) peak = 1370.199951 pos = 37.5574,140.2013 diff = 213.799927'
});
data_saddle.push({
lat: 3.7554999999e+01,
lng: 1.4018177778e+02,
content:'Saddle = 1156.400024 pos = 37.5550,140.1818 diff = 213.799927'
});
data_peak.push({
lat: 3.7795555555e+01,
lng: 1.3952788889e+02,
cert : true,
content:'Name = JA/NI-034(JA/NI-034) peak = 1360.900024 pos = 37.7956,139.5279 diff = 392.900024'
});
data_saddle.push({
lat: 3.7805777777e+01,
lng: 1.3955277778e+02,
content:'Saddle = 968.000000 pos = 37.8058,139.5528 diff = 392.900024'
});
data_peak.push({
lat: 3.7738111110e+01,
lng: 1.4014077778e+02,
cert : true,
content:'Name = Nishiadumayama(JA/FS-003) peak = 2034.599976 pos = 37.7381,140.1408 diff = 1062.099976'
});
data_saddle.push({
lat: 3.7803888888e+01,
lng: 1.3981211111e+02,
content:'Saddle = 972.500000 pos = 37.8039,139.8121 diff = 1062.099976'
});
data_peak.push({
lat: 3.7755888888e+01,
lng: 1.3995677778e+02,
cert : false,
content:' Peak = 1153.300049 pos = 37.7559,139.9568 diff = 152.200073'
});
data_saddle.push({
lat: 3.7755999999e+01,
lng: 1.3996277778e+02,
content:'Saddle = 1001.099976 pos = 37.7560,139.9628 diff = 152.200073'
});
data_peak.push({
lat: 3.7825777777e+01,
lng: 1.3998400000e+02,
cert : false,
content:' Peak = 1226.599976 pos = 37.8258,139.9840 diff = 175.599976'
});
data_saddle.push({
lat: 3.7824111110e+01,
lng: 1.3997822222e+02,
content:'Saddle = 1051.000000 pos = 37.8241,139.9782 diff = 175.599976'
});
data_peak.push({
lat: 3.7813888888e+01,
lng: 1.3992544444e+02,
cert : true,
content:'Name = Iimorisan(JA/FS-018) peak = 1594.500000 pos = 37.8139,139.9254 diff = 528.699951'
});
data_saddle.push({
lat: 3.7770555555e+01,
lng: 1.4004077778e+02,
content:'Saddle = 1065.800049 pos = 37.7706,140.0408 diff = 528.699951'
});
data_peak.push({
lat: 3.7820444444e+01,
lng: 1.3984688889e+02,
cert : false,
content:' Peak = 1321.599976 pos = 37.8204,139.8469 diff = 208.900024'
});
data_saddle.push({
lat: 3.7825111110e+01,
lng: 1.3986300000e+02,
content:'Saddle = 1112.699951 pos = 37.8251,139.8630 diff = 208.900024'
});
data_peak.push({
lat: 3.7722444444e+01,
lng: 1.3999755556e+02,
cert : true,
content:'Name = JA/FS-028(JA/FS-028) peak = 1442.199951 pos = 37.7224,139.9976 diff = 320.799927'
});
data_saddle.push({
lat: 3.7805777777e+01,
lng: 1.3996211111e+02,
content:'Saddle = 1121.400024 pos = 37.8058,139.9621 diff = 320.799927'
});
data_peak.push({
lat: 3.7657888888e+01,
lng: 1.4022688889e+02,
cert : false,
content:' Peak = 1248.699951 pos = 37.6579,140.2269 diff = 181.099976'
});
data_saddle.push({
lat: 3.7661555555e+01,
lng: 1.4023188889e+02,
content:'Saddle = 1067.599976 pos = 37.6616,140.2319 diff = 181.099976'
});
data_peak.push({
lat: 3.7647111110e+01,
lng: 1.4028077778e+02,
cert : true,
content:'Name = Minowayama(JA/FS-012) peak = 1727.500000 pos = 37.6471,140.2808 diff = 489.900024'
});
data_saddle.push({
lat: 3.7668333333e+01,
lng: 1.4025600000e+02,
content:'Saddle = 1237.599976 pos = 37.6683,140.2560 diff = 489.900024'
});
data_peak.push({
lat: 3.7700444444e+01,
lng: 1.4025711111e+02,
cert : true,
content:'Name = JA/FS-010(JA/FS-010) peak = 1806.300049 pos = 37.7004,140.2571 diff = 202.300049'
});
data_saddle.push({
lat: 3.7704999999e+01,
lng: 1.4024877778e+02,
content:'Saddle = 1604.000000 pos = 37.7050,140.2488 diff = 202.300049'
});
data_peak.push({
lat: 3.7724666666e+01,
lng: 1.4018711111e+02,
cert : false,
content:' Peak = 1931.699951 pos = 37.7247,140.1871 diff = 172.899902'
});
data_saddle.push({
lat: 3.7741999999e+01,
lng: 1.4018666667e+02,
content:'Saddle = 1758.800049 pos = 37.7420,140.1867 diff = 172.899902'
});
data_peak.push({
lat: 3.7711777777e+01,
lng: 1.4023022222e+02,
cert : true,
content:'Name = Higashiadumayama(JA/FS-004) peak = 1974.199951 pos = 37.7118,140.2302 diff = 200.799927'
});
data_saddle.push({
lat: 3.7740111110e+01,
lng: 1.4024022222e+02,
content:'Saddle = 1773.400024 pos = 37.7401,140.2402 diff = 200.799927'
});
data_peak.push({
lat: 3.7735444444e+01,
lng: 1.4024433333e+02,
cert : false,
content:' Peak = 1948.099976 pos = 37.7354,140.2443 diff = 170.799927'
});
data_saddle.push({
lat: 3.7721555555e+01,
lng: 1.4023044444e+02,
content:'Saddle = 1777.300049 pos = 37.7216,140.2304 diff = 170.799927'
});
data_peak.push({
lat: 3.7838777777e+01,
lng: 1.3984277778e+02,
cert : false,
content:' Peak = 1162.599976 pos = 37.8388,139.8428 diff = 161.399963'
});
data_saddle.push({
lat: 3.7825111110e+01,
lng: 1.3981822222e+02,
content:'Saddle = 1001.200012 pos = 37.8251,139.8182 diff = 161.399963'
});
data_peak.push({
lat: 3.7839111110e+01,
lng: 1.3950722222e+02,
cert : false,
content:' Peak = 1167.800049 pos = 37.8391,139.5072 diff = 155.400024'
});
data_saddle.push({
lat: 3.7841555555e+01,
lng: 1.3951344444e+02,
content:'Saddle = 1012.400024 pos = 37.8416,139.5134 diff = 155.400024'
});
data_peak.push({
lat: 3.7892111111e+01,
lng: 1.3950444444e+02,
cert : true,
content:'Name = JA/NI-031(JA/NI-031) peak = 1423.000000 pos = 37.8921,139.5044 diff = 400.900024'
});
data_saddle.push({
lat: 3.7887222222e+01,
lng: 1.3952366667e+02,
content:'Saddle = 1022.099976 pos = 37.8872,139.5237 diff = 400.900024'
});
data_peak.push({
lat: 3.7803111110e+01,
lng: 1.3961822222e+02,
cert : false,
content:' Peak = 1235.300049 pos = 37.8031,139.6182 diff = 162.900024'
});
data_saddle.push({
lat: 3.7805555555e+01,
lng: 1.3961033333e+02,
content:'Saddle = 1072.400024 pos = 37.8056,139.6103 diff = 162.900024'
});
data_peak.push({
lat: 3.7863444444e+01,
lng: 1.3955455556e+02,
cert : false,
content:' Peak = 1402.900024 pos = 37.8634,139.5546 diff = 176.700073'
});
data_saddle.push({
lat: 3.7862444444e+01,
lng: 1.3957766667e+02,
content:'Saddle = 1226.199951 pos = 37.8624,139.5777 diff = 176.700073'
});
data_peak.push({
lat: 3.7813777777e+01,
lng: 1.3959722222e+02,
cert : false,
content:' Peak = 1572.000000 pos = 37.8138,139.5972 diff = 162.000000'
});
data_saddle.push({
lat: 3.7824444444e+01,
lng: 1.3961022222e+02,
content:'Saddle = 1410.000000 pos = 37.8244,139.6102 diff = 162.000000'
});
data_peak.push({
lat: 3.7942666666e+01,
lng: 1.3960877778e+02,
cert : true,
content:'Name = Eburisashidake(JA/NI-019) peak = 1636.099976 pos = 37.9427,139.6088 diff = 213.000000'
});
data_saddle.push({
lat: 3.7931333333e+01,
lng: 1.3960888889e+02,
content:'Saddle = 1423.099976 pos = 37.9313,139.6089 diff = 213.000000'
});
data_peak.push({
lat: 3.7879999999e+01,
lng: 1.3963855556e+02,
cert : true,
content:'Name = Kitamatadake(JA/NI-011) peak = 2023.699951 pos = 37.8800,139.6386 diff = 221.399902'
});
data_saddle.push({
lat: 3.7857222222e+01,
lng: 1.3966855556e+02,
content:'Saddle = 1802.300049 pos = 37.8572,139.6686 diff = 221.399902'
});
data_peak.push({
lat: 3.7872444444e+01,
lng: 1.3965477778e+02,
cert : false,
content:' Peak = 2012.800049 pos = 37.8724,139.6548 diff = 159.700073'
});
data_saddle.push({
lat: 3.7877888888e+01,
lng: 1.3964400000e+02,
content:'Saddle = 1853.099976 pos = 37.8779,139.6440 diff = 159.700073'
});
data_peak.push({
lat: 3.7854888888e+01,
lng: 1.3970700000e+02,
cert : true,
content:'Name = Iidesan(JA/NI-008) peak = 2104.300049 pos = 37.8549,139.7070 diff = 226.200073'
});
data_saddle.push({
lat: 3.7842222222e+01,
lng: 1.3967722222e+02,
content:'Saddle = 1878.099976 pos = 37.8422,139.6772 diff = 226.200073'
});
data_peak.push({
lat: 3.7402111110e+01,
lng: 1.4007788889e+02,
cert : false,
content:' Peak = 710.799988 pos = 37.4021,140.0779 diff = 168.000000'
});
data_saddle.push({
lat: 3.7395666666e+01,
lng: 1.4007611111e+02,
content:'Saddle = 542.799988 pos = 37.3957,140.0761 diff = 168.000000'
});
data_peak.push({
lat: 3.7350222221e+01,
lng: 1.4021877778e+02,
cert : true,
content:'Name = JA/FS-137(JA/FS-137) peak = 774.299988 pos = 37.3502,140.2188 diff = 227.200012'
});
data_saddle.push({
lat: 3.7358555555e+01,
lng: 1.4022222222e+02,
content:'Saddle = 547.099976 pos = 37.3586,140.2222 diff = 227.200012'
});
data_peak.push({
lat: 3.7471666666e+01,
lng: 1.3961544444e+02,
cert : true,
content:'Name = JA/FS-124(JA/FS-124) peak = 831.700012 pos = 37.4717,139.6154 diff = 265.299988'
});
data_saddle.push({
lat: 3.7494333332e+01,
lng: 1.3961877778e+02,
content:'Saddle = 566.400024 pos = 37.4943,139.6188 diff = 265.299988'
});
data_peak.push({
lat: 3.7388555555e+01,
lng: 1.3933544444e+02,
cert : false,
content:' Peak = 827.000000 pos = 37.3886,139.3354 diff = 244.400024'
});
data_saddle.push({
lat: 3.7403666666e+01,
lng: 1.3933188889e+02,
content:'Saddle = 582.599976 pos = 37.4037,139.3319 diff = 244.400024'
});
data_peak.push({
lat: 3.7664666666e+01,
lng: 1.3932244444e+02,
cert : true,
content:'Name = JA/NI-077(JA/NI-077) peak = 864.799988 pos = 37.6647,139.3224 diff = 275.000000'
});
data_saddle.push({
lat: 3.7638999999e+01,
lng: 1.3932877778e+02,
content:'Saddle = 589.799988 pos = 37.6390,139.3288 diff = 275.000000'
});
data_peak.push({
lat: 3.7350222221e+01,
lng: 1.3930033333e+02,
cert : false,
content:' Peak = 760.599976 pos = 37.3502,139.3003 diff = 168.500000'
});
data_saddle.push({
lat: 3.7345999999e+01,
lng: 1.3929211111e+02,
content:'Saddle = 592.099976 pos = 37.3460,139.2921 diff = 168.500000'
});
data_peak.push({
lat: 3.7334111110e+01,
lng: 1.3942555556e+02,
cert : false,
content:' Peak = 963.500000 pos = 37.3341,139.4256 diff = 370.700012'
});
data_saddle.push({
lat: 3.7350111110e+01,
lng: 1.3947877778e+02,
content:'Saddle = 592.799988 pos = 37.3501,139.4788 diff = 370.700012'
});
data_peak.push({
lat: 3.7361999999e+01,
lng: 1.3933522222e+02,
cert : true,
content:'Name = JA/FS-117(JA/FS-117) peak = 870.700012 pos = 37.3620,139.3352 diff = 242.200012'
});
data_saddle.push({
lat: 3.7355111110e+01,
lng: 1.3935555556e+02,
content:'Saddle = 628.500000 pos = 37.3551,139.3556 diff = 242.200012'
});
data_peak.push({
lat: 3.7381555555e+01,
lng: 1.3936144444e+02,
cert : false,
content:' Peak = 912.700012 pos = 37.3816,139.3614 diff = 210.200012'
});
data_saddle.push({
lat: 3.7375555555e+01,
lng: 1.3936933333e+02,
content:'Saddle = 702.500000 pos = 37.3756,139.3693 diff = 210.200012'
});
data_peak.push({
lat: 3.7356555555e+01,
lng: 1.3939411111e+02,
cert : true,
content:'Name = JA/FS-103(JA/FS-103) peak = 911.500000 pos = 37.3566,139.3941 diff = 179.900024'
});
data_saddle.push({
lat: 3.7350111110e+01,
lng: 1.3940600000e+02,
content:'Saddle = 731.599976 pos = 37.3501,139.4060 diff = 179.900024'
});
data_peak.push({
lat: 3.7391111110e+01,
lng: 1.4011255556e+02,
cert : false,
content:' Peak = 752.599976 pos = 37.3911,140.1126 diff = 154.399963'
});
data_saddle.push({
lat: 3.7386888888e+01,
lng: 1.4010077778e+02,
content:'Saddle = 598.200012 pos = 37.3869,140.1008 diff = 154.399963'
});
data_peak.push({
lat: 3.7387222221e+01,
lng: 1.3994644444e+02,
cert : false,
content:' Peak = 770.799988 pos = 37.3872,139.9464 diff = 171.399963'
});
data_saddle.push({
lat: 3.7394666666e+01,
lng: 1.3995555556e+02,
content:'Saddle = 599.400024 pos = 37.3947,139.9556 diff = 171.399963'
});
data_peak.push({
lat: 3.7614444444e+01,
lng: 1.3919500000e+02,
cert : true,
content:'Name = JA/NI-061(JA/NI-061) peak = 1011.900024 pos = 37.6144,139.1950 diff = 410.000000'
});
data_saddle.push({
lat: 3.7586444444e+01,
lng: 1.3917700000e+02,
content:'Saddle = 601.900024 pos = 37.5864,139.1770 diff = 410.000000'
});
data_peak.push({
lat: 3.7409888888e+01,
lng: 1.3994900000e+02,
cert : false,
content:' Peak = 760.500000 pos = 37.4099,139.9490 diff = 157.299988'
});
data_saddle.push({
lat: 3.7413111110e+01,
lng: 1.3995622222e+02,
content:'Saddle = 603.200012 pos = 37.4131,139.9562 diff = 157.299988'
});
data_peak.push({
lat: 3.7460444444e+01,
lng: 1.3955811111e+02,
cert : true,
content:'Name = JA/FS-130(JA/FS-130) peak = 812.900024 pos = 37.4604,139.5581 diff = 209.600037'
});
data_saddle.push({
lat: 3.7450666666e+01,
lng: 1.3955822222e+02,
content:'Saddle = 603.299988 pos = 37.4507,139.5582 diff = 209.600037'
});
data_peak.push({
lat: 3.6823111110e+01,
lng: 1.3974966667e+02,
cert : false,
content:' Peak = 773.500000 pos = 36.8231,139.7497 diff = 170.099976'
});
data_saddle.push({
lat: 3.6827777776e+01,
lng: 1.3974188889e+02,
content:'Saddle = 603.400024 pos = 36.8278,139.7419 diff = 170.099976'
});
data_peak.push({
lat: 3.7422333332e+01,
lng: 1.3958633333e+02,
cert : true,
content:'Name = JA/FS-059(JA/FS-059) peak = 1091.900024 pos = 37.4223,139.5863 diff = 480.000000'
});
data_saddle.push({
lat: 3.7392444443e+01,
lng: 1.3960088889e+02,
content:'Saddle = 611.900024 pos = 37.3924,139.6009 diff = 480.000000'
});
data_peak.push({
lat: 3.7444666666e+01,
lng: 1.3956611111e+02,
cert : true,
content:'Name = JA/FS-123(JA/FS-123) peak = 834.299988 pos = 37.4447,139.5661 diff = 202.700012'
});
data_saddle.push({
lat: 3.7438444443e+01,
lng: 1.3956855556e+02,
content:'Saddle = 631.599976 pos = 37.4384,139.5686 diff = 202.700012'
});
data_peak.push({
lat: 3.7261444443e+01,
lng: 1.3907477778e+02,
cert : true,
content:'Name = JA/NI-052(JA/NI-052) peak = 1076.000000 pos = 37.2614,139.0748 diff = 455.000000'
});
data_saddle.push({
lat: 3.7227222221e+01,
lng: 1.3911811111e+02,
content:'Saddle = 621.000000 pos = 37.2272,139.1181 diff = 455.000000'
});
data_peak.push({
lat: 3.7300666666e+01,
lng: 1.3908922222e+02,
cert : true,
content:'Name = JA/NI-071(JA/NI-071) peak = 933.200012 pos = 37.3007,139.0892 diff = 201.200012'
});
data_saddle.push({
lat: 3.7266999999e+01,
lng: 1.3908855556e+02,
content:'Saddle = 732.000000 pos = 37.2670,139.0886 diff = 201.200012'
});
data_peak.push({
lat: 3.7268999999e+01,
lng: 1.3904255556e+02,
cert : true,
content:'Name = JA/NI-063(JA/NI-063) peak = 996.700012 pos = 37.2690,139.0426 diff = 243.799988'
});
data_saddle.push({
lat: 3.7266111110e+01,
lng: 1.3905044444e+02,
content:'Saddle = 752.900024 pos = 37.2661,139.0504 diff = 243.799988'
});
data_peak.push({
lat: 3.7427111110e+01,
lng: 1.4006188889e+02,
cert : false,
content:' Peak = 802.200012 pos = 37.4271,140.0619 diff = 175.500000'
});
data_saddle.push({
lat: 3.7412999999e+01,
lng: 1.4005077778e+02,
content:'Saddle = 626.700012 pos = 37.4130,140.0508 diff = 175.500000'
});
data_peak.push({
lat: 3.7374666666e+01,
lng: 1.3948533333e+02,
cert : false,
content:' Peak = 960.599976 pos = 37.3747,139.4853 diff = 329.399963'
});
data_saddle.push({
lat: 3.7355333332e+01,
lng: 1.3954733333e+02,
content:'Saddle = 631.200012 pos = 37.3553,139.5473 diff = 329.399963'
});
data_peak.push({
lat: 3.7407999999e+01,
lng: 1.3950077778e+02,
cert : true,
content:'Name = JA/FS-107(JA/FS-107) peak = 893.700012 pos = 37.4080,139.5008 diff = 211.100037'
});
data_saddle.push({
lat: 3.7394777777e+01,
lng: 1.3951255556e+02,
content:'Saddle = 682.599976 pos = 37.3948,139.5126 diff = 211.100037'
});
data_peak.push({
lat: 3.7392222221e+01,
lng: 1.3953666667e+02,
cert : true,
content:'Name = JA/FS-095(JA/FS-095) peak = 942.500000 pos = 37.3922,139.5367 diff = 225.099976'
});
data_saddle.push({
lat: 3.7369222221e+01,
lng: 1.3950255556e+02,
content:'Saddle = 717.400024 pos = 37.3692,139.5026 diff = 225.099976'
});
data_peak.push({
lat: 3.7316999999e+01,
lng: 1.3947244444e+02,
cert : false,
content:' Peak = 792.200012 pos = 37.3170,139.4724 diff = 150.400024'
});
data_saddle.push({
lat: 3.7316888888e+01,
lng: 1.3947911111e+02,
content:'Saddle = 641.799988 pos = 37.3169,139.4791 diff = 150.400024'
});
data_peak.push({
lat: 3.7438555555e+01,
lng: 1.3995544444e+02,
cert : true,
content:'Name = JA/FS-128(JA/FS-128) peak = 818.000000 pos = 37.4386,139.9554 diff = 176.000000'
});
data_saddle.push({
lat: 3.7426444443e+01,
lng: 1.3995966667e+02,
content:'Saddle = 642.000000 pos = 37.4264,139.9597 diff = 176.000000'
});
data_peak.push({
lat: 3.7376444443e+01,
lng: 1.3997322222e+02,
cert : true,
content:'Name = JA/FS-116(JA/FS-116) peak = 872.400024 pos = 37.3764,139.9732 diff = 228.400024'
});
data_saddle.push({
lat: 3.7379999999e+01,
lng: 1.3997655556e+02,
content:'Saddle = 644.000000 pos = 37.3800,139.9766 diff = 228.400024'
});
data_peak.push({
lat: 3.7308444443e+01,
lng: 1.3963344444e+02,
cert : false,
content:' Peak = 810.000000 pos = 37.3084,139.6334 diff = 161.700012'
});
data_saddle.push({
lat: 3.7307222221e+01,
lng: 1.3964044444e+02,
content:'Saddle = 648.299988 pos = 37.3072,139.6404 diff = 161.700012'
});
data_peak.push({
lat: 3.7285555554e+01,
lng: 1.3989588889e+02,
cert : false,
content:' Peak = 853.799988 pos = 37.2856,139.8959 diff = 184.899963'
});
data_saddle.push({
lat: 3.7284777777e+01,
lng: 1.3988500000e+02,
content:'Saddle = 668.900024 pos = 37.2848,139.8850 diff = 184.899963'
});
data_peak.push({
lat: 3.7402555555e+01,
lng: 1.3968677778e+02,
cert : true,
content:'Name = JA/FS-102(JA/FS-102) peak = 910.500000 pos = 37.4026,139.6868 diff = 239.299988'
});
data_saddle.push({
lat: 3.7395888888e+01,
lng: 1.3967422222e+02,
content:'Saddle = 671.200012 pos = 37.3959,139.6742 diff = 239.299988'
});
data_peak.push({
lat: 3.7430666666e+01,
lng: 1.3929800000e+02,
cert : false,
content:' Peak = 823.400024 pos = 37.4307,139.2980 diff = 151.000000'
});
data_saddle.push({
lat: 3.7432222221e+01,
lng: 1.3928933333e+02,
content:'Saddle = 672.400024 pos = 37.4322,139.2893 diff = 151.000000'
});
data_peak.push({
lat: 3.7383666666e+01,
lng: 1.3957522222e+02,
cert : true,
content:'Name = JA/FS-097(JA/FS-097) peak = 925.299988 pos = 37.3837,139.5752 diff = 251.899963'
});
data_saddle.push({
lat: 3.7376999999e+01,
lng: 1.3957944444e+02,
content:'Saddle = 673.400024 pos = 37.3770,139.5794 diff = 251.899963'
});
data_peak.push({
lat: 3.7296888888e+01,
lng: 1.3992133333e+02,
cert : true,
content:'Name = JA/FS-096(JA/FS-096) peak = 940.500000 pos = 37.2969,139.9213 diff = 266.799988'
});
data_saddle.push({
lat: 3.7294333332e+01,
lng: 1.3992711111e+02,
content:'Saddle = 673.700012 pos = 37.2943,139.9271 diff = 266.799988'
});
data_peak.push({
lat: 3.6839333332e+01,
lng: 1.3979333333e+02,
cert : true,
content:'Name = JA/TG-054(JA/TG-054) peak = 891.099976 pos = 36.8393,139.7933 diff = 208.699951'
});
data_saddle.push({
lat: 3.6851444443e+01,
lng: 1.3978888889e+02,
content:'Saddle = 682.400024 pos = 36.8514,139.7889 diff = 208.699951'
});
data_peak.push({
lat: 3.7301222221e+01,
lng: 1.3932500000e+02,
cert : false,
content:' Peak = 842.700012 pos = 37.3012,139.3250 diff = 159.799988'
});
data_saddle.push({
lat: 3.7290111110e+01,
lng: 1.3933288889e+02,
content:'Saddle = 682.900024 pos = 37.2901,139.3329 diff = 159.799988'
});
data_peak.push({
lat: 3.7387333332e+01,
lng: 1.3930311111e+02,
cert : true,
content:'Name = JA/FS-104(JA/FS-104) peak = 902.099976 pos = 37.3873,139.3031 diff = 219.099976'
});
data_saddle.push({
lat: 3.7391888888e+01,
lng: 1.3928377778e+02,
content:'Saddle = 683.000000 pos = 37.3919,139.2838 diff = 219.099976'
});
data_peak.push({
lat: 3.7266555554e+01,
lng: 1.3992822222e+02,
cert : false,
content:' Peak = 843.400024 pos = 37.2666,139.9282 diff = 150.500000'
});
data_saddle.push({
lat: 3.7265333332e+01,
lng: 1.3993266667e+02,
content:'Saddle = 692.900024 pos = 37.2653,139.9327 diff = 150.500000'
});
data_peak.push({
lat: 3.7555222221e+01,
lng: 1.3918866667e+02,
cert : true,
content:'Name = Awagatake(JA/NI-037) peak = 1291.900024 pos = 37.5552,139.1887 diff = 594.400024'
});
data_saddle.push({
lat: 3.7469333332e+01,
lng: 1.3926388889e+02,
content:'Saddle = 697.500000 pos = 37.4693,139.2639 diff = 594.400024'
});
data_peak.push({
lat: 3.7599888888e+01,
lng: 1.3936555556e+02,
cert : true,
content:'Name = JA/NI-048(JA/NI-048) peak = 1105.300049 pos = 37.5999,139.3656 diff = 402.200073'
});
data_saddle.push({
lat: 3.7539333332e+01,
lng: 1.3932788889e+02,
content:'Saddle = 703.099976 pos = 37.5393,139.3279 diff = 402.200073'
});
data_peak.push({
lat: 3.7559999999e+01,
lng: 1.3931922222e+02,
cert : true,
content:'Name = JA/NI-073(JA/NI-073) peak = 916.500000 pos = 37.5600,139.3192 diff = 174.299988'
});
data_saddle.push({
lat: 3.7564222221e+01,
lng: 1.3934688889e+02,
content:'Saddle = 742.200012 pos = 37.5642,139.3469 diff = 174.299988'
});
data_peak.push({
lat: 3.7622444444e+01,
lng: 1.3934533333e+02,
cert : true,
content:'Name = JA/NI-051(JA/NI-051) peak = 1080.500000 pos = 37.6224,139.3453 diff = 261.500000'
});
data_saddle.push({
lat: 3.7596555555e+01,
lng: 1.3935100000e+02,
content:'Saddle = 819.000000 pos = 37.5966,139.3510 diff = 261.500000'
});
data_peak.push({
lat: 3.7541888888e+01,
lng: 1.3930666667e+02,
cert : true,
content:'Name = JA/NI-074(JA/NI-074) peak = 915.200012 pos = 37.5419,139.3067 diff = 195.799988'
});
data_saddle.push({
lat: 3.7533444444e+01,
lng: 1.3929900000e+02,
content:'Saddle = 719.400024 pos = 37.5334,139.2990 diff = 195.799988'
});
data_peak.push({
lat: 3.7512555555e+01,
lng: 1.3926633333e+02,
cert : true,
content:'Name = Yahazudake(JA/NI-039) peak = 1253.300049 pos = 37.5126,139.2663 diff = 414.800049'
});
data_saddle.push({
lat: 3.7554888888e+01,
lng: 1.3923400000e+02,
content:'Saddle = 838.500000 pos = 37.5549,139.2340 diff = 414.800049'
});
data_peak.push({
lat: 3.7484999999e+01,
lng: 1.3929833333e+02,
cert : true,
content:'Name = JA/NI-049(JA/NI-049) peak = 1094.900024 pos = 37.4850,139.2983 diff = 212.900024'
});
data_saddle.push({
lat: 3.7496555555e+01,
lng: 1.3929077778e+02,
content:'Saddle = 882.000000 pos = 37.4966,139.2908 diff = 212.900024'
});
data_peak.push({
lat: 3.7539888888e+01,
lng: 1.3928222222e+02,
cert : false,
content:' Peak = 1112.500000 pos = 37.5399,139.2822 diff = 200.400024'
});
data_saddle.push({
lat: 3.7542222221e+01,
lng: 1.3927666667e+02,
content:'Saddle = 912.099976 pos = 37.5422,139.2767 diff = 200.400024'
});
data_peak.push({
lat: 3.7537333332e+01,
lng: 1.3925733333e+02,
cert : true,
content:'Name = JA/NI-041(JA/NI-041) peak = 1214.099976 pos = 37.5373,139.2573 diff = 272.099976'
});
data_saddle.push({
lat: 3.7529666666e+01,
lng: 1.3925633333e+02,
content:'Saddle = 942.000000 pos = 37.5297,139.2563 diff = 272.099976'
});
data_peak.push({
lat: 3.7512999999e+01,
lng: 1.3930300000e+02,
cert : false,
content:' Peak = 1120.699951 pos = 37.5130,139.3030 diff = 167.799927'
});
data_saddle.push({
lat: 3.7507666666e+01,
lng: 1.3928177778e+02,
content:'Saddle = 952.900024 pos = 37.5077,139.2818 diff = 167.799927'
});
data_peak.push({
lat: 3.7563888888e+01,
lng: 1.3924311111e+02,
cert : true,
content:'Name = JA/NI-055(JA/NI-055) peak = 1042.300049 pos = 37.5639,139.2431 diff = 183.300049'
});
data_saddle.push({
lat: 3.7556222221e+01,
lng: 1.3922444444e+02,
content:'Saddle = 859.000000 pos = 37.5562,139.2244 diff = 183.300049'
});
data_peak.push({
lat: 3.7544666666e+01,
lng: 1.3956877778e+02,
cert : true,
content:'Name = JA/FS-093(JA/FS-093) peak = 950.099976 pos = 37.5447,139.5688 diff = 242.799988'
});
data_saddle.push({
lat: 3.7518888888e+01,
lng: 1.3958655556e+02,
content:'Saddle = 707.299988 pos = 37.5189,139.5866 diff = 242.799988'
});
data_peak.push({
lat: 3.7477555555e+01,
lng: 1.3921933333e+02,
cert : false,
content:' Peak = 875.700012 pos = 37.4776,139.2193 diff = 160.200012'
});
data_saddle.push({
lat: 3.7473666666e+01,
lng: 1.3922266667e+02,
content:'Saddle = 715.500000 pos = 37.4737,139.2227 diff = 160.200012'
});
data_peak.push({
lat: 3.7509666666e+01,
lng: 1.3960311111e+02,
cert : true,
content:'Name = JA/FS-080(JA/FS-080) peak = 980.200012 pos = 37.5097,139.6031 diff = 257.600037'
});
data_saddle.push({
lat: 3.7511333332e+01,
lng: 1.3954100000e+02,
content:'Saddle = 722.599976 pos = 37.5113,139.5410 diff = 257.600037'
});
data_peak.push({
lat: 3.6719444443e+01,
lng: 1.3961677778e+02,
cert : true,
content:'Name = JA/TG-053(JA/TG-053) peak = 891.700012 pos = 36.7194,139.6168 diff = 168.500000'
});
data_saddle.push({
lat: 3.6721222221e+01,
lng: 1.3961022222e+02,
content:'Saddle = 723.200012 pos = 36.7212,139.6102 diff = 168.500000'
});
data_peak.push({
lat: 3.7401444443e+01,
lng: 1.3965811111e+02,
cert : false,
content:' Peak = 875.000000 pos = 37.4014,139.6581 diff = 151.700012'
});
data_saddle.push({
lat: 3.7399111110e+01,
lng: 1.3965900000e+02,
content:'Saddle = 723.299988 pos = 37.3991,139.6590 diff = 151.700012'
});
data_peak.push({
lat: 3.7165888888e+01,
lng: 1.3978222222e+02,
cert : true,
content:'Name = JA/FS-078(JA/FS-078) peak = 982.700012 pos = 37.1659,139.7822 diff = 254.900024'
});
data_saddle.push({
lat: 3.7158555554e+01,
lng: 1.3977888889e+02,
content:'Saddle = 727.799988 pos = 37.1586,139.7789 diff = 254.900024'
});
data_peak.push({
lat: 3.7175333332e+01,
lng: 1.3978000000e+02,
cert : true,
content:'Name = JA/FS-090(JA/FS-090) peak = 961.599976 pos = 37.1753,139.7800 diff = 165.500000'
});
data_saddle.push({
lat: 3.7172222221e+01,
lng: 1.3977811111e+02,
content:'Saddle = 796.099976 pos = 37.1722,139.7781 diff = 165.500000'
});
data_peak.push({
lat: 3.7475888888e+01,
lng: 1.3946444444e+02,
cert : true,
content:'Name = JA/FS-099(JA/FS-099) peak = 921.400024 pos = 37.4759,139.4644 diff = 189.500000'
});
data_saddle.push({
lat: 3.7484111110e+01,
lng: 1.3946888889e+02,
content:'Saddle = 731.900024 pos = 37.4841,139.4689 diff = 189.500000'
});
data_peak.push({
lat: 3.7336888888e+01,
lng: 1.3995300000e+02,
cert : true,
content:'Name = JA/FS-030(JA/FS-030) peak = 1414.000000 pos = 37.3369,139.9530 diff = 680.099976'
});
data_saddle.push({
lat: 3.7214444443e+01,
lng: 1.4007011111e+02,
content:'Saddle = 733.900024 pos = 37.2144,140.0701 diff = 680.099976'
});
data_peak.push({
lat: 3.7338444443e+01,
lng: 1.4016688889e+02,
cert : true,
content:'Name = JA/FS-058(JA/FS-058) peak = 1101.400024 pos = 37.3384,140.1669 diff = 364.400024'
});
data_saddle.push({
lat: 3.7331888888e+01,
lng: 1.4012533333e+02,
content:'Saddle = 737.000000 pos = 37.3319,140.1253 diff = 364.400024'
});
data_peak.push({
lat: 3.7441888888e+01,
lng: 1.4020377778e+02,
cert : true,
content:'Name = JA/FS-065(JA/FS-065) peak = 1055.099976 pos = 37.4419,140.2038 diff = 277.000000'
});
data_saddle.push({
lat: 3.7360111110e+01,
lng: 1.4017966667e+02,
content:'Saddle = 778.099976 pos = 37.3601,140.1797 diff = 277.000000'
});
data_peak.push({
lat: 3.7374111110e+01,
lng: 1.4020422222e+02,
cert : false,
content:' Peak = 967.000000 pos = 37.3741,140.2042 diff = 157.700012'
});
data_saddle.push({
lat: 3.7378777777e+01,
lng: 1.4019855556e+02,
content:'Saddle = 809.299988 pos = 37.3788,140.1986 diff = 157.700012'
});
data_peak.push({
lat: 3.7447333332e+01,
lng: 1.4017877778e+02,
cert : false,
content:' Peak = 1034.199951 pos = 37.4473,140.1788 diff = 162.599976'
});
data_saddle.push({
lat: 3.7453999999e+01,
lng: 1.4020411111e+02,
content:'Saddle = 871.599976 pos = 37.4540,140.2041 diff = 162.599976'
});
data_peak.push({
lat: 3.7338777777e+01,
lng: 1.4009588889e+02,
cert : true,
content:'Name = JA/FS-079(JA/FS-079) peak = 980.700012 pos = 37.3388,140.0959 diff = 237.500000'
});
data_saddle.push({
lat: 3.7328999999e+01,
lng: 1.4009911111e+02,
content:'Saddle = 743.200012 pos = 37.3290,140.0991 diff = 237.500000'
});
data_peak.push({
lat: 3.7256999999e+01,
lng: 1.4012855556e+02,
cert : false,
content:' Peak = 975.599976 pos = 37.2570,140.1286 diff = 158.599976'
});
data_saddle.push({
lat: 3.7264111110e+01,
lng: 1.4011311111e+02,
content:'Saddle = 817.000000 pos = 37.2641,140.1131 diff = 158.599976'
});
data_peak.push({
lat: 3.7271888888e+01,
lng: 1.4011555556e+02,
cert : true,
content:'Name = JA/FS-076(JA/FS-076) peak = 986.400024 pos = 37.2719,140.1156 diff = 168.500000'
});
data_saddle.push({
lat: 3.7301555554e+01,
lng: 1.4009722222e+02,
content:'Saddle = 817.900024 pos = 37.3016,140.0972 diff = 168.500000'
});
data_peak.push({
lat: 3.7301999999e+01,
lng: 1.3996977778e+02,
cert : false,
content:' Peak = 996.700012 pos = 37.3020,139.9698 diff = 174.000000'
});
data_saddle.push({
lat: 3.7302999999e+01,
lng: 1.3998355556e+02,
content:'Saddle = 822.700012 pos = 37.3030,139.9836 diff = 174.000000'
});
data_peak.push({
lat: 3.7305666666e+01,
lng: 1.4011722222e+02,
cert : false,
content:' Peak = 1020.799988 pos = 37.3057,140.1172 diff = 171.200012'
});
data_saddle.push({
lat: 3.7311111110e+01,
lng: 1.4011133333e+02,
content:'Saddle = 849.599976 pos = 37.3111,140.1113 diff = 171.200012'
});
data_peak.push({
lat: 3.7327999999e+01,
lng: 1.4000677778e+02,
cert : true,
content:'Name = JA/FS-056(JA/FS-056) peak = 1145.000000 pos = 37.3280,140.0068 diff = 282.700012'
});
data_saddle.push({
lat: 3.7329111110e+01,
lng: 1.3999566667e+02,
content:'Saddle = 862.299988 pos = 37.3291,139.9957 diff = 282.700012'
});
data_peak.push({
lat: 3.7285333332e+01,
lng: 1.4003244444e+02,
cert : false,
content:' Peak = 1022.500000 pos = 37.2853,140.0324 diff = 156.700012'
});
data_saddle.push({
lat: 3.7295222221e+01,
lng: 1.4003188889e+02,
content:'Saddle = 865.799988 pos = 37.2952,140.0319 diff = 156.700012'
});
data_peak.push({
lat: 3.7417222221e+01,
lng: 1.3971333333e+02,
cert : false,
content:' Peak = 901.500000 pos = 37.4172,139.7133 diff = 158.799988'
});
data_saddle.push({
lat: 3.7396888888e+01,
lng: 1.3972611111e+02,
content:'Saddle = 742.700012 pos = 37.3969,139.7261 diff = 158.799988'
});
data_peak.push({
lat: 3.7304999999e+01,
lng: 1.3986455556e+02,
cert : true,
content:'Name = JA/FS-071(JA/FS-071) peak = 1000.799988 pos = 37.3050,139.8646 diff = 255.899963'
});
data_saddle.push({
lat: 3.7310555555e+01,
lng: 1.3985188889e+02,
content:'Saddle = 744.900024 pos = 37.3106,139.8519 diff = 255.899963'
});
data_peak.push({
lat: 3.7427999999e+01,
lng: 1.3975966667e+02,
cert : true,
content:'Name = JA/FS-061(JA/FS-061) peak = 1070.400024 pos = 37.4280,139.7597 diff = 322.800049'
});
data_saddle.push({
lat: 3.7403111110e+01,
lng: 1.3976322222e+02,
content:'Saddle = 747.599976 pos = 37.4031,139.7632 diff = 322.800049'
});
data_peak.push({
lat: 3.7293777777e+01,
lng: 1.3966977778e+02,
cert : true,
content:'Name = JA/FS-088(JA/FS-088) peak = 962.799988 pos = 37.2938,139.6698 diff = 213.799988'
});
data_saddle.push({
lat: 3.7280111110e+01,
lng: 1.3968388889e+02,
content:'Saddle = 749.000000 pos = 37.2801,139.6839 diff = 213.799988'
});
data_peak.push({
lat: 3.6846999999e+01,
lng: 1.3975622222e+02,
cert : false,
content:' Peak = 902.700012 pos = 36.8470,139.7562 diff = 153.600037'
});
data_saddle.push({
lat: 3.6855222221e+01,
lng: 1.3976166667e+02,
content:'Saddle = 749.099976 pos = 36.8552,139.7617 diff = 153.600037'
});
data_peak.push({
lat: 3.6833444443e+01,
lng: 1.3969288889e+02,
cert : true,
content:'Name = JA/TG-051(JA/TG-051) peak = 963.700012 pos = 36.8334,139.6929 diff = 211.200012'
});
data_saddle.push({
lat: 3.6840333332e+01,
lng: 1.3968100000e+02,
content:'Saddle = 752.500000 pos = 36.8403,139.6810 diff = 211.200012'
});
data_peak.push({
lat: 3.7213666666e+01,
lng: 1.3913944444e+02,
cert : true,
content:'Name = JA/NI-070(JA/NI-070) peak = 938.400024 pos = 37.2137,139.1394 diff = 185.000000'
});
data_saddle.push({
lat: 3.7204777777e+01,
lng: 1.3912488889e+02,
content:'Saddle = 753.400024 pos = 37.2048,139.1249 diff = 185.000000'
});
data_peak.push({
lat: 3.6873888887e+01,
lng: 1.3971300000e+02,
cert : false,
content:' Peak = 950.900024 pos = 36.8739,139.7130 diff = 184.000000'
});
data_saddle.push({
lat: 3.6886111110e+01,
lng: 1.3972355556e+02,
content:'Saddle = 766.900024 pos = 36.8861,139.7236 diff = 184.000000'
});
data_peak.push({
lat: 3.7194777777e+01,
lng: 1.3913200000e+02,
cert : true,
content:'Name = JA/NI-056(JA/NI-056) peak = 1031.699951 pos = 37.1948,139.1320 diff = 256.099976'
});
data_saddle.push({
lat: 3.7176333332e+01,
lng: 1.3912533333e+02,
content:'Saddle = 775.599976 pos = 37.1763,139.1253 diff = 256.099976'
});
data_peak.push({
lat: 3.7512444444e+01,
lng: 1.3949744444e+02,
cert : false,
content:' Peak = 1133.099976 pos = 37.5124,139.4974 diff = 355.000000'
});
data_saddle.push({
lat: 3.7505333332e+01,
lng: 1.3947255556e+02,
content:'Saddle = 778.099976 pos = 37.5053,139.4726 diff = 355.000000'
});
data_peak.push({
lat: 3.7429888888e+01,
lng: 1.3935977778e+02,
cert : false,
content:' Peak = 991.500000 pos = 37.4299,139.3598 diff = 208.200012'
});
data_saddle.push({
lat: 3.7433222221e+01,
lng: 1.3935666667e+02,
content:'Saddle = 783.299988 pos = 37.4332,139.3567 diff = 208.200012'
});
data_peak.push({
lat: 3.7521888888e+01,
lng: 1.3942577778e+02,
cert : false,
content:' Peak = 1384.900024 pos = 37.5219,139.4258 diff = 593.100037'
});
data_saddle.push({
lat: 3.7455222221e+01,
lng: 1.3929655556e+02,
content:'Saddle = 791.799988 pos = 37.4552,139.2966 diff = 593.100037'
});
data_peak.push({
lat: 3.7466555555e+01,
lng: 1.3940633333e+02,
cert : true,
content:'Name = JA/FS-040(JA/FS-040) peak = 1313.900024 pos = 37.4666,139.4063 diff = 465.900024'
});
data_saddle.push({
lat: 3.7499999999e+01,
lng: 1.3941200000e+02,
content:'Saddle = 848.000000 pos = 37.5000,139.4120 diff = 465.900024'
});
data_peak.push({
lat: 3.7521222221e+01,
lng: 1.3945744444e+02,
cert : true,
content:'Name = JA/NI-046(JA/NI-046) peak = 1141.800049 pos = 37.5212,139.4574 diff = 260.400024'
});
data_saddle.push({
lat: 3.7517333332e+01,
lng: 1.3945088889e+02,
content:'Saddle = 881.400024 pos = 37.5173,139.4509 diff = 260.400024'
});
data_peak.push({
lat: 3.7406555555e+01,
lng: 1.3974911111e+02,
cert : true,
content:'Name = JA/FS-066(JA/FS-066) peak = 1043.199951 pos = 37.4066,139.7491 diff = 241.099976'
});
data_saddle.push({
lat: 3.7400777777e+01,
lng: 1.3974933333e+02,
content:'Saddle = 802.099976 pos = 37.4008,139.7493 diff = 241.099976'
});
data_peak.push({
lat: 3.7299888888e+01,
lng: 1.3951533333e+02,
cert : false,
content:' Peak = 953.400024 pos = 37.2999,139.5153 diff = 150.400024'
});
data_saddle.push({
lat: 3.7303999999e+01,
lng: 1.3951811111e+02,
content:'Saddle = 803.000000 pos = 37.3040,139.5181 diff = 150.400024'
});
data_peak.push({
lat: 3.7328222221e+01,
lng: 1.3955722222e+02,
cert : false,
content:' Peak = 971.700012 pos = 37.3282,139.5572 diff = 163.000000'
});
data_saddle.push({
lat: 3.7322666666e+01,
lng: 1.3957533333e+02,
content:'Saddle = 808.700012 pos = 37.3227,139.5753 diff = 163.000000'
});
data_peak.push({
lat: 3.7424777777e+01,
lng: 1.3925855556e+02,
cert : true,
content:'Name = JA/FS-067(JA/FS-067) peak = 1033.300049 pos = 37.4248,139.2586 diff = 221.500061'
});
data_saddle.push({
lat: 3.7440222221e+01,
lng: 1.3926033333e+02,
content:'Saddle = 811.799988 pos = 37.4402,139.2603 diff = 221.500061'
});
data_peak.push({
lat: 3.7403222221e+01,
lng: 1.3928511111e+02,
cert : false,
content:' Peak = 983.400024 pos = 37.4032,139.2851 diff = 170.600037'
});
data_saddle.push({
lat: 3.7410111110e+01,
lng: 1.3927055556e+02,
content:'Saddle = 812.799988 pos = 37.4101,139.2706 diff = 170.600037'
});
data_peak.push({
lat: 3.7411444443e+01,
lng: 1.3925488889e+02,
cert : false,
content:' Peak = 1031.400024 pos = 37.4114,139.2549 diff = 159.300049'
});
data_saddle.push({
lat: 3.7417888888e+01,
lng: 1.3925733333e+02,
content:'Saddle = 872.099976 pos = 37.4179,139.2573 diff = 159.300049'
});
data_peak.push({
lat: 3.7368333332e+01,
lng: 1.3962711111e+02,
cert : true,
content:'Name = JA/FS-044(JA/FS-044) peak = 1232.400024 pos = 37.3683,139.6271 diff = 420.600037'
});
data_saddle.push({
lat: 3.7348666666e+01,
lng: 1.3965922222e+02,
content:'Saddle = 811.799988 pos = 37.3487,139.6592 diff = 420.600037'
});
data_peak.push({
lat: 3.7224666666e+01,
lng: 1.3972233333e+02,
cert : true,
content:'Name = JA/FS-070(JA/FS-070) peak = 1023.799988 pos = 37.2247,139.7223 diff = 211.000000'
});
data_saddle.push({
lat: 3.7231222221e+01,
lng: 1.3971466667e+02,
content:'Saddle = 812.799988 pos = 37.2312,139.7147 diff = 211.000000'
});
data_peak.push({
lat: 3.7194666666e+01,
lng: 1.3950611111e+02,
cert : false,
content:' Peak = 993.700012 pos = 37.1947,139.5061 diff = 170.600037'
});
data_saddle.push({
lat: 3.7196333332e+01,
lng: 1.3949633333e+02,
content:'Saddle = 823.099976 pos = 37.1963,139.4963 diff = 170.600037'
});
data_peak.push({
lat: 3.7256333332e+01,
lng: 1.3957011111e+02,
cert : false,
content:' Peak = 999.200012 pos = 37.2563,139.5701 diff = 171.299988'
});
data_saddle.push({
lat: 3.7251777777e+01,
lng: 1.3956377778e+02,
content:'Saddle = 827.900024 pos = 37.2518,139.5638 diff = 171.299988'
});
data_peak.push({
lat: 3.7475111110e+01,
lng: 1.3924900000e+02,
cert : true,
content:'Name = JA/NI-054(JA/NI-054) peak = 1041.199951 pos = 37.4751,139.2490 diff = 208.599976'
});
data_saddle.push({
lat: 3.7468555555e+01,
lng: 1.3925155556e+02,
content:'Saddle = 832.599976 pos = 37.4686,139.2516 diff = 208.599976'
});
data_peak.push({
lat: 3.7428111110e+01,
lng: 1.3923577778e+02,
cert : false,
content:' Peak = 1032.699951 pos = 37.4281,139.2358 diff = 199.799927'
});
data_saddle.push({
lat: 3.7436666666e+01,
lng: 1.3923388889e+02,
content:'Saddle = 832.900024 pos = 37.4367,139.2339 diff = 199.799927'
});
data_peak.push({
lat: 3.6730333332e+01,
lng: 1.3959644444e+02,
cert : true,
content:'Name = JA/TG-048(JA/TG-048) peak = 1102.599976 pos = 36.7303,139.5964 diff = 269.500000'
});
data_saddle.push({
lat: 3.6730333332e+01,
lng: 1.3957977778e+02,
content:'Saddle = 833.099976 pos = 36.7303,139.5798 diff = 269.500000'
});
data_peak.push({
lat: 3.7247999999e+01,
lng: 1.3982200000e+02,
cert : true,
content:'Name = JA/FS-051(JA/FS-051) peak = 1160.400024 pos = 37.2480,139.8220 diff = 322.800049'
});
data_saddle.push({
lat: 3.7235444443e+01,
lng: 1.3976344444e+02,
content:'Saddle = 837.599976 pos = 37.2354,139.7634 diff = 322.800049'
});
data_peak.push({
lat: 3.7292777777e+01,
lng: 1.3957888889e+02,
cert : false,
content:' Peak = 1058.000000 pos = 37.2928,139.5789 diff = 216.099976'
});
data_saddle.push({
lat: 3.7259666666e+01,
lng: 1.3959422222e+02,
content:'Saddle = 841.900024 pos = 37.2597,139.5942 diff = 216.099976'
});
data_peak.push({
lat: 3.7397666666e+01,
lng: 1.3913644444e+02,
cert : true,
content:'Name = Sumondake(JA/NI-024) peak = 1535.599976 pos = 37.3977,139.1364 diff = 683.399963'
});
data_saddle.push({
lat: 3.7396777777e+01,
lng: 1.3920744444e+02,
content:'Saddle = 852.200012 pos = 37.3968,139.2074 diff = 683.399963'
});
data_peak.push({
lat: 3.7452444444e+01,
lng: 1.3925122222e+02,
cert : true,
content:'Name = JA/FS-062(JA/FS-062) peak = 1062.400024 pos = 37.4524,139.2512 diff = 200.700012'
});
data_saddle.push({
lat: 3.7448222221e+01,
lng: 1.3922277778e+02,
content:'Saddle = 861.700012 pos = 37.4482,139.2228 diff = 200.700012'
});
data_peak.push({
lat: 3.7418444443e+01,
lng: 1.3920766667e+02,
cert : true,
content:'Name = JA/FS-049(JA/FS-049) peak = 1195.300049 pos = 37.4184,139.2077 diff = 227.500061'
});
data_saddle.push({
lat: 3.7411555555e+01,
lng: 1.3918277778e+02,
content:'Saddle = 967.799988 pos = 37.4116,139.1828 diff = 227.500061'
});
data_peak.push({
lat: 3.7248888888e+01,
lng: 1.3975277778e+02,
cert : false,
content:' Peak = 1010.900024 pos = 37.2489,139.7528 diff = 158.400024'
});
data_saddle.push({
lat: 3.7249333332e+01,
lng: 1.3974188889e+02,
content:'Saddle = 852.500000 pos = 37.2493,139.7419 diff = 158.400024'
});
data_peak.push({
lat: 3.7390333332e+01,
lng: 1.3972788889e+02,
cert : false,
content:' Peak = 1037.199951 pos = 37.3903,139.7279 diff = 183.199951'
});
data_saddle.push({
lat: 3.7384777777e+01,
lng: 1.3973222222e+02,
content:'Saddle = 854.000000 pos = 37.3848,139.7322 diff = 183.199951'
});
data_peak.push({
lat: 3.7325999999e+01,
lng: 1.3988655556e+02,
cert : true,
content:'Name = Onodake(JA/FS-034) peak = 1382.699951 pos = 37.3260,139.8866 diff = 520.799927'
});
data_saddle.push({
lat: 3.7361222221e+01,
lng: 1.3986822222e+02,
content:'Saddle = 861.900024 pos = 37.3612,139.8682 diff = 520.799927'
});
data_peak.push({
lat: 3.7343666666e+01,
lng: 1.3923355556e+02,
cert : true,
content:'Name = Asakusadake(JA/FS-019) peak = 1584.800049 pos = 37.3437,139.2336 diff = 707.200073'
});
data_saddle.push({
lat: 3.7304444443e+01,
lng: 1.3921711111e+02,
content:'Saddle = 877.599976 pos = 37.3044,139.2171 diff = 707.200073'
});
data_peak.push({
lat: 3.7106333332e+01,
lng: 1.3950444444e+02,
cert : true,
content:'Name = JA/FS-052(JA/FS-052) peak = 1154.900024 pos = 37.1063,139.5044 diff = 271.500000'
});
data_saddle.push({
lat: 3.7080555554e+01,
lng: 1.3951344444e+02,
content:'Saddle = 883.400024 pos = 37.0806,139.5134 diff = 271.500000'
});
data_peak.push({
lat: 3.7252444443e+01,
lng: 1.3930722222e+02,
cert : false,
content:' Peak = 1067.599976 pos = 37.2524,139.3072 diff = 165.399963'
});
data_saddle.push({
lat: 3.7248111110e+01,
lng: 1.3930433333e+02,
content:'Saddle = 902.200012 pos = 37.2481,139.3043 diff = 165.399963'
});
data_peak.push({
lat: 3.6702555554e+01,
lng: 1.3957433333e+02,
cert : true,
content:'Name = JA/TG-049(JA/TG-049) peak = 1100.400024 pos = 36.7026,139.5743 diff = 193.600037'
});
data_saddle.push({
lat: 3.6710111110e+01,
lng: 1.3956833333e+02,
content:'Saddle = 906.799988 pos = 36.7101,139.5683 diff = 193.600037'
});
data_peak.push({
lat: 3.7150222221e+01,
lng: 1.3996133333e+02,
cert : true,
content:'Name = Sanbonyaridake(JA/TG-015) peak = 1915.500000 pos = 37.1502,139.9613 diff = 1007.299988'
});
data_saddle.push({
lat: 3.7070999999e+01,
lng: 1.3974666667e+02,
content:'Saddle = 908.200012 pos = 37.0710,139.7467 diff = 1007.299988'
});
data_peak.push({
lat: 3.7001333332e+01,
lng: 1.3977388889e+02,
cert : false,
content:' Peak = 1123.500000 pos = 37.0013,139.7739 diff = 160.200012'
});
data_saddle.push({
lat: 3.7005333332e+01,
lng: 1.3976422222e+02,
content:'Saddle = 963.299988 pos = 37.0053,139.7642 diff = 160.200012'
});
data_peak.push({
lat: 3.7088444443e+01,
lng: 1.3973855556e+02,
cert : true,
content:'Name = JA/FS-045(JA/FS-045) peak = 1221.000000 pos = 37.0884,139.7386 diff = 207.799988'
});
data_saddle.push({
lat: 3.7084333332e+01,
lng: 1.3975733333e+02,
content:'Saddle = 1013.200012 pos = 37.0843,139.7573 diff = 207.799988'
});
data_peak.push({
lat: 3.7129777777e+01,
lng: 1.3978588889e+02,
cert : false,
content:' Peak = 1214.199951 pos = 37.1298,139.7859 diff = 191.999939'
});
data_saddle.push({
lat: 3.7123222221e+01,
lng: 1.3978066667e+02,
content:'Saddle = 1022.200012 pos = 37.1232,139.7807 diff = 191.999939'
});
data_peak.push({
lat: 3.6994999999e+01,
lng: 1.3983211111e+02,
cert : true,
content:'Name = JA/TG-031(JA/TG-031) peak = 1391.599976 pos = 36.9950,139.8321 diff = 368.299988'
});
data_saddle.push({
lat: 3.7016777776e+01,
lng: 1.3980566667e+02,
content:'Saddle = 1023.299988 pos = 37.0168,139.8057 diff = 368.299988'
});
data_peak.push({
lat: 3.6953444443e+01,
lng: 1.3978855556e+02,
cert : false,
content:' Peak = 1182.199951 pos = 36.9534,139.7886 diff = 155.500000'
});
data_saddle.push({
lat: 3.6950444443e+01,
lng: 1.3978433333e+02,
content:'Saddle = 1026.699951 pos = 36.9504,139.7843 diff = 155.500000'
});
data_peak.push({
lat: 3.7008333332e+01,
lng: 1.3979222222e+02,
cert : false,
content:' Peak = 1200.800049 pos = 37.0083,139.7922 diff = 173.200073'
});
data_saddle.push({
lat: 3.7013888888e+01,
lng: 1.3979266667e+02,
content:'Saddle = 1027.599976 pos = 37.0139,139.7927 diff = 173.200073'
});
data_peak.push({
lat: 3.6899999999e+01,
lng: 1.3977666667e+02,
cert : true,
content:'Name = Takaharayama (Shakagadake)(JA/TG-019) peak = 1793.699951 pos = 36.9000,139.7767 diff = 746.299927'
});
data_saddle.push({
lat: 3.6974999999e+01,
lng: 1.3974477778e+02,
content:'Saddle = 1047.400024 pos = 36.9750,139.7448 diff = 746.299927'
});
data_peak.push({
lat: 3.6927444443e+01,
lng: 1.3978755556e+02,
cert : true,
content:'Name = JA/TG-021(JA/TG-021) peak = 1700.599976 pos = 36.9274,139.7876 diff = 192.900024'
});
data_saddle.push({
lat: 3.6914666665e+01,
lng: 1.3977033333e+02,
content:'Saddle = 1507.699951 pos = 36.9147,139.7703 diff = 192.900024'
});
data_peak.push({
lat: 3.7222888888e+01,
lng: 1.3992944444e+02,
cert : false,
content:' Peak = 1283.599976 pos = 37.2229,139.9294 diff = 212.000000'
});
data_saddle.push({
lat: 3.7222888888e+01,
lng: 1.3993355556e+02,
content:'Saddle = 1071.599976 pos = 37.2229,139.9336 diff = 212.000000'
});
data_peak.push({
lat: 3.7110777777e+01,
lng: 1.3975622222e+02,
cert : false,
content:' Peak = 1414.000000 pos = 37.1108,139.7562 diff = 313.300049'
});
data_saddle.push({
lat: 3.7099111110e+01,
lng: 1.3977333333e+02,
content:'Saddle = 1100.699951 pos = 37.0991,139.7733 diff = 313.300049'
});
data_peak.push({
lat: 3.7110999999e+01,
lng: 1.3977611111e+02,
cert : false,
content:' Peak = 1295.800049 pos = 37.1110,139.7761 diff = 152.800049'
});
data_saddle.push({
lat: 3.7110222221e+01,
lng: 1.3976388889e+02,
content:'Saddle = 1143.000000 pos = 37.1102,139.7639 diff = 152.800049'
});
data_peak.push({
lat: 3.7246555554e+01,
lng: 1.3996722222e+02,
cert : true,
content:'Name = Futamatayama(JA/FS-021) peak = 1542.400024 pos = 37.2466,139.9672 diff = 430.500000'
});
data_saddle.push({
lat: 3.7236666666e+01,
lng: 1.3995444444e+02,
content:'Saddle = 1111.900024 pos = 37.2367,139.9544 diff = 430.500000'
});
data_peak.push({
lat: 3.6985999999e+01,
lng: 1.3972866667e+02,
cert : false,
content:' Peak = 1304.000000 pos = 36.9860,139.7287 diff = 156.000000'
});
data_saddle.push({
lat: 3.6995666665e+01,
lng: 1.3975000000e+02,
content:'Saddle = 1148.000000 pos = 36.9957,139.7500 diff = 156.000000'
});
data_peak.push({
lat: 3.7107555554e+01,
lng: 1.3988711111e+02,
cert : false,
content:' Peak = 1356.099976 pos = 37.1076,139.8871 diff = 184.500000'
});
data_saddle.push({
lat: 3.7110555554e+01,
lng: 1.3988000000e+02,
content:'Saddle = 1171.599976 pos = 37.1106,139.8800 diff = 184.500000'
});
data_peak.push({
lat: 3.7024222221e+01,
lng: 1.3975577778e+02,
cert : true,
content:'Name = JA/TG-028(JA/TG-028) peak = 1462.599976 pos = 37.0242,139.7558 diff = 255.500000'
});
data_saddle.push({
lat: 3.7039888888e+01,
lng: 1.3976500000e+02,
content:'Saddle = 1207.099976 pos = 37.0399,139.7650 diff = 255.500000'
});
data_peak.push({
lat: 3.7112888888e+01,
lng: 1.3984000000e+02,
cert : true,
content:'Name = JA/TG-027(JA/TG-027) peak = 1481.900024 pos = 37.1129,139.8400 diff = 271.099976'
});
data_saddle.push({
lat: 3.7106333332e+01,
lng: 1.3983088889e+02,
content:'Saddle = 1210.800049 pos = 37.1063,139.8309 diff = 271.099976'
});
data_peak.push({
lat: 3.7083999999e+01,
lng: 1.3987466667e+02,
cert : false,
content:' Peak = 1403.500000 pos = 37.0840,139.8747 diff = 160.199951'
});
data_saddle.push({
lat: 3.7091111110e+01,
lng: 1.3986388889e+02,
content:'Saddle = 1243.300049 pos = 37.0911,139.8639 diff = 160.199951'
});
data_peak.push({
lat: 3.7112555554e+01,
lng: 1.3991800000e+02,
cert : false,
content:' Peak = 1411.599976 pos = 37.1126,139.9180 diff = 158.900024'
});
data_saddle.push({
lat: 3.7115666665e+01,
lng: 1.3992422222e+02,
content:'Saddle = 1252.699951 pos = 37.1157,139.9242 diff = 158.900024'
});
data_peak.push({
lat: 3.7063555554e+01,
lng: 1.3984444444e+02,
cert : true,
content:'Name = Oosabiyama(JA/TG-017) peak = 1905.199951 pos = 37.0636,139.8444 diff = 642.799927'
});
data_saddle.push({
lat: 3.7101111110e+01,
lng: 1.3981911111e+02,
content:'Saddle = 1262.400024 pos = 37.1011,139.8191 diff = 642.799927'
});
data_peak.push({
lat: 3.7031333332e+01,
lng: 1.3982522222e+02,
cert : false,
content:' Peak = 1640.099976 pos = 37.0313,139.8252 diff = 151.299927'
});
data_saddle.push({
lat: 3.7034222221e+01,
lng: 1.3982088889e+02,
content:'Saddle = 1488.800049 pos = 37.0342,139.8209 diff = 151.299927'
});
data_peak.push({
lat: 3.7038888888e+01,
lng: 1.3979300000e+02,
cert : true,
content:'Name = JA/TG-018(JA/TG-018) peak = 1846.599976 pos = 37.0389,139.7930 diff = 245.099976'
});
data_saddle.push({
lat: 3.7067999999e+01,
lng: 1.3982255556e+02,
content:'Saddle = 1601.500000 pos = 37.0680,139.8226 diff = 245.099976'
});
data_peak.push({
lat: 3.7117888888e+01,
lng: 1.3981588889e+02,
cert : true,
content:'Name = JA/TG-026(JA/TG-026) peak = 1500.699951 pos = 37.1179,139.8159 diff = 219.500000'
});
data_saddle.push({
lat: 3.7124111110e+01,
lng: 1.3982366667e+02,
content:'Saddle = 1281.199951 pos = 37.1241,139.8237 diff = 219.500000'
});
data_peak.push({
lat: 3.7201999999e+01,
lng: 1.3998322222e+02,
cert : true,
content:'Name = JA/FS-013(JA/FS-013) peak = 1641.300049 pos = 37.2020,139.9832 diff = 259.200073'
});
data_saddle.push({
lat: 3.7193555554e+01,
lng: 1.3997400000e+02,
content:'Saddle = 1382.099976 pos = 37.1936,139.9740 diff = 259.200073'
});
data_peak.push({
lat: 3.7157777777e+01,
lng: 1.3990277778e+02,
cert : true,
content:'Name = JA/FS-006(JA/FS-006) peak = 1885.699951 pos = 37.1578,139.9028 diff = 428.399902'
});
data_saddle.push({
lat: 3.7153333332e+01,
lng: 1.3994155556e+02,
content:'Saddle = 1457.300049 pos = 37.1533,139.9416 diff = 428.399902'
});
data_peak.push({
lat: 3.7180444443e+01,
lng: 1.3995977778e+02,
cert : true,
content:'Name = JA/FS-007(JA/FS-007) peak = 1830.699951 pos = 37.1804,139.9598 diff = 272.199951'
});
data_saddle.push({
lat: 3.7169111110e+01,
lng: 1.3996266667e+02,
content:'Saddle = 1558.500000 pos = 37.1691,139.9627 diff = 272.199951'
});
data_peak.push({
lat: 3.7124888888e+01,
lng: 1.3996311111e+02,
cert : true,
content:'Name = Nasudake (Chausudake)(JA/TG-016) peak = 1914.099976 pos = 37.1249,139.9631 diff = 191.699951'
});
data_saddle.push({
lat: 3.7131222221e+01,
lng: 1.3996233333e+02,
content:'Saddle = 1722.400024 pos = 37.1312,139.9623 diff = 191.699951'
});
data_peak.push({
lat: 3.7087888888e+01,
lng: 1.3958466667e+02,
cert : false,
content:' Peak = 1070.300049 pos = 37.0879,139.5847 diff = 157.600037'
});
data_saddle.push({
lat: 3.7079666665e+01,
lng: 1.3958677778e+02,
content:'Saddle = 912.700012 pos = 37.0797,139.5868 diff = 157.600037'
});
data_peak.push({
lat: 3.7346999999e+01,
lng: 1.3983833333e+02,
cert : false,
content:' Peak = 1093.000000 pos = 37.3470,139.8383 diff = 175.299988'
});
data_saddle.push({
lat: 3.7338666666e+01,
lng: 1.3983211111e+02,
content:'Saddle = 917.700012 pos = 37.3387,139.8321 diff = 175.299988'
});
data_peak.push({
lat: 3.6921111110e+01,
lng: 1.3967522222e+02,
cert : true,
content:'Name = JA/TG-047(JA/TG-047) peak = 1122.800049 pos = 36.9211,139.6752 diff = 204.500061'
});
data_saddle.push({
lat: 3.6921111110e+01,
lng: 1.3966822222e+02,
content:'Saddle = 918.299988 pos = 36.9211,139.6682 diff = 204.500061'
});
data_peak.push({
lat: 3.6829999999e+01,
lng: 1.3963322222e+02,
cert : true,
content:'Name = JA/TG-046(JA/TG-046) peak = 1130.599976 pos = 36.8300,139.6332 diff = 202.799988'
});
data_saddle.push({
lat: 3.6834777776e+01,
lng: 1.3962288889e+02,
content:'Saddle = 927.799988 pos = 36.8348,139.6229 diff = 202.799988'
});
data_peak.push({
lat: 3.7222555554e+01,
lng: 1.3949322222e+02,
cert : true,
content:'Name = JA/FS-039(JA/FS-039) peak = 1313.900024 pos = 37.2226,139.4932 diff = 382.000000'
});
data_saddle.push({
lat: 3.7202999999e+01,
lng: 1.3947688889e+02,
content:'Saddle = 931.900024 pos = 37.2030,139.4769 diff = 382.000000'
});
data_peak.push({
lat: 3.6982111110e+01,
lng: 1.3960888889e+02,
cert : false,
content:' Peak = 1106.000000 pos = 36.9821,139.6089 diff = 165.900024'
});
data_saddle.push({
lat: 3.6982555554e+01,
lng: 1.3961577778e+02,
content:'Saddle = 940.099976 pos = 36.9826,139.6158 diff = 165.900024'
});
data_peak.push({
lat: 3.7284888888e+01,
lng: 1.3920955556e+02,
cert : true,
content:'Name = JA/FS-043(JA/FS-043) peak = 1233.300049 pos = 37.2849,139.2096 diff = 271.100037'
});
data_saddle.push({
lat: 3.7278888888e+01,
lng: 1.3920133333e+02,
content:'Saddle = 962.200012 pos = 37.2789,139.2013 diff = 271.100037'
});
data_peak.push({
lat: 3.6872444443e+01,
lng: 1.3966111111e+02,
cert : false,
content:' Peak = 1174.500000 pos = 36.8724,139.6611 diff = 212.000000'
});
data_saddle.push({
lat: 3.6864777776e+01,
lng: 1.3966166667e+02,
content:'Saddle = 962.500000 pos = 36.8648,139.6617 diff = 212.000000'
});
data_peak.push({
lat: 3.7127111110e+01,
lng: 1.3953455556e+02,
cert : true,
content:'Name = JA/FS-053(JA/FS-053) peak = 1153.300049 pos = 37.1271,139.5346 diff = 190.500061'
});
data_saddle.push({
lat: 3.7131666665e+01,
lng: 1.3954266667e+02,
content:'Saddle = 962.799988 pos = 37.1317,139.5427 diff = 190.500061'
});
data_peak.push({
lat: 3.7183444443e+01,
lng: 1.3918944444e+02,
cert : true,
content:'Name = Mijyougatake(JA/NI-023) peak = 1552.099976 pos = 37.1834,139.1894 diff = 589.099976'
});
data_saddle.push({
lat: 3.7142222221e+01,
lng: 1.3914455556e+02,
content:'Saddle = 963.000000 pos = 37.1422,139.1446 diff = 589.099976'
});
data_peak.push({
lat: 3.7136111110e+01,
lng: 1.3921500000e+02,
cert : false,
content:' Peak = 1182.699951 pos = 37.1361,139.2150 diff = 170.399963'
});
data_saddle.push({
lat: 3.7132999999e+01,
lng: 1.3920655556e+02,
content:'Saddle = 1012.299988 pos = 37.1330,139.2066 diff = 170.399963'
});
data_peak.push({
lat: 3.7256777777e+01,
lng: 1.3917511111e+02,
cert : true,
content:'Name = Kemouyama(JA/FS-024) peak = 1515.000000 pos = 37.2568,139.1751 diff = 432.099976'
});
data_saddle.push({
lat: 3.7236999999e+01,
lng: 1.3916466667e+02,
content:'Saddle = 1082.900024 pos = 37.2370,139.1647 diff = 432.099976'
});
data_peak.push({
lat: 3.7203888888e+01,
lng: 1.3919477778e+02,
cert : false,
content:' Peak = 1351.300049 pos = 37.2039,139.1948 diff = 168.400024'
});
data_saddle.push({
lat: 3.7199888888e+01,
lng: 1.3919633333e+02,
content:'Saddle = 1182.900024 pos = 37.1999,139.1963 diff = 168.400024'
});
data_peak.push({
lat: 3.7147555554e+01,
lng: 1.3918544444e+02,
cert : true,
content:'Name = JA/NI-029(JA/NI-029) peak = 1431.300049 pos = 37.1476,139.1854 diff = 198.900024'
});
data_saddle.push({
lat: 3.7160444443e+01,
lng: 1.3918644444e+02,
content:'Saddle = 1232.400024 pos = 37.1604,139.1864 diff = 198.900024'
});
data_peak.push({
lat: 3.7229666666e+01,
lng: 1.3944344444e+02,
cert : false,
content:' Peak = 1123.500000 pos = 37.2297,139.4434 diff = 160.400024'
});
data_saddle.push({
lat: 3.7216777777e+01,
lng: 1.3944400000e+02,
content:'Saddle = 963.099976 pos = 37.2168,139.4440 diff = 160.400024'
});
data_peak.push({
lat: 3.7082777777e+01,
lng: 1.3971044444e+02,
cert : false,
content:' Peak = 1136.900024 pos = 37.0828,139.7104 diff = 164.800049'
});
data_saddle.push({
lat: 3.7069999999e+01,
lng: 1.3971000000e+02,
content:'Saddle = 972.099976 pos = 37.0700,139.7100 diff = 164.800049'
});
data_peak.push({
lat: 3.6973111110e+01,
lng: 1.3964222222e+02,
cert : true,
content:'Name = JA/TG-033(JA/TG-033) peak = 1364.699951 pos = 36.9731,139.6422 diff = 391.599976'
});
data_saddle.push({
lat: 3.6994999999e+01,
lng: 1.3962222222e+02,
content:'Saddle = 973.099976 pos = 36.9950,139.6222 diff = 391.599976'
});
data_peak.push({
lat: 3.7074444443e+01,
lng: 1.3971544444e+02,
cert : false,
content:' Peak = 1141.000000 pos = 37.0744,139.7154 diff = 152.900024'
});
data_saddle.push({
lat: 3.7065666665e+01,
lng: 1.3970911111e+02,
content:'Saddle = 988.099976 pos = 37.0657,139.7091 diff = 152.900024'
});
data_peak.push({
lat: 3.7189999999e+01,
lng: 1.3957077778e+02,
cert : false,
content:' Peak = 1173.300049 pos = 37.1900,139.5708 diff = 184.500061'
});
data_saddle.push({
lat: 3.7189222221e+01,
lng: 1.3957477778e+02,
content:'Saddle = 988.799988 pos = 37.1892,139.5748 diff = 184.500061'
});
data_peak.push({
lat: 3.6911111110e+01,
lng: 1.3965955556e+02,
cert : false,
content:' Peak = 1175.900024 pos = 36.9111,139.6596 diff = 173.600037'
});
data_saddle.push({
lat: 3.6914777776e+01,
lng: 1.3965077778e+02,
content:'Saddle = 1002.299988 pos = 36.9148,139.6508 diff = 173.600037'
});
data_peak.push({
lat: 3.7363222221e+01,
lng: 1.3971466667e+02,
cert : true,
content:'Name = Hakaseyama(JA/FS-026) peak = 1481.800049 pos = 37.3632,139.7147 diff = 467.200073'
});
data_saddle.push({
lat: 3.7280777777e+01,
lng: 1.3973111111e+02,
content:'Saddle = 1014.599976 pos = 37.2808,139.7311 diff = 467.200073'
});
data_peak.push({
lat: 3.7318111110e+01,
lng: 1.3983200000e+02,
cert : false,
content:' Peak = 1380.500000 pos = 37.3181,139.8320 diff = 343.400024'
});
data_saddle.push({
lat: 3.7328111110e+01,
lng: 1.3973566667e+02,
content:'Saddle = 1037.099976 pos = 37.3281,139.7357 diff = 343.400024'
});
data_peak.push({
lat: 3.6857222221e+01,
lng: 1.3964055556e+02,
cert : true,
content:'Name = JA/TG-035(JA/TG-035) peak = 1341.400024 pos = 36.8572,139.6406 diff = 321.200012'
});
data_saddle.push({
lat: 3.6845555554e+01,
lng: 1.3961644444e+02,
content:'Saddle = 1020.200012 pos = 36.8456,139.6164 diff = 321.200012'
});
data_peak.push({
lat: 3.6852777776e+01,
lng: 1.3961866667e+02,
cert : true,
content:'Name = JA/TG-037(JA/TG-037) peak = 1295.199951 pos = 36.8528,139.6187 diff = 263.500000'
});
data_saddle.push({
lat: 3.6851111110e+01,
lng: 1.3963377778e+02,
content:'Saddle = 1031.699951 pos = 36.8511,139.6338 diff = 263.500000'
});
data_peak.push({
lat: 3.6846222221e+01,
lng: 1.3965911111e+02,
cert : true,
content:'Name = JA/TG-038(JA/TG-038) peak = 1283.900024 pos = 36.8462,139.6591 diff = 175.700073'
});
data_saddle.push({
lat: 3.6858222221e+01,
lng: 1.3966155556e+02,
content:'Saddle = 1108.199951 pos = 36.8582,139.6616 diff = 175.700073'
});
data_peak.push({
lat: 3.6923666665e+01,
lng: 1.3964544444e+02,
cert : true,
content:'Name = JA/TG-041(JA/TG-041) peak = 1223.599976 pos = 36.9237,139.6454 diff = 200.399963'
});
data_saddle.push({
lat: 3.6924666665e+01,
lng: 1.3963577778e+02,
content:'Saddle = 1023.200012 pos = 36.9247,139.6358 diff = 200.399963'
});
data_peak.push({
lat: 3.7213444443e+01,
lng: 1.3925433333e+02,
cert : true,
content:'Name = JA/FS-022(JA/FS-022) peak = 1534.199951 pos = 37.2134,139.2543 diff = 510.799927'
});
data_saddle.push({
lat: 3.7161888888e+01,
lng: 1.3928544444e+02,
content:'Saddle = 1023.400024 pos = 37.1619,139.2854 diff = 510.799927'
});
data_peak.push({
lat: 3.7252999999e+01,
lng: 1.3926522222e+02,
cert : false,
content:' Peak = 1453.199951 pos = 37.2530,139.2652 diff = 214.899902'
});
data_saddle.push({
lat: 3.7235666666e+01,
lng: 1.3925366667e+02,
content:'Saddle = 1238.300049 pos = 37.2357,139.2537 diff = 214.899902'
});
data_peak.push({
lat: 3.7242555554e+01,
lng: 1.3925444444e+02,
cert : true,
content:'Name = JA/FS-027(JA/FS-027) peak = 1452.199951 pos = 37.2426,139.2544 diff = 199.799927'
});
data_saddle.push({
lat: 3.7249555554e+01,
lng: 1.3925988889e+02,
content:'Saddle = 1252.400024 pos = 37.2496,139.2599 diff = 199.799927'
});
data_peak.push({
lat: 3.7173111110e+01,
lng: 1.3968000000e+02,
cert : false,
content:' Peak = 1211.500000 pos = 37.1731,139.6800 diff = 166.500000'
});
data_saddle.push({
lat: 3.7159333332e+01,
lng: 1.3968000000e+02,
content:'Saddle = 1045.000000 pos = 37.1593,139.6800 diff = 166.500000'
});
data_peak.push({
lat: 3.7110555554e+01,
lng: 1.3954077778e+02,
cert : true,
content:'Name = JA/FS-038(JA/FS-038) peak = 1338.599976 pos = 37.1106,139.5408 diff = 274.799927'
});
data_saddle.push({
lat: 3.7120999999e+01,
lng: 1.3954944444e+02,
content:'Saddle = 1063.800049 pos = 37.1210,139.5494 diff = 274.799927'
});
data_peak.push({
lat: 3.7246333332e+01,
lng: 1.3969611111e+02,
cert : false,
content:' Peak = 1237.900024 pos = 37.2463,139.6961 diff = 169.800049'
});
data_saddle.push({
lat: 3.7241777777e+01,
lng: 1.3967033333e+02,
content:'Saddle = 1068.099976 pos = 37.2418,139.6703 diff = 169.800049'
});
data_peak.push({
lat: 3.7114444443e+01,
lng: 1.3947600000e+02,
cert : false,
content:' Peak = 1314.199951 pos = 37.1144,139.4760 diff = 244.199951'
});
data_saddle.push({
lat: 3.7096444443e+01,
lng: 1.3947155556e+02,
content:'Saddle = 1070.000000 pos = 37.0964,139.4716 diff = 244.199951'
});
data_peak.push({
lat: 3.7124555554e+01,
lng: 1.3964922222e+02,
cert : true,
content:'Name = JA/FS-014(JA/FS-014) peak = 1637.800049 pos = 37.1246,139.6492 diff = 563.600098'
});
data_saddle.push({
lat: 3.7086666665e+01,
lng: 1.3965377778e+02,
content:'Saddle = 1074.199951 pos = 37.0867,139.6538 diff = 563.600098'
});
data_peak.push({
lat: 3.7021222221e+01,
lng: 1.3967855556e+02,
cert : false,
content:' Peak = 1342.099976 pos = 37.0212,139.6786 diff = 259.099976'
});
data_saddle.push({
lat: 3.7043111110e+01,
lng: 1.3967866667e+02,
content:'Saddle = 1083.000000 pos = 37.0431,139.6787 diff = 259.099976'
});
data_peak.push({
lat: 3.7090666665e+01,
lng: 1.3946588889e+02,
cert : true,
content:'Name = JA/FS-042(JA/FS-042) peak = 1295.400024 pos = 37.0907,139.4659 diff = 202.599976'
});
data_saddle.push({
lat: 3.7073666665e+01,
lng: 1.3945855556e+02,
content:'Saddle = 1092.800049 pos = 37.0737,139.4586 diff = 202.599976'
});
data_peak.push({
lat: 3.6711888887e+01,
lng: 1.3955455556e+02,
cert : true,
content:'Name = JA/TG-039(JA/TG-039) peak = 1285.400024 pos = 36.7119,139.5546 diff = 177.900024'
});
data_saddle.push({
lat: 3.6712888887e+01,
lng: 1.3954344444e+02,
content:'Saddle = 1107.500000 pos = 36.7129,139.5434 diff = 177.900024'
});
data_peak.push({
lat: 3.7131666665e+01,
lng: 1.3925711111e+02,
cert : false,
content:' Peak = 1264.300049 pos = 37.1317,139.2571 diff = 151.600098'
});
data_saddle.push({
lat: 3.7114888888e+01,
lng: 1.3927344444e+02,
content:'Saddle = 1112.699951 pos = 37.1149,139.2734 diff = 151.600098'
});
data_peak.push({
lat: 3.7070111110e+01,
lng: 1.3943288889e+02,
cert : false,
content:' Peak = 1291.099976 pos = 37.0701,139.4329 diff = 173.500000'
});
data_saddle.push({
lat: 3.7058222221e+01,
lng: 1.3944200000e+02,
content:'Saddle = 1117.599976 pos = 37.0582,139.4420 diff = 173.500000'
});
data_peak.push({
lat: 3.7071777777e+01,
lng: 1.3956822222e+02,
cert : false,
content:' Peak = 1300.800049 pos = 37.0718,139.5682 diff = 158.300049'
});
data_saddle.push({
lat: 3.7068333332e+01,
lng: 1.3957344444e+02,
content:'Saddle = 1142.500000 pos = 37.0683,139.5734 diff = 158.300049'
});
data_peak.push({
lat: 3.7004888888e+01,
lng: 1.3964788889e+02,
cert : false,
content:' Peak = 1343.900024 pos = 37.0049,139.6479 diff = 181.599976'
});
data_saddle.push({
lat: 3.7011999999e+01,
lng: 1.3964200000e+02,
content:'Saddle = 1162.300049 pos = 37.0120,139.6420 diff = 181.599976'
});
data_peak.push({
lat: 3.7036111110e+01,
lng: 1.3964366667e+02,
cert : false,
content:' Peak = 1580.699951 pos = 37.0361,139.6437 diff = 417.899902'
});
data_saddle.push({
lat: 3.7013666665e+01,
lng: 1.3959277778e+02,
content:'Saddle = 1162.800049 pos = 37.0137,139.5928 diff = 417.899902'
});
data_peak.push({
lat: 3.7049111110e+01,
lng: 1.3958800000e+02,
cert : true,
content:'Name = JA/FS-020(JA/FS-020) peak = 1551.000000 pos = 37.0491,139.5880 diff = 282.900024'
});
data_saddle.push({
lat: 3.7035777777e+01,
lng: 1.3961522222e+02,
content:'Saddle = 1268.099976 pos = 37.0358,139.6152 diff = 282.900024'
});
data_peak.push({
lat: 3.7092222221e+01,
lng: 1.3928122222e+02,
cert : true,
content:'Name = JA/FS-037(JA/FS-037) peak = 1363.199951 pos = 37.0922,139.2812 diff = 192.699951'
});
data_saddle.push({
lat: 3.7094666665e+01,
lng: 1.3929866667e+02,
content:'Saddle = 1170.500000 pos = 37.0947,139.2987 diff = 192.699951'
});
data_peak.push({
lat: 3.7050222221e+01,
lng: 1.3941755556e+02,
cert : false,
content:' Peak = 1342.199951 pos = 37.0502,139.4176 diff = 154.599976'
});
data_saddle.push({
lat: 3.7044555554e+01,
lng: 1.3942144444e+02,
content:'Saddle = 1187.599976 pos = 37.0446,139.4214 diff = 154.599976'
});
data_peak.push({
lat: 3.6929444443e+01,
lng: 1.3960000000e+02,
cert : true,
content:'Name = JA/TG-023(JA/TG-023) peak = 1593.000000 pos = 36.9294,139.6000 diff = 402.199951'
});
data_saddle.push({
lat: 3.6913222221e+01,
lng: 1.3954433333e+02,
content:'Saddle = 1190.800049 pos = 36.9132,139.5443 diff = 402.199951'
});
data_peak.push({
lat: 3.6919777776e+01,
lng: 1.3957655556e+02,
cert : true,
content:'Name = JA/TG-029(JA/TG-029) peak = 1460.099976 pos = 36.9198,139.5766 diff = 248.099976'
});
data_saddle.push({
lat: 3.6912777776e+01,
lng: 1.3958466667e+02,
content:'Saddle = 1212.000000 pos = 36.9128,139.5847 diff = 248.099976'
});
data_peak.push({
lat: 3.7014888888e+01,
lng: 1.3958177778e+02,
cert : true,
content:'Name = JA/TG-030(JA/TG-030) peak = 1397.400024 pos = 37.0149,139.5818 diff = 200.200073'
});
data_saddle.push({
lat: 3.7001888888e+01,
lng: 1.3957411111e+02,
content:'Saddle = 1197.199951 pos = 37.0019,139.5741 diff = 200.200073'
});
data_peak.push({
lat: 3.6689777776e+01,
lng: 1.3953300000e+02,
cert : true,
content:'Name = JA/TG-025(JA/TG-025) peak = 1525.099976 pos = 36.6898,139.5330 diff = 327.599976'
});
data_saddle.push({
lat: 3.6710666665e+01,
lng: 1.3951411111e+02,
content:'Saddle = 1197.500000 pos = 36.7107,139.5141 diff = 327.599976'
});
data_peak.push({
lat: 3.7103999999e+01,
lng: 1.3902400000e+02,
cert : true,
content:'Name = Hakkaisan (Nyuudoudake)(JA/NI-017) peak = 1776.400024 pos = 37.1040,139.0240 diff = 528.700073'
});
data_saddle.push({
lat: 3.7095444443e+01,
lng: 1.3904733333e+02,
content:'Saddle = 1247.699951 pos = 37.0954,139.0473 diff = 528.700073'
});
data_peak.push({
lat: 3.7047999999e+01,
lng: 1.3944944444e+02,
cert : true,
content:'Name = JA/FS-029(JA/FS-029) peak = 1423.400024 pos = 37.0480,139.4494 diff = 169.800049'
});
data_saddle.push({
lat: 3.7033777777e+01,
lng: 1.3944400000e+02,
content:'Saddle = 1253.599976 pos = 37.0338,139.4440 diff = 169.800049'
});
data_peak.push({
lat: 3.7180999999e+01,
lng: 1.3946866667e+02,
cert : true,
content:'Name = JA/FS-025(JA/FS-025) peak = 1484.300049 pos = 37.1810,139.4687 diff = 182.300049'
});
data_saddle.push({
lat: 3.7170222221e+01,
lng: 1.3945844444e+02,
content:'Saddle = 1302.000000 pos = 37.1702,139.4584 diff = 182.300049'
});
data_peak.push({
lat: 3.7029999999e+01,
lng: 1.3927544444e+02,
cert : false,
content:' Peak = 1497.000000 pos = 37.0300,139.2754 diff = 183.800049'
});
data_saddle.push({
lat: 3.7007999999e+01,
lng: 1.3927977778e+02,
content:'Saddle = 1313.199951 pos = 37.0080,139.2798 diff = 183.800049'
});
data_peak.push({
lat: 3.7156333332e+01,
lng: 1.3944588889e+02,
cert : true,
content:'Name = JA/FS-023(JA/FS-023) peak = 1524.900024 pos = 37.1563,139.4459 diff = 204.700073'
});
data_saddle.push({
lat: 3.7133111110e+01,
lng: 1.3941544444e+02,
content:'Saddle = 1320.199951 pos = 37.1331,139.4154 diff = 204.700073'
});
data_peak.push({
lat: 3.7063333332e+01,
lng: 1.3917400000e+02,
cert : true,
content:'Name = JA/NI-025(JA/NI-025) peak = 1520.800049 pos = 37.0633,139.1740 diff = 178.500000'
});
data_saddle.push({
lat: 3.7057555554e+01,
lng: 1.3917233333e+02,
content:'Saddle = 1342.300049 pos = 37.0576,139.1723 diff = 178.500000'
});
data_peak.push({
lat: 3.6710777776e+01,
lng: 1.3947577778e+02,
cert : true,
content:'Name = JA/TG-020(JA/TG-020) peak = 1752.199951 pos = 36.7108,139.4758 diff = 344.599976'
});
data_saddle.push({
lat: 3.6717111110e+01,
lng: 1.3945911111e+02,
content:'Saddle = 1407.599976 pos = 36.7171,139.4591 diff = 344.599976'
});
data_peak.push({
lat: 3.7138666665e+01,
lng: 1.3940811111e+02,
cert : true,
content:'Name = JA/FS-017(JA/FS-017) peak = 1602.099976 pos = 37.1387,139.4081 diff = 190.599976'
});
data_saddle.push({
lat: 3.7122111110e+01,
lng: 1.3939122222e+02,
content:'Saddle = 1411.500000 pos = 37.1221,139.3912 diff = 190.599976'
});
data_peak.push({
lat: 3.7221222221e+01,
lng: 1.3933955556e+02,
cert : true,
content:'Name = Asahidake(JA/FS-016) peak = 1622.800049 pos = 37.2212,139.3396 diff = 201.200073'
});
data_saddle.push({
lat: 3.7194333332e+01,
lng: 1.3933477778e+02,
content:'Saddle = 1421.599976 pos = 37.1943,139.3348 diff = 201.200073'
});
data_peak.push({
lat: 3.7046888888e+01,
lng: 1.3955088889e+02,
cert : true,
content:'Name = JA/FS-015(JA/FS-015) peak = 1630.000000 pos = 37.0469,139.5509 diff = 198.599976'
});
data_saddle.push({
lat: 3.7023444443e+01,
lng: 1.3955111111e+02,
content:'Saddle = 1431.400024 pos = 37.0234,139.5511 diff = 198.599976'
});
data_peak.push({
lat: 3.6760444443e+01,
lng: 1.3943033333e+02,
cert : true,
content:'Name = JA/TG-022(JA/TG-022) peak = 1666.900024 pos = 36.7604,139.4303 diff = 227.800049'
});
data_saddle.push({
lat: 3.6772888887e+01,
lng: 1.3941755556e+02,
content:'Saddle = 1439.099976 pos = 36.7729,139.4176 diff = 227.800049'
});
data_peak.push({
lat: 3.6979333332e+01,
lng: 1.3900066667e+02,
cert : false,
content:' Peak = 1680.800049 pos = 36.9793,139.0007 diff = 238.500000'
});
data_saddle.push({
lat: 3.6983333332e+01,
lng: 1.3900644444e+02,
content:'Saddle = 1442.300049 pos = 36.9833,139.0064 diff = 238.500000'
});
data_peak.push({
lat: 3.7172666666e+01,
lng: 1.3933488889e+02,
cert : true,
content:'Name = Maruyamadake(JA/FS-008) peak = 1816.300049 pos = 37.1727,139.3349 diff = 342.800049'
});
data_saddle.push({
lat: 3.7119222221e+01,
lng: 1.3934600000e+02,
content:'Saddle = 1473.500000 pos = 37.1192,139.3460 diff = 342.800049'
});
data_peak.push({
lat: 3.7132777777e+01,
lng: 1.3933944444e+02,
cert : false,
content:' Peak = 1741.800049 pos = 37.1328,139.3394 diff = 179.300049'
});
data_saddle.push({
lat: 3.7145222221e+01,
lng: 1.3933600000e+02,
content:'Saddle = 1562.500000 pos = 37.1452,139.3360 diff = 179.300049'
});
data_peak.push({
lat: 3.7047666665e+01,
lng: 1.3935366667e+02,
cert : true,
content:'Name = Komagatake(JA/FS-002) peak = 2132.100098 pos = 37.0477,139.3537 diff = 623.400146'
});
data_saddle.push({
lat: 3.6983666665e+01,
lng: 1.3930377778e+02,
content:'Saddle = 1508.699951 pos = 36.9837,139.3038 diff = 623.400146'
});
data_peak.push({
lat: 3.7118333332e+01,
lng: 1.3937444444e+02,
cert : false,
content:' Peak = 1770.500000 pos = 37.1183,139.3744 diff = 159.199951'
});
data_saddle.push({
lat: 3.7112222221e+01,
lng: 1.3938066667e+02,
content:'Saddle = 1611.300049 pos = 37.1122,139.3807 diff = 159.199951'
});
data_peak.push({
lat: 3.6998444443e+01,
lng: 1.3930388889e+02,
cert : false,
content:' Peak = 1921.099976 pos = 36.9984,139.3039 diff = 173.199951'
});
data_saddle.push({
lat: 3.7013999999e+01,
lng: 1.3932955556e+02,
content:'Saddle = 1747.900024 pos = 37.0140,139.3296 diff = 173.199951'
});
data_peak.push({
lat: 3.7080888888e+01,
lng: 1.3937711111e+02,
cert : false,
content:' Peak = 2071.600098 pos = 37.0809,139.3771 diff = 152.700073'
});
data_saddle.push({
lat: 3.7063333332e+01,
lng: 1.3937233333e+02,
content:'Saddle = 1918.900024 pos = 37.0633,139.3723 diff = 152.700073'
});
data_peak.push({
lat: 3.6997999999e+01,
lng: 1.3954622222e+02,
cert : true,
content:'Name = JA/FS-011(JA/FS-011) peak = 1752.599976 pos = 36.9980,139.5462 diff = 223.400024'
});
data_saddle.push({
lat: 3.6980555554e+01,
lng: 1.3952788889e+02,
content:'Saddle = 1529.199951 pos = 36.9806,139.5279 diff = 223.400024'
});
data_peak.push({
lat: 3.6805222221e+01,
lng: 1.3913255556e+02,
cert : true,
content:'Name = Hotakayama(JA/GM-005) peak = 2156.600098 pos = 36.8052,139.1326 diff = 614.800049'
});
data_saddle.push({
lat: 3.6836999999e+01,
lng: 1.3918177778e+02,
content:'Saddle = 1541.800049 pos = 36.8370,139.1818 diff = 614.800049'
});
data_peak.push({
lat: 3.7085333332e+01,
lng: 1.3907755556e+02,
cert : true,
content:'Name = Nakanodake(JA/NI-009) peak = 2082.899902 pos = 37.0853,139.0776 diff = 530.199951'
});
data_saddle.push({
lat: 3.7050888888e+01,
lng: 1.3911322222e+02,
content:'Saddle = 1552.699951 pos = 37.0509,139.1132 diff = 530.199951'
});
data_peak.push({
lat: 3.7100444443e+01,
lng: 1.3914811111e+02,
cert : true,
content:'Name = Arasawadake(JA/NI-014) peak = 1966.400024 pos = 37.1004,139.1481 diff = 324.500000'
});
data_saddle.push({
lat: 3.7069444443e+01,
lng: 1.3911577778e+02,
content:'Saddle = 1641.900024 pos = 37.0694,139.1158 diff = 324.500000'
});
data_peak.push({
lat: 3.7078444443e+01,
lng: 1.3913766667e+02,
cert : false,
content:' Peak = 1852.199951 pos = 37.0784,139.1377 diff = 154.699951'
});
data_saddle.push({
lat: 3.7089444443e+01,
lng: 1.3913844444e+02,
content:'Saddle = 1697.500000 pos = 37.0894,139.1384 diff = 154.699951'
});
data_peak.push({
lat: 3.6987333332e+01,
lng: 1.3904722222e+02,
cert : true,
content:'Name = JA/GM-018(JA/GM-018) peak = 1945.199951 pos = 36.9873,139.0472 diff = 292.699951'
});
data_saddle.push({
lat: 3.7006111110e+01,
lng: 1.3906966667e+02,
content:'Saddle = 1652.500000 pos = 37.0061,139.0697 diff = 292.699951'
});
data_peak.push({
lat: 3.7008666665e+01,
lng: 1.3908044444e+02,
cert : false,
content:' Peak = 1862.500000 pos = 37.0087,139.0804 diff = 190.300049'
});
data_saddle.push({
lat: 3.7035111110e+01,
lng: 1.3908977778e+02,
content:'Saddle = 1672.199951 pos = 37.0351,139.0898 diff = 190.300049'
});
data_peak.push({
lat: 3.7123666665e+01,
lng: 1.3907522222e+02,
cert : true,
content:'Name = Komagatake(JA/NI-012) peak = 2002.400024 pos = 37.1237,139.0752 diff = 288.200073'
});
data_saddle.push({
lat: 3.7108777777e+01,
lng: 1.3907766667e+02,
content:'Saddle = 1714.199951 pos = 37.1088,139.0777 diff = 288.200073'
});
data_peak.push({
lat: 3.7066333332e+01,
lng: 1.3909788889e+02,
cert : true,
content:'Name = JA/NI-016(JA/NI-016) peak = 1924.000000 pos = 37.0663,139.0979 diff = 195.300049'
});
data_saddle.push({
lat: 3.7075222221e+01,
lng: 1.3908255556e+02,
content:'Saddle = 1728.699951 pos = 37.0752,139.0826 diff = 195.300049'
});
data_peak.push({
lat: 3.6903555554e+01,
lng: 1.3917322222e+02,
cert : true,
content:'Name = Shibutsusan(JA/GM-002) peak = 2226.000000 pos = 36.9036,139.1732 diff = 635.000000'
});
data_saddle.push({
lat: 3.6890222221e+01,
lng: 1.3920033333e+02,
content:'Saddle = 1591.000000 pos = 36.8902,139.2003 diff = 635.000000'
});
data_peak.push({
lat: 3.6841333332e+01,
lng: 1.3919811111e+02,
cert : true,
content:'Name = JA/GM-022(JA/GM-022) peak = 1897.199951 pos = 36.8413,139.1981 diff = 284.699951'
});
data_saddle.push({
lat: 3.6860444443e+01,
lng: 1.3918277778e+02,
content:'Saddle = 1612.500000 pos = 36.8604,139.1828 diff = 284.699951'
});
data_peak.push({
lat: 3.7002111110e+01,
lng: 1.3917077778e+02,
cert : true,
content:'Name = Hiragatake(JA/NI-006) peak = 2140.800049 pos = 37.0021,139.1708 diff = 514.500000'
});
data_saddle.push({
lat: 3.6931444443e+01,
lng: 1.3917044444e+02,
content:'Saddle = 1626.300049 pos = 36.9314,139.1704 diff = 514.500000'
});
data_peak.push({
lat: 3.6960555554e+01,
lng: 1.3914522222e+02,
cert : false,
content:' Peak = 1951.699951 pos = 36.9606,139.1452 diff = 190.699951'
});
data_saddle.push({
lat: 3.6957888888e+01,
lng: 1.3915677778e+02,
content:'Saddle = 1761.000000 pos = 36.9579,139.1568 diff = 190.699951'
});
data_peak.push({
lat: 3.6956888888e+01,
lng: 1.3921055556e+02,
cert : true,
content:'Name = Keiduruyama(JA/GM-012) peak = 2002.400024 pos = 36.9569,139.2106 diff = 210.300049'
});
data_saddle.push({
lat: 3.6972555554e+01,
lng: 1.3917533333e+02,
content:'Saddle = 1792.099976 pos = 36.9726,139.1753 diff = 210.300049'
});
data_peak.push({
lat: 3.6689888887e+01,
lng: 1.3933688889e+02,
cert : true,
content:'Name = Sukaisan(JA/TG-009) peak = 2141.600098 pos = 36.6899,139.3369 diff = 548.700073'
});
data_saddle.push({
lat: 3.6701444443e+01,
lng: 1.3935022222e+02,
content:'Saddle = 1592.900024 pos = 36.7014,139.3502 diff = 548.700073'
});
data_peak.push({
lat: 3.6844444443e+01,
lng: 1.3947666667e+02,
cert : false,
content:' Peak = 1791.300049 pos = 36.8444,139.4767 diff = 188.600098'
});
data_saddle.push({
lat: 3.6834222221e+01,
lng: 1.3947688889e+02,
content:'Saddle = 1602.699951 pos = 36.8342,139.4769 diff = 188.600098'
});
data_peak.push({
lat: 3.6987444443e+01,
lng: 1.3941333333e+02,
cert : false,
content:' Peak = 1844.199951 pos = 36.9874,139.4133 diff = 176.299927'
});
data_saddle.push({
lat: 3.6991555554e+01,
lng: 1.3943177778e+02,
content:'Saddle = 1667.900024 pos = 36.9916,139.4318 diff = 176.299927'
});
data_peak.push({
lat: 3.6724666665e+01,
lng: 1.3936677778e+02,
cert : true,
content:'Name = JA/TG-012(JA/TG-012) peak = 1980.099976 pos = 36.7247,139.3668 diff = 276.900024'
});
data_saddle.push({
lat: 3.6736444443e+01,
lng: 1.3936700000e+02,
content:'Saddle = 1703.199951 pos = 36.7364,139.3670 diff = 276.900024'
});
data_peak.push({
lat: 3.6724444443e+01,
lng: 1.3941155556e+02,
cert : true,
content:'Name = JA/TG-013(JA/TG-013) peak = 1974.900024 pos = 36.7244,139.4116 diff = 183.200073'
});
data_saddle.push({
lat: 3.6723999998e+01,
lng: 1.3938955556e+02,
content:'Saddle = 1791.699951 pos = 36.7240,139.3896 diff = 183.200073'
});
data_peak.push({
lat: 3.6811333332e+01,
lng: 1.3943988889e+02,
cert : true,
content:'Name = JA/TG-014(JA/TG-014) peak = 1943.900024 pos = 36.8113,139.4399 diff = 227.400024'
});
data_saddle.push({
lat: 3.6813333332e+01,
lng: 1.3945044444e+02,
content:'Saddle = 1716.500000 pos = 36.8133,139.4504 diff = 227.400024'
});
data_peak.push({
lat: 3.6886444443e+01,
lng: 1.3927177778e+02,
cert : true,
content:'Name = JA/GM-011(JA/GM-011) peak = 2023.400024 pos = 36.8864,139.2718 diff = 301.400024'
});
data_saddle.push({
lat: 3.6920444443e+01,
lng: 1.3929466667e+02,
content:'Saddle = 1722.000000 pos = 36.9204,139.2947 diff = 301.400024'
});
data_peak.push({
lat: 3.6914777776e+01,
lng: 1.3927788889e+02,
cert : false,
content:' Peak = 1916.099976 pos = 36.9148,139.2779 diff = 168.299927'
});
data_saddle.push({
lat: 3.6907666665e+01,
lng: 1.3927488889e+02,
content:'Saddle = 1747.800049 pos = 36.9077,139.2749 diff = 168.299927'
});
data_peak.push({
lat: 3.6765222221e+01,
lng: 1.3949077778e+02,
cert : true,
content:'Name = Nantaisan(JA/TG-002) peak = 2483.300049 pos = 36.7652,139.4908 diff = 755.600098'
});
data_saddle.push({
lat: 3.6823888887e+01,
lng: 1.3945855556e+02,
content:'Saddle = 1727.699951 pos = 36.8239,139.4586 diff = 755.600098'
});
data_peak.push({
lat: 3.6811555554e+01,
lng: 1.3953644444e+02,
cert : true,
content:'Name = Nyohousan(JA/TG-003) peak = 2480.100098 pos = 36.8116,139.5364 diff = 695.300049'
});
data_saddle.push({
lat: 3.6784555554e+01,
lng: 1.3950133333e+02,
content:'Saddle = 1784.800049 pos = 36.7846,139.5013 diff = 695.300049'
});
data_peak.push({
lat: 3.6817888887e+01,
lng: 1.3948277778e+02,
cert : true,
content:'Name = Tarousan(JA/TG-006) peak = 2365.699951 pos = 36.8179,139.4828 diff = 486.399902'
});
data_saddle.push({
lat: 3.6813888887e+01,
lng: 1.3949500000e+02,
content:'Saddle = 1879.300049 pos = 36.8139,139.4950 diff = 486.399902'
});
data_peak.push({
lat: 3.6817999999e+01,
lng: 1.3946300000e+02,
cert : false,
content:' Peak = 2075.300049 pos = 36.8180,139.4630 diff = 156.900024'
});
data_saddle.push({
lat: 3.6817222221e+01,
lng: 1.3946855556e+02,
content:'Saddle = 1918.400024 pos = 36.8172,139.4686 diff = 156.900024'
});
data_peak.push({
lat: 3.6795333332e+01,
lng: 1.3950700000e+02,
cert : true,
content:'Name = Nyohousan (Oomanagosan)(JA/TG-005) peak = 2374.699951 pos = 36.7953,139.5070 diff = 335.899902'
});
data_saddle.push({
lat: 3.6810333332e+01,
lng: 1.3951555556e+02,
content:'Saddle = 2038.800049 pos = 36.8103,139.5156 diff = 335.899902'
});
data_peak.push({
lat: 3.6807333332e+01,
lng: 1.3951077778e+02,
cert : false,
content:' Peak = 2322.500000 pos = 36.8073,139.5108 diff = 210.100098'
});
data_saddle.push({
lat: 3.6802888887e+01,
lng: 1.3951088889e+02,
content:'Saddle = 2112.399902 pos = 36.8029,139.5109 diff = 210.100098'
});
data_peak.push({
lat: 3.6955222221e+01,
lng: 1.3928522222e+02,
cert : true,
content:'Name = Hiuchigatake (Shibayasugura)(JA/FS-001) peak = 2353.100098 pos = 36.9552,139.2852 diff = 620.000122'
});
data_saddle.push({
lat: 3.6942444443e+01,
lng: 1.3931311111e+02,
content:'Saddle = 1733.099976 pos = 36.9424,139.3131 diff = 620.000122'
});
data_peak.push({
lat: 3.6969888888e+01,
lng: 1.3946000000e+02,
cert : true,
content:'Name = Taishakuzan(JA/TG-011) peak = 2056.800049 pos = 36.9699,139.4600 diff = 269.500000'
});
data_saddle.push({
lat: 3.6963888888e+01,
lng: 1.3945866667e+02,
content:'Saddle = 1787.300049 pos = 36.9639,139.4587 diff = 269.500000'
});
data_peak.push({
lat: 3.6844111110e+01,
lng: 1.3932977778e+02,
cert : true,
content:'Name = JA/GM-006(JA/GM-006) peak = 2155.100098 pos = 36.8441,139.3298 diff = 333.600098'
});
data_saddle.push({
lat: 3.6847888887e+01,
lng: 1.3933588889e+02,
content:'Saddle = 1821.500000 pos = 36.8479,139.3359 diff = 333.600098'
});
data_peak.push({
lat: 3.6827111110e+01,
lng: 1.3944766667e+02,
cert : false,
content:' Peak = 2020.199951 pos = 36.8271,139.4477 diff = 168.699951'
});
data_saddle.push({
lat: 3.6829444443e+01,
lng: 1.3943888889e+02,
content:'Saddle = 1851.500000 pos = 36.8294,139.4389 diff = 168.699951'
});
data_peak.push({
lat: 3.6947555554e+01,
lng: 1.3944177778e+02,
cert : false,
content:' Peak = 2060.399902 pos = 36.9476,139.4418 diff = 187.899902'
});
data_saddle.push({
lat: 3.6939444443e+01,
lng: 1.3943466667e+02,
content:'Saddle = 1872.500000 pos = 36.9394,139.4347 diff = 187.899902'
});
data_peak.push({
lat: 3.6912999999e+01,
lng: 1.3934922222e+02,
cert : false,
content:' Peak = 2041.699951 pos = 36.9130,139.3492 diff = 163.299927'
});
data_saddle.push({
lat: 3.6916333332e+01,
lng: 1.3936033333e+02,
content:'Saddle = 1878.400024 pos = 36.9163,139.3603 diff = 163.299927'
});
data_peak.push({
lat: 3.6852777776e+01,
lng: 1.3934844444e+02,
cert : true,
content:'Name = JA/GM-003(JA/GM-003) peak = 2220.800049 pos = 36.8528,139.3484 diff = 278.600098'
});
data_saddle.push({
lat: 3.6840333332e+01,
lng: 1.3937066667e+02,
content:'Saddle = 1942.199951 pos = 36.8403,139.3707 diff = 278.600098'
});
data_peak.push({
lat: 3.6908777776e+01,
lng: 1.3939366667e+02,
cert : true,
content:'Name = Kuroiwayama(JA/TG-008) peak = 2161.600098 pos = 36.9088,139.3937 diff = 189.900146'
});
data_saddle.push({
lat: 3.6901888888e+01,
lng: 1.3938922222e+02,
content:'Saddle = 1971.699951 pos = 36.9019,139.3892 diff = 189.900146'
});
data_peak.push({
lat: 3.6824555554e+01,
lng: 1.3940377778e+02,
cert : true,
content:'Name = JA/TG-007(JA/TG-007) peak = 2331.399902 pos = 36.8246,139.4038 diff = 320.099854'
});
data_saddle.push({
lat: 3.6818999999e+01,
lng: 1.3939500000e+02,
content:'Saddle = 2011.300049 pos = 36.8190,139.3950 diff = 320.099854'
});
data_peak.push({
lat: 3.6773666665e+01,
lng: 1.3935300000e+02,
cert : true,
content:'Name = JA/TG-004(JA/TG-004) peak = 2386.199951 pos = 36.7737,139.3530 diff = 218.500000'
});
data_saddle.push({
lat: 3.6777555554e+01,
lng: 1.3936144444e+02,
content:'Saddle = 2167.699951 pos = 36.7776,139.3614 diff = 218.500000'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:38.6667,
       south:36.6667,
       east:141,
       west:139}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
