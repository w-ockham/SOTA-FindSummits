function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.3137111111e+01,
lng: 1.3976600000e+02,
cert : true,
content:'Name = Nishiyama  (Hachijoufuji)(JA/TK-010) peak = 853.599976 pos = 33.1371,139.7660 diff = 853.599976'
});
data_saddle.push({
lat: 3.3333333333e+01,
lng: 1.3900000000e+02,
content:'Saddle = 0.000000 pos = 33.3333,139.0000 diff = 853.599976'
});
data_peak.push({
lat: 3.2458555556e+01,
lng: 1.3975911111e+02,
cert : true,
content:'Name = Otonbu(JA/TK-022) peak = 421.399994 pos = 32.4586,139.7591 diff = 421.399994'
});
data_saddle.push({
lat: 3.3045333333e+01,
lng: 1.3983277778e+02,
content:'Saddle = 0.000000 pos = 33.0453,139.8328 diff = 421.399994'
});
data_peak.push({
lat: 3.3125666667e+01,
lng: 1.3968822222e+02,
cert : true,
content:'Name = Taiheizan(JA/TK-017) peak = 613.000000 pos = 33.1257,139.6882 diff = 613.000000'
});
data_saddle.push({
lat: 3.3115555556e+01,
lng: 1.3969888889e+02,
content:'Saddle = 0.000000 pos = 33.1156,139.6989 diff = 613.000000'
});
data_peak.push({
lat: 3.3092111111e+01,
lng: 1.3981211111e+02,
cert : true,
content:'Name = Miharayama(JA/TK-016) peak = 700.400024 pos = 33.0921,139.8121 diff = 625.200012'
});
data_saddle.push({
lat: 3.3111666667e+01,
lng: 1.3979366667e+02,
content:'Saddle = 75.199997 pos = 33.1117,139.7937 diff = 625.200012'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:33.3333,
       south:31.3333,
       east:140,
       west:139}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
