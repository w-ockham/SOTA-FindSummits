function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.1934111112e+01,
lng: 1.3086177778e+02,
cert : true,
content:'Name = Kirishimayama (Karakunidake)(JA6/KG-003) peak = 1700.000000 pos = 31.9341,130.8618 diff = 1700.000000'
});
data_saddle.push({
lat: 3.3999444444e+01,
lng: 1.3081566667e+02,
content:'Saddle = 0.000000 pos = 33.9994,130.8157 diff = 1700.000000'
});
data_peak.push({
lat: 3.1801000001e+01,
lng: 1.2983000000e+02,
cert : false,
content:' Peak = 295.200012 pos = 31.8010,129.8300 diff = 295.200012'
});
data_saddle.push({
lat: 3.1774111112e+01,
lng: 1.2982622222e+02,
content:'Saddle = 0.000000 pos = 31.7741,129.8262 diff = 295.200012'
});
data_peak.push({
lat: 3.2158666667e+01,
lng: 1.3015755556e+02,
cert : true,
content:'Name = JA6/KG-101(JA6/KG-101) peak = 402.500000 pos = 32.1587,130.1576 diff = 402.500000'
});
data_saddle.push({
lat: 3.2089555556e+01,
lng: 1.3015744444e+02,
content:'Saddle = 0.000000 pos = 32.0896,130.1574 diff = 402.500000'
});
data_peak.push({
lat: 3.2116222223e+01,
lng: 1.3016266667e+02,
cert : false,
content:' Peak = 290.700012 pos = 32.1162,130.1627 diff = 192.300018'
});
data_saddle.push({
lat: 3.2129555556e+01,
lng: 1.3016622222e+02,
content:'Saddle = 98.400002 pos = 32.1296,130.1662 diff = 192.300018'
});
data_peak.push({
lat: 3.1833777779e+01,
lng: 1.2989711111e+02,
cert : true,
content:'Name = JA6/KG-093(JA6/KG-093) peak = 421.299988 pos = 31.8338,129.8971 diff = 421.299988'
});
data_saddle.push({
lat: 3.1800777779e+01,
lng: 1.2987222222e+02,
content:'Saddle = 0.000000 pos = 31.8008,129.8722 diff = 421.299988'
});
data_peak.push({
lat: 3.1860333334e+01,
lng: 1.2991455556e+02,
cert : false,
content:' Peak = 251.100006 pos = 31.8603,129.9146 diff = 246.400009'
});
data_saddle.push({
lat: 3.1849666668e+01,
lng: 1.2992066667e+02,
content:'Saddle = 4.700000 pos = 31.8497,129.9207 diff = 246.400009'
});
data_peak.push({
lat: 3.1858777779e+01,
lng: 1.2982322222e+02,
cert : true,
content:'Name = JA6/KG-125(JA6/KG-125) peak = 305.299988 pos = 31.8588,129.8232 diff = 282.899994'
});
data_saddle.push({
lat: 3.1863222223e+01,
lng: 1.2986855556e+02,
content:'Saddle = 22.400000 pos = 31.8632,129.8686 diff = 282.899994'
});
data_peak.push({
lat: 3.1864333334e+01,
lng: 1.2985466667e+02,
cert : false,
content:' Peak = 227.000000 pos = 31.8643,129.8547 diff = 154.300003'
});
data_saddle.push({
lat: 3.1877666668e+01,
lng: 1.2985655556e+02,
content:'Saddle = 72.699997 pos = 31.8777,129.8566 diff = 154.300003'
});
data_peak.push({
lat: 3.1843333334e+01,
lng: 1.2987344444e+02,
cert : true,
content:'Name = JA6/KG-127(JA6/KG-127) peak = 290.600006 pos = 31.8433,129.8734 diff = 192.000000'
});
data_saddle.push({
lat: 3.1840000001e+01,
lng: 1.2988711111e+02,
content:'Saddle = 98.599998 pos = 31.8400,129.8871 diff = 192.000000'
});
data_peak.push({
lat: 3.1824000001e+01,
lng: 1.2992433333e+02,
cert : false,
content:' Peak = 311.899994 pos = 31.8240,129.9243 diff = 155.099991'
});
data_saddle.push({
lat: 3.1829222223e+01,
lng: 1.2991777778e+02,
content:'Saddle = 156.800003 pos = 31.8292,129.9178 diff = 155.099991'
});
data_peak.push({
lat: 3.2267666667e+01,
lng: 1.3014022222e+02,
cert : false,
content:' Peak = 261.100006 pos = 32.2677,130.1402 diff = 261.100006'
});
data_saddle.push({
lat: 3.2262333334e+01,
lng: 1.3013677778e+02,
content:'Saddle = 0.000000 pos = 32.2623,130.1368 diff = 261.100006'
});
data_peak.push({
lat: 3.2276000001e+01,
lng: 1.3023633333e+02,
cert : true,
content:'Name = JA6/KG-105(JA6/KG-105) peak = 392.399994 pos = 32.2760,130.2363 diff = 392.399994'
});
data_saddle.push({
lat: 3.2250111112e+01,
lng: 1.3021488889e+02,
content:'Saddle = 0.000000 pos = 32.2501,130.2149 diff = 392.399994'
});
data_peak.push({
lat: 3.2351111112e+01,
lng: 1.3033233333e+02,
cert : false,
content:' Peak = 180.800003 pos = 32.3511,130.3323 diff = 180.800003'
});
data_saddle.push({
lat: 3.2339222223e+01,
lng: 1.3031055556e+02,
content:'Saddle = 0.000000 pos = 32.3392,130.3106 diff = 180.800003'
});
data_peak.push({
lat: 3.2364000001e+01,
lng: 1.3035044444e+02,
cert : false,
content:' Peak = 193.100006 pos = 32.3640,130.3504 diff = 193.100006'
});
data_saddle.push({
lat: 3.2360666667e+01,
lng: 1.3034955556e+02,
content:'Saddle = 0.000000 pos = 32.3607,130.3496 diff = 193.100006'
});
data_peak.push({
lat: 3.2375111112e+01,
lng: 1.3032166667e+02,
cert : false,
content:' Peak = 151.899994 pos = 32.3751,130.3217 diff = 151.899994'
});
data_saddle.push({
lat: 3.2370111112e+01,
lng: 1.3032333333e+02,
content:'Saddle = 0.000000 pos = 32.3701,130.3233 diff = 151.899994'
});
data_peak.push({
lat: 3.2386666667e+01,
lng: 1.3041866667e+02,
cert : false,
content:' Peak = 230.399994 pos = 32.3867,130.4187 diff = 230.399994'
});
data_saddle.push({
lat: 3.2367111112e+01,
lng: 1.3041955556e+02,
content:'Saddle = 0.000000 pos = 32.3671,130.4196 diff = 230.399994'
});
data_peak.push({
lat: 3.2374666667e+01,
lng: 1.3042244444e+02,
cert : false,
content:' Peak = 193.699997 pos = 32.3747,130.4224 diff = 172.699997'
});
data_saddle.push({
lat: 3.2380111112e+01,
lng: 1.3042322222e+02,
content:'Saddle = 21.000000 pos = 32.3801,130.4232 diff = 172.699997'
});
data_peak.push({
lat: 3.2326222223e+01,
lng: 1.3034855556e+02,
cert : true,
content:'Name = JA6/KM-069(JA6/KM-069) peak = 441.399994 pos = 32.3262,130.3486 diff = 441.399994'
});
data_saddle.push({
lat: 3.2303555556e+01,
lng: 1.3030233333e+02,
content:'Saddle = 0.000000 pos = 32.3036,130.3023 diff = 441.399994'
});
data_peak.push({
lat: 3.2436333334e+01,
lng: 1.3008388889e+02,
cert : true,
content:'Name = JA6/KM-056(JA6/KM-056) peak = 535.799988 pos = 32.4363,130.0839 diff = 535.799988'
});
data_saddle.push({
lat: 3.2188555556e+01,
lng: 1.3002288889e+02,
content:'Saddle = 0.000000 pos = 32.1886,130.0229 diff = 535.799988'
});
data_peak.push({
lat: 3.2293000001e+01,
lng: 1.3015433333e+02,
cert : false,
content:' Peak = 253.399994 pos = 32.2930,130.1543 diff = 246.000000'
});
data_saddle.push({
lat: 3.2295333334e+01,
lng: 1.3013666667e+02,
content:'Saddle = 7.400000 pos = 32.2953,130.1367 diff = 246.000000'
});
data_peak.push({
lat: 3.2293555556e+01,
lng: 1.3003644444e+02,
cert : false,
content:' Peak = 260.899994 pos = 32.2936,130.0364 diff = 243.799988'
});
data_saddle.push({
lat: 3.2278777778e+01,
lng: 1.3004244444e+02,
content:'Saddle = 17.100000 pos = 32.2788,130.0424 diff = 243.799988'
});
data_peak.push({
lat: 3.2213777778e+01,
lng: 1.3001988889e+02,
cert : false,
content:' Peak = 227.300003 pos = 32.2138,130.0199 diff = 200.400009'
});
data_saddle.push({
lat: 3.2220111112e+01,
lng: 1.3002400000e+02,
content:'Saddle = 26.900000 pos = 32.2201,130.0240 diff = 200.400009'
});
data_peak.push({
lat: 3.2244444445e+01,
lng: 1.2997388889e+02,
cert : false,
content:' Peak = 223.100006 pos = 32.2444,129.9739 diff = 186.100006'
});
data_saddle.push({
lat: 3.2251777778e+01,
lng: 1.2997455556e+02,
content:'Saddle = 37.000000 pos = 32.2518,129.9746 diff = 186.100006'
});
data_peak.push({
lat: 3.2341222223e+01,
lng: 1.3019100000e+02,
cert : true,
content:'Name = JA6/KM-086(JA6/KM-086) peak = 332.700012 pos = 32.3412,130.1910 diff = 294.000000'
});
data_saddle.push({
lat: 3.2350666667e+01,
lng: 1.3018344444e+02,
content:'Saddle = 38.700001 pos = 32.3507,130.1834 diff = 294.000000'
});
data_peak.push({
lat: 3.2376555556e+01,
lng: 1.3020711111e+02,
cert : false,
content:' Peak = 244.399994 pos = 32.3766,130.2071 diff = 167.699997'
});
data_saddle.push({
lat: 3.2362333334e+01,
lng: 1.3020466667e+02,
content:'Saddle = 76.699997 pos = 32.3623,130.2047 diff = 167.699997'
});
data_peak.push({
lat: 3.2285222223e+01,
lng: 1.3000877778e+02,
cert : false,
content:' Peak = 330.799988 pos = 32.2852,130.0088 diff = 291.299988'
});
data_saddle.push({
lat: 3.2255444445e+01,
lng: 1.3002511111e+02,
content:'Saddle = 39.500000 pos = 32.2554,130.0251 diff = 291.299988'
});
data_peak.push({
lat: 3.2326888890e+01,
lng: 1.3008577778e+02,
cert : false,
content:' Peak = 265.899994 pos = 32.3269,130.0858 diff = 199.000000'
});
data_saddle.push({
lat: 3.2323555556e+01,
lng: 1.3009822222e+02,
content:'Saddle = 66.900002 pos = 32.3236,130.0982 diff = 199.000000'
});
data_peak.push({
lat: 3.2234222223e+01,
lng: 1.3002777778e+02,
cert : true,
content:'Name = JA6/KM-075(JA6/KM-075) peak = 401.399994 pos = 32.2342,130.0278 diff = 303.500000'
});
data_saddle.push({
lat: 3.2257444445e+01,
lng: 1.3006944444e+02,
content:'Saddle = 97.900002 pos = 32.2574,130.0694 diff = 303.500000'
});
data_peak.push({
lat: 3.2259666667e+01,
lng: 1.3004200000e+02,
cert : true,
content:'Name = JA6/KM-084(JA6/KM-084) peak = 340.500000 pos = 32.2597,130.0420 diff = 222.000000'
});
data_saddle.push({
lat: 3.2243222223e+01,
lng: 1.3004255556e+02,
content:'Saddle = 118.500000 pos = 32.2432,130.0426 diff = 222.000000'
});
data_peak.push({
lat: 3.2265222223e+01,
lng: 1.3005266667e+02,
cert : false,
content:' Peak = 294.700012 pos = 32.2652,130.0527 diff = 152.300018'
});
data_saddle.push({
lat: 3.2261000001e+01,
lng: 1.3004822222e+02,
content:'Saddle = 142.399994 pos = 32.2610,130.0482 diff = 152.300018'
});
data_peak.push({
lat: 3.2244111112e+01,
lng: 1.3006811111e+02,
cert : false,
content:' Peak = 289.200012 pos = 32.2441,130.0681 diff = 167.100006'
});
data_saddle.push({
lat: 3.2229000001e+01,
lng: 1.3004211111e+02,
content:'Saddle = 122.099998 pos = 32.2290,130.0421 diff = 167.100006'
});
data_peak.push({
lat: 3.2374333334e+01,
lng: 1.3015311111e+02,
cert : true,
content:'Name = JA6/KM-087(JA6/KM-087) peak = 330.299988 pos = 32.3743,130.1531 diff = 215.999985'
});
data_saddle.push({
lat: 3.2358111112e+01,
lng: 1.3014888889e+02,
content:'Saddle = 114.300003 pos = 32.3581,130.1489 diff = 215.999985'
});
data_peak.push({
lat: 3.2296333334e+01,
lng: 1.3011666667e+02,
cert : true,
content:'Name = JA6/KM-070(JA6/KM-070) peak = 430.000000 pos = 32.2963,130.1167 diff = 312.899994'
});
data_saddle.push({
lat: 3.2349222223e+01,
lng: 1.3014077778e+02,
content:'Saddle = 117.099998 pos = 32.3492,130.1408 diff = 312.899994'
});
data_peak.push({
lat: 3.2266666667e+01,
lng: 1.3008855556e+02,
cert : true,
content:'Name = JA6/KM-074(JA6/KM-074) peak = 401.700012 pos = 32.2667,130.0886 diff = 238.700012'
});
data_saddle.push({
lat: 3.2273555556e+01,
lng: 1.3010122222e+02,
content:'Saddle = 163.000000 pos = 32.2736,130.1012 diff = 238.700012'
});
data_peak.push({
lat: 3.2447666667e+01,
lng: 1.3015988889e+02,
cert : true,
content:'Name = JA6/KM-081(JA6/KM-081) peak = 381.399994 pos = 32.4477,130.1599 diff = 219.599991'
});
data_saddle.push({
lat: 3.2434555556e+01,
lng: 1.3013255556e+02,
content:'Saddle = 161.800003 pos = 32.4346,130.1326 diff = 219.599991'
});
data_peak.push({
lat: 3.2372888890e+01,
lng: 1.3013922222e+02,
cert : true,
content:'Name = JA6/KM-083(JA6/KM-083) peak = 341.799988 pos = 32.3729,130.1392 diff = 171.699982'
});
data_saddle.push({
lat: 3.2361555556e+01,
lng: 1.3012922222e+02,
content:'Saddle = 170.100006 pos = 32.3616,130.1292 diff = 171.699982'
});
data_peak.push({
lat: 3.2355333334e+01,
lng: 1.2998366667e+02,
cert : false,
content:' Peak = 341.299988 pos = 32.3553,129.9837 diff = 160.799988'
});
data_saddle.push({
lat: 3.2352777778e+01,
lng: 1.2999122222e+02,
content:'Saddle = 180.500000 pos = 32.3528,129.9912 diff = 160.799988'
});
data_peak.push({
lat: 3.2356444445e+01,
lng: 1.3010922222e+02,
cert : true,
content:'Name = JA6/KM-063(JA6/KM-063) peak = 488.700012 pos = 32.3564,130.1092 diff = 292.000000'
});
data_saddle.push({
lat: 3.2378111112e+01,
lng: 1.3010333333e+02,
content:'Saddle = 196.699997 pos = 32.3781,130.1033 diff = 292.000000'
});
data_peak.push({
lat: 3.2342777778e+01,
lng: 1.3005144444e+02,
cert : false,
content:' Peak = 400.600006 pos = 32.3428,130.0514 diff = 177.600006'
});
data_saddle.push({
lat: 3.2349555556e+01,
lng: 1.3004366667e+02,
content:'Saddle = 223.000000 pos = 32.3496,130.0437 diff = 177.600006'
});
data_peak.push({
lat: 3.2360888890e+01,
lng: 1.3007188889e+02,
cert : false,
content:' Peak = 392.600006 pos = 32.3609,130.0719 diff = 164.300003'
});
data_saddle.push({
lat: 3.2369444445e+01,
lng: 1.3006400000e+02,
content:'Saddle = 228.300003 pos = 32.3694,130.0640 diff = 164.300003'
});
data_peak.push({
lat: 3.2421111112e+01,
lng: 1.3014477778e+02,
cert : false,
content:' Peak = 502.399994 pos = 32.4211,130.1448 diff = 264.200012'
});
data_saddle.push({
lat: 3.2412777778e+01,
lng: 1.3011922222e+02,
content:'Saddle = 238.199997 pos = 32.4128,130.1192 diff = 264.200012'
});
data_peak.push({
lat: 3.2399222223e+01,
lng: 1.3009377778e+02,
cert : true,
content:'Name = Kadoyama(JA6/KM-057) peak = 522.900024 pos = 32.3992,130.0938 diff = 229.500031'
});
data_saddle.push({
lat: 3.2424666667e+01,
lng: 1.3010066667e+02,
content:'Saddle = 293.399994 pos = 32.4247,130.1007 diff = 229.500031'
});
data_peak.push({
lat: 3.2399000001e+01,
lng: 1.3007377778e+02,
cert : false,
content:' Peak = 461.299988 pos = 32.3990,130.0738 diff = 164.199982'
});
data_saddle.push({
lat: 3.2397222223e+01,
lng: 1.3008244444e+02,
content:'Saddle = 297.100006 pos = 32.3972,130.0824 diff = 164.199982'
});
data_peak.push({
lat: 3.2376888890e+01,
lng: 1.3005400000e+02,
cert : false,
content:' Peak = 451.100006 pos = 32.3769,130.0540 diff = 153.600006'
});
data_saddle.push({
lat: 3.2382888890e+01,
lng: 1.3006888889e+02,
content:'Saddle = 297.500000 pos = 32.3829,130.0689 diff = 153.600006'
});
data_peak.push({
lat: 3.2384333334e+01,
lng: 1.3009233333e+02,
cert : true,
content:'Name = JA6/KM-065(JA6/KM-065) peak = 480.000000 pos = 32.3843,130.0923 diff = 178.200012'
});
data_saddle.push({
lat: 3.2393333334e+01,
lng: 1.3009511111e+02,
content:'Saddle = 301.799988 pos = 32.3933,130.0951 diff = 178.200012'
});
data_peak.push({
lat: 3.1723333334e+01,
lng: 1.2973933333e+02,
cert : true,
content:'Name = Otake(JA6/KG-044) peak = 603.900024 pos = 31.7233,129.7393 diff = 603.900024'
});
data_saddle.push({
lat: 3.1621222223e+01,
lng: 1.2968888889e+02,
content:'Saddle = 0.000000 pos = 31.6212,129.6889 diff = 603.900024'
});
data_peak.push({
lat: 3.1625555557e+01,
lng: 1.2971311111e+02,
cert : false,
content:' Peak = 163.800003 pos = 31.6256,129.7131 diff = 160.500000'
});
data_saddle.push({
lat: 3.1633444445e+01,
lng: 1.2971144444e+02,
content:'Saddle = 3.300000 pos = 31.6334,129.7114 diff = 160.500000'
});
data_peak.push({
lat: 3.1658444445e+01,
lng: 1.2971355556e+02,
cert : false,
content:' Peak = 482.700012 pos = 31.6584,129.7136 diff = 161.700012'
});
data_saddle.push({
lat: 3.1660666668e+01,
lng: 1.2970755556e+02,
content:'Saddle = 321.000000 pos = 31.6607,129.7076 diff = 161.700012'
});
data_peak.push({
lat: 3.2565111112e+01,
lng: 1.3047822222e+02,
cert : false,
content:' Peak = 161.699997 pos = 32.5651,130.4782 diff = 161.699997'
});
data_saddle.push({
lat: 3.2539444445e+01,
lng: 1.3046422222e+02,
content:'Saddle = 0.000000 pos = 32.5394,130.4642 diff = 161.699997'
});
data_peak.push({
lat: 3.2610888889e+01,
lng: 1.3045277778e+02,
cert : false,
content:' Peak = 227.899994 pos = 32.6109,130.4528 diff = 227.899994'
});
data_saddle.push({
lat: 3.2545666667e+01,
lng: 1.3042277778e+02,
content:'Saddle = 0.000000 pos = 32.5457,130.4228 diff = 227.899994'
});
data_peak.push({
lat: 3.2622222223e+01,
lng: 1.3044100000e+02,
cert : false,
content:' Peak = 224.199997 pos = 32.6222,130.4410 diff = 207.099991'
});
data_saddle.push({
lat: 3.2614333334e+01,
lng: 1.3044388889e+02,
content:'Saddle = 17.100000 pos = 32.6143,130.4439 diff = 207.099991'
});
data_peak.push({
lat: 3.2772777778e+01,
lng: 1.2900022222e+02,
cert : true,
content:'Name = JA6/NS-060(JA6/NS-060) peak = 320.700012 pos = 32.7728,129.0002 diff = 320.700012'
});
data_saddle.push({
lat: 3.2749888889e+01,
lng: 1.2900122222e+02,
content:'Saddle = 0.000000 pos = 32.7499,129.0012 diff = 320.700012'
});
data_peak.push({
lat: 3.2751888889e+01,
lng: 1.2900388889e+02,
cert : false,
content:' Peak = 183.100006 pos = 32.7519,129.0039 diff = 177.000000'
});
data_saddle.push({
lat: 3.2754666667e+01,
lng: 1.2900000000e+02,
content:'Saddle = 6.100000 pos = 32.7547,129.0000 diff = 177.000000'
});
data_peak.push({
lat: 3.3011333334e+01,
lng: 1.2901800000e+02,
cert : false,
content:' Peak = 154.000000 pos = 33.0113,129.0180 diff = 154.000000'
});
data_saddle.push({
lat: 3.3001444445e+01,
lng: 1.2900911111e+02,
content:'Saddle = 0.000000 pos = 33.0014,129.0091 diff = 154.000000'
});
data_peak.push({
lat: 3.3040444445e+01,
lng: 1.2961011111e+02,
cert : false,
content:' Peak = 190.699997 pos = 33.0404,129.6101 diff = 190.699997'
});
data_saddle.push({
lat: 3.3022111112e+01,
lng: 1.2960944444e+02,
content:'Saddle = 0.000000 pos = 33.0221,129.6094 diff = 190.699997'
});
data_peak.push({
lat: 3.3006111112e+01,
lng: 1.2924477778e+02,
cert : false,
content:' Peak = 202.899994 pos = 33.0061,129.2448 diff = 202.899994'
});
data_saddle.push({
lat: 3.2988777778e+01,
lng: 1.2923433333e+02,
content:'Saddle = 0.000000 pos = 32.9888,129.2343 diff = 202.899994'
});
data_peak.push({
lat: 3.3092888889e+01,
lng: 1.2974700000e+02,
cert : false,
content:' Peak = 207.800003 pos = 33.0929,129.7470 diff = 207.800003'
});
data_saddle.push({
lat: 3.3050111111e+01,
lng: 1.2976755556e+02,
content:'Saddle = 0.000000 pos = 33.0501,129.7676 diff = 207.800003'
});
data_peak.push({
lat: 3.3094555556e+01,
lng: 1.2978200000e+02,
cert : false,
content:' Peak = 201.600006 pos = 33.0946,129.7820 diff = 184.700012'
});
data_saddle.push({
lat: 3.3111444445e+01,
lng: 1.2976266667e+02,
content:'Saddle = 16.900000 pos = 33.1114,129.7627 diff = 184.700012'
});
data_peak.push({
lat: 3.3117888889e+01,
lng: 1.2976577778e+02,
cert : false,
content:' Peak = 201.300003 pos = 33.1179,129.7658 diff = 183.800003'
});
data_saddle.push({
lat: 3.3103111111e+01,
lng: 1.2977511111e+02,
content:'Saddle = 17.500000 pos = 33.1031,129.7751 diff = 183.800003'
});
data_peak.push({
lat: 3.3117888889e+01,
lng: 1.2975000000e+02,
cert : false,
content:' Peak = 183.600006 pos = 33.1179,129.7500 diff = 157.200012'
});
data_saddle.push({
lat: 3.3098888889e+01,
lng: 1.2976111111e+02,
content:'Saddle = 26.400000 pos = 33.0989,129.7611 diff = 157.200012'
});
data_peak.push({
lat: 3.2928222223e+01,
lng: 1.2961133333e+02,
cert : false,
content:' Peak = 212.600006 pos = 32.9282,129.6113 diff = 212.600006'
});
data_saddle.push({
lat: 3.2916111112e+01,
lng: 1.2961144444e+02,
content:'Saddle = 0.000000 pos = 32.9161,129.6114 diff = 212.600006'
});
data_peak.push({
lat: 3.3202444445e+01,
lng: 1.2912433333e+02,
cert : true,
content:'Name = JA6/NS-054(JA6/NS-054) peak = 342.600006 pos = 33.2024,129.1243 diff = 342.600006'
});
data_saddle.push({
lat: 3.3158555556e+01,
lng: 1.2913233333e+02,
content:'Saddle = 0.000000 pos = 33.1586,129.1323 diff = 342.600006'
});
data_peak.push({
lat: 3.3182000000e+01,
lng: 1.2912755556e+02,
cert : false,
content:' Peak = 253.800003 pos = 33.1820,129.1276 diff = 212.700012'
});
data_saddle.push({
lat: 3.3187333334e+01,
lng: 1.2912788889e+02,
content:'Saddle = 41.099998 pos = 33.1873,129.1279 diff = 212.700012'
});
data_peak.push({
lat: 3.3065555556e+01,
lng: 1.2909322222e+02,
cert : true,
content:'Name = JA6/NS-025(JA6/NS-025) peak = 441.600006 pos = 33.0656,129.0932 diff = 441.600006'
});
data_saddle.push({
lat: 3.2816333334e+01,
lng: 1.2905955556e+02,
content:'Saddle = 0.000000 pos = 32.8163,129.0596 diff = 441.600006'
});
data_peak.push({
lat: 3.2985888889e+01,
lng: 1.2915200000e+02,
cert : true,
content:'Name = JA6/NS-045(JA6/NS-045) peak = 363.500000 pos = 32.9859,129.1520 diff = 336.899994'
});
data_saddle.push({
lat: 3.2972333334e+01,
lng: 1.2909933333e+02,
content:'Saddle = 26.600000 pos = 32.9723,129.0993 diff = 336.899994'
});
data_peak.push({
lat: 3.2962888889e+01,
lng: 1.2912822222e+02,
cert : false,
content:' Peak = 333.399994 pos = 32.9629,129.1282 diff = 216.399994'
});
data_saddle.push({
lat: 3.2969444445e+01,
lng: 1.2914000000e+02,
content:'Saddle = 117.000000 pos = 32.9694,129.1400 diff = 216.399994'
});
data_peak.push({
lat: 3.2933444445e+01,
lng: 1.2905277778e+02,
cert : true,
content:'Name = Sannouzan (Odake)(JA6/NS-026) peak = 434.600006 pos = 32.9334,129.0528 diff = 387.399994'
});
data_saddle.push({
lat: 3.2986111112e+01,
lng: 1.2907777778e+02,
content:'Saddle = 47.200001 pos = 32.9861,129.0778 diff = 387.399994'
});
data_peak.push({
lat: 3.2833111112e+01,
lng: 1.2905866667e+02,
cert : false,
content:' Peak = 254.100006 pos = 32.8331,129.0587 diff = 196.500000'
});
data_saddle.push({
lat: 3.2853555556e+01,
lng: 1.2905377778e+02,
content:'Saddle = 57.599998 pos = 32.8536,129.0538 diff = 196.500000'
});
data_peak.push({
lat: 3.2951555556e+01,
lng: 1.2902500000e+02,
cert : true,
content:'Name = JA6/NS-066(JA6/NS-066) peak = 300.899994 pos = 32.9516,129.0250 diff = 234.299988'
});
data_saddle.push({
lat: 3.2953666667e+01,
lng: 1.2903177778e+02,
content:'Saddle = 66.599998 pos = 32.9537,129.0318 diff = 234.299988'
});
data_peak.push({
lat: 3.2966555556e+01,
lng: 1.2904222222e+02,
cert : false,
content:' Peak = 243.000000 pos = 32.9666,129.0422 diff = 165.899994'
});
data_saddle.push({
lat: 3.2950333334e+01,
lng: 1.2904022222e+02,
content:'Saddle = 77.099998 pos = 32.9503,129.0402 diff = 165.899994'
});
data_peak.push({
lat: 3.2859333334e+01,
lng: 1.2905844444e+02,
cert : true,
content:'Name = JA6/NS-058(JA6/NS-058) peak = 321.299988 pos = 32.8593,129.0584 diff = 202.999985'
});
data_saddle.push({
lat: 3.2872888889e+01,
lng: 1.2906455556e+02,
content:'Saddle = 118.300003 pos = 32.8729,129.0646 diff = 202.999985'
});
data_peak.push({
lat: 3.2963000000e+01,
lng: 1.2908677778e+02,
cert : true,
content:'Name = JA6/NS-039(JA6/NS-039) peak = 382.500000 pos = 32.9630,129.0868 diff = 253.899994'
});
data_saddle.push({
lat: 3.2930555556e+01,
lng: 1.2907733333e+02,
content:'Saddle = 128.600006 pos = 32.9306,129.0773 diff = 253.899994'
});
data_peak.push({
lat: 3.2860111112e+01,
lng: 1.2909122222e+02,
cert : true,
content:'Name = JA6/NS-067(JA6/NS-067) peak = 301.799988 pos = 32.8601,129.0912 diff = 166.699982'
});
data_saddle.push({
lat: 3.2872555556e+01,
lng: 1.2907544444e+02,
content:'Saddle = 135.100006 pos = 32.8726,129.0754 diff = 166.699982'
});
data_peak.push({
lat: 3.2920555556e+01,
lng: 1.2906655556e+02,
cert : false,
content:' Peak = 401.700012 pos = 32.9206,129.0666 diff = 163.200012'
});
data_saddle.push({
lat: 3.2930000000e+01,
lng: 1.2906055556e+02,
content:'Saddle = 238.500000 pos = 32.9300,129.0606 diff = 163.200012'
});
data_peak.push({
lat: 3.3010000000e+01,
lng: 1.2905611111e+02,
cert : true,
content:'Name = JA6/NS-027(JA6/NS-027) peak = 430.500000 pos = 33.0100,129.0561 diff = 373.299988'
});
data_saddle.push({
lat: 3.3019555556e+01,
lng: 1.2908666667e+02,
content:'Saddle = 57.200001 pos = 33.0196,129.0867 diff = 373.299988'
});
data_peak.push({
lat: 3.3012000000e+01,
lng: 1.2908244444e+02,
cert : true,
content:'Name = JA6/NS-043(JA6/NS-043) peak = 366.000000 pos = 33.0120,129.0824 diff = 289.399994'
});
data_saddle.push({
lat: 3.3007111112e+01,
lng: 1.2906777778e+02,
content:'Saddle = 76.599998 pos = 33.0071,129.0678 diff = 289.399994'
});
data_peak.push({
lat: 3.3134000000e+01,
lng: 1.2910533333e+02,
cert : false,
content:' Peak = 270.899994 pos = 33.1340,129.1053 diff = 193.500000'
});
data_saddle.push({
lat: 3.3124000000e+01,
lng: 1.2910055556e+02,
content:'Saddle = 77.400002 pos = 33.1240,129.1006 diff = 193.500000'
});
data_peak.push({
lat: 3.3106444445e+01,
lng: 1.2911400000e+02,
cert : true,
content:'Name = JA6/NS-047(JA6/NS-047) peak = 361.200012 pos = 33.1064,129.1140 diff = 269.700012'
});
data_saddle.push({
lat: 3.3087111111e+01,
lng: 1.2910900000e+02,
content:'Saddle = 91.500000 pos = 33.0871,129.1090 diff = 269.700012'
});
data_peak.push({
lat: 3.3047000000e+01,
lng: 1.2909222222e+02,
cert : false,
content:' Peak = 321.399994 pos = 33.0470,129.0922 diff = 204.199997'
});
data_saddle.push({
lat: 3.3054111111e+01,
lng: 1.2908900000e+02,
content:'Saddle = 117.199997 pos = 33.0541,129.0890 diff = 204.199997'
});
data_peak.push({
lat: 3.3393888889e+01,
lng: 1.2982233333e+02,
cert : false,
content:' Peak = 184.699997 pos = 33.3939,129.8223 diff = 184.699997'
});
data_saddle.push({
lat: 3.3348333334e+01,
lng: 1.2981255556e+02,
content:'Saddle = 0.000000 pos = 33.3483,129.8126 diff = 184.699997'
});
data_peak.push({
lat: 3.3382333334e+01,
lng: 1.2985088889e+02,
cert : false,
content:' Peak = 170.899994 pos = 33.3823,129.8509 diff = 153.399994'
});
data_saddle.push({
lat: 3.3378111111e+01,
lng: 1.2983566667e+02,
content:'Saddle = 17.500000 pos = 33.3781,129.8357 diff = 153.399994'
});
data_peak.push({
lat: 3.3273000000e+01,
lng: 1.2910788889e+02,
cert : false,
content:' Peak = 257.399994 pos = 33.2730,129.1079 diff = 257.399994'
});
data_saddle.push({
lat: 3.3245222223e+01,
lng: 1.2911855556e+02,
content:'Saddle = 0.000000 pos = 33.2452,129.1186 diff = 257.399994'
});
data_peak.push({
lat: 3.3478111111e+01,
lng: 1.2999133333e+02,
cert : false,
content:' Peak = 168.600006 pos = 33.4781,129.9913 diff = 168.600006'
});
data_saddle.push({
lat: 3.3472222222e+01,
lng: 1.2999366667e+02,
content:'Saddle = 0.000000 pos = 33.4722,129.9937 diff = 168.600006'
});
data_peak.push({
lat: 3.3496000000e+01,
lng: 1.2954144444e+02,
cert : false,
content:' Peak = 211.199997 pos = 33.4960,129.5414 diff = 211.199997'
});
data_saddle.push({
lat: 3.3469222222e+01,
lng: 1.2955344444e+02,
content:'Saddle = 0.000000 pos = 33.4692,129.5534 diff = 211.199997'
});
data_peak.push({
lat: 3.3573111111e+01,
lng: 1.3004877778e+02,
cert : false,
content:' Peak = 180.699997 pos = 33.5731,130.0488 diff = 180.699997'
});
data_saddle.push({
lat: 3.3563888889e+01,
lng: 1.3005122222e+02,
content:'Saddle = 0.000000 pos = 33.5639,130.0512 diff = 180.699997'
});
data_peak.push({
lat: 3.3620888889e+01,
lng: 1.3030344444e+02,
cert : false,
content:' Peak = 194.699997 pos = 33.6209,130.3034 diff = 194.699997'
});
data_saddle.push({
lat: 3.3606777778e+01,
lng: 1.3030266667e+02,
content:'Saddle = 0.000000 pos = 33.6068,130.3027 diff = 194.699997'
});
data_peak.push({
lat: 3.3741333333e+01,
lng: 1.2971022222e+02,
cert : false,
content:' Peak = 212.600006 pos = 33.7413,129.7102 diff = 212.600006'
});
data_saddle.push({
lat: 3.3704000000e+01,
lng: 1.2971655556e+02,
content:'Saddle = 0.000000 pos = 33.7040,129.7166 diff = 212.600006'
});
data_peak.push({
lat: 3.3903222222e+01,
lng: 1.3050022222e+02,
cert : false,
content:' Peak = 185.600006 pos = 33.9032,130.5002 diff = 185.600006'
});
data_saddle.push({
lat: 3.3895000000e+01,
lng: 1.3050211111e+02,
content:'Saddle = 0.000000 pos = 33.8950,130.5021 diff = 185.600006'
});
data_peak.push({
lat: 3.3898333333e+01,
lng: 1.3042455556e+02,
cert : false,
content:' Peak = 220.800003 pos = 33.8983,130.4246 diff = 220.800003'
});
data_saddle.push({
lat: 3.3886666667e+01,
lng: 1.3042911111e+02,
content:'Saddle = 0.000000 pos = 33.8867,130.4291 diff = 220.800003'
});
data_peak.push({
lat: 3.3574333334e+01,
lng: 1.2974988889e+02,
cert : false,
content:' Peak = 234.600006 pos = 33.5743,129.7499 diff = 234.600006'
});
data_saddle.push({
lat: 3.3562888889e+01,
lng: 1.2976044444e+02,
content:'Saddle = 0.000000 pos = 33.5629,129.7604 diff = 234.600006'
});
data_peak.push({
lat: 3.3390000000e+01,
lng: 1.2941811111e+02,
cert : false,
content:' Peak = 284.299988 pos = 33.3900,129.4181 diff = 284.299988'
});
data_saddle.push({
lat: 3.3350888889e+01,
lng: 1.2941588889e+02,
content:'Saddle = 0.000000 pos = 33.3509,129.4159 diff = 284.299988'
});
data_peak.push({
lat: 3.3989333333e+01,
lng: 1.3096577778e+02,
cert : false,
content:' Peak = 287.000000 pos = 33.9893,130.9658 diff = 287.000000'
});
data_saddle.push({
lat: 3.3938000000e+01,
lng: 1.3092311111e+02,
content:'Saddle = 0.000000 pos = 33.9380,130.9231 diff = 287.000000'
});
data_peak.push({
lat: 3.3974444444e+01,
lng: 1.3096066667e+02,
cert : false,
content:' Peak = 267.299988 pos = 33.9744,130.9607 diff = 159.999985'
});
data_saddle.push({
lat: 3.3981444444e+01,
lng: 1.3096244444e+02,
content:'Saddle = 107.300003 pos = 33.9814,130.9624 diff = 159.999985'
});
data_peak.push({
lat: 3.3336888889e+01,
lng: 1.2946588889e+02,
cert : true,
content:'Name = JA6/NS-015(JA6/NS-015) peak = 537.200012 pos = 33.3369,129.4659 diff = 537.200012'
});
data_saddle.push({
lat: 3.3168666667e+01,
lng: 1.2937522222e+02,
content:'Saddle = 0.000000 pos = 33.1687,129.3752 diff = 537.200012'
});
data_peak.push({
lat: 3.3175333334e+01,
lng: 1.2937266667e+02,
cert : true,
content:'Name = JA6/NS-055(JA6/NS-055) peak = 341.299988 pos = 33.1753,129.3727 diff = 335.599976'
});
data_saddle.push({
lat: 3.3178444445e+01,
lng: 1.2939922222e+02,
content:'Saddle = 5.700000 pos = 33.1784,129.3992 diff = 335.599976'
});
data_peak.push({
lat: 3.3377000000e+01,
lng: 1.2951411111e+02,
cert : false,
content:' Peak = 211.600006 pos = 33.3770,129.5141 diff = 189.600006'
});
data_saddle.push({
lat: 3.3356888889e+01,
lng: 1.2950355556e+02,
content:'Saddle = 22.000000 pos = 33.3569,129.5036 diff = 189.600006'
});
data_peak.push({
lat: 3.3403111111e+01,
lng: 1.2954744444e+02,
cert : false,
content:' Peak = 262.600006 pos = 33.4031,129.5474 diff = 230.800003'
});
data_saddle.push({
lat: 3.3389666667e+01,
lng: 1.2955000000e+02,
content:'Saddle = 31.799999 pos = 33.3897,129.5500 diff = 230.800003'
});
data_peak.push({
lat: 3.3343444445e+01,
lng: 1.2952922222e+02,
cert : false,
content:' Peak = 261.799988 pos = 33.3434,129.5292 diff = 227.599991'
});
data_saddle.push({
lat: 3.3344444445e+01,
lng: 1.2950888889e+02,
content:'Saddle = 34.200001 pos = 33.3444,129.5089 diff = 227.599991'
});
data_peak.push({
lat: 3.3215777778e+01,
lng: 1.2940033333e+02,
cert : true,
content:'Name = JA6/NS-035(JA6/NS-035) peak = 394.100006 pos = 33.2158,129.4003 diff = 347.100006'
});
data_saddle.push({
lat: 3.3203000000e+01,
lng: 1.2941755556e+02,
content:'Saddle = 47.000000 pos = 33.2030,129.4176 diff = 347.100006'
});
data_peak.push({
lat: 3.3226444445e+01,
lng: 1.2941044444e+02,
cert : false,
content:' Peak = 345.899994 pos = 33.2264,129.4104 diff = 166.699997'
});
data_saddle.push({
lat: 3.3222666667e+01,
lng: 1.2940522222e+02,
content:'Saddle = 179.199997 pos = 33.2227,129.4052 diff = 166.699997'
});
data_peak.push({
lat: 3.3193777778e+01,
lng: 1.2941666667e+02,
cert : false,
content:' Peak = 234.000000 pos = 33.1938,129.4167 diff = 186.300003'
});
data_saddle.push({
lat: 3.3211444445e+01,
lng: 1.2943955556e+02,
content:'Saddle = 47.700001 pos = 33.2114,129.4396 diff = 186.300003'
});
data_peak.push({
lat: 3.3258111111e+01,
lng: 1.2946688889e+02,
cert : false,
content:' Peak = 371.700012 pos = 33.2581,129.4669 diff = 314.200012'
});
data_saddle.push({
lat: 3.3287666667e+01,
lng: 1.2945477778e+02,
content:'Saddle = 57.500000 pos = 33.2877,129.4548 diff = 314.200012'
});
data_peak.push({
lat: 3.3271111111e+01,
lng: 1.2944411111e+02,
cert : true,
content:'Name = JA6/NS-052(JA6/NS-052) peak = 351.899994 pos = 33.2711,129.4441 diff = 254.000000'
});
data_saddle.push({
lat: 3.3271000000e+01,
lng: 1.2945400000e+02,
content:'Saddle = 97.900002 pos = 33.2710,129.4540 diff = 254.000000'
});
data_peak.push({
lat: 3.3349666667e+01,
lng: 1.2948366667e+02,
cert : false,
content:' Peak = 286.299988 pos = 33.3497,129.4837 diff = 198.599991'
});
data_saddle.push({
lat: 3.3346555556e+01,
lng: 1.2948000000e+02,
content:'Saddle = 87.699997 pos = 33.3466,129.4800 diff = 198.599991'
});
data_peak.push({
lat: 3.3347111111e+01,
lng: 1.2949677778e+02,
cert : false,
content:' Peak = 323.799988 pos = 33.3471,129.4968 diff = 185.499985'
});
data_saddle.push({
lat: 3.3340777778e+01,
lng: 1.2948411111e+02,
content:'Saddle = 138.300003 pos = 33.3408,129.4841 diff = 185.499985'
});
data_peak.push({
lat: 3.3316888889e+01,
lng: 1.2948944444e+02,
cert : true,
content:'Name = JA6/NS-033(JA6/NS-033) peak = 405.200012 pos = 33.3169,129.4894 diff = 176.400009'
});
data_saddle.push({
lat: 3.3321888889e+01,
lng: 1.2948488889e+02,
content:'Saddle = 228.800003 pos = 33.3219,129.4849 diff = 176.400009'
});
data_peak.push({
lat: 3.2427888890e+01,
lng: 1.3032688889e+02,
cert : true,
content:'Name = Kuradake(JA6/KM-044) peak = 681.500000 pos = 32.4279,130.3269 diff = 681.500000'
});
data_saddle.push({
lat: 3.2376888890e+01,
lng: 1.3035611111e+02,
content:'Saddle = 0.000000 pos = 32.3769,130.3561 diff = 681.500000'
});
data_peak.push({
lat: 3.2502888889e+01,
lng: 1.3041455556e+02,
cert : false,
content:' Peak = 232.300003 pos = 32.5029,130.4146 diff = 194.000000'
});
data_saddle.push({
lat: 3.2496333334e+01,
lng: 1.3041988889e+02,
content:'Saddle = 38.299999 pos = 32.4963,130.4199 diff = 194.000000'
});
data_peak.push({
lat: 3.2478888889e+01,
lng: 1.3040655556e+02,
cert : true,
content:'Name = JA6/KM-076(JA6/KM-076) peak = 397.899994 pos = 32.4789,130.4066 diff = 274.299988'
});
data_saddle.push({
lat: 3.2449222223e+01,
lng: 1.3039911111e+02,
content:'Saddle = 123.599998 pos = 32.4492,130.3991 diff = 274.299988'
});
data_peak.push({
lat: 3.2466000001e+01,
lng: 1.3042044444e+02,
cert : true,
content:'Name = JA6/KM-082(JA6/KM-082) peak = 370.700012 pos = 32.4660,130.4204 diff = 231.900009'
});
data_saddle.push({
lat: 3.2475000001e+01,
lng: 1.3041044444e+02,
content:'Saddle = 138.800003 pos = 32.4750,130.4104 diff = 231.900009'
});
data_peak.push({
lat: 3.2432000001e+01,
lng: 1.3038144444e+02,
cert : true,
content:'Name = JA6/KM-060(JA6/KM-060) peak = 500.600006 pos = 32.4320,130.3814 diff = 327.799988'
});
data_saddle.push({
lat: 3.2442444445e+01,
lng: 1.3037477778e+02,
content:'Saddle = 172.800003 pos = 32.4424,130.3748 diff = 327.799988'
});
data_peak.push({
lat: 3.2402222223e+01,
lng: 1.3037777778e+02,
cert : false,
content:' Peak = 476.299988 pos = 32.4022,130.3778 diff = 179.199982'
});
data_saddle.push({
lat: 3.2415111112e+01,
lng: 1.3037833333e+02,
content:'Saddle = 297.100006 pos = 32.4151,130.3783 diff = 179.199982'
});
data_peak.push({
lat: 3.2451000001e+01,
lng: 1.3027733333e+02,
cert : true,
content:'Name = JA6/KM-062(JA6/KM-062) peak = 495.000000 pos = 32.4510,130.2773 diff = 314.100006'
});
data_saddle.push({
lat: 3.2454555556e+01,
lng: 1.3030200000e+02,
content:'Saddle = 180.899994 pos = 32.4546,130.3020 diff = 314.100006'
});
data_peak.push({
lat: 3.2442555556e+01,
lng: 1.3037000000e+02,
cert : false,
content:' Peak = 333.000000 pos = 32.4426,130.3700 diff = 150.199997'
});
data_saddle.push({
lat: 3.2442666667e+01,
lng: 1.3035677778e+02,
content:'Saddle = 182.800003 pos = 32.4427,130.3568 diff = 150.199997'
});
data_peak.push({
lat: 3.2480777778e+01,
lng: 1.3034022222e+02,
cert : true,
content:'Name = JA6/KM-051(JA6/KM-051) peak = 590.000000 pos = 32.4808,130.3402 diff = 382.000000'
});
data_saddle.push({
lat: 3.2456444445e+01,
lng: 1.3033944444e+02,
content:'Saddle = 208.000000 pos = 32.4564,130.3394 diff = 382.000000'
});
data_peak.push({
lat: 3.2454888890e+01,
lng: 1.3031977778e+02,
cert : false,
content:' Peak = 440.899994 pos = 32.4549,130.3198 diff = 159.199982'
});
data_saddle.push({
lat: 3.2463888890e+01,
lng: 1.3033222222e+02,
content:'Saddle = 281.700012 pos = 32.4639,130.3322 diff = 159.199982'
});
data_peak.push({
lat: 3.3674888889e+01,
lng: 1.3030344444e+02,
cert : false,
content:' Peak = 173.399994 pos = 33.6749,130.3034 diff = 171.399994'
});
data_saddle.push({
lat: 3.3658333333e+01,
lng: 1.3032955556e+02,
content:'Saddle = 2.000000 pos = 33.6583,130.3296 diff = 171.399994'
});
data_peak.push({
lat: 3.3480333334e+01,
lng: 1.2996322222e+02,
cert : false,
content:' Peak = 175.100006 pos = 33.4803,129.9632 diff = 171.200012'
});
data_saddle.push({
lat: 3.3469444445e+01,
lng: 1.2995900000e+02,
content:'Saddle = 3.900000 pos = 33.4694,129.9590 diff = 171.200012'
});
data_peak.push({
lat: 3.2653555556e+01,
lng: 1.3057744444e+02,
cert : true,
content:'Name = JA6/KM-067(JA6/KM-067) peak = 477.000000 pos = 32.6536,130.5774 diff = 472.200012'
});
data_saddle.push({
lat: 3.2654111112e+01,
lng: 1.3066866667e+02,
content:'Saddle = 4.800000 pos = 32.6541,130.6687 diff = 472.200012'
});
data_peak.push({
lat: 3.2627777778e+01,
lng: 1.3046655556e+02,
cert : true,
content:'Name = JA6/KM-073(JA6/KM-073) peak = 401.000000 pos = 32.6278,130.4666 diff = 294.200012'
});
data_saddle.push({
lat: 3.2630222223e+01,
lng: 1.3048344444e+02,
content:'Saddle = 106.800003 pos = 32.6302,130.4834 diff = 294.200012'
});
data_peak.push({
lat: 3.3572444445e+01,
lng: 1.3016077778e+02,
cert : true,
content:'Name = JA6/FO-047(JA6/FO-047) peak = 363.899994 pos = 33.5724,130.1608 diff = 358.699982'
});
data_saddle.push({
lat: 3.3563333334e+01,
lng: 1.3019811111e+02,
content:'Saddle = 5.200000 pos = 33.5633,130.1981 diff = 358.699982'
});
data_peak.push({
lat: 3.3609888889e+01,
lng: 1.3026700000e+02,
cert : false,
content:' Peak = 175.899994 pos = 33.6099,130.2670 diff = 170.500000'
});
data_saddle.push({
lat: 3.3612444445e+01,
lng: 1.3024011111e+02,
content:'Saddle = 5.400000 pos = 33.6124,130.2401 diff = 170.500000'
});
data_peak.push({
lat: 3.3582888889e+01,
lng: 1.3010044444e+02,
cert : false,
content:' Peak = 203.100006 pos = 33.5829,130.1004 diff = 195.300003'
});
data_saddle.push({
lat: 3.3579666667e+01,
lng: 1.3012311111e+02,
content:'Saddle = 7.800000 pos = 33.5797,130.1231 diff = 195.300003'
});
data_peak.push({
lat: 3.3578444445e+01,
lng: 1.3013533333e+02,
cert : false,
content:' Peak = 162.300003 pos = 33.5784,130.1353 diff = 153.000000'
});
data_saddle.push({
lat: 3.3586555556e+01,
lng: 1.3015111111e+02,
content:'Saddle = 9.300000 pos = 33.5866,130.1511 diff = 153.000000'
});
data_peak.push({
lat: 3.3621111111e+01,
lng: 1.3020544444e+02,
cert : false,
content:' Peak = 260.399994 pos = 33.6211,130.2054 diff = 245.399994'
});
data_saddle.push({
lat: 3.3582888889e+01,
lng: 1.3017033333e+02,
content:'Saddle = 15.000000 pos = 33.5829,130.1703 diff = 245.399994'
});
data_peak.push({
lat: 3.3622666667e+01,
lng: 1.3016311111e+02,
cert : false,
content:' Peak = 232.399994 pos = 33.6227,130.1631 diff = 214.399994'
});
data_saddle.push({
lat: 3.3625444445e+01,
lng: 1.3018444444e+02,
content:'Saddle = 18.000000 pos = 33.6254,130.1844 diff = 214.399994'
});
data_peak.push({
lat: 3.3597666667e+01,
lng: 1.3016266667e+02,
cert : false,
content:' Peak = 243.100006 pos = 33.5977,130.1627 diff = 224.300003'
});
data_saddle.push({
lat: 3.3597555556e+01,
lng: 1.3018277778e+02,
content:'Saddle = 18.799999 pos = 33.5976,130.1828 diff = 224.300003'
});
data_peak.push({
lat: 3.3651111111e+01,
lng: 1.3022500000e+02,
cert : false,
content:' Peak = 210.199997 pos = 33.6511,130.2250 diff = 182.300003'
});
data_saddle.push({
lat: 3.3645000000e+01,
lng: 1.3022066667e+02,
content:'Saddle = 27.900000 pos = 33.6450,130.2207 diff = 182.300003'
});
data_peak.push({
lat: 3.3616666667e+01,
lng: 1.3022166667e+02,
cert : false,
content:' Peak = 254.600006 pos = 33.6167,130.2217 diff = 187.400009'
});
data_saddle.push({
lat: 3.3617666667e+01,
lng: 1.3021000000e+02,
content:'Saddle = 67.199997 pos = 33.6177,130.2100 diff = 187.400009'
});
data_peak.push({
lat: 3.2579888889e+01,
lng: 1.2974044444e+02,
cert : false,
content:' Peak = 197.500000 pos = 32.5799,129.7404 diff = 192.199997'
});
data_saddle.push({
lat: 3.2580000001e+01,
lng: 1.2975144444e+02,
content:'Saddle = 5.300000 pos = 32.5800,129.7514 diff = 192.199997'
});
data_peak.push({
lat: 3.3903333333e+01,
lng: 1.3077200000e+02,
cert : true,
content:'Name = JA6/FO-054(JA6/FO-054) peak = 303.600006 pos = 33.9033,130.7720 diff = 297.200012'
});
data_saddle.push({
lat: 3.3884777778e+01,
lng: 1.3069677778e+02,
content:'Saddle = 6.400000 pos = 33.8848,130.6968 diff = 297.200012'
});
data_peak.push({
lat: 3.3208777778e+01,
lng: 1.2963300000e+02,
cert : false,
content:' Peak = 174.399994 pos = 33.2088,129.6330 diff = 167.199997'
});
data_saddle.push({
lat: 3.3219666667e+01,
lng: 1.2963222222e+02,
content:'Saddle = 7.200000 pos = 33.2197,129.6322 diff = 167.199997'
});
data_peak.push({
lat: 3.3130777778e+01,
lng: 1.2969522222e+02,
cert : false,
content:' Peak = 166.800003 pos = 33.1308,129.6952 diff = 157.699997'
});
data_saddle.push({
lat: 3.3140888889e+01,
lng: 1.2970244444e+02,
content:'Saddle = 9.100000 pos = 33.1409,129.7024 diff = 157.699997'
});
data_peak.push({
lat: 3.3859555556e+01,
lng: 1.3091711111e+02,
cert : true,
content:'Name = Adachiyama (Kirigatake)(JA6/FO-026) peak = 597.000000 pos = 33.8596,130.9171 diff = 583.000000'
});
data_saddle.push({
lat: 3.3851777778e+01,
lng: 1.3089533333e+02,
content:'Saddle = 14.000000 pos = 33.8518,130.8953 diff = 583.000000'
});
data_peak.push({
lat: 3.3857000000e+01,
lng: 1.3097733333e+02,
cert : false,
content:' Peak = 224.500000 pos = 33.8570,130.9773 diff = 189.399994'
});
data_saddle.push({
lat: 3.3856111111e+01,
lng: 1.3095344444e+02,
content:'Saddle = 35.099998 pos = 33.8561,130.9534 diff = 189.399994'
});
data_peak.push({
lat: 3.3925666667e+01,
lng: 1.3095288889e+02,
cert : false,
content:' Peak = 363.200012 pos = 33.9257,130.9529 diff = 285.700012'
});
data_saddle.push({
lat: 3.3914222222e+01,
lng: 1.3096388889e+02,
content:'Saddle = 77.500000 pos = 33.9142,130.9639 diff = 285.700012'
});
data_peak.push({
lat: 3.3892111111e+01,
lng: 1.3094822222e+02,
cert : true,
content:'Name = JA6/FO-031(JA6/FO-031) peak = 521.900024 pos = 33.8921,130.9482 diff = 219.000031'
});
data_saddle.push({
lat: 3.3880666667e+01,
lng: 1.3094255556e+02,
content:'Saddle = 302.899994 pos = 33.8807,130.9426 diff = 219.000031'
});
data_peak.push({
lat: 3.3172111111e+01,
lng: 1.3007666667e+02,
cert : true,
content:'Name = JA6/SG-027(JA6/SG-027) peak = 371.100006 pos = 33.1721,130.0767 diff = 355.800018'
});
data_saddle.push({
lat: 3.3153000000e+01,
lng: 1.3006488889e+02,
content:'Saddle = 15.300000 pos = 33.1530,130.0649 diff = 355.800018'
});
data_peak.push({
lat: 3.3144000000e+01,
lng: 1.3008733333e+02,
cert : false,
content:' Peak = 340.200012 pos = 33.1440,130.0873 diff = 152.200012'
});
data_saddle.push({
lat: 3.3164111111e+01,
lng: 1.3007922222e+02,
content:'Saddle = 188.000000 pos = 33.1641,130.0792 diff = 152.200012'
});
data_peak.push({
lat: 3.2761333334e+01,
lng: 1.3029877778e+02,
cert : true,
content:'Name = Unzendake (Heiseishinzan)(JA6/NS-001) peak = 1482.199951 pos = 32.7613,130.2988 diff = 1465.000000'
});
data_saddle.push({
lat: 3.2838222223e+01,
lng: 1.3003366667e+02,
content:'Saddle = 17.200001 pos = 32.8382,130.0337 diff = 1465.000000'
});
data_peak.push({
lat: 3.2670222223e+01,
lng: 1.2985644444e+02,
cert : true,
content:'Name = Hachiroudake(JA6/NS-011) peak = 588.200012 pos = 32.6702,129.8564 diff = 559.500000'
});
data_saddle.push({
lat: 3.2801111112e+01,
lng: 1.3013177778e+02,
content:'Saddle = 28.700001 pos = 32.8011,130.1318 diff = 559.500000'
});
data_peak.push({
lat: 3.2713222223e+01,
lng: 1.2985677778e+02,
cert : false,
content:' Peak = 233.800003 pos = 32.7132,129.8568 diff = 187.100006'
});
data_saddle.push({
lat: 3.2714888889e+01,
lng: 1.2986533333e+02,
content:'Saddle = 46.700001 pos = 32.7149,129.8653 diff = 187.100006'
});
data_peak.push({
lat: 3.2609777778e+01,
lng: 1.2980444444e+02,
cert : true,
content:'Name = JA6/NS-059(JA6/NS-059) peak = 322.799988 pos = 32.6098,129.8044 diff = 275.299988'
});
data_saddle.push({
lat: 3.2652111112e+01,
lng: 1.2982222222e+02,
content:'Saddle = 47.500000 pos = 32.6521,129.8222 diff = 275.299988'
});
data_peak.push({
lat: 3.2673333334e+01,
lng: 1.2982966667e+02,
cert : true,
content:'Name = JA6/NS-051(JA6/NS-051) peak = 352.100006 pos = 32.6733,129.8297 diff = 303.300018'
});
data_saddle.push({
lat: 3.2666222223e+01,
lng: 1.2983611111e+02,
content:'Saddle = 48.799999 pos = 32.6662,129.8361 diff = 303.300018'
});
data_peak.push({
lat: 3.2783444445e+01,
lng: 1.2996988889e+02,
cert : true,
content:'Name = JA6/NS-021(JA6/NS-021) peak = 455.299988 pos = 32.7834,129.9699 diff = 400.199982'
});
data_saddle.push({
lat: 3.2811000000e+01,
lng: 1.2996722222e+02,
content:'Saddle = 55.099998 pos = 32.8110,129.9672 diff = 400.199982'
});
data_peak.push({
lat: 3.2769555556e+01,
lng: 1.2998844444e+02,
cert : false,
content:' Peak = 210.500000 pos = 32.7696,129.9884 diff = 154.100006'
});
data_saddle.push({
lat: 3.2774333334e+01,
lng: 1.2998844444e+02,
content:'Saddle = 56.400002 pos = 32.7743,129.9884 diff = 154.100006'
});
data_peak.push({
lat: 3.2816111112e+01,
lng: 1.3010355556e+02,
cert : true,
content:'Name = JA6/NS-070(JA6/NS-070) peak = 281.000000 pos = 32.8161,130.1036 diff = 223.600006'
});
data_saddle.push({
lat: 3.2806111112e+01,
lng: 1.3008777778e+02,
content:'Saddle = 57.400002 pos = 32.8061,130.0878 diff = 223.600006'
});
data_peak.push({
lat: 3.2785444445e+01,
lng: 1.3000233333e+02,
cert : false,
content:' Peak = 293.000000 pos = 32.7854,130.0023 diff = 205.600006'
});
data_saddle.push({
lat: 3.2789000000e+01,
lng: 1.3000411111e+02,
content:'Saddle = 87.400002 pos = 32.7890,130.0041 diff = 205.600006'
});
data_peak.push({
lat: 3.2775888889e+01,
lng: 1.3000355556e+02,
cert : false,
content:' Peak = 278.299988 pos = 32.7759,130.0036 diff = 171.099991'
});
data_saddle.push({
lat: 3.2780777778e+01,
lng: 1.3000266667e+02,
content:'Saddle = 107.199997 pos = 32.7808,130.0027 diff = 171.099991'
});
data_peak.push({
lat: 3.2798666667e+01,
lng: 1.3001811111e+02,
cert : false,
content:' Peak = 295.200012 pos = 32.7987,130.0181 diff = 157.600006'
});
data_saddle.push({
lat: 3.2799777778e+01,
lng: 1.3001355556e+02,
content:'Saddle = 137.600006 pos = 32.7998,130.0136 diff = 157.600006'
});
data_peak.push({
lat: 3.2806666667e+01,
lng: 1.2999077778e+02,
cert : true,
content:'Name = JA6/NS-032(JA6/NS-032) peak = 402.600006 pos = 32.8067,129.9908 diff = 214.900009'
});
data_saddle.push({
lat: 3.2794222223e+01,
lng: 1.2998933333e+02,
content:'Saddle = 187.699997 pos = 32.7942,129.9893 diff = 214.900009'
});
data_peak.push({
lat: 3.2788333334e+01,
lng: 1.2998233333e+02,
cert : true,
content:'Name = JA6/NS-023(JA6/NS-023) peak = 450.600006 pos = 32.7883,129.9823 diff = 252.700012'
});
data_saddle.push({
lat: 3.2785555556e+01,
lng: 1.2997533333e+02,
content:'Saddle = 197.899994 pos = 32.7856,129.9753 diff = 252.700012'
});
data_peak.push({
lat: 3.2908888889e+01,
lng: 1.2974244444e+02,
cert : false,
content:' Peak = 560.700012 pos = 32.9089,129.7424 diff = 503.200012'
});
data_saddle.push({
lat: 3.2805888889e+01,
lng: 1.2985311111e+02,
content:'Saddle = 57.500000 pos = 32.8059,129.8531 diff = 503.200012'
});
data_peak.push({
lat: 3.2793333334e+01,
lng: 1.2983033333e+02,
cert : true,
content:'Name = JA6/NS-019(JA6/NS-019) peak = 474.100006 pos = 32.7933,129.8303 diff = 396.700012'
});
data_saddle.push({
lat: 3.2835444445e+01,
lng: 1.2978455556e+02,
content:'Saddle = 77.400002 pos = 32.8354,129.7846 diff = 396.700012'
});
data_peak.push({
lat: 3.2752888889e+01,
lng: 1.2984944444e+02,
cert : false,
content:' Peak = 341.299988 pos = 32.7529,129.8494 diff = 192.899994'
});
data_saddle.push({
lat: 3.2783666667e+01,
lng: 1.2984077778e+02,
content:'Saddle = 148.399994 pos = 32.7837,129.8408 diff = 192.899994'
});
data_peak.push({
lat: 3.2815000000e+01,
lng: 1.2981800000e+02,
cert : true,
content:'Name = JA6/NS-030(JA6/NS-030) peak = 411.600006 pos = 32.8150,129.8180 diff = 204.200012'
});
data_saddle.push({
lat: 3.2801111112e+01,
lng: 1.2981977778e+02,
content:'Saddle = 207.399994 pos = 32.8011,129.8198 diff = 204.200012'
});
data_peak.push({
lat: 3.2793666667e+01,
lng: 1.2990744444e+02,
cert : true,
content:'Name = JA6/NS-017(JA6/NS-017) peak = 503.000000 pos = 32.7937,129.9074 diff = 355.600006'
});
data_saddle.push({
lat: 3.2728888889e+01,
lng: 1.2989188889e+02,
content:'Saddle = 147.399994 pos = 32.7289,129.8919 diff = 355.600006'
});
data_peak.push({
lat: 3.2771888889e+01,
lng: 1.2988377778e+02,
cert : false,
content:' Peak = 365.399994 pos = 32.7719,129.8838 diff = 198.399994'
});
data_saddle.push({
lat: 3.2779222223e+01,
lng: 1.2988811111e+02,
content:'Saddle = 167.000000 pos = 32.7792,129.8881 diff = 198.399994'
});
data_peak.push({
lat: 3.2851888889e+01,
lng: 1.2989388889e+02,
cert : true,
content:'Name = JA6/NS-022(JA6/NS-022) peak = 450.899994 pos = 32.8519,129.8939 diff = 243.199997'
});
data_saddle.push({
lat: 3.2842555556e+01,
lng: 1.2990477778e+02,
content:'Saddle = 207.699997 pos = 32.8426,129.9048 diff = 243.199997'
});
data_peak.push({
lat: 3.2744666667e+01,
lng: 1.2992033333e+02,
cert : false,
content:' Peak = 414.100006 pos = 32.7447,129.9203 diff = 172.800003'
});
data_saddle.push({
lat: 3.2751222223e+01,
lng: 1.2992377778e+02,
content:'Saddle = 241.300003 pos = 32.7512,129.9238 diff = 172.800003'
});
data_peak.push({
lat: 3.2627222223e+01,
lng: 1.3017933333e+02,
cert : true,
content:'Name = JA6/NS-069(JA6/NS-069) peak = 292.899994 pos = 32.6272,130.1793 diff = 231.299988'
});
data_saddle.push({
lat: 3.2627444445e+01,
lng: 1.3019155556e+02,
content:'Saddle = 61.599998 pos = 32.6274,130.1916 diff = 231.299988'
});
data_peak.push({
lat: 3.2641222223e+01,
lng: 1.3020911111e+02,
cert : true,
content:'Name = JA6/NS-031(JA6/NS-031) peak = 403.299988 pos = 32.6412,130.2091 diff = 305.500000'
});
data_saddle.push({
lat: 3.2652888889e+01,
lng: 1.3019844444e+02,
content:'Saddle = 97.800003 pos = 32.6529,130.1984 diff = 305.500000'
});
data_peak.push({
lat: 3.2769777778e+01,
lng: 1.3019955556e+02,
cert : true,
content:'Name = JA6/NS-036(JA6/NS-036) peak = 391.799988 pos = 32.7698,130.1996 diff = 235.499985'
});
data_saddle.push({
lat: 3.2765444445e+01,
lng: 1.3021400000e+02,
content:'Saddle = 156.300003 pos = 32.7654,130.2140 diff = 235.499985'
});
data_peak.push({
lat: 3.2771777778e+01,
lng: 1.3033700000e+02,
cert : true,
content:'Name = JA6/NS-007(JA6/NS-007) peak = 817.900024 pos = 32.7718,130.3370 diff = 300.800049'
});
data_saddle.push({
lat: 3.2764666667e+01,
lng: 1.3033266667e+02,
content:'Saddle = 517.099976 pos = 32.7647,130.3327 diff = 300.800049'
});
data_peak.push({
lat: 3.2791111112e+01,
lng: 1.3025277778e+02,
cert : true,
content:'Name = JA6/NS-006(JA6/NS-006) peak = 864.500000 pos = 32.7911,130.2528 diff = 232.599976'
});
data_saddle.push({
lat: 3.2785222223e+01,
lng: 1.3027222222e+02,
content:'Saddle = 631.900024 pos = 32.7852,130.2722 diff = 232.599976'
});
data_peak.push({
lat: 3.2788111112e+01,
lng: 1.3027188889e+02,
cert : false,
content:' Peak = 820.700012 pos = 32.7881,130.2719 diff = 173.299988'
});
data_saddle.push({
lat: 3.2788000000e+01,
lng: 1.3026788889e+02,
content:'Saddle = 647.400024 pos = 32.7880,130.2679 diff = 173.299988'
});
data_peak.push({
lat: 3.2737222223e+01,
lng: 1.3025111111e+02,
cert : true,
content:'Name = JA6/NS-005(JA6/NS-005) peak = 878.400024 pos = 32.7372,130.2511 diff = 196.900024'
});
data_saddle.push({
lat: 3.2742333334e+01,
lng: 1.3025800000e+02,
content:'Saddle = 681.500000 pos = 32.7423,130.2580 diff = 196.900024'
});
data_peak.push({
lat: 3.2717777778e+01,
lng: 1.3026988889e+02,
cert : false,
content:' Peak = 880.500000 pos = 32.7178,130.2699 diff = 152.500000'
});
data_saddle.push({
lat: 3.2729222223e+01,
lng: 1.3026944444e+02,
content:'Saddle = 728.000000 pos = 32.7292,130.2694 diff = 152.500000'
});
data_peak.push({
lat: 3.2739222223e+01,
lng: 1.3027122222e+02,
cert : true,
content:'Name = JA6/NS-004(JA6/NS-004) peak = 971.299988 pos = 32.7392,130.2712 diff = 214.099976'
});
data_saddle.push({
lat: 3.2740888889e+01,
lng: 1.3027511111e+02,
content:'Saddle = 757.200012 pos = 32.7409,130.2751 diff = 214.099976'
});
data_peak.push({
lat: 3.2775444445e+01,
lng: 1.3026066667e+02,
cert : true,
content:'Name = JA6/NS-002(JA6/NS-002) peak = 1062.500000 pos = 32.7754,130.2607 diff = 200.400024'
});
data_saddle.push({
lat: 3.2764666667e+01,
lng: 1.3027277778e+02,
content:'Saddle = 862.099976 pos = 32.7647,130.2728 diff = 200.400024'
});
data_peak.push({
lat: 3.3384777778e+01,
lng: 1.2996511111e+02,
cert : false,
content:' Peak = 203.100006 pos = 33.3848,129.9651 diff = 182.500000'
});
data_saddle.push({
lat: 3.3373111111e+01,
lng: 1.2996755556e+02,
content:'Saddle = 20.600000 pos = 33.3731,129.9676 diff = 182.500000'
});
data_peak.push({
lat: 3.2109777779e+01,
lng: 1.3022600000e+02,
cert : true,
content:'Name = JA6/KG-104(JA6/KG-104) peak = 393.399994 pos = 32.1098,130.2260 diff = 366.199982'
});
data_saddle.push({
lat: 3.2074111112e+01,
lng: 1.3024188889e+02,
content:'Saddle = 27.200001 pos = 32.0741,130.2419 diff = 366.199982'
});
data_peak.push({
lat: 3.3795333333e+01,
lng: 1.3049477778e+02,
cert : false,
content:' Peak = 244.800003 pos = 33.7953,130.4948 diff = 207.500000'
});
data_saddle.push({
lat: 3.3776444445e+01,
lng: 1.3051433333e+02,
content:'Saddle = 37.299999 pos = 33.7764,130.5143 diff = 207.500000'
});
data_peak.push({
lat: 3.2218000001e+01,
lng: 1.3043266667e+02,
cert : false,
content:' Peak = 232.399994 pos = 32.2180,130.4327 diff = 194.000000'
});
data_saddle.push({
lat: 3.2210222223e+01,
lng: 1.3042755556e+02,
content:'Saddle = 38.400002 pos = 32.2102,130.4276 diff = 194.000000'
});
data_peak.push({
lat: 3.2217555556e+01,
lng: 1.3041966667e+02,
cert : false,
content:' Peak = 212.300003 pos = 32.2176,130.4197 diff = 166.000000'
});
data_saddle.push({
lat: 3.2217444445e+01,
lng: 1.3042711111e+02,
content:'Saddle = 46.299999 pos = 32.2174,130.4271 diff = 166.000000'
});
data_peak.push({
lat: 3.2987555556e+01,
lng: 1.3007622222e+02,
cert : true,
content:'Name = Taradake (Kyougadake)(JA6/SG-001) peak = 1074.300049 pos = 32.9876,130.0762 diff = 1034.200073'
});
data_saddle.push({
lat: 3.3484111111e+01,
lng: 1.3052866667e+02,
content:'Saddle = 40.099998 pos = 33.4841,130.5287 diff = 1034.200073'
});
data_peak.push({
lat: 3.3148666667e+01,
lng: 1.3001600000e+02,
cert : true,
content:'Name = JA6/SG-031(JA6/SG-031) peak = 332.000000 pos = 33.1487,130.0160 diff = 288.399994'
});
data_saddle.push({
lat: 3.3138111111e+01,
lng: 1.2998622222e+02,
content:'Saddle = 43.599998 pos = 33.1381,129.9862 diff = 288.399994'
});
data_peak.push({
lat: 3.3184000000e+01,
lng: 1.3001944444e+02,
cert : false,
content:' Peak = 202.300003 pos = 33.1840,130.0194 diff = 155.600006'
});
data_saddle.push({
lat: 3.3175888889e+01,
lng: 1.3001711111e+02,
content:'Saddle = 46.700001 pos = 33.1759,130.0171 diff = 155.600006'
});
data_peak.push({
lat: 3.3201555556e+01,
lng: 1.2966366667e+02,
cert : false,
content:' Peak = 256.600006 pos = 33.2016,129.6637 diff = 209.500000'
});
data_saddle.push({
lat: 3.3210666667e+01,
lng: 1.2967388889e+02,
content:'Saddle = 47.099998 pos = 33.2107,129.6739 diff = 209.500000'
});
data_peak.push({
lat: 3.3440555556e+01,
lng: 1.2991677778e+02,
cert : false,
content:' Peak = 264.000000 pos = 33.4406,129.9168 diff = 216.199997'
});
data_saddle.push({
lat: 3.3366888889e+01,
lng: 1.2988900000e+02,
content:'Saddle = 47.799999 pos = 33.3669,129.8890 diff = 216.199997'
});
data_peak.push({
lat: 3.3151222223e+01,
lng: 1.2969977778e+02,
cert : false,
content:' Peak = 253.100006 pos = 33.1512,129.6998 diff = 204.900009'
});
data_saddle.push({
lat: 3.3161555556e+01,
lng: 1.2968955556e+02,
content:'Saddle = 48.200001 pos = 33.1616,129.6896 diff = 204.900009'
});
data_peak.push({
lat: 3.3100555556e+01,
lng: 1.2980955556e+02,
cert : false,
content:' Peak = 261.399994 pos = 33.1006,129.8096 diff = 203.899994'
});
data_saddle.push({
lat: 3.3108444445e+01,
lng: 1.2981822222e+02,
content:'Saddle = 57.500000 pos = 33.1084,129.8182 diff = 203.899994'
});
data_peak.push({
lat: 3.3274666667e+01,
lng: 1.3010066667e+02,
cert : false,
content:' Peak = 212.000000 pos = 33.2747,130.1007 diff = 153.600006'
});
data_saddle.push({
lat: 3.3285222223e+01,
lng: 1.3010633333e+02,
content:'Saddle = 58.400002 pos = 33.2852,130.1063 diff = 153.600006'
});
data_peak.push({
lat: 3.3327888889e+01,
lng: 1.2991288889e+02,
cert : true,
content:'Name = JA6/SG-024(JA6/SG-024) peak = 423.399994 pos = 33.3279,129.9129 diff = 357.000000'
});
data_saddle.push({
lat: 3.3291555556e+01,
lng: 1.2990900000e+02,
content:'Saddle = 66.400002 pos = 33.2916,129.9090 diff = 357.000000'
});
data_peak.push({
lat: 3.3309555556e+01,
lng: 1.2989777778e+02,
cert : true,
content:'Name = JA6/SG-026(JA6/SG-026) peak = 403.000000 pos = 33.3096,129.8978 diff = 200.199997'
});
data_saddle.push({
lat: 3.3323222222e+01,
lng: 1.2990300000e+02,
content:'Saddle = 202.800003 pos = 33.3232,129.9030 diff = 200.199997'
});
data_peak.push({
lat: 3.3356666667e+01,
lng: 1.2997833333e+02,
cert : true,
content:'Name = JA6/SG-033(JA6/SG-033) peak = 318.600006 pos = 33.3567,129.9783 diff = 252.000000'
});
data_saddle.push({
lat: 3.3261888889e+01,
lng: 1.2992255556e+02,
content:'Saddle = 66.599998 pos = 33.2619,129.9226 diff = 252.000000'
});
data_peak.push({
lat: 3.3267666667e+01,
lng: 1.2991944444e+02,
cert : false,
content:' Peak = 253.600006 pos = 33.2677,129.9194 diff = 185.700012'
});
data_saddle.push({
lat: 3.3280111111e+01,
lng: 1.2992111111e+02,
content:'Saddle = 67.900002 pos = 33.2801,129.9211 diff = 185.700012'
});
data_peak.push({
lat: 3.3288555556e+01,
lng: 1.2995466667e+02,
cert : false,
content:' Peak = 267.500000 pos = 33.2886,129.9547 diff = 179.800003'
});
data_saddle.push({
lat: 3.3302777778e+01,
lng: 1.2995444444e+02,
content:'Saddle = 87.699997 pos = 33.3028,129.9544 diff = 179.800003'
});
data_peak.push({
lat: 3.3362000000e+01,
lng: 1.2999888889e+02,
cert : false,
content:' Peak = 251.600006 pos = 33.3620,129.9989 diff = 153.800003'
});
data_saddle.push({
lat: 3.3361888889e+01,
lng: 1.2998911111e+02,
content:'Saddle = 97.800003 pos = 33.3619,129.9891 diff = 153.800003'
});
data_peak.push({
lat: 3.3428000000e+01,
lng: 1.3002488889e+02,
cert : false,
content:' Peak = 285.500000 pos = 33.4280,130.0249 diff = 216.800003'
});
data_saddle.push({
lat: 3.3423222222e+01,
lng: 1.3003433333e+02,
content:'Saddle = 68.699997 pos = 33.4232,130.0343 diff = 216.800003'
});
data_peak.push({
lat: 3.3237000000e+01,
lng: 1.2981277778e+02,
cert : true,
content:'Name = Kunimiyama(JA6/SG-010) peak = 775.299988 pos = 33.2370,129.8128 diff = 706.299988'
});
data_saddle.push({
lat: 3.3177444445e+01,
lng: 1.2985244444e+02,
content:'Saddle = 69.000000 pos = 33.1774,129.8524 diff = 706.299988'
});
data_peak.push({
lat: 3.3196666667e+01,
lng: 1.2970333333e+02,
cert : true,
content:'Name = JA6/NS-024(JA6/NS-024) peak = 443.799988 pos = 33.1967,129.7033 diff = 369.199982'
});
data_saddle.push({
lat: 3.3202000000e+01,
lng: 1.2972077778e+02,
content:'Saddle = 74.599998 pos = 33.2020,129.7208 diff = 369.199982'
});
data_peak.push({
lat: 3.3242777778e+01,
lng: 1.2959477778e+02,
cert : true,
content:'Name = JA6/NS-040(JA6/NS-040) peak = 373.600006 pos = 33.2428,129.5948 diff = 287.200012'
});
data_saddle.push({
lat: 3.3280444445e+01,
lng: 1.2968400000e+02,
content:'Saddle = 86.400002 pos = 33.2804,129.6840 diff = 287.200012'
});
data_peak.push({
lat: 3.3272111111e+01,
lng: 1.2966733333e+02,
cert : false,
content:' Peak = 352.299988 pos = 33.2721,129.6673 diff = 224.399994'
});
data_saddle.push({
lat: 3.3272333334e+01,
lng: 1.2965333333e+02,
content:'Saddle = 127.900002 pos = 33.2723,129.6533 diff = 224.399994'
});
data_peak.push({
lat: 3.3263666667e+01,
lng: 1.2964911111e+02,
cert : true,
content:'Name = JA6/NS-065(JA6/NS-065) peak = 311.399994 pos = 33.2637,129.6491 diff = 174.299988'
});
data_saddle.push({
lat: 3.3255333334e+01,
lng: 1.2963466667e+02,
content:'Saddle = 137.100006 pos = 33.2553,129.6347 diff = 174.299988'
});
data_peak.push({
lat: 3.3276222223e+01,
lng: 1.2970700000e+02,
cert : false,
content:' Peak = 300.500000 pos = 33.2762,129.7070 diff = 161.500000'
});
data_saddle.push({
lat: 3.3280444445e+01,
lng: 1.2971411111e+02,
content:'Saddle = 139.000000 pos = 33.2804,129.7141 diff = 161.500000'
});
data_peak.push({
lat: 3.3293888889e+01,
lng: 1.2978822222e+02,
cert : true,
content:'Name = JA6/SG-016(JA6/SG-016) peak = 523.500000 pos = 33.2939,129.7882 diff = 165.100006'
});
data_saddle.push({
lat: 3.3280444445e+01,
lng: 1.2981033333e+02,
content:'Saddle = 358.399994 pos = 33.2804,129.8103 diff = 165.100006'
});
data_peak.push({
lat: 3.3180444445e+01,
lng: 1.2975188889e+02,
cert : true,
content:'Name = JA6/NS-012(JA6/NS-012) peak = 566.700012 pos = 33.1804,129.7519 diff = 175.100006'
});
data_saddle.push({
lat: 3.3182333334e+01,
lng: 1.2977077778e+02,
content:'Saddle = 391.600006 pos = 33.1823,129.7708 diff = 175.100006'
});
data_peak.push({
lat: 3.3179333334e+01,
lng: 1.2980377778e+02,
cert : true,
content:'Name = JA6/NS-008(JA6/NS-008) peak = 669.299988 pos = 33.1793,129.8038 diff = 196.899994'
});
data_saddle.push({
lat: 3.3184777778e+01,
lng: 1.2981055556e+02,
content:'Saddle = 472.399994 pos = 33.1848,129.8106 diff = 196.899994'
});
data_peak.push({
lat: 3.2870444445e+01,
lng: 1.2999333333e+02,
cert : false,
content:' Peak = 258.000000 pos = 32.8704,129.9933 diff = 178.500000'
});
data_saddle.push({
lat: 3.2884111112e+01,
lng: 1.3001066667e+02,
content:'Saddle = 79.500000 pos = 32.8841,130.0107 diff = 178.500000'
});
data_peak.push({
lat: 3.3258444445e+01,
lng: 1.3015622222e+02,
cert : true,
content:'Name = JA6/SG-029(JA6/SG-029) peak = 365.399994 pos = 33.2584,130.1562 diff = 277.700012'
});
data_saddle.push({
lat: 3.3239111111e+01,
lng: 1.3014866667e+02,
content:'Saddle = 87.699997 pos = 33.2391,130.1487 diff = 277.700012'
});
data_peak.push({
lat: 3.3100111111e+01,
lng: 1.2984288889e+02,
cert : false,
content:' Peak = 394.000000 pos = 33.1001,129.8429 diff = 306.200012'
});
data_saddle.push({
lat: 3.3141222223e+01,
lng: 1.2984922222e+02,
content:'Saddle = 87.800003 pos = 33.1412,129.8492 diff = 306.200012'
});
data_peak.push({
lat: 3.3329444445e+01,
lng: 1.2999522222e+02,
cert : false,
content:' Peak = 281.899994 pos = 33.3294,129.9952 diff = 193.199997'
});
data_saddle.push({
lat: 3.3315777778e+01,
lng: 1.3000822222e+02,
content:'Saddle = 88.699997 pos = 33.3158,130.0082 diff = 193.199997'
});
data_peak.push({
lat: 3.3205333334e+01,
lng: 1.2995044444e+02,
cert : false,
content:' Peak = 242.399994 pos = 33.2053,129.9504 diff = 153.599991'
});
data_saddle.push({
lat: 3.3195222223e+01,
lng: 1.2994911111e+02,
content:'Saddle = 88.800003 pos = 33.1952,129.9491 diff = 153.599991'
});
data_peak.push({
lat: 3.3436444445e+01,
lng: 1.3036866667e+02,
cert : true,
content:'Name = Sefurisan(JA6/FO-001) peak = 1052.699951 pos = 33.4364,130.3687 diff = 963.499939'
});
data_saddle.push({
lat: 3.3239111111e+01,
lng: 1.3001100000e+02,
content:'Saddle = 89.199997 pos = 33.2391,130.0110 diff = 963.499939'
});
data_peak.push({
lat: 3.3282444445e+01,
lng: 1.3002722222e+02,
cert : true,
content:'Name = JA6/SG-011(JA6/SG-011) peak = 761.599976 pos = 33.2824,130.0272 diff = 663.699951'
});
data_saddle.push({
lat: 3.3304888889e+01,
lng: 1.3007688889e+02,
content:'Saddle = 97.900002 pos = 33.3049,130.0769 diff = 663.699951'
});
data_peak.push({
lat: 3.3235777778e+01,
lng: 1.3010677778e+02,
cert : true,
content:'Name = JA6/SG-021(JA6/SG-021) peak = 481.399994 pos = 33.2358,130.1068 diff = 349.700012'
});
data_saddle.push({
lat: 3.3242555556e+01,
lng: 1.3006633333e+02,
content:'Saddle = 131.699997 pos = 33.2426,130.0663 diff = 349.700012'
});
data_peak.push({
lat: 3.3250222223e+01,
lng: 1.3003988889e+02,
cert : true,
content:'Name = JA6/SG-023(JA6/SG-023) peak = 442.200012 pos = 33.2502,130.0399 diff = 243.400009'
});
data_saddle.push({
lat: 3.3257222223e+01,
lng: 1.3002511111e+02,
content:'Saddle = 198.800003 pos = 33.2572,130.0251 diff = 243.400009'
});
data_peak.push({
lat: 3.3277333334e+01,
lng: 1.2999144444e+02,
cert : true,
content:'Name = JA6/SG-017(JA6/SG-017) peak = 517.900024 pos = 33.2773,129.9914 diff = 215.900024'
});
data_saddle.push({
lat: 3.3280888889e+01,
lng: 1.3000988889e+02,
content:'Saddle = 302.000000 pos = 33.2809,130.0099 diff = 215.900024'
});
data_peak.push({
lat: 3.3289444445e+01,
lng: 1.3005111111e+02,
cert : true,
content:'Name = JA6/SG-012(JA6/SG-012) peak = 693.599976 pos = 33.2894,130.0511 diff = 177.299988'
});
data_saddle.push({
lat: 3.3281000000e+01,
lng: 1.3003944444e+02,
content:'Saddle = 516.299988 pos = 33.2810,130.0394 diff = 177.299988'
});
data_peak.push({
lat: 3.3512111111e+01,
lng: 1.3036444444e+02,
cert : true,
content:'Name = JA6/FO-027(JA6/FO-027) peak = 596.099976 pos = 33.5121,130.3644 diff = 398.499969'
});
data_saddle.push({
lat: 3.3487111111e+01,
lng: 1.3038144444e+02,
content:'Saddle = 197.600006 pos = 33.4871,130.3814 diff = 398.499969'
});
data_peak.push({
lat: 3.3548222222e+01,
lng: 1.3026855556e+02,
cert : false,
content:' Peak = 421.000000 pos = 33.5482,130.2686 diff = 173.100006'
});
data_saddle.push({
lat: 3.3530222222e+01,
lng: 1.3028822222e+02,
content:'Saddle = 247.899994 pos = 33.5302,130.2882 diff = 173.100006'
});
data_peak.push({
lat: 3.3540111111e+01,
lng: 1.3028700000e+02,
cert : false,
content:' Peak = 414.600006 pos = 33.5401,130.2870 diff = 150.800018'
});
data_saddle.push({
lat: 3.3541555556e+01,
lng: 1.3028100000e+02,
content:'Saddle = 263.799988 pos = 33.5416,130.2810 diff = 150.800018'
});
data_peak.push({
lat: 3.3346555556e+01,
lng: 1.3030300000e+02,
cert : true,
content:'Name = JA6/SG-018(JA6/SG-018) peak = 500.200012 pos = 33.3466,130.3030 diff = 198.500000'
});
data_saddle.push({
lat: 3.3353444445e+01,
lng: 1.3030655556e+02,
content:'Saddle = 301.700012 pos = 33.3534,130.3066 diff = 198.500000'
});
data_peak.push({
lat: 3.3522555556e+01,
lng: 1.3028688889e+02,
cert : false,
content:' Peak = 474.700012 pos = 33.5226,130.2869 diff = 156.500000'
});
data_saddle.push({
lat: 3.3509444445e+01,
lng: 1.3028922222e+02,
content:'Saddle = 318.200012 pos = 33.5094,130.2892 diff = 156.500000'
});
data_peak.push({
lat: 3.3360777778e+01,
lng: 1.3032677778e+02,
cert : false,
content:' Peak = 512.200012 pos = 33.3608,130.3268 diff = 164.400024'
});
data_saddle.push({
lat: 3.3373777778e+01,
lng: 1.3031744444e+02,
content:'Saddle = 347.799988 pos = 33.3738,130.3174 diff = 164.400024'
});
data_peak.push({
lat: 3.3472444445e+01,
lng: 1.3006800000e+02,
cert : true,
content:'Name = JA6/SG-015(JA6/SG-015) peak = 532.099976 pos = 33.4724,130.0680 diff = 178.799988'
});
data_saddle.push({
lat: 3.3470000000e+01,
lng: 1.3007688889e+02,
content:'Saddle = 353.299988 pos = 33.4700,130.0769 diff = 178.799988'
});
data_peak.push({
lat: 3.3384000000e+01,
lng: 1.3022244444e+02,
cert : false,
content:' Peak = 530.599976 pos = 33.3840,130.2224 diff = 171.599976'
});
data_saddle.push({
lat: 3.3393888889e+01,
lng: 1.3022966667e+02,
content:'Saddle = 359.000000 pos = 33.3939,130.2297 diff = 171.599976'
});
data_peak.push({
lat: 3.3400111111e+01,
lng: 1.3023855556e+02,
cert : true,
content:'Name = JA6/SG-014(JA6/SG-014) peak = 581.099976 pos = 33.4001,130.2386 diff = 173.199982'
});
data_saddle.push({
lat: 3.3405000000e+01,
lng: 1.3024933333e+02,
content:'Saddle = 407.899994 pos = 33.4050,130.2493 diff = 173.199982'
});
data_peak.push({
lat: 3.3338888889e+01,
lng: 1.3014288889e+02,
cert : true,
content:'Name = Tenzan(JA6/SG-002) peak = 1042.400024 pos = 33.3389,130.1429 diff = 596.300049'
});
data_saddle.push({
lat: 3.3443333334e+01,
lng: 1.3016933333e+02,
content:'Saddle = 446.100006 pos = 33.4433,130.1693 diff = 596.300049'
});
data_peak.push({
lat: 3.3360777778e+01,
lng: 1.3007488889e+02,
cert : true,
content:'Name = JA6/SG-007(JA6/SG-007) peak = 896.500000 pos = 33.3608,130.0749 diff = 279.700012'
});
data_saddle.push({
lat: 3.3397111111e+01,
lng: 1.3009555556e+02,
content:'Saddle = 616.799988 pos = 33.3971,130.0956 diff = 279.700012'
});
data_peak.push({
lat: 3.3375888889e+01,
lng: 1.3012277778e+02,
cert : true,
content:'Name = JA6/SG-005(JA6/SG-005) peak = 901.900024 pos = 33.3759,130.1228 diff = 273.500000'
});
data_saddle.push({
lat: 3.3366111111e+01,
lng: 1.3014366667e+02,
content:'Saddle = 628.400024 pos = 33.3661,130.1437 diff = 273.500000'
});
data_peak.push({
lat: 3.3373666667e+01,
lng: 1.3015944444e+02,
cert : false,
content:' Peak = 790.700012 pos = 33.3737,130.1594 diff = 151.900024'
});
data_saddle.push({
lat: 3.3375111111e+01,
lng: 1.3015055556e+02,
content:'Saddle = 638.799988 pos = 33.3751,130.1506 diff = 151.900024'
});
data_peak.push({
lat: 3.3342000000e+01,
lng: 1.3019466667e+02,
cert : false,
content:' Peak = 841.200012 pos = 33.3420,130.1947 diff = 159.000000'
});
data_saddle.push({
lat: 3.3339111111e+01,
lng: 1.3017688889e+02,
content:'Saddle = 682.200012 pos = 33.3391,130.1769 diff = 159.000000'
});
data_peak.push({
lat: 3.3416777778e+01,
lng: 1.3044600000e+02,
cert : true,
content:'Name = JA6/SG-008(JA6/SG-008) peak = 847.000000 pos = 33.4168,130.4460 diff = 349.799988'
});
data_saddle.push({
lat: 3.3400777778e+01,
lng: 1.3041744444e+02,
content:'Saddle = 497.200012 pos = 33.4008,130.4174 diff = 349.799988'
});
data_peak.push({
lat: 3.3495444445e+01,
lng: 1.3027188889e+02,
cert : true,
content:'Name = JA6/FO-011(JA6/FO-011) peak = 733.500000 pos = 33.4954,130.2719 diff = 194.400024'
});
data_saddle.push({
lat: 3.3487777778e+01,
lng: 1.3026555556e+02,
content:'Saddle = 539.099976 pos = 33.4878,130.2656 diff = 194.400024'
});
data_peak.push({
lat: 3.3470000000e+01,
lng: 1.3009922222e+02,
cert : true,
content:'Name = Ukidake(JA6/SG-009) peak = 801.799988 pos = 33.4700,130.0992 diff = 259.799988'
});
data_saddle.push({
lat: 3.3476000000e+01,
lng: 1.3010944444e+02,
content:'Saddle = 542.000000 pos = 33.4760,130.1094 diff = 259.799988'
});
data_peak.push({
lat: 3.3465444445e+01,
lng: 1.3017588889e+02,
cert : true,
content:'Name = JA6/SG-006(JA6/SG-006) peak = 900.400024 pos = 33.4654,130.1759 diff = 340.000000'
});
data_saddle.push({
lat: 3.3481000000e+01,
lng: 1.3020044444e+02,
content:'Saddle = 560.400024 pos = 33.4810,130.2004 diff = 340.000000'
});
data_peak.push({
lat: 3.3474888889e+01,
lng: 1.3011588889e+02,
cert : false,
content:' Peak = 745.000000 pos = 33.4749,130.1159 diff = 158.700012'
});
data_saddle.push({
lat: 3.3470444445e+01,
lng: 1.3013855556e+02,
content:'Saddle = 586.299988 pos = 33.4704,130.1386 diff = 158.700012'
});
data_peak.push({
lat: 3.3470444445e+01,
lng: 1.3024955556e+02,
cert : true,
content:'Name = JA6/SG-003(JA6/SG-003) peak = 982.099976 pos = 33.4704,130.2496 diff = 394.199951'
});
data_saddle.push({
lat: 3.3474555556e+01,
lng: 1.3028155556e+02,
content:'Saddle = 587.900024 pos = 33.4746,130.2816 diff = 394.199951'
});
data_peak.push({
lat: 3.3463555556e+01,
lng: 1.3030577778e+02,
cert : true,
content:'Name = JA6/SG-004(JA6/SG-004) peak = 965.299988 pos = 33.4636,130.3058 diff = 207.500000'
});
data_saddle.push({
lat: 3.3445111111e+01,
lng: 1.3033677778e+02,
content:'Saddle = 757.799988 pos = 33.4451,130.3368 diff = 207.500000'
});
data_peak.push({
lat: 3.3204888889e+01,
lng: 1.3000077778e+02,
cert : true,
content:'Name = JA6/SG-032(JA6/SG-032) peak = 324.200012 pos = 33.2049,130.0008 diff = 234.800018'
});
data_saddle.push({
lat: 3.3190555556e+01,
lng: 1.2998344444e+02,
content:'Saddle = 89.400002 pos = 33.1906,129.9834 diff = 234.800018'
});
data_peak.push({
lat: 3.3231222223e+01,
lng: 1.2999177778e+02,
cert : false,
content:' Peak = 302.000000 pos = 33.2312,129.9918 diff = 153.899994'
});
data_saddle.push({
lat: 3.3227222223e+01,
lng: 1.3000022222e+02,
content:'Saddle = 148.100006 pos = 33.2272,130.0002 diff = 153.899994'
});
data_peak.push({
lat: 3.3220777778e+01,
lng: 1.3000277778e+02,
cert : false,
content:' Peak = 304.000000 pos = 33.2208,130.0028 diff = 155.699997'
});
data_saddle.push({
lat: 3.3215444445e+01,
lng: 1.3000511111e+02,
content:'Saddle = 148.300003 pos = 33.2154,130.0051 diff = 155.699997'
});
data_peak.push({
lat: 3.3171000000e+01,
lng: 1.2986333333e+02,
cert : true,
content:'Name = JA6/NS-062(JA6/NS-062) peak = 318.100006 pos = 33.1710,129.8633 diff = 220.000000'
});
data_saddle.push({
lat: 3.3161333334e+01,
lng: 1.2989688889e+02,
content:'Saddle = 98.099998 pos = 33.1613,129.8969 diff = 220.000000'
});
data_peak.push({
lat: 3.3223666667e+01,
lng: 1.2989733333e+02,
cert : true,
content:'Name = JA6/SG-013(JA6/SG-013) peak = 616.000000 pos = 33.2237,129.8973 diff = 517.500000'
});
data_saddle.push({
lat: 3.3140777778e+01,
lng: 1.2994788889e+02,
content:'Saddle = 98.500000 pos = 33.1408,129.9479 diff = 517.500000'
});
data_peak.push({
lat: 3.3164777778e+01,
lng: 1.2994422222e+02,
cert : true,
content:'Name = JA6/SG-022(JA6/SG-022) peak = 441.799988 pos = 33.1648,129.9442 diff = 333.899994'
});
data_saddle.push({
lat: 3.3191666667e+01,
lng: 1.2991355556e+02,
content:'Saddle = 107.900002 pos = 33.1917,129.9136 diff = 333.899994'
});
data_peak.push({
lat: 3.3184111111e+01,
lng: 1.2990100000e+02,
cert : false,
content:' Peak = 351.799988 pos = 33.1841,129.9010 diff = 214.699982'
});
data_saddle.push({
lat: 3.3173777778e+01,
lng: 1.2992544444e+02,
content:'Saddle = 137.100006 pos = 33.1738,129.9254 diff = 214.699982'
});
data_peak.push({
lat: 3.3229888889e+01,
lng: 1.2993122222e+02,
cert : true,
content:'Name = JA6/SG-028(JA6/SG-028) peak = 366.200012 pos = 33.2299,129.9312 diff = 248.600006'
});
data_saddle.push({
lat: 3.3225333334e+01,
lng: 1.2992166667e+02,
content:'Saddle = 117.599998 pos = 33.2253,129.9217 diff = 248.600006'
});
data_peak.push({
lat: 3.3243444445e+01,
lng: 1.2987033333e+02,
cert : true,
content:'Name = JA6/SG-020(JA6/SG-020) peak = 485.899994 pos = 33.2434,129.8703 diff = 213.799988'
});
data_saddle.push({
lat: 3.3235666667e+01,
lng: 1.2987122222e+02,
content:'Saddle = 272.100006 pos = 33.2357,129.8712 diff = 213.799988'
});
data_peak.push({
lat: 3.3214222223e+01,
lng: 1.2990166667e+02,
cert : false,
content:' Peak = 514.599976 pos = 33.2142,129.9017 diff = 170.999969'
});
data_saddle.push({
lat: 3.3217777778e+01,
lng: 1.2990100000e+02,
content:'Saddle = 343.600006 pos = 33.2178,129.9010 diff = 170.999969'
});
data_peak.push({
lat: 3.3107333334e+01,
lng: 1.3003711111e+02,
cert : true,
content:'Name = JA6/SG-025(JA6/SG-025) peak = 402.100006 pos = 33.1073,130.0371 diff = 255.100006'
});
data_saddle.push({
lat: 3.3099888889e+01,
lng: 1.3003544444e+02,
content:'Saddle = 147.000000 pos = 33.0999,130.0354 diff = 255.100006'
});
data_peak.push({
lat: 3.3090555556e+01,
lng: 1.2992144444e+02,
cert : true,
content:'Name = Kokuzouzan(JA6/NS-010) peak = 606.099976 pos = 33.0906,129.9214 diff = 416.999969'
});
data_saddle.push({
lat: 3.3062222223e+01,
lng: 1.2995977778e+02,
content:'Saddle = 189.100006 pos = 33.0622,129.9598 diff = 416.999969'
});
data_peak.push({
lat: 3.3069333334e+01,
lng: 1.3004977778e+02,
cert : true,
content:'Name = JA6/SG-019(JA6/SG-019) peak = 501.200012 pos = 33.0693,130.0498 diff = 218.900024'
});
data_saddle.push({
lat: 3.3059000000e+01,
lng: 1.3004722222e+02,
content:'Saddle = 282.299988 pos = 33.0590,130.0472 diff = 218.900024'
});
data_peak.push({
lat: 3.3058444445e+01,
lng: 1.3008122222e+02,
cert : false,
content:' Peak = 500.000000 pos = 33.0584,130.0812 diff = 198.500000'
});
data_saddle.push({
lat: 3.3049111111e+01,
lng: 1.3008077778e+02,
content:'Saddle = 301.500000 pos = 33.0491,130.0808 diff = 198.500000'
});
data_peak.push({
lat: 3.2958111112e+01,
lng: 1.3007644444e+02,
cert : true,
content:'Name = Taradake (Gokaharadake)(JA6/NS-003) peak = 1055.900024 pos = 32.9581,130.0764 diff = 278.400024'
});
data_saddle.push({
lat: 3.2983111112e+01,
lng: 1.3008100000e+02,
content:'Saddle = 777.500000 pos = 32.9831,130.0810 diff = 278.400024'
});
data_peak.push({
lat: 3.2975555556e+01,
lng: 1.3009244444e+02,
cert : false,
content:' Peak = 993.599976 pos = 32.9756,130.0924 diff = 151.099976'
});
data_saddle.push({
lat: 3.2968333334e+01,
lng: 1.3007955556e+02,
content:'Saddle = 842.500000 pos = 32.9683,130.0796 diff = 151.099976'
});
data_peak.push({
lat: 3.2688111112e+01,
lng: 1.3070877778e+02,
cert : true,
content:'Name = JA6/KM-089(JA6/KM-089) peak = 313.399994 pos = 32.6881,130.7088 diff = 266.100006'
});
data_saddle.push({
lat: 3.2677333334e+01,
lng: 1.3072577778e+02,
content:'Saddle = 47.299999 pos = 32.6773,130.7258 diff = 266.100006'
});
data_peak.push({
lat: 3.3679777778e+01,
lng: 1.3046822222e+02,
cert : true,
content:'Name = JA6/FO-046(JA6/FO-046) peak = 366.399994 pos = 33.6798,130.4682 diff = 317.100006'
});
data_saddle.push({
lat: 3.3677000000e+01,
lng: 1.3048511111e+02,
content:'Saddle = 49.299999 pos = 33.6770,130.4851 diff = 317.100006'
});
data_peak.push({
lat: 3.3748000000e+01,
lng: 1.3068111111e+02,
cert : true,
content:'Name = JA6/FO-050(JA6/FO-050) peak = 336.899994 pos = 33.7480,130.6811 diff = 287.500000'
});
data_saddle.push({
lat: 3.3741000000e+01,
lng: 1.3066433333e+02,
content:'Saddle = 49.400002 pos = 33.7410,130.6643 diff = 287.500000'
});
data_peak.push({
lat: 3.3721000000e+01,
lng: 1.3091377778e+02,
cert : false,
content:' Peak = 231.100006 pos = 33.7210,130.9138 diff = 177.500000'
});
data_saddle.push({
lat: 3.3720777778e+01,
lng: 1.3090822222e+02,
content:'Saddle = 53.599998 pos = 33.7208,130.9082 diff = 177.500000'
});
data_peak.push({
lat: 3.3810555556e+01,
lng: 1.3086733333e+02,
cert : false,
content:' Peak = 221.600006 pos = 33.8106,130.8673 diff = 162.900009'
});
data_saddle.push({
lat: 3.3802111111e+01,
lng: 1.3087377778e+02,
content:'Saddle = 58.700001 pos = 33.8021,130.8738 diff = 162.900009'
});
data_peak.push({
lat: 3.3560333334e+01,
lng: 1.3049633333e+02,
cert : false,
content:' Peak = 234.699997 pos = 33.5603,130.4963 diff = 172.500000'
});
data_saddle.push({
lat: 3.3557666667e+01,
lng: 1.3050333333e+02,
content:'Saddle = 62.200001 pos = 33.5577,130.5033 diff = 172.500000'
});
data_peak.push({
lat: 3.2984666667e+01,
lng: 1.3052733333e+02,
cert : true,
content:'Name = Tsutsugatake(JA6/KM-061) peak = 501.100006 pos = 32.9847,130.5273 diff = 435.200012'
});
data_saddle.push({
lat: 3.3009000000e+01,
lng: 1.3053722222e+02,
content:'Saddle = 65.900002 pos = 33.0090,130.5372 diff = 435.200012'
});
data_peak.push({
lat: 3.2274333334e+01,
lng: 1.3050744444e+02,
cert : false,
content:' Peak = 227.800003 pos = 32.2743,130.5074 diff = 160.100006'
});
data_saddle.push({
lat: 3.2264777778e+01,
lng: 1.3052477778e+02,
content:'Saddle = 67.699997 pos = 32.2648,130.5248 diff = 160.100006'
});
data_peak.push({
lat: 3.2844444445e+01,
lng: 1.3062222222e+02,
cert : true,
content:'Name = JA6/KM-043(JA6/KM-043) peak = 683.700012 pos = 32.8444,130.6222 diff = 613.299988'
});
data_saddle.push({
lat: 3.2897111112e+01,
lng: 1.3070911111e+02,
content:'Saddle = 70.400002 pos = 32.8971,130.7091 diff = 613.299988'
});
data_peak.push({
lat: 3.2945555556e+01,
lng: 1.3063722222e+02,
cert : true,
content:'Name = JA6/KM-078(JA6/KM-078) peak = 386.700012 pos = 32.9456,130.6372 diff = 305.900024'
});
data_saddle.push({
lat: 3.2881888889e+01,
lng: 1.3067688889e+02,
content:'Saddle = 80.800003 pos = 32.8819,130.6769 diff = 305.900024'
});
data_peak.push({
lat: 3.2975000000e+01,
lng: 1.3066588889e+02,
cert : true,
content:'Name = JA6/KM-090(JA6/KM-090) peak = 311.299988 pos = 32.9750,130.6659 diff = 225.899994'
});
data_saddle.push({
lat: 3.2950666667e+01,
lng: 1.3067366667e+02,
content:'Saddle = 85.400002 pos = 32.9507,130.6737 diff = 225.899994'
});
data_peak.push({
lat: 3.2935000000e+01,
lng: 1.3061644444e+02,
cert : true,
content:'Name = JA6/KM-080(JA6/KM-080) peak = 382.600006 pos = 32.9350,130.6164 diff = 191.200012'
});
data_saddle.push({
lat: 3.2938000000e+01,
lng: 1.3062344444e+02,
content:'Saddle = 191.399994 pos = 32.9380,130.6234 diff = 191.200012'
});
data_peak.push({
lat: 3.2788777778e+01,
lng: 1.3063022222e+02,
cert : true,
content:'Name = JA6/KM-092(JA6/KM-092) peak = 272.600006 pos = 32.7888,130.6302 diff = 169.500000'
});
data_saddle.push({
lat: 3.2795222223e+01,
lng: 1.3062755556e+02,
content:'Saddle = 103.099998 pos = 32.7952,130.6276 diff = 169.500000'
});
data_peak.push({
lat: 3.2814000000e+01,
lng: 1.3063888889e+02,
cert : true,
content:'Name = Kinbouzan(JA6/KM-045) peak = 663.900024 pos = 32.8140,130.6389 diff = 385.300018'
});
data_saddle.push({
lat: 3.2818555556e+01,
lng: 1.3065566667e+02,
content:'Saddle = 278.600006 pos = 32.8186,130.6557 diff = 385.300018'
});
data_peak.push({
lat: 3.2854888889e+01,
lng: 1.3063144444e+02,
cert : false,
content:' Peak = 681.000000 pos = 32.8549,130.6314 diff = 170.000000'
});
data_saddle.push({
lat: 3.2852444445e+01,
lng: 1.3062544444e+02,
content:'Saddle = 511.000000 pos = 32.8524,130.6254 diff = 170.000000'
});
data_peak.push({
lat: 3.2287000001e+01,
lng: 1.3048722222e+02,
cert : false,
content:' Peak = 232.899994 pos = 32.2870,130.4872 diff = 161.899994'
});
data_saddle.push({
lat: 3.2279777778e+01,
lng: 1.3048866667e+02,
content:'Saddle = 71.000000 pos = 32.2798,130.4887 diff = 161.899994'
});
data_peak.push({
lat: 3.2651222223e+01,
lng: 1.3077433333e+02,
cert : false,
content:' Peak = 273.500000 pos = 32.6512,130.7743 diff = 199.899994'
});
data_saddle.push({
lat: 3.2653444445e+01,
lng: 1.3079511111e+02,
content:'Saddle = 73.599998 pos = 32.6534,130.7951 diff = 199.899994'
});
data_peak.push({
lat: 3.3692111111e+01,
lng: 1.3066311111e+02,
cert : false,
content:' Peak = 267.600006 pos = 33.6921,130.6631 diff = 190.900009'
});
data_saddle.push({
lat: 3.3690111111e+01,
lng: 1.3065722222e+02,
content:'Saddle = 76.699997 pos = 33.6901,130.6572 diff = 190.900009'
});
data_peak.push({
lat: 3.3594555556e+01,
lng: 1.3077588889e+02,
cert : true,
content:'Name = JA6/FO-041(JA6/FO-041) peak = 421.700012 pos = 33.5946,130.7759 diff = 344.800018'
});
data_saddle.push({
lat: 3.3574111111e+01,
lng: 1.3077722222e+02,
content:'Saddle = 76.900002 pos = 33.5741,130.7772 diff = 344.800018'
});
data_peak.push({
lat: 3.3630666667e+01,
lng: 1.3075177778e+02,
cert : true,
content:'Name = JA6/FO-049(JA6/FO-049) peak = 357.899994 pos = 33.6307,130.7518 diff = 200.699997'
});
data_saddle.push({
lat: 3.3619666667e+01,
lng: 1.3075955556e+02,
content:'Saddle = 157.199997 pos = 33.6197,130.7596 diff = 200.699997'
});
data_peak.push({
lat: 3.3849111111e+01,
lng: 1.3057066667e+02,
cert : true,
content:'Name = JA6/FO-034(JA6/FO-034) peak = 495.899994 pos = 33.8491,130.5707 diff = 418.399994'
});
data_saddle.push({
lat: 3.3800888889e+01,
lng: 1.3063400000e+02,
content:'Saddle = 77.500000 pos = 33.8009,130.6340 diff = 418.399994'
});
data_peak.push({
lat: 3.3819444445e+01,
lng: 1.3062488889e+02,
cert : false,
content:' Peak = 266.500000 pos = 33.8194,130.6249 diff = 188.899994'
});
data_saddle.push({
lat: 3.3823000000e+01,
lng: 1.3060722222e+02,
content:'Saddle = 77.599998 pos = 33.8230,130.6072 diff = 188.899994'
});
data_peak.push({
lat: 3.3869555556e+01,
lng: 1.3055300000e+02,
cert : true,
content:'Name = JA6/FO-036(JA6/FO-036) peak = 470.299988 pos = 33.8696,130.5530 diff = 362.299988'
});
data_saddle.push({
lat: 3.3861000000e+01,
lng: 1.3056666667e+02,
content:'Saddle = 108.000000 pos = 33.8610,130.5667 diff = 362.299988'
});
data_peak.push({
lat: 3.3818555556e+01,
lng: 1.3059111111e+02,
cert : true,
content:'Name = JA6/FO-045(JA6/FO-045) peak = 361.799988 pos = 33.8186,130.5911 diff = 204.699982'
});
data_saddle.push({
lat: 3.3841222222e+01,
lng: 1.3058111111e+02,
content:'Saddle = 157.100006 pos = 33.8412,130.5811 diff = 204.699982'
});
data_peak.push({
lat: 3.3053666667e+01,
lng: 1.3061033333e+02,
cert : false,
content:' Peak = 243.100006 pos = 33.0537,130.6103 diff = 165.500000'
});
data_saddle.push({
lat: 3.3067888889e+01,
lng: 1.3060533333e+02,
content:'Saddle = 77.599998 pos = 33.0679,130.6053 diff = 165.500000'
});
data_peak.push({
lat: 3.1867666668e+01,
lng: 1.3041066667e+02,
cert : false,
content:' Peak = 240.100006 pos = 31.8677,130.4107 diff = 162.400009'
});
data_saddle.push({
lat: 3.1876444445e+01,
lng: 1.3040333333e+02,
content:'Saddle = 77.699997 pos = 31.8764,130.4033 diff = 162.400009'
});
data_peak.push({
lat: 3.3027111112e+01,
lng: 1.3050433333e+02,
cert : false,
content:' Peak = 383.399994 pos = 33.0271,130.5043 diff = 305.099976'
});
data_saddle.push({
lat: 3.3078666667e+01,
lng: 1.3054144444e+02,
content:'Saddle = 78.300003 pos = 33.0787,130.5414 diff = 305.099976'
});
data_peak.push({
lat: 3.3083222223e+01,
lng: 1.3052233333e+02,
cert : false,
content:' Peak = 273.399994 pos = 33.0832,130.5223 diff = 156.099991'
});
data_saddle.push({
lat: 3.3075333334e+01,
lng: 1.3051855556e+02,
content:'Saddle = 117.300003 pos = 33.0753,130.5186 diff = 156.099991'
});
data_peak.push({
lat: 3.1830666668e+01,
lng: 1.3034666667e+02,
cert : true,
content:'Name = JA6/KG-123(JA6/KG-123) peak = 310.299988 pos = 31.8307,130.3467 diff = 231.499985'
});
data_saddle.push({
lat: 3.1819555556e+01,
lng: 1.3035388889e+02,
content:'Saddle = 78.800003 pos = 31.8196,130.3539 diff = 231.499985'
});
data_peak.push({
lat: 3.3781222222e+01,
lng: 1.3062211111e+02,
cert : true,
content:'Name = JA6/FO-052(JA6/FO-052) peak = 320.899994 pos = 33.7812,130.6221 diff = 239.799988'
});
data_saddle.push({
lat: 3.3763888889e+01,
lng: 1.3059344444e+02,
content:'Saddle = 81.099998 pos = 33.7639,130.5934 diff = 239.799988'
});
data_peak.push({
lat: 3.3758444445e+01,
lng: 1.3060688889e+02,
cert : false,
content:' Peak = 296.700012 pos = 33.7584,130.6069 diff = 160.200012'
});
data_saddle.push({
lat: 3.3777333333e+01,
lng: 1.3061177778e+02,
content:'Saddle = 136.500000 pos = 33.7773,130.6118 diff = 160.200012'
});
data_peak.push({
lat: 3.1612000001e+01,
lng: 1.3035000000e+02,
cert : false,
content:' Peak = 241.300003 pos = 31.6120,130.3500 diff = 154.500000'
});
data_saddle.push({
lat: 3.1620666668e+01,
lng: 1.3036077778e+02,
content:'Saddle = 86.800003 pos = 31.6207,130.3608 diff = 154.500000'
});
data_peak.push({
lat: 3.3776333333e+01,
lng: 1.3053933333e+02,
cert : false,
content:' Peak = 270.500000 pos = 33.7763,130.5393 diff = 182.899994'
});
data_saddle.push({
lat: 3.3769111111e+01,
lng: 1.3053988889e+02,
content:'Saddle = 87.599998 pos = 33.7691,130.5399 diff = 182.899994'
});
data_peak.push({
lat: 3.2442111112e+01,
lng: 1.3061933333e+02,
cert : true,
content:'Name = JA6/KM-058(JA6/KM-058) peak = 510.600006 pos = 32.4421,130.6193 diff = 422.900024'
});
data_saddle.push({
lat: 3.2403444445e+01,
lng: 1.3060300000e+02,
content:'Saddle = 87.699997 pos = 32.4034,130.6030 diff = 422.900024'
});
data_peak.push({
lat: 3.2409111112e+01,
lng: 1.3061055556e+02,
cert : false,
content:' Peak = 291.399994 pos = 32.4091,130.6106 diff = 172.799988'
});
data_saddle.push({
lat: 3.2410444445e+01,
lng: 1.3060466667e+02,
content:'Saddle = 118.599998 pos = 32.4104,130.6047 diff = 172.799988'
});
data_peak.push({
lat: 3.2466888890e+01,
lng: 1.3061900000e+02,
cert : false,
content:' Peak = 361.100006 pos = 32.4669,130.6190 diff = 168.300003'
});
data_saddle.push({
lat: 3.2457444445e+01,
lng: 1.3060866667e+02,
content:'Saddle = 192.800003 pos = 32.4574,130.6087 diff = 168.300003'
});
data_peak.push({
lat: 3.1776777779e+01,
lng: 1.3024177778e+02,
cert : true,
content:'Name = JA6/KG-061(JA6/KG-061) peak = 527.099976 pos = 31.7768,130.2418 diff = 439.199982'
});
data_saddle.push({
lat: 3.1753111112e+01,
lng: 1.3029677778e+02,
content:'Saddle = 87.900002 pos = 31.7531,130.2968 diff = 439.199982'
});
data_peak.push({
lat: 3.1404555557e+01,
lng: 1.3015822222e+02,
cert : true,
content:'Name = Nomadake(JA6/KG-047) peak = 591.000000 pos = 31.4046,130.1582 diff = 502.700012'
});
data_saddle.push({
lat: 3.1347666668e+01,
lng: 1.3027611111e+02,
content:'Saddle = 88.300003 pos = 31.3477,130.2761 diff = 502.700012'
});
data_peak.push({
lat: 3.1380333334e+01,
lng: 1.3026722222e+02,
cert : true,
content:'Name = JA6/KG-069(JA6/KG-069) peak = 513.099976 pos = 31.3803,130.2672 diff = 420.699982'
});
data_saddle.push({
lat: 3.1378222223e+01,
lng: 1.3017111111e+02,
content:'Saddle = 92.400002 pos = 31.3782,130.1711 diff = 420.699982'
});
data_peak.push({
lat: 3.1351444446e+01,
lng: 1.3021955556e+02,
cert : false,
content:' Peak = 386.399994 pos = 31.3514,130.2196 diff = 267.899994'
});
data_saddle.push({
lat: 3.1333444446e+01,
lng: 1.3023188889e+02,
content:'Saddle = 118.500000 pos = 31.3334,130.2319 diff = 267.899994'
});
data_peak.push({
lat: 3.1380222223e+01,
lng: 1.3018322222e+02,
cert : false,
content:' Peak = 360.200012 pos = 31.3802,130.1832 diff = 192.400009'
});
data_saddle.push({
lat: 3.1374111112e+01,
lng: 1.3019211111e+02,
content:'Saddle = 167.800003 pos = 31.3741,130.1921 diff = 192.400009'
});
data_peak.push({
lat: 3.1336444446e+01,
lng: 1.3024122222e+02,
cert : false,
content:' Peak = 390.100006 pos = 31.3364,130.2412 diff = 221.800003'
});
data_saddle.push({
lat: 3.1354777779e+01,
lng: 1.3026200000e+02,
content:'Saddle = 168.300003 pos = 31.3548,130.2620 diff = 221.800003'
});
data_peak.push({
lat: 3.3742333333e+01,
lng: 1.3080388889e+02,
cert : true,
content:'Name = Fukuchiyama(JA6/FO-006) peak = 901.200012 pos = 33.7423,130.8039 diff = 812.700012'
});
data_saddle.push({
lat: 3.3613444445e+01,
lng: 1.3087544444e+02,
content:'Saddle = 88.500000 pos = 33.6134,130.8754 diff = 812.700012'
});
data_peak.push({
lat: 3.3667444445e+01,
lng: 1.3090788889e+02,
cert : false,
content:' Peak = 352.600006 pos = 33.6674,130.9079 diff = 151.200012'
});
data_saddle.push({
lat: 3.3665555556e+01,
lng: 1.3090366667e+02,
content:'Saddle = 201.399994 pos = 33.6656,130.9037 diff = 151.200012'
});
data_peak.push({
lat: 3.3762666667e+01,
lng: 1.3084655556e+02,
cert : true,
content:'Name = JA6/FO-043(JA6/FO-043) peak = 394.299988 pos = 33.7627,130.8466 diff = 186.399994'
});
data_saddle.push({
lat: 3.3741777778e+01,
lng: 1.3084833333e+02,
content:'Saddle = 207.899994 pos = 33.7418,130.8483 diff = 186.399994'
});
data_peak.push({
lat: 3.3768444445e+01,
lng: 1.3095266667e+02,
cert : false,
content:' Peak = 415.000000 pos = 33.7684,130.9527 diff = 193.000000'
});
data_saddle.push({
lat: 3.3770888889e+01,
lng: 1.3094677778e+02,
content:'Saddle = 222.000000 pos = 33.7709,130.9468 diff = 193.000000'
});
data_peak.push({
lat: 3.3780555556e+01,
lng: 1.3090933333e+02,
cert : false,
content:' Peak = 711.400024 pos = 33.7806,130.9093 diff = 489.200012'
});
data_saddle.push({
lat: 3.3736111111e+01,
lng: 1.3085811111e+02,
content:'Saddle = 222.199997 pos = 33.7361,130.8581 diff = 489.200012'
});
data_peak.push({
lat: 3.3658111111e+01,
lng: 1.3088122222e+02,
cert : true,
content:'Name = JA6/FO-029(JA6/FO-029) peak = 571.900024 pos = 33.6581,130.8812 diff = 324.300018'
});
data_saddle.push({
lat: 3.3702555556e+01,
lng: 1.3087600000e+02,
content:'Saddle = 247.600006 pos = 33.7026,130.8760 diff = 324.300018'
});
data_peak.push({
lat: 3.3736888889e+01,
lng: 1.3086688889e+02,
cert : true,
content:'Name = JA6/FO-019(JA6/FO-019) peak = 680.700012 pos = 33.7369,130.8669 diff = 303.200012'
});
data_saddle.push({
lat: 3.3762111111e+01,
lng: 1.3089122222e+02,
content:'Saddle = 377.500000 pos = 33.7621,130.8912 diff = 303.200012'
});
data_peak.push({
lat: 3.3752666667e+01,
lng: 1.3088188889e+02,
cert : true,
content:'Name = JA6/FO-030(JA6/FO-030) peak = 540.700012 pos = 33.7527,130.8819 diff = 152.100006'
});
data_saddle.push({
lat: 3.3748555556e+01,
lng: 1.3087711111e+02,
content:'Saddle = 388.600006 pos = 33.7486,130.8771 diff = 152.100006'
});
data_peak.push({
lat: 3.3692222222e+01,
lng: 1.3084444444e+02,
cert : true,
content:'Name = JA6/FO-032(JA6/FO-032) peak = 511.600006 pos = 33.6922,130.8444 diff = 243.300018'
});
data_saddle.push({
lat: 3.3692666667e+01,
lng: 1.3083922222e+02,
content:'Saddle = 268.299988 pos = 33.6927,130.8392 diff = 243.300018'
});
data_peak.push({
lat: 3.3846555556e+01,
lng: 1.3079644444e+02,
cert : true,
content:'Name = JA6/FO-024(JA6/FO-024) peak = 623.099976 pos = 33.8466,130.7964 diff = 324.099976'
});
data_saddle.push({
lat: 3.3830888889e+01,
lng: 1.3078100000e+02,
content:'Saddle = 299.000000 pos = 33.8309,130.7810 diff = 324.099976'
});
data_peak.push({
lat: 3.3791555556e+01,
lng: 1.3082877778e+02,
cert : false,
content:' Peak = 500.799988 pos = 33.7916,130.8288 diff = 172.299988'
});
data_saddle.push({
lat: 3.3794666667e+01,
lng: 1.3081911111e+02,
content:'Saddle = 328.500000 pos = 33.7947,130.8191 diff = 172.299988'
});
data_peak.push({
lat: 3.3786000000e+01,
lng: 1.3078077778e+02,
cert : true,
content:'Name = JA6/FO-028(JA6/FO-028) peak = 573.599976 pos = 33.7860,130.7808 diff = 182.699982'
});
data_saddle.push({
lat: 3.3779333333e+01,
lng: 1.3079144444e+02,
content:'Saddle = 390.899994 pos = 33.7793,130.7914 diff = 182.699982'
});
data_peak.push({
lat: 3.2608000001e+01,
lng: 1.3073100000e+02,
cert : false,
content:' Peak = 280.799988 pos = 32.6080,130.7310 diff = 191.899994'
});
data_saddle.push({
lat: 3.2612333334e+01,
lng: 1.3075155556e+02,
content:'Saddle = 88.900002 pos = 32.6123,130.7516 diff = 191.899994'
});
data_peak.push({
lat: 3.1339777779e+01,
lng: 1.3030244444e+02,
cert : true,
content:'Name = JA6/KG-078(JA6/KG-078) peak = 474.500000 pos = 31.3398,130.3024 diff = 379.600006'
});
data_saddle.push({
lat: 3.1333444446e+01,
lng: 1.3033711111e+02,
content:'Saddle = 94.900002 pos = 31.3334,130.3371 diff = 379.600006'
});
data_peak.push({
lat: 3.1989444445e+01,
lng: 1.3022688889e+02,
cert : true,
content:'Name = JA6/KG-120(JA6/KG-120) peak = 320.799988 pos = 31.9894,130.2269 diff = 223.499985'
});
data_saddle.push({
lat: 3.1986777779e+01,
lng: 1.3023655556e+02,
content:'Saddle = 97.300003 pos = 31.9868,130.2366 diff = 223.499985'
});
data_peak.push({
lat: 3.3551777778e+01,
lng: 1.3069377778e+02,
cert : true,
content:'Name = JA6/FO-053(JA6/FO-053) peak = 310.100006 pos = 33.5518,130.6938 diff = 212.000000'
});
data_saddle.push({
lat: 3.3541222222e+01,
lng: 1.3068555556e+02,
content:'Saddle = 98.099998 pos = 33.5412,130.6856 diff = 212.000000'
});
data_peak.push({
lat: 3.1787000001e+01,
lng: 1.3035344444e+02,
cert : true,
content:'Name = JA6/KG-117(JA6/KG-117) peak = 340.000000 pos = 31.7870,130.3534 diff = 237.399994'
});
data_saddle.push({
lat: 3.1776222223e+01,
lng: 1.3037611111e+02,
content:'Saddle = 102.599998 pos = 31.7762,130.3761 diff = 237.399994'
});
data_peak.push({
lat: 3.1905333334e+01,
lng: 1.3029100000e+02,
cert : false,
content:' Peak = 263.100006 pos = 31.9053,130.2910 diff = 156.600006'
});
data_saddle.push({
lat: 3.1914333334e+01,
lng: 1.3028000000e+02,
content:'Saddle = 106.500000 pos = 31.9143,130.2800 diff = 156.600006'
});
data_peak.push({
lat: 3.3051111111e+01,
lng: 1.3058344444e+02,
cert : false,
content:' Peak = 316.600006 pos = 33.0511,130.5834 diff = 208.600006'
});
data_saddle.push({
lat: 3.3066444445e+01,
lng: 1.3057433333e+02,
content:'Saddle = 108.000000 pos = 33.0664,130.5743 diff = 208.600006'
});
data_peak.push({
lat: 3.1431666668e+01,
lng: 1.3035711111e+02,
cert : true,
content:'Name = JA6/KG-130(JA6/KG-130) peak = 286.899994 pos = 31.4317,130.3571 diff = 176.399994'
});
data_saddle.push({
lat: 3.1438000001e+01,
lng: 1.3036888889e+02,
content:'Saddle = 110.500000 pos = 31.4380,130.3689 diff = 176.399994'
});
data_peak.push({
lat: 3.1333777779e+01,
lng: 1.3037700000e+02,
cert : false,
content:' Peak = 353.799988 pos = 31.3338,130.3770 diff = 239.499985'
});
data_saddle.push({
lat: 3.1333444446e+01,
lng: 1.3039333333e+02,
content:'Saddle = 114.300003 pos = 31.3334,130.3933 diff = 239.499985'
});
data_peak.push({
lat: 3.3538222222e+01,
lng: 1.3051411111e+02,
cert : true,
content:'Name = JA6/FO-042(JA6/FO-042) peak = 403.500000 pos = 33.5382,130.5141 diff = 286.299988'
});
data_saddle.push({
lat: 3.3549000000e+01,
lng: 1.3054055556e+02,
content:'Saddle = 117.199997 pos = 33.5490,130.5406 diff = 286.299988'
});
data_peak.push({
lat: 3.3702000000e+01,
lng: 1.3063644444e+02,
cert : false,
content:' Peak = 280.399994 pos = 33.7020,130.6364 diff = 162.500000'
});
data_saddle.push({
lat: 3.3698222222e+01,
lng: 1.3062411111e+02,
content:'Saddle = 117.900002 pos = 33.6982,130.6241 diff = 162.500000'
});
data_peak.push({
lat: 3.1871666668e+01,
lng: 1.3046366667e+02,
cert : true,
content:'Name = JA6/KG-107(JA6/KG-107) peak = 383.399994 pos = 31.8717,130.4637 diff = 256.599976'
});
data_saddle.push({
lat: 3.1876333334e+01,
lng: 1.3051366667e+02,
content:'Saddle = 126.800003 pos = 31.8763,130.5137 diff = 256.599976'
});
data_peak.push({
lat: 3.3476333334e+01,
lng: 1.3092588889e+02,
cert : true,
content:'Name = Hikosan(JA6/OT-016) peak = 1193.400024 pos = 33.4763,130.9259 diff = 1065.099976'
});
data_saddle.push({
lat: 3.3287555556e+01,
lng: 1.3099988889e+02,
content:'Saddle = 128.300003 pos = 33.2876,130.9999 diff = 1065.099976'
});
data_peak.push({
lat: 3.3307777778e+01,
lng: 1.3099800000e+02,
cert : false,
content:' Peak = 334.200012 pos = 33.3078,130.9980 diff = 201.600006'
});
data_saddle.push({
lat: 3.3330222222e+01,
lng: 1.3099988889e+02,
content:'Saddle = 132.600006 pos = 33.3302,130.9999 diff = 201.600006'
});
data_peak.push({
lat: 3.3434666667e+01,
lng: 1.3068566667e+02,
cert : false,
content:' Peak = 313.200012 pos = 33.4347,130.6857 diff = 174.400009'
});
data_saddle.push({
lat: 3.3436333334e+01,
lng: 1.3071944444e+02,
content:'Saddle = 138.800003 pos = 33.4363,130.7194 diff = 174.400009'
});
data_peak.push({
lat: 3.3492888889e+01,
lng: 1.3056844444e+02,
cert : true,
content:'Name = JA6/FO-051(JA6/FO-051) peak = 338.500000 pos = 33.4929,130.5684 diff = 189.899994'
});
data_saddle.push({
lat: 3.3502888889e+01,
lng: 1.3057311111e+02,
content:'Saddle = 148.600006 pos = 33.5029,130.5731 diff = 189.899994'
});
data_peak.push({
lat: 3.3597777778e+01,
lng: 1.3099422222e+02,
cert : false,
content:' Peak = 373.399994 pos = 33.5978,130.9942 diff = 180.299988'
});
data_saddle.push({
lat: 3.3584333333e+01,
lng: 1.3099988889e+02,
content:'Saddle = 193.100006 pos = 33.5843,130.9999 diff = 180.299988'
});
data_peak.push({
lat: 3.3549666667e+01,
lng: 1.3066577778e+02,
cert : true,
content:'Name = JA6/FO-044(JA6/FO-044) peak = 376.899994 pos = 33.5497,130.6658 diff = 178.899994'
});
data_saddle.push({
lat: 3.3540444445e+01,
lng: 1.3065900000e+02,
content:'Saddle = 198.000000 pos = 33.5404,130.6590 diff = 178.899994'
});
data_peak.push({
lat: 3.3686666667e+01,
lng: 1.3064211111e+02,
cert : true,
content:'Name = JA6/FO-040(JA6/FO-040) peak = 421.600006 pos = 33.6867,130.6421 diff = 209.000000'
});
data_saddle.push({
lat: 3.3669777778e+01,
lng: 1.3063344444e+02,
content:'Saddle = 212.600006 pos = 33.6698,130.6334 diff = 209.000000'
});
data_peak.push({
lat: 3.3673333333e+01,
lng: 1.3061855556e+02,
cert : true,
content:'Name = JA6/FO-039(JA6/FO-039) peak = 442.200012 pos = 33.6733,130.6186 diff = 221.500015'
});
data_saddle.push({
lat: 3.3642222222e+01,
lng: 1.3062411111e+02,
content:'Saddle = 220.699997 pos = 33.6422,130.6241 diff = 221.500015'
});
data_peak.push({
lat: 3.3362555556e+01,
lng: 1.3086166667e+02,
cert : true,
content:'Name = JA6/OT-084(JA6/OT-084) peak = 510.000000 pos = 33.3626,130.8617 diff = 281.100006'
});
data_saddle.push({
lat: 3.3405333334e+01,
lng: 1.3084900000e+02,
content:'Saddle = 228.899994 pos = 33.4053,130.8490 diff = 281.100006'
});
data_peak.push({
lat: 3.3409666667e+01,
lng: 1.3075944444e+02,
cert : true,
content:'Name = JA6/FO-037(JA6/FO-037) peak = 461.000000 pos = 33.4097,130.7594 diff = 198.200012'
});
data_saddle.push({
lat: 3.3393000000e+01,
lng: 1.3078055556e+02,
content:'Saddle = 262.799988 pos = 33.3930,130.7806 diff = 198.200012'
});
data_peak.push({
lat: 3.3355666667e+01,
lng: 1.3099844444e+02,
cert : false,
content:' Peak = 533.500000 pos = 33.3557,130.9984 diff = 259.600006'
});
data_saddle.push({
lat: 3.3366333334e+01,
lng: 1.3099966667e+02,
content:'Saddle = 273.899994 pos = 33.3663,130.9997 diff = 259.600006'
});
data_peak.push({
lat: 3.3660444445e+01,
lng: 1.3058144444e+02,
cert : true,
content:'Name = JA6/FO-018(JA6/FO-018) peak = 681.500000 pos = 33.6604,130.5814 diff = 394.600006'
});
data_saddle.push({
lat: 3.3623555556e+01,
lng: 1.3059055556e+02,
content:'Saddle = 286.899994 pos = 33.6236,130.5906 diff = 394.600006'
});
data_peak.push({
lat: 3.3720333333e+01,
lng: 1.3055922222e+02,
cert : true,
content:'Name = JA6/FO-021(JA6/FO-021) peak = 642.099976 pos = 33.7203,130.5592 diff = 274.199982'
});
data_saddle.push({
lat: 3.3675000000e+01,
lng: 1.3054400000e+02,
content:'Saddle = 367.899994 pos = 33.6750,130.5440 diff = 274.199982'
});
data_peak.push({
lat: 3.3674222222e+01,
lng: 1.3056455556e+02,
cert : true,
content:'Name = JA6/FO-023(JA6/FO-023) peak = 623.299988 pos = 33.6742,130.5646 diff = 164.899994'
});
data_saddle.push({
lat: 3.3663111111e+01,
lng: 1.3057044444e+02,
content:'Saddle = 458.399994 pos = 33.6631,130.5704 diff = 164.899994'
});
data_peak.push({
lat: 3.3555666667e+01,
lng: 1.3058377778e+02,
cert : true,
content:'Name = Sangunzan(JA6/FO-004) peak = 930.200012 pos = 33.5557,130.5838 diff = 642.099976'
});
data_saddle.push({
lat: 3.3510222222e+01,
lng: 1.3062055556e+02,
content:'Saddle = 288.100006 pos = 33.5102,130.6206 diff = 642.099976'
});
data_peak.push({
lat: 3.3615555556e+01,
lng: 1.3061244444e+02,
cert : true,
content:'Name = JA6/FO-025(JA6/FO-025) peak = 611.500000 pos = 33.6156,130.6124 diff = 302.399994'
});
data_saddle.push({
lat: 3.3596777778e+01,
lng: 1.3058100000e+02,
content:'Saddle = 309.100006 pos = 33.5968,130.5810 diff = 302.399994'
});
data_peak.push({
lat: 3.3545222222e+01,
lng: 1.3062388889e+02,
cert : false,
content:' Peak = 482.500000 pos = 33.5452,130.6239 diff = 150.500000'
});
data_saddle.push({
lat: 3.3538444445e+01,
lng: 1.3061800000e+02,
content:'Saddle = 332.000000 pos = 33.5384,130.6180 diff = 150.500000'
});
data_peak.push({
lat: 3.3519555556e+01,
lng: 1.3060866667e+02,
cert : true,
content:'Name = JA6/FO-020(JA6/FO-020) peak = 651.400024 pos = 33.5196,130.6087 diff = 304.100037'
});
data_saddle.push({
lat: 3.3537666667e+01,
lng: 1.3059866667e+02,
content:'Saddle = 347.299988 pos = 33.5377,130.5987 diff = 304.100037'
});
data_peak.push({
lat: 3.3597888889e+01,
lng: 1.3054455556e+02,
cert : false,
content:' Peak = 680.700012 pos = 33.5979,130.5446 diff = 183.000000'
});
data_saddle.push({
lat: 3.3596000000e+01,
lng: 1.3056033333e+02,
content:'Saddle = 497.700012 pos = 33.5960,130.5603 diff = 183.000000'
});
data_peak.push({
lat: 3.3493111111e+01,
lng: 1.3061033333e+02,
cert : true,
content:'Name = JA6/FO-035(JA6/FO-035) peak = 495.299988 pos = 33.4931,130.6103 diff = 198.000000'
});
data_saddle.push({
lat: 3.3500111111e+01,
lng: 1.3061444444e+02,
content:'Saddle = 297.299988 pos = 33.5001,130.6144 diff = 198.000000'
});
data_peak.push({
lat: 3.3546666667e+01,
lng: 1.3088677778e+02,
cert : false,
content:' Peak = 512.000000 pos = 33.5467,130.8868 diff = 194.899994'
});
data_saddle.push({
lat: 3.3541777778e+01,
lng: 1.3088488889e+02,
content:'Saddle = 317.100006 pos = 33.5418,130.8849 diff = 194.899994'
});
data_peak.push({
lat: 3.3415555556e+01,
lng: 1.3087000000e+02,
cert : false,
content:' Peak = 542.299988 pos = 33.4156,130.8700 diff = 150.299988'
});
data_saddle.push({
lat: 3.3419555556e+01,
lng: 1.3086922222e+02,
content:'Saddle = 392.000000 pos = 33.4196,130.8692 diff = 150.299988'
});
data_peak.push({
lat: 3.3454888889e+01,
lng: 1.3076322222e+02,
cert : true,
content:'Name = JA6/FO-016(JA6/FO-016) peak = 693.400024 pos = 33.4549,130.7632 diff = 286.400024'
});
data_saddle.push({
lat: 3.3456444445e+01,
lng: 1.3079500000e+02,
content:'Saddle = 407.000000 pos = 33.4564,130.7950 diff = 286.400024'
});
data_peak.push({
lat: 3.3435555556e+01,
lng: 1.3080244444e+02,
cert : true,
content:'Name = JA6/FO-022(JA6/FO-022) peak = 640.799988 pos = 33.4356,130.8024 diff = 170.000000'
});
data_saddle.push({
lat: 3.3432000000e+01,
lng: 1.3080255556e+02,
content:'Saddle = 470.799988 pos = 33.4320,130.8026 diff = 170.000000'
});
data_peak.push({
lat: 3.3457333334e+01,
lng: 1.3081788889e+02,
cert : true,
content:'Name = JA6/FO-010(JA6/FO-010) peak = 742.299988 pos = 33.4573,130.8179 diff = 266.399994'
});
data_saddle.push({
lat: 3.3465444445e+01,
lng: 1.3083022222e+02,
content:'Saddle = 475.899994 pos = 33.4654,130.8302 diff = 266.399994'
});
data_peak.push({
lat: 3.3419000000e+01,
lng: 1.3080977778e+02,
cert : true,
content:'Name = JA6/FO-012(JA6/FO-012) peak = 714.000000 pos = 33.4190,130.8098 diff = 186.200012'
});
data_saddle.push({
lat: 3.3417666667e+01,
lng: 1.3083477778e+02,
content:'Saddle = 527.799988 pos = 33.4177,130.8348 diff = 186.200012'
});
data_peak.push({
lat: 3.3440222222e+01,
lng: 1.3082788889e+02,
cert : false,
content:' Peak = 732.599976 pos = 33.4402,130.8279 diff = 151.000000'
});
data_saddle.push({
lat: 3.3449222222e+01,
lng: 1.3082788889e+02,
content:'Saddle = 581.599976 pos = 33.4492,130.8279 diff = 151.000000'
});
data_peak.push({
lat: 3.3486555556e+01,
lng: 1.3076777778e+02,
cert : true,
content:'Name = Umamiyama(JA6/FO-002) peak = 976.400024 pos = 33.4866,130.7678 diff = 499.100037'
});
data_saddle.push({
lat: 3.3469222222e+01,
lng: 1.3083255556e+02,
content:'Saddle = 477.299988 pos = 33.4692,130.8326 diff = 499.100037'
});
data_peak.push({
lat: 3.3513222222e+01,
lng: 1.3081088889e+02,
cert : true,
content:'Name = JA6/FO-015(JA6/FO-015) peak = 711.599976 pos = 33.5132,130.8109 diff = 214.099976'
});
data_saddle.push({
lat: 3.3479333334e+01,
lng: 1.3080933333e+02,
content:'Saddle = 497.500000 pos = 33.4793,130.8093 diff = 214.099976'
});
data_peak.push({
lat: 3.3487444445e+01,
lng: 1.3083377778e+02,
cert : true,
content:'Name = JA6/FO-014(JA6/FO-014) peak = 710.700012 pos = 33.4874,130.8338 diff = 183.500000'
});
data_saddle.push({
lat: 3.3494777778e+01,
lng: 1.3081477778e+02,
content:'Saddle = 527.200012 pos = 33.4948,130.8148 diff = 183.500000'
});
data_peak.push({
lat: 3.3487888889e+01,
lng: 1.3074033333e+02,
cert : true,
content:'Name = JA6/FO-005(JA6/FO-005) peak = 925.400024 pos = 33.4879,130.7403 diff = 243.500000'
});
data_saddle.push({
lat: 3.3487777778e+01,
lng: 1.3075522222e+02,
content:'Saddle = 681.900024 pos = 33.4878,130.7552 diff = 243.500000'
});
data_peak.push({
lat: 3.3564777778e+01,
lng: 1.3091444444e+02,
cert : true,
content:'Name = JA6/FO-017(JA6/FO-017) peak = 693.200012 pos = 33.5648,130.9144 diff = 215.300018'
});
data_saddle.push({
lat: 3.3539888889e+01,
lng: 1.3092811111e+02,
content:'Saddle = 477.899994 pos = 33.5399,130.9281 diff = 215.300018'
});
data_peak.push({
lat: 3.3414555556e+01,
lng: 1.3092200000e+02,
cert : true,
content:'Name = JA6/OT-055(JA6/OT-055) peak = 645.299988 pos = 33.4146,130.9220 diff = 166.699982'
});
data_saddle.push({
lat: 3.3424333334e+01,
lng: 1.3091277778e+02,
content:'Saddle = 478.600006 pos = 33.4243,130.9128 diff = 166.699982'
});
data_peak.push({
lat: 3.3391000000e+01,
lng: 1.3092122222e+02,
cert : false,
content:' Peak = 643.099976 pos = 33.3910,130.9212 diff = 150.999969'
});
data_saddle.push({
lat: 3.3394888889e+01,
lng: 1.3092266667e+02,
content:'Saddle = 492.100006 pos = 33.3949,130.9227 diff = 150.999969'
});
data_peak.push({
lat: 3.3430000000e+01,
lng: 1.3085911111e+02,
cert : false,
content:' Peak = 727.500000 pos = 33.4300,130.8591 diff = 165.299988'
});
data_saddle.push({
lat: 3.3434111111e+01,
lng: 1.3085944444e+02,
content:'Saddle = 562.200012 pos = 33.4341,130.8594 diff = 165.299988'
});
data_peak.push({
lat: 3.3450444445e+01,
lng: 1.3086077778e+02,
cert : false,
content:' Peak = 823.799988 pos = 33.4504,130.8608 diff = 184.599976'
});
data_saddle.push({
lat: 3.3450666667e+01,
lng: 1.3086744444e+02,
content:'Saddle = 639.200012 pos = 33.4507,130.8674 diff = 184.599976'
});
data_peak.push({
lat: 3.3417444445e+01,
lng: 1.3097177778e+02,
cert : true,
content:'Name = JA6/OT-028(JA6/OT-028) peak = 911.500000 pos = 33.4174,130.9718 diff = 198.400024'
});
data_saddle.push({
lat: 3.3430555556e+01,
lng: 1.3095766667e+02,
content:'Saddle = 713.099976 pos = 33.4306,130.9577 diff = 198.400024'
});
data_peak.push({
lat: 3.3509333334e+01,
lng: 1.3098988889e+02,
cert : false,
content:' Peak = 1122.000000 pos = 33.5093,130.9899 diff = 394.900024'
});
data_saddle.push({
lat: 3.3496222222e+01,
lng: 1.3096222222e+02,
content:'Saddle = 727.099976 pos = 33.4962,130.9622 diff = 394.900024'
});
data_peak.push({
lat: 3.2364111112e+01,
lng: 1.3062766667e+02,
cert : true,
content:'Name = JA6/KM-048(JA6/KM-048) peak = 623.000000 pos = 32.3641,130.6277 diff = 484.600006'
});
data_saddle.push({
lat: 3.2293222223e+01,
lng: 1.3056544444e+02,
content:'Saddle = 138.399994 pos = 32.2932,130.5654 diff = 484.600006'
});
data_peak.push({
lat: 3.2387777778e+01,
lng: 1.3053055556e+02,
cert : false,
content:' Peak = 331.299988 pos = 32.3878,130.5306 diff = 184.299988'
});
data_saddle.push({
lat: 3.2378666667e+01,
lng: 1.3052855556e+02,
content:'Saddle = 147.000000 pos = 32.3787,130.5286 diff = 184.299988'
});
data_peak.push({
lat: 3.2313111112e+01,
lng: 1.3059777778e+02,
cert : true,
content:'Name = JA6/KM-064(JA6/KM-064) peak = 484.799988 pos = 32.3131,130.5978 diff = 316.000000'
});
data_saddle.push({
lat: 3.2306222223e+01,
lng: 1.3053788889e+02,
content:'Saddle = 168.800003 pos = 32.3062,130.5379 diff = 316.000000'
});
data_peak.push({
lat: 3.2345000001e+01,
lng: 1.3054877778e+02,
cert : true,
content:'Name = JA6/KM-052(JA6/KM-052) peak = 565.500000 pos = 32.3450,130.5488 diff = 298.700012'
});
data_saddle.push({
lat: 3.2363888890e+01,
lng: 1.3054011111e+02,
content:'Saddle = 266.799988 pos = 32.3639,130.5401 diff = 298.700012'
});
data_peak.push({
lat: 3.2287000001e+01,
lng: 1.3056744444e+02,
cert : true,
content:'Name = JA6/KM-091(JA6/KM-091) peak = 310.700012 pos = 32.2870,130.5674 diff = 162.400009'
});
data_saddle.push({
lat: 3.2275888890e+01,
lng: 1.3056744444e+02,
content:'Saddle = 148.300003 pos = 32.2759,130.5674 diff = 162.400009'
});
data_peak.push({
lat: 3.1598222223e+01,
lng: 1.3038111111e+02,
cert : true,
content:'Name = JA6/KG-124(JA6/KG-124) peak = 310.600006 pos = 31.5982,130.3811 diff = 159.900009'
});
data_saddle.push({
lat: 3.1602555557e+01,
lng: 1.3039333333e+02,
content:'Saddle = 150.699997 pos = 31.6026,130.3933 diff = 159.900009'
});
data_peak.push({
lat: 3.2764666667e+01,
lng: 1.3083288889e+02,
cert : false,
content:' Peak = 309.799988 pos = 32.7647,130.8329 diff = 157.799988'
});
data_saddle.push({
lat: 3.2767333334e+01,
lng: 1.3083944444e+02,
content:'Saddle = 152.000000 pos = 32.7673,130.8394 diff = 157.799988'
});
data_peak.push({
lat: 3.3053888889e+01,
lng: 1.3070622222e+02,
cert : true,
content:'Name = JA6/KM-071(JA6/KM-071) peak = 414.299988 pos = 33.0539,130.7062 diff = 257.599976'
});
data_saddle.push({
lat: 3.3055666667e+01,
lng: 1.3071766667e+02,
content:'Saddle = 156.699997 pos = 33.0557,130.7177 diff = 257.599976'
});
data_peak.push({
lat: 3.1467777779e+01,
lng: 1.3038288889e+02,
cert : true,
content:'Name = Kinpouzan(JA6/KG-039) peak = 632.099976 pos = 31.4678,130.3829 diff = 472.499969'
});
data_saddle.push({
lat: 3.1685666668e+01,
lng: 1.3045966667e+02,
content:'Saddle = 159.600006 pos = 31.6857,130.4597 diff = 472.499969'
});
data_peak.push({
lat: 3.1384111112e+01,
lng: 1.3050633333e+02,
cert : true,
content:'Name = JA6/KG-043(JA6/KG-043) peak = 604.599976 pos = 31.3841,130.5063 diff = 359.899963'
});
data_saddle.push({
lat: 3.1476555557e+01,
lng: 1.3039466667e+02,
content:'Saddle = 244.699997 pos = 31.4766,130.3947 diff = 359.899963'
});
data_peak.push({
lat: 3.1333444446e+01,
lng: 1.3051755556e+02,
cert : false,
content:' Peak = 425.899994 pos = 31.3334,130.5176 diff = 167.100006'
});
data_saddle.push({
lat: 3.1333444446e+01,
lng: 1.3050888889e+02,
content:'Saddle = 258.799988 pos = 31.3334,130.5089 diff = 167.100006'
});
data_peak.push({
lat: 3.1470555557e+01,
lng: 1.3042933333e+02,
cert : true,
content:'Name = JA6/KG-059(JA6/KG-059) peak = 531.500000 pos = 31.4706,130.4293 diff = 250.000000'
});
data_saddle.push({
lat: 3.1480333334e+01,
lng: 1.3047855556e+02,
content:'Saddle = 281.500000 pos = 31.4803,130.4786 diff = 250.000000'
});
data_peak.push({
lat: 3.1504222223e+01,
lng: 1.3046677778e+02,
cert : false,
content:' Peak = 483.799988 pos = 31.5042,130.4668 diff = 170.399994'
});
data_saddle.push({
lat: 3.1499555557e+01,
lng: 1.3042777778e+02,
content:'Saddle = 313.399994 pos = 31.4996,130.4278 diff = 170.399994'
});
data_peak.push({
lat: 3.1455222223e+01,
lng: 1.3046377778e+02,
cert : false,
content:' Peak = 588.000000 pos = 31.4552,130.4638 diff = 242.899994'
});
data_saddle.push({
lat: 3.1405111112e+01,
lng: 1.3050288889e+02,
content:'Saddle = 345.100006 pos = 31.4051,130.5029 diff = 242.899994'
});
data_peak.push({
lat: 3.1425888890e+01,
lng: 1.3047755556e+02,
cert : true,
content:'Name = JA6/KG-049(JA6/KG-049) peak = 584.500000 pos = 31.4259,130.4776 diff = 222.500000'
});
data_saddle.push({
lat: 3.1464111112e+01,
lng: 1.3048000000e+02,
content:'Saddle = 362.000000 pos = 31.4641,130.4800 diff = 222.500000'
});
data_peak.push({
lat: 3.2628666667e+01,
lng: 1.3083833333e+02,
cert : true,
content:'Name = JA6/KM-077(JA6/KM-077) peak = 390.000000 pos = 32.6287,130.8383 diff = 228.000000'
});
data_saddle.push({
lat: 3.2629333334e+01,
lng: 1.3085977778e+02,
content:'Saddle = 162.000000 pos = 32.6293,130.8598 diff = 228.000000'
});
data_peak.push({
lat: 3.2642666667e+01,
lng: 1.3085177778e+02,
cert : false,
content:' Peak = 371.200012 pos = 32.6427,130.8518 diff = 158.400009'
});
data_saddle.push({
lat: 3.2632222223e+01,
lng: 1.3084000000e+02,
content:'Saddle = 212.800003 pos = 32.6322,130.8400 diff = 158.400009'
});
data_peak.push({
lat: 3.1904666668e+01,
lng: 1.3027677778e+02,
cert : true,
content:'Name = JA6/KG-110(JA6/KG-110) peak = 364.799988 pos = 31.9047,130.2768 diff = 198.099991'
});
data_saddle.push({
lat: 3.1911444445e+01,
lng: 1.3027188889e+02,
content:'Saddle = 166.699997 pos = 31.9114,130.2719 diff = 198.099991'
});
data_peak.push({
lat: 3.1739222223e+01,
lng: 1.3029488889e+02,
cert : true,
content:'Name = JA6/KG-115(JA6/KG-115) peak = 346.799988 pos = 31.7392,130.2949 diff = 174.799988'
});
data_saddle.push({
lat: 3.1747111112e+01,
lng: 1.3031233333e+02,
content:'Saddle = 172.000000 pos = 31.7471,130.3123 diff = 174.799988'
});
data_peak.push({
lat: 3.3081555556e+01,
lng: 1.3065033333e+02,
cert : true,
content:'Name = JA6/KM-072(JA6/KM-072) peak = 407.600006 pos = 33.0816,130.6503 diff = 230.000000'
});
data_saddle.push({
lat: 3.3105555556e+01,
lng: 1.3066511111e+02,
content:'Saddle = 177.600006 pos = 33.1056,130.6651 diff = 230.000000'
});
data_peak.push({
lat: 3.3065333334e+01,
lng: 1.3068366667e+02,
cert : false,
content:' Peak = 354.399994 pos = 33.0653,130.6837 diff = 152.099991'
});
data_saddle.push({
lat: 3.3074000000e+01,
lng: 1.3066455556e+02,
content:'Saddle = 202.300003 pos = 33.0740,130.6646 diff = 152.099991'
});
data_peak.push({
lat: 3.3102555556e+01,
lng: 1.3067355556e+02,
cert : false,
content:' Peak = 397.600006 pos = 33.1026,130.6736 diff = 156.000000'
});
data_saddle.push({
lat: 3.3093111111e+01,
lng: 1.3065633333e+02,
content:'Saddle = 241.600006 pos = 33.0931,130.6563 diff = 156.000000'
});
data_peak.push({
lat: 3.1749222223e+01,
lng: 1.3033177778e+02,
cert : true,
content:'Name = Kanmuridake (Nishidake)(JA6/KG-068) peak = 512.900024 pos = 31.7492,130.3318 diff = 326.500031'
});
data_saddle.push({
lat: 3.1734111112e+01,
lng: 1.3041388889e+02,
content:'Saddle = 186.399994 pos = 31.7341,130.4139 diff = 326.500031'
});
data_peak.push({
lat: 3.1732222223e+01,
lng: 1.3035744444e+02,
cert : true,
content:'Name = JA6/KG-092(JA6/KG-092) peak = 430.299988 pos = 31.7322,130.3574 diff = 199.999985'
});
data_saddle.push({
lat: 3.1745666668e+01,
lng: 1.3038800000e+02,
content:'Saddle = 230.300003 pos = 31.7457,130.3880 diff = 199.999985'
});
data_peak.push({
lat: 3.3158222223e+01,
lng: 1.3059133333e+02,
cert : false,
content:' Peak = 461.500000 pos = 33.1582,130.5913 diff = 274.799988'
});
data_saddle.push({
lat: 3.3113111111e+01,
lng: 1.3065388889e+02,
content:'Saddle = 186.699997 pos = 33.1131,130.6539 diff = 274.799988'
});
data_peak.push({
lat: 3.2473333334e+01,
lng: 1.3094677778e+02,
cert : true,
content:'Name = Kamifukuneyama(JA6/KM-001) peak = 1640.000000 pos = 32.4733,130.9468 diff = 1444.699951'
});
data_saddle.push({
lat: 3.2305222223e+01,
lng: 1.3099988889e+02,
content:'Saddle = 195.300003 pos = 32.3052,130.9999 diff = 1444.699951'
});
data_peak.push({
lat: 3.3310000000e+01,
lng: 1.3086233333e+02,
cert : false,
content:' Peak = 404.100006 pos = 33.3100,130.8623 diff = 186.300003'
});
data_saddle.push({
lat: 3.3303555556e+01,
lng: 1.3086244444e+02,
content:'Saddle = 217.800003 pos = 33.3036,130.8624 diff = 186.300003'
});
data_peak.push({
lat: 3.3187555556e+01,
lng: 1.3088900000e+02,
cert : true,
content:'Name = Shakadake(JA6/OT-014) peak = 1230.599976 pos = 33.1876,130.8890 diff = 1001.500000'
});
data_saddle.push({
lat: 3.2645888889e+01,
lng: 1.3099977778e+02,
content:'Saddle = 229.100006 pos = 32.6459,130.9998 diff = 1001.500000'
});
data_peak.push({
lat: 3.2673222223e+01,
lng: 1.3084722222e+02,
cert : true,
content:'Name = JA6/KM-068(JA6/KM-068) peak = 461.200012 pos = 32.6732,130.8472 diff = 212.100006'
});
data_saddle.push({
lat: 3.2679444445e+01,
lng: 1.3084866667e+02,
content:'Saddle = 249.100006 pos = 32.6794,130.8487 diff = 212.100006'
});
data_peak.push({
lat: 3.3229333334e+01,
lng: 1.3099988889e+02,
cert : false,
content:' Peak = 488.700012 pos = 33.2293,130.9999 diff = 239.100006'
});
data_saddle.push({
lat: 3.3196555556e+01,
lng: 1.3099988889e+02,
content:'Saddle = 249.600006 pos = 33.1966,130.9999 diff = 239.100006'
});
data_peak.push({
lat: 3.3204555556e+01,
lng: 1.3099911111e+02,
cert : false,
content:' Peak = 486.100006 pos = 33.2046,130.9991 diff = 188.000000'
});
data_saddle.push({
lat: 3.3216444445e+01,
lng: 1.3099988889e+02,
content:'Saddle = 298.100006 pos = 33.2164,130.9999 diff = 188.000000'
});
data_peak.push({
lat: 3.3213888889e+01,
lng: 1.3099955556e+02,
cert : false,
content:' Peak = 467.899994 pos = 33.2139,130.9996 diff = 169.299988'
});
data_saddle.push({
lat: 3.3210111111e+01,
lng: 1.3099988889e+02,
content:'Saddle = 298.600006 pos = 33.2101,130.9999 diff = 169.299988'
});
data_peak.push({
lat: 3.3171333334e+01,
lng: 1.3067988889e+02,
cert : true,
content:'Name = JA6/KM-050(JA6/KM-050) peak = 594.000000 pos = 33.1713,130.6799 diff = 317.399994'
});
data_saddle.push({
lat: 3.3163333334e+01,
lng: 1.3069011111e+02,
content:'Saddle = 276.600006 pos = 33.1633,130.6901 diff = 317.399994'
});
data_peak.push({
lat: 3.2740000001e+01,
lng: 1.3082755556e+02,
cert : false,
content:' Peak = 433.899994 pos = 32.7400,130.8276 diff = 155.899994'
});
data_saddle.push({
lat: 3.2750111112e+01,
lng: 1.3084600000e+02,
content:'Saddle = 278.000000 pos = 32.7501,130.8460 diff = 155.899994'
});
data_peak.push({
lat: 3.3185000000e+01,
lng: 1.3099988889e+02,
cert : false,
content:' Peak = 453.399994 pos = 33.1850,130.9999 diff = 172.799988'
});
data_saddle.push({
lat: 3.3194444445e+01,
lng: 1.3099277778e+02,
content:'Saddle = 280.600006 pos = 33.1944,130.9928 diff = 172.799988'
});
data_peak.push({
lat: 3.3093555556e+01,
lng: 1.3072888889e+02,
cert : true,
content:'Name = JA6/KM-047(JA6/KM-047) peak = 643.299988 pos = 33.0936,130.7289 diff = 346.799988'
});
data_saddle.push({
lat: 3.3087555556e+01,
lng: 1.3074622222e+02,
content:'Saddle = 296.500000 pos = 33.0876,130.7462 diff = 346.799988'
});
data_peak.push({
lat: 3.2791222223e+01,
lng: 1.3099988889e+02,
cert : false,
content:' Peak = 1215.000000 pos = 32.7912,130.9999 diff = 895.099976'
});
data_saddle.push({
lat: 3.2855000000e+01,
lng: 1.3099977778e+02,
content:'Saddle = 319.899994 pos = 32.8550,130.9998 diff = 895.099976'
});
data_peak.push({
lat: 3.2664111112e+01,
lng: 1.3087611111e+02,
cert : true,
content:'Name = JA6/KM-039(JA6/KM-039) peak = 751.799988 pos = 32.6641,130.8761 diff = 424.399994'
});
data_saddle.push({
lat: 3.2686777778e+01,
lng: 1.3086855556e+02,
content:'Saddle = 327.399994 pos = 32.6868,130.8686 diff = 424.399994'
});
data_peak.push({
lat: 3.2657555556e+01,
lng: 1.3093933333e+02,
cert : true,
content:'Name = JA6/KM-046(JA6/KM-046) peak = 660.700012 pos = 32.6576,130.9393 diff = 205.700012'
});
data_saddle.push({
lat: 3.2661777778e+01,
lng: 1.3095311111e+02,
content:'Saddle = 455.000000 pos = 32.6618,130.9531 diff = 205.700012'
});
data_peak.push({
lat: 3.2692555556e+01,
lng: 1.3091922222e+02,
cert : true,
content:'Name = JA6/KM-038(JA6/KM-038) peak = 810.799988 pos = 32.6926,130.9192 diff = 262.299988'
});
data_saddle.push({
lat: 3.2717555556e+01,
lng: 1.3096633333e+02,
content:'Saddle = 548.500000 pos = 32.7176,130.9663 diff = 262.299988'
});
data_peak.push({
lat: 3.2838000000e+01,
lng: 1.3097022222e+02,
cert : true,
content:'Name = JA6/KM-020(JA6/KM-020) peak = 1101.300049 pos = 32.8380,130.9702 diff = 203.300049'
});
data_saddle.push({
lat: 3.2831666667e+01,
lng: 1.3097444444e+02,
content:'Saddle = 898.000000 pos = 32.8317,130.9744 diff = 203.300049'
});
data_peak.push({
lat: 3.3284777778e+01,
lng: 1.3083322222e+02,
cert : false,
content:' Peak = 614.000000 pos = 33.2848,130.8332 diff = 217.000000'
});
data_saddle.push({
lat: 3.3284777778e+01,
lng: 1.3085244444e+02,
content:'Saddle = 397.000000 pos = 33.2848,130.8524 diff = 217.000000'
});
data_peak.push({
lat: 3.3164000000e+01,
lng: 1.3099866667e+02,
cert : false,
content:' Peak = 636.099976 pos = 33.1640,130.9987 diff = 192.799988'
});
data_saddle.push({
lat: 3.3155222223e+01,
lng: 1.3099988889e+02,
content:'Saddle = 443.299988 pos = 33.1552,130.9999 diff = 192.799988'
});
data_peak.push({
lat: 3.3139777778e+01,
lng: 1.3099988889e+02,
cert : false,
content:' Peak = 736.700012 pos = 33.1398,130.9999 diff = 290.600006'
});
data_saddle.push({
lat: 3.3126888889e+01,
lng: 1.3099988889e+02,
content:'Saddle = 446.100006 pos = 33.1269,130.9999 diff = 290.600006'
});
data_peak.push({
lat: 3.3146111111e+01,
lng: 1.3081522222e+02,
cert : false,
content:' Peak = 641.099976 pos = 33.1461,130.8152 diff = 159.799988'
});
data_saddle.push({
lat: 3.3139666667e+01,
lng: 1.3082300000e+02,
content:'Saddle = 481.299988 pos = 33.1397,130.8230 diff = 159.799988'
});
data_peak.push({
lat: 3.3098555556e+01,
lng: 1.3099988889e+02,
cert : false,
content:' Peak = 780.299988 pos = 33.0986,130.9999 diff = 257.799988'
});
data_saddle.push({
lat: 3.3073000000e+01,
lng: 1.3099988889e+02,
content:'Saddle = 522.500000 pos = 33.0730,130.9999 diff = 257.799988'
});
data_peak.push({
lat: 3.3090666667e+01,
lng: 1.3099855556e+02,
cert : false,
content:' Peak = 740.400024 pos = 33.0907,130.9986 diff = 186.600037'
});
data_saddle.push({
lat: 3.3093555556e+01,
lng: 1.3099977778e+02,
content:'Saddle = 553.799988 pos = 33.0936,130.9998 diff = 186.600037'
});
data_peak.push({
lat: 3.3303000000e+01,
lng: 1.3072277778e+02,
cert : true,
content:'Name = Takatoriyama(JA6/FO-009) peak = 802.799988 pos = 33.3030,130.7228 diff = 271.399963'
});
data_saddle.push({
lat: 3.3280000000e+01,
lng: 1.3074588889e+02,
content:'Saddle = 531.400024 pos = 33.2800,130.7459 diff = 271.399963'
});
data_peak.push({
lat: 3.3157000000e+01,
lng: 1.3077066667e+02,
cert : true,
content:'Name = JA6/FO-007(JA6/FO-007) peak = 840.700012 pos = 33.1570,130.7707 diff = 282.400024'
});
data_saddle.push({
lat: 3.3134666667e+01,
lng: 1.3076966667e+02,
content:'Saddle = 558.299988 pos = 33.1347,130.7697 diff = 282.400024'
});
data_peak.push({
lat: 3.3196333334e+01,
lng: 1.3078744444e+02,
cert : true,
content:'Name = JA6/FO-003(JA6/FO-003) peak = 942.500000 pos = 33.1963,130.7874 diff = 344.599976'
});
data_saddle.push({
lat: 3.3197333334e+01,
lng: 1.3080688889e+02,
content:'Saddle = 597.900024 pos = 33.1973,130.8069 diff = 344.599976'
});
data_peak.push({
lat: 3.2898555556e+01,
lng: 1.3097744444e+02,
cert : true,
content:'Name = JA6/KM-035(JA6/KM-035) peak = 860.500000 pos = 32.8986,130.9774 diff = 203.700012'
});
data_saddle.push({
lat: 3.2911777778e+01,
lng: 1.3096811111e+02,
content:'Saddle = 656.799988 pos = 32.9118,130.9681 diff = 203.700012'
});
data_peak.push({
lat: 3.2953444445e+01,
lng: 1.3093388889e+02,
cert : true,
content:'Name = JA6/KM-018(JA6/KM-018) peak = 1115.000000 pos = 32.9534,130.9339 diff = 437.000000'
});
data_saddle.push({
lat: 3.3065222223e+01,
lng: 1.3090622222e+02,
content:'Saddle = 678.000000 pos = 33.0652,130.9062 diff = 437.000000'
});
data_peak.push({
lat: 3.3052333334e+01,
lng: 1.3093722222e+02,
cert : true,
content:'Name = JA6/KM-025(JA6/KM-025) peak = 1015.299988 pos = 33.0523,130.9372 diff = 193.899963'
});
data_saddle.push({
lat: 3.3032444445e+01,
lng: 1.3098422222e+02,
content:'Saddle = 821.400024 pos = 33.0324,130.9842 diff = 193.899963'
});
data_peak.push({
lat: 3.3026444445e+01,
lng: 1.3099388889e+02,
cert : false,
content:' Peak = 1040.599976 pos = 33.0264,130.9939 diff = 188.599976'
});
data_saddle.push({
lat: 3.2994222223e+01,
lng: 1.3099977778e+02,
content:'Saddle = 852.000000 pos = 32.9942,130.9998 diff = 188.599976'
});
data_peak.push({
lat: 3.3097000000e+01,
lng: 1.3090833333e+02,
cert : true,
content:'Name = Shyutendoujiyama(JA6/OT-017) peak = 1180.300049 pos = 33.0970,130.9083 diff = 497.900024'
});
data_saddle.push({
lat: 3.3090888889e+01,
lng: 1.3086833333e+02,
content:'Saddle = 682.400024 pos = 33.0909,130.8683 diff = 497.900024'
});
data_peak.push({
lat: 3.3070333334e+01,
lng: 1.3083466667e+02,
cert : true,
content:'Name = JA6/KM-021(JA6/KM-021) peak = 1051.199951 pos = 33.0703,130.8347 diff = 304.399963'
});
data_saddle.push({
lat: 3.3137333334e+01,
lng: 1.3086888889e+02,
content:'Saddle = 746.799988 pos = 33.1373,130.8689 diff = 304.399963'
});
data_peak.push({
lat: 3.3105444445e+01,
lng: 1.3081744444e+02,
cert : true,
content:'Name = Kunimiyama(JA6/KM-023) peak = 1016.000000 pos = 33.1054,130.8174 diff = 262.000000'
});
data_saddle.push({
lat: 3.3085555556e+01,
lng: 1.3084077778e+02,
content:'Saddle = 754.000000 pos = 33.0856,130.8408 diff = 262.000000'
});
data_peak.push({
lat: 3.3172333334e+01,
lng: 1.3092788889e+02,
cert : true,
content:'Name = JA6/OT-019(JA6/OT-019) peak = 1150.099976 pos = 33.1723,130.9279 diff = 236.500000'
});
data_saddle.push({
lat: 3.3181777778e+01,
lng: 1.3092266667e+02,
content:'Saddle = 913.599976 pos = 33.1818,130.9227 diff = 236.500000'
});
data_peak.push({
lat: 3.2584888889e+01,
lng: 1.3077766667e+02,
cert : true,
content:'Name = JA6/KM-053(JA6/KM-053) peak = 562.500000 pos = 32.5849,130.7777 diff = 324.700012'
});
data_saddle.push({
lat: 3.2575333334e+01,
lng: 1.3079822222e+02,
content:'Saddle = 237.800003 pos = 32.5753,130.7982 diff = 324.700012'
});
data_peak.push({
lat: 3.2563000001e+01,
lng: 1.3075188889e+02,
cert : false,
content:' Peak = 477.100006 pos = 32.5630,130.7519 diff = 181.399994'
});
data_saddle.push({
lat: 3.2573000001e+01,
lng: 1.3075844444e+02,
content:'Saddle = 295.700012 pos = 32.5730,130.7584 diff = 181.399994'
});
data_peak.push({
lat: 3.2527666667e+01,
lng: 1.3068644444e+02,
cert : true,
content:'Name = JA6/KM-055(JA6/KM-055) peak = 541.299988 pos = 32.5277,130.6864 diff = 283.599976'
});
data_saddle.push({
lat: 3.2520555556e+01,
lng: 1.3068755556e+02,
content:'Saddle = 257.700012 pos = 32.5206,130.6876 diff = 283.599976'
});
data_peak.push({
lat: 3.2278333334e+01,
lng: 1.3063677778e+02,
cert : true,
content:'Name = JA6/KM-042(JA6/KM-042) peak = 700.900024 pos = 32.2783,130.6368 diff = 192.800018'
});
data_saddle.push({
lat: 3.2283333334e+01,
lng: 1.3062200000e+02,
content:'Saddle = 508.100006 pos = 32.2833,130.6220 diff = 192.800018'
});
data_peak.push({
lat: 3.2612777778e+01,
lng: 1.3099988889e+02,
cert : false,
content:' Peak = 670.099976 pos = 32.6128,130.9999 diff = 155.699951'
});
data_saddle.push({
lat: 3.2606555556e+01,
lng: 1.3099988889e+02,
content:'Saddle = 514.400024 pos = 32.6066,130.9999 diff = 155.699951'
});
data_peak.push({
lat: 3.2550000001e+01,
lng: 1.3079100000e+02,
cert : false,
content:' Peak = 870.799988 pos = 32.5500,130.7910 diff = 303.399963'
});
data_saddle.push({
lat: 3.2543222223e+01,
lng: 1.3078844444e+02,
content:'Saddle = 567.400024 pos = 32.5432,130.7884 diff = 303.399963'
});
data_peak.push({
lat: 3.2605444445e+01,
lng: 1.3090177778e+02,
cert : false,
content:' Peak = 837.599976 pos = 32.6054,130.9018 diff = 174.099976'
});
data_saddle.push({
lat: 3.2601888889e+01,
lng: 1.3090300000e+02,
content:'Saddle = 663.500000 pos = 32.6019,130.9030 diff = 174.099976'
});
data_peak.push({
lat: 3.2320777778e+01,
lng: 1.3066933333e+02,
cert : true,
content:'Name = JA6/KM-030(JA6/KM-030) peak = 927.200012 pos = 32.3208,130.6693 diff = 257.299988'
});
data_saddle.push({
lat: 3.2327888890e+01,
lng: 1.3066988889e+02,
content:'Saddle = 669.900024 pos = 32.3279,130.6699 diff = 257.299988'
});
data_peak.push({
lat: 3.2306888890e+01,
lng: 1.3067655556e+02,
cert : true,
content:'Name = JA6/KM-033(JA6/KM-033) peak = 893.299988 pos = 32.3069,130.6766 diff = 215.599976'
});
data_saddle.push({
lat: 3.2311777778e+01,
lng: 1.3067155556e+02,
content:'Saddle = 677.700012 pos = 32.3118,130.6716 diff = 215.599976'
});
data_peak.push({
lat: 3.2371444445e+01,
lng: 1.3077766667e+02,
cert : true,
content:'Name = Nokeeboshiyama(JA6/KM-009) peak = 1301.199951 pos = 32.3714,130.7777 diff = 597.399963'
});
data_saddle.push({
lat: 3.2452333334e+01,
lng: 1.3073055556e+02,
content:'Saddle = 703.799988 pos = 32.4523,130.7306 diff = 597.399963'
});
data_peak.push({
lat: 3.2325333334e+01,
lng: 1.3071566667e+02,
cert : false,
content:' Peak = 1020.400024 pos = 32.3253,130.7157 diff = 237.900024'
});
data_saddle.push({
lat: 3.2330111112e+01,
lng: 1.3070188889e+02,
content:'Saddle = 782.500000 pos = 32.3301,130.7019 diff = 237.900024'
});
data_peak.push({
lat: 3.2370222223e+01,
lng: 1.3071122222e+02,
cert : true,
content:'Name = JA6/KM-022(JA6/KM-022) peak = 1033.800049 pos = 32.3702,130.7112 diff = 236.600037'
});
data_saddle.push({
lat: 3.2383333334e+01,
lng: 1.3071977778e+02,
content:'Saddle = 797.200012 pos = 32.3833,130.7198 diff = 236.600037'
});
data_peak.push({
lat: 3.2345444445e+01,
lng: 1.3069811111e+02,
cert : true,
content:'Name = JA6/KM-027(JA6/KM-027) peak = 984.000000 pos = 32.3454,130.6981 diff = 172.000000'
});
data_saddle.push({
lat: 3.2356111112e+01,
lng: 1.3070077778e+02,
content:'Saddle = 812.000000 pos = 32.3561,130.7008 diff = 172.000000'
});
data_peak.push({
lat: 3.2425222223e+01,
lng: 1.3076733333e+02,
cert : true,
content:'Name = JA6/KM-026(JA6/KM-026) peak = 991.400024 pos = 32.4252,130.7673 diff = 178.900024'
});
data_saddle.push({
lat: 3.2413777778e+01,
lng: 1.3074344444e+02,
content:'Saddle = 812.500000 pos = 32.4138,130.7434 diff = 178.900024'
});
data_peak.push({
lat: 3.2387000001e+01,
lng: 1.3074055556e+02,
cert : false,
content:' Peak = 1154.699951 pos = 32.3870,130.7406 diff = 166.099976'
});
data_saddle.push({
lat: 3.2383777778e+01,
lng: 1.3077222222e+02,
content:'Saddle = 988.599976 pos = 32.3838,130.7722 diff = 166.099976'
});
data_peak.push({
lat: 3.2468666667e+01,
lng: 1.3075155556e+02,
cert : true,
content:'Name = JA6/KM-028(JA6/KM-028) peak = 972.799988 pos = 32.4687,130.7516 diff = 195.599976'
});
data_saddle.push({
lat: 3.2478888889e+01,
lng: 1.3076022222e+02,
content:'Saddle = 777.200012 pos = 32.4789,130.7602 diff = 195.599976'
});
data_peak.push({
lat: 3.2568777778e+01,
lng: 1.3099777778e+02,
cert : false,
content:' Peak = 1562.300049 pos = 32.5688,130.9978 diff = 633.500061'
});
data_saddle.push({
lat: 3.2529555556e+01,
lng: 1.3099988889e+02,
content:'Saddle = 928.799988 pos = 32.5296,130.9999 diff = 633.500061'
});
data_peak.push({
lat: 3.2435333334e+01,
lng: 1.3081877778e+02,
cert : false,
content:' Peak = 1270.199951 pos = 32.4353,130.8188 diff = 317.999939'
});
data_saddle.push({
lat: 3.2518555556e+01,
lng: 1.3084477778e+02,
content:'Saddle = 952.200012 pos = 32.5186,130.8448 diff = 317.999939'
});
data_peak.push({
lat: 3.2494111112e+01,
lng: 1.3080811111e+02,
cert : true,
content:'Name = JA6/KM-016(JA6/KM-016) peak = 1147.699951 pos = 32.4941,130.8081 diff = 181.799927'
});
data_saddle.push({
lat: 3.2471111112e+01,
lng: 1.3081222222e+02,
content:'Saddle = 965.900024 pos = 32.4711,130.8122 diff = 181.799927'
});
data_peak.push({
lat: 3.2454888890e+01,
lng: 1.3081933333e+02,
cert : true,
content:'Name = JA6/KM-011(JA6/KM-011) peak = 1243.699951 pos = 32.4549,130.8193 diff = 170.599976'
});
data_saddle.push({
lat: 3.2440555556e+01,
lng: 1.3081600000e+02,
content:'Saddle = 1073.099976 pos = 32.4406,130.8160 diff = 170.599976'
});
data_peak.push({
lat: 3.2506111112e+01,
lng: 1.3088188889e+02,
cert : false,
content:' Peak = 1282.599976 pos = 32.5061,130.8819 diff = 269.899963'
});
data_saddle.push({
lat: 3.2532444445e+01,
lng: 1.3087366667e+02,
content:'Saddle = 1012.700012 pos = 32.5324,130.8737 diff = 269.899963'
});
data_peak.push({
lat: 3.2531333334e+01,
lng: 1.3092333333e+02,
cert : false,
content:' Peak = 1398.300049 pos = 32.5313,130.9233 diff = 327.200073'
});
data_saddle.push({
lat: 3.2568444445e+01,
lng: 1.3090911111e+02,
content:'Saddle = 1071.099976 pos = 32.5684,130.9091 diff = 327.200073'
});
data_peak.push({
lat: 3.2603444445e+01,
lng: 1.3096766667e+02,
cert : true,
content:'Name = JA6/KM-006(JA6/KM-006) peak = 1347.900024 pos = 32.6034,130.9677 diff = 210.900024'
});
data_saddle.push({
lat: 3.2594888889e+01,
lng: 1.3095833333e+02,
content:'Saddle = 1137.000000 pos = 32.5949,130.9583 diff = 210.900024'
});
data_peak.push({
lat: 3.2546555556e+01,
lng: 1.3099988889e+02,
cert : false,
content:' Peak = 1345.500000 pos = 32.5466,130.9999 diff = 151.599976'
});
data_saddle.push({
lat: 3.2550111112e+01,
lng: 1.3099977778e+02,
content:'Saddle = 1193.900024 pos = 32.5501,130.9998 diff = 151.599976'
});
data_peak.push({
lat: 3.2563777778e+01,
lng: 1.3092566667e+02,
cert : false,
content:' Peak = 1371.099976 pos = 32.5638,130.9257 diff = 159.199951'
});
data_saddle.push({
lat: 3.2573777778e+01,
lng: 1.3092466667e+02,
content:'Saddle = 1211.900024 pos = 32.5738,130.9247 diff = 159.199951'
});
data_peak.push({
lat: 3.2366666667e+01,
lng: 1.3091488889e+02,
cert : true,
content:'Name = JA6/KM-013(JA6/KM-013) peak = 1221.500000 pos = 32.3667,130.9149 diff = 188.900024'
});
data_saddle.push({
lat: 3.2354222223e+01,
lng: 1.3093977778e+02,
content:'Saddle = 1032.599976 pos = 32.3542,130.9398 diff = 188.900024'
});
data_peak.push({
lat: 3.2516555556e+01,
lng: 1.3099966667e+02,
cert : false,
content:' Peak = 1493.400024 pos = 32.5166,130.9997 diff = 385.500000'
});
data_saddle.push({
lat: 3.2485666667e+01,
lng: 1.3099988889e+02,
content:'Saddle = 1107.900024 pos = 32.4857,130.9999 diff = 385.500000'
});
data_peak.push({
lat: 3.2503666667e+01,
lng: 1.3099988889e+02,
cert : false,
content:' Peak = 1482.900024 pos = 32.5037,130.9999 diff = 295.400024'
});
data_saddle.push({
lat: 3.2510333334e+01,
lng: 1.3099988889e+02,
content:'Saddle = 1187.500000 pos = 32.5103,130.9999 diff = 295.400024'
});
data_peak.push({
lat: 3.2462888890e+01,
lng: 1.3099988889e+02,
cert : false,
content:' Peak = 1547.300049 pos = 32.4629,130.9999 diff = 192.100098'
});
data_saddle.push({
lat: 3.2458000001e+01,
lng: 1.3099988889e+02,
content:'Saddle = 1355.199951 pos = 32.4580,130.9999 diff = 192.100098'
});
data_peak.push({
lat: 3.1734555556e+01,
lng: 1.3044833333e+02,
cert : true,
content:'Name = Yaeyama(JA6/KG-032) peak = 676.400024 pos = 31.7346,130.4483 diff = 481.000031'
});
data_saddle.push({
lat: 3.1766444445e+01,
lng: 1.3049222222e+02,
content:'Saddle = 195.399994 pos = 31.7664,130.4922 diff = 481.000031'
});
data_peak.push({
lat: 3.1737000001e+01,
lng: 1.3053155556e+02,
cert : true,
content:'Name = JA6/KG-111(JA6/KG-111) peak = 360.600006 pos = 31.7370,130.5316 diff = 162.500000'
});
data_saddle.push({
lat: 3.1739888890e+01,
lng: 1.3052488889e+02,
content:'Saddle = 198.100006 pos = 31.7399,130.5249 diff = 162.500000'
});
data_peak.push({
lat: 3.1701222223e+01,
lng: 1.3038166667e+02,
cert : false,
content:' Peak = 371.600006 pos = 31.7012,130.3817 diff = 163.500000'
});
data_saddle.push({
lat: 3.1714444445e+01,
lng: 1.3039533333e+02,
content:'Saddle = 208.100006 pos = 31.7144,130.3953 diff = 163.500000'
});
data_peak.push({
lat: 3.1745777779e+01,
lng: 1.3051377778e+02,
cert : true,
content:'Name = JA6/KG-088(JA6/KG-088) peak = 434.299988 pos = 31.7458,130.5138 diff = 212.099991'
});
data_saddle.push({
lat: 3.1742333334e+01,
lng: 1.3051077778e+02,
content:'Saddle = 222.199997 pos = 31.7423,130.5108 diff = 212.099991'
});
data_peak.push({
lat: 3.1697333334e+01,
lng: 1.3058288889e+02,
cert : false,
content:' Peak = 580.900024 pos = 31.6973,130.5829 diff = 356.100037'
});
data_saddle.push({
lat: 3.1687222223e+01,
lng: 1.3056177778e+02,
content:'Saddle = 224.800003 pos = 31.6872,130.5618 diff = 356.100037'
});
data_peak.push({
lat: 3.1690333334e+01,
lng: 1.3052100000e+02,
cert : true,
content:'Name = JA6/KG-074(JA6/KG-074) peak = 484.399994 pos = 31.6903,130.5210 diff = 241.599991'
});
data_saddle.push({
lat: 3.1700777779e+01,
lng: 1.3052266667e+02,
content:'Saddle = 242.800003 pos = 31.7008,130.5227 diff = 241.599991'
});
data_peak.push({
lat: 3.1699333334e+01,
lng: 1.3042033333e+02,
cert : true,
content:'Name = JA6/KG-065(JA6/KG-065) peak = 522.500000 pos = 31.6993,130.4203 diff = 255.399994'
});
data_saddle.push({
lat: 3.1716111112e+01,
lng: 1.3042688889e+02,
content:'Saddle = 267.100006 pos = 31.7161,130.4269 diff = 255.399994'
});
data_peak.push({
lat: 3.1720111112e+01,
lng: 1.3051166667e+02,
cert : false,
content:' Peak = 542.500000 pos = 31.7201,130.5117 diff = 234.100006'
});
data_saddle.push({
lat: 3.1724777779e+01,
lng: 1.3049444444e+02,
content:'Saddle = 308.399994 pos = 31.7248,130.4944 diff = 234.100006'
});
data_peak.push({
lat: 3.1749111112e+01,
lng: 1.3048744444e+02,
cert : true,
content:'Name = JA6/KG-055(JA6/KG-055) peak = 543.000000 pos = 31.7491,130.4874 diff = 200.500000'
});
data_saddle.push({
lat: 3.1742111112e+01,
lng: 1.3048066667e+02,
content:'Saddle = 342.500000 pos = 31.7421,130.4807 diff = 200.500000'
});
data_peak.push({
lat: 3.1822555556e+01,
lng: 1.3046111111e+02,
cert : true,
content:'Name = JA6/KG-070(JA6/KG-070) peak = 504.000000 pos = 31.8226,130.4611 diff = 302.500000'
});
data_saddle.push({
lat: 3.1823888890e+01,
lng: 1.3049477778e+02,
content:'Saddle = 201.500000 pos = 31.8239,130.4948 diff = 302.500000'
});
data_peak.push({
lat: 3.1837000001e+01,
lng: 1.3049555556e+02,
cert : true,
content:'Name = JA6/KG-087(JA6/KG-087) peak = 441.600006 pos = 31.8370,130.4956 diff = 239.700012'
});
data_saddle.push({
lat: 3.1826666668e+01,
lng: 1.3048922222e+02,
content:'Saddle = 201.899994 pos = 31.8267,130.4892 diff = 239.700012'
});
data_peak.push({
lat: 3.1776666668e+01,
lng: 1.3051366667e+02,
cert : true,
content:'Name = JA6/KG-095(JA6/KG-095) peak = 421.200012 pos = 31.7767,130.5137 diff = 184.500015'
});
data_saddle.push({
lat: 3.1779000001e+01,
lng: 1.3051122222e+02,
content:'Saddle = 236.699997 pos = 31.7790,130.5112 diff = 184.500015'
});
data_peak.push({
lat: 3.1874888890e+01,
lng: 1.3060600000e+02,
cert : true,
content:'Name = JA6/KG-028(JA6/KG-028) peak = 702.099976 pos = 31.8749,130.6060 diff = 464.499969'
});
data_saddle.push({
lat: 3.1925555556e+01,
lng: 1.3072577778e+02,
content:'Saddle = 237.600006 pos = 31.9256,130.7258 diff = 464.499969'
});
data_peak.push({
lat: 3.1766222223e+01,
lng: 1.3050877778e+02,
cert : true,
content:'Name = JA6/KG-079(JA6/KG-079) peak = 474.200012 pos = 31.7662,130.5088 diff = 236.400009'
});
data_saddle.push({
lat: 3.1807333334e+01,
lng: 1.3050977778e+02,
content:'Saddle = 237.800003 pos = 31.8073,130.5098 diff = 236.400009'
});
data_peak.push({
lat: 3.1788111112e+01,
lng: 1.3051200000e+02,
cert : false,
content:' Peak = 401.899994 pos = 31.7881,130.5120 diff = 150.299988'
});
data_saddle.push({
lat: 3.1789444445e+01,
lng: 1.3050811111e+02,
content:'Saddle = 251.600006 pos = 31.7894,130.5081 diff = 150.299988'
});
data_peak.push({
lat: 3.1785111112e+01,
lng: 1.3049211111e+02,
cert : false,
content:' Peak = 423.500000 pos = 31.7851,130.4921 diff = 161.200012'
});
data_saddle.push({
lat: 3.1784666668e+01,
lng: 1.3049633333e+02,
content:'Saddle = 262.299988 pos = 31.7847,130.4963 diff = 161.200012'
});
data_peak.push({
lat: 3.1794000001e+01,
lng: 1.3050766667e+02,
cert : false,
content:' Peak = 453.700012 pos = 31.7940,130.5077 diff = 151.000000'
});
data_saddle.push({
lat: 3.1779000001e+01,
lng: 1.3050288889e+02,
content:'Saddle = 302.700012 pos = 31.7790,130.5029 diff = 151.000000'
});
data_peak.push({
lat: 3.1989000001e+01,
lng: 1.3054177778e+02,
cert : true,
content:'Name = JA6/KG-089(JA6/KG-089) peak = 436.299988 pos = 31.9890,130.5418 diff = 187.999985'
});
data_saddle.push({
lat: 3.1962222223e+01,
lng: 1.3055233333e+02,
content:'Saddle = 248.300003 pos = 31.9622,130.5523 diff = 187.999985'
});
data_peak.push({
lat: 3.1808888890e+01,
lng: 1.3051466667e+02,
cert : false,
content:' Peak = 421.500000 pos = 31.8089,130.5147 diff = 164.700012'
});
data_saddle.push({
lat: 3.1818333334e+01,
lng: 1.3051144444e+02,
content:'Saddle = 256.799988 pos = 31.8183,130.5114 diff = 164.700012'
});
data_peak.push({
lat: 3.1833888890e+01,
lng: 1.3053511111e+02,
cert : false,
content:' Peak = 515.099976 pos = 31.8339,130.5351 diff = 217.099976'
});
data_saddle.push({
lat: 3.1847111112e+01,
lng: 1.3054333333e+02,
content:'Saddle = 298.000000 pos = 31.8471,130.5433 diff = 217.099976'
});
data_peak.push({
lat: 3.1927888890e+01,
lng: 1.3063677778e+02,
cert : true,
content:'Name = JA6/KG-037(JA6/KG-037) peak = 647.900024 pos = 31.9279,130.6368 diff = 300.400024'
});
data_saddle.push({
lat: 3.1898111112e+01,
lng: 1.3062755556e+02,
content:'Saddle = 347.500000 pos = 31.8981,130.6276 diff = 300.400024'
});
data_peak.push({
lat: 3.1909888890e+01,
lng: 1.3060622222e+02,
cert : true,
content:'Name = Chayagaoka(JA6/KG-054) peak = 564.000000 pos = 31.9099,130.6062 diff = 186.799988'
});
data_saddle.push({
lat: 3.1887222223e+01,
lng: 1.3062188889e+02,
content:'Saddle = 377.200012 pos = 31.8872,130.6219 diff = 186.799988'
});
data_peak.push({
lat: 3.1902555556e+01,
lng: 1.3058233333e+02,
cert : false,
content:' Peak = 650.700012 pos = 31.9026,130.5823 diff = 217.900024'
});
data_saddle.push({
lat: 3.1898444445e+01,
lng: 1.3058233333e+02,
content:'Saddle = 432.799988 pos = 31.8984,130.5823 diff = 217.900024'
});
data_peak.push({
lat: 3.1856666668e+01,
lng: 1.3057488889e+02,
cert : false,
content:' Peak = 665.299988 pos = 31.8567,130.5749 diff = 187.599976'
});
data_saddle.push({
lat: 3.1872222223e+01,
lng: 1.3057566667e+02,
content:'Saddle = 477.700012 pos = 31.8722,130.5757 diff = 187.599976'
});
data_peak.push({
lat: 3.1846444445e+01,
lng: 1.3063466667e+02,
cert : true,
content:'Name = JA6/KG-031(JA6/KG-031) peak = 681.099976 pos = 31.8464,130.6347 diff = 168.399963'
});
data_saddle.push({
lat: 3.1866888890e+01,
lng: 1.3061700000e+02,
content:'Saddle = 512.700012 pos = 31.8669,130.6170 diff = 168.399963'
});
data_peak.push({
lat: 3.1891888890e+01,
lng: 1.3036500000e+02,
cert : false,
content:' Peak = 431.399994 pos = 31.8919,130.3650 diff = 161.899994'
});
data_saddle.push({
lat: 3.1914666668e+01,
lng: 1.3037344444e+02,
content:'Saddle = 269.500000 pos = 31.9147,130.3734 diff = 161.899994'
});
data_peak.push({
lat: 3.2257777778e+01,
lng: 1.3099933333e+02,
cert : false,
content:' Peak = 557.500000 pos = 32.2578,130.9993 diff = 250.399994'
});
data_saddle.push({
lat: 3.2250777778e+01,
lng: 1.3099988889e+02,
content:'Saddle = 307.100006 pos = 32.2508,130.9999 diff = 250.399994'
});
data_peak.push({
lat: 3.2150444445e+01,
lng: 1.3094333333e+02,
cert : true,
content:'Name = Shiragadake(JA6/KM-004) peak = 1416.400024 pos = 32.1504,130.9433 diff = 1105.300049'
});
data_saddle.push({
lat: 3.2014555556e+01,
lng: 1.3090477778e+02,
content:'Saddle = 311.100006 pos = 32.0146,130.9048 diff = 1105.300049'
});
data_peak.push({
lat: 3.2123000001e+01,
lng: 1.3040066667e+02,
cert : true,
content:'Name = Yahazudake(JA6/KG-030) peak = 684.400024 pos = 32.1230,130.4007 diff = 346.100037'
});
data_saddle.push({
lat: 3.2117888890e+01,
lng: 1.3041600000e+02,
content:'Saddle = 338.299988 pos = 32.1179,130.4160 diff = 346.100037'
});
data_peak.push({
lat: 3.2181666667e+01,
lng: 1.3049444444e+02,
cert : false,
content:' Peak = 543.500000 pos = 32.1817,130.4944 diff = 172.000000'
});
data_saddle.push({
lat: 3.2188777779e+01,
lng: 1.3050622222e+02,
content:'Saddle = 371.500000 pos = 32.1888,130.5062 diff = 172.000000'
});
data_peak.push({
lat: 3.1980888890e+01,
lng: 1.3036755556e+02,
cert : true,
content:'Name = Shibisan (Jyougusan)(JA6/KG-010) peak = 1066.300049 pos = 31.9809,130.3676 diff = 677.900024'
});
data_saddle.push({
lat: 3.2011333334e+01,
lng: 1.3044066667e+02,
content:'Saddle = 388.399994 pos = 32.0113,130.4407 diff = 677.900024'
});
data_peak.push({
lat: 3.2031000001e+01,
lng: 1.3039800000e+02,
cert : false,
content:' Peak = 552.200012 pos = 32.0310,130.3980 diff = 150.300018'
});
data_saddle.push({
lat: 3.2013666667e+01,
lng: 1.3040900000e+02,
content:'Saddle = 401.899994 pos = 32.0137,130.4090 diff = 150.300018'
});
data_peak.push({
lat: 3.1967444445e+01,
lng: 1.3026788889e+02,
cert : true,
content:'Name = JA6/KG-046(JA6/KG-046) peak = 603.500000 pos = 31.9674,130.2679 diff = 190.399994'
});
data_saddle.push({
lat: 3.1955000001e+01,
lng: 1.3028400000e+02,
content:'Saddle = 413.100006 pos = 31.9550,130.2840 diff = 190.399994'
});
data_peak.push({
lat: 3.1944888890e+01,
lng: 1.3034211111e+02,
cert : false,
content:' Peak = 682.400024 pos = 31.9449,130.3421 diff = 150.300049'
});
data_saddle.push({
lat: 3.1954333334e+01,
lng: 1.3034488889e+02,
content:'Saddle = 532.099976 pos = 31.9543,130.3449 diff = 150.300049'
});
data_peak.push({
lat: 3.2071555556e+01,
lng: 1.3049033333e+02,
cert : true,
content:'Name = JA6/KG-053(JA6/KG-053) peak = 570.799988 pos = 32.0716,130.4903 diff = 162.399994'
});
data_saddle.push({
lat: 3.2057666667e+01,
lng: 1.3049400000e+02,
content:'Saddle = 408.399994 pos = 32.0577,130.4940 diff = 162.399994'
});
data_peak.push({
lat: 3.2206000001e+01,
lng: 1.3048244444e+02,
cert : true,
content:'Name = JA6/KM-049(JA6/KM-049) peak = 608.000000 pos = 32.2060,130.4824 diff = 194.500000'
});
data_saddle.push({
lat: 3.2203333334e+01,
lng: 1.3050822222e+02,
content:'Saddle = 413.500000 pos = 32.2033,130.5082 diff = 194.500000'
});
data_peak.push({
lat: 3.2043777779e+01,
lng: 1.3045944444e+02,
cert : false,
content:' Peak = 590.000000 pos = 32.0438,130.4594 diff = 168.899994'
});
data_saddle.push({
lat: 3.2053777779e+01,
lng: 1.3049800000e+02,
content:'Saddle = 421.100006 pos = 32.0538,130.4980 diff = 168.899994'
});
data_peak.push({
lat: 3.2113777779e+01,
lng: 1.3042888889e+02,
cert : true,
content:'Name = JA6/KG-034(JA6/KG-034) peak = 663.000000 pos = 32.1138,130.4289 diff = 228.500000'
});
data_saddle.push({
lat: 3.2114777779e+01,
lng: 1.3045233333e+02,
content:'Saddle = 434.500000 pos = 32.1148,130.4523 diff = 228.500000'
});
data_peak.push({
lat: 3.2020111112e+01,
lng: 1.3071744444e+02,
cert : true,
content:'Name = JA6/KG-042(JA6/KG-042) peak = 613.099976 pos = 32.0201,130.7174 diff = 160.499969'
});
data_saddle.push({
lat: 3.2056666667e+01,
lng: 1.3072044444e+02,
content:'Saddle = 452.600006 pos = 32.0567,130.7204 diff = 160.499969'
});
data_peak.push({
lat: 3.2135777779e+01,
lng: 1.3046355556e+02,
cert : true,
content:'Name = JA6/KM-041(JA6/KM-041) peak = 734.099976 pos = 32.1358,130.4636 diff = 253.199982'
});
data_saddle.push({
lat: 3.2142222223e+01,
lng: 1.3054066667e+02,
content:'Saddle = 480.899994 pos = 32.1422,130.5407 diff = 253.199982'
});
data_peak.push({
lat: 3.2068444445e+01,
lng: 1.3086788889e+02,
cert : true,
content:'Name = JA6/MZ-090(JA6/MZ-090) peak = 704.000000 pos = 32.0684,130.8679 diff = 182.000000'
});
data_saddle.push({
lat: 3.2077222223e+01,
lng: 1.3085455556e+02,
content:'Saddle = 522.000000 pos = 32.0772,130.8546 diff = 182.000000'
});
data_peak.push({
lat: 3.2154888890e+01,
lng: 1.3058255556e+02,
cert : true,
content:'Name = JA6/KG-022(JA6/KG-022) peak = 842.799988 pos = 32.1549,130.5826 diff = 280.799988'
});
data_saddle.push({
lat: 3.2173666667e+01,
lng: 1.3059366667e+02,
content:'Saddle = 562.000000 pos = 32.1737,130.5937 diff = 280.799988'
});
data_peak.push({
lat: 3.2243222223e+01,
lng: 1.3099988889e+02,
cert : false,
content:' Peak = 738.799988 pos = 32.2432,130.9999 diff = 155.500000'
});
data_saddle.push({
lat: 3.2239444445e+01,
lng: 1.3099988889e+02,
content:'Saddle = 583.299988 pos = 32.2394,130.9999 diff = 155.500000'
});
data_peak.push({
lat: 3.2150000001e+01,
lng: 1.3062066667e+02,
cert : true,
content:'Name = JA6/KG-011(JA6/KG-011) peak = 1002.400024 pos = 32.1500,130.6207 diff = 360.500000'
});
data_saddle.push({
lat: 3.2085666667e+01,
lng: 1.3075077778e+02,
content:'Saddle = 641.900024 pos = 32.0857,130.7508 diff = 360.500000'
});
data_peak.push({
lat: 3.2110222223e+01,
lng: 1.3075566667e+02,
cert : false,
content:' Peak = 842.000000 pos = 32.1102,130.7557 diff = 173.900024'
});
data_saddle.push({
lat: 3.2087222223e+01,
lng: 1.3074844444e+02,
content:'Saddle = 668.099976 pos = 32.0872,130.7484 diff = 173.900024'
});
data_peak.push({
lat: 3.2187888890e+01,
lng: 1.3061411111e+02,
cert : true,
content:'Name = Kunimiyama(JA6/KM-029) peak = 968.700012 pos = 32.1879,130.6141 diff = 295.600037'
});
data_saddle.push({
lat: 3.2171222223e+01,
lng: 1.3061666667e+02,
content:'Saddle = 673.099976 pos = 32.1712,130.6167 diff = 295.600037'
});
data_peak.push({
lat: 3.2197222223e+01,
lng: 1.3055533333e+02,
cert : true,
content:'Name = JA6/KM-032(JA6/KM-032) peak = 903.299988 pos = 32.1972,130.5553 diff = 205.599976'
});
data_saddle.push({
lat: 3.2186777779e+01,
lng: 1.3059666667e+02,
content:'Saddle = 697.700012 pos = 32.1868,130.5967 diff = 205.599976'
});
data_peak.push({
lat: 3.2109333334e+01,
lng: 1.3067688889e+02,
cert : false,
content:' Peak = 901.299988 pos = 32.1093,130.6769 diff = 165.500000'
});
data_saddle.push({
lat: 3.2121000001e+01,
lng: 1.3067388889e+02,
content:'Saddle = 735.799988 pos = 32.1210,130.6739 diff = 165.500000'
});
data_peak.push({
lat: 3.2111444445e+01,
lng: 1.3096588889e+02,
cert : true,
content:'Name = JA6/MZ-062(JA6/MZ-062) peak = 902.299988 pos = 32.1114,130.9659 diff = 254.799988'
});
data_saddle.push({
lat: 3.2118777779e+01,
lng: 1.3094288889e+02,
content:'Saddle = 647.500000 pos = 32.1188,130.9429 diff = 254.799988'
});
data_peak.push({
lat: 3.2131777779e+01,
lng: 1.3098922222e+02,
cert : true,
content:'Name = JA6/MZ-048(JA6/MZ-048) peak = 974.599976 pos = 32.1318,130.9892 diff = 261.199951'
});
data_saddle.push({
lat: 3.2146333334e+01,
lng: 1.3099311111e+02,
content:'Saddle = 713.400024 pos = 32.1463,130.9931 diff = 261.199951'
});
data_peak.push({
lat: 3.2212333334e+01,
lng: 1.3098400000e+02,
cert : false,
content:' Peak = 1013.099976 pos = 32.2123,130.9840 diff = 296.199951'
});
data_saddle.push({
lat: 3.2201333334e+01,
lng: 1.3097877778e+02,
content:'Saddle = 716.900024 pos = 32.2013,130.9788 diff = 296.199951'
});
data_peak.push({
lat: 3.2226777778e+01,
lng: 1.3099522222e+02,
cert : false,
content:' Peak = 925.400024 pos = 32.2268,130.9952 diff = 152.800049'
});
data_saddle.push({
lat: 3.2216777778e+01,
lng: 1.3098944444e+02,
content:'Saddle = 772.599976 pos = 32.2168,130.9894 diff = 152.800049'
});
data_peak.push({
lat: 3.2121555556e+01,
lng: 1.3088200000e+02,
cert : false,
content:' Peak = 962.500000 pos = 32.1216,130.8820 diff = 210.799988'
});
data_saddle.push({
lat: 3.2132333334e+01,
lng: 1.3086911111e+02,
content:'Saddle = 751.700012 pos = 32.1323,130.8691 diff = 210.799988'
});
data_peak.push({
lat: 3.2119666667e+01,
lng: 1.3090355556e+02,
cert : true,
content:'Name = JA6/MZ-054(JA6/MZ-054) peak = 940.799988 pos = 32.1197,130.9036 diff = 182.399963'
});
data_saddle.push({
lat: 3.2118222223e+01,
lng: 1.3089166667e+02,
content:'Saddle = 758.400024 pos = 32.1182,130.8917 diff = 182.399963'
});
data_peak.push({
lat: 3.2203333334e+01,
lng: 1.3099900000e+02,
cert : false,
content:' Peak = 953.099976 pos = 32.2033,130.9990 diff = 182.500000'
});
data_saddle.push({
lat: 3.2195666667e+01,
lng: 1.3099211111e+02,
content:'Saddle = 770.599976 pos = 32.1957,130.9921 diff = 182.500000'
});
data_peak.push({
lat: 3.2147333334e+01,
lng: 1.3088744444e+02,
cert : true,
content:'Name = JA6/KM-017(JA6/KM-017) peak = 1118.500000 pos = 32.1473,130.8874 diff = 211.299988'
});
data_saddle.push({
lat: 3.2164888890e+01,
lng: 1.3090455556e+02,
content:'Saddle = 907.200012 pos = 32.1649,130.9046 diff = 211.299988'
});
data_peak.push({
lat: 3.2155444445e+01,
lng: 1.3097822222e+02,
cert : true,
content:'Name = JA6/KM-014(JA6/KM-014) peak = 1182.000000 pos = 32.1554,130.9782 diff = 219.299988'
});
data_saddle.push({
lat: 3.2158222223e+01,
lng: 1.3097233333e+02,
content:'Saddle = 962.700012 pos = 32.1582,130.9723 diff = 219.299988'
});
data_peak.push({
lat: 3.1485888890e+01,
lng: 1.3081900000e+02,
cert : true,
content:'Name = Takakumayama (Oonogaradake)(JA6/KG-006) peak = 1232.199951 pos = 31.4859,130.8190 diff = 870.499939'
});
data_saddle.push({
lat: 3.1833888890e+01,
lng: 1.3087488889e+02,
content:'Saddle = 361.700012 pos = 31.8339,130.8749 diff = 870.499939'
});
data_peak.push({
lat: 3.1828777779e+01,
lng: 1.3088755556e+02,
cert : false,
content:' Peak = 574.000000 pos = 31.8288,130.8876 diff = 206.600006'
});
data_saddle.push({
lat: 3.1779888890e+01,
lng: 1.3089222222e+02,
content:'Saddle = 367.399994 pos = 31.7799,130.8922 diff = 206.600006'
});
data_peak.push({
lat: 3.1728222223e+01,
lng: 1.3090111111e+02,
cert : false,
content:' Peak = 604.500000 pos = 31.7282,130.9011 diff = 221.899994'
});
data_saddle.push({
lat: 3.1669111112e+01,
lng: 1.3084388889e+02,
content:'Saddle = 382.600006 pos = 31.6691,130.8439 diff = 221.899994'
});
data_peak.push({
lat: 3.1767222223e+01,
lng: 1.3087800000e+02,
cert : false,
content:' Peak = 570.299988 pos = 31.7672,130.8780 diff = 158.199982'
});
data_saddle.push({
lat: 3.1743888890e+01,
lng: 1.3086722222e+02,
content:'Saddle = 412.100006 pos = 31.7439,130.8672 diff = 158.199982'
});
data_peak.push({
lat: 3.1546111112e+01,
lng: 1.3078755556e+02,
cert : true,
content:'Name = JA6/KG-020(JA6/KG-020) peak = 881.900024 pos = 31.5461,130.7876 diff = 350.300049'
});
data_saddle.push({
lat: 3.1524666668e+01,
lng: 1.3077111111e+02,
content:'Saddle = 531.599976 pos = 31.5247,130.7711 diff = 350.300049'
});
data_peak.push({
lat: 3.1506555557e+01,
lng: 1.3079811111e+02,
cert : true,
content:'Name = JA6/KG-021(JA6/KG-021) peak = 881.000000 pos = 31.5066,130.7981 diff = 173.400024'
});
data_saddle.push({
lat: 3.1500777779e+01,
lng: 1.3080622222e+02,
content:'Saddle = 707.599976 pos = 31.5008,130.8062 diff = 173.400024'
});
data_peak.push({
lat: 3.1461888890e+01,
lng: 1.3079466667e+02,
cert : false,
content:' Peak = 1101.500000 pos = 31.4619,130.7947 diff = 163.299988'
});
data_saddle.push({
lat: 3.1464222223e+01,
lng: 1.3080011111e+02,
content:'Saddle = 938.200012 pos = 31.4642,130.8001 diff = 163.299988'
});
data_peak.push({
lat: 3.1460333334e+01,
lng: 1.3082055556e+02,
cert : false,
content:' Peak = 1181.000000 pos = 31.4603,130.8206 diff = 178.500000'
});
data_saddle.push({
lat: 3.1464444445e+01,
lng: 1.3081477778e+02,
content:'Saddle = 1002.500000 pos = 31.4644,130.8148 diff = 178.500000'
});
data_peak.push({
lat: 3.1981666667e+01,
lng: 1.3079622222e+02,
cert : true,
content:'Name = JA6/MZ-071(JA6/MZ-071) peak = 846.200012 pos = 31.9817,130.7962 diff = 206.799988'
});
data_saddle.push({
lat: 3.1974333334e+01,
lng: 1.3079522222e+02,
content:'Saddle = 639.400024 pos = 31.9743,130.7952 diff = 206.799988'
});
data_peak.push({
lat: 3.1954666667e+01,
lng: 1.3079166667e+02,
cert : true,
content:'Name = JA6/KG-009(JA6/KG-009) peak = 1101.599976 pos = 31.9547,130.7917 diff = 159.299988'
});
data_saddle.push({
lat: 3.1947777779e+01,
lng: 1.3080777778e+02,
content:'Saddle = 942.299988 pos = 31.9478,130.8078 diff = 159.299988'
});
data_peak.push({
lat: 3.1950777779e+01,
lng: 1.3090844444e+02,
cert : false,
content:' Peak = 1340.800049 pos = 31.9508,130.9084 diff = 188.600098'
});
data_saddle.push({
lat: 3.1945444445e+01,
lng: 1.3090777778e+02,
content:'Saddle = 1152.199951 pos = 31.9454,130.9078 diff = 188.600098'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:34,
       south:31.3333,
       east:131,
       west:129}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
