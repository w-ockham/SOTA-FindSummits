function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.0336000000e+01,
lng: 1.3050422222e+02,
cert : true,
content:'Name = Miyanouradake(JA6/KG-001) peak = 1935.400024 pos = 30.3360,130.5042 diff = 1935.400024'
});
data_saddle.push({
lat: 3.1333333333e+01,
lng: 1.2900000000e+02,
content:'Saddle = 0.000000 pos = 31.3333,129.0000 diff = 1935.400024'
});
data_peak.push({
lat: 3.0002222223e+01,
lng: 1.2991422222e+02,
cert : false,
content:' Peak = 233.600006 pos = 30.0022,129.9142 diff = 233.600006'
});
data_saddle.push({
lat: 3.0226333334e+01,
lng: 1.3052233333e+02,
content:'Saddle = 0.000000 pos = 30.2263,130.5223 diff = 233.600006'
});
data_peak.push({
lat: 3.0639444445e+01,
lng: 1.3097866667e+02,
cert : false,
content:' Peak = 281.899994 pos = 30.6394,130.9787 diff = 281.899994'
});
data_saddle.push({
lat: 3.0343777778e+01,
lng: 1.3088366667e+02,
content:'Saddle = 0.000000 pos = 30.3438,130.8837 diff = 281.899994'
});
data_peak.push({
lat: 3.0745333334e+01,
lng: 1.3105488889e+02,
cert : false,
content:' Peak = 242.800003 pos = 30.7453,131.0549 diff = 168.800003'
});
data_saddle.push({
lat: 3.0746666667e+01,
lng: 1.3101244444e+02,
content:'Saddle = 74.000000 pos = 30.7467,131.0124 diff = 168.800003'
});
data_peak.push({
lat: 3.0443222223e+01,
lng: 1.3021733333e+02,
cert : true,
content:'Name = Furudake(JA6/KG-035) peak = 655.299988 pos = 30.4432,130.2173 diff = 655.299988'
});
data_saddle.push({
lat: 3.0421777778e+01,
lng: 1.3021144444e+02,
content:'Saddle = 0.000000 pos = 30.4218,130.2114 diff = 655.299988'
});
data_peak.push({
lat: 3.0470555556e+01,
lng: 1.3017733333e+02,
cert : false,
content:' Peak = 290.000000 pos = 30.4706,130.1773 diff = 242.100006'
});
data_saddle.push({
lat: 3.0468555556e+01,
lng: 1.3019177778e+02,
content:'Saddle = 47.900002 pos = 30.4686,130.1918 diff = 242.100006'
});
data_peak.push({
lat: 3.0812444445e+01,
lng: 1.3043277778e+02,
cert : false,
content:' Peak = 218.500000 pos = 30.8124,130.4328 diff = 218.500000'
});
data_saddle.push({
lat: 3.0800111111e+01,
lng: 1.3044222222e+02,
content:'Saddle = 0.000000 pos = 30.8001,130.4422 diff = 218.500000'
});
data_peak.push({
lat: 3.0828444445e+01,
lng: 1.2993744444e+02,
cert : true,
content:'Name = Yaguradake(JA6/KG-041) peak = 620.299988 pos = 30.8284,129.9374 diff = 620.299988'
});
data_saddle.push({
lat: 3.0811777778e+01,
lng: 1.2993011111e+02,
content:'Saddle = 0.000000 pos = 30.8118,129.9301 diff = 620.299988'
});
data_peak.push({
lat: 3.0793111111e+01,
lng: 1.3030522222e+02,
cert : true,
content:'Name = Ioudake(JA6/KG-027) peak = 700.700012 pos = 30.7931,130.3052 diff = 700.700012'
});
data_saddle.push({
lat: 3.0772444445e+01,
lng: 1.3027788889e+02,
content:'Saddle = 0.000000 pos = 30.7724,130.2779 diff = 700.700012'
});
data_peak.push({
lat: 3.0782888889e+01,
lng: 1.3028844444e+02,
cert : false,
content:' Peak = 240.600006 pos = 30.7829,130.2884 diff = 162.400009'
});
data_saddle.push({
lat: 3.0787111111e+01,
lng: 1.3029111111e+02,
content:'Saddle = 78.199997 pos = 30.7871,130.2911 diff = 162.400009'
});
data_peak.push({
lat: 3.0794333334e+01,
lng: 1.3028433333e+02,
cert : true,
content:'Name = JA6/KG-114(JA6/KG-114) peak = 346.100006 pos = 30.7943,130.2843 diff = 234.100006'
});
data_saddle.push({
lat: 3.0794222222e+01,
lng: 1.3029344444e+02,
content:'Saddle = 112.000000 pos = 30.7942,130.2934 diff = 234.100006'
});
data_peak.push({
lat: 3.1195555556e+01,
lng: 1.2944777778e+02,
cert : false,
content:' Peak = 315.399994 pos = 31.1956,129.4478 diff = 315.399994'
});
data_saddle.push({
lat: 3.1175777778e+01,
lng: 1.2943522222e+02,
content:'Saddle = 0.000000 pos = 31.1758,129.4352 diff = 315.399994'
});
data_peak.push({
lat: 3.1180000000e+01,
lng: 1.3052833333e+02,
cert : true,
content:'Name = Kaimondake(JA6/KG-016) peak = 923.599976 pos = 31.1800,130.5283 diff = 923.599976'
});
data_saddle.push({
lat: 3.1155222222e+01,
lng: 1.3058700000e+02,
content:'Saddle = 0.000000 pos = 31.1552,130.5870 diff = 923.599976'
});
data_peak.push({
lat: 3.1262111111e+01,
lng: 1.3065422222e+02,
cert : false,
content:' Peak = 212.899994 pos = 31.2621,130.6542 diff = 201.799988'
});
data_saddle.push({
lat: 3.1268777778e+01,
lng: 1.3063544444e+02,
content:'Saddle = 11.100000 pos = 31.2688,130.6354 diff = 201.799988'
});
data_peak.push({
lat: 3.1184666667e+01,
lng: 1.3062066667e+02,
cert : false,
content:' Peak = 200.399994 pos = 31.1847,130.6207 diff = 165.699997'
});
data_saddle.push({
lat: 3.1188000000e+01,
lng: 1.3062133333e+02,
content:'Saddle = 34.700001 pos = 31.1880,130.6213 diff = 165.699997'
});
data_peak.push({
lat: 3.1310666667e+01,
lng: 1.3052633333e+02,
cert : true,
content:'Name = JA6/KG-052(JA6/KG-052) peak = 576.500000 pos = 31.3107,130.5263 diff = 534.299988'
});
data_saddle.push({
lat: 3.1204111111e+01,
lng: 1.3053233333e+02,
content:'Saddle = 42.200001 pos = 31.2041,130.5323 diff = 534.299988'
});
data_peak.push({
lat: 3.1329000000e+01,
lng: 1.3022411111e+02,
cert : true,
content:'Name = JA6/KG-081(JA6/KG-081) peak = 462.799988 pos = 31.3290,130.2241 diff = 397.500000'
});
data_saddle.push({
lat: 3.1333333333e+01,
lng: 1.3027422222e+02,
content:'Saddle = 65.300003 pos = 31.3333,130.2742 diff = 397.500000'
});
data_peak.push({
lat: 3.1274111111e+01,
lng: 1.3024588889e+02,
cert : false,
content:' Peak = 261.700012 pos = 31.2741,130.2459 diff = 183.700012'
});
data_saddle.push({
lat: 3.1286555556e+01,
lng: 1.3025533333e+02,
content:'Saddle = 78.000000 pos = 31.2866,130.2553 diff = 183.700012'
});
data_peak.push({
lat: 3.1304333333e+01,
lng: 1.3024722222e+02,
cert : true,
content:'Name = JA6/KG-086(JA6/KG-086) peak = 444.200012 pos = 31.3043,130.2472 diff = 206.500015'
});
data_saddle.push({
lat: 3.1325555556e+01,
lng: 1.3023188889e+02,
content:'Saddle = 237.699997 pos = 31.3256,130.2319 diff = 206.500015'
});
data_peak.push({
lat: 3.1222888889e+01,
lng: 1.3059500000e+02,
cert : true,
content:'Name = JA6/KG-100(JA6/KG-100) peak = 411.100006 pos = 31.2229,130.5950 diff = 312.600006'
});
data_saddle.push({
lat: 3.1261555556e+01,
lng: 1.3056533333e+02,
content:'Saddle = 98.500000 pos = 31.2616,130.5653 diff = 312.600006'
});
data_peak.push({
lat: 3.1311333333e+01,
lng: 1.3035300000e+02,
cert : true,
content:'Name = JA6/KG-098(JA6/KG-098) peak = 413.899994 pos = 31.3113,130.3530 diff = 271.599976'
});
data_saddle.push({
lat: 3.1321555556e+01,
lng: 1.3042688889e+02,
content:'Saddle = 142.300003 pos = 31.3216,130.4269 diff = 271.599976'
});
data_peak.push({
lat: 3.1294333333e+01,
lng: 1.3033455556e+02,
cert : true,
content:'Name = JA6/KG-103(JA6/KG-103) peak = 390.799988 pos = 31.2943,130.3346 diff = 191.599991'
});
data_saddle.push({
lat: 3.1308666667e+01,
lng: 1.3034777778e+02,
content:'Saddle = 199.199997 pos = 31.3087,130.3478 diff = 191.599991'
});
data_peak.push({
lat: 3.1256000000e+01,
lng: 1.3051666667e+02,
cert : true,
content:'Name = JA6/KG-080(JA6/KG-080) peak = 463.299988 pos = 31.2560,130.5167 diff = 211.499985'
});
data_saddle.push({
lat: 3.1261777778e+01,
lng: 1.3052733333e+02,
content:'Saddle = 251.800003 pos = 31.2618,130.5273 diff = 211.499985'
});
data_peak.push({
lat: 3.1264222222e+01,
lng: 1.3099011111e+02,
cert : true,
content:'Name = Hoyoshidake(JA6/KG-013) peak = 965.599976 pos = 31.2642,130.9901 diff = 965.599976'
});
data_saddle.push({
lat: 3.0994222222e+01,
lng: 1.3066055556e+02,
content:'Saddle = 0.000000 pos = 30.9942,130.6606 diff = 965.599976'
});
data_peak.push({
lat: 3.1001666667e+01,
lng: 1.3066211111e+02,
cert : false,
content:' Peak = 220.399994 pos = 31.0017,130.6621 diff = 198.199997'
});
data_saddle.push({
lat: 3.1012222222e+01,
lng: 1.3066600000e+02,
content:'Saddle = 22.200001 pos = 31.0122,130.6660 diff = 198.199997'
});
data_peak.push({
lat: 3.1015333333e+01,
lng: 1.3068288889e+02,
cert : false,
content:' Peak = 217.800003 pos = 31.0153,130.6829 diff = 174.399994'
});
data_saddle.push({
lat: 3.1028000000e+01,
lng: 1.3067744444e+02,
content:'Saddle = 43.400002 pos = 31.0280,130.6774 diff = 174.399994'
});
data_peak.push({
lat: 3.1204000000e+01,
lng: 1.3075911111e+02,
cert : false,
content:' Peak = 230.300003 pos = 31.2040,130.7591 diff = 162.700012'
});
data_saddle.push({
lat: 3.1197888889e+01,
lng: 1.3077300000e+02,
content:'Saddle = 67.599998 pos = 31.1979,130.7730 diff = 162.700012'
});
data_peak.push({
lat: 3.1328111111e+01,
lng: 1.3097066667e+02,
cert : true,
content:'Name = JA6/KG-132(JA6/KG-132) peak = 280.399994 pos = 31.3281,130.9707 diff = 168.299988'
});
data_saddle.push({
lat: 3.1330444444e+01,
lng: 1.3097833333e+02,
content:'Saddle = 112.099998 pos = 31.3304,130.9783 diff = 168.299988'
});
data_peak.push({
lat: 3.1286777778e+01,
lng: 1.3090066667e+02,
cert : false,
content:' Peak = 281.299988 pos = 31.2868,130.9007 diff = 163.899994'
});
data_saddle.push({
lat: 3.1274666667e+01,
lng: 1.3090288889e+02,
content:'Saddle = 117.400002 pos = 31.2747,130.9029 diff = 163.899994'
});
data_peak.push({
lat: 3.1301333333e+01,
lng: 1.3094911111e+02,
cert : true,
content:'Name = JA6/KG-118(JA6/KG-118) peak = 321.600006 pos = 31.3013,130.9491 diff = 191.000000'
});
data_saddle.push({
lat: 3.1294111111e+01,
lng: 1.3094244444e+02,
content:'Saddle = 130.600006 pos = 31.2941,130.9424 diff = 191.000000'
});
data_peak.push({
lat: 3.1295111111e+01,
lng: 1.3086500000e+02,
cert : false,
content:' Peak = 484.500000 pos = 31.2951,130.8650 diff = 303.600006'
});
data_saddle.push({
lat: 3.1253777778e+01,
lng: 1.3086200000e+02,
content:'Saddle = 180.899994 pos = 31.2538,130.8620 diff = 303.600006'
});
data_peak.push({
lat: 3.1056555556e+01,
lng: 1.3070377778e+02,
cert : true,
content:'Name = JA6/KG-116(JA6/KG-116) peak = 347.600006 pos = 31.0566,130.7038 diff = 156.900009'
});
data_saddle.push({
lat: 3.1081222222e+01,
lng: 1.3070911111e+02,
content:'Saddle = 190.699997 pos = 31.0812,130.7091 diff = 156.900009'
});
data_peak.push({
lat: 3.1270333333e+01,
lng: 1.3092844444e+02,
cert : false,
content:' Peak = 460.899994 pos = 31.2703,130.9284 diff = 161.799988'
});
data_saddle.push({
lat: 3.1263888889e+01,
lng: 1.3093133333e+02,
content:'Saddle = 299.100006 pos = 31.2639,130.9313 diff = 161.799988'
});
data_peak.push({
lat: 3.1129555556e+01,
lng: 1.3088011111e+02,
cert : true,
content:'Name = JA6/KG-014(JA6/KG-014) peak = 956.200012 pos = 31.1296,130.8801 diff = 489.200012'
});
data_saddle.push({
lat: 3.1173666667e+01,
lng: 1.3093066667e+02,
content:'Saddle = 467.000000 pos = 31.1737,130.9307 diff = 489.200012'
});
data_peak.push({
lat: 3.1136444444e+01,
lng: 1.3077044444e+02,
cert : true,
content:'Name = JA6/KG-018(JA6/KG-018) peak = 896.500000 pos = 31.1364,130.7704 diff = 298.700012'
});
data_saddle.push({
lat: 3.1131666667e+01,
lng: 1.3078622222e+02,
content:'Saddle = 597.799988 pos = 31.1317,130.7862 diff = 298.700012'
});
data_peak.push({
lat: 3.1125555556e+01,
lng: 1.3080700000e+02,
cert : true,
content:'Name = JA6/KG-019(JA6/KG-019) peak = 890.799988 pos = 31.1256,130.8070 diff = 237.299988'
});
data_saddle.push({
lat: 3.1128777778e+01,
lng: 1.3084188889e+02,
content:'Saddle = 653.500000 pos = 31.1288,130.8419 diff = 237.299988'
});
data_peak.push({
lat: 3.1226777778e+01,
lng: 1.3092533333e+02,
cert : true,
content:'Name = JA6/KG-015(JA6/KG-015) peak = 940.000000 pos = 31.2268,130.9253 diff = 443.500000'
});
data_saddle.push({
lat: 3.1249333333e+01,
lng: 1.3097500000e+02,
content:'Saddle = 496.500000 pos = 31.2493,130.9750 diff = 443.500000'
});
data_peak.push({
lat: 3.1184888889e+01,
lng: 1.3094455556e+02,
cert : true,
content:'Name = JA6/KG-024(JA6/KG-024) peak = 751.799988 pos = 31.1849,130.9446 diff = 214.200012'
});
data_saddle.push({
lat: 3.1193111111e+01,
lng: 1.3093566667e+02,
content:'Saddle = 537.599976 pos = 31.1931,130.9357 diff = 214.200012'
});
data_peak.push({
lat: 3.1249555556e+01,
lng: 1.3100522222e+02,
cert : true,
content:'Name = JA6/KG-025(JA6/KG-025) peak = 741.799988 pos = 31.2496,131.0052 diff = 169.599976'
});
data_saddle.push({
lat: 3.1253555556e+01,
lng: 1.3099844444e+02,
content:'Saddle = 572.200012 pos = 31.2536,130.9984 diff = 169.599976'
});
data_peak.push({
lat: 3.1290111111e+01,
lng: 1.3099100000e+02,
cert : true,
content:'Name = JA6/KG-017(JA6/KG-017) peak = 912.200012 pos = 31.2901,130.9910 diff = 181.900024'
});
data_saddle.push({
lat: 3.1285111111e+01,
lng: 1.3099322222e+02,
content:'Saddle = 730.299988 pos = 31.2851,130.9932 diff = 181.900024'
});
data_peak.push({
lat: 3.0427222223e+01,
lng: 1.3053166667e+02,
cert : true,
content:'Name = JA6/KG-026(JA6/KG-026) peak = 704.400024 pos = 30.4272,130.5317 diff = 197.700012'
});
data_saddle.push({
lat: 3.0425666667e+01,
lng: 1.3052400000e+02,
content:'Saddle = 506.700012 pos = 30.4257,130.5240 diff = 197.700012'
});
data_peak.push({
lat: 3.0352222223e+01,
lng: 1.3062633333e+02,
cert : false,
content:' Peak = 941.000000 pos = 30.3522,130.6263 diff = 166.000000'
});
data_saddle.push({
lat: 3.0356444445e+01,
lng: 1.3062011111e+02,
content:'Saddle = 775.000000 pos = 30.3564,130.6201 diff = 166.000000'
});
data_peak.push({
lat: 3.0366000000e+01,
lng: 1.3060011111e+02,
cert : true,
content:'Name = JA6/KG-007(JA6/KG-007) peak = 1231.000000 pos = 30.3660,130.6001 diff = 342.900024'
});
data_saddle.push({
lat: 3.0366555556e+01,
lng: 1.3057666667e+02,
content:'Saddle = 888.099976 pos = 30.3666,130.5767 diff = 342.900024'
});
data_peak.push({
lat: 3.0323777778e+01,
lng: 1.3059222222e+02,
cert : false,
content:' Peak = 1060.699951 pos = 30.3238,130.5922 diff = 169.999939'
});
data_saddle.push({
lat: 3.0316777778e+01,
lng: 1.3058644444e+02,
content:'Saddle = 890.700012 pos = 30.3168,130.5864 diff = 169.999939'
});
data_peak.push({
lat: 3.0352333334e+01,
lng: 1.3041455556e+02,
cert : false,
content:' Peak = 1322.599976 pos = 30.3523,130.4146 diff = 160.400024'
});
data_saddle.push({
lat: 3.0353111111e+01,
lng: 1.3043211111e+02,
content:'Saddle = 1162.199951 pos = 30.3531,130.4321 diff = 160.400024'
});
data_peak.push({
lat: 3.0273111112e+01,
lng: 1.3055444444e+02,
cert : true,
content:'Name = JA6/KG-005(JA6/KG-005) peak = 1411.099976 pos = 30.2731,130.5544 diff = 218.400024'
});
data_saddle.push({
lat: 3.0282111111e+01,
lng: 1.3055088889e+02,
content:'Saddle = 1192.699951 pos = 30.2821,130.5509 diff = 218.400024'
});
data_peak.push({
lat: 3.0359000000e+01,
lng: 1.3048577778e+02,
cert : false,
content:' Peak = 1539.199951 pos = 30.3590,130.4858 diff = 165.399902'
});
data_saddle.push({
lat: 3.0358111111e+01,
lng: 1.3048811111e+02,
content:'Saddle = 1373.800049 pos = 30.3581,130.4881 diff = 165.399902'
});
data_peak.push({
lat: 3.0321000000e+01,
lng: 1.3055677778e+02,
cert : false,
content:' Peak = 1582.099976 pos = 30.3210,130.5568 diff = 174.099976'
});
data_saddle.push({
lat: 3.0317000000e+01,
lng: 1.3054500000e+02,
content:'Saddle = 1408.000000 pos = 30.3170,130.5450 diff = 174.099976'
});
data_peak.push({
lat: 3.0290111111e+01,
lng: 1.3051055556e+02,
cert : true,
content:'Name = JA6/KG-002(JA6/KG-002) peak = 1732.699951 pos = 30.2901,130.5106 diff = 235.500000'
});
data_saddle.push({
lat: 3.0298444445e+01,
lng: 1.3050533333e+02,
content:'Saddle = 1497.199951 pos = 30.2984,130.5053 diff = 235.500000'
});
data_peak.push({
lat: 3.0342888889e+01,
lng: 1.3049233333e+02,
cert : false,
content:' Peak = 1884.199951 pos = 30.3429,130.4923 diff = 157.399902'
});
data_saddle.push({
lat: 3.0340555556e+01,
lng: 1.3049477778e+02,
content:'Saddle = 1726.800049 pos = 30.3406,130.4948 diff = 157.399902'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:31.3333,
       south:30,
       east:132,
       west:129}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
