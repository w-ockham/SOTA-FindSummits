function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.5360666657e+01,
lng: 1.3872733333e+02,
cert : true,
content:'Name = Fujisan Kengamine(JA/SO-001) peak = 3774.899902 pos = 35.3607,138.7273 diff = 3774.899902'
});
data_saddle.push({
lat: 3.5687222215e+01,
lng: 1.3994688889e+02,
content:'Saddle = 0.000000 pos = 35.6872,139.9469 diff = 3774.899902'
});
data_peak.push({
lat: 3.5114888877e+01,
lng: 1.3998677778e+02,
cert : true,
content:'Name = Atagoyama(JA/CB-001) peak = 407.299988 pos = 35.1149,139.9868 diff = 407.299988'
});
data_saddle.push({
lat: 3.4899444431e+01,
lng: 1.3988722222e+02,
content:'Saddle = 0.000000 pos = 34.8994,139.8872 diff = 407.299988'
});
data_peak.push({
lat: 3.4937555542e+01,
lng: 1.3994044444e+02,
cert : false,
content:' Peak = 214.699997 pos = 34.9376,139.9404 diff = 176.399994'
});
data_saddle.push({
lat: 3.5009999987e+01,
lng: 1.3993888889e+02,
content:'Saddle = 38.299999 pos = 35.0100,139.9389 diff = 176.399994'
});
data_peak.push({
lat: 3.5112333321e+01,
lng: 1.3986466667e+02,
cert : false,
content:' Peak = 258.500000 pos = 35.1123,139.8647 diff = 166.500000'
});
data_saddle.push({
lat: 3.5110666655e+01,
lng: 1.3987566667e+02,
content:'Saddle = 92.000000 pos = 35.1107,139.8757 diff = 166.500000'
});
data_peak.push({
lat: 3.5098888877e+01,
lng: 1.3988144444e+02,
cert : true,
content:'Name = Tomisan(JA/CB-005) peak = 348.799988 pos = 35.0989,139.8814 diff = 250.199982'
});
data_saddle.push({
lat: 3.5099444432e+01,
lng: 1.3989777778e+02,
content:'Saddle = 98.599998 pos = 35.0994,139.8978 diff = 250.199982'
});
data_peak.push({
lat: 3.5255666656e+01,
lng: 1.3997177778e+02,
cert : true,
content:'Name = Shirotori Shrine(JA/CB-002) peak = 378.299988 pos = 35.2557,139.9718 diff = 257.500000'
});
data_saddle.push({
lat: 3.5245999989e+01,
lng: 1.3997655556e+02,
content:'Saddle = 120.800003 pos = 35.2460,139.9766 diff = 257.500000'
});
data_peak.push({
lat: 3.5160444433e+01,
lng: 1.3984077778e+02,
cert : true,
content:'Name = Nokogiriyama(JA/CB-006) peak = 327.299988 pos = 35.1604,139.8408 diff = 189.899994'
});
data_saddle.push({
lat: 3.5161999988e+01,
lng: 1.3986333333e+02,
content:'Saddle = 137.399994 pos = 35.1620,139.8633 diff = 189.899994'
});
data_peak.push({
lat: 3.5157444433e+01,
lng: 1.3988344444e+02,
cert : false,
content:' Peak = 313.899994 pos = 35.1574,139.8834 diff = 161.399994'
});
data_saddle.push({
lat: 3.5141222210e+01,
lng: 1.3991211111e+02,
content:'Saddle = 152.500000 pos = 35.1412,139.9121 diff = 161.399994'
});
data_peak.push({
lat: 3.5073999988e+01,
lng: 1.3997522222e+02,
cert : false,
content:' Peak = 310.500000 pos = 35.0740,139.9752 diff = 153.899994'
});
data_saddle.push({
lat: 3.5094222210e+01,
lng: 1.3999300000e+02,
content:'Saddle = 156.600006 pos = 35.0942,139.9930 diff = 153.899994'
});
data_peak.push({
lat: 3.5088777765e+01,
lng: 1.3994777778e+02,
cert : true,
content:'Name = Gotenyama(JA/CB-004) peak = 362.399994 pos = 35.0888,139.9478 diff = 204.799988'
});
data_saddle.push({
lat: 3.5098222210e+01,
lng: 1.3996144444e+02,
content:'Saddle = 157.600006 pos = 35.0982,139.9614 diff = 204.799988'
});
data_peak.push({
lat: 3.5155222210e+01,
lng: 1.3998000000e+02,
cert : false,
content:' Peak = 343.399994 pos = 35.1552,139.9800 diff = 176.000000'
});
data_saddle.push({
lat: 3.5144333321e+01,
lng: 1.3993088889e+02,
content:'Saddle = 167.399994 pos = 35.1443,139.9309 diff = 176.000000'
});
data_peak.push({
lat: 3.5107333321e+01,
lng: 1.3991388889e+02,
cert : false,
content:' Peak = 333.399994 pos = 35.1073,139.9139 diff = 165.899994'
});
data_saddle.push({
lat: 3.5121777766e+01,
lng: 1.3992377778e+02,
content:'Saddle = 167.500000 pos = 35.1218,139.9238 diff = 165.899994'
});
data_peak.push({
lat: 3.5138999988e+01,
lng: 1.3993255556e+02,
cert : false,
content:' Peak = 323.299988 pos = 35.1390,139.9326 diff = 151.099991'
});
data_saddle.push({
lat: 3.5121333321e+01,
lng: 1.3995055556e+02,
content:'Saddle = 172.199997 pos = 35.1213,139.9506 diff = 151.099991'
});
data_peak.push({
lat: 3.4724555540e+01,
lng: 1.3939422222e+02,
cert : false,
content:' Peak = 755.599976 pos = 34.7246,139.3942 diff = 755.599976'
});
data_saddle.push({
lat: 3.4677999984e+01,
lng: 1.3943444444e+02,
content:'Saddle = 0.000000 pos = 34.6780,139.4344 diff = 755.599976'
});
data_peak.push({
lat: 3.4093666646e+01,
lng: 1.3952611111e+02,
cert : true,
content:'Name = Oyama(JA/TK-014) peak = 773.000000 pos = 34.0937,139.5261 diff = 773.000000'
});
data_saddle.push({
lat: 3.4595111095e+01,
lng: 1.3822688889e+02,
content:'Saddle = 0.000000 pos = 34.5951,138.2269 diff = 773.000000'
});
data_peak.push({
lat: 3.4472888872e+01,
lng: 1.3929333333e+02,
cert : true,
content:'Name = Udoneshima(JA/TK-029) peak = 202.800003 pos = 34.4729,139.2933 diff = 202.800003'
});
data_saddle.push({
lat: 3.4469777761e+01,
lng: 1.3929800000e+02,
content:'Saddle = 0.000000 pos = 34.4698,139.2980 diff = 202.800003'
});
data_peak.push({
lat: 3.4396888871e+01,
lng: 1.3927022222e+02,
cert : true,
content:'Name = Miyatsukesan  (Niijima)(JA/TK-021) peak = 431.100006 pos = 34.3969,139.2702 diff = 431.100006'
});
data_saddle.push({
lat: 3.4329999982e+01,
lng: 1.3927244444e+02,
content:'Saddle = 0.000000 pos = 34.3300,139.2724 diff = 431.100006'
});
data_peak.push({
lat: 3.4349666648e+01,
lng: 1.3926933333e+02,
cert : true,
content:'Name = Omine(JA/TK-025) peak = 300.600006 pos = 34.3497,139.2693 diff = 272.600006'
});
data_saddle.push({
lat: 3.4370555538e+01,
lng: 1.3926522222e+02,
content:'Saddle = 28.000000 pos = 34.3706,139.2652 diff = 272.600006'
});
data_peak.push({
lat: 3.4416666649e+01,
lng: 1.3928600000e+02,
cert : false,
content:' Peak = 233.899994 pos = 34.4167,139.2860 diff = 176.699997'
});
data_saddle.push({
lat: 3.4412666649e+01,
lng: 1.3927955556e+02,
content:'Saddle = 57.200001 pos = 34.4127,139.2796 diff = 176.699997'
});
data_peak.push({
lat: 3.4520444428e+01,
lng: 1.3927922222e+02,
cert : true,
content:'Name = Miyatsukesan(JA/TK-019) peak = 507.000000 pos = 34.5204,139.2792 diff = 507.000000'
});
data_saddle.push({
lat: 3.4510999983e+01,
lng: 1.3927788889e+02,
content:'Saddle = 0.000000 pos = 34.5110,139.2779 diff = 507.000000'
});
data_peak.push({
lat: 3.4222333314e+01,
lng: 1.3915700000e+02,
cert : false,
content:' Peak = 573.099976 pos = 34.2223,139.1570 diff = 573.099976'
});
data_saddle.push({
lat: 3.4184555536e+01,
lng: 1.3912922222e+02,
content:'Saddle = 0.000000 pos = 34.1846,139.1292 diff = 573.099976'
});
data_peak.push({
lat: 3.4973111098e+01,
lng: 1.3846966667e+02,
cert : true,
content:'Name = JA/SO-120(JA/SO-120) peak = 305.700012 pos = 34.9731,138.4697 diff = 294.700012'
});
data_saddle.push({
lat: 3.4977666653e+01,
lng: 1.3842000000e+02,
content:'Saddle = 11.000000 pos = 34.9777,138.4200 diff = 294.700012'
});
data_peak.push({
lat: 3.4896555542e+01,
lng: 1.3826788889e+02,
cert : false,
content:' Peak = 203.699997 pos = 34.8966,138.2679 diff = 184.000000'
});
data_saddle.push({
lat: 3.4893999986e+01,
lng: 1.3826166667e+02,
content:'Saddle = 19.700001 pos = 34.8940,138.2617 diff = 184.000000'
});
data_peak.push({
lat: 3.5092333321e+01,
lng: 1.3887755556e+02,
cert : false,
content:' Peak = 192.500000 pos = 35.0923,138.8776 diff = 165.399994'
});
data_saddle.push({
lat: 3.5088999988e+01,
lng: 1.3888500000e+02,
content:'Saddle = 27.100000 pos = 35.0890,138.8850 diff = 165.399994'
});
data_peak.push({
lat: 3.6315999998e+01,
lng: 1.3962922222e+02,
cert : false,
content:' Peak = 226.300003 pos = 36.3160,139.6292 diff = 197.300003'
});
data_saddle.push({
lat: 3.6317777775e+01,
lng: 1.3964011111e+02,
content:'Saddle = 29.000000 pos = 36.3178,139.6401 diff = 197.300003'
});
data_peak.push({
lat: 3.5059444432e+01,
lng: 1.3889388889e+02,
cert : true,
content:'Name = JA/SO-115(JA/SO-115) peak = 391.700012 pos = 35.0594,138.8939 diff = 349.200012'
});
data_saddle.push({
lat: 3.5047444432e+01,
lng: 1.3890844444e+02,
content:'Saddle = 42.500000 pos = 35.0474,138.9084 diff = 349.200012'
});
data_peak.push({
lat: 3.5046444432e+01,
lng: 1.3892577778e+02,
cert : false,
content:' Peak = 206.500000 pos = 35.0464,138.9258 diff = 161.300003'
});
data_saddle.push({
lat: 3.5042999987e+01,
lng: 1.3892122222e+02,
content:'Saddle = 45.200001 pos = 35.0430,138.9212 diff = 161.300003'
});
data_peak.push({
lat: 3.5250111100e+01,
lng: 1.3962800000e+02,
cert : false,
content:' Peak = 241.000000 pos = 35.2501,139.6280 diff = 194.699997'
});
data_saddle.push({
lat: 3.5400333324e+01,
lng: 1.3957855556e+02,
content:'Saddle = 46.299999 pos = 35.4003,139.5786 diff = 194.699997'
});
data_peak.push({
lat: 3.5275222211e+01,
lng: 1.3962300000e+02,
cert : false,
content:' Peak = 212.000000 pos = 35.2752,139.6230 diff = 150.199997'
});
data_saddle.push({
lat: 3.5262222211e+01,
lng: 1.3963633333e+02,
content:'Saddle = 61.799999 pos = 35.2622,139.6363 diff = 150.199997'
});
data_peak.push({
lat: 3.4655333318e+01,
lng: 1.3889755556e+02,
cert : false,
content:' Peak = 200.199997 pos = 34.6553,138.8976 diff = 152.399994'
});
data_saddle.push({
lat: 3.4665666651e+01,
lng: 1.3890000000e+02,
content:'Saddle = 47.799999 pos = 34.6657,138.9000 diff = 152.399994'
});
data_peak.push({
lat: 3.4733333318e+01,
lng: 1.3800544444e+02,
cert : false,
content:' Peak = 264.399994 pos = 34.7333,138.0054 diff = 215.799988'
});
data_saddle.push({
lat: 3.4771333319e+01,
lng: 1.3806477778e+02,
content:'Saddle = 48.599998 pos = 34.7713,138.0648 diff = 215.799988'
});
data_peak.push({
lat: 3.6317555553e+01,
lng: 1.3937755556e+02,
cert : false,
content:' Peak = 237.300003 pos = 36.3176,139.3776 diff = 175.700012'
});
data_saddle.push({
lat: 3.6337333331e+01,
lng: 1.3936544444e+02,
content:'Saddle = 61.599998 pos = 36.3373,139.3654 diff = 175.700012'
});
data_peak.push({
lat: 3.4885888875e+01,
lng: 1.3822277778e+02,
cert : false,
content:' Peak = 244.600006 pos = 34.8859,138.2228 diff = 156.500000'
});
data_saddle.push({
lat: 3.4894444431e+01,
lng: 1.3822622222e+02,
content:'Saddle = 88.099998 pos = 34.8944,138.2262 diff = 156.500000'
});
data_peak.push({
lat: 3.4673555540e+01,
lng: 1.3892655556e+02,
cert : false,
content:' Peak = 252.000000 pos = 34.6736,138.9266 diff = 150.899994'
});
data_saddle.push({
lat: 3.4680222207e+01,
lng: 1.3892544444e+02,
content:'Saddle = 101.099998 pos = 34.6802,138.9254 diff = 150.899994'
});
data_peak.push({
lat: 3.4635111095e+01,
lng: 1.3883788889e+02,
cert : true,
content:'Name = JA/SO-119(JA/SO-119) peak = 307.899994 pos = 34.6351,138.8379 diff = 200.599991'
});
data_saddle.push({
lat: 3.4635333317e+01,
lng: 1.3881466667e+02,
content:'Saddle = 107.300003 pos = 34.6353,138.8147 diff = 200.599991'
});
data_peak.push({
lat: 3.6360333331e+01,
lng: 1.3967533333e+02,
cert : true,
content:'Name = JA/TG-082(JA/TG-082) peak = 418.000000 pos = 36.3603,139.6753 diff = 310.600006'
});
data_saddle.push({
lat: 3.6372444442e+01,
lng: 1.3965744444e+02,
content:'Saddle = 107.400002 pos = 36.3724,139.6574 diff = 310.600006'
});
data_peak.push({
lat: 3.5036222210e+01,
lng: 1.3891211111e+02,
cert : true,
content:'Name = JA/SO-122(JA/SO-122) peak = 272.399994 pos = 35.0362,138.9121 diff = 164.699997'
});
data_saddle.push({
lat: 3.5025222209e+01,
lng: 1.3890888889e+02,
content:'Saddle = 107.699997 pos = 35.0252,138.9089 diff = 164.699997'
});
data_peak.push({
lat: 3.4818999986e+01,
lng: 1.3875900000e+02,
cert : true,
content:'Name = JA/SO-121(JA/SO-121) peak = 302.100006 pos = 34.8190,138.7590 diff = 193.300003'
});
data_saddle.push({
lat: 3.4815666652e+01,
lng: 1.3876844444e+02,
content:'Saddle = 108.800003 pos = 34.8157,138.7684 diff = 193.300003'
});
data_peak.push({
lat: 3.6041777773e+01,
lng: 1.3927100000e+02,
cert : true,
content:'Name = Sengenyama(JA/ST-021) peak = 298.600006 pos = 36.0418,139.2710 diff = 171.300003'
});
data_saddle.push({
lat: 3.6032666662e+01,
lng: 1.3926211111e+02,
content:'Saddle = 127.300003 pos = 36.0327,139.2621 diff = 171.300003'
});
data_peak.push({
lat: 3.6378333331e+01,
lng: 1.3932622222e+02,
cert : false,
content:' Peak = 293.100006 pos = 36.3783,139.3262 diff = 164.100006'
});
data_saddle.push({
lat: 3.6387555554e+01,
lng: 1.3930955556e+02,
content:'Saddle = 129.000000 pos = 36.3876,139.3096 diff = 164.100006'
});
data_peak.push({
lat: 3.4911222209e+01,
lng: 1.3821266667e+02,
cert : true,
content:'Name = JA/SO-114(JA/SO-114) peak = 390.100006 pos = 34.9112,138.2127 diff = 227.500000'
});
data_saddle.push({
lat: 3.4919333320e+01,
lng: 1.3821400000e+02,
content:'Saddle = 162.600006 pos = 34.9193,138.2140 diff = 227.500000'
});
data_peak.push({
lat: 3.6374222220e+01,
lng: 1.3961733333e+02,
cert : false,
content:' Peak = 322.399994 pos = 36.3742,139.6173 diff = 155.899994'
});
data_saddle.push({
lat: 3.6378777776e+01,
lng: 1.3962444444e+02,
content:'Saddle = 166.500000 pos = 36.3788,139.6244 diff = 155.899994'
});
data_peak.push({
lat: 3.4939666653e+01,
lng: 1.3913133333e+02,
cert : false,
content:' Peak = 320.899994 pos = 34.9397,139.1313 diff = 154.099991'
});
data_saddle.push({
lat: 3.4932111098e+01,
lng: 1.3912733333e+02,
content:'Saddle = 166.800003 pos = 34.9321,139.1273 diff = 154.099991'
});
data_peak.push({
lat: 3.5316333323e+01,
lng: 1.3919777778e+02,
cert : false,
content:' Peak = 326.700012 pos = 35.3163,139.1978 diff = 158.900009'
});
data_saddle.push({
lat: 3.5339666656e+01,
lng: 1.3917066667e+02,
content:'Saddle = 167.800003 pos = 35.3397,139.1707 diff = 158.900009'
});
data_peak.push({
lat: 3.4905222208e+01,
lng: 1.3831888889e+02,
cert : false,
content:' Peak = 501.100006 pos = 34.9052,138.3189 diff = 333.100006'
});
data_saddle.push({
lat: 3.4933222209e+01,
lng: 1.3830311111e+02,
content:'Saddle = 168.000000 pos = 34.9332,138.3031 diff = 333.100006'
});
data_peak.push({
lat: 3.4922666653e+01,
lng: 1.3832600000e+02,
cert : true,
content:'Name = JA/SO-104(JA/SO-104) peak = 470.500000 pos = 34.9227,138.3260 diff = 193.000000'
});
data_saddle.push({
lat: 3.4908555542e+01,
lng: 1.3832566667e+02,
content:'Saddle = 277.500000 pos = 34.9086,138.3257 diff = 193.000000'
});
data_peak.push({
lat: 3.4962111098e+01,
lng: 1.3834077778e+02,
cert : true,
content:'Name = JA/SO-116(JA/SO-116) peak = 374.799988 pos = 34.9621,138.3408 diff = 204.299988'
});
data_saddle.push({
lat: 3.4961222209e+01,
lng: 1.3833433333e+02,
content:'Saddle = 170.500000 pos = 34.9612,138.3343 diff = 204.299988'
});
data_peak.push({
lat: 3.4702888874e+01,
lng: 1.3895522222e+02,
cert : true,
content:'Name = JA/SO-118(JA/SO-118) peak = 342.100006 pos = 34.7029,138.9552 diff = 165.600006'
});
data_saddle.push({
lat: 3.4721777763e+01,
lng: 1.3896755556e+02,
content:'Saddle = 176.500000 pos = 34.7218,138.9676 diff = 165.600006'
});
data_peak.push({
lat: 3.4732111096e+01,
lng: 1.3876955556e+02,
cert : false,
content:' Peak = 357.700012 pos = 34.7321,138.7696 diff = 170.000015'
});
data_saddle.push({
lat: 3.4727888874e+01,
lng: 1.3876866667e+02,
content:'Saddle = 187.699997 pos = 34.7279,138.7687 diff = 170.000015'
});
data_peak.push({
lat: 3.5583111103e+01,
lng: 1.3927866667e+02,
cert : true,
content:'Name = Shiroyama(JA/KN-022) peak = 374.100006 pos = 35.5831,139.2787 diff = 176.600006'
});
data_saddle.push({
lat: 3.5580222214e+01,
lng: 1.3927277778e+02,
content:'Saddle = 197.500000 pos = 35.5802,139.2728 diff = 176.600006'
});
data_peak.push({
lat: 3.4677333318e+01,
lng: 1.3881022222e+02,
cert : false,
content:' Peak = 352.899994 pos = 34.6773,138.8102 diff = 155.000000'
});
data_saddle.push({
lat: 3.4681555540e+01,
lng: 1.3879777778e+02,
content:'Saddle = 197.899994 pos = 34.6816,138.7978 diff = 155.000000'
});
data_peak.push({
lat: 3.6665777778e+01,
lng: 1.3985300000e+02,
cert : false,
content:' Peak = 411.200012 pos = 36.6658,139.8530 diff = 209.500015'
});
data_saddle.push({
lat: 3.6666666667e+01,
lng: 1.3983788889e+02,
content:'Saddle = 201.699997 pos = 36.6667,139.8379 diff = 209.500015'
});
data_peak.push({
lat: 3.6387444443e+01,
lng: 1.3950333333e+02,
cert : false,
content:' Peak = 370.700012 pos = 36.3874,139.5033 diff = 167.600006'
});
data_saddle.push({
lat: 3.6399666665e+01,
lng: 1.3948811111e+02,
content:'Saddle = 203.100006 pos = 36.3997,139.4881 diff = 167.600006'
});
data_peak.push({
lat: 3.5207777766e+01,
lng: 1.3853311111e+02,
cert : true,
content:'Name = JA/SO-087(JA/SO-087) peak = 566.799988 pos = 35.2078,138.5331 diff = 358.599976'
});
data_saddle.push({
lat: 3.5209222211e+01,
lng: 1.3851600000e+02,
content:'Saddle = 208.199997 pos = 35.2092,138.5160 diff = 358.599976'
});
data_peak.push({
lat: 3.5011777765e+01,
lng: 1.3892022222e+02,
cert : true,
content:'Name = JA/SO-108(JA/SO-108) peak = 451.000000 pos = 35.0118,138.9202 diff = 235.100006'
});
data_saddle.push({
lat: 3.5001222209e+01,
lng: 1.3889022222e+02,
content:'Saddle = 215.899994 pos = 35.0012,138.8902 diff = 235.100006'
});
data_peak.push({
lat: 3.6605111111e+01,
lng: 1.3980377778e+02,
cert : false,
content:' Peak = 376.500000 pos = 36.6051,139.8038 diff = 159.500000'
});
data_saddle.push({
lat: 3.6611111111e+01,
lng: 1.3980255556e+02,
content:'Saddle = 217.000000 pos = 36.6111,139.8026 diff = 159.500000'
});
data_peak.push({
lat: 3.6377555554e+01,
lng: 1.3943744444e+02,
cert : true,
content:'Name = JA/TG-080(JA/TG-080) peak = 440.799988 pos = 36.3776,139.4374 diff = 214.099991'
});
data_saddle.push({
lat: 3.6391999998e+01,
lng: 1.3944344444e+02,
content:'Saddle = 226.699997 pos = 36.3920,139.4434 diff = 214.099991'
});
data_peak.push({
lat: 3.6016999995e+01,
lng: 1.3925000000e+02,
cert : true,
content:'Name = Raidenyama(JA/ST-020) peak = 415.600006 pos = 36.0170,139.2500 diff = 186.800003'
});
data_saddle.push({
lat: 3.6022555551e+01,
lng: 1.3923900000e+02,
content:'Saddle = 228.800003 pos = 36.0226,139.2390 diff = 186.800003'
});
data_peak.push({
lat: 3.5611555547e+01,
lng: 1.3919866667e+02,
cert : false,
content:' Peak = 405.000000 pos = 35.6116,139.1987 diff = 171.300003'
});
data_saddle.push({
lat: 3.5601111103e+01,
lng: 1.3919844444e+02,
content:'Saddle = 233.699997 pos = 35.6011,139.1984 diff = 171.300003'
});
data_peak.push({
lat: 3.5556666658e+01,
lng: 1.3927400000e+02,
cert : true,
content:'Name = JA/KN-021(JA/KN-021) peak = 428.299988 pos = 35.5567,139.2740 diff = 194.399994'
});
data_saddle.push({
lat: 3.5553111103e+01,
lng: 1.3926288889e+02,
content:'Saddle = 233.899994 pos = 35.5531,139.2629 diff = 194.399994'
});
data_peak.push({
lat: 3.4953222209e+01,
lng: 1.3830088889e+02,
cert : true,
content:'Name = JA/SO-103(JA/SO-103) peak = 482.600006 pos = 34.9532,138.3009 diff = 247.900009'
});
data_saddle.push({
lat: 3.4976333320e+01,
lng: 1.3827622222e+02,
content:'Saddle = 234.699997 pos = 34.9763,138.2762 diff = 247.900009'
});
data_peak.push({
lat: 3.5093888877e+01,
lng: 1.3850155556e+02,
cert : false,
content:' Peak = 504.100006 pos = 35.0939,138.5016 diff = 266.299988'
});
data_saddle.push({
lat: 3.5092444432e+01,
lng: 1.3846144444e+02,
content:'Saddle = 237.800003 pos = 35.0924,138.4614 diff = 266.299988'
});
data_peak.push({
lat: 3.5091888877e+01,
lng: 1.3847988889e+02,
cert : false,
content:' Peak = 413.899994 pos = 35.0919,138.4799 diff = 157.399994'
});
data_saddle.push({
lat: 3.5093444432e+01,
lng: 1.3849044444e+02,
content:'Saddle = 256.500000 pos = 35.0934,138.4904 diff = 157.399994'
});
data_peak.push({
lat: 3.6409222220e+01,
lng: 1.3964244444e+02,
cert : false,
content:' Peak = 393.600006 pos = 36.4092,139.6424 diff = 155.200012'
});
data_saddle.push({
lat: 3.6425999998e+01,
lng: 1.3963644444e+02,
content:'Saddle = 238.399994 pos = 36.4260,139.6364 diff = 155.200012'
});
data_peak.push({
lat: 3.5006222209e+01,
lng: 1.3833866667e+02,
cert : true,
content:'Name = JA/SO-110(JA/SO-110) peak = 435.100006 pos = 35.0062,138.3387 diff = 193.000000'
});
data_saddle.push({
lat: 3.5012444432e+01,
lng: 1.3833988889e+02,
content:'Saddle = 242.100006 pos = 35.0124,138.3399 diff = 193.000000'
});
data_peak.push({
lat: 3.4892444431e+01,
lng: 1.3815877778e+02,
cert : true,
content:'Name = JA/SO-101(JA/SO-101) peak = 495.799988 pos = 34.8924,138.1588 diff = 253.699982'
});
data_saddle.push({
lat: 3.4908333320e+01,
lng: 1.3816611111e+02,
content:'Saddle = 242.100006 pos = 34.9083,138.1661 diff = 253.699982'
});
data_peak.push({
lat: 3.4742666652e+01,
lng: 1.3895788889e+02,
cert : false,
content:' Peak = 454.100006 pos = 34.7427,138.9579 diff = 211.400009'
});
data_saddle.push({
lat: 3.4758222207e+01,
lng: 1.3896511111e+02,
content:'Saddle = 242.699997 pos = 34.7582,138.9651 diff = 211.400009'
});
data_peak.push({
lat: 3.6617555555e+01,
lng: 1.3971677778e+02,
cert : true,
content:'Name = JA/TG-076(JA/TG-076) peak = 471.500000 pos = 36.6176,139.7168 diff = 225.100006'
});
data_saddle.push({
lat: 3.6642777778e+01,
lng: 1.3971100000e+02,
content:'Saddle = 246.399994 pos = 36.6428,139.7110 diff = 225.100006'
});
data_peak.push({
lat: 3.6410333332e+01,
lng: 1.3945700000e+02,
cert : true,
content:'Name = JA/TG-081(JA/TG-081) peak = 437.399994 pos = 36.4103,139.4570 diff = 189.799988'
});
data_saddle.push({
lat: 3.6416444443e+01,
lng: 1.3944766667e+02,
content:'Saddle = 247.600006 pos = 36.4164,139.4477 diff = 189.799988'
});
data_peak.push({
lat: 3.6621777778e+01,
lng: 1.3977144444e+02,
cert : true,
content:'Name = JA/TG-067(JA/TG-067) peak = 582.299988 pos = 36.6218,139.7714 diff = 332.500000'
});
data_saddle.push({
lat: 3.6666555556e+01,
lng: 1.3973533333e+02,
content:'Saddle = 249.800003 pos = 36.6666,139.7353 diff = 332.500000'
});
data_peak.push({
lat: 3.6666444445e+01,
lng: 1.3975711111e+02,
cert : false,
content:' Peak = 419.299988 pos = 36.6664,139.7571 diff = 164.999985'
});
data_saddle.push({
lat: 3.6655666667e+01,
lng: 1.3977344444e+02,
content:'Saddle = 254.300003 pos = 36.6557,139.7734 diff = 164.999985'
});
data_peak.push({
lat: 3.6657222222e+01,
lng: 1.3981777778e+02,
cert : false,
content:' Peak = 501.600006 pos = 36.6572,139.8178 diff = 163.800018'
});
data_saddle.push({
lat: 3.6643888889e+01,
lng: 1.3979288889e+02,
content:'Saddle = 337.799988 pos = 36.6439,139.7929 diff = 163.800018'
});
data_peak.push({
lat: 3.6641222222e+01,
lng: 1.3979222222e+02,
cert : false,
content:' Peak = 492.299988 pos = 36.6412,139.7922 diff = 154.199982'
});
data_saddle.push({
lat: 3.6640555556e+01,
lng: 1.3978033333e+02,
content:'Saddle = 338.100006 pos = 36.6406,139.7803 diff = 154.199982'
});
data_peak.push({
lat: 3.5120111099e+01,
lng: 1.3853344444e+02,
cert : true,
content:'Name = JA/SO-068(JA/SO-068) peak = 705.799988 pos = 35.1201,138.5334 diff = 448.899994'
});
data_saddle.push({
lat: 3.5146111099e+01,
lng: 1.3852177778e+02,
content:'Saddle = 256.899994 pos = 35.1461,138.5218 diff = 448.899994'
});
data_peak.push({
lat: 3.5144666655e+01,
lng: 1.3858933333e+02,
cert : true,
content:'Name = JA/SO-080(JA/SO-080) peak = 597.299988 pos = 35.1447,138.5893 diff = 240.799988'
});
data_saddle.push({
lat: 3.5151666655e+01,
lng: 1.3854355556e+02,
content:'Saddle = 356.500000 pos = 35.1517,138.5436 diff = 240.799988'
});
data_peak.push({
lat: 3.5161555544e+01,
lng: 1.3855400000e+02,
cert : true,
content:'Name = JA/SO-088(JA/SO-088) peak = 563.799988 pos = 35.1616,138.5540 diff = 186.699982'
});
data_saddle.push({
lat: 3.5156333322e+01,
lng: 1.3856811111e+02,
content:'Saddle = 377.100006 pos = 35.1563,138.5681 diff = 186.699982'
});
data_peak.push({
lat: 3.6067222218e+01,
lng: 1.3920077778e+02,
cert : false,
content:' Peak = 420.899994 pos = 36.0672,139.2008 diff = 163.699982'
});
data_saddle.push({
lat: 3.6085111107e+01,
lng: 1.3917222222e+02,
content:'Saddle = 257.200012 pos = 36.0851,139.1722 diff = 163.699982'
});
data_peak.push({
lat: 3.6583888889e+01,
lng: 1.3968255556e+02,
cert : true,
content:'Name = JA/TG-068(JA/TG-068) peak = 566.500000 pos = 36.5839,139.6826 diff = 308.000000'
});
data_saddle.push({
lat: 3.6598444444e+01,
lng: 1.3966733333e+02,
content:'Saddle = 258.500000 pos = 36.5984,139.6673 diff = 308.000000'
});
data_peak.push({
lat: 3.6444777776e+01,
lng: 1.3962244444e+02,
cert : false,
content:' Peak = 502.899994 pos = 36.4448,139.6224 diff = 239.899994'
});
data_saddle.push({
lat: 3.6455888888e+01,
lng: 1.3959944444e+02,
content:'Saddle = 263.000000 pos = 36.4559,139.5994 diff = 239.899994'
});
data_peak.push({
lat: 3.6137888885e+01,
lng: 1.3909544444e+02,
cert : true,
content:'Name = Fudousan(JA/ST-018) peak = 548.200012 pos = 36.1379,139.0954 diff = 282.000000'
});
data_saddle.push({
lat: 3.6110222218e+01,
lng: 1.3908200000e+02,
content:'Saddle = 266.200012 pos = 36.1102,139.0820 diff = 282.000000'
});
data_peak.push({
lat: 3.4707111096e+01,
lng: 1.3875177778e+02,
cert : true,
content:'Name = JA/SO-097(JA/SO-097) peak = 517.200012 pos = 34.7071,138.7518 diff = 246.500000'
});
data_saddle.push({
lat: 3.4707111096e+01,
lng: 1.3875833333e+02,
content:'Saddle = 270.700012 pos = 34.7071,138.7583 diff = 246.500000'
});
data_peak.push({
lat: 3.6093111107e+01,
lng: 1.3909155556e+02,
cert : true,
content:'Name = Hodosan(JA/ST-019) peak = 495.500000 pos = 36.0931,139.0916 diff = 219.200012'
});
data_saddle.push({
lat: 3.6110444440e+01,
lng: 1.3907866667e+02,
content:'Saddle = 276.299988 pos = 36.1104,139.0787 diff = 219.200012'
});
data_peak.push({
lat: 3.6057888884e+01,
lng: 1.3911266667e+02,
cert : true,
content:'Name = Minoyama(JA/ST-017) peak = 584.900024 pos = 36.0579,139.1127 diff = 306.900024'
});
data_saddle.push({
lat: 3.6033111106e+01,
lng: 1.3912766667e+02,
content:'Saddle = 278.000000 pos = 36.0331,139.1277 diff = 306.900024'
});
data_peak.push({
lat: 3.4795555541e+01,
lng: 1.3878155556e+02,
cert : false,
content:' Peak = 435.299988 pos = 34.7956,138.7816 diff = 154.799988'
});
data_saddle.push({
lat: 3.4798111096e+01,
lng: 1.3878444444e+02,
content:'Saddle = 280.500000 pos = 34.7981,138.7844 diff = 154.799988'
});
data_peak.push({
lat: 3.5520666658e+01,
lng: 1.3925800000e+02,
cert : true,
content:'Name = Bukkasan(JA/KN-017) peak = 744.799988 pos = 35.5207,139.2580 diff = 446.899994'
});
data_saddle.push({
lat: 3.5503777769e+01,
lng: 1.3925633333e+02,
content:'Saddle = 297.899994 pos = 35.5038,139.2563 diff = 446.899994'
});
data_peak.push({
lat: 3.5618888881e+01,
lng: 1.3908522222e+02,
cert : false,
content:' Peak = 462.100006 pos = 35.6189,139.0852 diff = 160.800018'
});
data_saddle.push({
lat: 3.5622999992e+01,
lng: 1.3907188889e+02,
content:'Saddle = 301.299988 pos = 35.6230,139.0719 diff = 160.800018'
});
data_peak.push({
lat: 3.5475444435e+01,
lng: 1.3846300000e+02,
cert : true,
content:'Name = JA/YN-072(JA/YN-072) peak = 471.200012 pos = 35.4754,138.4630 diff = 168.600006'
});
data_saddle.push({
lat: 3.5470888880e+01,
lng: 1.3846711111e+02,
content:'Saddle = 302.600006 pos = 35.4709,138.4671 diff = 168.600006'
});
data_peak.push({
lat: 3.6408555554e+01,
lng: 1.3941266667e+02,
cert : true,
content:'Name = JA/TG-072(JA/TG-072) peak = 504.500000 pos = 36.4086,139.4127 diff = 193.299988'
});
data_saddle.push({
lat: 3.6412777776e+01,
lng: 1.3942322222e+02,
content:'Saddle = 311.200012 pos = 36.4128,139.4232 diff = 193.299988'
});
data_peak.push({
lat: 3.4703555540e+01,
lng: 1.3885511111e+02,
cert : true,
content:'Name = JA/SO-092(JA/SO-092) peak = 543.099976 pos = 34.7036,138.8551 diff = 231.099976'
});
data_saddle.push({
lat: 3.4731444429e+01,
lng: 1.3885788889e+02,
content:'Saddle = 312.000000 pos = 34.7314,138.8579 diff = 231.099976'
});
data_peak.push({
lat: 3.4716444429e+01,
lng: 1.3877722222e+02,
cert : false,
content:' Peak = 521.799988 pos = 34.7164,138.7772 diff = 183.099976'
});
data_saddle.push({
lat: 3.4704999985e+01,
lng: 1.3880122222e+02,
content:'Saddle = 338.700012 pos = 34.7050,138.8012 diff = 183.099976'
});
data_peak.push({
lat: 3.5634333325e+01,
lng: 1.3913177778e+02,
cert : false,
content:' Peak = 471.600006 pos = 35.6343,139.1318 diff = 154.700012'
});
data_saddle.push({
lat: 3.5639555548e+01,
lng: 1.3913200000e+02,
content:'Saddle = 316.899994 pos = 35.6396,139.1320 diff = 154.700012'
});
data_peak.push({
lat: 3.5561666658e+01,
lng: 1.3922533333e+02,
cert : true,
content:'Name = Sendoujiyama(JA/KN-019) peak = 582.299988 pos = 35.5617,139.2253 diff = 264.199982'
});
data_saddle.push({
lat: 3.5555111103e+01,
lng: 1.3921111111e+02,
content:'Saddle = 318.100006 pos = 35.5551,139.2111 diff = 264.199982'
});
data_peak.push({
lat: 3.5545777769e+01,
lng: 1.3923555556e+02,
cert : true,
content:'Name = JA/KN-020(JA/KN-020) peak = 567.900024 pos = 35.5458,139.2356 diff = 246.800018'
});
data_saddle.push({
lat: 3.5538222214e+01,
lng: 1.3922011111e+02,
content:'Saddle = 321.100006 pos = 35.5382,139.2201 diff = 246.800018'
});
data_peak.push({
lat: 3.4857777764e+01,
lng: 1.3806788889e+02,
cert : true,
content:'Name = JA/SO-081(JA/SO-081) peak = 584.799988 pos = 34.8578,138.0679 diff = 262.599976'
});
data_saddle.push({
lat: 3.4860555541e+01,
lng: 1.3804722222e+02,
content:'Saddle = 322.200012 pos = 34.8606,138.0472 diff = 262.599976'
});
data_peak.push({
lat: 3.5017333320e+01,
lng: 1.3829800000e+02,
cert : true,
content:'Name = JA/SO-102(JA/SO-102) peak = 493.200012 pos = 35.0173,138.2980 diff = 170.900024'
});
data_saddle.push({
lat: 3.5036111098e+01,
lng: 1.3830044444e+02,
content:'Saddle = 322.299988 pos = 35.0361,138.3004 diff = 170.900024'
});
data_peak.push({
lat: 3.6461222221e+01,
lng: 1.3962111111e+02,
cert : true,
content:'Name = JA/TG-064(JA/TG-064) peak = 604.000000 pos = 36.4612,139.6211 diff = 280.299988'
});
data_saddle.push({
lat: 3.6484555554e+01,
lng: 1.3959566667e+02,
content:'Saddle = 323.700012 pos = 36.4846,139.5957 diff = 280.299988'
});
data_peak.push({
lat: 3.5815666660e+01,
lng: 1.3921522222e+02,
cert : false,
content:' Peak = 492.899994 pos = 35.8157,139.2152 diff = 165.699982'
});
data_saddle.push({
lat: 3.5820999994e+01,
lng: 1.3920955556e+02,
content:'Saddle = 327.200012 pos = 35.8210,139.2096 diff = 165.699982'
});
data_peak.push({
lat: 3.6486222221e+01,
lng: 1.3964277778e+02,
cert : false,
content:' Peak = 599.000000 pos = 36.4862,139.6428 diff = 271.399994'
});
data_saddle.push({
lat: 3.6495888888e+01,
lng: 1.3961744444e+02,
content:'Saddle = 327.600006 pos = 36.4959,139.6174 diff = 271.399994'
});
data_peak.push({
lat: 3.6656222222e+01,
lng: 1.3964133333e+02,
cert : true,
content:'Name = JA/TG-056(JA/TG-056) peak = 797.700012 pos = 36.6562,139.6413 diff = 468.000000'
});
data_saddle.push({
lat: 3.6666666667e+01,
lng: 1.3962600000e+02,
content:'Saddle = 329.700012 pos = 36.6667,139.6260 diff = 468.000000'
});
data_peak.push({
lat: 3.4864222208e+01,
lng: 1.3800511111e+02,
cert : true,
content:'Name = JA/SO-098(JA/SO-098) peak = 506.600006 pos = 34.8642,138.0051 diff = 173.300018'
});
data_saddle.push({
lat: 3.4875666653e+01,
lng: 1.3800677778e+02,
content:'Saddle = 333.299988 pos = 34.8757,138.0068 diff = 173.300018'
});
data_peak.push({
lat: 3.6649444445e+01,
lng: 1.3932744444e+02,
cert : false,
content:' Peak = 1960.800049 pos = 36.6494,139.3274 diff = 1616.900024'
});
data_saddle.push({
lat: 3.6666666667e+01,
lng: 1.3900866667e+02,
content:'Saddle = 343.899994 pos = 36.6667,139.0087 diff = 1616.900024'
});
data_peak.push({
lat: 3.6608333333e+01,
lng: 1.3968700000e+02,
cert : true,
content:'Name = JA/TG-070(JA/TG-070) peak = 555.200012 pos = 36.6083,139.6870 diff = 198.100006'
});
data_saddle.push({
lat: 3.6616666667e+01,
lng: 1.3968177778e+02,
content:'Saddle = 357.100006 pos = 36.6167,139.6818 diff = 198.100006'
});
data_peak.push({
lat: 3.6482666666e+01,
lng: 1.3955322222e+02,
cert : false,
content:' Peak = 533.000000 pos = 36.4827,139.5532 diff = 165.399994'
});
data_saddle.push({
lat: 3.6486888888e+01,
lng: 1.3955333333e+02,
content:'Saddle = 367.600006 pos = 36.4869,139.5533 diff = 165.399994'
});
data_peak.push({
lat: 3.6436999998e+01,
lng: 1.3940255556e+02,
cert : false,
content:' Peak = 662.700012 pos = 36.4370,139.4026 diff = 274.800018'
});
data_saddle.push({
lat: 3.6450444443e+01,
lng: 1.3944266667e+02,
content:'Saddle = 387.899994 pos = 36.4504,139.4427 diff = 274.800018'
});
data_peak.push({
lat: 3.6632333333e+01,
lng: 1.3964555556e+02,
cert : false,
content:' Peak = 775.900024 pos = 36.6323,139.6456 diff = 369.700012'
});
data_saddle.push({
lat: 3.6643888889e+01,
lng: 1.3962111111e+02,
content:'Saddle = 406.200012 pos = 36.6439,139.6211 diff = 369.700012'
});
data_peak.push({
lat: 3.6525999999e+01,
lng: 1.3957411111e+02,
cert : false,
content:' Peak = 601.400024 pos = 36.5260,139.5741 diff = 158.200012'
});
data_saddle.push({
lat: 3.6527222221e+01,
lng: 1.3956711111e+02,
content:'Saddle = 443.200012 pos = 36.5272,139.5671 diff = 158.200012'
});
data_peak.push({
lat: 3.6664000000e+01,
lng: 1.3958777778e+02,
cert : false,
content:' Peak = 951.599976 pos = 36.6640,139.5878 diff = 505.499969'
});
data_saddle.push({
lat: 3.6666666667e+01,
lng: 1.3956488889e+02,
content:'Saddle = 446.100006 pos = 36.6667,139.5649 diff = 505.499969'
});
data_peak.push({
lat: 3.6487555554e+01,
lng: 1.3951266667e+02,
cert : true,
content:'Name = JA/TG-060(JA/TG-060) peak = 701.500000 pos = 36.4876,139.5127 diff = 254.500000'
});
data_saddle.push({
lat: 3.6495555555e+01,
lng: 1.3950800000e+02,
content:'Saddle = 447.000000 pos = 36.4956,139.5080 diff = 254.500000'
});
data_peak.push({
lat: 3.6551777777e+01,
lng: 1.3959322222e+02,
cert : true,
content:'Name = JA/TG-061(JA/TG-061) peak = 671.200012 pos = 36.5518,139.5932 diff = 218.400024'
});
data_saddle.push({
lat: 3.6565666666e+01,
lng: 1.3958366667e+02,
content:'Saddle = 452.799988 pos = 36.5657,139.5837 diff = 218.400024'
});
data_peak.push({
lat: 3.6454777776e+01,
lng: 1.3944411111e+02,
cert : false,
content:' Peak = 607.000000 pos = 36.4548,139.4441 diff = 150.100006'
});
data_saddle.push({
lat: 3.6462111110e+01,
lng: 1.3943744444e+02,
content:'Saddle = 456.899994 pos = 36.4621,139.4374 diff = 150.100006'
});
data_peak.push({
lat: 3.6611777778e+01,
lng: 1.3962388889e+02,
cert : true,
content:'Name = JA/TG-059(JA/TG-059) peak = 722.200012 pos = 36.6118,139.6239 diff = 200.400024'
});
data_saddle.push({
lat: 3.6612555555e+01,
lng: 1.3961055556e+02,
content:'Saddle = 521.799988 pos = 36.6126,139.6106 diff = 200.400024'
});
data_peak.push({
lat: 3.6666666667e+01,
lng: 1.3917033333e+02,
cert : false,
content:' Peak = 897.799988 pos = 36.6667,139.1703 diff = 339.200012'
});
data_saddle.push({
lat: 3.6666444445e+01,
lng: 1.3920755556e+02,
content:'Saddle = 558.599976 pos = 36.6664,139.2076 diff = 339.200012'
});
data_peak.push({
lat: 3.6557444444e+01,
lng: 1.3954466667e+02,
cert : true,
content:'Name = JA/TG-058(JA/TG-058) peak = 747.099976 pos = 36.5574,139.5447 diff = 176.699951'
});
data_saddle.push({
lat: 3.6563888888e+01,
lng: 1.3953388889e+02,
content:'Saddle = 570.400024 pos = 36.5639,139.5339 diff = 176.699951'
});
data_peak.push({
lat: 3.6624777778e+01,
lng: 1.3959466667e+02,
cert : true,
content:'Name = JA/TG-055(JA/TG-055) peak = 810.500000 pos = 36.6248,139.5947 diff = 197.900024'
});
data_saddle.push({
lat: 3.6625555556e+01,
lng: 1.3958188889e+02,
content:'Saddle = 612.599976 pos = 36.6256,139.5819 diff = 197.900024'
});
data_peak.push({
lat: 3.6631222222e+01,
lng: 1.3950833333e+02,
cert : true,
content:'Name = JA/TG-032(JA/TG-032) peak = 1387.599976 pos = 36.6312,139.5083 diff = 707.500000'
});
data_saddle.push({
lat: 3.6666666667e+01,
lng: 1.3944533333e+02,
content:'Saddle = 680.099976 pos = 36.6667,139.4453 diff = 707.500000'
});
data_peak.push({
lat: 3.6601000000e+01,
lng: 1.3958033333e+02,
cert : false,
content:' Peak = 891.000000 pos = 36.6010,139.5803 diff = 208.400024'
});
data_saddle.push({
lat: 3.6609888889e+01,
lng: 1.3957066667e+02,
content:'Saddle = 682.599976 pos = 36.6099,139.5707 diff = 208.400024'
});
data_peak.push({
lat: 3.6666666667e+01,
lng: 1.3945944444e+02,
cert : false,
content:' Peak = 951.099976 pos = 36.6667,139.4594 diff = 238.399963'
});
data_saddle.push({
lat: 3.6666666667e+01,
lng: 1.3947244444e+02,
content:'Saddle = 712.700012 pos = 36.6667,139.4724 diff = 238.399963'
});
data_peak.push({
lat: 3.6555111111e+01,
lng: 1.3952011111e+02,
cert : true,
content:'Name = JA/TG-052(JA/TG-052) peak = 932.000000 pos = 36.5551,139.5201 diff = 210.000000'
});
data_saddle.push({
lat: 3.6556444444e+01,
lng: 1.3951244444e+02,
content:'Saddle = 722.000000 pos = 36.5564,139.5124 diff = 210.000000'
});
data_peak.push({
lat: 3.6623444444e+01,
lng: 1.3955311111e+02,
cert : false,
content:' Peak = 1070.000000 pos = 36.6234,139.5531 diff = 200.900024'
});
data_saddle.push({
lat: 3.6624000000e+01,
lng: 1.3954100000e+02,
content:'Saddle = 869.099976 pos = 36.6240,139.5410 diff = 200.900024'
});
data_peak.push({
lat: 3.6666000000e+01,
lng: 1.3953033333e+02,
cert : false,
content:' Peak = 1221.500000 pos = 36.6660,139.5303 diff = 333.400024'
});
data_saddle.push({
lat: 3.6666666667e+01,
lng: 1.3952177778e+02,
content:'Saddle = 888.099976 pos = 36.6667,139.5218 diff = 333.400024'
});
data_peak.push({
lat: 3.6523777777e+01,
lng: 1.3940155556e+02,
cert : true,
content:'Name = JA/GM-063(JA/GM-063) peak = 1106.300049 pos = 36.5238,139.4016 diff = 165.500061'
});
data_saddle.push({
lat: 3.6531444444e+01,
lng: 1.3941277778e+02,
content:'Saddle = 940.799988 pos = 36.5314,139.4128 diff = 165.500061'
});
data_peak.push({
lat: 3.6549777777e+01,
lng: 1.3945088889e+02,
cert : true,
content:'Name = JA/TG-043(JA/TG-043) peak = 1198.400024 pos = 36.5498,139.4509 diff = 240.600037'
});
data_saddle.push({
lat: 3.6580777777e+01,
lng: 1.3948255556e+02,
content:'Saddle = 957.799988 pos = 36.5808,139.4826 diff = 240.600037'
});
data_peak.push({
lat: 3.6608777778e+01,
lng: 1.3946522222e+02,
cert : false,
content:' Peak = 1272.800049 pos = 36.6088,139.4652 diff = 164.400024'
});
data_saddle.push({
lat: 3.6615888889e+01,
lng: 1.3947222222e+02,
content:'Saddle = 1108.400024 pos = 36.6159,139.4722 diff = 164.400024'
});
data_peak.push({
lat: 3.6664444445e+01,
lng: 1.3949955556e+02,
cert : false,
content:' Peak = 1334.300049 pos = 36.6644,139.4996 diff = 192.600098'
});
data_saddle.push({
lat: 3.6650444445e+01,
lng: 1.3950177778e+02,
content:'Saddle = 1141.699951 pos = 36.6504,139.5018 diff = 192.600098'
});
data_peak.push({
lat: 3.6647777778e+01,
lng: 1.3919366667e+02,
cert : false,
content:' Peak = 994.099976 pos = 36.6478,139.1937 diff = 168.899963'
});
data_saddle.push({
lat: 3.6652000000e+01,
lng: 1.3920711111e+02,
content:'Saddle = 825.200012 pos = 36.6520,139.2071 diff = 168.899963'
});
data_peak.push({
lat: 3.6560444444e+01,
lng: 1.3919322222e+02,
cert : true,
content:'Name = Akagisan (Kurobisan)(JA/GM-023) peak = 1827.199951 pos = 36.5604,139.1932 diff = 804.699951'
});
data_saddle.push({
lat: 3.6582000000e+01,
lng: 1.3923355556e+02,
content:'Saddle = 1022.500000 pos = 36.5820,139.2336 diff = 804.699951'
});
data_peak.push({
lat: 3.6540999999e+01,
lng: 1.3917722222e+02,
cert : true,
content:'Name = Akagisan (Jizoudake)(JA/GM-026) peak = 1672.800049 pos = 36.5410,139.1772 diff = 282.400024'
});
data_saddle.push({
lat: 3.6540888888e+01,
lng: 1.3919300000e+02,
content:'Saddle = 1390.400024 pos = 36.5409,139.1930 diff = 282.400024'
});
data_peak.push({
lat: 3.6525888888e+01,
lng: 1.3916544444e+02,
cert : false,
content:' Peak = 1571.800049 pos = 36.5259,139.1654 diff = 159.400024'
});
data_saddle.push({
lat: 3.6534222221e+01,
lng: 1.3917088889e+02,
content:'Saddle = 1412.400024 pos = 36.5342,139.1709 diff = 159.400024'
});
data_peak.push({
lat: 3.6655777778e+01,
lng: 1.3942722222e+02,
cert : true,
content:'Name = JA/TG-040(JA/TG-040) peak = 1270.599976 pos = 36.6558,139.4272 diff = 237.599976'
});
data_saddle.push({
lat: 3.6660444445e+01,
lng: 1.3941877778e+02,
content:'Saddle = 1033.000000 pos = 36.6604,139.4188 diff = 237.599976'
});
data_peak.push({
lat: 3.6633000000e+01,
lng: 1.3921122222e+02,
cert : true,
content:'Name = JA/GM-050(JA/GM-050) peak = 1270.800049 pos = 36.6330,139.2112 diff = 233.200073'
});
data_saddle.push({
lat: 3.6641111111e+01,
lng: 1.3921722222e+02,
content:'Saddle = 1037.599976 pos = 36.6411,139.2172 diff = 233.200073'
});
data_peak.push({
lat: 3.6666000000e+01,
lng: 1.3941088889e+02,
cert : false,
content:' Peak = 1250.699951 pos = 36.6660,139.4109 diff = 152.099976'
});
data_saddle.push({
lat: 3.6666666667e+01,
lng: 1.3940644444e+02,
content:'Saddle = 1098.599976 pos = 36.6667,139.4064 diff = 152.099976'
});
data_peak.push({
lat: 3.6666555556e+01,
lng: 1.3939388889e+02,
cert : false,
content:' Peak = 1454.500000 pos = 36.6666,139.3939 diff = 150.099976'
});
data_saddle.push({
lat: 3.6666666667e+01,
lng: 1.3939088889e+02,
content:'Saddle = 1304.400024 pos = 36.6667,139.3909 diff = 150.099976'
});
data_peak.push({
lat: 3.6666666667e+01,
lng: 1.3936388889e+02,
cert : false,
content:' Peak = 1630.000000 pos = 36.6667,139.3639 diff = 197.099976'
});
data_saddle.push({
lat: 3.6666666667e+01,
lng: 1.3935266667e+02,
content:'Saddle = 1432.900024 pos = 36.6667,139.3527 diff = 197.099976'
});
data_peak.push({
lat: 3.4893888875e+01,
lng: 1.3812988889e+02,
cert : true,
content:'Name = JA/SO-086(JA/SO-086) peak = 567.700012 pos = 34.8939,138.1299 diff = 219.900024'
});
data_saddle.push({
lat: 3.4902888875e+01,
lng: 1.3813911111e+02,
content:'Saddle = 347.799988 pos = 34.9029,138.1391 diff = 219.900024'
});
data_peak.push({
lat: 3.4903111097e+01,
lng: 1.3909466667e+02,
cert : true,
content:'Name = Oomuroyama(JA/SO-082) peak = 580.000000 pos = 34.9031,139.0947 diff = 227.899994'
});
data_saddle.push({
lat: 3.4905999986e+01,
lng: 1.3908066667e+02,
content:'Saddle = 352.100006 pos = 34.9060,139.0807 diff = 227.899994'
});
data_peak.push({
lat: 3.4796666652e+01,
lng: 1.3881711111e+02,
cert : true,
content:'Name = JA/SO-093(JA/SO-093) peak = 544.799988 pos = 34.7967,138.8171 diff = 191.899994'
});
data_saddle.push({
lat: 3.4795222208e+01,
lng: 1.3882555556e+02,
content:'Saddle = 352.899994 pos = 34.7952,138.8256 diff = 191.899994'
});
data_peak.push({
lat: 3.5137888877e+01,
lng: 1.3815000000e+02,
cert : false,
content:' Peak = 523.900024 pos = 35.1379,138.1500 diff = 170.600037'
});
data_saddle.push({
lat: 3.5141555544e+01,
lng: 1.3814733333e+02,
content:'Saddle = 353.299988 pos = 35.1416,138.1473 diff = 170.600037'
});
data_peak.push({
lat: 3.5437444435e+01,
lng: 1.3846244444e+02,
cert : true,
content:'Name = JA/YN-070(JA/YN-070) peak = 635.700012 pos = 35.4374,138.4624 diff = 282.400024'
});
data_saddle.push({
lat: 3.5464555546e+01,
lng: 1.3847788889e+02,
content:'Saddle = 353.299988 pos = 35.4646,138.4779 diff = 282.400024'
});
data_peak.push({
lat: 3.4862888875e+01,
lng: 1.3900166667e+02,
cert : true,
content:'Name = Amagisan (Banzaburoudake)(JA/SO-030) peak = 1404.699951 pos = 34.8629,139.0017 diff = 1046.799927'
});
data_saddle.push({
lat: 3.4951999987e+01,
lng: 1.3905355556e+02,
content:'Saddle = 357.899994 pos = 34.9520,139.0536 diff = 1046.799927'
});
data_peak.push({
lat: 3.4737888874e+01,
lng: 1.3885944444e+02,
cert : true,
content:'Name = JA/SO-079(JA/SO-079) peak = 606.799988 pos = 34.7379,138.8594 diff = 195.099976'
});
data_saddle.push({
lat: 3.4742444429e+01,
lng: 1.3887044444e+02,
content:'Saddle = 411.700012 pos = 34.7424,138.8704 diff = 195.099976'
});
data_peak.push({
lat: 3.4927888875e+01,
lng: 1.3896444444e+02,
cert : true,
content:'Name = JA/SO-078(JA/SO-078) peak = 607.500000 pos = 34.9279,138.9644 diff = 190.000000'
});
data_saddle.push({
lat: 3.4909111097e+01,
lng: 1.3895300000e+02,
content:'Saddle = 417.500000 pos = 34.9091,138.9530 diff = 190.000000'
});
data_peak.push({
lat: 3.4817333319e+01,
lng: 1.3879433333e+02,
cert : true,
content:'Name = JA/SO-069(JA/SO-069) peak = 702.599976 pos = 34.8173,138.7943 diff = 216.299988'
});
data_saddle.push({
lat: 3.4822222208e+01,
lng: 1.3881688889e+02,
content:'Saddle = 486.299988 pos = 34.8222,138.8169 diff = 216.299988'
});
data_peak.push({
lat: 3.4955111098e+01,
lng: 1.3883922222e+02,
cert : true,
content:'Name = Darumayama(JA/SO-051) peak = 981.000000 pos = 34.9551,138.8392 diff = 403.099976'
});
data_saddle.push({
lat: 3.4922111097e+01,
lng: 1.3884144444e+02,
content:'Saddle = 577.900024 pos = 34.9221,138.8414 diff = 403.099976'
});
data_peak.push({
lat: 3.4894888875e+01,
lng: 1.3905722222e+02,
cert : false,
content:' Peak = 815.000000 pos = 34.8949,139.0572 diff = 153.099976'
});
data_saddle.push({
lat: 3.4894444431e+01,
lng: 1.3905344444e+02,
content:'Saddle = 661.900024 pos = 34.8944,139.0534 diff = 153.099976'
});
data_peak.push({
lat: 3.4788444430e+01,
lng: 1.3886800000e+02,
cert : true,
content:'Name = Chyoukurouyama(JA/SO-050) peak = 995.299988 pos = 34.7884,138.8680 diff = 263.200012'
});
data_saddle.push({
lat: 3.4807666652e+01,
lng: 1.3888144444e+02,
content:'Saddle = 732.099976 pos = 34.8077,138.8814 diff = 263.200012'
});
data_peak.push({
lat: 3.4884555542e+01,
lng: 1.3884033333e+02,
cert : false,
content:' Peak = 932.599976 pos = 34.8846,138.8403 diff = 160.000000'
});
data_saddle.push({
lat: 3.4872666653e+01,
lng: 1.3883488889e+02,
content:'Saddle = 772.599976 pos = 34.8727,138.8349 diff = 160.000000'
});
data_peak.push({
lat: 3.4857777764e+01,
lng: 1.3886366667e+02,
cert : true,
content:'Name = JA/SO-047(JA/SO-047) peak = 1035.500000 pos = 34.8578,138.8637 diff = 212.900024'
});
data_saddle.push({
lat: 3.4831777763e+01,
lng: 1.3890811111e+02,
content:'Saddle = 822.599976 pos = 34.8318,138.9081 diff = 212.900024'
});
data_peak.push({
lat: 3.4878888875e+01,
lng: 1.3903244444e+02,
cert : true,
content:'Name = JA/SO-038(JA/SO-038) peak = 1196.300049 pos = 34.8789,139.0324 diff = 177.900024'
});
data_saddle.push({
lat: 3.4874555542e+01,
lng: 1.3902644444e+02,
content:'Saddle = 1018.400024 pos = 34.8746,139.0264 diff = 177.900024'
});
data_peak.push({
lat: 3.4992777765e+01,
lng: 1.3827244444e+02,
cert : true,
content:'Name = JA/SO-090(JA/SO-090) peak = 561.000000 pos = 34.9928,138.2724 diff = 198.399994'
});
data_saddle.push({
lat: 3.4998555543e+01,
lng: 1.3826477778e+02,
content:'Saddle = 362.600006 pos = 34.9986,138.2648 diff = 198.399994'
});
data_peak.push({
lat: 3.5519888880e+01,
lng: 1.3847311111e+02,
cert : true,
content:'Name = JA/YN-071(JA/YN-071) peak = 551.900024 pos = 35.5199,138.4731 diff = 189.100037'
});
data_saddle.push({
lat: 3.5519111102e+01,
lng: 1.3848322222e+02,
content:'Saddle = 362.799988 pos = 35.5191,138.4832 diff = 189.100037'
});
data_peak.push({
lat: 3.5585222214e+01,
lng: 1.3919066667e+02,
cert : true,
content:'Name = Sekirouzan(JA/KN-018) peak = 701.299988 pos = 35.5852,139.1907 diff = 329.599976'
});
data_saddle.push({
lat: 3.5561888880e+01,
lng: 1.3915122222e+02,
content:'Saddle = 371.700012 pos = 35.5619,139.1512 diff = 329.599976'
});
data_peak.push({
lat: 3.5572666658e+01,
lng: 1.3916933333e+02,
cert : false,
content:' Peak = 577.700012 pos = 35.5727,139.1693 diff = 165.700012'
});
data_saddle.push({
lat: 3.5576666658e+01,
lng: 1.3917655556e+02,
content:'Saddle = 412.000000 pos = 35.5767,139.1766 diff = 165.700012'
});
data_peak.push({
lat: 3.5129333321e+01,
lng: 1.3848933333e+02,
cert : false,
content:' Peak = 530.799988 pos = 35.1293,138.4893 diff = 157.500000'
});
data_saddle.push({
lat: 3.5135333321e+01,
lng: 1.3849044444e+02,
content:'Saddle = 373.299988 pos = 35.1353,138.4904 diff = 157.500000'
});
data_peak.push({
lat: 3.5346999990e+01,
lng: 1.3843033333e+02,
cert : false,
content:' Peak = 537.799988 pos = 35.3470,138.4303 diff = 164.500000'
});
data_saddle.push({
lat: 3.5329333323e+01,
lng: 1.3843100000e+02,
content:'Saddle = 373.299988 pos = 35.3293,138.4310 diff = 164.500000'
});
data_peak.push({
lat: 3.5976222217e+01,
lng: 1.3899300000e+02,
cert : true,
content:'Name = JA/ST-016(JA/ST-016) peak = 643.200012 pos = 35.9762,138.9930 diff = 264.800018'
});
data_saddle.push({
lat: 3.5979111106e+01,
lng: 1.3897566667e+02,
content:'Saddle = 378.399994 pos = 35.9791,138.9757 diff = 264.800018'
});
data_peak.push({
lat: 3.5660222215e+01,
lng: 1.3909855556e+02,
cert : false,
content:' Peak = 541.000000 pos = 35.6602,139.0986 diff = 158.299988'
});
data_saddle.push({
lat: 3.5665888881e+01,
lng: 1.3910411111e+02,
content:'Saddle = 382.700012 pos = 35.6659,139.1041 diff = 158.299988'
});
data_peak.push({
lat: 3.5004777765e+01,
lng: 1.3825833333e+02,
cert : true,
content:'Name = JA/SO-085(JA/SO-085) peak = 573.599976 pos = 35.0048,138.2583 diff = 180.799988'
});
data_saddle.push({
lat: 3.5012111098e+01,
lng: 1.3824311111e+02,
content:'Saddle = 392.799988 pos = 35.0121,138.2431 diff = 180.799988'
});
data_peak.push({
lat: 3.5870999994e+01,
lng: 1.3919688889e+02,
cert : false,
content:' Peak = 552.299988 pos = 35.8710,139.1969 diff = 151.399994'
});
data_saddle.push({
lat: 3.5876666661e+01,
lng: 1.3919666667e+02,
content:'Saddle = 400.899994 pos = 35.8767,139.1967 diff = 151.399994'
});
data_peak.push({
lat: 3.5132444433e+01,
lng: 1.3842344444e+02,
cert : false,
content:' Peak = 562.900024 pos = 35.1324,138.4234 diff = 161.700012'
});
data_saddle.push({
lat: 3.5133555544e+01,
lng: 1.3841633333e+02,
content:'Saddle = 401.200012 pos = 35.1336,138.4163 diff = 161.700012'
});
data_peak.push({
lat: 3.4881999986e+01,
lng: 1.3807788889e+02,
cert : true,
content:'Name = JA/SO-074(JA/SO-074) peak = 669.500000 pos = 34.8820,138.0779 diff = 261.600006'
});
data_saddle.push({
lat: 3.4890111097e+01,
lng: 1.3807033333e+02,
content:'Saddle = 407.899994 pos = 34.8901,138.0703 diff = 261.600006'
});
data_peak.push({
lat: 3.5608333325e+01,
lng: 1.3904511111e+02,
cert : false,
content:' Peak = 565.700012 pos = 35.6083,139.0451 diff = 153.900024'
});
data_saddle.push({
lat: 3.5614999992e+01,
lng: 1.3903400000e+02,
content:'Saddle = 411.799988 pos = 35.6150,139.0340 diff = 153.900024'
});
data_peak.push({
lat: 3.5446999991e+01,
lng: 1.3842744444e+02,
cert : false,
content:' Peak = 643.900024 pos = 35.4470,138.4274 diff = 230.600037'
});
data_saddle.push({
lat: 3.5456777768e+01,
lng: 1.3841900000e+02,
content:'Saddle = 413.299988 pos = 35.4568,138.4190 diff = 230.600037'
});
data_peak.push({
lat: 3.4971777765e+01,
lng: 1.3905955556e+02,
cert : false,
content:' Peak = 593.400024 pos = 34.9718,139.0596 diff = 161.700012'
});
data_saddle.push({
lat: 3.5016999987e+01,
lng: 1.3904533333e+02,
content:'Saddle = 431.700012 pos = 35.0170,139.0453 diff = 161.700012'
});
data_peak.push({
lat: 3.6133222218e+01,
lng: 1.3906033333e+02,
cert : false,
content:' Peak = 592.700012 pos = 36.1332,139.0603 diff = 160.900024'
});
data_saddle.push({
lat: 3.6123666663e+01,
lng: 1.3905288889e+02,
content:'Saddle = 431.799988 pos = 36.1237,139.0529 diff = 160.900024'
});
data_peak.push({
lat: 3.4953999987e+01,
lng: 1.3818288889e+02,
cert : false,
content:' Peak = 690.500000 pos = 34.9540,138.1829 diff = 257.200012'
});
data_saddle.push({
lat: 3.4974999987e+01,
lng: 1.3819500000e+02,
content:'Saddle = 433.299988 pos = 34.9750,138.1950 diff = 257.200012'
});
data_peak.push({
lat: 3.4941555542e+01,
lng: 1.3816022222e+02,
cert : true,
content:'Name = JA/SO-070(JA/SO-070) peak = 690.299988 pos = 34.9416,138.1602 diff = 212.599976'
});
data_saddle.push({
lat: 3.4949222209e+01,
lng: 1.3817166667e+02,
content:'Saddle = 477.700012 pos = 34.9492,138.1717 diff = 212.599976'
});
data_peak.push({
lat: 3.5233444433e+01,
lng: 1.3902077778e+02,
cert : false,
content:' Peak = 1437.400024 pos = 35.2334,139.0208 diff = 991.100037'
});
data_saddle.push({
lat: 3.5293888878e+01,
lng: 1.3894088889e+02,
content:'Saddle = 446.299988 pos = 35.2939,138.9409 diff = 991.100037'
});
data_peak.push({
lat: 3.5081777765e+01,
lng: 1.3902800000e+02,
cert : true,
content:'Name = Kurotake(JA/SO-061) peak = 797.299988 pos = 35.0818,139.0280 diff = 180.299988'
});
data_saddle.push({
lat: 3.5101222210e+01,
lng: 1.3903500000e+02,
content:'Saddle = 617.000000 pos = 35.1012,139.0350 diff = 180.299988'
});
data_peak.push({
lat: 3.5328666656e+01,
lng: 1.3903533333e+02,
cert : true,
content:'Name = Yaguradake(JA/KN-016) peak = 869.000000 pos = 35.3287,139.0353 diff = 217.000000'
});
data_saddle.push({
lat: 3.5331999990e+01,
lng: 1.3902822222e+02,
content:'Saddle = 652.000000 pos = 35.3320,139.0282 diff = 217.000000'
});
data_peak.push({
lat: 3.5289777767e+01,
lng: 1.3900477778e+02,
cert : true,
content:'Name = Hakoneyama (Kintokizan)(JA/KN-007) peak = 1212.000000 pos = 35.2898,139.0048 diff = 423.700012'
});
data_saddle.push({
lat: 3.5205777766e+01,
lng: 1.3903566667e+02,
content:'Saddle = 788.299988 pos = 35.2058,139.0357 diff = 423.700012'
});
data_peak.push({
lat: 3.5195666655e+01,
lng: 1.3903600000e+02,
cert : false,
content:' Peak = 948.000000 pos = 35.1957,139.0360 diff = 159.700012'
});
data_saddle.push({
lat: 3.5186888877e+01,
lng: 1.3903211111e+02,
content:'Saddle = 788.299988 pos = 35.1869,139.0321 diff = 159.700012'
});
data_peak.push({
lat: 3.5183111100e+01,
lng: 1.3904611111e+02,
cert : true,
content:'Name = Daikanzan(JA/KN-014) peak = 1011.700012 pos = 35.1831,139.0461 diff = 164.100037'
});
data_saddle.push({
lat: 3.5180777766e+01,
lng: 1.3901366667e+02,
content:'Saddle = 847.599976 pos = 35.1808,139.0137 diff = 164.100037'
});
data_peak.push({
lat: 3.5215999989e+01,
lng: 1.3898388889e+02,
cert : true,
content:'Name = Mikuniyama(JA/KN-010) peak = 1101.599976 pos = 35.2160,138.9839 diff = 248.500000'
});
data_saddle.push({
lat: 3.5230555544e+01,
lng: 1.3897877778e+02,
content:'Saddle = 853.099976 pos = 35.2306,138.9788 diff = 248.500000'
});
data_peak.push({
lat: 3.5279555545e+01,
lng: 1.3905244444e+02,
cert : true,
content:'Name = Myoujingatake(JA/KN-009) peak = 1168.099976 pos = 35.2796,139.0524 diff = 300.599976'
});
data_saddle.push({
lat: 3.5282333323e+01,
lng: 1.3901177778e+02,
content:'Saddle = 867.500000 pos = 35.2823,139.0118 diff = 300.599976'
});
data_peak.push({
lat: 3.5270444434e+01,
lng: 1.3898211111e+02,
cert : false,
content:' Peak = 1155.000000 pos = 35.2704,138.9821 diff = 150.700012'
});
data_saddle.push({
lat: 3.5280999989e+01,
lng: 1.3898888889e+02,
content:'Saddle = 1004.299988 pos = 35.2810,138.9889 diff = 150.700012'
});
data_peak.push({
lat: 3.5214777766e+01,
lng: 1.3904188889e+02,
cert : true,
content:'Name = Uefutagosan(JA/KN-011) peak = 1099.000000 pos = 35.2148,139.0419 diff = 221.500000'
});
data_saddle.push({
lat: 3.5217555544e+01,
lng: 1.3903866667e+02,
content:'Saddle = 877.500000 pos = 35.2176,139.0387 diff = 221.500000'
});
data_peak.push({
lat: 3.6245111108e+01,
lng: 1.3877222222e+02,
cert : true,
content:'Name = JA/GM-068(JA/GM-068) peak = 834.700012 pos = 36.2451,138.7722 diff = 385.800018'
});
data_saddle.push({
lat: 3.6262111108e+01,
lng: 1.3875944444e+02,
content:'Saddle = 448.899994 pos = 36.2621,138.7594 diff = 385.800018'
});
data_peak.push({
lat: 3.5051111099e+01,
lng: 1.3831788889e+02,
cert : true,
content:'Name = JA/SO-065(JA/SO-065) peak = 717.500000 pos = 35.0511,138.3179 diff = 266.600006'
});
data_saddle.push({
lat: 3.5058999987e+01,
lng: 1.3830700000e+02,
content:'Saddle = 450.899994 pos = 35.0590,138.3070 diff = 266.600006'
});
data_peak.push({
lat: 3.5145999988e+01,
lng: 1.3850600000e+02,
cert : false,
content:' Peak = 618.599976 pos = 35.1460,138.5060 diff = 161.399963'
});
data_saddle.push({
lat: 3.5149333322e+01,
lng: 1.3849955556e+02,
content:'Saddle = 457.200012 pos = 35.1493,138.4996 diff = 161.399963'
});
data_peak.push({
lat: 3.5474111102e+01,
lng: 1.3850255556e+02,
cert : true,
content:'Name = JA/YN-068(JA/YN-068) peak = 662.000000 pos = 35.4741,138.5026 diff = 199.200012'
});
data_saddle.push({
lat: 3.5480999991e+01,
lng: 1.3852500000e+02,
content:'Saddle = 462.799988 pos = 35.4810,138.5250 diff = 199.200012'
});
data_peak.push({
lat: 3.5621777770e+01,
lng: 1.3894977778e+02,
cert : false,
content:' Peak = 633.099976 pos = 35.6218,138.9498 diff = 166.499969'
});
data_saddle.push({
lat: 3.5622888881e+01,
lng: 1.3894411111e+02,
content:'Saddle = 466.600006 pos = 35.6229,138.9441 diff = 166.499969'
});
data_peak.push({
lat: 3.6074777773e+01,
lng: 1.3904500000e+02,
cert : false,
content:' Peak = 651.500000 pos = 36.0748,139.0450 diff = 179.500000'
});
data_saddle.push({
lat: 3.6078666662e+01,
lng: 1.3903500000e+02,
content:'Saddle = 472.000000 pos = 36.0787,139.0350 diff = 179.500000'
});
data_peak.push({
lat: 3.5262222211e+01,
lng: 1.3851422222e+02,
cert : true,
content:'Name = JA/YN-066(JA/YN-066) peak = 811.099976 pos = 35.2622,138.5142 diff = 329.799988'
});
data_saddle.push({
lat: 3.5275222211e+01,
lng: 1.3852022222e+02,
content:'Saddle = 481.299988 pos = 35.2752,138.5202 diff = 329.799988'
});
data_peak.push({
lat: 3.5907111105e+01,
lng: 1.3918500000e+02,
cert : true,
content:'Name = JA/ST-015(JA/ST-015) peak = 661.299988 pos = 35.9071,139.1850 diff = 172.099976'
});
data_saddle.push({
lat: 3.5911111105e+01,
lng: 1.3917633333e+02,
content:'Saddle = 489.200012 pos = 35.9111,139.1763 diff = 172.099976'
});
data_peak.push({
lat: 3.6044111106e+01,
lng: 1.3895655556e+02,
cert : false,
content:' Peak = 694.700012 pos = 36.0441,138.9566 diff = 187.700012'
});
data_saddle.push({
lat: 3.6046111106e+01,
lng: 1.3894888889e+02,
content:'Saddle = 507.000000 pos = 36.0461,138.9489 diff = 187.700012'
});
data_peak.push({
lat: 3.4896999986e+01,
lng: 1.3802277778e+02,
cert : false,
content:' Peak = 674.599976 pos = 34.8970,138.0228 diff = 151.899963'
});
data_saddle.push({
lat: 3.4910111097e+01,
lng: 1.3802833333e+02,
content:'Saddle = 522.700012 pos = 34.9101,138.0283 diff = 151.899963'
});
data_peak.push({
lat: 3.5293222212e+01,
lng: 1.3851722222e+02,
cert : true,
content:'Name = JA/SO-063(JA/SO-063) peak = 730.700012 pos = 35.2932,138.5172 diff = 179.100037'
});
data_saddle.push({
lat: 3.5304888878e+01,
lng: 1.3851355556e+02,
content:'Saddle = 551.599976 pos = 35.3049,138.5136 diff = 179.100037'
});
data_peak.push({
lat: 3.4964777764e+01,
lng: 1.3811666667e+02,
cert : true,
content:'Name = JA/SO-064(JA/SO-064) peak = 721.200012 pos = 34.9648,138.1167 diff = 169.100037'
});
data_saddle.push({
lat: 3.4972555542e+01,
lng: 1.3814855556e+02,
content:'Saddle = 552.099976 pos = 34.9726,138.1486 diff = 169.100037'
});
data_peak.push({
lat: 3.4995999987e+01,
lng: 1.3803166667e+02,
cert : true,
content:'Name = JA/SO-049(JA/SO-049) peak = 1008.299988 pos = 34.9960,138.0317 diff = 450.000000'
});
data_saddle.push({
lat: 3.5017888876e+01,
lng: 1.3802788889e+02,
content:'Saddle = 558.299988 pos = 35.0179,138.0279 diff = 450.000000'
});
data_peak.push({
lat: 3.4938333320e+01,
lng: 1.3800600000e+02,
cert : true,
content:'Name = JA/SO-054(JA/SO-054) peak = 880.700012 pos = 34.9383,138.0060 diff = 304.600037'
});
data_saddle.push({
lat: 3.4953666653e+01,
lng: 1.3801477778e+02,
content:'Saddle = 576.099976 pos = 34.9537,138.0148 diff = 304.600037'
});
data_peak.push({
lat: 3.4907333320e+01,
lng: 1.3805688889e+02,
cert : true,
content:'Name = Hakkousan(JA/SO-059) peak = 834.599976 pos = 34.9073,138.0569 diff = 212.000000'
});
data_saddle.push({
lat: 3.4916555542e+01,
lng: 1.3804411111e+02,
content:'Saddle = 622.599976 pos = 34.9166,138.0441 diff = 212.000000'
});
data_peak.push({
lat: 3.5616333325e+01,
lng: 1.3891766667e+02,
cert : false,
content:' Peak = 751.299988 pos = 35.6163,138.9177 diff = 183.700012'
});
data_saddle.push({
lat: 3.5620555548e+01,
lng: 1.3890944444e+02,
content:'Saddle = 567.599976 pos = 35.6206,138.9094 diff = 183.700012'
});
data_peak.push({
lat: 3.6592000000e+01,
lng: 1.3899766667e+02,
cert : true,
content:'Name = Komochiyama(JA/GM-046) peak = 1295.400024 pos = 36.5920,138.9977 diff = 725.500000'
});
data_saddle.push({
lat: 3.6666666667e+01,
lng: 1.3879577778e+02,
content:'Saddle = 569.900024 pos = 36.6667,138.7958 diff = 725.500000'
});
data_peak.push({
lat: 3.6613888889e+01,
lng: 1.3883100000e+02,
cert : false,
content:' Peak = 786.500000 pos = 36.6139,138.8310 diff = 163.299988'
});
data_saddle.push({
lat: 3.6619333333e+01,
lng: 1.3882977778e+02,
content:'Saddle = 623.200012 pos = 36.6193,138.8298 diff = 163.299988'
});
data_peak.push({
lat: 3.6633888889e+01,
lng: 1.3885122222e+02,
cert : true,
content:'Name = JA/GM-067(JA/GM-067) peak = 852.599976 pos = 36.6339,138.8512 diff = 200.099976'
});
data_saddle.push({
lat: 3.6636666667e+01,
lng: 1.3884722222e+02,
content:'Saddle = 652.500000 pos = 36.6367,138.8472 diff = 200.099976'
});
data_peak.push({
lat: 3.6666111111e+01,
lng: 1.3881544444e+02,
cert : false,
content:' Peak = 1292.300049 pos = 36.6661,138.8154 diff = 595.600037'
});
data_saddle.push({
lat: 3.6634111111e+01,
lng: 1.3898833333e+02,
content:'Saddle = 696.700012 pos = 36.6341,138.9883 diff = 595.600037'
});
data_peak.push({
lat: 3.6658444445e+01,
lng: 1.3890333333e+02,
cert : true,
content:'Name = JA/GM-059(JA/GM-059) peak = 1157.199951 pos = 36.6584,138.9033 diff = 407.499939'
});
data_saddle.push({
lat: 3.6666666667e+01,
lng: 1.3887022222e+02,
content:'Saddle = 749.700012 pos = 36.6667,138.8702 diff = 407.499939'
});
data_peak.push({
lat: 3.6580888889e+01,
lng: 1.3893700000e+02,
cert : true,
content:'Name = JA/GM-053(JA/GM-053) peak = 1206.699951 pos = 36.5809,138.9370 diff = 508.599976'
});
data_saddle.push({
lat: 3.6587555555e+01,
lng: 1.3896222222e+02,
content:'Saddle = 698.099976 pos = 36.5876,138.9622 diff = 508.599976'
});
data_peak.push({
lat: 3.6587000000e+01,
lng: 1.3892300000e+02,
cert : false,
content:' Peak = 1200.599976 pos = 36.5870,138.9230 diff = 177.399963'
});
data_saddle.push({
lat: 3.6585111111e+01,
lng: 1.3893522222e+02,
content:'Saddle = 1023.200012 pos = 36.5851,138.9352 diff = 177.399963'
});
data_peak.push({
lat: 3.6034444440e+01,
lng: 1.3915622222e+02,
cert : true,
content:'Name = Oogiriyama(JA/ST-014) peak = 765.500000 pos = 36.0344,139.1562 diff = 182.500000'
});
data_saddle.push({
lat: 3.6018444440e+01,
lng: 1.3915777778e+02,
content:'Saddle = 583.000000 pos = 36.0184,139.1578 diff = 182.500000'
});
data_peak.push({
lat: 3.6180444441e+01,
lng: 1.3877933333e+02,
cert : false,
content:' Peak = 786.400024 pos = 36.1804,138.7793 diff = 179.600037'
});
data_saddle.push({
lat: 3.6177888885e+01,
lng: 1.3878633333e+02,
content:'Saddle = 606.799988 pos = 36.1779,138.7863 diff = 179.600037'
});
data_peak.push({
lat: 3.5988666662e+01,
lng: 1.3915955556e+02,
cert : true,
content:'Name = Maruyama(JA/ST-012) peak = 960.200012 pos = 35.9887,139.1596 diff = 351.600037'
});
data_saddle.push({
lat: 3.5931222217e+01,
lng: 1.3915211111e+02,
content:'Saddle = 608.599976 pos = 35.9312,139.1521 diff = 351.600037'
});
data_peak.push({
lat: 3.5926888883e+01,
lng: 1.3916055556e+02,
cert : true,
content:'Name = Izugatake(JA/ST-013) peak = 850.599976 pos = 35.9269,139.1606 diff = 217.899963'
});
data_saddle.push({
lat: 3.5941777772e+01,
lng: 1.3916044444e+02,
content:'Saddle = 632.700012 pos = 35.9418,139.1604 diff = 217.899963'
});
data_peak.push({
lat: 3.4979777765e+01,
lng: 1.3818333333e+02,
cert : true,
content:'Name = JA/SO-055(JA/SO-055) peak = 870.599976 pos = 34.9798,138.1833 diff = 261.899963'
});
data_saddle.push({
lat: 3.5006888876e+01,
lng: 1.3818711111e+02,
content:'Saddle = 608.700012 pos = 35.0069,138.1871 diff = 261.899963'
});
data_peak.push({
lat: 3.5706555548e+01,
lng: 1.3916533333e+02,
cert : true,
content:'Name = Usukiyama(JA/TK-012) peak = 841.299988 pos = 35.7066,139.1653 diff = 220.500000'
});
data_saddle.push({
lat: 3.5696222215e+01,
lng: 1.3917244444e+02,
content:'Saddle = 620.799988 pos = 35.6962,139.1724 diff = 220.500000'
});
data_peak.push({
lat: 3.5595333325e+01,
lng: 1.3895177778e+02,
cert : true,
content:'Name = JA/YN-067(JA/YN-067) peak = 795.900024 pos = 35.5953,138.9518 diff = 168.100037'
});
data_saddle.push({
lat: 3.5588888881e+01,
lng: 1.3894922222e+02,
content:'Saddle = 627.799988 pos = 35.5889,138.9492 diff = 168.100037'
});
data_peak.push({
lat: 3.5009444432e+01,
lng: 1.3820088889e+02,
cert : true,
content:'Name = JA/SO-058(JA/SO-058) peak = 833.700012 pos = 35.0094,138.2009 diff = 205.900024'
});
data_saddle.push({
lat: 3.5012888876e+01,
lng: 1.3819344444e+02,
content:'Saddle = 627.799988 pos = 35.0129,138.1934 diff = 205.900024'
});
data_peak.push({
lat: 3.5586111103e+01,
lng: 1.3890188889e+02,
cert : true,
content:'Name = JA/YN-062(JA/YN-062) peak = 975.400024 pos = 35.5861,138.9019 diff = 343.900024'
});
data_saddle.push({
lat: 3.5574444436e+01,
lng: 1.3886277778e+02,
content:'Saddle = 631.500000 pos = 35.5744,138.8628 diff = 343.900024'
});
data_peak.push({
lat: 3.5485444435e+01,
lng: 1.3923611111e+02,
cert : false,
content:' Peak = 814.799988 pos = 35.4854,139.2361 diff = 181.399963'
});
data_saddle.push({
lat: 3.5481444435e+01,
lng: 1.3924800000e+02,
content:'Saddle = 633.400024 pos = 35.4814,139.2480 diff = 181.399963'
});
data_peak.push({
lat: 3.5022555543e+01,
lng: 1.3818766667e+02,
cert : true,
content:'Name = JA/SO-056(JA/SO-056) peak = 866.299988 pos = 35.0226,138.1877 diff = 223.700012'
});
data_saddle.push({
lat: 3.5057888876e+01,
lng: 1.3820088889e+02,
content:'Saddle = 642.599976 pos = 35.0579,138.2009 diff = 223.700012'
});
data_peak.push({
lat: 3.6256777775e+01,
lng: 1.3873133333e+02,
cert : true,
content:'Name = JA/GM-066(JA/GM-066) peak = 876.099976 pos = 36.2568,138.7313 diff = 213.399963'
});
data_saddle.push({
lat: 3.6262666664e+01,
lng: 1.3871800000e+02,
content:'Saddle = 662.700012 pos = 36.2627,138.7180 diff = 213.399963'
});
data_peak.push({
lat: 3.6477444443e+01,
lng: 1.3885077778e+02,
cert : true,
content:'Name = Harunasan (Kamongatake)(JA/GM-033) peak = 1448.199951 pos = 36.4774,138.8508 diff = 774.499939'
});
data_saddle.push({
lat: 3.6472555554e+01,
lng: 1.3877833333e+02,
content:'Saddle = 673.700012 pos = 36.4726,138.7783 diff = 774.499939'
});
data_peak.push({
lat: 3.6480777777e+01,
lng: 1.3892966667e+02,
cert : false,
content:' Peak = 1194.199951 pos = 36.4808,138.9297 diff = 151.299927'
});
data_saddle.push({
lat: 3.6481333332e+01,
lng: 1.3892255556e+02,
content:'Saddle = 1042.900024 pos = 36.4813,138.9226 diff = 151.299927'
});
data_peak.push({
lat: 3.6457444443e+01,
lng: 1.3886511111e+02,
cert : true,
content:'Name = JA/GM-049(JA/GM-049) peak = 1270.599976 pos = 36.4574,138.8651 diff = 174.900024'
});
data_saddle.push({
lat: 3.6462111110e+01,
lng: 1.3886677778e+02,
content:'Saddle = 1095.699951 pos = 36.4621,138.8668 diff = 174.900024'
});
data_peak.push({
lat: 3.6449333332e+01,
lng: 1.3886077778e+02,
cert : false,
content:' Peak = 1251.699951 pos = 36.4493,138.8608 diff = 150.199951'
});
data_saddle.push({
lat: 3.6452666665e+01,
lng: 1.3886188889e+02,
content:'Saddle = 1101.500000 pos = 36.4527,138.8619 diff = 150.199951'
});
data_peak.push({
lat: 3.6474555554e+01,
lng: 1.3890066667e+02,
cert : true,
content:'Name = JA/GM-036(JA/GM-036) peak = 1410.400024 pos = 36.4746,138.9007 diff = 292.200073'
});
data_saddle.push({
lat: 3.6469999999e+01,
lng: 1.3885911111e+02,
content:'Saddle = 1118.199951 pos = 36.4700,138.8591 diff = 292.200073'
});
data_peak.push({
lat: 3.6461777776e+01,
lng: 1.3888222222e+02,
cert : true,
content:'Name = JA/GM-045(JA/GM-045) peak = 1314.000000 pos = 36.4618,138.8822 diff = 187.099976'
});
data_saddle.push({
lat: 3.6472222221e+01,
lng: 1.3888988889e+02,
content:'Saddle = 1126.900024 pos = 36.4722,138.8899 diff = 187.099976'
});
data_peak.push({
lat: 3.6476999999e+01,
lng: 1.3887822222e+02,
cert : false,
content:' Peak = 1390.199951 pos = 36.4770,138.8782 diff = 253.799927'
});
data_saddle.push({
lat: 3.6479666666e+01,
lng: 1.3888255556e+02,
content:'Saddle = 1136.400024 pos = 36.4797,138.8826 diff = 253.799927'
});
data_peak.push({
lat: 3.6482111110e+01,
lng: 1.3890533333e+02,
cert : true,
content:'Name = JA/GM-041(JA/GM-041) peak = 1341.800049 pos = 36.4821,138.9053 diff = 189.400024'
});
data_saddle.push({
lat: 3.6478888888e+01,
lng: 1.3891044444e+02,
content:'Saddle = 1152.400024 pos = 36.4789,138.9104 diff = 189.400024'
});
data_peak.push({
lat: 3.6487555554e+01,
lng: 1.3887477778e+02,
cert : true,
content:'Name = JA/GM-039(JA/GM-039) peak = 1362.699951 pos = 36.4876,138.8748 diff = 184.599976'
});
data_saddle.push({
lat: 3.6482888888e+01,
lng: 1.3885944444e+02,
content:'Saddle = 1178.099976 pos = 36.4829,138.8594 diff = 184.599976'
});
data_peak.push({
lat: 3.6486999999e+01,
lng: 1.3886377778e+02,
cert : false,
content:' Peak = 1350.199951 pos = 36.4870,138.8638 diff = 154.299927'
});
data_saddle.push({
lat: 3.6486888888e+01,
lng: 1.3886900000e+02,
content:'Saddle = 1195.900024 pos = 36.4869,138.8690 diff = 154.299927'
});
data_peak.push({
lat: 3.5586444436e+01,
lng: 1.3906700000e+02,
cert : true,
content:'Name = JA/YN-065(JA/YN-065) peak = 860.099976 pos = 35.5864,139.0670 diff = 183.099976'
});
data_saddle.push({
lat: 3.5584444436e+01,
lng: 1.3906055556e+02,
content:'Saddle = 677.000000 pos = 35.5844,139.0606 diff = 183.099976'
});
data_peak.push({
lat: 3.5794666660e+01,
lng: 1.3833644444e+02,
cert : false,
content:' Peak = 890.599976 pos = 35.7947,138.3364 diff = 205.299988'
});
data_saddle.push({
lat: 3.5796777771e+01,
lng: 1.3831733333e+02,
content:'Saddle = 685.299988 pos = 35.7968,138.3173 diff = 205.299988'
});
data_peak.push({
lat: 3.5652222214e+01,
lng: 1.3916644444e+02,
cert : false,
content:' Peak = 853.900024 pos = 35.6522,139.1664 diff = 162.600037'
});
data_saddle.push({
lat: 3.5657777770e+01,
lng: 1.3916811111e+02,
content:'Saddle = 691.299988 pos = 35.6578,139.1681 diff = 162.600037'
});
data_peak.push({
lat: 3.6199555552e+01,
lng: 1.3873733333e+02,
cert : false,
content:' Peak = 896.299988 pos = 36.1996,138.7373 diff = 198.899963'
});
data_saddle.push({
lat: 3.6202666663e+01,
lng: 1.3873288889e+02,
content:'Saddle = 697.400024 pos = 36.2027,138.7329 diff = 198.899963'
});
data_peak.push({
lat: 3.6282333331e+01,
lng: 1.3875700000e+02,
cert : false,
content:' Peak = 855.000000 pos = 36.2823,138.7570 diff = 152.400024'
});
data_saddle.push({
lat: 3.6286444442e+01,
lng: 1.3874633333e+02,
content:'Saddle = 702.599976 pos = 36.2864,138.7463 diff = 152.400024'
});
data_peak.push({
lat: 3.5399777768e+01,
lng: 1.3900311111e+02,
cert : true,
content:'Name = Furousan(JA/KN-015) peak = 927.500000 pos = 35.3998,139.0031 diff = 220.099976'
});
data_saddle.push({
lat: 3.5403444435e+01,
lng: 1.3899333333e+02,
content:'Saddle = 707.400024 pos = 35.4034,138.9933 diff = 220.099976'
});
data_peak.push({
lat: 3.6173222219e+01,
lng: 1.3870644444e+02,
cert : false,
content:' Peak = 895.799988 pos = 36.1732,138.7064 diff = 182.700012'
});
data_saddle.push({
lat: 3.6177444441e+01,
lng: 1.3870566667e+02,
content:'Saddle = 713.099976 pos = 36.1774,138.7057 diff = 182.700012'
});
data_peak.push({
lat: 3.5576555547e+01,
lng: 1.3895111111e+02,
cert : true,
content:'Name = JA/YN-063(JA/YN-063) peak = 968.099976 pos = 35.5766,138.9511 diff = 250.599976'
});
data_saddle.push({
lat: 3.5577111103e+01,
lng: 1.3898366667e+02,
content:'Saddle = 717.500000 pos = 35.5771,138.9837 diff = 250.599976'
});
data_peak.push({
lat: 3.5177555544e+01,
lng: 1.3847800000e+02,
cert : true,
content:'Name = JA/SO-053(JA/SO-053) peak = 943.900024 pos = 35.1776,138.4780 diff = 222.700012'
});
data_saddle.push({
lat: 3.5178444433e+01,
lng: 1.3846411111e+02,
content:'Saddle = 721.200012 pos = 35.1784,138.4641 diff = 222.700012'
});
data_peak.push({
lat: 3.4998333320e+01,
lng: 1.3811566667e+02,
cert : false,
content:' Peak = 874.799988 pos = 34.9983,138.1157 diff = 152.700012'
});
data_saddle.push({
lat: 3.5040777765e+01,
lng: 1.3813944444e+02,
content:'Saddle = 722.099976 pos = 35.0408,138.1394 diff = 152.700012'
});
data_peak.push({
lat: 3.5430666657e+01,
lng: 1.3902522222e+02,
cert : true,
content:'Name = Gongenyama(JA/KN-012) peak = 1017.700012 pos = 35.4307,139.0252 diff = 269.799988'
});
data_saddle.push({
lat: 3.5438999991e+01,
lng: 1.3902544444e+02,
content:'Saddle = 747.900024 pos = 35.4390,139.0254 diff = 269.799988'
});
data_peak.push({
lat: 3.5440888879e+01,
lng: 1.3923111111e+02,
cert : true,
content:'Name = Ooyama(JA/KN-006) peak = 1251.800049 pos = 35.4409,139.2311 diff = 500.500061'
});
data_saddle.push({
lat: 3.5427333324e+01,
lng: 1.3920788889e+02,
content:'Saddle = 751.299988 pos = 35.4273,139.2079 diff = 500.500061'
});
data_peak.push({
lat: 3.6049555551e+01,
lng: 1.3891700000e+02,
cert : true,
content:'Name = Shiroishiyama(JA/ST-010) peak = 991.099976 pos = 36.0496,138.9170 diff = 238.399963'
});
data_saddle.push({
lat: 3.6061777773e+01,
lng: 1.3889177778e+02,
content:'Saddle = 752.700012 pos = 36.0618,138.8918 diff = 238.399963'
});
data_peak.push({
lat: 3.6097666662e+01,
lng: 1.3900755556e+02,
cert : true,
content:'Name = Jominesan(JA/ST-009) peak = 1036.099976 pos = 36.0977,139.0076 diff = 278.199951'
});
data_saddle.push({
lat: 3.6094555551e+01,
lng: 1.3894377778e+02,
content:'Saddle = 757.900024 pos = 36.0946,138.9438 diff = 278.199951'
});
data_peak.push({
lat: 3.6101888885e+01,
lng: 1.3895044444e+02,
cert : true,
content:'Name = JA/ST-011(JA/ST-011) peak = 977.000000 pos = 36.1019,138.9504 diff = 199.500000'
});
data_saddle.push({
lat: 3.6096666662e+01,
lng: 1.3898977778e+02,
content:'Saddle = 777.500000 pos = 36.0967,138.9898 diff = 199.500000'
});
data_peak.push({
lat: 3.6206444441e+01,
lng: 1.3872455556e+02,
cert : false,
content:' Peak = 1012.200012 pos = 36.2064,138.7246 diff = 253.200012'
});
data_saddle.push({
lat: 3.6211888886e+01,
lng: 1.3871166667e+02,
content:'Saddle = 759.000000 pos = 36.2119,138.7117 diff = 253.200012'
});
data_peak.push({
lat: 3.6298666664e+01,
lng: 1.3874888889e+02,
cert : true,
content:'Name = Myougisan (Soumadake)(JA/GM-064) peak = 1100.300049 pos = 36.2987,138.7489 diff = 338.700073'
});
data_saddle.push({
lat: 3.6284888886e+01,
lng: 1.3871111111e+02,
content:'Saddle = 761.599976 pos = 36.2849,138.7111 diff = 338.700073'
});
data_peak.push({
lat: 3.6287777775e+01,
lng: 1.3873533333e+02,
cert : false,
content:' Peak = 1092.300049 pos = 36.2878,138.7353 diff = 184.800049'
});
data_saddle.push({
lat: 3.6297111108e+01,
lng: 1.3874500000e+02,
content:'Saddle = 907.500000 pos = 36.2971,138.7450 diff = 184.800049'
});
data_peak.push({
lat: 3.5638111103e+01,
lng: 1.3898100000e+02,
cert : true,
content:'Name = JA/YN-060(JA/YN-060) peak = 1002.200012 pos = 35.6381,138.9810 diff = 239.400024'
});
data_saddle.push({
lat: 3.5641999992e+01,
lng: 1.3899777778e+02,
content:'Saddle = 762.799988 pos = 35.6420,138.9978 diff = 239.400024'
});
data_peak.push({
lat: 3.6323222220e+01,
lng: 1.3867777778e+02,
cert : false,
content:' Peak = 951.900024 pos = 36.3232,138.6778 diff = 184.500000'
});
data_saddle.push({
lat: 3.6321111109e+01,
lng: 1.3867444444e+02,
content:'Saddle = 767.400024 pos = 36.3211,138.6744 diff = 184.500000'
});
data_peak.push({
lat: 3.6168555552e+01,
lng: 1.3888466667e+02,
cert : false,
content:' Peak = 937.299988 pos = 36.1686,138.8847 diff = 167.799988'
});
data_saddle.push({
lat: 3.6169888885e+01,
lng: 1.3886977778e+02,
content:'Saddle = 769.500000 pos = 36.1699,138.8698 diff = 167.799988'
});
data_peak.push({
lat: 3.5159777766e+01,
lng: 1.3834844444e+02,
cert : true,
content:'Name = JA/SO-045(JA/SO-045) peak = 1046.300049 pos = 35.1598,138.3484 diff = 261.500061'
});
data_saddle.push({
lat: 3.5171777766e+01,
lng: 1.3834100000e+02,
content:'Saddle = 784.799988 pos = 35.1718,138.3410 diff = 261.500061'
});
data_peak.push({
lat: 3.5178555544e+01,
lng: 1.3843788889e+02,
cert : true,
content:'Name = [takadokkyou](JA/SO-040) peak = 1133.000000 pos = 35.1786,138.4379 diff = 335.599976'
});
data_saddle.push({
lat: 3.5185777766e+01,
lng: 1.3842677778e+02,
content:'Saddle = 797.400024 pos = 35.1858,138.4268 diff = 335.599976'
});
data_peak.push({
lat: 3.5583888881e+01,
lng: 1.3901977778e+02,
cert : true,
content:'Name = JA/YN-061(JA/YN-061) peak = 990.000000 pos = 35.5839,139.0198 diff = 191.799988'
});
data_saddle.push({
lat: 3.5566555547e+01,
lng: 1.3901111111e+02,
content:'Saddle = 798.200012 pos = 35.5666,139.0111 diff = 191.799988'
});
data_peak.push({
lat: 3.6091555551e+01,
lng: 1.3891233333e+02,
cert : true,
content:'Name = Near Tetemizuyama(JA/ST-007) peak = 1064.699951 pos = 36.0916,138.9123 diff = 264.699951'
});
data_saddle.push({
lat: 3.6085444440e+01,
lng: 1.3888855556e+02,
content:'Saddle = 800.000000 pos = 36.0854,138.8886 diff = 264.699951'
});
data_peak.push({
lat: 3.5672444437e+01,
lng: 1.3913644444e+02,
cert : true,
content:'Name = Ifujisan(JA/KN-013) peak = 1016.400024 pos = 35.6724,139.1364 diff = 194.700012'
});
data_saddle.push({
lat: 3.5691555548e+01,
lng: 1.3910333333e+02,
content:'Saddle = 821.700012 pos = 35.6916,139.1033 diff = 194.700012'
});
data_peak.push({
lat: 3.5091888877e+01,
lng: 1.3828966667e+02,
cert : false,
content:' Peak = 1035.599976 pos = 35.0919,138.2897 diff = 208.399963'
});
data_saddle.push({
lat: 3.5103777766e+01,
lng: 1.3827433333e+02,
content:'Saddle = 827.200012 pos = 35.1038,138.2743 diff = 208.399963'
});
data_peak.push({
lat: 3.5078444432e+01,
lng: 1.3827655556e+02,
cert : true,
content:'Name = JA/SO-048(JA/SO-048) peak = 1021.299988 pos = 35.0784,138.2766 diff = 193.599976'
});
data_saddle.push({
lat: 3.5085444432e+01,
lng: 1.3827700000e+02,
content:'Saddle = 827.700012 pos = 35.0854,138.2770 diff = 193.599976'
});
data_peak.push({
lat: 3.5090999988e+01,
lng: 1.3830600000e+02,
cert : false,
content:' Peak = 1034.099976 pos = 35.0910,138.3060 diff = 159.399963'
});
data_saddle.push({
lat: 3.5090999988e+01,
lng: 1.3829411111e+02,
content:'Saddle = 874.700012 pos = 35.0910,138.2941 diff = 159.399963'
});
data_peak.push({
lat: 3.6666666667e+01,
lng: 1.3874077778e+02,
cert : false,
content:' Peak = 1261.000000 pos = 36.6667,138.7408 diff = 429.700012'
});
data_saddle.push({
lat: 3.6666666667e+01,
lng: 1.3872777778e+02,
content:'Saddle = 831.299988 pos = 36.6667,138.7278 diff = 429.700012'
});
data_peak.push({
lat: 3.6651111111e+01,
lng: 1.3877755556e+02,
cert : true,
content:'Name = JA/GM-051(JA/GM-051) peak = 1211.400024 pos = 36.6511,138.7776 diff = 284.200012'
});
data_saddle.push({
lat: 3.6655777778e+01,
lng: 1.3876566667e+02,
content:'Saddle = 927.200012 pos = 36.6558,138.7657 diff = 284.200012'
});
data_peak.push({
lat: 3.5936999994e+01,
lng: 1.3913022222e+02,
cert : true,
content:'Name = Takegawadake(JA/ST-008) peak = 1051.599976 pos = 35.9370,139.1302 diff = 220.000000'
});
data_saddle.push({
lat: 3.5933666661e+01,
lng: 1.3912155556e+02,
content:'Saddle = 831.599976 pos = 35.9337,139.1216 diff = 220.000000'
});
data_peak.push({
lat: 3.5088333321e+01,
lng: 1.3840344444e+02,
cert : true,
content:'Name = Ryuusouzan(JA/SO-043) peak = 1050.500000 pos = 35.0883,138.4034 diff = 218.799988'
});
data_saddle.push({
lat: 3.5102777766e+01,
lng: 1.3839733333e+02,
content:'Saddle = 831.700012 pos = 35.1028,138.3973 diff = 218.799988'
});
data_peak.push({
lat: 3.6338888887e+01,
lng: 1.3869688889e+02,
cert : false,
content:' Peak = 989.599976 pos = 36.3389,138.6969 diff = 152.599976'
});
data_saddle.push({
lat: 3.6343111109e+01,
lng: 1.3868411111e+02,
content:'Saddle = 837.000000 pos = 36.3431,138.6841 diff = 152.599976'
});
data_peak.push({
lat: 3.5298888878e+01,
lng: 1.3849088889e+02,
cert : false,
content:' Peak = 1041.500000 pos = 35.2989,138.4909 diff = 198.900024'
});
data_saddle.push({
lat: 3.5322333323e+01,
lng: 1.3848211111e+02,
content:'Saddle = 842.599976 pos = 35.3223,138.4821 diff = 198.900024'
});
data_peak.push({
lat: 3.6303999997e+01,
lng: 1.3869900000e+02,
cert : true,
content:'Name = JA/GM-058(JA/GM-058) peak = 1161.099976 pos = 36.3040,138.6990 diff = 315.199951'
});
data_saddle.push({
lat: 3.6283999997e+01,
lng: 1.3867811111e+02,
content:'Saddle = 845.900024 pos = 36.2840,138.6781 diff = 315.199951'
});
data_peak.push({
lat: 3.6313555553e+01,
lng: 1.3871477778e+02,
cert : false,
content:' Peak = 1111.199951 pos = 36.3136,138.7148 diff = 239.399963'
});
data_saddle.push({
lat: 3.6306444442e+01,
lng: 1.3871111111e+02,
content:'Saddle = 871.799988 pos = 36.3064,138.7111 diff = 239.399963'
});
data_peak.push({
lat: 3.6163333330e+01,
lng: 1.3876200000e+02,
cert : true,
content:'Name = JA/GM-065(JA/GM-065) peak = 1086.099976 pos = 36.1633,138.7620 diff = 239.299988'
});
data_saddle.push({
lat: 3.6150555552e+01,
lng: 1.3876500000e+02,
content:'Saddle = 846.799988 pos = 36.1506,138.7650 diff = 239.299988'
});
data_peak.push({
lat: 3.6143777774e+01,
lng: 1.3898000000e+02,
cert : false,
content:' Peak = 1012.099976 pos = 36.1438,138.9800 diff = 161.099976'
});
data_saddle.push({
lat: 3.6145111107e+01,
lng: 1.3895911111e+02,
content:'Saddle = 851.000000 pos = 36.1451,138.9591 diff = 161.099976'
});
data_peak.push({
lat: 3.5637222214e+01,
lng: 1.3901355556e+02,
cert : true,
content:'Name = Gongenyama (Ougiyama)(JA/YN-059) peak = 1137.400024 pos = 35.6372,139.0136 diff = 286.300049'
});
data_saddle.push({
lat: 3.5653333326e+01,
lng: 1.3901622222e+02,
content:'Saddle = 851.099976 pos = 35.6533,139.0162 diff = 286.300049'
});
data_peak.push({
lat: 3.5738999993e+01,
lng: 1.3901366667e+02,
cert : true,
content:'Name = Mitousan(JA/TK-005) peak = 1530.400024 pos = 35.7390,139.0137 diff = 658.600037'
});
data_saddle.push({
lat: 3.5731222215e+01,
lng: 1.3897677778e+02,
content:'Saddle = 871.799988 pos = 35.7312,138.9768 diff = 658.600037'
});
data_peak.push({
lat: 3.5770111104e+01,
lng: 1.3908055556e+02,
cert : true,
content:'Name = Gozenyama(JA/TK-006) peak = 1404.400024 pos = 35.7701,139.0806 diff = 422.800049'
});
data_saddle.push({
lat: 3.5759666660e+01,
lng: 1.3905133333e+02,
content:'Saddle = 981.599976 pos = 35.7597,139.0513 diff = 422.800049'
});
data_peak.push({
lat: 3.5765222215e+01,
lng: 1.3913033333e+02,
cert : false,
content:' Peak = 1264.900024 pos = 35.7652,139.1303 diff = 274.000000'
});
data_saddle.push({
lat: 3.5778888882e+01,
lng: 1.3910288889e+02,
content:'Saddle = 990.900024 pos = 35.7789,139.1029 diff = 274.000000'
});
data_peak.push({
lat: 3.5742444437e+01,
lng: 1.3903477778e+02,
cert : false,
content:' Peak = 1301.800049 pos = 35.7424,139.0348 diff = 159.100098'
});
data_saddle.push({
lat: 3.5742333326e+01,
lng: 1.3902688889e+02,
content:'Saddle = 1142.699951 pos = 35.7423,139.0269 diff = 159.100098'
});
data_peak.push({
lat: 3.5061333321e+01,
lng: 1.3814977778e+02,
cert : true,
content:'Name = JA/SO-041(JA/SO-041) peak = 1111.900024 pos = 35.0613,138.1498 diff = 239.600037'
});
data_saddle.push({
lat: 3.5099666654e+01,
lng: 1.3818955556e+02,
content:'Saddle = 872.299988 pos = 35.0997,138.1896 diff = 239.600037'
});
data_peak.push({
lat: 3.6146444441e+01,
lng: 1.3861900000e+02,
cert : false,
content:' Peak = 1031.599976 pos = 36.1464,138.6190 diff = 154.399963'
});
data_saddle.push({
lat: 3.6143111107e+01,
lng: 1.3861888889e+02,
content:'Saddle = 877.200012 pos = 36.1431,138.6189 diff = 154.399963'
});
data_peak.push({
lat: 3.6069999996e+01,
lng: 1.3886322222e+02,
cert : true,
content:'Name = Futagoyama(JA/ST-006) peak = 1164.900024 pos = 36.0700,138.8632 diff = 286.300049'
});
data_saddle.push({
lat: 3.6061444440e+01,
lng: 1.3884533333e+02,
content:'Saddle = 878.599976 pos = 36.0614,138.8453 diff = 286.300049'
});
data_peak.push({
lat: 3.5238111100e+01,
lng: 1.3879400000e+02,
cert : true,
content:'Name = Ashitakayama (Echizendake)(JA/SO-027) peak = 1503.099976 pos = 35.2381,138.7940 diff = 616.099976'
});
data_saddle.push({
lat: 3.5255999989e+01,
lng: 1.3879333333e+02,
content:'Saddle = 887.000000 pos = 35.2560,138.7933 diff = 616.099976'
});
data_peak.push({
lat: 3.5223777767e+01,
lng: 1.3881000000e+02,
cert : true,
content:'Name = JA/SO-029(JA/SO-029) peak = 1455.699951 pos = 35.2238,138.8100 diff = 202.399902'
});
data_saddle.push({
lat: 3.5227222211e+01,
lng: 1.3879811111e+02,
content:'Saddle = 1253.300049 pos = 35.2272,138.7981 diff = 202.399902'
});
data_peak.push({
lat: 3.5833555549e+01,
lng: 1.3845688889e+02,
cert : false,
content:' Peak = 1121.699951 pos = 35.8336,138.4569 diff = 204.899963'
});
data_saddle.push({
lat: 3.5844222216e+01,
lng: 1.3846488889e+02,
content:'Saddle = 916.799988 pos = 35.8442,138.4649 diff = 204.899963'
});
data_peak.push({
lat: 3.6302333331e+01,
lng: 1.3867700000e+02,
cert : false,
content:' Peak = 1072.599976 pos = 36.3023,138.6770 diff = 151.099976'
});
data_saddle.push({
lat: 3.6307777775e+01,
lng: 1.3866944444e+02,
content:'Saddle = 921.500000 pos = 36.3078,138.6694 diff = 151.099976'
});
data_peak.push({
lat: 3.5397555546e+01,
lng: 1.3841622222e+02,
cert : true,
content:'Name = Minobusan(JA/YN-058) peak = 1152.199951 pos = 35.3976,138.4162 diff = 230.199951'
});
data_saddle.push({
lat: 3.5393777768e+01,
lng: 1.3840144444e+02,
content:'Saddle = 922.000000 pos = 35.3938,138.4014 diff = 230.199951'
});
data_peak.push({
lat: 3.5770333326e+01,
lng: 1.3894966667e+02,
cert : true,
content:'Name = JA/YN-055(JA/YN-055) peak = 1286.800049 pos = 35.7703,138.9497 diff = 363.700073'
});
data_saddle.push({
lat: 3.5774777771e+01,
lng: 1.3893277778e+02,
content:'Saddle = 923.099976 pos = 35.7748,138.9328 diff = 363.700073'
});
data_peak.push({
lat: 3.6128999996e+01,
lng: 1.3885922222e+02,
cert : false,
content:' Peak = 1101.599976 pos = 36.1290,138.8592 diff = 178.399963'
});
data_saddle.push({
lat: 3.6132333329e+01,
lng: 1.3885611111e+02,
content:'Saddle = 923.200012 pos = 36.1323,138.8561 diff = 178.399963'
});
data_peak.push({
lat: 3.6544444444e+01,
lng: 1.3873000000e+02,
cert : false,
content:' Peak = 1080.199951 pos = 36.5444,138.7300 diff = 153.399963'
});
data_saddle.push({
lat: 3.6536333333e+01,
lng: 1.3871466667e+02,
content:'Saddle = 926.799988 pos = 36.5363,138.7147 diff = 153.399963'
});
data_peak.push({
lat: 3.5951666661e+01,
lng: 1.3909777778e+02,
cert : true,
content:'Name = Bukousan(JA/ST-004) peak = 1302.500000 pos = 35.9517,139.0978 diff = 370.200012'
});
data_saddle.push({
lat: 3.5912222217e+01,
lng: 1.3911311111e+02,
content:'Saddle = 932.299988 pos = 35.9122,139.1131 diff = 370.200012'
});
data_peak.push({
lat: 3.5928555550e+01,
lng: 1.3910044444e+02,
cert : true,
content:'Name = Oomochiyama(JA/ST-005) peak = 1293.500000 pos = 35.9286,139.1004 diff = 230.800049'
});
data_saddle.push({
lat: 3.5944999995e+01,
lng: 1.3909622222e+02,
content:'Saddle = 1062.699951 pos = 35.9450,139.0962 diff = 230.800049'
});
data_peak.push({
lat: 3.6584777777e+01,
lng: 1.3876111111e+02,
cert : true,
content:'Name = JA/GM-057(JA/GM-057) peak = 1180.900024 pos = 36.5848,138.7611 diff = 248.100037'
});
data_saddle.push({
lat: 3.6596333333e+01,
lng: 1.3872933333e+02,
content:'Saddle = 932.799988 pos = 36.5963,138.7293 diff = 248.100037'
});
data_peak.push({
lat: 3.6290111108e+01,
lng: 1.3865766667e+02,
cert : true,
content:'Name = JA/GM-056(JA/GM-056) peak = 1180.500000 pos = 36.2901,138.6577 diff = 242.000000'
});
data_saddle.push({
lat: 3.6297444442e+01,
lng: 1.3865544444e+02,
content:'Saddle = 938.500000 pos = 36.2974,138.6554 diff = 242.000000'
});
data_peak.push({
lat: 3.5674555548e+01,
lng: 1.3823877778e+02,
cert : true,
content:'Name = Kitadake(JA/YN-001) peak = 3191.300049 pos = 35.6746,138.2388 diff = 2236.500000'
});
data_saddle.push({
lat: 3.5911222217e+01,
lng: 1.3821988889e+02,
content:'Saddle = 954.799988 pos = 35.9112,138.2199 diff = 2236.500000'
});
data_peak.push({
lat: 3.5741666660e+01,
lng: 1.3837733333e+02,
cert : false,
content:' Peak = 1131.400024 pos = 35.7417,138.3773 diff = 169.800049'
});
data_saddle.push({
lat: 3.5737222215e+01,
lng: 1.3837044444e+02,
content:'Saddle = 961.599976 pos = 35.7372,138.3704 diff = 169.800049'
});
data_peak.push({
lat: 3.5371888879e+01,
lng: 1.3839433333e+02,
cert : true,
content:'Name = JA/YN-057(JA/YN-057) peak = 1167.800049 pos = 35.3719,138.3943 diff = 186.100037'
});
data_saddle.push({
lat: 3.5356555545e+01,
lng: 1.3838766667e+02,
content:'Saddle = 981.700012 pos = 35.3566,138.3877 diff = 186.100037'
});
data_peak.push({
lat: 3.5219999989e+01,
lng: 1.3832311111e+02,
cert : true,
content:'Name = JA/SO-037(JA/SO-037) peak = 1206.800049 pos = 35.2200,138.3231 diff = 220.300049'
});
data_saddle.push({
lat: 3.5222111100e+01,
lng: 1.3831266667e+02,
content:'Saddle = 986.500000 pos = 35.2221,138.3127 diff = 220.300049'
});
data_peak.push({
lat: 3.5836888883e+01,
lng: 1.3808233333e+02,
cert : true,
content:'Name = Tsukikurayama(JA/NN-169) peak = 1191.599976 pos = 35.8369,138.0823 diff = 191.199951'
});
data_saddle.push({
lat: 3.5845444438e+01,
lng: 1.3809166667e+02,
content:'Saddle = 1000.400024 pos = 35.8454,138.0917 diff = 191.199951'
});
data_peak.push({
lat: 3.5206555544e+01,
lng: 1.3841788889e+02,
cert : false,
content:' Peak = 1202.300049 pos = 35.2066,138.4179 diff = 170.200073'
});
data_saddle.push({
lat: 3.5201777766e+01,
lng: 1.3841144444e+02,
content:'Saddle = 1032.099976 pos = 35.2018,138.4114 diff = 170.200073'
});
data_peak.push({
lat: 3.5247777767e+01,
lng: 1.3842633333e+02,
cert : true,
content:'Name = Shinoisan(JA/YN-052) peak = 1392.699951 pos = 35.2478,138.4263 diff = 321.500000'
});
data_saddle.push({
lat: 3.5244666656e+01,
lng: 1.3841400000e+02,
content:'Saddle = 1071.199951 pos = 35.2447,138.4140 diff = 321.500000'
});
data_peak.push({
lat: 3.5177777766e+01,
lng: 1.3816711111e+02,
cert : true,
content:'Name = JA/SO-036(JA/SO-036) peak = 1293.000000 pos = 35.1778,138.1671 diff = 209.400024'
});
data_saddle.push({
lat: 3.5182999988e+01,
lng: 1.3816466667e+02,
content:'Saddle = 1083.599976 pos = 35.1830,138.1647 diff = 209.400024'
});
data_peak.push({
lat: 3.5105111099e+01,
lng: 1.3805900000e+02,
cert : false,
content:' Peak = 1380.300049 pos = 35.1051,138.0590 diff = 237.300049'
});
data_saddle.push({
lat: 3.5112222210e+01,
lng: 1.3804866667e+02,
content:'Saddle = 1143.000000 pos = 35.1122,138.0487 diff = 237.300049'
});
data_peak.push({
lat: 3.5156666655e+01,
lng: 1.3821888889e+02,
cert : true,
content:'Name = JA/SO-026(JA/SO-026) peak = 1531.800049 pos = 35.1567,138.2189 diff = 383.900024'
});
data_saddle.push({
lat: 3.5190111100e+01,
lng: 1.3825144444e+02,
content:'Saddle = 1147.900024 pos = 35.1901,138.2514 diff = 383.900024'
});
data_peak.push({
lat: 3.5136777766e+01,
lng: 1.3818422222e+02,
cert : true,
content:'Name = JA/SO-033(JA/SO-033) peak = 1362.099976 pos = 35.1368,138.1842 diff = 187.799927'
});
data_saddle.push({
lat: 3.5142999988e+01,
lng: 1.3819488889e+02,
content:'Saddle = 1174.300049 pos = 35.1430,138.1949 diff = 187.799927'
});
data_peak.push({
lat: 3.5680111104e+01,
lng: 1.3800000000e+02,
cert : false,
content:' Peak = 1398.300049 pos = 35.6801,138.0000 diff = 230.500000'
});
data_saddle.push({
lat: 3.5672999992e+01,
lng: 1.3801411111e+02,
content:'Saddle = 1167.800049 pos = 35.6730,138.0141 diff = 230.500000'
});
data_peak.push({
lat: 3.5420333324e+01,
lng: 1.3820688889e+02,
cert : false,
content:' Peak = 1572.300049 pos = 35.4203,138.2069 diff = 383.300049'
});
data_saddle.push({
lat: 3.5430888879e+01,
lng: 1.3820511111e+02,
content:'Saddle = 1189.000000 pos = 35.4309,138.2051 diff = 383.300049'
});
data_peak.push({
lat: 3.5967555550e+01,
lng: 1.3809344444e+02,
cert : true,
content:'Name = Moriyasan(JA/NN-108) peak = 1650.199951 pos = 35.9676,138.0934 diff = 413.599976'
});
data_saddle.push({
lat: 3.5970111106e+01,
lng: 1.3812377778e+02,
content:'Saddle = 1236.599976 pos = 35.9701,138.1238 diff = 413.599976'
});
data_peak.push({
lat: 3.5913333328e+01,
lng: 1.3806044444e+02,
cert : true,
content:'Name = JA/NN-120(JA/NN-120) peak = 1527.400024 pos = 35.9133,138.0604 diff = 240.200073'
});
data_saddle.push({
lat: 3.5947222217e+01,
lng: 1.3809077778e+02,
content:'Saddle = 1287.199951 pos = 35.9472,138.0908 diff = 240.200073'
});
data_peak.push({
lat: 3.5156444433e+01,
lng: 1.3810744444e+02,
cert : false,
content:' Peak = 1423.900024 pos = 35.1564,138.1074 diff = 170.599976'
});
data_saddle.push({
lat: 3.5155666655e+01,
lng: 1.3809500000e+02,
content:'Saddle = 1253.300049 pos = 35.1557,138.0950 diff = 170.599976'
});
data_peak.push({
lat: 3.5632444437e+01,
lng: 1.3802022222e+02,
cert : false,
content:' Peak = 1444.300049 pos = 35.6324,138.0202 diff = 182.000000'
});
data_saddle.push({
lat: 3.5633222214e+01,
lng: 1.3802644444e+02,
content:'Saddle = 1262.300049 pos = 35.6332,138.0264 diff = 182.000000'
});
data_peak.push({
lat: 3.5099888877e+01,
lng: 1.3801055556e+02,
cert : true,
content:'Name = JA/SO-028(JA/SO-028) peak = 1501.500000 pos = 35.0999,138.0106 diff = 208.800049'
});
data_saddle.push({
lat: 3.5106333321e+01,
lng: 1.3800888889e+02,
content:'Saddle = 1292.699951 pos = 35.1063,138.0089 diff = 208.800049'
});
data_peak.push({
lat: 3.5744999993e+01,
lng: 1.3805188889e+02,
cert : true,
content:'Name = Tokurayama (Inafuji)(JA/NN-098) peak = 1680.400024 pos = 35.7450,138.0519 diff = 387.700073'
});
data_saddle.push({
lat: 3.5715555548e+01,
lng: 1.3806300000e+02,
content:'Saddle = 1292.699951 pos = 35.7156,138.0630 diff = 387.700073'
});
data_peak.push({
lat: 3.5503999991e+01,
lng: 1.3800000000e+02,
cert : false,
content:' Peak = 1785.099976 pos = 35.5040,138.0000 diff = 486.799927'
});
data_saddle.push({
lat: 3.5481222213e+01,
lng: 1.3801155556e+02,
content:'Saddle = 1298.300049 pos = 35.4812,138.0116 diff = 486.799927'
});
data_peak.push({
lat: 3.5489555546e+01,
lng: 1.3800000000e+02,
cert : false,
content:' Peak = 1592.400024 pos = 35.4896,138.0000 diff = 164.200073'
});
data_saddle.push({
lat: 3.5497333324e+01,
lng: 1.3800000000e+02,
content:'Saddle = 1428.199951 pos = 35.4973,138.0000 diff = 164.200073'
});
data_peak.push({
lat: 3.5488111102e+01,
lng: 1.3836988889e+02,
cert : true,
content:'Name = JA/YN-040(JA/YN-040) peak = 1668.800049 pos = 35.4881,138.3699 diff = 296.300049'
});
data_saddle.push({
lat: 3.5508888880e+01,
lng: 1.3835988889e+02,
content:'Saddle = 1372.500000 pos = 35.5089,138.3599 diff = 296.300049'
});
data_peak.push({
lat: 3.5137444433e+01,
lng: 1.3805722222e+02,
cert : false,
content:' Peak = 1561.599976 pos = 35.1374,138.0572 diff = 169.500000'
});
data_saddle.push({
lat: 3.5134999988e+01,
lng: 1.3804622222e+02,
content:'Saddle = 1392.099976 pos = 35.1350,138.0462 diff = 169.500000'
});
data_peak.push({
lat: 3.5674777770e+01,
lng: 1.3804400000e+02,
cert : true,
content:'Name = JA/NN-093(JA/NN-093) peak = 1741.199951 pos = 35.6748,138.0440 diff = 329.699951'
});
data_saddle.push({
lat: 3.5699333326e+01,
lng: 1.3806677778e+02,
content:'Saddle = 1411.500000 pos = 35.6993,138.0668 diff = 329.699951'
});
data_peak.push({
lat: 3.5243555545e+01,
lng: 1.3838577778e+02,
cert : false,
content:' Peak = 1732.199951 pos = 35.2436,138.3858 diff = 308.899902'
});
data_saddle.push({
lat: 3.5317555545e+01,
lng: 1.3835800000e+02,
content:'Saddle = 1423.300049 pos = 35.3176,138.3580 diff = 308.899902'
});
data_peak.push({
lat: 3.5298888878e+01,
lng: 1.3837244444e+02,
cert : true,
content:'Name = JA/YN-039(JA/YN-039) peak = 1671.300049 pos = 35.2989,138.3724 diff = 237.900024'
});
data_saddle.push({
lat: 3.5268333322e+01,
lng: 1.3836944444e+02,
content:'Saddle = 1433.400024 pos = 35.2683,138.3694 diff = 237.900024'
});
data_peak.push({
lat: 3.5126111099e+01,
lng: 1.3803466667e+02,
cert : true,
content:'Name = Sobatsubuyama(JA/SO-025) peak = 1623.400024 pos = 35.1261,138.0347 diff = 191.599976'
});
data_saddle.push({
lat: 3.5127777766e+01,
lng: 1.3802422222e+02,
content:'Saddle = 1431.800049 pos = 35.1278,138.0242 diff = 191.599976'
});
data_peak.push({
lat: 3.5258777767e+01,
lng: 1.3807877778e+02,
cert : true,
content:'Name = JA/SO-024(JA/SO-024) peak = 1744.400024 pos = 35.2588,138.0788 diff = 261.800049'
});
data_saddle.push({
lat: 3.5266777767e+01,
lng: 1.3806977778e+02,
content:'Saddle = 1482.599976 pos = 35.2668,138.0698 diff = 261.800049'
});
data_peak.push({
lat: 3.5590888881e+01,
lng: 1.3837033333e+02,
cert : false,
content:' Peak = 2054.699951 pos = 35.5909,138.3703 diff = 522.000000'
});
data_saddle.push({
lat: 3.5597999992e+01,
lng: 1.3833522222e+02,
content:'Saddle = 1532.699951 pos = 35.5980,138.3352 diff = 522.000000'
});
data_peak.push({
lat: 3.5587666658e+01,
lng: 1.3832722222e+02,
cert : false,
content:' Peak = 1800.800049 pos = 35.5877,138.3272 diff = 163.400024'
});
data_saddle.push({
lat: 3.5589444436e+01,
lng: 1.3833300000e+02,
content:'Saddle = 1637.400024 pos = 35.5894,138.3330 diff = 163.400024'
});
data_peak.push({
lat: 3.5567444436e+01,
lng: 1.3834522222e+02,
cert : true,
content:'Name = JA/YN-028(JA/YN-028) peak = 1910.099976 pos = 35.5674,138.3452 diff = 237.599976'
});
data_saddle.push({
lat: 3.5569999992e+01,
lng: 1.3835655556e+02,
content:'Saddle = 1672.500000 pos = 35.5700,138.3566 diff = 237.599976'
});
data_peak.push({
lat: 3.5553111103e+01,
lng: 1.3836244444e+02,
cert : true,
content:'Name = JA/YN-029(JA/YN-029) peak = 1906.400024 pos = 35.5531,138.3624 diff = 230.300049'
});
data_saddle.push({
lat: 3.5563111103e+01,
lng: 1.3835500000e+02,
content:'Saddle = 1676.099976 pos = 35.5631,138.3550 diff = 230.300049'
});
data_peak.push({
lat: 3.5240777767e+01,
lng: 1.3821744444e+02,
cert : false,
content:' Peak = 1711.199951 pos = 35.2408,138.2174 diff = 178.299927'
});
data_saddle.push({
lat: 3.5257222211e+01,
lng: 1.3821044444e+02,
content:'Saddle = 1532.900024 pos = 35.2572,138.2104 diff = 178.299927'
});
data_peak.push({
lat: 3.5268333322e+01,
lng: 1.3827644444e+02,
cert : true,
content:'Name = JA/SO-023(JA/SO-023) peak = 1762.400024 pos = 35.2683,138.2764 diff = 200.700073'
});
data_saddle.push({
lat: 3.5276555545e+01,
lng: 1.3828044444e+02,
content:'Saddle = 1561.699951 pos = 35.2766,138.2804 diff = 200.700073'
});
data_peak.push({
lat: 3.5235444433e+01,
lng: 1.3804111111e+02,
cert : true,
content:'Name = Fudougatake(JA/SO-016) peak = 2170.399902 pos = 35.2354,138.0411 diff = 567.099854'
});
data_saddle.push({
lat: 3.5239888878e+01,
lng: 1.3801577778e+02,
content:'Saddle = 1603.300049 pos = 35.2399,138.0158 diff = 567.099854'
});
data_peak.push({
lat: 3.5187333322e+01,
lng: 1.3807033333e+02,
cert : true,
content:'Name = JA/SO-020(JA/SO-020) peak = 1942.099976 pos = 35.1873,138.0703 diff = 288.400024'
});
data_saddle.push({
lat: 3.5188111100e+01,
lng: 1.3805711111e+02,
content:'Saddle = 1653.699951 pos = 35.1881,138.0571 diff = 288.400024'
});
data_peak.push({
lat: 3.5196111100e+01,
lng: 1.3802922222e+02,
cert : true,
content:'Name = Kuroboushigatake(JA/SO-017) peak = 2064.899902 pos = 35.1961,138.0292 diff = 203.399902'
});
data_saddle.push({
lat: 3.5203666655e+01,
lng: 1.3802988889e+02,
content:'Saddle = 1861.500000 pos = 35.2037,138.0299 diff = 203.399902'
});
data_peak.push({
lat: 3.5206888878e+01,
lng: 1.3813222222e+02,
cert : true,
content:'Name = JA/SO-021(JA/SO-021) peak = 1825.500000 pos = 35.2069,138.1322 diff = 204.599976'
});
data_saddle.push({
lat: 3.5212666655e+01,
lng: 1.3813011111e+02,
content:'Saddle = 1620.900024 pos = 35.2127,138.1301 diff = 204.599976'
});
data_peak.push({
lat: 3.5812888882e+01,
lng: 1.3812900000e+02,
cert : false,
content:' Peak = 1884.699951 pos = 35.8129,138.1290 diff = 261.199951'
});
data_saddle.push({
lat: 3.5857111105e+01,
lng: 1.3814500000e+02,
content:'Saddle = 1623.500000 pos = 35.8571,138.1450 diff = 261.199951'
});
data_peak.push({
lat: 3.5826333327e+01,
lng: 1.3823555556e+02,
cert : true,
content:'Name = JA/YN-026(JA/YN-026) peak = 2035.900024 pos = 35.8263,138.2356 diff = 353.000000'
});
data_saddle.push({
lat: 3.5816666660e+01,
lng: 1.3823844444e+02,
content:'Saddle = 1682.900024 pos = 35.8167,138.2384 diff = 353.000000'
});
data_peak.push({
lat: 3.5360555545e+01,
lng: 1.3835000000e+02,
cert : false,
content:' Peak = 1992.400024 pos = 35.3606,138.3500 diff = 261.099976'
});
data_saddle.push({
lat: 3.5336888879e+01,
lng: 1.3834122222e+02,
content:'Saddle = 1731.300049 pos = 35.3369,138.3412 diff = 261.099976'
});
data_peak.push({
lat: 3.5616111103e+01,
lng: 1.3813588889e+02,
cert : false,
content:' Peak = 1980.199951 pos = 35.6161,138.1359 diff = 188.099976'
});
data_saddle.push({
lat: 3.5630999992e+01,
lng: 1.3813877778e+02,
content:'Saddle = 1792.099976 pos = 35.6310,138.1388 diff = 188.099976'
});
data_peak.push({
lat: 3.5255999989e+01,
lng: 1.3816144444e+02,
cert : true,
content:'Name = Daimugenzan(JA/SO-013) peak = 2328.199951 pos = 35.2560,138.1614 diff = 535.599976'
});
data_saddle.push({
lat: 3.5287777767e+01,
lng: 1.3813088889e+02,
content:'Saddle = 1792.599976 pos = 35.2878,138.1309 diff = 535.599976'
});
data_peak.push({
lat: 3.5283333323e+01,
lng: 1.3813722222e+02,
cert : true,
content:'Name = JA/SO-015(JA/SO-015) peak = 2240.699951 pos = 35.2833,138.1372 diff = 392.099976'
});
data_saddle.push({
lat: 3.5268333322e+01,
lng: 1.3813800000e+02,
content:'Saddle = 1848.599976 pos = 35.2683,138.1380 diff = 392.099976'
});
data_peak.push({
lat: 3.5563333325e+01,
lng: 1.3809333333e+02,
cert : false,
content:' Peak = 2081.199951 pos = 35.5633,138.0933 diff = 268.500000'
});
data_saddle.push({
lat: 3.5562222214e+01,
lng: 1.3810300000e+02,
content:'Saddle = 1812.699951 pos = 35.5622,138.1030 diff = 268.500000'
});
data_peak.push({
lat: 3.5304333323e+01,
lng: 1.3828522222e+02,
cert : true,
content:'Name = Yanbushi(JA/SO-018) peak = 2013.199951 pos = 35.3043,138.2852 diff = 190.599976'
});
data_saddle.push({
lat: 3.5309888878e+01,
lng: 1.3827555556e+02,
content:'Saddle = 1822.599976 pos = 35.3099,138.2756 diff = 190.599976'
});
data_peak.push({
lat: 3.5674444437e+01,
lng: 1.3835188889e+02,
cert : true,
content:'Name = JA/YN-021(JA/YN-021) peak = 2140.600098 pos = 35.6744,138.3519 diff = 248.500122'
});
data_saddle.push({
lat: 3.5672999992e+01,
lng: 1.3834355556e+02,
content:'Saddle = 1892.099976 pos = 35.6730,138.3436 diff = 248.500122'
});
data_peak.push({
lat: 3.5284999989e+01,
lng: 1.3804255556e+02,
cert : false,
content:' Peak = 2147.199951 pos = 35.2850,138.0426 diff = 204.500000'
});
data_saddle.push({
lat: 3.5290777767e+01,
lng: 1.3803666667e+02,
content:'Saddle = 1942.699951 pos = 35.2908,138.0367 diff = 204.500000'
});
data_peak.push({
lat: 3.5814444438e+01,
lng: 1.3817466667e+02,
cert : true,
content:'Name = JA/NN-049(JA/NN-049) peak = 2266.800049 pos = 35.8144,138.1747 diff = 323.700073'
});
data_saddle.push({
lat: 3.5783666660e+01,
lng: 1.3818288889e+02,
content:'Saddle = 1943.099976 pos = 35.7837,138.1829 diff = 323.700073'
});
data_peak.push({
lat: 3.5348777768e+01,
lng: 1.3825566667e+02,
cert : true,
content:'Name = JA/YN-020(JA/YN-020) peak = 2204.399902 pos = 35.3488,138.2557 diff = 251.699951'
});
data_saddle.push({
lat: 3.5367111101e+01,
lng: 1.3824688889e+02,
content:'Saddle = 1952.699951 pos = 35.3671,138.2469 diff = 251.699951'
});
data_peak.push({
lat: 3.5424111102e+01,
lng: 1.3825944444e+02,
cert : true,
content:'Name = Zarugatake(JA/YN-011) peak = 2626.500000 pos = 35.4241,138.2594 diff = 648.900024'
});
data_saddle.push({
lat: 3.5545111102e+01,
lng: 1.3825988889e+02,
content:'Saddle = 1977.599976 pos = 35.5451,138.2599 diff = 648.900024'
});
data_peak.push({
lat: 3.5513888880e+01,
lng: 1.3827111111e+02,
cert : true,
content:'Name = JA/YN-019(JA/YN-019) peak = 2224.800049 pos = 35.5139,138.2711 diff = 240.400024'
});
data_saddle.push({
lat: 3.5502222213e+01,
lng: 1.3825977778e+02,
content:'Saddle = 1984.400024 pos = 35.5022,138.2598 diff = 240.400024'
});
data_peak.push({
lat: 3.5370111101e+01,
lng: 1.3822888889e+02,
cert : false,
content:' Peak = 2406.100098 pos = 35.3701,138.2289 diff = 373.500122'
});
data_saddle.push({
lat: 3.5394333323e+01,
lng: 1.3824722222e+02,
content:'Saddle = 2032.599976 pos = 35.3943,138.2472 diff = 373.500122'
});
data_peak.push({
lat: 3.5446222213e+01,
lng: 1.3825644444e+02,
cert : true,
content:'Name = JA/YN-014(JA/YN-014) peak = 2545.100098 pos = 35.4462,138.2564 diff = 223.300049'
});
data_saddle.push({
lat: 3.5439777768e+01,
lng: 1.3825555556e+02,
content:'Saddle = 2321.800049 pos = 35.4398,138.2556 diff = 223.300049'
});
data_peak.push({
lat: 3.5408555546e+01,
lng: 1.3825811111e+02,
cert : false,
content:' Peak = 2582.699951 pos = 35.4086,138.2581 diff = 164.500000'
});
data_saddle.push({
lat: 3.5417777768e+01,
lng: 1.3825811111e+02,
content:'Saddle = 2418.199951 pos = 35.4178,138.2581 diff = 164.500000'
});
data_peak.push({
lat: 3.5781555549e+01,
lng: 1.3818766667e+02,
cert : true,
content:'Name = JA/NN-056(JA/NN-056) peak = 2141.699951 pos = 35.7816,138.1877 diff = 160.000000'
});
data_saddle.push({
lat: 3.5782111104e+01,
lng: 1.3819122222e+02,
content:'Saddle = 1981.699951 pos = 35.7821,138.1912 diff = 160.000000'
});
data_peak.push({
lat: 3.5648666659e+01,
lng: 1.3810255556e+02,
cert : true,
content:'Name = JA/NN-050(JA/NN-050) peak = 2240.600098 pos = 35.6487,138.1026 diff = 207.900146'
});
data_saddle.push({
lat: 3.5605222214e+01,
lng: 1.3810744444e+02,
content:'Saddle = 2032.699951 pos = 35.6052,138.1074 diff = 207.900146'
});
data_peak.push({
lat: 3.5757999993e+01,
lng: 1.3823677778e+02,
cert : true,
content:'Name = Komagatake(JA/YN-005) peak = 2964.399902 pos = 35.7580,138.2368 diff = 925.999878'
});
data_saddle.push({
lat: 3.5743111104e+01,
lng: 1.3821122222e+02,
content:'Saddle = 2038.400024 pos = 35.7431,138.2112 diff = 925.999878'
});
data_peak.push({
lat: 3.5794333327e+01,
lng: 1.3823111111e+02,
cert : false,
content:' Peak = 2317.600098 pos = 35.7943,138.2311 diff = 164.500000'
});
data_saddle.push({
lat: 3.5790777771e+01,
lng: 1.3823122222e+02,
content:'Saddle = 2153.100098 pos = 35.7908,138.2312 diff = 164.500000'
});
data_peak.push({
lat: 3.5701888882e+01,
lng: 1.3830455556e+02,
cert : true,
content:'Name = Kannongadake(JA/YN-007) peak = 2840.199951 pos = 35.7019,138.3046 diff = 572.599854'
});
data_saddle.push({
lat: 3.5745777771e+01,
lng: 1.3823388889e+02,
content:'Saddle = 2267.600098 pos = 35.7458,138.2339 diff = 572.599854'
});
data_peak.push({
lat: 3.5731777771e+01,
lng: 1.3824133333e+02,
cert : true,
content:'Name = Asayomine(JA/YN-008) peak = 2796.699951 pos = 35.7318,138.2413 diff = 454.000000'
});
data_saddle.push({
lat: 3.5719222215e+01,
lng: 1.3826911111e+02,
content:'Saddle = 2342.699951 pos = 35.7192,138.2691 diff = 454.000000'
});
data_peak.push({
lat: 3.5709777770e+01,
lng: 1.3828766667e+02,
cert : false,
content:' Peak = 2776.300049 pos = 35.7098,138.2877 diff = 152.300049'
});
data_saddle.push({
lat: 3.5707222215e+01,
lng: 1.3830000000e+02,
content:'Saddle = 2624.000000 pos = 35.7072,138.3000 diff = 152.300049'
});
data_peak.push({
lat: 3.5779111104e+01,
lng: 1.3821000000e+02,
cert : true,
content:'Name = Nokogiriyama(JA/YN-010) peak = 2681.000000 pos = 35.7791,138.2100 diff = 193.800049'
});
data_saddle.push({
lat: 3.5774888882e+01,
lng: 1.3821477778e+02,
content:'Saddle = 2487.199951 pos = 35.7749,138.2148 diff = 193.800049'
});
data_peak.push({
lat: 3.5294333323e+01,
lng: 1.3801777778e+02,
cert : true,
content:'Name = JA/SO-014(JA/SO-014) peak = 2292.000000 pos = 35.2943,138.0178 diff = 221.399902'
});
data_saddle.push({
lat: 3.5320999990e+01,
lng: 1.3802744444e+02,
content:'Saddle = 2070.600098 pos = 35.3210,138.0274 diff = 221.399902'
});
data_peak.push({
lat: 3.5684777770e+01,
lng: 1.3816266667e+02,
cert : true,
content:'Name = JA/NN-047(JA/NN-047) peak = 2291.500000 pos = 35.6848,138.1627 diff = 218.399902'
});
data_saddle.push({
lat: 3.5701444437e+01,
lng: 1.3816000000e+02,
content:'Saddle = 2073.100098 pos = 35.7014,138.1600 diff = 218.399902'
});
data_peak.push({
lat: 3.5307111101e+01,
lng: 1.3809833333e+02,
cert : true,
content:'Name = JA/SO-012(JA/SO-012) peak = 2331.600098 pos = 35.3071,138.0983 diff = 254.200195'
});
data_saddle.push({
lat: 3.5314777767e+01,
lng: 1.3809222222e+02,
content:'Saddle = 2077.399902 pos = 35.3148,138.0922 diff = 254.200195'
});
data_peak.push({
lat: 3.5330222212e+01,
lng: 1.3803822222e+02,
cert : true,
content:'Name = Ikeguchidake(JA/SO-011) peak = 2391.199951 pos = 35.3302,138.0382 diff = 233.800049'
});
data_saddle.push({
lat: 3.5335222212e+01,
lng: 1.3804488889e+02,
content:'Saddle = 2157.399902 pos = 35.3352,138.0449 diff = 233.800049'
});
data_peak.push({
lat: 3.5484999991e+01,
lng: 1.3806900000e+02,
cert : true,
content:'Name = Okuchausuyama(JA/NN-033) peak = 2472.699951 pos = 35.4850,138.0690 diff = 301.899902'
});
data_saddle.push({
lat: 3.5481111102e+01,
lng: 1.3808888889e+02,
content:'Saddle = 2170.800049 pos = 35.4811,138.0889 diff = 301.899902'
});
data_peak.push({
lat: 3.5338222212e+01,
lng: 1.3808377778e+02,
cert : true,
content:'Name = Tekaridake(JA/SO-010) peak = 2590.100098 pos = 35.3382,138.0838 diff = 399.100098'
});
data_saddle.push({
lat: 3.5351555545e+01,
lng: 1.3809444444e+02,
content:'Saddle = 2191.000000 pos = 35.3516,138.0944 diff = 399.100098'
});
data_peak.push({
lat: 3.5347222212e+01,
lng: 1.3806122222e+02,
cert : false,
content:' Peak = 2428.600098 pos = 35.3472,138.0612 diff = 167.000000'
});
data_saddle.push({
lat: 3.5344333323e+01,
lng: 1.3807522222e+02,
content:'Saddle = 2261.600098 pos = 35.3443,138.0752 diff = 167.000000'
});
data_peak.push({
lat: 3.5474777769e+01,
lng: 1.3809466667e+02,
cert : false,
content:' Peak = 2373.100098 pos = 35.4748,138.0947 diff = 152.300049'
});
data_saddle.push({
lat: 3.5473333324e+01,
lng: 1.3810522222e+02,
content:'Saddle = 2220.800049 pos = 35.4733,138.1052 diff = 152.300049'
});
data_peak.push({
lat: 3.5383777768e+01,
lng: 1.3817444444e+02,
cert : false,
content:' Peak = 2422.100098 pos = 35.3838,138.1744 diff = 160.300049'
});
data_saddle.push({
lat: 3.5385333323e+01,
lng: 1.3817077778e+02,
content:'Saddle = 2261.800049 pos = 35.3853,138.1708 diff = 160.300049'
});
data_peak.push({
lat: 3.5389555546e+01,
lng: 1.3815266667e+02,
cert : true,
content:'Name = Kamikouchidake(JA/SO-008) peak = 2800.600098 pos = 35.3896,138.1527 diff = 521.700195'
});
data_saddle.push({
lat: 3.5405999990e+01,
lng: 1.3813977778e+02,
content:'Saddle = 2278.899902 pos = 35.4060,138.1398 diff = 521.700195'
});
data_peak.push({
lat: 3.5720111104e+01,
lng: 1.3818355556e+02,
cert : true,
content:'Name = Senjyougatake(JA/YN-004) peak = 3031.600098 pos = 35.7201,138.1836 diff = 738.700195'
});
data_saddle.push({
lat: 3.5669333326e+01,
lng: 1.3819900000e+02,
content:'Saddle = 2292.899902 pos = 35.6693,138.1990 diff = 738.700195'
});
data_peak.push({
lat: 3.5500777769e+01,
lng: 1.3818233333e+02,
cert : true,
content:'Name = Warusawadake(JA/SO-002) peak = 3140.699951 pos = 35.5008,138.1823 diff = 749.399902'
});
data_saddle.push({
lat: 3.5503666658e+01,
lng: 1.3814044444e+02,
content:'Saddle = 2391.300049 pos = 35.5037,138.1404 diff = 749.399902'
});
data_peak.push({
lat: 3.5422555546e+01,
lng: 1.3813955556e+02,
cert : true,
content:'Name = Hijiridake (Maehijiridake)(JA/SO-007) peak = 3010.699951 pos = 35.4226,138.1396 diff = 468.199951'
});
data_saddle.push({
lat: 3.5454444435e+01,
lng: 1.3812822222e+02,
content:'Saddle = 2542.500000 pos = 35.4544,138.1282 diff = 468.199951'
});
data_peak.push({
lat: 3.5449444435e+01,
lng: 1.3812022222e+02,
cert : false,
content:' Peak = 2823.300049 pos = 35.4494,138.1202 diff = 211.699951'
});
data_saddle.push({
lat: 3.5427222213e+01,
lng: 1.3812822222e+02,
content:'Saddle = 2611.600098 pos = 35.4272,138.1282 diff = 211.699951'
});
data_peak.push({
lat: 3.5428666657e+01,
lng: 1.3812111111e+02,
cert : true,
content:'Name = Usagidake(JA/NN-015) peak = 2815.300049 pos = 35.4287,138.1211 diff = 182.600098'
});
data_saddle.push({
lat: 3.5438777768e+01,
lng: 1.3812300000e+02,
content:'Saddle = 2632.699951 pos = 35.4388,138.1230 diff = 182.600098'
});
data_peak.push({
lat: 3.5461111102e+01,
lng: 1.3815733333e+02,
cert : true,
content:'Name = Akaishidake(JA/SO-003) peak = 3120.000000 pos = 35.4611,138.1573 diff = 420.500000'
});
data_saddle.push({
lat: 3.5477555546e+01,
lng: 1.3815655556e+02,
content:'Saddle = 2699.500000 pos = 35.4776,138.1566 diff = 420.500000'
});
data_peak.push({
lat: 3.5496666658e+01,
lng: 1.3816700000e+02,
cert : true,
content:'Name = Arakawadake (Nakadake)(JA/SO-004) peak = 3080.600098 pos = 35.4967,138.1670 diff = 159.900146'
});
data_saddle.push({
lat: 3.5498777769e+01,
lng: 1.3817588889e+02,
content:'Saddle = 2920.699951 pos = 35.4988,138.1759 diff = 159.900146'
});
data_peak.push({
lat: 3.5537777769e+01,
lng: 1.3815300000e+02,
cert : true,
content:'Name = Kogouchidake(JA/SO-009) peak = 2801.300049 pos = 35.5378,138.1530 diff = 310.100098'
});
data_saddle.push({
lat: 3.5565222214e+01,
lng: 1.3815044444e+02,
content:'Saddle = 2491.199951 pos = 35.5652,138.1504 diff = 310.100098'
});
data_peak.push({
lat: 3.5573888880e+01,
lng: 1.3818311111e+02,
cert : true,
content:'Name = Shiomidake(JA/SO-006) peak = 3042.199951 pos = 35.5739,138.1831 diff = 501.500000'
});
data_saddle.push({
lat: 3.5599444436e+01,
lng: 1.3820033333e+02,
content:'Saddle = 2540.699951 pos = 35.5994,138.2003 diff = 501.500000'
});
data_peak.push({
lat: 3.5624999992e+01,
lng: 1.3822955556e+02,
cert : true,
content:'Name = Noutoridake (Nishinoutoridake)(JA/SO-005) peak = 3053.300049 pos = 35.6250,138.2296 diff = 266.000000'
});
data_saddle.push({
lat: 3.5634333325e+01,
lng: 1.3823022222e+02,
content:'Saddle = 2787.300049 pos = 35.6343,138.2302 diff = 266.000000'
});
data_peak.push({
lat: 3.5645999992e+01,
lng: 1.3822822222e+02,
cert : true,
content:'Name = Ainodake(JA/YN-002) peak = 3181.399902 pos = 35.6460,138.2282 diff = 293.899902'
});
data_saddle.push({
lat: 3.5664444437e+01,
lng: 1.3823266667e+02,
content:'Saddle = 2887.500000 pos = 35.6644,138.2327 diff = 293.899902'
});
data_peak.push({
lat: 3.6638444445e+01,
lng: 1.3869044444e+02,
cert : true,
content:'Name = JA/GM-031(JA/GM-031) peak = 1511.400024 pos = 36.6384,138.6904 diff = 554.300049'
});
data_saddle.push({
lat: 3.6666666667e+01,
lng: 1.3868766667e+02,
content:'Saddle = 957.099976 pos = 36.6667,138.6877 diff = 554.300049'
});
data_peak.push({
lat: 3.6575111111e+01,
lng: 1.3868144444e+02,
cert : true,
content:'Name = JA/GM-042(JA/GM-042) peak = 1341.599976 pos = 36.5751,138.6814 diff = 252.599976'
});
data_saddle.push({
lat: 3.6603000000e+01,
lng: 1.3868444444e+02,
content:'Saddle = 1089.000000 pos = 36.6030,138.6844 diff = 252.599976'
});
data_peak.push({
lat: 3.5425999990e+01,
lng: 1.3910566667e+02,
cert : false,
content:' Peak = 1175.900024 pos = 35.4260,139.1057 diff = 217.300049'
});
data_saddle.push({
lat: 3.5443444435e+01,
lng: 1.3912733333e+02,
content:'Saddle = 958.599976 pos = 35.4434,139.1273 diff = 217.300049'
});
data_peak.push({
lat: 3.6406555554e+01,
lng: 1.3852288889e+02,
cert : true,
content:'Name = Asamayama(JA/NN-026) peak = 2567.600098 pos = 36.4066,138.5229 diff = 1600.700073'
});
data_saddle.push({
lat: 3.6344555553e+01,
lng: 1.3865066667e+02,
content:'Saddle = 966.900024 pos = 36.3446,138.6507 diff = 1600.700073'
});
data_peak.push({
lat: 3.6666666667e+01,
lng: 1.3864277778e+02,
cert : false,
content:' Peak = 1284.199951 pos = 36.6667,138.6428 diff = 303.199951'
});
data_saddle.push({
lat: 3.6666666667e+01,
lng: 1.3861611111e+02,
content:'Saddle = 981.000000 pos = 36.6667,138.6161 diff = 303.199951'
});
data_peak.push({
lat: 3.6666444445e+01,
lng: 1.3866522222e+02,
cert : false,
content:' Peak = 1220.099976 pos = 36.6664,138.6652 diff = 233.799988'
});
data_saddle.push({
lat: 3.6666444445e+01,
lng: 1.3865577778e+02,
content:'Saddle = 986.299988 pos = 36.6664,138.6558 diff = 233.799988'
});
data_peak.push({
lat: 3.6599333333e+01,
lng: 1.3830544444e+02,
cert : true,
content:'Name = JA/NN-155(JA/NN-155) peak = 1293.300049 pos = 36.5993,138.3054 diff = 305.900024'
});
data_saddle.push({
lat: 3.6581222222e+01,
lng: 1.3830800000e+02,
content:'Saddle = 987.400024 pos = 36.5812,138.3080 diff = 305.900024'
});
data_peak.push({
lat: 3.6521999999e+01,
lng: 1.3867511111e+02,
cert : true,
content:'Name = JA/GM-052(JA/GM-052) peak = 1206.000000 pos = 36.5220,138.6751 diff = 167.500000'
});
data_saddle.push({
lat: 3.6520888888e+01,
lng: 1.3866177778e+02,
content:'Saddle = 1038.500000 pos = 36.5209,138.6618 diff = 167.500000'
});
data_peak.push({
lat: 3.6450888887e+01,
lng: 1.3824188889e+02,
cert : false,
content:' Peak = 1326.199951 pos = 36.4509,138.2419 diff = 287.399902'
});
data_saddle.push({
lat: 3.6512888888e+01,
lng: 1.3823611111e+02,
content:'Saddle = 1038.800049 pos = 36.5129,138.2361 diff = 287.399902'
});
data_peak.push({
lat: 3.6440555554e+01,
lng: 1.3826877778e+02,
cert : false,
content:' Peak = 1300.400024 pos = 36.4406,138.2688 diff = 259.700073'
});
data_saddle.push({
lat: 3.6440444443e+01,
lng: 1.3825777778e+02,
content:'Saddle = 1040.699951 pos = 36.4404,138.2578 diff = 259.700073'
});
data_peak.push({
lat: 3.6501111110e+01,
lng: 1.3820177778e+02,
cert : true,
content:'Name = JA/NN-158(JA/NN-158) peak = 1268.400024 pos = 36.5011,138.2018 diff = 180.200073'
});
data_saddle.push({
lat: 3.6491111110e+01,
lng: 1.3821788889e+02,
content:'Saddle = 1088.199951 pos = 36.4911,138.2179 diff = 180.200073'
});
data_peak.push({
lat: 3.6478999999e+01,
lng: 1.3823044444e+02,
cert : true,
content:'Name = JA/NN-150(JA/NN-150) peak = 1324.300049 pos = 36.4790,138.2304 diff = 155.500000'
});
data_saddle.push({
lat: 3.6460111110e+01,
lng: 1.3823622222e+02,
content:'Saddle = 1168.800049 pos = 36.4601,138.2362 diff = 155.500000'
});
data_peak.push({
lat: 3.6353888887e+01,
lng: 1.3861188889e+02,
cert : false,
content:' Peak = 1255.000000 pos = 36.3539,138.6119 diff = 197.199951'
});
data_saddle.push({
lat: 3.6357444442e+01,
lng: 1.3861022222e+02,
content:'Saddle = 1057.800049 pos = 36.3574,138.6102 diff = 197.199951'
});
data_peak.push({
lat: 3.6465444443e+01,
lng: 1.3868188889e+02,
cert : true,
content:'Name = JA/GM-037(JA/GM-037) peak = 1410.199951 pos = 36.4654,138.6819 diff = 226.500000'
});
data_saddle.push({
lat: 3.6463111110e+01,
lng: 1.3867311111e+02,
content:'Saddle = 1183.699951 pos = 36.4631,138.6731 diff = 226.500000'
});
data_peak.push({
lat: 3.6473888888e+01,
lng: 1.3869255556e+02,
cert : false,
content:' Peak = 1401.599976 pos = 36.4739,138.6926 diff = 150.099976'
});
data_saddle.push({
lat: 3.6471111110e+01,
lng: 1.3868422222e+02,
content:'Saddle = 1251.500000 pos = 36.4711,138.6842 diff = 150.099976'
});
data_peak.push({
lat: 3.6421777776e+01,
lng: 1.3868811111e+02,
cert : false,
content:' Peak = 1391.400024 pos = 36.4218,138.6881 diff = 164.700073'
});
data_saddle.push({
lat: 3.6419333332e+01,
lng: 1.3868533333e+02,
content:'Saddle = 1226.699951 pos = 36.4193,138.6853 diff = 164.700073'
});
data_peak.push({
lat: 3.6504222221e+01,
lng: 1.3827011111e+02,
cert : true,
content:'Name = JA/NN-131(JA/NN-131) peak = 1457.199951 pos = 36.5042,138.2701 diff = 195.199951'
});
data_saddle.push({
lat: 3.6523888888e+01,
lng: 1.3827111111e+02,
content:'Saddle = 1262.000000 pos = 36.5239,138.2711 diff = 195.199951'
});
data_peak.push({
lat: 3.6415777776e+01,
lng: 1.3868133333e+02,
cert : false,
content:' Peak = 1428.300049 pos = 36.4158,138.6813 diff = 161.200073'
});
data_saddle.push({
lat: 3.6411777776e+01,
lng: 1.3867000000e+02,
content:'Saddle = 1267.099976 pos = 36.4118,138.6700 diff = 161.200073'
});
data_peak.push({
lat: 3.6512333332e+01,
lng: 1.3830544444e+02,
cert : true,
content:'Name = JA/NN-109(JA/NN-109) peak = 1646.900024 pos = 36.5123,138.3054 diff = 379.200073'
});
data_saddle.push({
lat: 3.6540888888e+01,
lng: 1.3830288889e+02,
content:'Saddle = 1267.699951 pos = 36.5409,138.3029 diff = 379.200073'
});
data_peak.push({
lat: 3.6453777776e+01,
lng: 1.3865244444e+02,
cert : true,
content:'Name = Asamakakushiyama(JA/GM-024) peak = 1755.900024 pos = 36.4538,138.6524 diff = 480.400024'
});
data_saddle.push({
lat: 3.6419999998e+01,
lng: 1.3861866667e+02,
content:'Saddle = 1275.500000 pos = 36.4200,138.6187 diff = 480.400024'
});
data_peak.push({
lat: 3.6515222221e+01,
lng: 1.3864455556e+02,
cert : false,
content:' Peak = 1472.500000 pos = 36.5152,138.6446 diff = 191.900024'
});
data_saddle.push({
lat: 3.6507222221e+01,
lng: 1.3864088889e+02,
content:'Saddle = 1280.599976 pos = 36.5072,138.6409 diff = 191.900024'
});
data_peak.push({
lat: 3.6410888887e+01,
lng: 1.3864633333e+02,
cert : false,
content:' Peak = 1652.300049 pos = 36.4109,138.6463 diff = 270.900024'
});
data_saddle.push({
lat: 3.6435333332e+01,
lng: 1.3864333333e+02,
content:'Saddle = 1381.400024 pos = 36.4353,138.6433 diff = 270.900024'
});
data_peak.push({
lat: 3.6546333333e+01,
lng: 1.3832344444e+02,
cert : true,
content:'Name = JA/NN-124(JA/NN-124) peak = 1483.099976 pos = 36.5463,138.3234 diff = 164.599976'
});
data_saddle.push({
lat: 3.6539777777e+01,
lng: 1.3833844444e+02,
content:'Saddle = 1318.500000 pos = 36.5398,138.3384 diff = 164.599976'
});
data_peak.push({
lat: 3.6541777777e+01,
lng: 1.3841288889e+02,
cert : true,
content:'Name = Azumayasan(JA/GM-001) peak = 2351.699951 pos = 36.5418,138.4129 diff = 983.699951'
});
data_saddle.push({
lat: 3.6489999999e+01,
lng: 1.3839766667e+02,
content:'Saddle = 1368.000000 pos = 36.4900,138.3977 diff = 983.699951'
});
data_peak.push({
lat: 3.6666666667e+01,
lng: 1.3846777778e+02,
cert : false,
content:' Peak = 1651.500000 pos = 36.6667,138.4678 diff = 193.300049'
});
data_saddle.push({
lat: 3.6666555556e+01,
lng: 1.3847488889e+02,
content:'Saddle = 1458.199951 pos = 36.6666,138.4749 diff = 193.300049'
});
data_peak.push({
lat: 3.6666666667e+01,
lng: 1.3848022222e+02,
cert : false,
content:' Peak = 1756.199951 pos = 36.6667,138.4802 diff = 258.000000'
});
data_saddle.push({
lat: 3.6666666667e+01,
lng: 1.3848455556e+02,
content:'Saddle = 1498.199951 pos = 36.6667,138.4846 diff = 258.000000'
});
data_peak.push({
lat: 3.6661000000e+01,
lng: 1.3853222222e+02,
cert : false,
content:' Peak = 2216.199951 pos = 36.6610,138.5322 diff = 437.599976'
});
data_saddle.push({
lat: 3.6588444444e+01,
lng: 1.3842711111e+02,
content:'Saddle = 1778.599976 pos = 36.5884,138.4271 diff = 437.599976'
});
data_peak.push({
lat: 3.6601222222e+01,
lng: 1.3844066667e+02,
cert : true,
content:'Name = JA/GM-013(JA/GM-013) peak = 2004.199951 pos = 36.6012,138.4407 diff = 182.899902'
});
data_saddle.push({
lat: 3.6610888889e+01,
lng: 1.3844866667e+02,
content:'Saddle = 1821.300049 pos = 36.6109,138.4487 diff = 182.899902'
});
data_peak.push({
lat: 3.6628777778e+01,
lng: 1.3845855556e+02,
cert : true,
content:'Name = JA/GM-004(JA/GM-004) peak = 2163.800049 pos = 36.6288,138.4586 diff = 341.400024'
});
data_saddle.push({
lat: 3.6642222222e+01,
lng: 1.3849377778e+02,
content:'Saddle = 1822.400024 pos = 36.6422,138.4938 diff = 341.400024'
});
data_peak.push({
lat: 3.6623000000e+01,
lng: 1.3853166667e+02,
cert : false,
content:' Peak = 2170.699951 pos = 36.6230,138.5317 diff = 159.299927'
});
data_saddle.push({
lat: 3.6637777778e+01,
lng: 1.3853300000e+02,
content:'Saddle = 2011.400024 pos = 36.6378,138.5330 diff = 159.299927'
});
data_peak.push({
lat: 3.6549222222e+01,
lng: 1.3839511111e+02,
cert : false,
content:' Peak = 2205.800049 pos = 36.5492,138.3951 diff = 166.700073'
});
data_saddle.push({
lat: 3.6545999999e+01,
lng: 1.3840311111e+02,
content:'Saddle = 2039.099976 pos = 36.5460,138.4031 diff = 166.700073'
});
data_peak.push({
lat: 3.6464777776e+01,
lng: 1.3837088889e+02,
cert : true,
content:'Name = JA/NN-110(JA/NN-110) peak = 1643.900024 pos = 36.4648,138.3709 diff = 192.500000'
});
data_saddle.push({
lat: 3.6462777776e+01,
lng: 1.3838166667e+02,
content:'Saddle = 1451.400024 pos = 36.4628,138.3817 diff = 192.500000'
});
data_peak.push({
lat: 3.6454999999e+01,
lng: 1.3844855556e+02,
cert : false,
content:' Peak = 1745.199951 pos = 36.4550,138.4486 diff = 221.299927'
});
data_saddle.push({
lat: 3.6447666665e+01,
lng: 1.3844066667e+02,
content:'Saddle = 1523.900024 pos = 36.4477,138.4407 diff = 221.299927'
});
data_peak.push({
lat: 3.6434777776e+01,
lng: 1.3840088889e+02,
cert : true,
content:'Name = Yunomaruyama(JA/NN-059) peak = 2100.899902 pos = 36.4348,138.4009 diff = 370.499878'
});
data_saddle.push({
lat: 3.6427111110e+01,
lng: 1.3841966667e+02,
content:'Saddle = 1730.400024 pos = 36.4271,138.4197 diff = 370.499878'
});
data_peak.push({
lat: 3.6452999999e+01,
lng: 1.3840844444e+02,
cert : true,
content:'Name = JA/GM-014(JA/GM-014) peak = 1980.099976 pos = 36.4530,138.4084 diff = 172.699951'
});
data_saddle.push({
lat: 3.6448555554e+01,
lng: 1.3840200000e+02,
content:'Saddle = 1807.400024 pos = 36.4486,138.4020 diff = 172.699951'
});
data_peak.push({
lat: 3.6433444443e+01,
lng: 1.3838711111e+02,
cert : false,
content:' Peak = 2063.699951 pos = 36.4334,138.3871 diff = 210.899902'
});
data_saddle.push({
lat: 3.6432555554e+01,
lng: 1.3839411111e+02,
content:'Saddle = 1852.800049 pos = 36.4326,138.3941 diff = 210.899902'
});
data_peak.push({
lat: 3.6442444443e+01,
lng: 1.3842700000e+02,
cert : true,
content:'Name = JA/GM-020(JA/GM-020) peak = 1930.800049 pos = 36.4424,138.4270 diff = 197.200073'
});
data_saddle.push({
lat: 3.6437888887e+01,
lng: 1.3843088889e+02,
content:'Saddle = 1733.599976 pos = 36.4379,138.4309 diff = 197.200073'
});
data_peak.push({
lat: 3.6419333332e+01,
lng: 1.3844711111e+02,
cert : true,
content:'Name = Kagonotoyama (Higashikagonotoyama)(JA/NN-051) peak = 2226.399902 pos = 36.4193,138.4471 diff = 284.199951'
});
data_saddle.push({
lat: 3.6410444443e+01,
lng: 1.3845911111e+02,
content:'Saddle = 1942.199951 pos = 36.4104,138.4591 diff = 284.199951'
});
data_peak.push({
lat: 3.6392444443e+01,
lng: 1.3850344444e+02,
cert : false,
content:' Peak = 2281.600098 pos = 36.3924,138.5034 diff = 201.100098'
});
data_saddle.push({
lat: 3.6395444443e+01,
lng: 1.3850622222e+02,
content:'Saddle = 2080.500000 pos = 36.3954,138.5062 diff = 201.100098'
});
data_peak.push({
lat: 3.6405222220e+01,
lng: 1.3848855556e+02,
cert : false,
content:' Peak = 2402.800049 pos = 36.4052,138.4886 diff = 271.500000'
});
data_saddle.push({
lat: 3.6413777776e+01,
lng: 1.3850700000e+02,
content:'Saddle = 2131.300049 pos = 36.4138,138.5070 diff = 271.500000'
});
data_peak.push({
lat: 3.6094888885e+01,
lng: 1.3878333333e+02,
cert : false,
content:' Peak = 1130.199951 pos = 36.0949,138.7833 diff = 158.599976'
});
data_saddle.push({
lat: 3.6110555551e+01,
lng: 1.3878055556e+02,
content:'Saddle = 971.599976 pos = 36.1106,138.7806 diff = 158.599976'
});
data_peak.push({
lat: 3.6322333331e+01,
lng: 1.3811466667e+02,
cert : true,
content:'Name = JA/NN-163(JA/NN-163) peak = 1231.500000 pos = 36.3223,138.1147 diff = 259.000000'
});
data_saddle.push({
lat: 3.6324777775e+01,
lng: 1.3810188889e+02,
content:'Saddle = 972.500000 pos = 36.3248,138.1019 diff = 259.000000'
});
data_peak.push({
lat: 3.6300333331e+01,
lng: 1.3865855556e+02,
cert : true,
content:'Name = JA/GM-055(JA/GM-055) peak = 1190.400024 pos = 36.3003,138.6586 diff = 214.400024'
});
data_saddle.push({
lat: 3.6297777775e+01,
lng: 1.3864666667e+02,
content:'Saddle = 976.000000 pos = 36.2978,138.6467 diff = 214.400024'
});
data_peak.push({
lat: 3.6334222220e+01,
lng: 1.3865044444e+02,
cert : false,
content:' Peak = 1182.000000 pos = 36.3342,138.6504 diff = 150.400024'
});
data_saddle.push({
lat: 3.6320222220e+01,
lng: 1.3865100000e+02,
content:'Saddle = 1031.599976 pos = 36.3202,138.6510 diff = 150.400024'
});
data_peak.push({
lat: 3.5970888884e+01,
lng: 1.3837011111e+02,
cert : true,
content:'Name = Akadake(JA/YN-006) peak = 2894.800049 pos = 35.9709,138.3701 diff = 1910.500000'
});
data_saddle.push({
lat: 3.5446444435e+01,
lng: 1.3861111111e+02,
content:'Saddle = 984.299988 pos = 35.4464,138.6111 diff = 1910.500000'
});
data_peak.push({
lat: 3.6284555553e+01,
lng: 1.3863266667e+02,
cert : true,
content:'Name = JA/GM-054(JA/GM-054) peak = 1206.000000 pos = 36.2846,138.6327 diff = 213.799988'
});
data_saddle.push({
lat: 3.6288222220e+01,
lng: 1.3862611111e+02,
content:'Saddle = 992.200012 pos = 36.2882,138.6261 diff = 213.799988'
});
data_peak.push({
lat: 3.5829999994e+01,
lng: 1.3910177778e+02,
cert : true,
content:'Name = Honitayama(JA/TK-008) peak = 1222.599976 pos = 35.8300,139.1018 diff = 230.000000'
});
data_saddle.push({
lat: 3.5837999994e+01,
lng: 1.3910666667e+02,
content:'Saddle = 992.599976 pos = 35.8380,139.1067 diff = 230.000000'
});
data_peak.push({
lat: 3.6028777773e+01,
lng: 1.3800000000e+02,
cert : false,
content:' Peak = 1173.199951 pos = 36.0288,138.0000 diff = 156.299927'
});
data_saddle.push({
lat: 3.6086222218e+01,
lng: 1.3802911111e+02,
content:'Saddle = 1016.900024 pos = 36.0862,138.0291 diff = 156.299927'
});
data_peak.push({
lat: 3.6149222218e+01,
lng: 1.3894144444e+02,
cert : false,
content:' Peak = 1245.900024 pos = 36.1492,138.9414 diff = 223.100037'
});
data_saddle.push({
lat: 3.6150999996e+01,
lng: 1.3892644444e+02,
content:'Saddle = 1022.799988 pos = 36.1510,138.9264 diff = 223.100037'
});
data_peak.push({
lat: 3.6377666665e+01,
lng: 1.3803955556e+02,
cert : true,
content:'Name = JA/NN-154(JA/NN-154) peak = 1312.900024 pos = 36.3777,138.0396 diff = 281.099976'
});
data_saddle.push({
lat: 3.6378444442e+01,
lng: 1.3804966667e+02,
content:'Saddle = 1031.800049 pos = 36.3784,138.0497 diff = 281.099976'
});
data_peak.push({
lat: 3.5548333325e+01,
lng: 1.3861555556e+02,
cert : false,
content:' Peak = 1244.599976 pos = 35.5483,138.6156 diff = 202.599976'
});
data_saddle.push({
lat: 3.5560333325e+01,
lng: 1.3864022222e+02,
content:'Saddle = 1042.000000 pos = 35.5603,138.6402 diff = 202.599976'
});
data_peak.push({
lat: 3.5667888881e+01,
lng: 1.3902133333e+02,
cert : true,
content:'Name = Gongenyama(JA/YN-054) peak = 1311.199951 pos = 35.6679,139.0213 diff = 268.099976'
});
data_saddle.push({
lat: 3.5694222215e+01,
lng: 1.3898022222e+02,
content:'Saddle = 1043.099976 pos = 35.6942,138.9802 diff = 268.099976'
});
data_peak.push({
lat: 3.6143777774e+01,
lng: 1.3884322222e+02,
cert : true,
content:'Name = Akagunayama(JA/GM-030) peak = 1521.800049 pos = 36.1438,138.8432 diff = 469.200073'
});
data_saddle.push({
lat: 3.6121888885e+01,
lng: 1.3873933333e+02,
content:'Saddle = 1052.599976 pos = 36.1219,138.7393 diff = 469.200073'
});
data_peak.push({
lat: 3.6152333330e+01,
lng: 1.3891844444e+02,
cert : true,
content:'Name = Mikaboyama (Nishimikaboyama)(JA/GM-047) peak = 1284.800049 pos = 36.1523,138.9184 diff = 223.200073'
});
data_saddle.push({
lat: 3.6146333330e+01,
lng: 1.3889655556e+02,
content:'Saddle = 1061.599976 pos = 36.1463,138.8966 diff = 223.200073'
});
data_peak.push({
lat: 3.6169555552e+01,
lng: 1.3882511111e+02,
cert : false,
content:' Peak = 1365.500000 pos = 36.1696,138.8251 diff = 193.900024'
});
data_saddle.push({
lat: 3.6164555552e+01,
lng: 1.3882711111e+02,
content:'Saddle = 1171.599976 pos = 36.1646,138.8271 diff = 193.900024'
});
data_peak.push({
lat: 3.6398555554e+01,
lng: 1.3806344444e+02,
cert : false,
content:' Peak = 1437.699951 pos = 36.3986,138.0634 diff = 375.000000'
});
data_saddle.push({
lat: 3.6379999998e+01,
lng: 1.3807266667e+02,
content:'Saddle = 1062.699951 pos = 36.3800,138.0727 diff = 375.000000'
});
data_peak.push({
lat: 3.5562111103e+01,
lng: 1.3865255556e+02,
cert : false,
content:' Peak = 1235.099976 pos = 35.5621,138.6526 diff = 167.000000'
});
data_saddle.push({
lat: 3.5562999992e+01,
lng: 1.3867655556e+02,
content:'Saddle = 1068.099976 pos = 35.5630,138.6766 diff = 167.000000'
});
data_peak.push({
lat: 3.6247444441e+01,
lng: 1.3860444444e+02,
cert : true,
content:'Name = JA/NN-142(JA/NN-142) peak = 1373.800049 pos = 36.2474,138.6044 diff = 305.700073'
});
data_saddle.push({
lat: 3.6222666663e+01,
lng: 1.3861588889e+02,
content:'Saddle = 1068.099976 pos = 36.2227,138.6159 diff = 305.700073'
});
data_peak.push({
lat: 3.6278333331e+01,
lng: 1.3860044444e+02,
cert : false,
content:' Peak = 1322.900024 pos = 36.2783,138.6004 diff = 181.400024'
});
data_saddle.push({
lat: 3.6264888886e+01,
lng: 1.3860444444e+02,
content:'Saddle = 1141.500000 pos = 36.2649,138.6044 diff = 181.400024'
});
data_peak.push({
lat: 3.5415777768e+01,
lng: 1.3854366667e+02,
cert : true,
content:'Name = Kenashiyama(JA/SO-019) peak = 1962.000000 pos = 35.4158,138.5437 diff = 891.599976'
});
data_saddle.push({
lat: 3.5475999991e+01,
lng: 1.3857266667e+02,
content:'Saddle = 1070.400024 pos = 35.4760,138.5727 diff = 891.599976'
});
data_peak.push({
lat: 3.5340333323e+01,
lng: 1.3852200000e+02,
cert : false,
content:' Peak = 1300.400024 pos = 35.3403,138.5220 diff = 162.800049'
});
data_saddle.push({
lat: 3.5343999990e+01,
lng: 1.3852700000e+02,
content:'Saddle = 1137.599976 pos = 35.3440,138.5270 diff = 162.800049'
});
data_peak.push({
lat: 3.5446777768e+01,
lng: 1.3858355556e+02,
cert : false,
content:' Peak = 1484.199951 pos = 35.4468,138.5836 diff = 231.799927'
});
data_saddle.push({
lat: 3.5439666657e+01,
lng: 1.3857122222e+02,
content:'Saddle = 1252.400024 pos = 35.4397,138.5712 diff = 231.799927'
});
data_peak.push({
lat: 3.5381333323e+01,
lng: 1.3851255556e+02,
cert : true,
content:'Name = JA/YN-042(JA/YN-042) peak = 1633.500000 pos = 35.3813,138.5126 diff = 270.599976'
});
data_saddle.push({
lat: 3.5382666657e+01,
lng: 1.3853066667e+02,
content:'Saddle = 1362.900024 pos = 35.3827,138.5307 diff = 270.599976'
});
data_peak.push({
lat: 3.5518999991e+01,
lng: 1.3853577778e+02,
cert : true,
content:'Name = JA/YN-056(JA/YN-056) peak = 1272.099976 pos = 35.5190,138.5358 diff = 183.299927'
});
data_saddle.push({
lat: 3.5517777769e+01,
lng: 1.3858555556e+02,
content:'Saddle = 1088.800049 pos = 35.5178,138.5856 diff = 183.299927'
});
data_peak.push({
lat: 3.5552111103e+01,
lng: 1.3874933333e+02,
cert : false,
content:' Peak = 1792.099976 pos = 35.5521,138.7493 diff = 693.400024'
});
data_saddle.push({
lat: 3.5613111103e+01,
lng: 1.3878000000e+02,
content:'Saddle = 1098.699951 pos = 35.6131,138.7800 diff = 693.400024'
});
data_peak.push({
lat: 3.5504777769e+01,
lng: 1.3860255556e+02,
cert : true,
content:'Name = JA/YN-051(JA/YN-051) peak = 1420.900024 pos = 35.5048,138.6026 diff = 233.500000'
});
data_saddle.push({
lat: 3.5503999991e+01,
lng: 1.3861022222e+02,
content:'Saddle = 1187.400024 pos = 35.5040,138.6102 diff = 233.500000'
});
data_peak.push({
lat: 3.5580888881e+01,
lng: 1.3869977778e+02,
cert : false,
content:' Peak = 1413.500000 pos = 35.5809,138.6998 diff = 202.699951'
});
data_saddle.push({
lat: 3.5570222214e+01,
lng: 1.3870455556e+02,
content:'Saddle = 1210.800049 pos = 35.5702,138.7046 diff = 202.699951'
});
data_peak.push({
lat: 3.5605888881e+01,
lng: 1.3875922222e+02,
cert : true,
content:'Name = JA/YN-046(JA/YN-046) peak = 1485.500000 pos = 35.6059,138.7592 diff = 198.699951'
});
data_saddle.push({
lat: 3.5597333325e+01,
lng: 1.3877122222e+02,
content:'Saddle = 1286.800049 pos = 35.5973,138.7712 diff = 198.699951'
});
data_peak.push({
lat: 3.5549333325e+01,
lng: 1.3880911111e+02,
cert : true,
content:'Name = Mitsutougeyama(JA/YN-032) peak = 1783.699951 pos = 35.5493,138.8091 diff = 356.099976'
});
data_saddle.push({
lat: 3.5559222214e+01,
lng: 1.3878066667e+02,
content:'Saddle = 1427.599976 pos = 35.5592,138.7807 diff = 356.099976'
});
data_peak.push({
lat: 3.5574888880e+01,
lng: 1.3880733333e+02,
cert : true,
content:'Name = JA/YN-043(JA/YN-043) peak = 1630.500000 pos = 35.5749,138.8073 diff = 177.699951'
});
data_saddle.push({
lat: 3.5566111103e+01,
lng: 1.3879922222e+02,
content:'Saddle = 1452.800049 pos = 35.5661,138.7992 diff = 177.699951'
});
data_peak.push({
lat: 3.5562888880e+01,
lng: 1.3872088889e+02,
cert : false,
content:' Peak = 1640.300049 pos = 35.5629,138.7209 diff = 188.100098'
});
data_saddle.push({
lat: 3.5561777769e+01,
lng: 1.3873955556e+02,
content:'Saddle = 1452.199951 pos = 35.5618,138.7396 diff = 188.100098'
});
data_peak.push({
lat: 3.5528555547e+01,
lng: 1.3868333333e+02,
cert : false,
content:' Peak = 1735.400024 pos = 35.5286,138.6833 diff = 224.300049'
});
data_saddle.push({
lat: 3.5535777769e+01,
lng: 1.3870288889e+02,
content:'Saddle = 1511.099976 pos = 35.5358,138.7029 diff = 224.300049'
});
data_peak.push({
lat: 3.6139888885e+01,
lng: 1.3859311111e+02,
cert : true,
content:'Name = JA/NN-125(JA/NN-125) peak = 1480.199951 pos = 36.1399,138.5931 diff = 372.799927'
});
data_saddle.push({
lat: 3.6136111107e+01,
lng: 1.3860777778e+02,
content:'Saddle = 1107.400024 pos = 36.1361,138.6078 diff = 372.799927'
});
data_peak.push({
lat: 3.6203999997e+01,
lng: 1.3863711111e+02,
cert : true,
content:'Name = Arafuneyama(JA/GM-035) peak = 1421.699951 pos = 36.2040,138.6371 diff = 289.799927'
});
data_saddle.push({
lat: 3.6188666663e+01,
lng: 1.3860566667e+02,
content:'Saddle = 1131.900024 pos = 36.1887,138.6057 diff = 289.799927'
});
data_peak.push({
lat: 3.6176666663e+01,
lng: 1.3859322222e+02,
cert : false,
content:' Peak = 1301.599976 pos = 36.1767,138.5932 diff = 157.599976'
});
data_saddle.push({
lat: 3.6177888885e+01,
lng: 1.3859055556e+02,
content:'Saddle = 1144.000000 pos = 36.1779,138.5906 diff = 157.599976'
});
data_peak.push({
lat: 3.5622111103e+01,
lng: 1.3881333333e+02,
cert : true,
content:'Name = JA/YN-050(JA/YN-050) peak = 1433.699951 pos = 35.6221,138.8133 diff = 303.899902'
});
data_saddle.push({
lat: 3.5627888881e+01,
lng: 1.3881877778e+02,
content:'Saddle = 1129.800049 pos = 35.6279,138.8188 diff = 303.899902'
});
data_peak.push({
lat: 3.5775777771e+01,
lng: 1.3854244444e+02,
cert : false,
content:' Peak = 1321.699951 pos = 35.7758,138.5424 diff = 159.099976'
});
data_saddle.push({
lat: 3.5781333327e+01,
lng: 1.3854433333e+02,
content:'Saddle = 1162.599976 pos = 35.7813,138.5443 diff = 159.099976'
});
data_peak.push({
lat: 3.5850777772e+01,
lng: 1.3910688889e+02,
cert : false,
content:' Peak = 1362.199951 pos = 35.8508,139.1069 diff = 185.500000'
});
data_saddle.push({
lat: 3.5859333327e+01,
lng: 1.3910188889e+02,
content:'Saddle = 1176.699951 pos = 35.8593,139.1019 diff = 185.500000'
});
data_peak.push({
lat: 3.5778222215e+01,
lng: 1.3858811111e+02,
cert : true,
content:'Name = JA/YN-048(JA/YN-048) peak = 1474.000000 pos = 35.7782,138.5881 diff = 191.699951'
});
data_saddle.push({
lat: 3.5782999993e+01,
lng: 1.3859222222e+02,
content:'Saddle = 1282.300049 pos = 35.7830,138.5922 diff = 191.699951'
});
data_peak.push({
lat: 3.6333222220e+01,
lng: 1.3806288889e+02,
cert : true,
content:'Name = JA/NN-113(JA/NN-113) peak = 1624.300049 pos = 36.3332,138.0629 diff = 311.400024'
});
data_saddle.push({
lat: 3.6302777775e+01,
lng: 1.3807822222e+02,
content:'Saddle = 1312.900024 pos = 36.3028,138.0782 diff = 311.400024'
});
data_peak.push({
lat: 3.5767444438e+01,
lng: 1.3888811111e+02,
cert : false,
content:' Peak = 1540.900024 pos = 35.7674,138.8881 diff = 178.900024'
});
data_saddle.push({
lat: 3.5759888882e+01,
lng: 1.3887600000e+02,
content:'Saddle = 1362.000000 pos = 35.7599,138.8760 diff = 178.900024'
});
data_peak.push({
lat: 3.6023444440e+01,
lng: 1.3884122222e+02,
cert : true,
content:'Name = Ryoukamisan(JA/ST-002) peak = 1722.500000 pos = 36.0234,138.8412 diff = 360.000000'
});
data_saddle.push({
lat: 3.6033888884e+01,
lng: 1.3878266667e+02,
content:'Saddle = 1362.500000 pos = 36.0339,138.7827 diff = 360.000000'
});
data_peak.push({
lat: 3.5758444438e+01,
lng: 1.3860477778e+02,
cert : true,
content:'Name = JA/YN-045(JA/YN-045) peak = 1552.800049 pos = 35.7584,138.6048 diff = 189.400024'
});
data_saddle.push({
lat: 3.5770777771e+01,
lng: 1.3860977778e+02,
content:'Saddle = 1363.400024 pos = 35.7708,138.6098 diff = 189.400024'
});
data_peak.push({
lat: 3.5803222216e+01,
lng: 1.3850933333e+02,
cert : true,
content:'Name = JA/YN-035(JA/YN-035) peak = 1763.599976 pos = 35.8032,138.5093 diff = 391.299927'
});
data_saddle.push({
lat: 3.5805666660e+01,
lng: 1.3852388889e+02,
content:'Saddle = 1372.300049 pos = 35.8057,138.5239 diff = 391.299927'
});
data_peak.push({
lat: 3.5868666661e+01,
lng: 1.3867066667e+02,
cert : true,
content:'Name = Kitaokusenjyoudake(JA/YN-012) peak = 2600.699951 pos = 35.8687,138.6707 diff = 1224.500000'
});
data_saddle.push({
lat: 3.5944777772e+01,
lng: 1.3845211111e+02,
content:'Saddle = 1376.199951 pos = 35.9448,138.4521 diff = 1224.500000'
});
data_peak.push({
lat: 3.5816666660e+01,
lng: 1.3883922222e+02,
cert : true,
content:'Name = JA/YN-044(JA/YN-044) peak = 1605.300049 pos = 35.8167,138.8392 diff = 226.900024'
});
data_saddle.push({
lat: 3.5822777771e+01,
lng: 1.3883066667e+02,
content:'Saddle = 1378.400024 pos = 35.8228,138.8307 diff = 226.900024'
});
data_peak.push({
lat: 3.6012777773e+01,
lng: 1.3858655556e+02,
cert : true,
content:'Name = JA/NN-112(JA/NN-112) peak = 1631.800049 pos = 36.0128,138.5866 diff = 234.900024'
});
data_saddle.push({
lat: 3.6010333328e+01,
lng: 1.3860044444e+02,
content:'Saddle = 1396.900024 pos = 36.0103,138.6004 diff = 234.900024'
});
data_peak.push({
lat: 3.5961555550e+01,
lng: 1.3858411111e+02,
cert : true,
content:'Name = JA/NN-104(JA/NN-104) peak = 1662.800049 pos = 35.9616,138.5841 diff = 231.500000'
});
data_saddle.push({
lat: 3.5950777772e+01,
lng: 1.3858511111e+02,
content:'Saddle = 1431.300049 pos = 35.9508,138.5851 diff = 231.500000'
});
data_peak.push({
lat: 3.5918777772e+01,
lng: 1.3852111111e+02,
cert : true,
content:'Name = Yokooyama(JA/YN-030) peak = 1814.400024 pos = 35.9188,138.5211 diff = 347.500000'
});
data_saddle.push({
lat: 3.5915111105e+01,
lng: 1.3854233333e+02,
content:'Saddle = 1466.900024 pos = 35.9151,138.5423 diff = 347.500000'
});
data_peak.push({
lat: 3.5938555550e+01,
lng: 1.3852433333e+02,
cert : false,
content:' Peak = 1731.500000 pos = 35.9386,138.5243 diff = 169.699951'
});
data_saddle.push({
lat: 3.5932666661e+01,
lng: 1.3852000000e+02,
content:'Saddle = 1561.800049 pos = 35.9327,138.5200 diff = 169.699951'
});
data_peak.push({
lat: 3.6023999995e+01,
lng: 1.3875077778e+02,
cert : false,
content:' Peak = 1656.599976 pos = 36.0240,138.7508 diff = 183.400024'
});
data_saddle.push({
lat: 3.6007555551e+01,
lng: 1.3873900000e+02,
content:'Saddle = 1473.199951 pos = 36.0076,138.7390 diff = 183.400024'
});
data_peak.push({
lat: 3.5748777771e+01,
lng: 1.3884544444e+02,
cert : true,
content:'Name = Daibosatsurei(JA/YN-024) peak = 2056.399902 pos = 35.7488,138.8454 diff = 579.499878'
});
data_saddle.push({
lat: 3.5777111104e+01,
lng: 1.3880211111e+02,
content:'Saddle = 1476.900024 pos = 35.7771,138.8021 diff = 579.499878'
});
data_peak.push({
lat: 3.5788555549e+01,
lng: 1.3883555556e+02,
cert : false,
content:' Peak = 1714.000000 pos = 35.7886,138.8356 diff = 157.500000'
});
data_saddle.push({
lat: 3.5787333327e+01,
lng: 1.3882644444e+02,
content:'Saddle = 1556.500000 pos = 35.7873,138.8264 diff = 157.500000'
});
data_peak.push({
lat: 3.5686777770e+01,
lng: 1.3888477778e+02,
cert : false,
content:' Peak = 1873.099976 pos = 35.6868,138.8848 diff = 311.900024'
});
data_saddle.push({
lat: 3.5687111104e+01,
lng: 1.3887766667e+02,
content:'Saddle = 1561.199951 pos = 35.6871,138.8777 diff = 311.900024'
});
data_peak.push({
lat: 3.5811777771e+01,
lng: 1.3878311111e+02,
cert : true,
content:'Name = JA/YN-033(JA/YN-033) peak = 1773.599976 pos = 35.8118,138.7831 diff = 285.699951'
});
data_saddle.push({
lat: 3.5831111105e+01,
lng: 1.3878777778e+02,
content:'Saddle = 1487.900024 pos = 35.8311,138.7878 diff = 285.699951'
});
data_peak.push({
lat: 3.6111888885e+01,
lng: 1.3854766667e+02,
cert : true,
content:'Name = JA/NN-094(JA/NN-094) peak = 1716.699951 pos = 36.1119,138.5477 diff = 212.699951'
});
data_saddle.push({
lat: 3.6063999996e+01,
lng: 1.3864244444e+02,
content:'Saddle = 1504.000000 pos = 36.0640,138.6424 diff = 212.699951'
});
data_peak.push({
lat: 3.6094888885e+01,
lng: 1.3862488889e+02,
cert : false,
content:' Peak = 1683.599976 pos = 36.0949,138.6249 diff = 150.799927'
});
data_saddle.push({
lat: 3.6096777774e+01,
lng: 1.3860633333e+02,
content:'Saddle = 1532.800049 pos = 36.0968,138.6063 diff = 150.799927'
});
data_peak.push({
lat: 3.5874444438e+01,
lng: 1.3857200000e+02,
cert : false,
content:' Peak = 1703.099976 pos = 35.8744,138.5720 diff = 185.699951'
});
data_saddle.push({
lat: 3.5875999994e+01,
lng: 1.3857811111e+02,
content:'Saddle = 1517.400024 pos = 35.8760,138.5781 diff = 185.699951'
});
data_peak.push({
lat: 3.5781666660e+01,
lng: 1.3866411111e+02,
cert : true,
content:'Name = Konarayama(JA/YN-037) peak = 1712.099976 pos = 35.7817,138.6641 diff = 183.699951'
});
data_saddle.push({
lat: 3.5796333327e+01,
lng: 1.3864888889e+02,
content:'Saddle = 1528.400024 pos = 35.7963,138.6489 diff = 183.699951'
});
data_peak.push({
lat: 3.5864555549e+01,
lng: 1.3898988889e+02,
cert : false,
content:' Peak = 1722.199951 pos = 35.8646,138.9899 diff = 180.500000'
});
data_saddle.push({
lat: 3.5870999994e+01,
lng: 1.3898388889e+02,
content:'Saddle = 1541.699951 pos = 35.8710,138.9839 diff = 180.500000'
});
data_peak.push({
lat: 3.5897111105e+01,
lng: 1.3901022222e+02,
cert : true,
content:'Name = Toridaniyama(JA/TK-004) peak = 1716.900024 pos = 35.8971,139.0102 diff = 166.800049'
});
data_saddle.push({
lat: 3.5890999994e+01,
lng: 1.3900644444e+02,
content:'Saddle = 1550.099976 pos = 35.8910,139.0064 diff = 166.800049'
});
data_peak.push({
lat: 3.5829888883e+01,
lng: 1.3901233333e+02,
cert : true,
content:'Name = Takanosuyama(JA/TK-003) peak = 1734.699951 pos = 35.8299,139.0123 diff = 181.599976'
});
data_saddle.push({
lat: 3.5828222216e+01,
lng: 1.3900200000e+02,
content:'Saddle = 1553.099976 pos = 35.8282,139.0020 diff = 181.599976'
});
data_peak.push({
lat: 3.5828777771e+01,
lng: 1.3857177778e+02,
cert : true,
content:'Name = JA/YN-034(JA/YN-034) peak = 1773.900024 pos = 35.8288,138.5718 diff = 181.400024'
});
data_saddle.push({
lat: 3.5829222216e+01,
lng: 1.3858055556e+02,
content:'Saddle = 1592.500000 pos = 35.8292,138.5806 diff = 181.400024'
});
data_peak.push({
lat: 3.5991777773e+01,
lng: 1.3856900000e+02,
cert : true,
content:'Name = JA/NN-081(JA/NN-081) peak = 1880.699951 pos = 35.9918,138.5690 diff = 268.399902'
});
data_saddle.push({
lat: 3.5991444439e+01,
lng: 1.3862600000e+02,
content:'Saddle = 1612.300049 pos = 35.9914,138.6260 diff = 268.399902'
});
data_peak.push({
lat: 3.5991111106e+01,
lng: 1.3860100000e+02,
cert : true,
content:'Name = JA/NN-087(JA/NN-087) peak = 1821.500000 pos = 35.9911,138.6010 diff = 204.400024'
});
data_saddle.push({
lat: 3.5993222217e+01,
lng: 1.3857866667e+02,
content:'Saddle = 1617.099976 pos = 35.9932,138.5787 diff = 204.400024'
});
data_peak.push({
lat: 3.5993888884e+01,
lng: 1.3854744444e+02,
cert : false,
content:' Peak = 1853.500000 pos = 35.9939,138.5474 diff = 160.800049'
});
data_saddle.push({
lat: 3.5993555551e+01,
lng: 1.3856277778e+02,
content:'Saddle = 1692.699951 pos = 35.9936,138.5628 diff = 160.800049'
});
data_peak.push({
lat: 3.5960666661e+01,
lng: 1.3877433333e+02,
cert : false,
content:' Peak = 1815.900024 pos = 35.9607,138.7743 diff = 182.800049'
});
data_saddle.push({
lat: 3.5958777772e+01,
lng: 1.3876477778e+02,
content:'Saddle = 1633.099976 pos = 35.9588,138.7648 diff = 182.800049'
});
data_peak.push({
lat: 3.6033888884e+01,
lng: 1.3860733333e+02,
cert : true,
content:'Name = Ogurasan(JA/NN-058) peak = 2112.100098 pos = 36.0339,138.6073 diff = 419.100098'
});
data_saddle.push({
lat: 3.6016555551e+01,
lng: 1.3865822222e+02,
content:'Saddle = 1693.000000 pos = 36.0166,138.6582 diff = 419.100098'
});
data_peak.push({
lat: 3.5874111105e+01,
lng: 1.3895422222e+02,
cert : true,
content:'Name = Imotokinodokke(JA/TK-002) peak = 1944.800049 pos = 35.8741,138.9542 diff = 241.900024'
});
data_saddle.push({
lat: 3.5866222216e+01,
lng: 1.3894566667e+02,
content:'Saddle = 1702.900024 pos = 35.8662,138.9457 diff = 241.900024'
});
data_peak.push({
lat: 3.5991777773e+01,
lng: 1.3868888889e+02,
cert : true,
content:'Name = JA/NN-071(JA/NN-071) peak = 1976.800049 pos = 35.9918,138.6889 diff = 254.900024'
});
data_saddle.push({
lat: 3.5976888884e+01,
lng: 1.3871177778e+02,
content:'Saddle = 1721.900024 pos = 35.9769,138.7118 diff = 254.900024'
});
data_peak.push({
lat: 3.5855555549e+01,
lng: 1.3894388889e+02,
cert : true,
content:'Name = Kumotoriyama(JA/TK-001) peak = 2015.699951 pos = 35.8556,138.9439 diff = 273.500000'
});
data_saddle.push({
lat: 3.5850666660e+01,
lng: 1.3892100000e+02,
content:'Saddle = 1742.199951 pos = 35.8507,138.9210 diff = 273.500000'
});
data_peak.push({
lat: 3.5867777772e+01,
lng: 1.3884533333e+02,
cert : true,
content:'Name = Karamatsuoyama(JA/YN-022) peak = 2108.199951 pos = 35.8678,138.8453 diff = 325.500000'
});
data_saddle.push({
lat: 3.5864777772e+01,
lng: 1.3881111111e+02,
content:'Saddle = 1782.699951 pos = 35.8648,138.8111 diff = 325.500000'
});
data_peak.push({
lat: 3.5839888883e+01,
lng: 1.3889222222e+02,
cert : true,
content:'Name = Ooborayama (Hiryuuyama)(JA/YN-023) peak = 2074.300049 pos = 35.8399,138.8922 diff = 277.200073'
});
data_saddle.push({
lat: 3.5858999994e+01,
lng: 1.3886255556e+02,
content:'Saddle = 1797.099976 pos = 35.8590,138.8626 diff = 277.200073'
});
data_peak.push({
lat: 3.5854999994e+01,
lng: 1.3887222222e+02,
cert : false,
content:' Peak = 2011.000000 pos = 35.8550,138.8722 diff = 187.900024'
});
data_saddle.push({
lat: 3.5844444438e+01,
lng: 1.3888755556e+02,
content:'Saddle = 1823.099976 pos = 35.8444,138.8876 diff = 187.900024'
});
data_peak.push({
lat: 3.5841333327e+01,
lng: 1.3870977778e+02,
cert : true,
content:'Name = JA/YN-018(JA/YN-018) peak = 2231.300049 pos = 35.8413,138.7098 diff = 268.300049'
});
data_saddle.push({
lat: 3.5836999994e+01,
lng: 1.3869700000e+02,
content:'Saddle = 1963.000000 pos = 35.8370,138.6970 diff = 268.300049'
});
data_peak.push({
lat: 3.5909444439e+01,
lng: 1.3861255556e+02,
cert : true,
content:'Name = JA/NN-036(JA/NN-036) peak = 2413.199951 pos = 35.9094,138.6126 diff = 360.699951'
});
data_saddle.push({
lat: 3.5886444439e+01,
lng: 1.3860611111e+02,
content:'Saddle = 2052.500000 pos = 35.8864,138.6061 diff = 360.699951'
});
data_peak.push({
lat: 3.5901888883e+01,
lng: 1.3875866667e+02,
cert : true,
content:'Name = JA/YN-017(JA/YN-017) peak = 2316.699951 pos = 35.9019,138.7587 diff = 233.800049'
});
data_saddle.push({
lat: 3.5902111105e+01,
lng: 1.3875066667e+02,
content:'Saddle = 2082.899902 pos = 35.9021,138.7507 diff = 233.800049'
});
data_peak.push({
lat: 3.5917888883e+01,
lng: 1.3872744444e+02,
cert : true,
content:'Name = Sanpouyama(JA/ST-001) peak = 2483.899902 pos = 35.9179,138.7274 diff = 332.000000'
});
data_saddle.push({
lat: 3.5889333327e+01,
lng: 1.3868455556e+02,
content:'Saddle = 2151.899902 pos = 35.8893,138.6846 diff = 332.000000'
});
data_peak.push({
lat: 3.5871666661e+01,
lng: 1.3862544444e+02,
cert : true,
content:'Name = Kinpusan(JA/YN-013) peak = 2597.899902 pos = 35.8717,138.6254 diff = 234.899902'
});
data_saddle.push({
lat: 3.5873222216e+01,
lng: 1.3866255556e+02,
content:'Saddle = 2363.000000 pos = 35.8732,138.6626 diff = 234.899902'
});
data_peak.push({
lat: 3.6225888886e+01,
lng: 1.3810744444e+02,
cert : true,
content:'Name = Utsukushigahara (Ougatou)(JA/NN-067) peak = 2033.699951 pos = 36.2259,138.1074 diff = 602.599976'
});
data_saddle.push({
lat: 3.6112666663e+01,
lng: 1.3824144444e+02,
content:'Saddle = 1431.099976 pos = 36.1127,138.2414 diff = 602.599976'
});
data_peak.push({
lat: 3.6287111108e+01,
lng: 1.3803988889e+02,
cert : false,
content:' Peak = 1628.300049 pos = 36.2871,138.0399 diff = 194.500000'
});
data_saddle.push({
lat: 3.6286333331e+01,
lng: 1.3805433333e+02,
content:'Saddle = 1433.800049 pos = 36.2863,138.0543 diff = 194.500000'
});
data_peak.push({
lat: 3.6158555552e+01,
lng: 1.3819377778e+02,
cert : true,
content:'Name = JA/NN-101(JA/NN-101) peak = 1671.500000 pos = 36.1586,138.1938 diff = 214.800049'
});
data_saddle.push({
lat: 3.6151666663e+01,
lng: 1.3818733333e+02,
content:'Saddle = 1456.699951 pos = 36.1517,138.1873 diff = 214.800049'
});
data_peak.push({
lat: 3.6151333330e+01,
lng: 1.3821933333e+02,
cert : false,
content:' Peak = 1657.199951 pos = 36.1513,138.2193 diff = 176.299927'
});
data_saddle.push({
lat: 3.6153222218e+01,
lng: 1.3820966667e+02,
content:'Saddle = 1480.900024 pos = 36.1532,138.2097 diff = 176.299927'
});
data_peak.push({
lat: 3.6163111107e+01,
lng: 1.3805911111e+02,
cert : true,
content:'Name = Hachibuseyama(JA/NN-075) peak = 1928.300049 pos = 36.1631,138.0591 diff = 415.800049'
});
data_saddle.push({
lat: 3.6163111107e+01,
lng: 1.3810000000e+02,
content:'Saddle = 1512.500000 pos = 36.1631,138.1000 diff = 415.800049'
});
data_peak.push({
lat: 3.6102999996e+01,
lng: 1.3819655556e+02,
cert : true,
content:'Name = Kirigamine (Kurumayama)(JA/NN-076) peak = 1924.699951 pos = 36.1030,138.1966 diff = 408.299927'
});
data_saddle.push({
lat: 3.6145222218e+01,
lng: 1.3814388889e+02,
content:'Saddle = 1516.400024 pos = 36.1452,138.1439 diff = 408.299927'
});
data_peak.push({
lat: 3.6130111107e+01,
lng: 1.3815433333e+02,
cert : true,
content:'Name = JA/NN-089(JA/NN-089) peak = 1794.300049 pos = 36.1301,138.1543 diff = 161.800049'
});
data_saddle.push({
lat: 3.6121999996e+01,
lng: 1.3816500000e+02,
content:'Saddle = 1632.500000 pos = 36.1220,138.1650 diff = 161.800049'
});
data_peak.push({
lat: 3.6166444441e+01,
lng: 1.3812800000e+02,
cert : true,
content:'Name = JA/NN-080(JA/NN-080) peak = 1883.300049 pos = 36.1664,138.1280 diff = 279.300049'
});
data_saddle.push({
lat: 3.6181111108e+01,
lng: 1.3812788889e+02,
content:'Saddle = 1604.000000 pos = 36.1811,138.1279 diff = 279.300049'
});
data_peak.push({
lat: 3.6103777774e+01,
lng: 1.3829500000e+02,
cert : true,
content:'Name = Tateshinayama(JA/NN-031) peak = 2530.300049 pos = 36.1038,138.2950 diff = 443.300049'
});
data_saddle.push({
lat: 3.6111999996e+01,
lng: 1.3831922222e+02,
content:'Saddle = 2087.000000 pos = 36.1120,138.3192 diff = 443.300049'
});
data_peak.push({
lat: 3.6087555551e+01,
lng: 1.3832000000e+02,
cert : true,
content:'Name = Yokodake(JA/NN-032) peak = 2481.899902 pos = 36.0876,138.3200 diff = 362.799805'
});
data_saddle.push({
lat: 3.6059555551e+01,
lng: 1.3834677778e+02,
content:'Saddle = 2119.100098 pos = 36.0596,138.3468 diff = 362.799805'
});
data_peak.push({
lat: 3.6075333329e+01,
lng: 1.3833144444e+02,
cert : true,
content:'Name = Shimagareyama(JA/NN-037) peak = 2402.399902 pos = 36.0753,138.3314 diff = 153.599854'
});
data_saddle.push({
lat: 3.6079333329e+01,
lng: 1.3832600000e+02,
content:'Saddle = 2248.800049 pos = 36.0793,138.3260 diff = 153.599854'
});
data_peak.push({
lat: 3.6019222217e+01,
lng: 1.3835544444e+02,
cert : true,
content:'Name = Tengudake(JA/NN-024) peak = 2644.699951 pos = 36.0192,138.3554 diff = 212.099854'
});
data_saddle.push({
lat: 3.6006444439e+01,
lng: 1.3836477778e+02,
content:'Saddle = 2432.600098 pos = 36.0064,138.3648 diff = 212.099854'
});
data_peak.push({
lat: 3.5949888883e+01,
lng: 1.3835966667e+02,
cert : true,
content:'Name = Gongendake(JA/YN-009) peak = 2708.399902 pos = 35.9499,138.3597 diff = 256.699951'
});
data_saddle.push({
lat: 3.5963999995e+01,
lng: 1.3836333333e+02,
content:'Saddle = 2451.699951 pos = 35.9640,138.3633 diff = 256.699951'
});
data_peak.push({
lat: 3.5972555550e+01,
lng: 1.3835866667e+02,
cert : false,
content:' Peak = 2802.399902 pos = 35.9726,138.3587 diff = 160.899902'
});
data_saddle.push({
lat: 3.5971999995e+01,
lng: 1.3836133333e+02,
content:'Saddle = 2641.500000 pos = 35.9720,138.3613 diff = 160.899902'
});
data_peak.push({
lat: 3.5494222213e+01,
lng: 1.3870755556e+02,
cert : true,
content:'Name = JA/YN-053(JA/YN-053) peak = 1353.900024 pos = 35.4942,138.7076 diff = 345.600037'
});
data_saddle.push({
lat: 3.5481444435e+01,
lng: 1.3867266667e+02,
content:'Saddle = 1008.299988 pos = 35.4814,138.6727 diff = 345.600037'
});
data_peak.push({
lat: 3.5486999991e+01,
lng: 1.3893155556e+02,
cert : true,
content:'Name = Mishoutaiyama(JA/YN-038) peak = 1681.300049 pos = 35.4870,138.9316 diff = 633.400024'
});
data_saddle.push({
lat: 3.5428333324e+01,
lng: 1.3892966667e+02,
content:'Saddle = 1047.900024 pos = 35.4283,138.9297 diff = 633.400024'
});
data_peak.push({
lat: 3.5486333324e+01,
lng: 1.3913888889e+02,
cert : true,
content:'Name = Tanzawasan (Hirugatake)(JA/KN-001) peak = 1672.500000 pos = 35.4863,139.1389 diff = 611.099976'
});
data_saddle.push({
lat: 3.5495111102e+01,
lng: 1.3907733333e+02,
content:'Saddle = 1061.400024 pos = 35.4951,139.0773 diff = 611.099976'
});
data_peak.push({
lat: 3.5479111102e+01,
lng: 1.3910277778e+02,
cert : true,
content:'Name = Hinokiboramaru(JA/KN-002) peak = 1600.699951 pos = 35.4791,139.1028 diff = 343.599976'
});
data_saddle.push({
lat: 3.5477222213e+01,
lng: 1.3912077778e+02,
content:'Saddle = 1257.099976 pos = 35.4772,139.1208 diff = 343.599976'
});
data_peak.push({
lat: 3.5465888880e+01,
lng: 1.3910455556e+02,
cert : false,
content:' Peak = 1490.599976 pos = 35.4659,139.1046 diff = 167.900024'
});
data_saddle.push({
lat: 3.5471111102e+01,
lng: 1.3910122222e+02,
content:'Saddle = 1322.699951 pos = 35.4711,139.1012 diff = 167.900024'
});
data_peak.push({
lat: 3.5544333325e+01,
lng: 1.3902444444e+02,
cert : false,
content:' Peak = 1298.199951 pos = 35.5443,139.0244 diff = 226.000000'
});
data_saddle.push({
lat: 3.5534444436e+01,
lng: 1.3900644444e+02,
content:'Saddle = 1072.199951 pos = 35.5344,139.0064 diff = 226.000000'
});
data_peak.push({
lat: 3.5508111102e+01,
lng: 1.3885577778e+02,
cert : false,
content:' Peak = 1254.900024 pos = 35.5081,138.8558 diff = 162.200073'
});
data_saddle.push({
lat: 3.5499444435e+01,
lng: 1.3885677778e+02,
content:'Saddle = 1092.699951 pos = 35.4994,138.8568 diff = 162.200073'
});
data_peak.push({
lat: 3.5521888880e+01,
lng: 1.3896955556e+02,
cert : true,
content:'Name = JA/YN-047(JA/YN-047) peak = 1482.099976 pos = 35.5219,138.9696 diff = 369.099976'
});
data_saddle.push({
lat: 3.5509999991e+01,
lng: 1.3897088889e+02,
content:'Saddle = 1113.000000 pos = 35.5100,138.9709 diff = 369.099976'
});
data_peak.push({
lat: 3.5510888880e+01,
lng: 1.3906833333e+02,
cert : true,
content:'Name = Oomuroyama(JA/KN-003) peak = 1586.400024 pos = 35.5109,139.0683 diff = 463.599976'
});
data_saddle.push({
lat: 3.5481222213e+01,
lng: 1.3902488889e+02,
content:'Saddle = 1122.800049 pos = 35.4812,139.0249 diff = 463.599976'
});
data_peak.push({
lat: 3.5463777768e+01,
lng: 1.3897844444e+02,
cert : true,
content:'Name = Komotsurushiyama(JA/KN-005) peak = 1375.500000 pos = 35.4638,138.9784 diff = 233.599976'
});
data_saddle.push({
lat: 3.5451888880e+01,
lng: 1.3893188889e+02,
content:'Saddle = 1141.900024 pos = 35.4519,138.9319 diff = 233.599976'
});
data_peak.push({
lat: 3.5485777769e+01,
lng: 1.3887622222e+02,
cert : true,
content:'Name = JA/YN-041(JA/YN-041) peak = 1640.199951 pos = 35.4858,138.8762 diff = 487.500000'
});
data_saddle.push({
lat: 3.5457111102e+01,
lng: 1.3889255556e+02,
content:'Saddle = 1152.699951 pos = 35.4571,138.8926 diff = 487.500000'
});
data_peak.push({
lat: 3.5389666657e+01,
lng: 1.3889177778e+02,
cert : true,
content:'Name = JA/SO-031(JA/SO-031) peak = 1382.800049 pos = 35.3897,138.8918 diff = 274.700073'
});
data_saddle.push({
lat: 3.5393333323e+01,
lng: 1.3886377778e+02,
content:'Saddle = 1108.099976 pos = 35.3933,138.8638 diff = 274.700073'
});
data_peak.push({
lat: 3.5440888879e+01,
lng: 1.3865355556e+02,
cert : false,
content:' Peak = 1467.599976 pos = 35.4409,138.6536 diff = 203.500000'
});
data_saddle.push({
lat: 3.5433999990e+01,
lng: 1.3865644444e+02,
content:'Saddle = 1264.099976 pos = 35.4340,138.6564 diff = 203.500000'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:36.6667,
       south:34,
       east:140,
       west:138}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
