function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 2.9859333333e+01,
lng: 1.2985688889e+02,
cert : true,
content:'Name = Ontake(JA6/KG-012) peak = 977.799988 pos = 29.8593,129.8569 diff = 977.799988'
});
data_saddle.push({
lat: 2.9998111111e+01,
lng: 1.2991977778e+02,
content:'Saddle = 0.000000 pos = 29.9981,129.9198 diff = 977.799988'
});
data_peak.push({
lat: 2.9968111111e+01,
lng: 1.2992544444e+02,
cert : true,
content:'Name = Maedake(JA6/KG-040) peak = 626.599976 pos = 29.9681,129.9254 diff = 626.599976'
});
data_saddle.push({
lat: 2.9949000000e+01,
lng: 1.2993522222e+02,
content:'Saddle = 0.000000 pos = 29.9490,129.9352 diff = 626.599976'
});
data_peak.push({
lat: 2.9955555556e+01,
lng: 1.2993644444e+02,
cert : true,
content:'Name = JA6/KG-084(JA6/KG-084) peak = 451.899994 pos = 29.9556,129.9364 diff = 189.899994'
});
data_saddle.push({
lat: 2.9962333333e+01,
lng: 1.2992788889e+02,
content:'Saddle = 262.000000 pos = 29.9623,129.9279 diff = 189.899994'
});
data_peak.push({
lat: 2.9961333333e+01,
lng: 1.2993300000e+02,
cert : false,
content:' Peak = 423.600006 pos = 29.9613,129.9330 diff = 154.899994'
});
data_saddle.push({
lat: 2.9957444444e+01,
lng: 1.2993400000e+02,
content:'Saddle = 268.700012 pos = 29.9574,129.9340 diff = 154.899994'
});
data_peak.push({
lat: 2.9638555556e+01,
lng: 1.2971355556e+02,
cert : true,
content:'Name = Otake(JA6/KG-023) peak = 794.299988 pos = 29.6386,129.7136 diff = 794.299988'
});
data_saddle.push({
lat: 2.9816111111e+01,
lng: 1.2987511111e+02,
content:'Saddle = 0.000000 pos = 29.8161,129.8751 diff = 794.299988'
});
data_peak.push({
lat: 2.9691666667e+01,
lng: 1.2953388889e+02,
cert : false,
content:' Peak = 240.699997 pos = 29.6917,129.5339 diff = 240.699997'
});
data_saddle.push({
lat: 2.9676333333e+01,
lng: 1.2953644444e+02,
content:'Saddle = 0.000000 pos = 29.6763,129.5364 diff = 240.699997'
});
data_peak.push({
lat: 2.9465111111e+01,
lng: 1.2959444444e+02,
cert : true,
content:'Name = Mitake(JA6/KG-050) peak = 581.700012 pos = 29.4651,129.5944 diff = 581.700012'
});
data_saddle.push({
lat: 2.9602000000e+01,
lng: 1.2970611111e+02,
content:'Saddle = 0.000000 pos = 29.6020,129.7061 diff = 581.700012'
});
data_peak.push({
lat: 2.9144555556e+01,
lng: 1.2920788889e+02,
cert : true,
content:'Name = Imakiradake(JA6/KG-128) peak = 291.500000 pos = 29.1446,129.2079 diff = 291.500000'
});
data_saddle.push({
lat: 2.9444666667e+01,
lng: 1.2960000000e+02,
content:'Saddle = 0.000000 pos = 29.4447,129.6000 diff = 291.500000'
});
data_peak.push({
lat: 2.8799444445e+01,
lng: 1.2900000000e+02,
cert : false,
content:' Peak = 282.000000 pos = 28.7994,129.0000 diff = 282.000000'
});
data_saddle.push({
lat: 2.9126777778e+01,
lng: 1.2922044444e+02,
content:'Saddle = 0.000000 pos = 29.1268,129.2204 diff = 282.000000'
});
data_peak.push({
lat: 2.8830777778e+01,
lng: 1.2900066667e+02,
cert : true,
content:'Name = JA6/KG-133(JA6/KG-133) peak = 275.899994 pos = 28.8308,129.0007 diff = 275.899994'
});
data_saddle.push({
lat: 2.8827666667e+01,
lng: 1.2900133333e+02,
content:'Saddle = 0.000000 pos = 28.8277,129.0013 diff = 275.899994'
});
data_peak.push({
lat: 2.9664444445e+01,
lng: 1.2973688889e+02,
cert : true,
content:'Name = JA6/KG-057(JA6/KG-057) peak = 534.400024 pos = 29.6644,129.7369 diff = 212.100037'
});
data_saddle.push({
lat: 2.9656333333e+01,
lng: 1.2973133333e+02,
content:'Saddle = 322.299988 pos = 29.6563,129.7313 diff = 212.100037'
});
data_peak.push({
lat: 2.9829444445e+01,
lng: 1.2988755556e+02,
cert : true,
content:'Name = JA6/KG-063(JA6/KG-063) peak = 523.900024 pos = 29.8294,129.8876 diff = 300.200012'
});
data_saddle.push({
lat: 2.9846333333e+01,
lng: 1.2987777778e+02,
content:'Saddle = 223.699997 pos = 29.8463,129.8778 diff = 300.200012'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:30,
       south:28.6667,
       east:130,
       west:129}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
