function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.5360666669e+01,
lng: 1.3872733333e+02,
cert : true,
content:'Name = Fujisan Kengamine(JA/SO-001) peak = 3774.899902 pos = 35.3607,138.7273 diff = 3774.899902'
});
data_saddle.push({
lat: 3.5687111112e+01,
lng: 1.3994633333e+02,
content:'Saddle = 0.000000 pos = 35.6871,139.9463 diff = 3774.899902'
});
data_peak.push({
lat: 3.4724555561e+01,
lng: 1.3939422222e+02,
cert : false,
content:' Peak = 755.599976 pos = 34.7246,139.3942 diff = 755.599976'
});
data_saddle.push({
lat: 3.4678000005e+01,
lng: 1.3943444444e+02,
content:'Saddle = 0.000000 pos = 34.6780,139.4344 diff = 755.599976'
});
data_peak.push({
lat: 3.5114888892e+01,
lng: 1.3998677778e+02,
cert : true,
content:'Name = Atagoyama(JA/CB-001) peak = 407.299988 pos = 35.1149,139.9868 diff = 402.000000'
});
data_saddle.push({
lat: 3.5945333334e+01,
lng: 1.3980622222e+02,
content:'Saddle = 5.300000 pos = 35.9453,139.8062 diff = 402.000000'
});
data_peak.push({
lat: 3.4937555560e+01,
lng: 1.3994044444e+02,
cert : false,
content:' Peak = 214.699997 pos = 34.9376,139.9404 diff = 176.399994'
});
data_saddle.push({
lat: 3.5010000004e+01,
lng: 1.3993888889e+02,
content:'Saddle = 38.299999 pos = 35.0100,139.9389 diff = 176.399994'
});
data_peak.push({
lat: 3.5112333337e+01,
lng: 1.3986466667e+02,
cert : false,
content:' Peak = 258.500000 pos = 35.1123,139.8647 diff = 166.500000'
});
data_saddle.push({
lat: 3.5110666670e+01,
lng: 1.3987566667e+02,
content:'Saddle = 92.000000 pos = 35.1107,139.8757 diff = 166.500000'
});
data_peak.push({
lat: 3.5098888892e+01,
lng: 1.3988144444e+02,
cert : true,
content:'Name = Tomisan(JA/CB-005) peak = 348.799988 pos = 35.0989,139.8814 diff = 250.199982'
});
data_saddle.push({
lat: 3.5099444448e+01,
lng: 1.3989777778e+02,
content:'Saddle = 98.599998 pos = 35.0994,139.8978 diff = 250.199982'
});
data_peak.push({
lat: 3.5313888892e+01,
lng: 1.4011355556e+02,
cert : false,
content:' Peak = 270.700012 pos = 35.3139,140.1136 diff = 150.700012'
});
data_saddle.push({
lat: 3.5298666669e+01,
lng: 1.4011622222e+02,
content:'Saddle = 120.000000 pos = 35.2987,140.1162 diff = 150.700012'
});
data_peak.push({
lat: 3.5255666670e+01,
lng: 1.3997177778e+02,
cert : true,
content:'Name = Shirotori Shrine(JA/CB-002) peak = 378.299988 pos = 35.2557,139.9718 diff = 257.500000'
});
data_saddle.push({
lat: 3.5246000003e+01,
lng: 1.3997655556e+02,
content:'Saddle = 120.800003 pos = 35.2460,139.9766 diff = 257.500000'
});
data_peak.push({
lat: 3.5262888892e+01,
lng: 1.4002455556e+02,
cert : false,
content:' Peak = 313.100006 pos = 35.2629,140.0246 diff = 176.400009'
});
data_saddle.push({
lat: 3.5250666670e+01,
lng: 1.4002944444e+02,
content:'Saddle = 136.699997 pos = 35.2507,140.0294 diff = 176.400009'
});
data_peak.push({
lat: 3.5160444448e+01,
lng: 1.3984077778e+02,
cert : true,
content:'Name = Nokogiriyama(JA/CB-006) peak = 327.299988 pos = 35.1604,139.8408 diff = 189.899994'
});
data_saddle.push({
lat: 3.5162000003e+01,
lng: 1.3986333333e+02,
content:'Saddle = 137.399994 pos = 35.1620,139.8633 diff = 189.899994'
});
data_peak.push({
lat: 3.5157444448e+01,
lng: 1.3988344444e+02,
cert : false,
content:' Peak = 313.899994 pos = 35.1574,139.8834 diff = 161.399994'
});
data_saddle.push({
lat: 3.5141222226e+01,
lng: 1.3991211111e+02,
content:'Saddle = 152.500000 pos = 35.1412,139.9121 diff = 161.399994'
});
data_peak.push({
lat: 3.5074000004e+01,
lng: 1.3997522222e+02,
cert : false,
content:' Peak = 310.500000 pos = 35.0740,139.9752 diff = 153.899994'
});
data_saddle.push({
lat: 3.5094222226e+01,
lng: 1.3999300000e+02,
content:'Saddle = 156.600006 pos = 35.0942,139.9930 diff = 153.899994'
});
data_peak.push({
lat: 3.5088777781e+01,
lng: 1.3994777778e+02,
cert : true,
content:'Name = Gotenyama(JA/CB-004) peak = 362.399994 pos = 35.0888,139.9478 diff = 204.799988'
});
data_saddle.push({
lat: 3.5098222226e+01,
lng: 1.3996144444e+02,
content:'Saddle = 157.600006 pos = 35.0982,139.9614 diff = 204.799988'
});
data_peak.push({
lat: 3.5162333337e+01,
lng: 1.4015222222e+02,
cert : true,
content:'Name = Myokensan(JA/CB-003) peak = 375.399994 pos = 35.1623,140.1522 diff = 208.000000'
});
data_saddle.push({
lat: 3.5144333337e+01,
lng: 1.3993088889e+02,
content:'Saddle = 167.399994 pos = 35.1443,139.9309 diff = 208.000000'
});
data_peak.push({
lat: 3.5157555559e+01,
lng: 1.4002022222e+02,
cert : false,
content:' Peak = 362.500000 pos = 35.1576,140.0202 diff = 165.899994'
});
data_saddle.push({
lat: 3.5165777781e+01,
lng: 1.4006077778e+02,
content:'Saddle = 196.600006 pos = 35.1658,140.0608 diff = 165.899994'
});
data_peak.push({
lat: 3.5107333337e+01,
lng: 1.3991388889e+02,
cert : false,
content:' Peak = 333.399994 pos = 35.1073,139.9139 diff = 165.899994'
});
data_saddle.push({
lat: 3.5121777781e+01,
lng: 1.3992377778e+02,
content:'Saddle = 167.500000 pos = 35.1218,139.9238 diff = 165.899994'
});
data_peak.push({
lat: 3.5139000003e+01,
lng: 1.3993255556e+02,
cert : false,
content:' Peak = 323.299988 pos = 35.1390,139.9326 diff = 151.099991'
});
data_saddle.push({
lat: 3.5121333337e+01,
lng: 1.3995055556e+02,
content:'Saddle = 172.199997 pos = 35.1213,139.9506 diff = 151.099991'
});
data_peak.push({
lat: 3.5108666670e+01,
lng: 1.4002233333e+02,
cert : false,
content:' Peak = 334.100006 pos = 35.1087,140.0223 diff = 155.700012'
});
data_saddle.push({
lat: 3.5105111115e+01,
lng: 1.3999466667e+02,
content:'Saddle = 178.399994 pos = 35.1051,139.9947 diff = 155.700012'
});
data_peak.push({
lat: 3.5250111114e+01,
lng: 1.3962800000e+02,
cert : false,
content:' Peak = 241.000000 pos = 35.2501,139.6280 diff = 194.699997'
});
data_saddle.push({
lat: 3.5400333336e+01,
lng: 1.3957855556e+02,
content:'Saddle = 46.299999 pos = 35.4003,139.5786 diff = 194.699997'
});
data_peak.push({
lat: 3.5275222225e+01,
lng: 1.3962300000e+02,
cert : false,
content:' Peak = 212.000000 pos = 35.2752,139.6230 diff = 150.199997'
});
data_saddle.push({
lat: 3.5262222225e+01,
lng: 1.3963633333e+02,
content:'Saddle = 61.799999 pos = 35.2622,139.6363 diff = 150.199997'
});
data_peak.push({
lat: 3.4673555561e+01,
lng: 1.3892655556e+02,
cert : false,
content:' Peak = 252.000000 pos = 34.6736,138.9266 diff = 150.899994'
});
data_saddle.push({
lat: 3.4680222228e+01,
lng: 1.3892544444e+02,
content:'Saddle = 101.099998 pos = 34.6802,138.9254 diff = 150.899994'
});
data_peak.push({
lat: 3.4939666671e+01,
lng: 1.3913133333e+02,
cert : false,
content:' Peak = 320.899994 pos = 34.9397,139.1313 diff = 154.099991'
});
data_saddle.push({
lat: 3.4932111115e+01,
lng: 1.3912733333e+02,
content:'Saddle = 166.800003 pos = 34.9321,139.1273 diff = 154.099991'
});
data_peak.push({
lat: 3.5316333336e+01,
lng: 1.3919777778e+02,
cert : false,
content:' Peak = 326.700012 pos = 35.3163,139.1978 diff = 158.900009'
});
data_saddle.push({
lat: 3.5339666669e+01,
lng: 1.3917066667e+02,
content:'Saddle = 167.800003 pos = 35.3397,139.1707 diff = 158.900009'
});
data_peak.push({
lat: 3.4702888894e+01,
lng: 1.3895522222e+02,
cert : true,
content:'Name = JA/SO-118(JA/SO-118) peak = 342.100006 pos = 34.7029,138.9552 diff = 165.600006'
});
data_saddle.push({
lat: 3.4721777783e+01,
lng: 1.3896755556e+02,
content:'Saddle = 176.500000 pos = 34.7218,138.9676 diff = 165.600006'
});
data_peak.push({
lat: 3.5583111113e+01,
lng: 1.3927866667e+02,
cert : true,
content:'Name = Shiroyama(JA/KN-022) peak = 374.100006 pos = 35.5831,139.2787 diff = 176.600006'
});
data_saddle.push({
lat: 3.5580222224e+01,
lng: 1.3927277778e+02,
content:'Saddle = 197.500000 pos = 35.5802,139.2728 diff = 176.600006'
});
data_peak.push({
lat: 3.4677333339e+01,
lng: 1.3881022222e+02,
cert : false,
content:' Peak = 352.899994 pos = 34.6773,138.8102 diff = 155.000000'
});
data_saddle.push({
lat: 3.4681555561e+01,
lng: 1.3879777778e+02,
content:'Saddle = 197.899994 pos = 34.6816,138.7978 diff = 155.000000'
});
data_peak.push({
lat: 3.4956777782e+01,
lng: 1.3756077778e+02,
cert : true,
content:'Name = JA/AC-033(JA/AC-033) peak = 411.299988 pos = 34.9568,137.5608 diff = 203.599991'
});
data_saddle.push({
lat: 3.4964000004e+01,
lng: 1.3757111111e+02,
content:'Saddle = 207.699997 pos = 34.9640,137.5711 diff = 203.599991'
});
data_peak.push({
lat: 3.5207777781e+01,
lng: 1.3853311111e+02,
cert : true,
content:'Name = JA/SO-087(JA/SO-087) peak = 566.799988 pos = 35.2078,138.5331 diff = 358.599976'
});
data_saddle.push({
lat: 3.5209222225e+01,
lng: 1.3851600000e+02,
content:'Saddle = 208.199997 pos = 35.2092,138.5160 diff = 358.599976'
});
data_peak.push({
lat: 3.5611777779e+01,
lng: 1.3700000000e+02,
cert : false,
content:' Peak = 451.500000 pos = 35.6118,137.0000 diff = 242.300003'
});
data_saddle.push({
lat: 3.5622777779e+01,
lng: 1.3700000000e+02,
content:'Saddle = 209.199997 pos = 35.6228,137.0000 diff = 242.300003'
});
data_peak.push({
lat: 3.4852888893e+01,
lng: 1.3769100000e+02,
cert : true,
content:'Name = JA/SO-105(JA/SO-105) peak = 466.200012 pos = 34.8529,137.6910 diff = 253.500015'
});
data_saddle.push({
lat: 3.4868666671e+01,
lng: 1.3768188889e+02,
content:'Saddle = 212.699997 pos = 34.8687,137.6819 diff = 253.500015'
});
data_peak.push({
lat: 3.4877666671e+01,
lng: 1.3769188889e+02,
cert : true,
content:'Name = JA/SO-112(JA/SO-112) peak = 431.200012 pos = 34.8777,137.6919 diff = 218.400009'
});
data_saddle.push({
lat: 3.4879333338e+01,
lng: 1.3765422222e+02,
content:'Saddle = 212.800003 pos = 34.8793,137.6542 diff = 218.400009'
});
data_peak.push({
lat: 3.5011777782e+01,
lng: 1.3892022222e+02,
cert : true,
content:'Name = JA/SO-108(JA/SO-108) peak = 451.000000 pos = 35.0118,138.9202 diff = 235.100006'
});
data_saddle.push({
lat: 3.5001222226e+01,
lng: 1.3889022222e+02,
content:'Saddle = 215.899994 pos = 35.0012,138.8902 diff = 235.100006'
});
data_peak.push({
lat: 3.4849666671e+01,
lng: 1.3758711111e+02,
cert : false,
content:' Peak = 562.900024 pos = 34.8497,137.5871 diff = 345.100037'
});
data_saddle.push({
lat: 3.4895777782e+01,
lng: 1.3764188889e+02,
content:'Saddle = 217.800003 pos = 34.8958,137.6419 diff = 345.100037'
});
data_peak.push({
lat: 3.4847444449e+01,
lng: 1.3754688889e+02,
cert : true,
content:'Name = JA/SO-113(JA/SO-113) peak = 423.200012 pos = 34.8474,137.5469 diff = 185.400009'
});
data_saddle.push({
lat: 3.4851666671e+01,
lng: 1.3755477778e+02,
content:'Saddle = 237.800003 pos = 34.8517,137.5548 diff = 185.400009'
});
data_peak.push({
lat: 3.4822888894e+01,
lng: 1.3760866667e+02,
cert : true,
content:'Name = JA/SO-111(JA/SO-111) peak = 431.500000 pos = 34.8229,137.6087 diff = 164.399994'
});
data_saddle.push({
lat: 3.4831888894e+01,
lng: 1.3759100000e+02,
content:'Saddle = 267.100006 pos = 34.8319,137.5910 diff = 164.399994'
});
data_peak.push({
lat: 3.4881333338e+01,
lng: 1.3762400000e+02,
cert : true,
content:'Name = JA/SO-096(JA/SO-096) peak = 518.299988 pos = 34.8813,137.6240 diff = 220.899994'
});
data_saddle.push({
lat: 3.4859888893e+01,
lng: 1.3759544444e+02,
content:'Saddle = 297.399994 pos = 34.8599,137.5954 diff = 220.899994'
});
data_peak.push({
lat: 3.4946888893e+01,
lng: 1.3787300000e+02,
cert : false,
content:' Peak = 451.600006 pos = 34.9469,137.8730 diff = 225.100006'
});
data_saddle.push({
lat: 3.4936111115e+01,
lng: 1.3788077778e+02,
content:'Saddle = 226.500000 pos = 34.9361,137.8808 diff = 225.100006'
});
data_peak.push({
lat: 3.5515777780e+01,
lng: 1.3701988889e+02,
cert : false,
content:' Peak = 380.000000 pos = 35.5158,137.0199 diff = 153.300003'
});
data_saddle.push({
lat: 3.5528666669e+01,
lng: 1.3701844444e+02,
content:'Saddle = 226.699997 pos = 35.5287,137.0184 diff = 153.300003'
});
data_peak.push({
lat: 3.5611555557e+01,
lng: 1.3919866667e+02,
cert : false,
content:' Peak = 405.000000 pos = 35.6116,139.1987 diff = 171.300003'
});
data_saddle.push({
lat: 3.5601111113e+01,
lng: 1.3919844444e+02,
content:'Saddle = 233.699997 pos = 35.6011,139.1984 diff = 171.300003'
});
data_peak.push({
lat: 3.5556666668e+01,
lng: 1.3927400000e+02,
cert : true,
content:'Name = JA/KN-021(JA/KN-021) peak = 428.299988 pos = 35.5567,139.2740 diff = 194.399994'
});
data_saddle.push({
lat: 3.5553111113e+01,
lng: 1.3926288889e+02,
content:'Saddle = 233.899994 pos = 35.5531,139.2629 diff = 194.399994'
});
data_peak.push({
lat: 3.4953222226e+01,
lng: 1.3830088889e+02,
cert : true,
content:'Name = JA/SO-103(JA/SO-103) peak = 482.600006 pos = 34.9532,138.3009 diff = 247.900009'
});
data_saddle.push({
lat: 3.4976333337e+01,
lng: 1.3827622222e+02,
content:'Saddle = 234.699997 pos = 34.9763,138.2762 diff = 247.900009'
});
data_peak.push({
lat: 3.4900666671e+01,
lng: 1.3732255556e+02,
cert : true,
content:'Name = JA/AC-032(JA/AC-032) peak = 441.200012 pos = 34.9007,137.3226 diff = 203.900009'
});
data_saddle.push({
lat: 3.4888666671e+01,
lng: 1.3732844444e+02,
content:'Saddle = 237.300003 pos = 34.8887,137.3284 diff = 203.900009'
});
data_peak.push({
lat: 3.4923000004e+01,
lng: 1.3782355556e+02,
cert : false,
content:' Peak = 392.399994 pos = 34.9230,137.8236 diff = 154.899994'
});
data_saddle.push({
lat: 3.4927333338e+01,
lng: 1.3784488889e+02,
content:'Saddle = 237.500000 pos = 34.9273,137.8449 diff = 154.899994'
});
data_peak.push({
lat: 3.5093888893e+01,
lng: 1.3850155556e+02,
cert : false,
content:' Peak = 504.100006 pos = 35.0939,138.5016 diff = 266.299988'
});
data_saddle.push({
lat: 3.5092444448e+01,
lng: 1.3846144444e+02,
content:'Saddle = 237.800003 pos = 35.0924,138.4614 diff = 266.299988'
});
data_peak.push({
lat: 3.5091888893e+01,
lng: 1.3847988889e+02,
cert : false,
content:' Peak = 413.899994 pos = 35.0919,138.4799 diff = 157.399994'
});
data_saddle.push({
lat: 3.5093444448e+01,
lng: 1.3849044444e+02,
content:'Saddle = 256.500000 pos = 35.0934,138.4904 diff = 157.399994'
});
data_peak.push({
lat: 3.5006222226e+01,
lng: 1.3833866667e+02,
cert : true,
content:'Name = JA/SO-110(JA/SO-110) peak = 435.100006 pos = 35.0062,138.3387 diff = 193.000000'
});
data_saddle.push({
lat: 3.5012444448e+01,
lng: 1.3833988889e+02,
content:'Saddle = 242.100006 pos = 35.0124,138.3399 diff = 193.000000'
});
data_peak.push({
lat: 3.4892444449e+01,
lng: 1.3815877778e+02,
cert : true,
content:'Name = JA/SO-101(JA/SO-101) peak = 495.799988 pos = 34.8924,138.1588 diff = 253.699982'
});
data_saddle.push({
lat: 3.4908333338e+01,
lng: 1.3816611111e+02,
content:'Saddle = 242.100006 pos = 34.9083,138.1661 diff = 253.699982'
});
data_peak.push({
lat: 3.4742666672e+01,
lng: 1.3895788889e+02,
cert : false,
content:' Peak = 454.100006 pos = 34.7427,138.9579 diff = 211.400009'
});
data_saddle.push({
lat: 3.4758222227e+01,
lng: 1.3896511111e+02,
content:'Saddle = 242.699997 pos = 34.7582,138.9651 diff = 211.400009'
});
data_peak.push({
lat: 3.4927111115e+01,
lng: 1.3785822222e+02,
cert : true,
content:'Name = JA/SO-091(JA/SO-091) peak = 551.000000 pos = 34.9271,137.8582 diff = 304.399994'
});
data_saddle.push({
lat: 3.4926666671e+01,
lng: 1.3787866667e+02,
content:'Saddle = 246.600006 pos = 34.9267,137.8787 diff = 304.399994'
});
data_peak.push({
lat: 3.5649555557e+01,
lng: 1.3716122222e+02,
cert : false,
content:' Peak = 413.500000 pos = 35.6496,137.1612 diff = 158.399994'
});
data_saddle.push({
lat: 3.5653111112e+01,
lng: 1.3715400000e+02,
content:'Saddle = 255.100006 pos = 35.6531,137.1540 diff = 158.399994'
});
data_peak.push({
lat: 3.5120111115e+01,
lng: 1.3853344444e+02,
cert : true,
content:'Name = JA/SO-068(JA/SO-068) peak = 705.799988 pos = 35.1201,138.5334 diff = 448.899994'
});
data_saddle.push({
lat: 3.5146111115e+01,
lng: 1.3852177778e+02,
content:'Saddle = 256.899994 pos = 35.1461,138.5218 diff = 448.899994'
});
data_peak.push({
lat: 3.5144666670e+01,
lng: 1.3858933333e+02,
cert : true,
content:'Name = JA/SO-080(JA/SO-080) peak = 597.299988 pos = 35.1447,138.5893 diff = 240.799988'
});
data_saddle.push({
lat: 3.5151666670e+01,
lng: 1.3854355556e+02,
content:'Saddle = 356.500000 pos = 35.1517,138.5436 diff = 240.799988'
});
data_peak.push({
lat: 3.5161555559e+01,
lng: 1.3855400000e+02,
cert : true,
content:'Name = JA/SO-088(JA/SO-088) peak = 563.799988 pos = 35.1616,138.5540 diff = 186.699982'
});
data_saddle.push({
lat: 3.5156333337e+01,
lng: 1.3856811111e+02,
content:'Saddle = 377.100006 pos = 35.1563,138.5681 diff = 186.699982'
});
data_peak.push({
lat: 3.4910111115e+01,
lng: 1.3735488889e+02,
cert : false,
content:' Peak = 480.100006 pos = 34.9101,137.3549 diff = 212.000000'
});
data_saddle.push({
lat: 3.4891111116e+01,
lng: 1.3735833333e+02,
content:'Saddle = 268.100006 pos = 34.8911,137.3583 diff = 212.000000'
});
data_peak.push({
lat: 3.4707111116e+01,
lng: 1.3875177778e+02,
cert : true,
content:'Name = JA/SO-097(JA/SO-097) peak = 517.200012 pos = 34.7071,138.7518 diff = 246.500000'
});
data_saddle.push({
lat: 3.4707111116e+01,
lng: 1.3875833333e+02,
content:'Saddle = 270.700012 pos = 34.7071,138.7583 diff = 246.500000'
});
data_peak.push({
lat: 3.5545222224e+01,
lng: 1.3709400000e+02,
cert : true,
content:'Name = JA/GF-181(JA/GF-181) peak = 631.299988 pos = 35.5452,137.0940 diff = 352.899994'
});
data_saddle.push({
lat: 3.5580444446e+01,
lng: 1.3706366667e+02,
content:'Saddle = 278.399994 pos = 35.5804,137.0637 diff = 352.899994'
});
data_peak.push({
lat: 3.5545888891e+01,
lng: 1.3705111111e+02,
cert : false,
content:' Peak = 553.799988 pos = 35.5459,137.0511 diff = 205.399994'
});
data_saddle.push({
lat: 3.5550888891e+01,
lng: 1.3705822222e+02,
content:'Saddle = 348.399994 pos = 35.5509,137.0582 diff = 205.399994'
});
data_peak.push({
lat: 3.4795555560e+01,
lng: 1.3878155556e+02,
cert : false,
content:' Peak = 435.299988 pos = 34.7956,138.7816 diff = 154.799988'
});
data_saddle.push({
lat: 3.4798111116e+01,
lng: 1.3878444444e+02,
content:'Saddle = 280.500000 pos = 34.7981,138.7844 diff = 154.799988'
});
data_peak.push({
lat: 3.5636444446e+01,
lng: 1.3700000000e+02,
cert : false,
content:' Peak = 462.100006 pos = 35.6364,137.0000 diff = 168.600006'
});
data_saddle.push({
lat: 3.5639777779e+01,
lng: 1.3700000000e+02,
content:'Saddle = 293.500000 pos = 35.6398,137.0000 diff = 168.600006'
});
data_peak.push({
lat: 3.5520666669e+01,
lng: 1.3925800000e+02,
cert : true,
content:'Name = Bukkasan(JA/KN-017) peak = 744.799988 pos = 35.5207,139.2580 diff = 446.899994'
});
data_saddle.push({
lat: 3.5503777780e+01,
lng: 1.3925633333e+02,
content:'Saddle = 297.899994 pos = 35.5038,139.2563 diff = 446.899994'
});
data_peak.push({
lat: 3.5618888890e+01,
lng: 1.3908522222e+02,
cert : false,
content:' Peak = 462.100006 pos = 35.6189,139.0852 diff = 160.800018'
});
data_saddle.push({
lat: 3.5623000002e+01,
lng: 1.3907188889e+02,
content:'Saddle = 301.299988 pos = 35.6230,139.0719 diff = 160.800018'
});
data_peak.push({
lat: 3.5475444447e+01,
lng: 1.3846300000e+02,
cert : true,
content:'Name = JA/YN-072(JA/YN-072) peak = 471.200012 pos = 35.4754,138.4630 diff = 168.600006'
});
data_saddle.push({
lat: 3.5470888891e+01,
lng: 1.3846711111e+02,
content:'Saddle = 302.600006 pos = 35.4709,138.4671 diff = 168.600006'
});
data_peak.push({
lat: 3.4703555561e+01,
lng: 1.3885511111e+02,
cert : true,
content:'Name = JA/SO-092(JA/SO-092) peak = 543.099976 pos = 34.7036,138.8551 diff = 231.099976'
});
data_saddle.push({
lat: 3.4731444450e+01,
lng: 1.3885788889e+02,
content:'Saddle = 312.000000 pos = 34.7314,138.8579 diff = 231.099976'
});
data_peak.push({
lat: 3.4716444450e+01,
lng: 1.3877722222e+02,
cert : false,
content:' Peak = 521.799988 pos = 34.7164,138.7772 diff = 183.099976'
});
data_saddle.push({
lat: 3.4705000005e+01,
lng: 1.3880122222e+02,
content:'Saddle = 338.700012 pos = 34.7050,138.8012 diff = 183.099976'
});
data_peak.push({
lat: 3.5643222224e+01,
lng: 1.3700000000e+02,
cert : false,
content:' Peak = 488.500000 pos = 35.6432,137.0000 diff = 176.399994'
});
data_saddle.push({
lat: 3.5646555557e+01,
lng: 1.3700000000e+02,
content:'Saddle = 312.100006 pos = 35.6466,137.0000 diff = 176.399994'
});
data_peak.push({
lat: 3.5634333335e+01,
lng: 1.3913177778e+02,
cert : false,
content:' Peak = 471.600006 pos = 35.6343,139.1318 diff = 154.700012'
});
data_saddle.push({
lat: 3.5639555557e+01,
lng: 1.3913200000e+02,
content:'Saddle = 316.899994 pos = 35.6396,139.1320 diff = 154.700012'
});
data_peak.push({
lat: 3.5561666668e+01,
lng: 1.3922533333e+02,
cert : true,
content:'Name = Sendoujiyama(JA/KN-019) peak = 582.299988 pos = 35.5617,139.2253 diff = 264.199982'
});
data_saddle.push({
lat: 3.5555111113e+01,
lng: 1.3921111111e+02,
content:'Saddle = 318.100006 pos = 35.5551,139.2111 diff = 264.199982'
});
data_peak.push({
lat: 3.5545777780e+01,
lng: 1.3923555556e+02,
cert : true,
content:'Name = JA/KN-020(JA/KN-020) peak = 567.900024 pos = 35.5458,139.2356 diff = 246.800018'
});
data_saddle.push({
lat: 3.5538222224e+01,
lng: 1.3922011111e+02,
content:'Saddle = 321.100006 pos = 35.5382,139.2201 diff = 246.800018'
});
data_peak.push({
lat: 3.4857777782e+01,
lng: 1.3806788889e+02,
cert : true,
content:'Name = JA/SO-081(JA/SO-081) peak = 584.799988 pos = 34.8578,138.0679 diff = 262.599976'
});
data_saddle.push({
lat: 3.4860555560e+01,
lng: 1.3804722222e+02,
content:'Saddle = 322.200012 pos = 34.8606,138.0472 diff = 262.599976'
});
data_peak.push({
lat: 3.5017333337e+01,
lng: 1.3829800000e+02,
cert : true,
content:'Name = JA/SO-102(JA/SO-102) peak = 493.200012 pos = 35.0173,138.2980 diff = 170.900024'
});
data_saddle.push({
lat: 3.5036111115e+01,
lng: 1.3830044444e+02,
content:'Saddle = 322.299988 pos = 35.0361,138.3004 diff = 170.900024'
});
data_peak.push({
lat: 3.5043555559e+01,
lng: 1.3781333333e+02,
cert : true,
content:'Name = JA/SO-042(JA/SO-042) peak = 1057.900024 pos = 35.0436,137.8133 diff = 735.400024'
});
data_saddle.push({
lat: 3.5020666671e+01,
lng: 1.3769555556e+02,
content:'Saddle = 322.500000 pos = 35.0207,137.6956 diff = 735.400024'
});
data_peak.push({
lat: 3.4984777782e+01,
lng: 1.3765033333e+02,
cert : true,
content:'Name = JA/AC-027(JA/AC-027) peak = 582.299988 pos = 34.9848,137.6503 diff = 224.799988'
});
data_saddle.push({
lat: 3.4964555560e+01,
lng: 1.3765355556e+02,
content:'Saddle = 357.500000 pos = 34.9646,137.6536 diff = 224.799988'
});
data_peak.push({
lat: 3.4947222226e+01,
lng: 1.3774655556e+02,
cert : true,
content:'Name = JA/SO-076(JA/SO-076) peak = 657.099976 pos = 34.9472,137.7466 diff = 295.199982'
});
data_saddle.push({
lat: 3.4956888893e+01,
lng: 1.3773266667e+02,
content:'Saddle = 361.899994 pos = 34.9569,137.7327 diff = 295.199982'
});
data_peak.push({
lat: 3.4962666671e+01,
lng: 1.3781388889e+02,
cert : false,
content:' Peak = 563.200012 pos = 34.9627,137.8139 diff = 151.800018'
});
data_saddle.push({
lat: 3.4969111115e+01,
lng: 1.3779255556e+02,
content:'Saddle = 411.399994 pos = 34.9691,137.7926 diff = 151.800018'
});
data_peak.push({
lat: 3.4900111116e+01,
lng: 1.3774444444e+02,
cert : true,
content:'Name = JA/SO-084(JA/SO-084) peak = 574.000000 pos = 34.9001,137.7444 diff = 161.000000'
});
data_saddle.push({
lat: 3.4931888893e+01,
lng: 1.3770255556e+02,
content:'Saddle = 413.000000 pos = 34.9319,137.7026 diff = 161.000000'
});
data_peak.push({
lat: 3.4932888893e+01,
lng: 1.3765077778e+02,
cert : false,
content:' Peak = 677.700012 pos = 34.9329,137.6508 diff = 238.900024'
});
data_saddle.push({
lat: 3.4951777782e+01,
lng: 1.3768066667e+02,
content:'Saddle = 438.799988 pos = 34.9518,137.6807 diff = 238.900024'
});
data_peak.push({
lat: 3.5003555560e+01,
lng: 1.3770088889e+02,
cert : true,
content:'Name = JA/SO-067(JA/SO-067) peak = 711.099976 pos = 35.0036,137.7009 diff = 212.599976'
});
data_saddle.push({
lat: 3.4982777782e+01,
lng: 1.3770088889e+02,
content:'Saddle = 498.500000 pos = 34.9828,137.7009 diff = 212.599976'
});
data_peak.push({
lat: 3.4955555560e+01,
lng: 1.3777088889e+02,
cert : false,
content:' Peak = 712.599976 pos = 34.9556,137.7709 diff = 189.000000'
});
data_saddle.push({
lat: 3.4966333337e+01,
lng: 1.3775122222e+02,
content:'Saddle = 523.599976 pos = 34.9663,137.7512 diff = 189.000000'
});
data_peak.push({
lat: 3.4991000004e+01,
lng: 1.3781555556e+02,
cert : false,
content:' Peak = 772.799988 pos = 34.9910,137.8156 diff = 185.000000'
});
data_saddle.push({
lat: 3.5003333337e+01,
lng: 1.3780455556e+02,
content:'Saddle = 587.799988 pos = 35.0033,137.8046 diff = 185.000000'
});
data_peak.push({
lat: 3.4982333337e+01,
lng: 1.3775344444e+02,
cert : false,
content:' Peak = 840.700012 pos = 34.9823,137.7534 diff = 192.900024'
});
data_saddle.push({
lat: 3.4989000004e+01,
lng: 1.3775577778e+02,
content:'Saddle = 647.799988 pos = 34.9890,137.7558 diff = 192.900024'
});
data_peak.push({
lat: 3.5013333337e+01,
lng: 1.3777211111e+02,
cert : false,
content:' Peak = 1052.599976 pos = 35.0133,137.7721 diff = 365.500000'
});
data_saddle.push({
lat: 3.5034111115e+01,
lng: 1.3779500000e+02,
content:'Saddle = 687.099976 pos = 35.0341,137.7950 diff = 365.500000'
});
data_peak.push({
lat: 3.5815666667e+01,
lng: 1.3921522222e+02,
cert : false,
content:' Peak = 492.899994 pos = 35.8157,139.2152 diff = 165.699982'
});
data_saddle.push({
lat: 3.5821000001e+01,
lng: 1.3920955556e+02,
content:'Saddle = 327.200012 pos = 35.8210,139.2096 diff = 165.699982'
});
data_peak.push({
lat: 3.5653000001e+01,
lng: 1.3701133333e+02,
cert : true,
content:'Name = JA/GF-184(JA/GF-184) peak = 590.599976 pos = 35.6530,137.0113 diff = 261.399963'
});
data_saddle.push({
lat: 3.5669777779e+01,
lng: 1.3700011111e+02,
content:'Saddle = 329.200012 pos = 35.6698,137.0001 diff = 261.399963'
});
data_peak.push({
lat: 3.5661333335e+01,
lng: 1.3700044444e+02,
cert : false,
content:' Peak = 481.200012 pos = 35.6613,137.0004 diff = 151.600006'
});
data_saddle.push({
lat: 3.5657000001e+01,
lng: 1.3700011111e+02,
content:'Saddle = 329.600006 pos = 35.6570,137.0001 diff = 151.600006'
});
data_peak.push({
lat: 3.4864222227e+01,
lng: 1.3800511111e+02,
cert : true,
content:'Name = JA/SO-098(JA/SO-098) peak = 506.600006 pos = 34.8642,138.0051 diff = 173.300018'
});
data_saddle.push({
lat: 3.4875666671e+01,
lng: 1.3800677778e+02,
content:'Saddle = 333.299988 pos = 34.8757,138.0068 diff = 173.300018'
});
data_peak.push({
lat: 3.5080111115e+01,
lng: 1.3784788889e+02,
cert : false,
content:' Peak = 539.000000 pos = 35.0801,137.8479 diff = 202.500000'
});
data_saddle.push({
lat: 3.5084333337e+01,
lng: 1.3784377778e+02,
content:'Saddle = 336.500000 pos = 35.0843,137.8438 diff = 202.500000'
});
data_peak.push({
lat: 3.4902000004e+01,
lng: 1.3791933333e+02,
cert : false,
content:' Peak = 583.900024 pos = 34.9020,137.9193 diff = 244.700012'
});
data_saddle.push({
lat: 3.4941666671e+01,
lng: 1.3793088889e+02,
content:'Saddle = 339.200012 pos = 34.9417,137.9309 diff = 244.700012'
});
data_peak.push({
lat: 3.4928111115e+01,
lng: 1.3792455556e+02,
cert : false,
content:' Peak = 547.799988 pos = 34.9281,137.9246 diff = 159.000000'
});
data_saddle.push({
lat: 3.4908666671e+01,
lng: 1.3792411111e+02,
content:'Saddle = 388.799988 pos = 34.9087,137.9241 diff = 159.000000'
});
data_peak.push({
lat: 3.5015888893e+01,
lng: 1.3753900000e+02,
cert : true,
content:'Name = JA/AC-028(JA/AC-028) peak = 523.099976 pos = 35.0159,137.5390 diff = 175.499969'
});
data_saddle.push({
lat: 3.5050444448e+01,
lng: 1.3755566667e+02,
content:'Saddle = 347.600006 pos = 35.0504,137.5557 diff = 175.499969'
});
data_peak.push({
lat: 3.4893888893e+01,
lng: 1.3812988889e+02,
cert : true,
content:'Name = JA/SO-086(JA/SO-086) peak = 567.700012 pos = 34.8939,138.1299 diff = 219.900024'
});
data_saddle.push({
lat: 3.4902888893e+01,
lng: 1.3813911111e+02,
content:'Saddle = 347.799988 pos = 34.9029,138.1391 diff = 219.900024'
});
data_peak.push({
lat: 3.5604333335e+01,
lng: 1.3705611111e+02,
cert : true,
content:'Name = JA/GF-183(JA/GF-183) peak = 596.599976 pos = 35.6043,137.0561 diff = 248.099976'
});
data_saddle.push({
lat: 3.5609111113e+01,
lng: 1.3705933333e+02,
content:'Saddle = 348.500000 pos = 35.6091,137.0593 diff = 248.099976'
});
data_peak.push({
lat: 3.4903111115e+01,
lng: 1.3909466667e+02,
cert : true,
content:'Name = Oomuroyama(JA/SO-082) peak = 580.000000 pos = 34.9031,139.0947 diff = 227.899994'
});
data_saddle.push({
lat: 3.4906000004e+01,
lng: 1.3908066667e+02,
content:'Saddle = 352.100006 pos = 34.9060,139.0807 diff = 227.899994'
});
data_peak.push({
lat: 3.4796666671e+01,
lng: 1.3881711111e+02,
cert : true,
content:'Name = JA/SO-093(JA/SO-093) peak = 544.799988 pos = 34.7967,138.8171 diff = 191.899994'
});
data_saddle.push({
lat: 3.4795222227e+01,
lng: 1.3882555556e+02,
content:'Saddle = 352.899994 pos = 34.7952,138.8256 diff = 191.899994'
});
data_peak.push({
lat: 3.5137888892e+01,
lng: 1.3815000000e+02,
cert : false,
content:' Peak = 523.900024 pos = 35.1379,138.1500 diff = 170.600037'
});
data_saddle.push({
lat: 3.5141555559e+01,
lng: 1.3814733333e+02,
content:'Saddle = 353.299988 pos = 35.1416,138.1473 diff = 170.600037'
});
data_peak.push({
lat: 3.5437444447e+01,
lng: 1.3846244444e+02,
cert : true,
content:'Name = JA/YN-070(JA/YN-070) peak = 635.700012 pos = 35.4374,138.4624 diff = 282.400024'
});
data_saddle.push({
lat: 3.5464555558e+01,
lng: 1.3847788889e+02,
content:'Saddle = 353.299988 pos = 35.4646,138.4779 diff = 282.400024'
});
data_peak.push({
lat: 3.5453333336e+01,
lng: 1.3729900000e+02,
cert : false,
content:' Peak = 661.200012 pos = 35.4533,137.2990 diff = 303.300018'
});
data_saddle.push({
lat: 3.5443888891e+01,
lng: 1.3737888889e+02,
content:'Saddle = 357.899994 pos = 35.4439,137.3789 diff = 303.300018'
});
data_peak.push({
lat: 3.5456444447e+01,
lng: 1.3734822222e+02,
cert : true,
content:'Name = JA/GF-185(JA/GF-185) peak = 574.799988 pos = 35.4564,137.3482 diff = 197.599976'
});
data_saddle.push({
lat: 3.5457555558e+01,
lng: 1.3731244444e+02,
content:'Saddle = 377.200012 pos = 35.4576,137.3124 diff = 197.599976'
});
data_peak.push({
lat: 3.5435888891e+01,
lng: 1.3729222222e+02,
cert : false,
content:' Peak = 631.200012 pos = 35.4359,137.2922 diff = 154.800018'
});
data_saddle.push({
lat: 3.5434888891e+01,
lng: 1.3730277778e+02,
content:'Saddle = 476.399994 pos = 35.4349,137.3028 diff = 154.800018'
});
data_peak.push({
lat: 3.4862888893e+01,
lng: 1.3900166667e+02,
cert : true,
content:'Name = Amagisan (Banzaburoudake)(JA/SO-030) peak = 1404.699951 pos = 34.8629,139.0017 diff = 1046.799927'
});
data_saddle.push({
lat: 3.4952000004e+01,
lng: 1.3905355556e+02,
content:'Saddle = 357.899994 pos = 34.9520,139.0536 diff = 1046.799927'
});
data_peak.push({
lat: 3.4737888894e+01,
lng: 1.3885944444e+02,
cert : true,
content:'Name = JA/SO-079(JA/SO-079) peak = 606.799988 pos = 34.7379,138.8594 diff = 195.099976'
});
data_saddle.push({
lat: 3.4742444449e+01,
lng: 1.3887044444e+02,
content:'Saddle = 411.700012 pos = 34.7424,138.8704 diff = 195.099976'
});
data_peak.push({
lat: 3.4927888893e+01,
lng: 1.3896444444e+02,
cert : true,
content:'Name = JA/SO-078(JA/SO-078) peak = 607.500000 pos = 34.9279,138.9644 diff = 190.000000'
});
data_saddle.push({
lat: 3.4909111115e+01,
lng: 1.3895300000e+02,
content:'Saddle = 417.500000 pos = 34.9091,138.9530 diff = 190.000000'
});
data_peak.push({
lat: 3.4817333338e+01,
lng: 1.3879433333e+02,
cert : true,
content:'Name = JA/SO-069(JA/SO-069) peak = 702.599976 pos = 34.8173,138.7943 diff = 216.299988'
});
data_saddle.push({
lat: 3.4822222227e+01,
lng: 1.3881688889e+02,
content:'Saddle = 486.299988 pos = 34.8222,138.8169 diff = 216.299988'
});
data_peak.push({
lat: 3.4955111115e+01,
lng: 1.3883922222e+02,
cert : true,
content:'Name = Darumayama(JA/SO-051) peak = 981.000000 pos = 34.9551,138.8392 diff = 403.099976'
});
data_saddle.push({
lat: 3.4922111115e+01,
lng: 1.3884144444e+02,
content:'Saddle = 577.900024 pos = 34.9221,138.8414 diff = 403.099976'
});
data_peak.push({
lat: 3.4894888893e+01,
lng: 1.3905722222e+02,
cert : false,
content:' Peak = 815.000000 pos = 34.8949,139.0572 diff = 153.099976'
});
data_saddle.push({
lat: 3.4894444449e+01,
lng: 1.3905344444e+02,
content:'Saddle = 661.900024 pos = 34.8944,139.0534 diff = 153.099976'
});
data_peak.push({
lat: 3.4788444449e+01,
lng: 1.3886800000e+02,
cert : true,
content:'Name = Chyoukurouyama(JA/SO-050) peak = 995.299988 pos = 34.7884,138.8680 diff = 263.200012'
});
data_saddle.push({
lat: 3.4807666671e+01,
lng: 1.3888144444e+02,
content:'Saddle = 732.099976 pos = 34.8077,138.8814 diff = 263.200012'
});
data_peak.push({
lat: 3.4884555560e+01,
lng: 1.3884033333e+02,
cert : false,
content:' Peak = 932.599976 pos = 34.8846,138.8403 diff = 160.000000'
});
data_saddle.push({
lat: 3.4872666671e+01,
lng: 1.3883488889e+02,
content:'Saddle = 772.599976 pos = 34.8727,138.8349 diff = 160.000000'
});
data_peak.push({
lat: 3.4857777782e+01,
lng: 1.3886366667e+02,
cert : true,
content:'Name = JA/SO-047(JA/SO-047) peak = 1035.500000 pos = 34.8578,138.8637 diff = 212.900024'
});
data_saddle.push({
lat: 3.4831777782e+01,
lng: 1.3890811111e+02,
content:'Saddle = 822.599976 pos = 34.8318,138.9081 diff = 212.900024'
});
data_peak.push({
lat: 3.4878888893e+01,
lng: 1.3903244444e+02,
cert : true,
content:'Name = JA/SO-038(JA/SO-038) peak = 1196.300049 pos = 34.8789,139.0324 diff = 177.900024'
});
data_saddle.push({
lat: 3.4874555560e+01,
lng: 1.3902644444e+02,
content:'Saddle = 1018.400024 pos = 34.8746,139.0264 diff = 177.900024'
});
data_peak.push({
lat: 3.5201888892e+01,
lng: 1.3717244444e+02,
cert : true,
content:'Name = JA/AC-025(JA/AC-025) peak = 631.599976 pos = 35.2019,137.1724 diff = 273.599976'
});
data_saddle.push({
lat: 3.5216333336e+01,
lng: 1.3717300000e+02,
content:'Saddle = 358.000000 pos = 35.2163,137.1730 diff = 273.599976'
});
data_peak.push({
lat: 3.4992777782e+01,
lng: 1.3827244444e+02,
cert : true,
content:'Name = JA/SO-090(JA/SO-090) peak = 561.000000 pos = 34.9928,138.2724 diff = 198.399994'
});
data_saddle.push({
lat: 3.4998555560e+01,
lng: 1.3826477778e+02,
content:'Saddle = 362.600006 pos = 34.9986,138.2648 diff = 198.399994'
});
data_peak.push({
lat: 3.5519888891e+01,
lng: 1.3847311111e+02,
cert : true,
content:'Name = JA/YN-071(JA/YN-071) peak = 551.900024 pos = 35.5199,138.4731 diff = 189.100037'
});
data_saddle.push({
lat: 3.5519111113e+01,
lng: 1.3848322222e+02,
content:'Saddle = 362.799988 pos = 35.5191,138.4832 diff = 189.100037'
});
data_peak.push({
lat: 3.5678222224e+01,
lng: 1.3701155556e+02,
cert : false,
content:' Peak = 551.400024 pos = 35.6782,137.0116 diff = 183.500031'
});
data_saddle.push({
lat: 3.5678777779e+01,
lng: 1.3700000000e+02,
content:'Saddle = 367.899994 pos = 35.6788,137.0000 diff = 183.500031'
});
data_peak.push({
lat: 3.5585222224e+01,
lng: 1.3919066667e+02,
cert : true,
content:'Name = Sekirouzan(JA/KN-018) peak = 701.299988 pos = 35.5852,139.1907 diff = 329.599976'
});
data_saddle.push({
lat: 3.5561888891e+01,
lng: 1.3915122222e+02,
content:'Saddle = 371.700012 pos = 35.5619,139.1512 diff = 329.599976'
});
data_peak.push({
lat: 3.5572666668e+01,
lng: 1.3916933333e+02,
cert : false,
content:' Peak = 577.700012 pos = 35.5727,139.1693 diff = 165.700012'
});
data_saddle.push({
lat: 3.5576666668e+01,
lng: 1.3917655556e+02,
content:'Saddle = 412.000000 pos = 35.5767,139.1766 diff = 165.700012'
});
data_peak.push({
lat: 3.5129333337e+01,
lng: 1.3848933333e+02,
cert : false,
content:' Peak = 530.799988 pos = 35.1293,138.4893 diff = 157.500000'
});
data_saddle.push({
lat: 3.5135333337e+01,
lng: 1.3849044444e+02,
content:'Saddle = 373.299988 pos = 35.1353,138.4904 diff = 157.500000'
});
data_peak.push({
lat: 3.5347000003e+01,
lng: 1.3843033333e+02,
cert : false,
content:' Peak = 537.799988 pos = 35.3470,138.4303 diff = 164.500000'
});
data_saddle.push({
lat: 3.5329333336e+01,
lng: 1.3843100000e+02,
content:'Saddle = 373.299988 pos = 35.3293,138.4310 diff = 164.500000'
});
data_peak.push({
lat: 3.5601555557e+01,
lng: 1.3718622222e+02,
cert : true,
content:'Name = JA/GF-177(JA/GF-177) peak = 663.700012 pos = 35.6016,137.1862 diff = 289.600006'
});
data_saddle.push({
lat: 3.5604111113e+01,
lng: 1.3719777778e+02,
content:'Saddle = 374.100006 pos = 35.6041,137.1978 diff = 289.600006'
});
data_peak.push({
lat: 3.5660222224e+01,
lng: 1.3909855556e+02,
cert : false,
content:' Peak = 541.000000 pos = 35.6602,139.0986 diff = 158.299988'
});
data_saddle.push({
lat: 3.5665888890e+01,
lng: 1.3910411111e+02,
content:'Saddle = 382.700012 pos = 35.6659,139.1041 diff = 158.299988'
});
data_peak.push({
lat: 3.5575000002e+01,
lng: 1.3716700000e+02,
cert : true,
content:'Name = JA/GF-167(JA/GF-167) peak = 742.299988 pos = 35.5750,137.1670 diff = 355.299988'
});
data_saddle.push({
lat: 3.5635000001e+01,
lng: 1.3709277778e+02,
content:'Saddle = 387.000000 pos = 35.6350,137.0928 diff = 355.299988'
});
data_peak.push({
lat: 3.5631333335e+01,
lng: 1.3709077778e+02,
cert : false,
content:' Peak = 552.099976 pos = 35.6313,137.0908 diff = 152.699982'
});
data_saddle.push({
lat: 3.5626777779e+01,
lng: 1.3709388889e+02,
content:'Saddle = 399.399994 pos = 35.6268,137.0939 diff = 152.699982'
});
data_peak.push({
lat: 3.5621666668e+01,
lng: 1.3713877778e+02,
cert : true,
content:'Name = JA/GF-174(JA/GF-174) peak = 687.099976 pos = 35.6217,137.1388 diff = 214.499969'
});
data_saddle.push({
lat: 3.5608000002e+01,
lng: 1.3713766667e+02,
content:'Saddle = 472.600006 pos = 35.6080,137.1377 diff = 214.499969'
});
data_peak.push({
lat: 3.5620333335e+01,
lng: 1.3711955556e+02,
cert : false,
content:' Peak = 650.900024 pos = 35.6203,137.1196 diff = 168.200012'
});
data_saddle.push({
lat: 3.5612888890e+01,
lng: 1.3713166667e+02,
content:'Saddle = 482.700012 pos = 35.6129,137.1317 diff = 168.200012'
});
data_peak.push({
lat: 3.5614555557e+01,
lng: 1.3715566667e+02,
cert : false,
content:' Peak = 662.900024 pos = 35.6146,137.1557 diff = 166.200012'
});
data_saddle.push({
lat: 3.5600888890e+01,
lng: 1.3714822222e+02,
content:'Saddle = 496.700012 pos = 35.6009,137.1482 diff = 166.200012'
});
data_peak.push({
lat: 3.5573333335e+01,
lng: 1.3713388889e+02,
cert : false,
content:' Peak = 673.900024 pos = 35.5733,137.1339 diff = 150.700012'
});
data_saddle.push({
lat: 3.5576777779e+01,
lng: 1.3714266667e+02,
content:'Saddle = 523.200012 pos = 35.5768,137.1427 diff = 150.700012'
});
data_peak.push({
lat: 3.5590111113e+01,
lng: 1.3715744444e+02,
cert : false,
content:' Peak = 707.400024 pos = 35.5901,137.1574 diff = 155.400024'
});
data_saddle.push({
lat: 3.5583666668e+01,
lng: 1.3715922222e+02,
content:'Saddle = 552.000000 pos = 35.5837,137.1592 diff = 155.400024'
});
data_peak.push({
lat: 3.5059777782e+01,
lng: 1.3774533333e+02,
cert : true,
content:'Name = JA/SO-094(JA/SO-094) peak = 543.599976 pos = 35.0598,137.7453 diff = 152.099976'
});
data_saddle.push({
lat: 3.5056888893e+01,
lng: 1.3773233333e+02,
content:'Saddle = 391.500000 pos = 35.0569,137.7323 diff = 152.099976'
});
data_peak.push({
lat: 3.5004777782e+01,
lng: 1.3825833333e+02,
cert : true,
content:'Name = JA/SO-085(JA/SO-085) peak = 573.599976 pos = 35.0048,138.2583 diff = 180.799988'
});
data_saddle.push({
lat: 3.5012111115e+01,
lng: 1.3824311111e+02,
content:'Saddle = 392.799988 pos = 35.0121,138.2431 diff = 180.799988'
});
data_peak.push({
lat: 3.5871000001e+01,
lng: 1.3919688889e+02,
cert : false,
content:' Peak = 552.299988 pos = 35.8710,139.1969 diff = 151.399994'
});
data_saddle.push({
lat: 3.5876666667e+01,
lng: 1.3919666667e+02,
content:'Saddle = 400.899994 pos = 35.8767,139.1967 diff = 151.399994'
});
data_peak.push({
lat: 3.5132333337e+01,
lng: 1.3842333333e+02,
cert : false,
content:' Peak = 562.900024 pos = 35.1323,138.4233 diff = 161.700012'
});
data_saddle.push({
lat: 3.5133555559e+01,
lng: 1.3841633333e+02,
content:'Saddle = 401.200012 pos = 35.1336,138.4163 diff = 161.700012'
});
data_peak.push({
lat: 3.5656777779e+01,
lng: 1.3713844444e+02,
cert : false,
content:' Peak = 564.700012 pos = 35.6568,137.1384 diff = 162.200012'
});
data_saddle.push({
lat: 3.5658444446e+01,
lng: 1.3713366667e+02,
content:'Saddle = 402.500000 pos = 35.6584,137.1337 diff = 162.200012'
});
data_peak.push({
lat: 3.5067000004e+01,
lng: 1.3771455556e+02,
cert : false,
content:' Peak = 580.299988 pos = 35.0670,137.7146 diff = 173.199982'
});
data_saddle.push({
lat: 3.5062555559e+01,
lng: 1.3770588889e+02,
content:'Saddle = 407.100006 pos = 35.0626,137.7059 diff = 173.199982'
});
data_peak.push({
lat: 3.5640555557e+01,
lng: 1.3709555556e+02,
cert : true,
content:'Name = JA/GF-182(JA/GF-182) peak = 604.099976 pos = 35.6406,137.0956 diff = 196.899963'
});
data_saddle.push({
lat: 3.5644222224e+01,
lng: 1.3709300000e+02,
content:'Saddle = 407.200012 pos = 35.6442,137.0930 diff = 196.899963'
});
data_peak.push({
lat: 3.4882000004e+01,
lng: 1.3807788889e+02,
cert : true,
content:'Name = JA/SO-074(JA/SO-074) peak = 669.500000 pos = 34.8820,138.0779 diff = 261.600006'
});
data_saddle.push({
lat: 3.4890111116e+01,
lng: 1.3807033333e+02,
content:'Saddle = 407.899994 pos = 34.8901,138.0703 diff = 261.600006'
});
data_peak.push({
lat: 3.4984111115e+01,
lng: 1.3758277778e+02,
cert : true,
content:'Name = Houraijisan(JA/AC-022) peak = 692.299988 pos = 34.9841,137.5828 diff = 280.899994'
});
data_saddle.push({
lat: 3.4997444448e+01,
lng: 1.3758233333e+02,
content:'Saddle = 411.399994 pos = 34.9974,137.5823 diff = 280.899994'
});
data_peak.push({
lat: 3.5608333335e+01,
lng: 1.3904511111e+02,
cert : false,
content:' Peak = 565.700012 pos = 35.6083,139.0451 diff = 153.900024'
});
data_saddle.push({
lat: 3.5615000002e+01,
lng: 1.3903400000e+02,
content:'Saddle = 411.799988 pos = 35.6150,139.0340 diff = 153.900024'
});
data_peak.push({
lat: 3.5447000002e+01,
lng: 1.3842744444e+02,
cert : false,
content:' Peak = 643.900024 pos = 35.4470,138.4274 diff = 230.600037'
});
data_saddle.push({
lat: 3.5456777780e+01,
lng: 1.3841900000e+02,
content:'Saddle = 413.299988 pos = 35.4568,138.4190 diff = 230.600037'
});
data_peak.push({
lat: 3.5060333337e+01,
lng: 1.3730277778e+02,
cert : true,
content:'Name = JA/AC-024(JA/AC-024) peak = 683.099976 pos = 35.0603,137.3028 diff = 255.499969'
});
data_saddle.push({
lat: 3.5044777782e+01,
lng: 1.3733322222e+02,
content:'Saddle = 427.600006 pos = 35.0448,137.3332 diff = 255.499969'
});
data_peak.push({
lat: 3.5055000004e+01,
lng: 1.3728422222e+02,
cert : true,
content:'Name = JA/AC-026(JA/AC-026) peak = 610.799988 pos = 35.0550,137.2842 diff = 181.500000'
});
data_saddle.push({
lat: 3.5053888893e+01,
lng: 1.3729255556e+02,
content:'Saddle = 429.299988 pos = 35.0539,137.2926 diff = 181.500000'
});
data_peak.push({
lat: 3.4915777782e+01,
lng: 1.3797766667e+02,
cert : true,
content:'Name = JA/SO-077(JA/SO-077) peak = 627.700012 pos = 34.9158,137.9777 diff = 199.900024'
});
data_saddle.push({
lat: 3.4939555560e+01,
lng: 1.3798422222e+02,
content:'Saddle = 427.799988 pos = 34.9396,137.9842 diff = 199.900024'
});
data_peak.push({
lat: 3.4971777782e+01,
lng: 1.3905955556e+02,
cert : false,
content:' Peak = 593.400024 pos = 34.9718,139.0596 diff = 161.700012'
});
data_saddle.push({
lat: 3.5017000004e+01,
lng: 1.3904533333e+02,
content:'Saddle = 431.700012 pos = 35.0170,139.0453 diff = 161.700012'
});
data_peak.push({
lat: 3.4954000004e+01,
lng: 1.3818288889e+02,
cert : false,
content:' Peak = 690.500000 pos = 34.9540,138.1829 diff = 257.200012'
});
data_saddle.push({
lat: 3.4975000004e+01,
lng: 1.3819500000e+02,
content:'Saddle = 433.299988 pos = 34.9750,138.1950 diff = 257.200012'
});
data_peak.push({
lat: 3.4941555560e+01,
lng: 1.3816022222e+02,
cert : true,
content:'Name = JA/SO-070(JA/SO-070) peak = 690.299988 pos = 34.9416,138.1602 diff = 212.599976'
});
data_saddle.push({
lat: 3.4949222226e+01,
lng: 1.3817166667e+02,
content:'Saddle = 477.700012 pos = 34.9492,138.1717 diff = 212.599976'
});
data_peak.push({
lat: 3.5233444448e+01,
lng: 1.3902077778e+02,
cert : false,
content:' Peak = 1437.400024 pos = 35.2334,139.0208 diff = 991.100037'
});
data_saddle.push({
lat: 3.5293888892e+01,
lng: 1.3894088889e+02,
content:'Saddle = 446.299988 pos = 35.2939,138.9409 diff = 991.100037'
});
data_peak.push({
lat: 3.5081777781e+01,
lng: 1.3902800000e+02,
cert : true,
content:'Name = Kurotake(JA/SO-061) peak = 797.299988 pos = 35.0818,139.0280 diff = 180.299988'
});
data_saddle.push({
lat: 3.5101222226e+01,
lng: 1.3903500000e+02,
content:'Saddle = 617.000000 pos = 35.1012,139.0350 diff = 180.299988'
});
data_peak.push({
lat: 3.5328666669e+01,
lng: 1.3903533333e+02,
cert : true,
content:'Name = Yaguradake(JA/KN-016) peak = 869.000000 pos = 35.3287,139.0353 diff = 217.000000'
});
data_saddle.push({
lat: 3.5332000003e+01,
lng: 1.3902822222e+02,
content:'Saddle = 652.000000 pos = 35.3320,139.0282 diff = 217.000000'
});
data_peak.push({
lat: 3.5289777781e+01,
lng: 1.3900477778e+02,
cert : true,
content:'Name = Hakoneyama (Kintokizan)(JA/KN-007) peak = 1212.000000 pos = 35.2898,139.0048 diff = 423.700012'
});
data_saddle.push({
lat: 3.5205777781e+01,
lng: 1.3903566667e+02,
content:'Saddle = 788.299988 pos = 35.2058,139.0357 diff = 423.700012'
});
data_peak.push({
lat: 3.5195666670e+01,
lng: 1.3903600000e+02,
cert : false,
content:' Peak = 948.000000 pos = 35.1957,139.0360 diff = 159.700012'
});
data_saddle.push({
lat: 3.5186888892e+01,
lng: 1.3903211111e+02,
content:'Saddle = 788.299988 pos = 35.1869,139.0321 diff = 159.700012'
});
data_peak.push({
lat: 3.5183111114e+01,
lng: 1.3904611111e+02,
cert : true,
content:'Name = Daikanzan(JA/KN-014) peak = 1011.700012 pos = 35.1831,139.0461 diff = 164.100037'
});
data_saddle.push({
lat: 3.5180777781e+01,
lng: 1.3901366667e+02,
content:'Saddle = 847.599976 pos = 35.1808,139.0137 diff = 164.100037'
});
data_peak.push({
lat: 3.5216000003e+01,
lng: 1.3898388889e+02,
cert : true,
content:'Name = Mikuniyama(JA/KN-010) peak = 1101.599976 pos = 35.2160,138.9839 diff = 248.500000'
});
data_saddle.push({
lat: 3.5230555559e+01,
lng: 1.3897877778e+02,
content:'Saddle = 853.099976 pos = 35.2306,138.9788 diff = 248.500000'
});
data_peak.push({
lat: 3.5279555558e+01,
lng: 1.3905244444e+02,
cert : true,
content:'Name = Myoujingatake(JA/KN-009) peak = 1168.099976 pos = 35.2796,139.0524 diff = 300.599976'
});
data_saddle.push({
lat: 3.5282333336e+01,
lng: 1.3901177778e+02,
content:'Saddle = 867.500000 pos = 35.2823,139.0118 diff = 300.599976'
});
data_peak.push({
lat: 3.5270444447e+01,
lng: 1.3898211111e+02,
cert : false,
content:' Peak = 1155.000000 pos = 35.2704,138.9821 diff = 150.700012'
});
data_saddle.push({
lat: 3.5281000003e+01,
lng: 1.3898888889e+02,
content:'Saddle = 1004.299988 pos = 35.2810,138.9889 diff = 150.700012'
});
data_peak.push({
lat: 3.5214777781e+01,
lng: 1.3904188889e+02,
cert : true,
content:'Name = Uefutagosan(JA/KN-011) peak = 1099.000000 pos = 35.2148,139.0419 diff = 221.500000'
});
data_saddle.push({
lat: 3.5217555559e+01,
lng: 1.3903866667e+02,
content:'Saddle = 877.500000 pos = 35.2176,139.0387 diff = 221.500000'
});
data_peak.push({
lat: 3.5653111112e+01,
lng: 1.3722611111e+02,
cert : false,
content:' Peak = 613.099976 pos = 35.6531,137.2261 diff = 163.699982'
});
data_saddle.push({
lat: 3.5659000001e+01,
lng: 1.3722822222e+02,
content:'Saddle = 449.399994 pos = 35.6590,137.2282 diff = 163.699982'
});
data_peak.push({
lat: 3.5051111115e+01,
lng: 1.3831788889e+02,
cert : true,
content:'Name = JA/SO-065(JA/SO-065) peak = 717.500000 pos = 35.0511,138.3179 diff = 266.600006'
});
data_saddle.push({
lat: 3.5059000004e+01,
lng: 1.3830700000e+02,
content:'Saddle = 450.899994 pos = 35.0590,138.3070 diff = 266.600006'
});
data_peak.push({
lat: 3.5254888892e+01,
lng: 1.3719011111e+02,
cert : true,
content:'Name = Mikuniyama(JA/AC-021) peak = 700.799988 pos = 35.2549,137.1901 diff = 244.899994'
});
data_saddle.push({
lat: 3.5259000003e+01,
lng: 1.3721022222e+02,
content:'Saddle = 455.899994 pos = 35.2590,137.2102 diff = 244.899994'
});
data_peak.push({
lat: 3.5146000003e+01,
lng: 1.3850600000e+02,
cert : false,
content:' Peak = 618.599976 pos = 35.1460,138.5060 diff = 161.399963'
});
data_saddle.push({
lat: 3.5149333337e+01,
lng: 1.3849955556e+02,
content:'Saddle = 457.200012 pos = 35.1493,138.4996 diff = 161.399963'
});
data_peak.push({
lat: 3.5680888890e+01,
lng: 1.3710933333e+02,
cert : true,
content:'Name = JA/GF-172(JA/GF-172) peak = 703.099976 pos = 35.6809,137.1093 diff = 245.899963'
});
data_saddle.push({
lat: 3.5678333335e+01,
lng: 1.3708200000e+02,
content:'Saddle = 457.200012 pos = 35.6783,137.0820 diff = 245.899963'
});
data_peak.push({
lat: 3.5660111112e+01,
lng: 1.3710944444e+02,
cert : true,
content:'Name = JA/GF-178(JA/GF-178) peak = 663.299988 pos = 35.6601,137.1094 diff = 195.299988'
});
data_saddle.push({
lat: 3.5663555557e+01,
lng: 1.3710000000e+02,
content:'Saddle = 468.000000 pos = 35.6636,137.1000 diff = 195.299988'
});
data_peak.push({
lat: 3.4940777782e+01,
lng: 1.3749300000e+02,
cert : true,
content:'Name = JA/AC-023(JA/AC-023) peak = 687.200012 pos = 34.9408,137.4930 diff = 229.100006'
});
data_saddle.push({
lat: 3.4919888893e+01,
lng: 1.3744688889e+02,
content:'Saddle = 458.100006 pos = 34.9199,137.4469 diff = 229.100006'
});
data_peak.push({
lat: 3.4978222226e+01,
lng: 1.3794577778e+02,
cert : true,
content:'Name = JA/SO-075(JA/SO-075) peak = 657.500000 pos = 34.9782,137.9458 diff = 194.899994'
});
data_saddle.push({
lat: 3.4972000004e+01,
lng: 1.3797544444e+02,
content:'Saddle = 462.600006 pos = 34.9720,137.9754 diff = 194.899994'
});
data_peak.push({
lat: 3.5474111113e+01,
lng: 1.3850255556e+02,
cert : true,
content:'Name = JA/YN-068(JA/YN-068) peak = 662.000000 pos = 35.4741,138.5026 diff = 199.200012'
});
data_saddle.push({
lat: 3.5481000002e+01,
lng: 1.3852500000e+02,
content:'Saddle = 462.799988 pos = 35.4810,138.5250 diff = 199.200012'
});
data_peak.push({
lat: 3.5621777779e+01,
lng: 1.3894977778e+02,
cert : false,
content:' Peak = 633.099976 pos = 35.6218,138.9498 diff = 166.499969'
});
data_saddle.push({
lat: 3.5622888890e+01,
lng: 1.3894411111e+02,
content:'Saddle = 466.600006 pos = 35.6229,138.9441 diff = 166.499969'
});
data_peak.push({
lat: 3.5262222225e+01,
lng: 1.3851422222e+02,
cert : true,
content:'Name = JA/YN-066(JA/YN-066) peak = 811.099976 pos = 35.2622,138.5142 diff = 329.799988'
});
data_saddle.push({
lat: 3.5275222225e+01,
lng: 1.3852022222e+02,
content:'Saddle = 481.299988 pos = 35.2752,138.5202 diff = 329.799988'
});
data_peak.push({
lat: 3.5907111111e+01,
lng: 1.3918500000e+02,
cert : true,
content:'Name = JA/ST-015(JA/ST-015) peak = 661.299988 pos = 35.9071,139.1850 diff = 172.099976'
});
data_saddle.push({
lat: 3.5911111111e+01,
lng: 1.3917633333e+02,
content:'Saddle = 489.200012 pos = 35.9111,139.1763 diff = 172.099976'
});
data_peak.push({
lat: 3.5521888891e+01,
lng: 1.3716188889e+02,
cert : true,
content:'Name = JA/GF-175(JA/GF-175) peak = 684.900024 pos = 35.5219,137.1619 diff = 191.800018'
});
data_saddle.push({
lat: 3.5524666669e+01,
lng: 1.3717588889e+02,
content:'Saddle = 493.100006 pos = 35.5247,137.1759 diff = 191.800018'
});
data_peak.push({
lat: 3.5280666670e+01,
lng: 1.3726088889e+02,
cert : true,
content:'Name = JA/AC-020(JA/AC-020) peak = 723.299988 pos = 35.2807,137.2609 diff = 226.799988'
});
data_saddle.push({
lat: 3.5289444447e+01,
lng: 1.3729955556e+02,
content:'Saddle = 496.500000 pos = 35.2894,137.2996 diff = 226.799988'
});
data_peak.push({
lat: 3.4947000004e+01,
lng: 1.3796111111e+02,
cert : false,
content:' Peak = 656.900024 pos = 34.9470,137.9611 diff = 155.500031'
});
data_saddle.push({
lat: 3.4954777782e+01,
lng: 1.3796444444e+02,
content:'Saddle = 501.399994 pos = 34.9548,137.9644 diff = 155.500031'
});
data_peak.push({
lat: 3.5067222226e+01,
lng: 1.3785533333e+02,
cert : true,
content:'Name = JA/SO-073(JA/SO-073) peak = 677.000000 pos = 35.0672,137.8553 diff = 171.700012'
});
data_saddle.push({
lat: 3.5070111115e+01,
lng: 1.3786377778e+02,
content:'Saddle = 505.299988 pos = 35.0701,137.8638 diff = 171.700012'
});
data_peak.push({
lat: 3.5428333336e+01,
lng: 1.3744522222e+02,
cert : true,
content:'Name = JA/GF-173(JA/GF-173) peak = 701.299988 pos = 35.4283,137.4452 diff = 194.500000'
});
data_saddle.push({
lat: 3.5414444447e+01,
lng: 1.3745955556e+02,
content:'Saddle = 506.799988 pos = 35.4144,137.4596 diff = 194.500000'
});
data_peak.push({
lat: 3.5701555557e+01,
lng: 1.3706755556e+02,
cert : true,
content:'Name = JA/GF-157(JA/GF-157) peak = 792.500000 pos = 35.7016,137.0676 diff = 285.299988'
});
data_saddle.push({
lat: 3.5715555557e+01,
lng: 1.3700033333e+02,
content:'Saddle = 507.200012 pos = 35.7156,137.0003 diff = 285.299988'
});
data_peak.push({
lat: 3.5685000001e+01,
lng: 1.3706955556e+02,
cert : false,
content:' Peak = 703.700012 pos = 35.6850,137.0696 diff = 176.500000'
});
data_saddle.push({
lat: 3.5690777779e+01,
lng: 1.3705811111e+02,
content:'Saddle = 527.200012 pos = 35.6908,137.0581 diff = 176.500000'
});
data_peak.push({
lat: 3.5711555557e+01,
lng: 1.3700744444e+02,
cert : true,
content:'Name = JA/GF-160(JA/GF-160) peak = 771.099976 pos = 35.7116,137.0074 diff = 240.199951'
});
data_saddle.push({
lat: 3.5693555557e+01,
lng: 1.3702000000e+02,
content:'Saddle = 530.900024 pos = 35.6936,137.0200 diff = 240.199951'
});
data_peak.push({
lat: 3.5730777779e+01,
lng: 1.3700033333e+02,
cert : true,
content:'Name = JA/GF-164(JA/GF-164) peak = 754.099976 pos = 35.7308,137.0003 diff = 238.199951'
});
data_saddle.push({
lat: 3.5739000001e+01,
lng: 1.3700000000e+02,
content:'Saddle = 515.900024 pos = 35.7390,137.0000 diff = 238.199951'
});
data_peak.push({
lat: 3.5049777782e+01,
lng: 1.3766244444e+02,
cert : true,
content:'Name = JA/AC-006(JA/AC-006) peak = 1014.599976 pos = 35.0498,137.6624 diff = 495.099976'
});
data_saddle.push({
lat: 3.5053777782e+01,
lng: 1.3760422222e+02,
content:'Saddle = 519.500000 pos = 35.0538,137.6042 diff = 495.099976'
});
data_peak.push({
lat: 3.4897000004e+01,
lng: 1.3802277778e+02,
cert : false,
content:' Peak = 674.599976 pos = 34.8970,138.0228 diff = 151.899963'
});
data_saddle.push({
lat: 3.4910111115e+01,
lng: 1.3802833333e+02,
content:'Saddle = 522.700012 pos = 34.9101,138.0283 diff = 151.899963'
});
data_peak.push({
lat: 3.5351666669e+01,
lng: 1.3732477778e+02,
cert : false,
content:' Peak = 821.400024 pos = 35.3517,137.3248 diff = 294.400024'
});
data_saddle.push({
lat: 3.5357555558e+01,
lng: 1.3742322222e+02,
content:'Saddle = 527.000000 pos = 35.3576,137.4232 diff = 294.400024'
});
data_peak.push({
lat: 3.5414444447e+01,
lng: 1.3740111111e+02,
cert : true,
content:'Name = JA/GF-162(JA/GF-162) peak = 770.299988 pos = 35.4144,137.4011 diff = 193.899963'
});
data_saddle.push({
lat: 3.5380888891e+01,
lng: 1.3738266667e+02,
content:'Saddle = 576.400024 pos = 35.3809,137.3827 diff = 193.899963'
});
data_peak.push({
lat: 3.5321888892e+01,
lng: 1.3736655556e+02,
cert : true,
content:'Name = JA/GF-166(JA/GF-166) peak = 740.799988 pos = 35.3219,137.3666 diff = 212.599976'
});
data_saddle.push({
lat: 3.5332888892e+01,
lng: 1.3738944444e+02,
content:'Saddle = 528.200012 pos = 35.3329,137.3894 diff = 212.599976'
});
data_peak.push({
lat: 3.5550555557e+01,
lng: 1.3750588889e+02,
cert : true,
content:'Name = JA/GF-135(JA/GF-135) peak = 944.200012 pos = 35.5506,137.5059 diff = 415.600037'
});
data_saddle.push({
lat: 3.5612555557e+01,
lng: 1.3748744444e+02,
content:'Saddle = 528.599976 pos = 35.6126,137.4874 diff = 415.600037'
});
data_peak.push({
lat: 3.4909777782e+01,
lng: 1.3742055556e+02,
cert : true,
content:'Name = Honguusan(JA/AC-017) peak = 788.099976 pos = 34.9098,137.4206 diff = 256.099976'
});
data_saddle.push({
lat: 3.4970666671e+01,
lng: 1.3742855556e+02,
content:'Saddle = 532.000000 pos = 34.9707,137.4286 diff = 256.099976'
});
data_peak.push({
lat: 3.4976000004e+01,
lng: 1.3740188889e+02,
cert : false,
content:' Peak = 733.299988 pos = 34.9760,137.4019 diff = 175.899963'
});
data_saddle.push({
lat: 3.4957333338e+01,
lng: 1.3740833333e+02,
content:'Saddle = 557.400024 pos = 34.9573,137.4083 diff = 175.899963'
});
data_peak.push({
lat: 3.5323000003e+01,
lng: 1.3794277778e+02,
cert : true,
content:'Name = JA/NN-193(JA/NN-193) peak = 716.400024 pos = 35.3230,137.9428 diff = 183.700012'
});
data_saddle.push({
lat: 3.5323444447e+01,
lng: 1.3794866667e+02,
content:'Saddle = 532.700012 pos = 35.3234,137.9487 diff = 183.700012'
});
data_peak.push({
lat: 3.5681666668e+01,
lng: 1.3721833333e+02,
cert : true,
content:'Name = JA/GF-141(JA/GF-141) peak = 906.599976 pos = 35.6817,137.2183 diff = 369.799988'
});
data_saddle.push({
lat: 3.5676777779e+01,
lng: 1.3723733333e+02,
content:'Saddle = 536.799988 pos = 35.6768,137.2373 diff = 369.799988'
});
data_peak.push({
lat: 3.5695666668e+01,
lng: 1.3719922222e+02,
cert : false,
content:' Peak = 700.000000 pos = 35.6957,137.1992 diff = 162.299988'
});
data_saddle.push({
lat: 3.5691888890e+01,
lng: 1.3720733333e+02,
content:'Saddle = 537.700012 pos = 35.6919,137.2073 diff = 162.299988'
});
data_peak.push({
lat: 3.5086777781e+01,
lng: 1.3766111111e+02,
cert : true,
content:'Name = JA/AC-016(JA/AC-016) peak = 788.400024 pos = 35.0868,137.6611 diff = 245.900024'
});
data_saddle.push({
lat: 3.5084777781e+01,
lng: 1.3763855556e+02,
content:'Saddle = 542.500000 pos = 35.0848,137.6386 diff = 245.900024'
});
data_peak.push({
lat: 3.5544666668e+01,
lng: 1.3720655556e+02,
cert : true,
content:'Name = JA/GF-168(JA/GF-168) peak = 732.900024 pos = 35.5447,137.2066 diff = 185.400024'
});
data_saddle.push({
lat: 3.5552444446e+01,
lng: 1.3720355556e+02,
content:'Saddle = 547.500000 pos = 35.5524,137.2036 diff = 185.400024'
});
data_peak.push({
lat: 3.5589000002e+01,
lng: 1.3724100000e+02,
cert : true,
content:'Name = JA/GF-169(JA/GF-169) peak = 723.500000 pos = 35.5890,137.2410 diff = 175.900024'
});
data_saddle.push({
lat: 3.5589777779e+01,
lng: 1.3725055556e+02,
content:'Saddle = 547.599976 pos = 35.5898,137.2506 diff = 175.900024'
});
data_peak.push({
lat: 3.5094555559e+01,
lng: 1.3771500000e+02,
cert : true,
content:'Name = JA/AC-019(JA/AC-019) peak = 715.700012 pos = 35.0946,137.7150 diff = 167.700012'
});
data_saddle.push({
lat: 3.5110777781e+01,
lng: 1.3770777778e+02,
content:'Saddle = 548.000000 pos = 35.1108,137.7078 diff = 167.700012'
});
data_peak.push({
lat: 3.5733666668e+01,
lng: 1.3702333333e+02,
cert : true,
content:'Name = JA/GF-163(JA/GF-163) peak = 761.200012 pos = 35.7337,137.0233 diff = 212.299988'
});
data_saddle.push({
lat: 3.5740444445e+01,
lng: 1.3701844444e+02,
content:'Saddle = 548.900024 pos = 35.7404,137.0184 diff = 212.299988'
});
data_peak.push({
lat: 3.5293222225e+01,
lng: 1.3851722222e+02,
cert : true,
content:'Name = JA/SO-063(JA/SO-063) peak = 730.700012 pos = 35.2932,138.5172 diff = 179.100037'
});
data_saddle.push({
lat: 3.5304888892e+01,
lng: 1.3851355556e+02,
content:'Saddle = 551.599976 pos = 35.3049,138.5136 diff = 179.100037'
});
data_peak.push({
lat: 3.4964777782e+01,
lng: 1.3811666667e+02,
cert : true,
content:'Name = JA/SO-064(JA/SO-064) peak = 721.200012 pos = 34.9648,138.1167 diff = 169.100037'
});
data_saddle.push({
lat: 3.4972555560e+01,
lng: 1.3814855556e+02,
content:'Saddle = 552.099976 pos = 34.9726,138.1486 diff = 169.100037'
});
data_peak.push({
lat: 3.5563888891e+01,
lng: 1.3719700000e+02,
cert : false,
content:' Peak = 713.700012 pos = 35.5639,137.1970 diff = 155.700012'
});
data_saddle.push({
lat: 3.5557666668e+01,
lng: 1.3720811111e+02,
content:'Saddle = 558.000000 pos = 35.5577,137.2081 diff = 155.700012'
});
data_peak.push({
lat: 3.4996000004e+01,
lng: 1.3803166667e+02,
cert : true,
content:'Name = JA/SO-049(JA/SO-049) peak = 1008.299988 pos = 34.9960,138.0317 diff = 450.000000'
});
data_saddle.push({
lat: 3.5017888893e+01,
lng: 1.3802788889e+02,
content:'Saddle = 558.299988 pos = 35.0179,138.0279 diff = 450.000000'
});
data_peak.push({
lat: 3.4938333338e+01,
lng: 1.3800600000e+02,
cert : true,
content:'Name = JA/SO-054(JA/SO-054) peak = 880.700012 pos = 34.9383,138.0060 diff = 304.600037'
});
data_saddle.push({
lat: 3.4953666671e+01,
lng: 1.3801477778e+02,
content:'Saddle = 576.099976 pos = 34.9537,138.0148 diff = 304.600037'
});
data_peak.push({
lat: 3.4907333338e+01,
lng: 1.3805688889e+02,
cert : true,
content:'Name = Hakkousan(JA/SO-059) peak = 834.599976 pos = 34.9073,138.0569 diff = 212.000000'
});
data_saddle.push({
lat: 3.4916555560e+01,
lng: 1.3804411111e+02,
content:'Saddle = 622.599976 pos = 34.9166,138.0441 diff = 212.000000'
});
data_peak.push({
lat: 3.5118333337e+01,
lng: 1.3783944444e+02,
cert : true,
content:'Name = JA/SO-060(JA/SO-060) peak = 813.400024 pos = 35.1183,137.8394 diff = 252.200012'
});
data_saddle.push({
lat: 3.5125111115e+01,
lng: 1.3783633333e+02,
content:'Saddle = 561.200012 pos = 35.1251,137.8363 diff = 252.200012'
});
data_peak.push({
lat: 3.5616333335e+01,
lng: 1.3891766667e+02,
cert : false,
content:' Peak = 751.299988 pos = 35.6163,138.9177 diff = 183.700012'
});
data_saddle.push({
lat: 3.5620555557e+01,
lng: 1.3890944444e+02,
content:'Saddle = 567.599976 pos = 35.6206,138.9094 diff = 183.700012'
});
data_peak.push({
lat: 3.5085000004e+01,
lng: 1.3763155556e+02,
cert : true,
content:'Name = JA/AC-018(JA/AC-018) peak = 756.200012 pos = 35.0850,137.6316 diff = 183.799988'
});
data_saddle.push({
lat: 3.5087666670e+01,
lng: 1.3762866667e+02,
content:'Saddle = 572.400024 pos = 35.0877,137.6287 diff = 183.799988'
});
data_peak.push({
lat: 3.5706000001e+01,
lng: 1.3715577778e+02,
cert : true,
content:'Name = JA/GF-161(JA/GF-161) peak = 772.900024 pos = 35.7060,137.1558 diff = 179.800049'
});
data_saddle.push({
lat: 3.5717444446e+01,
lng: 1.3715233333e+02,
content:'Saddle = 593.099976 pos = 35.7174,137.1523 diff = 179.800049'
});
data_peak.push({
lat: 3.5957111111e+01,
lng: 1.3700433333e+02,
cert : true,
content:'Name = JA/GF-029(JA/GF-029) peak = 1630.800049 pos = 35.9571,137.0043 diff = 1036.200073'
});
data_saddle.push({
lat: 3.5999777778e+01,
lng: 1.3728555556e+02,
content:'Saddle = 594.599976 pos = 35.9998,137.2856 diff = 1036.200073'
});
data_peak.push({
lat: 3.5998555556e+01,
lng: 1.3727566667e+02,
cert : false,
content:' Peak = 906.900024 pos = 35.9986,137.2757 diff = 243.500000'
});
data_saddle.push({
lat: 3.6000000000e+01,
lng: 1.3726788889e+02,
content:'Saddle = 663.400024 pos = 36.0000,137.2679 diff = 243.500000'
});
data_peak.push({
lat: 3.5745777779e+01,
lng: 1.3717444444e+02,
cert : true,
content:'Name = JA/GF-148(JA/GF-148) peak = 871.500000 pos = 35.7458,137.1744 diff = 186.500000'
});
data_saddle.push({
lat: 3.5757000001e+01,
lng: 1.3717933333e+02,
content:'Saddle = 685.000000 pos = 35.7570,137.1793 diff = 186.500000'
});
data_peak.push({
lat: 3.5997000000e+01,
lng: 1.3722811111e+02,
cert : false,
content:' Peak = 1322.199951 pos = 35.9970,137.2281 diff = 620.799927'
});
data_saddle.push({
lat: 3.5999888889e+01,
lng: 1.3718322222e+02,
content:'Saddle = 701.400024 pos = 35.9999,137.1832 diff = 620.799927'
});
data_peak.push({
lat: 3.5999444444e+01,
lng: 1.3719611111e+02,
cert : false,
content:' Peak = 1180.099976 pos = 35.9994,137.1961 diff = 342.099976'
});
data_saddle.push({
lat: 3.6000000000e+01,
lng: 1.3720522222e+02,
content:'Saddle = 838.000000 pos = 36.0000,137.2052 diff = 342.099976'
});
data_peak.push({
lat: 3.5769333334e+01,
lng: 1.3719444444e+02,
cert : true,
content:'Name = JA/GF-144(JA/GF-144) peak = 896.099976 pos = 35.7693,137.1944 diff = 167.699951'
});
data_saddle.push({
lat: 3.5774333334e+01,
lng: 1.3719744444e+02,
content:'Saddle = 728.400024 pos = 35.7743,137.1974 diff = 167.699951'
});
data_peak.push({
lat: 3.5792777779e+01,
lng: 1.3721166667e+02,
cert : true,
content:'Name = JA/GF-111(JA/GF-111) peak = 1100.400024 pos = 35.7928,137.2117 diff = 346.700012'
});
data_saddle.push({
lat: 3.5868000001e+01,
lng: 1.3718988889e+02,
content:'Saddle = 753.700012 pos = 35.8680,137.1899 diff = 346.700012'
});
data_peak.push({
lat: 3.5848333334e+01,
lng: 1.3720011111e+02,
cert : false,
content:' Peak = 1068.300049 pos = 35.8483,137.2001 diff = 157.900024'
});
data_saddle.push({
lat: 3.5815555556e+01,
lng: 1.3721333333e+02,
content:'Saddle = 910.400024 pos = 35.8156,137.2133 diff = 157.900024'
});
data_peak.push({
lat: 3.5866444445e+01,
lng: 1.3701300000e+02,
cert : false,
content:' Peak = 1030.000000 pos = 35.8664,137.0130 diff = 255.000000'
});
data_saddle.push({
lat: 3.5897555556e+01,
lng: 1.3700000000e+02,
content:'Saddle = 775.000000 pos = 35.8976,137.0000 diff = 255.000000'
});
data_peak.push({
lat: 3.5887666667e+01,
lng: 1.3700000000e+02,
cert : false,
content:' Peak = 1025.900024 pos = 35.8877,137.0000 diff = 178.900024'
});
data_saddle.push({
lat: 3.5875000001e+01,
lng: 1.3700000000e+02,
content:'Saddle = 847.000000 pos = 35.8750,137.0000 diff = 178.900024'
});
data_peak.push({
lat: 3.5832000001e+01,
lng: 1.3704655556e+02,
cert : true,
content:'Name = JA/GF-100(JA/GF-100) peak = 1152.900024 pos = 35.8320,137.0466 diff = 265.400024'
});
data_saddle.push({
lat: 3.5833111112e+01,
lng: 1.3706155556e+02,
content:'Saddle = 887.500000 pos = 35.8331,137.0616 diff = 265.400024'
});
data_peak.push({
lat: 3.5836777778e+01,
lng: 1.3712333333e+02,
cert : true,
content:'Name = JA/GF-091(JA/GF-091) peak = 1213.099976 pos = 35.8368,137.1233 diff = 301.500000'
});
data_saddle.push({
lat: 3.5853555556e+01,
lng: 1.3707600000e+02,
content:'Saddle = 911.599976 pos = 35.8536,137.0760 diff = 301.500000'
});
data_peak.push({
lat: 3.5825111112e+01,
lng: 1.3707600000e+02,
cert : false,
content:' Peak = 1110.900024 pos = 35.8251,137.0760 diff = 168.600037'
});
data_saddle.push({
lat: 3.5836666667e+01,
lng: 1.3707988889e+02,
content:'Saddle = 942.299988 pos = 35.8367,137.0799 diff = 168.600037'
});
data_peak.push({
lat: 3.5903222223e+01,
lng: 1.3717844444e+02,
cert : true,
content:'Name = JA/GF-103(JA/GF-103) peak = 1138.199951 pos = 35.9032,137.1784 diff = 225.099976'
});
data_saddle.push({
lat: 3.5910111111e+01,
lng: 1.3717788889e+02,
content:'Saddle = 913.099976 pos = 35.9101,137.1779 diff = 225.099976'
});
data_peak.push({
lat: 3.5999777778e+01,
lng: 1.3715433333e+02,
cert : false,
content:' Peak = 1553.900024 pos = 35.9998,137.1543 diff = 618.000000'
});
data_saddle.push({
lat: 3.5999888889e+01,
lng: 1.3711922222e+02,
content:'Saddle = 935.900024 pos = 35.9999,137.1192 diff = 618.000000'
});
data_peak.push({
lat: 3.5956333334e+01,
lng: 1.3716222222e+02,
cert : true,
content:'Name = JA/GF-039(JA/GF-039) peak = 1510.599976 pos = 35.9563,137.1622 diff = 207.900024'
});
data_saddle.push({
lat: 3.5974333333e+01,
lng: 1.3716366667e+02,
content:'Saddle = 1302.699951 pos = 35.9743,137.1637 diff = 207.900024'
});
data_peak.push({
lat: 3.6000000000e+01,
lng: 1.3714211111e+02,
cert : false,
content:' Peak = 1529.199951 pos = 36.0000,137.1421 diff = 180.799927'
});
data_saddle.push({
lat: 3.6000000000e+01,
lng: 1.3714644444e+02,
content:'Saddle = 1348.400024 pos = 36.0000,137.1464 diff = 180.799927'
});
data_peak.push({
lat: 3.5865555556e+01,
lng: 1.3715055556e+02,
cert : true,
content:'Name = JA/GF-110(JA/GF-110) peak = 1102.400024 pos = 35.8656,137.1506 diff = 164.700012'
});
data_saddle.push({
lat: 3.5883000000e+01,
lng: 1.3714233333e+02,
content:'Saddle = 937.700012 pos = 35.8830,137.1423 diff = 164.700012'
});
data_peak.push({
lat: 3.5999222222e+01,
lng: 1.3710211111e+02,
cert : false,
content:' Peak = 1262.300049 pos = 35.9992,137.1021 diff = 310.200073'
});
data_saddle.push({
lat: 3.6000000000e+01,
lng: 1.3705855556e+02,
content:'Saddle = 952.099976 pos = 36.0000,137.0586 diff = 310.200073'
});
data_peak.push({
lat: 3.6000000000e+01,
lng: 1.3708477778e+02,
cert : false,
content:' Peak = 1125.300049 pos = 36.0000,137.0848 diff = 157.400024'
});
data_saddle.push({
lat: 3.6000000000e+01,
lng: 1.3709111111e+02,
content:'Saddle = 967.900024 pos = 36.0000,137.0911 diff = 157.400024'
});
data_peak.push({
lat: 3.5922777778e+01,
lng: 1.3710233333e+02,
cert : true,
content:'Name = JA/GF-078(JA/GF-078) peak = 1285.199951 pos = 35.9228,137.1023 diff = 307.499939'
});
data_saddle.push({
lat: 3.5919111111e+01,
lng: 1.3706977778e+02,
content:'Saddle = 977.700012 pos = 35.9191,137.0698 diff = 307.499939'
});
data_peak.push({
lat: 3.5037555559e+01,
lng: 1.3757666667e+02,
cert : false,
content:' Peak = 761.099976 pos = 35.0376,137.5767 diff = 164.799988'
});
data_saddle.push({
lat: 3.5040444448e+01,
lng: 1.3758266667e+02,
content:'Saddle = 596.299988 pos = 35.0404,137.5827 diff = 164.799988'
});
data_peak.push({
lat: 3.5451333336e+01,
lng: 1.3777777778e+02,
cert : true,
content:'Name = JA/NN-192(JA/NN-192) peak = 797.700012 pos = 35.4513,137.7778 diff = 194.799988'
});
data_saddle.push({
lat: 3.5464666669e+01,
lng: 1.3776844444e+02,
content:'Saddle = 602.900024 pos = 35.4647,137.7684 diff = 194.799988'
});
data_peak.push({
lat: 3.5988666667e+01,
lng: 1.3915955556e+02,
cert : true,
content:'Name = Maruyama(JA/ST-012) peak = 960.200012 pos = 35.9887,139.1596 diff = 351.600037'
});
data_saddle.push({
lat: 3.5931222222e+01,
lng: 1.3915211111e+02,
content:'Saddle = 608.599976 pos = 35.9312,139.1521 diff = 351.600037'
});
data_peak.push({
lat: 3.5926888889e+01,
lng: 1.3916055556e+02,
cert : true,
content:'Name = Izugatake(JA/ST-013) peak = 850.599976 pos = 35.9269,139.1606 diff = 217.899963'
});
data_saddle.push({
lat: 3.5941777778e+01,
lng: 1.3916044444e+02,
content:'Saddle = 632.700012 pos = 35.9418,139.1604 diff = 217.899963'
});
data_peak.push({
lat: 3.4979777782e+01,
lng: 1.3818333333e+02,
cert : true,
content:'Name = JA/SO-055(JA/SO-055) peak = 870.599976 pos = 34.9798,138.1833 diff = 261.899963'
});
data_saddle.push({
lat: 3.5006888893e+01,
lng: 1.3818711111e+02,
content:'Saddle = 608.700012 pos = 35.0069,138.1871 diff = 261.899963'
});
data_peak.push({
lat: 3.5995555556e+01,
lng: 1.3890300000e+02,
cert : false,
content:' Peak = 1192.099976 pos = 35.9956,138.9030 diff = 575.000000'
});
data_saddle.push({
lat: 3.5999888889e+01,
lng: 1.3887000000e+02,
content:'Saddle = 617.099976 pos = 35.9999,138.8700 diff = 575.000000'
});
data_peak.push({
lat: 3.5760000001e+01,
lng: 1.3724244444e+02,
cert : true,
content:'Name = JA/GF-140(JA/GF-140) peak = 906.599976 pos = 35.7600,137.2424 diff = 288.199951'
});
data_saddle.push({
lat: 3.5739888890e+01,
lng: 1.3725633333e+02,
content:'Saddle = 618.400024 pos = 35.7399,137.2563 diff = 288.199951'
});
data_peak.push({
lat: 3.5243111114e+01,
lng: 1.3743044444e+02,
cert : true,
content:'Name = JA/GF-158(JA/GF-158) peak = 793.900024 pos = 35.2431,137.4304 diff = 175.400024'
});
data_saddle.push({
lat: 3.5257111114e+01,
lng: 1.3744777778e+02,
content:'Saddle = 618.500000 pos = 35.2571,137.4478 diff = 175.400024'
});
data_peak.push({
lat: 3.5732222223e+01,
lng: 1.3722122222e+02,
cert : false,
content:' Peak = 773.500000 pos = 35.7322,137.2212 diff = 154.900024'
});
data_saddle.push({
lat: 3.5724555557e+01,
lng: 1.3722833333e+02,
content:'Saddle = 618.599976 pos = 35.7246,137.2283 diff = 154.900024'
});
data_peak.push({
lat: 3.5706555557e+01,
lng: 1.3916533333e+02,
cert : true,
content:'Name = Usukiyama(JA/TK-012) peak = 841.299988 pos = 35.7066,139.1653 diff = 220.500000'
});
data_saddle.push({
lat: 3.5696222223e+01,
lng: 1.3917244444e+02,
content:'Saddle = 620.799988 pos = 35.6962,139.1724 diff = 220.500000'
});
data_peak.push({
lat: 3.5022777782e+01,
lng: 1.3759777778e+02,
cert : true,
content:'Name = JA/AC-011(JA/AC-011) peak = 928.200012 pos = 35.0228,137.5978 diff = 307.000000'
});
data_saddle.push({
lat: 3.5047888893e+01,
lng: 1.3758522222e+02,
content:'Saddle = 621.200012 pos = 35.0479,137.5852 diff = 307.000000'
});
data_peak.push({
lat: 3.5722444446e+01,
lng: 1.3726077778e+02,
cert : true,
content:'Name = JA/GF-146(JA/GF-146) peak = 880.799988 pos = 35.7224,137.2608 diff = 254.700012'
});
data_saddle.push({
lat: 3.5720444446e+01,
lng: 1.3728844444e+02,
content:'Saddle = 626.099976 pos = 35.7204,137.2884 diff = 254.700012'
});
data_peak.push({
lat: 3.5595333335e+01,
lng: 1.3895177778e+02,
cert : true,
content:'Name = JA/YN-067(JA/YN-067) peak = 795.900024 pos = 35.5953,138.9518 diff = 168.100037'
});
data_saddle.push({
lat: 3.5588888891e+01,
lng: 1.3894922222e+02,
content:'Saddle = 627.799988 pos = 35.5889,138.9492 diff = 168.100037'
});
data_peak.push({
lat: 3.5009444448e+01,
lng: 1.3820088889e+02,
cert : true,
content:'Name = JA/SO-058(JA/SO-058) peak = 833.700012 pos = 35.0094,138.2009 diff = 205.900024'
});
data_saddle.push({
lat: 3.5012888893e+01,
lng: 1.3819344444e+02,
content:'Saddle = 627.799988 pos = 35.0129,138.1934 diff = 205.900024'
});
data_peak.push({
lat: 3.5586111113e+01,
lng: 1.3890188889e+02,
cert : true,
content:'Name = JA/YN-062(JA/YN-062) peak = 975.400024 pos = 35.5861,138.9019 diff = 343.900024'
});
data_saddle.push({
lat: 3.5574444446e+01,
lng: 1.3886277778e+02,
content:'Saddle = 631.500000 pos = 35.5744,138.8628 diff = 343.900024'
});
data_peak.push({
lat: 3.5485444447e+01,
lng: 1.3923611111e+02,
cert : false,
content:' Peak = 814.799988 pos = 35.4854,139.2361 diff = 181.399963'
});
data_saddle.push({
lat: 3.5481444447e+01,
lng: 1.3924800000e+02,
content:'Saddle = 633.400024 pos = 35.4814,139.2480 diff = 181.399963'
});
data_peak.push({
lat: 3.5572777779e+01,
lng: 1.3739900000e+02,
cert : false,
content:' Peak = 1222.400024 pos = 35.5728,137.3990 diff = 583.900024'
});
data_saddle.push({
lat: 3.5682888890e+01,
lng: 1.3740155556e+02,
content:'Saddle = 638.500000 pos = 35.6829,137.4016 diff = 583.900024'
});
data_peak.push({
lat: 3.5483666669e+01,
lng: 1.3730966667e+02,
cert : false,
content:' Peak = 791.200012 pos = 35.4837,137.3097 diff = 150.100037'
});
data_saddle.push({
lat: 3.5509888891e+01,
lng: 1.3728322222e+02,
content:'Saddle = 641.099976 pos = 35.5099,137.2832 diff = 150.100037'
});
data_peak.push({
lat: 3.5597777779e+01,
lng: 1.3728344444e+02,
cert : true,
content:'Name = JA/GF-145(JA/GF-145) peak = 886.900024 pos = 35.5978,137.2834 diff = 239.500000'
});
data_saddle.push({
lat: 3.5606444446e+01,
lng: 1.3730355556e+02,
content:'Saddle = 647.400024 pos = 35.6064,137.3036 diff = 239.500000'
});
data_peak.push({
lat: 3.5527111113e+01,
lng: 1.3726888889e+02,
cert : true,
content:'Name = JA/GF-143(JA/GF-143) peak = 903.900024 pos = 35.5271,137.2689 diff = 253.300049'
});
data_saddle.push({
lat: 3.5534222224e+01,
lng: 1.3731855556e+02,
content:'Saddle = 650.599976 pos = 35.5342,137.3186 diff = 253.300049'
});
data_peak.push({
lat: 3.5531222224e+01,
lng: 1.3728922222e+02,
cert : true,
content:'Name = JA/GF-150(JA/GF-150) peak = 865.900024 pos = 35.5312,137.2892 diff = 199.800049'
});
data_saddle.push({
lat: 3.5530111113e+01,
lng: 1.3727844444e+02,
content:'Saddle = 666.099976 pos = 35.5301,137.2784 diff = 199.800049'
});
data_peak.push({
lat: 3.5639333335e+01,
lng: 1.3736955556e+02,
cert : true,
content:'Name = JA/GF-125(JA/GF-125) peak = 1002.799988 pos = 35.6393,137.3696 diff = 294.000000'
});
data_saddle.push({
lat: 3.5629777779e+01,
lng: 1.3737233333e+02,
content:'Saddle = 708.799988 pos = 35.6298,137.3723 diff = 294.000000'
});
data_peak.push({
lat: 3.5510666669e+01,
lng: 1.3734766667e+02,
cert : true,
content:'Name = JA/GF-107(JA/GF-107) peak = 1126.500000 pos = 35.5107,137.3477 diff = 409.000000'
});
data_saddle.push({
lat: 3.5538000002e+01,
lng: 1.3734700000e+02,
content:'Saddle = 717.500000 pos = 35.5380,137.3470 diff = 409.000000'
});
data_peak.push({
lat: 3.5569333335e+01,
lng: 1.3728133333e+02,
cert : false,
content:' Peak = 912.700012 pos = 35.5693,137.2813 diff = 150.700012'
});
data_saddle.push({
lat: 3.5565333335e+01,
lng: 1.3728700000e+02,
content:'Saddle = 762.000000 pos = 35.5653,137.2870 diff = 150.700012'
});
data_peak.push({
lat: 3.5662444446e+01,
lng: 1.3739666667e+02,
cert : false,
content:' Peak = 983.000000 pos = 35.6624,137.3967 diff = 205.099976'
});
data_saddle.push({
lat: 3.5641333335e+01,
lng: 1.3740588889e+02,
content:'Saddle = 777.900024 pos = 35.6413,137.4059 diff = 205.099976'
});
data_peak.push({
lat: 3.5646333335e+01,
lng: 1.3739955556e+02,
cert : true,
content:'Name = JA/GF-129(JA/GF-129) peak = 971.299988 pos = 35.6463,137.3996 diff = 163.099976'
});
data_saddle.push({
lat: 3.5658777779e+01,
lng: 1.3740800000e+02,
content:'Saddle = 808.200012 pos = 35.6588,137.4080 diff = 163.099976'
});
data_peak.push({
lat: 3.5617444446e+01,
lng: 1.3734455556e+02,
cert : true,
content:'Name = JA/GF-126(JA/GF-126) peak = 1001.599976 pos = 35.6174,137.3446 diff = 213.299988'
});
data_saddle.push({
lat: 3.5616333335e+01,
lng: 1.3736566667e+02,
content:'Saddle = 788.299988 pos = 35.6163,137.3657 diff = 213.299988'
});
data_peak.push({
lat: 3.5565000002e+01,
lng: 1.3734288889e+02,
cert : true,
content:'Name = JA/GF-114(JA/GF-114) peak = 1080.000000 pos = 35.5650,137.3429 diff = 281.299988'
});
data_saddle.push({
lat: 3.5565222224e+01,
lng: 1.3735933333e+02,
content:'Saddle = 798.700012 pos = 35.5652,137.3593 diff = 281.299988'
});
data_peak.push({
lat: 3.5603000002e+01,
lng: 1.3738666667e+02,
cert : true,
content:'Name = JA/GF-099(JA/GF-099) peak = 1155.400024 pos = 35.6030,137.3867 diff = 273.700012'
});
data_saddle.push({
lat: 3.5589777779e+01,
lng: 1.3739033333e+02,
content:'Saddle = 881.700012 pos = 35.5898,137.3903 diff = 273.700012'
});
data_peak.push({
lat: 3.5022555559e+01,
lng: 1.3818766667e+02,
cert : true,
content:'Name = JA/SO-056(JA/SO-056) peak = 866.299988 pos = 35.0226,138.1877 diff = 223.700012'
});
data_saddle.push({
lat: 3.5057888893e+01,
lng: 1.3820088889e+02,
content:'Saddle = 642.599976 pos = 35.0579,138.2009 diff = 223.700012'
});
data_peak.push({
lat: 3.5123444448e+01,
lng: 1.3773722222e+02,
cert : true,
content:'Name = JA/AC-008(JA/AC-008) peak = 983.200012 pos = 35.1234,137.7372 diff = 335.100037'
});
data_saddle.push({
lat: 3.5132555559e+01,
lng: 1.3768922222e+02,
content:'Saddle = 648.099976 pos = 35.1326,137.6892 diff = 335.100037'
});
data_peak.push({
lat: 3.5125777781e+01,
lng: 1.3770288889e+02,
cert : false,
content:' Peak = 936.500000 pos = 35.1258,137.7029 diff = 155.000000'
});
data_saddle.push({
lat: 3.5128888892e+01,
lng: 1.3771933333e+02,
content:'Saddle = 781.500000 pos = 35.1289,137.7193 diff = 155.000000'
});
data_peak.push({
lat: 3.5607777779e+01,
lng: 1.3751422222e+02,
cert : true,
content:'Name = JA/GF-152(JA/GF-152) peak = 840.200012 pos = 35.6078,137.5142 diff = 191.500000'
});
data_saddle.push({
lat: 3.5615000002e+01,
lng: 1.3751600000e+02,
content:'Saddle = 648.700012 pos = 35.6150,137.5160 diff = 191.500000'
});
data_peak.push({
lat: 3.5058111115e+01,
lng: 1.3757977778e+02,
cert : true,
content:'Name = JA/AC-013(JA/AC-013) peak = 885.400024 pos = 35.0581,137.5798 diff = 233.700012'
});
data_saddle.push({
lat: 3.5079333337e+01,
lng: 1.3760000000e+02,
content:'Saddle = 651.700012 pos = 35.0793,137.6000 diff = 233.700012'
});
data_peak.push({
lat: 3.5139111115e+01,
lng: 1.3765533333e+02,
cert : true,
content:'Name = JA/AC-010(JA/AC-010) peak = 953.099976 pos = 35.1391,137.6553 diff = 292.699951'
});
data_saddle.push({
lat: 3.5150111115e+01,
lng: 1.3764888889e+02,
content:'Saddle = 660.400024 pos = 35.1501,137.6489 diff = 292.699951'
});
data_peak.push({
lat: 3.5980555556e+01,
lng: 1.3886600000e+02,
cert : false,
content:' Peak = 1463.500000 pos = 35.9806,138.8660 diff = 796.200012'
});
data_saddle.push({
lat: 3.5998666667e+01,
lng: 1.3882688889e+02,
content:'Saddle = 667.299988 pos = 35.9987,138.8269 diff = 796.200012'
});
data_peak.push({
lat: 3.5650222224e+01,
lng: 1.3728266667e+02,
cert : true,
content:'Name = JA/GF-134(JA/GF-134) peak = 943.799988 pos = 35.6502,137.2827 diff = 275.200012'
});
data_saddle.push({
lat: 3.5669444446e+01,
lng: 1.3730633333e+02,
content:'Saddle = 668.599976 pos = 35.6694,137.3063 diff = 275.200012'
});
data_peak.push({
lat: 3.5619888890e+01,
lng: 1.3722866667e+02,
cert : true,
content:'Name = JA/GF-151(JA/GF-151) peak = 861.900024 pos = 35.6199,137.2287 diff = 169.200012'
});
data_saddle.push({
lat: 3.5634888890e+01,
lng: 1.3724433333e+02,
content:'Saddle = 692.700012 pos = 35.6349,137.2443 diff = 169.200012'
});
data_peak.push({
lat: 3.5250444447e+01,
lng: 1.3751700000e+02,
cert : false,
content:' Peak = 830.599976 pos = 35.2504,137.5170 diff = 154.000000'
});
data_saddle.push({
lat: 3.5223777781e+01,
lng: 1.3753622222e+02,
content:'Saddle = 676.599976 pos = 35.2238,137.5362 diff = 154.000000'
});
data_peak.push({
lat: 3.5586444446e+01,
lng: 1.3906700000e+02,
cert : true,
content:'Name = JA/YN-065(JA/YN-065) peak = 860.099976 pos = 35.5864,139.0670 diff = 183.099976'
});
data_saddle.push({
lat: 3.5584444446e+01,
lng: 1.3906055556e+02,
content:'Saddle = 677.000000 pos = 35.5844,139.0606 diff = 183.099976'
});
data_peak.push({
lat: 3.5217111114e+01,
lng: 1.3746288889e+02,
cert : false,
content:' Peak = 864.700012 pos = 35.2171,137.4629 diff = 186.299988'
});
data_saddle.push({
lat: 3.5194888892e+01,
lng: 1.3746211111e+02,
content:'Saddle = 678.400024 pos = 35.1949,137.4621 diff = 186.299988'
});
data_peak.push({
lat: 3.5105222226e+01,
lng: 1.3760633333e+02,
cert : true,
content:'Name = JA/AC-007(JA/AC-007) peak = 1011.000000 pos = 35.1052,137.6063 diff = 332.000000'
});
data_saddle.push({
lat: 3.5154444448e+01,
lng: 1.3761222222e+02,
content:'Saddle = 679.000000 pos = 35.1544,137.6122 diff = 332.000000'
});
data_peak.push({
lat: 3.5140888892e+01,
lng: 1.3762666667e+02,
cert : true,
content:'Name = JA/AC-014(JA/AC-014) peak = 864.700012 pos = 35.1409,137.6267 diff = 156.799988'
});
data_saddle.push({
lat: 3.5131888892e+01,
lng: 1.3760977778e+02,
content:'Saddle = 707.900024 pos = 35.1319,137.6098 diff = 156.799988'
});
data_peak.push({
lat: 3.5794666667e+01,
lng: 1.3833644444e+02,
cert : false,
content:' Peak = 890.599976 pos = 35.7947,138.3364 diff = 205.299988'
});
data_saddle.push({
lat: 3.5796777779e+01,
lng: 1.3831733333e+02,
content:'Saddle = 685.299988 pos = 35.7968,138.3173 diff = 205.299988'
});
data_peak.push({
lat: 3.5652222224e+01,
lng: 1.3916644444e+02,
cert : false,
content:' Peak = 853.900024 pos = 35.6522,139.1664 diff = 162.600037'
});
data_saddle.push({
lat: 3.5657777779e+01,
lng: 1.3916811111e+02,
content:'Saddle = 691.299988 pos = 35.6578,139.1681 diff = 162.600037'
});
data_peak.push({
lat: 3.5152666670e+01,
lng: 1.3749488889e+02,
cert : true,
content:'Name = Takanosuyama(JA/AC-003) peak = 1152.099976 pos = 35.1527,137.4949 diff = 457.199951'
});
data_saddle.push({
lat: 3.5128888892e+01,
lng: 1.3756111111e+02,
content:'Saddle = 694.900024 pos = 35.1289,137.5611 diff = 457.199951'
});
data_peak.push({
lat: 3.5136222226e+01,
lng: 1.3744377778e+02,
cert : true,
content:'Name = JA/AC-004(JA/AC-004) peak = 1126.099976 pos = 35.1362,137.4438 diff = 188.099976'
});
data_saddle.push({
lat: 3.5116000004e+01,
lng: 1.3748200000e+02,
content:'Saddle = 938.000000 pos = 35.1160,137.4820 diff = 188.099976'
});
data_peak.push({
lat: 3.5707888890e+01,
lng: 1.3734166667e+02,
cert : false,
content:' Peak = 1144.300049 pos = 35.7079,137.3417 diff = 449.100037'
});
data_saddle.push({
lat: 3.5749888890e+01,
lng: 1.3732922222e+02,
content:'Saddle = 695.200012 pos = 35.7499,137.3292 diff = 449.100037'
});
data_peak.push({
lat: 3.5760666668e+01,
lng: 1.3727666667e+02,
cert : false,
content:' Peak = 881.500000 pos = 35.7607,137.2767 diff = 173.500000'
});
data_saddle.push({
lat: 3.5754222223e+01,
lng: 1.3727955556e+02,
content:'Saddle = 708.000000 pos = 35.7542,137.2796 diff = 173.500000'
});
data_peak.push({
lat: 3.5399777780e+01,
lng: 1.3900311111e+02,
cert : true,
content:'Name = Furousan(JA/KN-015) peak = 927.500000 pos = 35.3998,139.0031 diff = 220.099976'
});
data_saddle.push({
lat: 3.5403444447e+01,
lng: 1.3899333333e+02,
content:'Saddle = 707.400024 pos = 35.4034,138.9933 diff = 220.099976'
});
data_peak.push({
lat: 3.5576555557e+01,
lng: 1.3895111111e+02,
cert : true,
content:'Name = JA/YN-063(JA/YN-063) peak = 968.099976 pos = 35.5766,138.9511 diff = 250.599976'
});
data_saddle.push({
lat: 3.5577111113e+01,
lng: 1.3898366667e+02,
content:'Saddle = 717.500000 pos = 35.5771,138.9837 diff = 250.599976'
});
data_peak.push({
lat: 3.5177555559e+01,
lng: 1.3847800000e+02,
cert : true,
content:'Name = JA/SO-053(JA/SO-053) peak = 943.900024 pos = 35.1776,138.4780 diff = 222.700012'
});
data_saddle.push({
lat: 3.5178444448e+01,
lng: 1.3846411111e+02,
content:'Saddle = 721.200012 pos = 35.1784,138.4641 diff = 222.700012'
});
data_peak.push({
lat: 3.4998333337e+01,
lng: 1.3811566667e+02,
cert : false,
content:' Peak = 874.799988 pos = 34.9983,138.1157 diff = 152.700012'
});
data_saddle.push({
lat: 3.5040777782e+01,
lng: 1.3813944444e+02,
content:'Saddle = 722.099976 pos = 35.0408,138.1394 diff = 152.700012'
});
data_peak.push({
lat: 3.5893111112e+01,
lng: 1.3748044444e+02,
cert : true,
content:'Name = Ontakesan (Kengamine)(JA/NN-005) peak = 3064.300049 pos = 35.8931,137.4804 diff = 2331.399902'
});
data_saddle.push({
lat: 3.5999666667e+01,
lng: 1.3800688889e+02,
content:'Saddle = 732.900024 pos = 35.9997,138.0069 diff = 2331.399902'
});
data_peak.push({
lat: 3.6000000000e+01,
lng: 1.3799255556e+02,
cert : false,
content:' Peak = 1141.400024 pos = 36.0000,137.9926 diff = 394.200012'
});
data_saddle.push({
lat: 3.5999888889e+01,
lng: 1.3797766667e+02,
content:'Saddle = 747.200012 pos = 35.9999,137.9777 diff = 394.200012'
});
data_peak.push({
lat: 3.5160222226e+01,
lng: 1.3765133333e+02,
cert : false,
content:' Peak = 967.500000 pos = 35.1602,137.6513 diff = 213.900024'
});
data_saddle.push({
lat: 3.5168333337e+01,
lng: 1.3764600000e+02,
content:'Saddle = 753.599976 pos = 35.1683,137.6460 diff = 213.900024'
});
data_peak.push({
lat: 3.5113333337e+01,
lng: 1.3777622222e+02,
cert : true,
content:'Name = JA/AC-012(JA/AC-012) peak = 921.700012 pos = 35.1133,137.7762 diff = 158.400024'
});
data_saddle.push({
lat: 3.5141111115e+01,
lng: 1.3777022222e+02,
content:'Saddle = 763.299988 pos = 35.1411,137.7702 diff = 158.400024'
});
data_peak.push({
lat: 3.5551555557e+01,
lng: 1.3757144444e+02,
cert : true,
content:'Name = JA/NN-180(JA/NN-180) peak = 1031.800049 pos = 35.5516,137.5714 diff = 244.900024'
});
data_saddle.push({
lat: 3.5538555557e+01,
lng: 1.3758444444e+02,
content:'Saddle = 786.900024 pos = 35.5386,137.5844 diff = 244.900024'
});
data_peak.push({
lat: 3.5271666670e+01,
lng: 1.3777211111e+02,
cert : true,
content:'Name = JA/NN-174(JA/NN-174) peak = 1131.099976 pos = 35.2717,137.7721 diff = 313.399963'
});
data_saddle.push({
lat: 3.5273000003e+01,
lng: 1.3776044444e+02,
content:'Saddle = 817.700012 pos = 35.2730,137.7604 diff = 313.399963'
});
data_peak.push({
lat: 3.5654888890e+01,
lng: 1.3763511111e+02,
cert : true,
content:'Name = JA/NN-176(JA/NN-176) peak = 1100.199951 pos = 35.6549,137.6351 diff = 262.999939'
});
data_saddle.push({
lat: 3.5653333335e+01,
lng: 1.3765522222e+02,
content:'Saddle = 837.200012 pos = 35.6533,137.6552 diff = 262.999939'
});
data_peak.push({
lat: 3.5153111114e+01,
lng: 1.3776688889e+02,
cert : true,
content:'Name = JA/AC-005(JA/AC-005) peak = 1108.699951 pos = 35.1531,137.7669 diff = 215.599976'
});
data_saddle.push({
lat: 3.5169222226e+01,
lng: 1.3775811111e+02,
content:'Saddle = 893.099976 pos = 35.1692,137.7581 diff = 215.599976'
});
data_peak.push({
lat: 3.6000000000e+01,
lng: 1.3730477778e+02,
cert : false,
content:' Peak = 1145.900024 pos = 36.0000,137.3048 diff = 250.200012'
});
data_saddle.push({
lat: 3.6000000000e+01,
lng: 1.3731522222e+02,
content:'Saddle = 895.700012 pos = 36.0000,137.3152 diff = 250.200012'
});
data_peak.push({
lat: 3.5164111114e+01,
lng: 1.3759544444e+02,
cert : false,
content:' Peak = 1054.199951 pos = 35.1641,137.5954 diff = 151.999939'
});
data_saddle.push({
lat: 3.5166222226e+01,
lng: 1.3758944444e+02,
content:'Saddle = 902.200012 pos = 35.1662,137.5894 diff = 151.999939'
});
data_peak.push({
lat: 3.5190444448e+01,
lng: 1.3758088889e+02,
cert : false,
content:' Peak = 1238.500000 pos = 35.1904,137.5809 diff = 331.000000'
});
data_saddle.push({
lat: 3.5190666670e+01,
lng: 1.3760644444e+02,
content:'Saddle = 907.500000 pos = 35.1907,137.6064 diff = 331.000000'
});
data_peak.push({
lat: 3.5422777780e+01,
lng: 1.3772300000e+02,
cert : false,
content:' Peak = 1071.099976 pos = 35.4228,137.7230 diff = 163.299988'
});
data_saddle.push({
lat: 3.5419888891e+01,
lng: 1.3771944444e+02,
content:'Saddle = 907.799988 pos = 35.4199,137.7194 diff = 163.299988'
});
data_peak.push({
lat: 3.5225666670e+01,
lng: 1.3778788889e+02,
cert : true,
content:'Name = JA/NN-168(JA/NN-168) peak = 1204.800049 pos = 35.2257,137.7879 diff = 246.900024'
});
data_saddle.push({
lat: 3.5222333336e+01,
lng: 1.3773177778e+02,
content:'Saddle = 957.900024 pos = 35.2223,137.7318 diff = 246.900024'
});
data_peak.push({
lat: 3.5321111114e+01,
lng: 1.3760600000e+02,
cert : false,
content:' Peak = 1271.000000 pos = 35.3211,137.6060 diff = 293.700012'
});
data_saddle.push({
lat: 3.5305333336e+01,
lng: 1.3762211111e+02,
content:'Saddle = 977.299988 pos = 35.3053,137.6221 diff = 293.700012'
});
data_peak.push({
lat: 3.5449555558e+01,
lng: 1.3769633333e+02,
cert : false,
content:' Peak = 1135.199951 pos = 35.4496,137.6963 diff = 153.399963'
});
data_saddle.push({
lat: 3.5445222224e+01,
lng: 1.3769588889e+02,
content:'Saddle = 981.799988 pos = 35.4452,137.6959 diff = 153.399963'
});
data_peak.push({
lat: 3.5208888892e+01,
lng: 1.3761511111e+02,
cert : false,
content:' Peak = 1160.500000 pos = 35.2089,137.6151 diff = 153.799988'
});
data_saddle.push({
lat: 3.5198333337e+01,
lng: 1.3761988889e+02,
content:'Saddle = 1006.700012 pos = 35.1983,137.6199 diff = 153.799988'
});
data_peak.push({
lat: 3.5285444447e+01,
lng: 1.3760744444e+02,
cert : false,
content:' Peak = 1181.400024 pos = 35.2854,137.6074 diff = 153.300049'
});
data_saddle.push({
lat: 3.5279222225e+01,
lng: 1.3761333333e+02,
content:'Saddle = 1028.099976 pos = 35.2792,137.6133 diff = 153.300049'
});
data_peak.push({
lat: 3.5941666667e+01,
lng: 1.3777122222e+02,
cert : true,
content:'Name = JA/NN-152(JA/NN-152) peak = 1316.900024 pos = 35.9417,137.7712 diff = 257.599976'
});
data_saddle.push({
lat: 3.5963333333e+01,
lng: 1.3775100000e+02,
content:'Saddle = 1059.300049 pos = 35.9633,137.7510 diff = 257.599976'
});
data_peak.push({
lat: 3.5470777780e+01,
lng: 1.3768033333e+02,
cert : true,
content:'Name = JA/NN-151(JA/NN-151) peak = 1314.199951 pos = 35.4708,137.6803 diff = 235.899902'
});
data_saddle.push({
lat: 3.5492666669e+01,
lng: 1.3767533333e+02,
content:'Saddle = 1078.300049 pos = 35.4927,137.6753 diff = 235.899902'
});
data_peak.push({
lat: 3.5393000002e+01,
lng: 1.3770522222e+02,
cert : false,
content:' Peak = 1450.599976 pos = 35.3930,137.7052 diff = 363.400024'
});
data_saddle.push({
lat: 3.5399222225e+01,
lng: 1.3768877778e+02,
content:'Saddle = 1087.199951 pos = 35.3992,137.6888 diff = 363.400024'
});
data_peak.push({
lat: 3.5613444446e+01,
lng: 1.3758344444e+02,
cert : false,
content:' Peak = 1372.699951 pos = 35.6134,137.5834 diff = 261.000000'
});
data_saddle.push({
lat: 3.5622555557e+01,
lng: 1.3757666667e+02,
content:'Saddle = 1111.699951 pos = 35.6226,137.5767 diff = 261.000000'
});
data_peak.push({
lat: 3.5791888890e+01,
lng: 1.3766266667e+02,
cert : true,
content:'Name = JA/NN-121(JA/NN-121) peak = 1501.500000 pos = 35.7919,137.6627 diff = 388.599976'
});
data_saddle.push({
lat: 3.5796888890e+01,
lng: 1.3762955556e+02,
content:'Saddle = 1112.900024 pos = 35.7969,137.6296 diff = 388.599976'
});
data_peak.push({
lat: 3.5789666668e+01,
lng: 1.3780466667e+02,
cert : true,
content:'Name = Komagatake(JA/NN-006) peak = 2954.199951 pos = 35.7897,137.8047 diff = 1826.799927'
});
data_saddle.push({
lat: 3.5976444445e+01,
lng: 1.3776800000e+02,
content:'Saddle = 1127.400024 pos = 35.9764,137.7680 diff = 1826.799927'
});
data_peak.push({
lat: 3.5275888892e+01,
lng: 1.3762555556e+02,
cert : false,
content:' Peak = 1321.300049 pos = 35.2759,137.6256 diff = 174.600098'
});
data_saddle.push({
lat: 3.5271777781e+01,
lng: 1.3764644444e+02,
content:'Saddle = 1146.699951 pos = 35.2718,137.6464 diff = 174.600098'
});
data_peak.push({
lat: 3.5501666669e+01,
lng: 1.3773922222e+02,
cert : true,
content:'Name = JA/NN-138(JA/NN-138) peak = 1391.400024 pos = 35.5017,137.7392 diff = 235.099976'
});
data_saddle.push({
lat: 3.5510888891e+01,
lng: 1.3774566667e+02,
content:'Saddle = 1156.300049 pos = 35.5109,137.7457 diff = 235.099976'
});
data_peak.push({
lat: 3.5227666670e+01,
lng: 1.3765544444e+02,
cert : true,
content:'Name = Chausuyama(JA/AC-001) peak = 1414.400024 pos = 35.2277,137.6554 diff = 249.099976'
});
data_saddle.push({
lat: 3.5234111114e+01,
lng: 1.3766811111e+02,
content:'Saddle = 1165.300049 pos = 35.2341,137.6681 diff = 249.099976'
});
data_peak.push({
lat: 3.5533555557e+01,
lng: 1.3760700000e+02,
cert : false,
content:' Peak = 1341.900024 pos = 35.5336,137.6070 diff = 170.400024'
});
data_saddle.push({
lat: 3.5531444446e+01,
lng: 1.3760944444e+02,
content:'Saddle = 1171.500000 pos = 35.5314,137.6094 diff = 170.400024'
});
data_peak.push({
lat: 3.5592555557e+01,
lng: 1.3764422222e+02,
cert : true,
content:'Name = Nagisodake(JA/NN-099) peak = 1677.900024 pos = 35.5926,137.6442 diff = 505.400024'
});
data_saddle.push({
lat: 3.5595000002e+01,
lng: 1.3767622222e+02,
content:'Saddle = 1172.500000 pos = 35.5950,137.6762 diff = 505.400024'
});
data_peak.push({
lat: 3.5443222224e+01,
lng: 1.3759766667e+02,
cert : true,
content:'Name = Enasan(JA/NN-053) peak = 2190.600098 pos = 35.4432,137.5977 diff = 1003.000122'
});
data_saddle.push({
lat: 3.5532666669e+01,
lng: 1.3766433333e+02,
content:'Saddle = 1187.599976 pos = 35.5327,137.6643 diff = 1003.000122'
});
data_peak.push({
lat: 3.5341444447e+01,
lng: 1.3768811111e+02,
cert : false,
content:' Peak = 1663.099976 pos = 35.3414,137.6881 diff = 466.699951'
});
data_saddle.push({
lat: 3.5349666669e+01,
lng: 1.3766533333e+02,
content:'Saddle = 1196.400024 pos = 35.3497,137.6653 diff = 466.699951'
});
data_peak.push({
lat: 3.5317444447e+01,
lng: 1.3767422222e+02,
cert : false,
content:' Peak = 1463.800049 pos = 35.3174,137.6742 diff = 216.200073'
});
data_saddle.push({
lat: 3.5326555558e+01,
lng: 1.3767666667e+02,
content:'Saddle = 1247.599976 pos = 35.3266,137.6767 diff = 216.200073'
});
data_peak.push({
lat: 3.5415888891e+01,
lng: 1.3767877778e+02,
cert : false,
content:' Peak = 1460.900024 pos = 35.4159,137.6788 diff = 226.300049'
});
data_saddle.push({
lat: 3.5419333336e+01,
lng: 1.3766900000e+02,
content:'Saddle = 1234.599976 pos = 35.4193,137.6690 diff = 226.300049'
});
data_peak.push({
lat: 3.5403888891e+01,
lng: 1.3756411111e+02,
cert : true,
content:'Name = JA/GF-022(JA/GF-022) peak = 1708.099976 pos = 35.4039,137.5641 diff = 298.900024'
});
data_saddle.push({
lat: 3.5395000002e+01,
lng: 1.3758822222e+02,
content:'Saddle = 1409.199951 pos = 35.3950,137.5882 diff = 298.900024'
});
data_peak.push({
lat: 3.5483111113e+01,
lng: 1.3762955556e+02,
cert : true,
content:'Name = JA/NN-092(JA/NN-092) peak = 1738.000000 pos = 35.4831,137.6296 diff = 190.199951'
});
data_saddle.push({
lat: 3.5468222224e+01,
lng: 1.3762055556e+02,
content:'Saddle = 1547.800049 pos = 35.4682,137.6206 diff = 190.199951'
});
data_peak.push({
lat: 3.5398333336e+01,
lng: 1.3763388889e+02,
cert : true,
content:'Name = JA/NN-074(JA/NN-074) peak = 1940.699951 pos = 35.3983,137.6339 diff = 273.799927'
});
data_saddle.push({
lat: 3.5420111113e+01,
lng: 1.3761811111e+02,
content:'Saddle = 1666.900024 pos = 35.4201,137.6181 diff = 273.799927'
});
data_peak.push({
lat: 3.6000000000e+01,
lng: 1.3778977778e+02,
cert : false,
content:' Peak = 1613.699951 pos = 36.0000,137.7898 diff = 421.299927'
});
data_saddle.push({
lat: 3.6000000000e+01,
lng: 1.3779877778e+02,
content:'Saddle = 1192.400024 pos = 36.0000,137.7988 diff = 421.299927'
});
data_peak.push({
lat: 3.5998555556e+01,
lng: 1.3780866667e+02,
cert : false,
content:' Peak = 1570.400024 pos = 35.9986,137.8087 diff = 362.800049'
});
data_saddle.push({
lat: 3.5951888889e+01,
lng: 1.3779677778e+02,
content:'Saddle = 1207.599976 pos = 35.9519,137.7968 diff = 362.800049'
});
data_peak.push({
lat: 3.5542333335e+01,
lng: 1.3774033333e+02,
cert : true,
content:'Name = JA/NN-122(JA/NN-122) peak = 1491.900024 pos = 35.5423,137.7403 diff = 253.599976'
});
data_saddle.push({
lat: 3.5553000002e+01,
lng: 1.3773533333e+02,
content:'Saddle = 1238.300049 pos = 35.5530,137.7353 diff = 253.599976'
});
data_peak.push({
lat: 3.5549555557e+01,
lng: 1.3778377778e+02,
cert : true,
content:'Name = Kazakoshiyama (Gongenyama)(JA/NN-119) peak = 1534.699951 pos = 35.5496,137.7838 diff = 293.500000'
});
data_saddle.push({
lat: 3.5586333335e+01,
lng: 1.3779844444e+02,
content:'Saddle = 1241.199951 pos = 35.5863,137.7984 diff = 293.500000'
});
data_peak.push({
lat: 3.5820888890e+01,
lng: 1.3772044444e+02,
cert : true,
content:'Name = JA/NN-132(JA/NN-132) peak = 1451.900024 pos = 35.8209,137.7204 diff = 209.200073'
});
data_saddle.push({
lat: 3.5819333334e+01,
lng: 1.3773633333e+02,
content:'Saddle = 1242.699951 pos = 35.8193,137.7363 diff = 209.200073'
});
data_peak.push({
lat: 3.5916000000e+01,
lng: 1.3780566667e+02,
cert : true,
content:'Name = JA/NN-123(JA/NN-123) peak = 1491.500000 pos = 35.9160,137.8057 diff = 204.599976'
});
data_saddle.push({
lat: 3.5905888889e+01,
lng: 1.3780444444e+02,
content:'Saddle = 1286.900024 pos = 35.9059,137.8044 diff = 204.599976'
});
data_peak.push({
lat: 3.5533222224e+01,
lng: 1.3767744444e+02,
cert : false,
content:' Peak = 1473.000000 pos = 35.5332,137.6774 diff = 175.099976'
});
data_saddle.push({
lat: 3.5544888891e+01,
lng: 1.3768655556e+02,
content:'Saddle = 1297.900024 pos = 35.5449,137.6866 diff = 175.099976'
});
data_peak.push({
lat: 3.5552777780e+01,
lng: 1.3770411111e+02,
cert : true,
content:'Name = JA/NN-111(JA/NN-111) peak = 1635.099976 pos = 35.5528,137.7041 diff = 283.000000'
});
data_saddle.push({
lat: 3.5559111113e+01,
lng: 1.3769500000e+02,
content:'Saddle = 1352.099976 pos = 35.5591,137.6950 diff = 283.000000'
});
data_peak.push({
lat: 3.5912888889e+01,
lng: 1.3786255556e+02,
cert : true,
content:'Name = Kyougatake(JA/NN-046) peak = 2292.500000 pos = 35.9129,137.8626 diff = 769.800049'
});
data_saddle.push({
lat: 3.5872444445e+01,
lng: 1.3785688889e+02,
content:'Saddle = 1522.699951 pos = 35.8724,137.8569 diff = 769.800049'
});
data_peak.push({
lat: 3.5938222222e+01,
lng: 1.3782877778e+02,
cert : false,
content:' Peak = 1960.500000 pos = 35.9382,137.8288 diff = 198.400024'
});
data_saddle.push({
lat: 3.5929666667e+01,
lng: 1.3783422222e+02,
content:'Saddle = 1762.099976 pos = 35.9297,137.8342 diff = 198.400024'
});
data_peak.push({
lat: 3.5708333335e+01,
lng: 1.3773377778e+02,
cert : true,
content:'Name = Itoseyama(JA/NN-082) peak = 1866.000000 pos = 35.7083,137.7338 diff = 329.699951'
});
data_saddle.push({
lat: 3.5722777779e+01,
lng: 1.3775077778e+02,
content:'Saddle = 1536.300049 pos = 35.7228,137.7508 diff = 329.699951'
});
data_peak.push({
lat: 3.5812222223e+01,
lng: 1.3777033333e+02,
cert : false,
content:' Peak = 2176.100098 pos = 35.8122,137.7703 diff = 152.200073'
});
data_saddle.push({
lat: 3.5809777779e+01,
lng: 1.3777344444e+02,
content:'Saddle = 2023.900024 pos = 35.8098,137.7734 diff = 152.200073'
});
data_peak.push({
lat: 3.5630444446e+01,
lng: 1.3777433333e+02,
cert : true,
content:'Name = Anpeijiyama(JA/NN-041) peak = 2362.600098 pos = 35.6304,137.7743 diff = 280.700195'
});
data_saddle.push({
lat: 3.5642444446e+01,
lng: 1.3778900000e+02,
content:'Saddle = 2081.899902 pos = 35.6424,137.7890 diff = 280.700195'
});
data_peak.push({
lat: 3.5848000001e+01,
lng: 1.3781000000e+02,
cert : true,
content:'Name = Oodanairiyama(JA/NN-039) peak = 2373.399902 pos = 35.8480,137.8100 diff = 260.199951'
});
data_saddle.push({
lat: 3.5838333334e+01,
lng: 1.3780766667e+02,
content:'Saddle = 2113.199951 pos = 35.8383,137.8077 diff = 260.199951'
});
data_peak.push({
lat: 3.5655333335e+01,
lng: 1.3782700000e+02,
cert : true,
content:'Name = JA/NN-044(JA/NN-044) peak = 2326.899902 pos = 35.6553,137.8270 diff = 204.099854'
});
data_saddle.push({
lat: 3.5651111113e+01,
lng: 1.3780733333e+02,
content:'Saddle = 2122.800049 pos = 35.6511,137.8073 diff = 204.099854'
});
data_peak.push({
lat: 3.5719000001e+01,
lng: 1.3781700000e+02,
cert : true,
content:'Name = Utsugidake(JA/NN-013) peak = 2862.000000 pos = 35.7190,137.8170 diff = 368.300049'
});
data_saddle.push({
lat: 3.5723333334e+01,
lng: 1.3780788889e+02,
content:'Saddle = 2493.699951 pos = 35.7233,137.8079 diff = 368.300049'
});
data_peak.push({
lat: 3.5739333334e+01,
lng: 1.3780322222e+02,
cert : true,
content:'Name = Kumazawadake(JA/NN-017) peak = 2775.500000 pos = 35.7393,137.8032 diff = 238.699951'
});
data_saddle.push({
lat: 3.5757222223e+01,
lng: 1.3781266667e+02,
content:'Saddle = 2536.800049 pos = 35.7572,137.8127 diff = 238.699951'
});
data_peak.push({
lat: 3.5766777779e+01,
lng: 1.3779400000e+02,
cert : false,
content:' Peak = 2845.600098 pos = 35.7668,137.7940 diff = 189.300049'
});
data_saddle.push({
lat: 3.5772111112e+01,
lng: 1.3779911111e+02,
content:'Saddle = 2656.300049 pos = 35.7721,137.7991 diff = 189.300049'
});
data_peak.push({
lat: 3.5883333334e+01,
lng: 1.3726844444e+02,
cert : true,
content:'Name = JA/GF-027(JA/GF-027) peak = 1652.500000 pos = 35.8833,137.2684 diff = 519.500000'
});
data_saddle.push({
lat: 3.5849777778e+01,
lng: 1.3726177778e+02,
content:'Saddle = 1133.000000 pos = 35.8498,137.2618 diff = 519.500000'
});
data_peak.push({
lat: 3.6000000000e+01,
lng: 1.3775733333e+02,
cert : false,
content:' Peak = 1681.500000 pos = 36.0000,137.7573 diff = 522.400024'
});
data_saddle.push({
lat: 3.6000000000e+01,
lng: 1.3773733333e+02,
content:'Saddle = 1159.099976 pos = 36.0000,137.7373 diff = 522.400024'
});
data_peak.push({
lat: 3.5941444445e+01,
lng: 1.3731222222e+02,
cert : false,
content:' Peak = 1364.500000 pos = 35.9414,137.3122 diff = 184.500000'
});
data_saddle.push({
lat: 3.5946222222e+01,
lng: 1.3730644444e+02,
content:'Saddle = 1180.000000 pos = 35.9462,137.3064 diff = 184.500000'
});
data_peak.push({
lat: 3.5837555556e+01,
lng: 1.3727755556e+02,
cert : true,
content:'Name = JA/GF-051(JA/GF-051) peak = 1410.199951 pos = 35.8376,137.2776 diff = 215.000000'
});
data_saddle.push({
lat: 3.5824444445e+01,
lng: 1.3728333333e+02,
content:'Saddle = 1195.199951 pos = 35.8244,137.2833 diff = 215.000000'
});
data_peak.push({
lat: 3.5977333333e+01,
lng: 1.3732088889e+02,
cert : false,
content:' Peak = 1462.599976 pos = 35.9773,137.3209 diff = 251.599976'
});
data_saddle.push({
lat: 3.5975111111e+01,
lng: 1.3735800000e+02,
content:'Saddle = 1211.000000 pos = 35.9751,137.3580 diff = 251.599976'
});
data_peak.push({
lat: 3.5778888890e+01,
lng: 1.3758044444e+02,
cert : false,
content:' Peak = 1463.000000 pos = 35.7789,137.5804 diff = 211.099976'
});
data_saddle.push({
lat: 3.5777111112e+01,
lng: 1.3758822222e+02,
content:'Saddle = 1251.900024 pos = 35.7771,137.5882 diff = 211.099976'
});
data_peak.push({
lat: 3.5732888890e+01,
lng: 1.3740700000e+02,
cert : true,
content:'Name = JA/GF-034(JA/GF-034) peak = 1562.099976 pos = 35.7329,137.4070 diff = 300.599976'
});
data_saddle.push({
lat: 3.5733333334e+01,
lng: 1.3739477778e+02,
content:'Saddle = 1261.500000 pos = 35.7333,137.3948 diff = 300.599976'
});
data_peak.push({
lat: 3.5751444445e+01,
lng: 1.3765411111e+02,
cert : true,
content:'Name = JA/NN-126(JA/NN-126) peak = 1473.800049 pos = 35.7514,137.6541 diff = 172.200073'
});
data_saddle.push({
lat: 3.5721444446e+01,
lng: 1.3764866667e+02,
content:'Saddle = 1301.599976 pos = 35.7214,137.6487 diff = 172.200073'
});
data_peak.push({
lat: 3.5977111111e+01,
lng: 1.3769722222e+02,
cert : false,
content:' Peak = 2043.900024 pos = 35.9771,137.6972 diff = 733.000000'
});
data_saddle.push({
lat: 3.6000000000e+01,
lng: 1.3764977778e+02,
content:'Saddle = 1310.900024 pos = 36.0000,137.6498 diff = 733.000000'
});
data_peak.push({
lat: 3.6000000000e+01,
lng: 1.3767177778e+02,
cert : false,
content:' Peak = 1777.400024 pos = 36.0000,137.6718 diff = 290.500000'
});
data_saddle.push({
lat: 3.6000000000e+01,
lng: 1.3768277778e+02,
content:'Saddle = 1486.900024 pos = 36.0000,137.6828 diff = 290.500000'
});
data_peak.push({
lat: 3.5996000000e+01,
lng: 1.3769777778e+02,
cert : false,
content:' Peak = 1983.699951 pos = 35.9960,137.6978 diff = 214.500000'
});
data_saddle.push({
lat: 3.5990666667e+01,
lng: 1.3769900000e+02,
content:'Saddle = 1769.199951 pos = 35.9907,137.6990 diff = 214.500000'
});
data_peak.push({
lat: 3.5987222222e+01,
lng: 1.3761755556e+02,
cert : false,
content:' Peak = 1831.800049 pos = 35.9872,137.6176 diff = 474.900024'
});
data_saddle.push({
lat: 3.5971777778e+01,
lng: 1.3754355556e+02,
content:'Saddle = 1356.900024 pos = 35.9718,137.5436 diff = 474.900024'
});
data_peak.push({
lat: 3.5995333333e+01,
lng: 1.3757600000e+02,
cert : false,
content:' Peak = 1772.099976 pos = 35.9953,137.5760 diff = 400.699951'
});
data_saddle.push({
lat: 3.6000000000e+01,
lng: 1.3759922222e+02,
content:'Saddle = 1371.400024 pos = 36.0000,137.5992 diff = 400.699951'
});
data_peak.push({
lat: 3.6000000000e+01,
lng: 1.3760411111e+02,
cert : false,
content:' Peak = 1611.500000 pos = 36.0000,137.6041 diff = 191.599976'
});
data_saddle.push({
lat: 3.6000000000e+01,
lng: 1.3760977778e+02,
content:'Saddle = 1419.900024 pos = 36.0000,137.6098 diff = 191.599976'
});
data_peak.push({
lat: 3.5716333334e+01,
lng: 1.3759300000e+02,
cert : true,
content:'Name = JA/NN-118(JA/NN-118) peak = 1556.800049 pos = 35.7163,137.5930 diff = 190.800049'
});
data_saddle.push({
lat: 3.5737000001e+01,
lng: 1.3758077778e+02,
content:'Saddle = 1366.000000 pos = 35.7370,137.5808 diff = 190.800049'
});
data_peak.push({
lat: 3.5852888889e+01,
lng: 1.3757277778e+02,
cert : true,
content:'Name = JA/NN-117(JA/NN-117) peak = 1554.400024 pos = 35.8529,137.5728 diff = 186.400024'
});
data_saddle.push({
lat: 3.5860333334e+01,
lng: 1.3755333333e+02,
content:'Saddle = 1368.000000 pos = 35.8603,137.5533 diff = 186.400024'
});
data_peak.push({
lat: 3.5785444445e+01,
lng: 1.3739688889e+02,
cert : true,
content:'Name = Kohideyama(JA/NN-070) peak = 1981.000000 pos = 35.7854,137.3969 diff = 609.900024'
});
data_saddle.push({
lat: 3.5842555556e+01,
lng: 1.3734866667e+02,
content:'Saddle = 1371.099976 pos = 35.8426,137.3487 diff = 609.900024'
});
data_peak.push({
lat: 3.5713444446e+01,
lng: 1.3748711111e+02,
cert : true,
content:'Name = JA/NN-085(JA/NN-085) peak = 1842.199951 pos = 35.7134,137.4871 diff = 459.199951'
});
data_saddle.push({
lat: 3.5774777779e+01,
lng: 1.3741722222e+02,
content:'Saddle = 1383.000000 pos = 35.7748,137.4172 diff = 459.199951'
});
data_peak.push({
lat: 3.5794222223e+01,
lng: 1.3746244444e+02,
cert : true,
content:'Name = JA/NN-105(JA/NN-105) peak = 1654.900024 pos = 35.7942,137.4624 diff = 230.000000'
});
data_saddle.push({
lat: 3.5784333334e+01,
lng: 1.3744966667e+02,
content:'Saddle = 1424.900024 pos = 35.7843,137.4497 diff = 230.000000'
});
data_peak.push({
lat: 3.5771777779e+01,
lng: 1.3747855556e+02,
cert : false,
content:' Peak = 1700.599976 pos = 35.7718,137.4786 diff = 218.699951'
});
data_saddle.push({
lat: 3.5752333334e+01,
lng: 1.3746500000e+02,
content:'Saddle = 1481.900024 pos = 35.7523,137.4650 diff = 218.699951'
});
data_peak.push({
lat: 3.5765777779e+01,
lng: 1.3743477778e+02,
cert : true,
content:'Name = JA/NN-097(JA/NN-097) peak = 1691.000000 pos = 35.7658,137.4348 diff = 152.500000'
});
data_saddle.push({
lat: 3.5758333334e+01,
lng: 1.3744288889e+02,
content:'Saddle = 1538.500000 pos = 35.7583,137.4429 diff = 152.500000'
});
data_peak.push({
lat: 3.5754333334e+01,
lng: 1.3753355556e+02,
cert : true,
content:'Name = JA/NN-095(JA/NN-095) peak = 1714.800049 pos = 35.7543,137.5336 diff = 226.800049'
});
data_saddle.push({
lat: 3.5730333334e+01,
lng: 1.3754400000e+02,
content:'Saddle = 1488.000000 pos = 35.7303,137.5440 diff = 226.800049'
});
data_peak.push({
lat: 3.5681666668e+01,
lng: 1.3750711111e+02,
cert : true,
content:'Name = Okusangaidake(JA/GF-016) peak = 1811.300049 pos = 35.6817,137.5071 diff = 209.000000'
});
data_saddle.push({
lat: 3.5698555557e+01,
lng: 1.3749600000e+02,
content:'Saddle = 1602.300049 pos = 35.6986,137.4960 diff = 209.000000'
});
data_peak.push({
lat: 3.5726666668e+01,
lng: 1.3747888889e+02,
cert : true,
content:'Name = JA/GF-015(JA/GF-015) peak = 1822.099976 pos = 35.7267,137.4789 diff = 153.799927'
});
data_saddle.push({
lat: 3.5722333334e+01,
lng: 1.3748611111e+02,
content:'Saddle = 1668.300049 pos = 35.7223,137.4861 diff = 153.799927'
});
data_peak.push({
lat: 3.5808444445e+01,
lng: 1.3733244444e+02,
cert : false,
content:' Peak = 1662.500000 pos = 35.8084,137.3324 diff = 231.199951'
});
data_saddle.push({
lat: 3.5801222223e+01,
lng: 1.3735388889e+02,
content:'Saddle = 1431.300049 pos = 35.8012,137.3539 diff = 231.199951'
});
data_peak.push({
lat: 3.5956222222e+01,
lng: 1.3736711111e+02,
cert : false,
content:' Peak = 1590.400024 pos = 35.9562,137.3671 diff = 162.800049'
});
data_saddle.push({
lat: 3.5948111111e+01,
lng: 1.3737800000e+02,
content:'Saddle = 1427.599976 pos = 35.9481,137.3780 diff = 162.800049'
});
data_peak.push({
lat: 3.5961222222e+01,
lng: 1.3739911111e+02,
cert : true,
content:'Name = JA/GF-028(JA/GF-028) peak = 1633.500000 pos = 35.9612,137.3991 diff = 198.500000'
});
data_saddle.push({
lat: 3.5968777778e+01,
lng: 1.3741488889e+02,
content:'Saddle = 1435.000000 pos = 35.9688,137.4149 diff = 198.500000'
});
data_peak.push({
lat: 3.5936777778e+01,
lng: 1.3742144444e+02,
cert : false,
content:' Peak = 1798.400024 pos = 35.9368,137.4214 diff = 164.500000'
});
data_saddle.push({
lat: 3.5929000000e+01,
lng: 1.3743355556e+02,
content:'Saddle = 1633.900024 pos = 35.9290,137.4336 diff = 164.500000'
});
data_peak.push({
lat: 3.5430666669e+01,
lng: 1.3902522222e+02,
cert : true,
content:'Name = Gongenyama(JA/KN-012) peak = 1017.700012 pos = 35.4307,139.0252 diff = 269.799988'
});
data_saddle.push({
lat: 3.5439000002e+01,
lng: 1.3902544444e+02,
content:'Saddle = 747.900024 pos = 35.4390,139.0254 diff = 269.799988'
});
data_peak.push({
lat: 3.5440888891e+01,
lng: 1.3923111111e+02,
cert : true,
content:'Name = Ooyama(JA/KN-006) peak = 1251.800049 pos = 35.4409,139.2311 diff = 500.500061'
});
data_saddle.push({
lat: 3.5427333336e+01,
lng: 1.3920788889e+02,
content:'Saddle = 751.299988 pos = 35.4273,139.2079 diff = 500.500061'
});
data_peak.push({
lat: 3.5133111115e+01,
lng: 1.3782700000e+02,
cert : true,
content:'Name = JA/SO-052(JA/SO-052) peak = 954.299988 pos = 35.1331,137.8270 diff = 202.700012'
});
data_saddle.push({
lat: 3.5142888892e+01,
lng: 1.3783677778e+02,
content:'Saddle = 751.599976 pos = 35.1429,137.8368 diff = 202.700012'
});
data_peak.push({
lat: 3.5121222226e+01,
lng: 1.3781388889e+02,
cert : false,
content:' Peak = 924.799988 pos = 35.1212,137.8139 diff = 162.899963'
});
data_saddle.push({
lat: 3.5128666670e+01,
lng: 1.3782177778e+02,
content:'Saddle = 761.900024 pos = 35.1287,137.8218 diff = 162.899963'
});
data_peak.push({
lat: 3.5638111113e+01,
lng: 1.3898100000e+02,
cert : true,
content:'Name = JA/YN-060(JA/YN-060) peak = 1002.200012 pos = 35.6381,138.9810 diff = 239.400024'
});
data_saddle.push({
lat: 3.5642000001e+01,
lng: 1.3899777778e+02,
content:'Saddle = 762.799988 pos = 35.6420,138.9978 diff = 239.400024'
});
data_peak.push({
lat: 3.5159777781e+01,
lng: 1.3834844444e+02,
cert : true,
content:'Name = JA/SO-045(JA/SO-045) peak = 1046.300049 pos = 35.1598,138.3484 diff = 261.500061'
});
data_saddle.push({
lat: 3.5171777781e+01,
lng: 1.3834100000e+02,
content:'Saddle = 784.799988 pos = 35.1718,138.3410 diff = 261.500061'
});
data_peak.push({
lat: 3.5178555559e+01,
lng: 1.3843788889e+02,
cert : true,
content:'Name = [takadokkyou](JA/SO-040) peak = 1133.000000 pos = 35.1786,138.4379 diff = 335.599976'
});
data_saddle.push({
lat: 3.5185777781e+01,
lng: 1.3842677778e+02,
content:'Saddle = 797.400024 pos = 35.1858,138.4268 diff = 335.599976'
});
data_peak.push({
lat: 3.5583888891e+01,
lng: 1.3901977778e+02,
cert : true,
content:'Name = JA/YN-061(JA/YN-061) peak = 990.000000 pos = 35.5839,139.0198 diff = 191.799988'
});
data_saddle.push({
lat: 3.5566555557e+01,
lng: 1.3901111111e+02,
content:'Saddle = 798.200012 pos = 35.5666,139.0111 diff = 191.799988'
});
data_peak.push({
lat: 3.5672444446e+01,
lng: 1.3913644444e+02,
cert : true,
content:'Name = Ifujisan(JA/KN-013) peak = 1016.400024 pos = 35.6724,139.1364 diff = 194.700012'
});
data_saddle.push({
lat: 3.5691555557e+01,
lng: 1.3910333333e+02,
content:'Saddle = 821.700012 pos = 35.6916,139.1033 diff = 194.700012'
});
data_peak.push({
lat: 3.5091888893e+01,
lng: 1.3828966667e+02,
cert : false,
content:' Peak = 1035.599976 pos = 35.0919,138.2897 diff = 208.399963'
});
data_saddle.push({
lat: 3.5103777781e+01,
lng: 1.3827433333e+02,
content:'Saddle = 827.200012 pos = 35.1038,138.2743 diff = 208.399963'
});
data_peak.push({
lat: 3.5078444448e+01,
lng: 1.3827655556e+02,
cert : true,
content:'Name = JA/SO-048(JA/SO-048) peak = 1021.299988 pos = 35.0784,138.2766 diff = 193.599976'
});
data_saddle.push({
lat: 3.5085444448e+01,
lng: 1.3827700000e+02,
content:'Saddle = 827.700012 pos = 35.0854,138.2770 diff = 193.599976'
});
data_peak.push({
lat: 3.5091000004e+01,
lng: 1.3830600000e+02,
cert : false,
content:' Peak = 1034.099976 pos = 35.0910,138.3060 diff = 159.399963'
});
data_saddle.push({
lat: 3.5091000004e+01,
lng: 1.3829411111e+02,
content:'Saddle = 874.700012 pos = 35.0910,138.2941 diff = 159.399963'
});
data_peak.push({
lat: 3.5937000000e+01,
lng: 1.3913022222e+02,
cert : true,
content:'Name = Takegawadake(JA/ST-008) peak = 1051.599976 pos = 35.9370,139.1302 diff = 220.000000'
});
data_saddle.push({
lat: 3.5933666667e+01,
lng: 1.3912155556e+02,
content:'Saddle = 831.599976 pos = 35.9337,139.1216 diff = 220.000000'
});
data_peak.push({
lat: 3.5088333337e+01,
lng: 1.3840344444e+02,
cert : true,
content:'Name = Ryuusouzan(JA/SO-043) peak = 1050.500000 pos = 35.0883,138.4034 diff = 218.799988'
});
data_saddle.push({
lat: 3.5102777781e+01,
lng: 1.3839733333e+02,
content:'Saddle = 831.700012 pos = 35.1028,138.3973 diff = 218.799988'
});
data_peak.push({
lat: 3.5298888892e+01,
lng: 1.3849088889e+02,
cert : false,
content:' Peak = 1041.500000 pos = 35.2989,138.4909 diff = 198.900024'
});
data_saddle.push({
lat: 3.5322333336e+01,
lng: 1.3848211111e+02,
content:'Saddle = 842.599976 pos = 35.3223,138.4821 diff = 198.900024'
});
data_peak.push({
lat: 3.5637222224e+01,
lng: 1.3901355556e+02,
cert : true,
content:'Name = Gongenyama (Ougiyama)(JA/YN-059) peak = 1137.400024 pos = 35.6372,139.0136 diff = 286.300049'
});
data_saddle.push({
lat: 3.5653333335e+01,
lng: 1.3901622222e+02,
content:'Saddle = 851.099976 pos = 35.6533,139.0162 diff = 286.300049'
});
data_peak.push({
lat: 3.5739000001e+01,
lng: 1.3901366667e+02,
cert : true,
content:'Name = Mitousan(JA/TK-005) peak = 1530.400024 pos = 35.7390,139.0137 diff = 658.600037'
});
data_saddle.push({
lat: 3.5731222223e+01,
lng: 1.3897677778e+02,
content:'Saddle = 871.799988 pos = 35.7312,138.9768 diff = 658.600037'
});
data_peak.push({
lat: 3.5770111112e+01,
lng: 1.3908055556e+02,
cert : true,
content:'Name = Gozenyama(JA/TK-006) peak = 1404.400024 pos = 35.7701,139.0806 diff = 422.800049'
});
data_saddle.push({
lat: 3.5759666668e+01,
lng: 1.3905133333e+02,
content:'Saddle = 981.599976 pos = 35.7597,139.0513 diff = 422.800049'
});
data_peak.push({
lat: 3.5765222223e+01,
lng: 1.3913033333e+02,
cert : false,
content:' Peak = 1264.900024 pos = 35.7652,139.1303 diff = 274.000000'
});
data_saddle.push({
lat: 3.5778888890e+01,
lng: 1.3910288889e+02,
content:'Saddle = 990.900024 pos = 35.7789,139.1029 diff = 274.000000'
});
data_peak.push({
lat: 3.5742444445e+01,
lng: 1.3903477778e+02,
cert : false,
content:' Peak = 1301.800049 pos = 35.7424,139.0348 diff = 159.100098'
});
data_saddle.push({
lat: 3.5742333334e+01,
lng: 1.3902688889e+02,
content:'Saddle = 1142.699951 pos = 35.7423,139.0269 diff = 159.100098'
});
data_peak.push({
lat: 3.5061333337e+01,
lng: 1.3814977778e+02,
cert : true,
content:'Name = JA/SO-041(JA/SO-041) peak = 1111.900024 pos = 35.0613,138.1498 diff = 239.600037'
});
data_saddle.push({
lat: 3.5099666670e+01,
lng: 1.3818955556e+02,
content:'Saddle = 872.299988 pos = 35.0997,138.1896 diff = 239.600037'
});
data_peak.push({
lat: 3.5238111114e+01,
lng: 1.3879400000e+02,
cert : true,
content:'Name = Ashitakayama (Echizendake)(JA/SO-027) peak = 1503.099976 pos = 35.2381,138.7940 diff = 616.099976'
});
data_saddle.push({
lat: 3.5256000003e+01,
lng: 1.3879333333e+02,
content:'Saddle = 887.000000 pos = 35.2560,138.7933 diff = 616.099976'
});
data_peak.push({
lat: 3.5223777781e+01,
lng: 1.3881000000e+02,
cert : true,
content:'Name = JA/SO-029(JA/SO-029) peak = 1455.699951 pos = 35.2238,138.8100 diff = 202.399902'
});
data_saddle.push({
lat: 3.5227222225e+01,
lng: 1.3879811111e+02,
content:'Saddle = 1253.300049 pos = 35.2272,138.7981 diff = 202.399902'
});
data_peak.push({
lat: 3.6000000000e+01,
lng: 1.3878200000e+02,
cert : false,
content:' Peak = 1240.500000 pos = 36.0000,138.7820 diff = 332.099976'
});
data_saddle.push({
lat: 3.6000000000e+01,
lng: 1.3877777778e+02,
content:'Saddle = 908.400024 pos = 36.0000,138.7778 diff = 332.099976'
});
data_peak.push({
lat: 3.5833555556e+01,
lng: 1.3845688889e+02,
cert : false,
content:' Peak = 1121.699951 pos = 35.8336,138.4569 diff = 204.899963'
});
data_saddle.push({
lat: 3.5844222223e+01,
lng: 1.3846488889e+02,
content:'Saddle = 916.799988 pos = 35.8442,138.4649 diff = 204.899963'
});
data_peak.push({
lat: 3.5397555558e+01,
lng: 1.3841622222e+02,
cert : true,
content:'Name = Minobusan(JA/YN-058) peak = 1152.199951 pos = 35.3976,138.4162 diff = 230.199951'
});
data_saddle.push({
lat: 3.5393777780e+01,
lng: 1.3840144444e+02,
content:'Saddle = 922.000000 pos = 35.3938,138.4014 diff = 230.199951'
});
data_peak.push({
lat: 3.5770333334e+01,
lng: 1.3894966667e+02,
cert : true,
content:'Name = JA/YN-055(JA/YN-055) peak = 1286.800049 pos = 35.7703,138.9497 diff = 363.700073'
});
data_saddle.push({
lat: 3.5774777779e+01,
lng: 1.3893277778e+02,
content:'Saddle = 923.099976 pos = 35.7748,138.9328 diff = 363.700073'
});
data_peak.push({
lat: 3.5201777781e+01,
lng: 1.3790600000e+02,
cert : false,
content:' Peak = 1167.199951 pos = 35.2018,137.9060 diff = 238.599976'
});
data_saddle.push({
lat: 3.5230444448e+01,
lng: 1.3790788889e+02,
content:'Saddle = 928.599976 pos = 35.2304,137.9079 diff = 238.599976'
});
data_peak.push({
lat: 3.5951666667e+01,
lng: 1.3909777778e+02,
cert : true,
content:'Name = Bukousan(JA/ST-004) peak = 1302.500000 pos = 35.9517,139.0978 diff = 370.200012'
});
data_saddle.push({
lat: 3.5912222223e+01,
lng: 1.3911311111e+02,
content:'Saddle = 932.299988 pos = 35.9122,139.1131 diff = 370.200012'
});
data_peak.push({
lat: 3.5928555556e+01,
lng: 1.3910044444e+02,
cert : true,
content:'Name = Oomochiyama(JA/ST-005) peak = 1293.500000 pos = 35.9286,139.1004 diff = 230.800049'
});
data_saddle.push({
lat: 3.5945000000e+01,
lng: 1.3909622222e+02,
content:'Saddle = 1062.699951 pos = 35.9450,139.0962 diff = 230.800049'
});
data_peak.push({
lat: 3.5521777780e+01,
lng: 1.3795855556e+02,
cert : false,
content:' Peak = 1134.099976 pos = 35.5218,137.9586 diff = 186.299988'
});
data_saddle.push({
lat: 3.5514666669e+01,
lng: 1.3796188889e+02,
content:'Saddle = 947.799988 pos = 35.5147,137.9619 diff = 186.299988'
});
data_peak.push({
lat: 3.5674555557e+01,
lng: 1.3823877778e+02,
cert : true,
content:'Name = Kitadake(JA/YN-001) peak = 3191.300049 pos = 35.6746,138.2388 diff = 2236.500000'
});
data_saddle.push({
lat: 3.5911222223e+01,
lng: 1.3821988889e+02,
content:'Saddle = 954.799988 pos = 35.9112,138.2199 diff = 2236.500000'
});
data_peak.push({
lat: 3.5741666668e+01,
lng: 1.3837733333e+02,
cert : false,
content:' Peak = 1131.400024 pos = 35.7417,138.3773 diff = 169.800049'
});
data_saddle.push({
lat: 3.5737222223e+01,
lng: 1.3837044444e+02,
content:'Saddle = 961.599976 pos = 35.7372,138.3704 diff = 169.800049'
});
data_peak.push({
lat: 3.5728444446e+01,
lng: 1.3801588889e+02,
cert : false,
content:' Peak = 1120.099976 pos = 35.7284,138.0159 diff = 157.799988'
});
data_saddle.push({
lat: 3.5736333334e+01,
lng: 1.3801688889e+02,
content:'Saddle = 962.299988 pos = 35.7363,138.0169 diff = 157.799988'
});
data_peak.push({
lat: 3.5371888891e+01,
lng: 1.3839433333e+02,
cert : true,
content:'Name = JA/YN-057(JA/YN-057) peak = 1167.800049 pos = 35.3719,138.3943 diff = 186.100037'
});
data_saddle.push({
lat: 3.5356555558e+01,
lng: 1.3838766667e+02,
content:'Saddle = 981.700012 pos = 35.3566,138.3877 diff = 186.100037'
});
data_peak.push({
lat: 3.5220000003e+01,
lng: 1.3832311111e+02,
cert : true,
content:'Name = JA/SO-037(JA/SO-037) peak = 1206.800049 pos = 35.2200,138.3231 diff = 220.300049'
});
data_saddle.push({
lat: 3.5222111114e+01,
lng: 1.3831266667e+02,
content:'Saddle = 986.500000 pos = 35.2221,138.3127 diff = 220.300049'
});
data_peak.push({
lat: 3.5836888890e+01,
lng: 1.3808233333e+02,
cert : true,
content:'Name = Tsukikurayama(JA/NN-169) peak = 1191.599976 pos = 35.8369,138.0823 diff = 191.199951'
});
data_saddle.push({
lat: 3.5845444445e+01,
lng: 1.3809166667e+02,
content:'Saddle = 1000.400024 pos = 35.8454,138.0917 diff = 191.199951'
});
data_peak.push({
lat: 3.5206555559e+01,
lng: 1.3841788889e+02,
cert : false,
content:' Peak = 1202.300049 pos = 35.2066,138.4179 diff = 170.200073'
});
data_saddle.push({
lat: 3.5201777781e+01,
lng: 1.3841144444e+02,
content:'Saddle = 1032.099976 pos = 35.2018,138.4114 diff = 170.200073'
});
data_peak.push({
lat: 3.5068111115e+01,
lng: 1.3788222222e+02,
cert : false,
content:' Peak = 1353.000000 pos = 35.0681,137.8822 diff = 285.500000'
});
data_saddle.push({
lat: 3.5135555559e+01,
lng: 1.3791422222e+02,
content:'Saddle = 1067.500000 pos = 35.1356,137.9142 diff = 285.500000'
});
data_peak.push({
lat: 3.5121111115e+01,
lng: 1.3789666667e+02,
cert : true,
content:'Name = JA/SO-035(JA/SO-035) peak = 1331.400024 pos = 35.1211,137.8967 diff = 228.500000'
});
data_saddle.push({
lat: 3.5114222226e+01,
lng: 1.3789666667e+02,
content:'Saddle = 1102.900024 pos = 35.1142,137.8967 diff = 228.500000'
});
data_peak.push({
lat: 3.5247777781e+01,
lng: 1.3842633333e+02,
cert : true,
content:'Name = Shinoisan(JA/YN-052) peak = 1392.699951 pos = 35.2478,138.4263 diff = 321.500000'
});
data_saddle.push({
lat: 3.5244666670e+01,
lng: 1.3841400000e+02,
content:'Saddle = 1071.199951 pos = 35.2447,138.4140 diff = 321.500000'
});
data_peak.push({
lat: 3.5177777781e+01,
lng: 1.3816711111e+02,
cert : true,
content:'Name = JA/SO-036(JA/SO-036) peak = 1293.000000 pos = 35.1778,138.1671 diff = 209.400024'
});
data_saddle.push({
lat: 3.5183000003e+01,
lng: 1.3816466667e+02,
content:'Saddle = 1083.599976 pos = 35.1830,138.1647 diff = 209.400024'
});
data_peak.push({
lat: 3.5263333336e+01,
lng: 1.3789477778e+02,
cert : true,
content:'Name = Kumabushiyama(JA/NN-106) peak = 1652.400024 pos = 35.2633,137.8948 diff = 565.000000'
});
data_saddle.push({
lat: 3.5254111114e+01,
lng: 1.3791077778e+02,
content:'Saddle = 1087.400024 pos = 35.2541,137.9108 diff = 565.000000'
});
data_peak.push({
lat: 3.5105111115e+01,
lng: 1.3805900000e+02,
cert : false,
content:' Peak = 1380.300049 pos = 35.1051,138.0590 diff = 237.300049'
});
data_saddle.push({
lat: 3.5112222226e+01,
lng: 1.3804866667e+02,
content:'Saddle = 1143.000000 pos = 35.1122,138.0487 diff = 237.300049'
});
data_peak.push({
lat: 3.5156666670e+01,
lng: 1.3821888889e+02,
cert : true,
content:'Name = JA/SO-026(JA/SO-026) peak = 1531.800049 pos = 35.1567,138.2189 diff = 383.900024'
});
data_saddle.push({
lat: 3.5190111114e+01,
lng: 1.3825144444e+02,
content:'Saddle = 1147.900024 pos = 35.1901,138.2514 diff = 383.900024'
});
data_peak.push({
lat: 3.5136777781e+01,
lng: 1.3818422222e+02,
cert : true,
content:'Name = JA/SO-033(JA/SO-033) peak = 1362.099976 pos = 35.1368,138.1842 diff = 187.799927'
});
data_saddle.push({
lat: 3.5143000003e+01,
lng: 1.3819488889e+02,
content:'Saddle = 1174.300049 pos = 35.1430,138.1949 diff = 187.799927'
});
data_peak.push({
lat: 3.5254555559e+01,
lng: 1.3791866667e+02,
cert : true,
content:'Name = JA/SO-032(JA/SO-032) peak = 1366.800049 pos = 35.2546,137.9187 diff = 213.200073'
});
data_saddle.push({
lat: 3.5274111114e+01,
lng: 1.3792911111e+02,
content:'Saddle = 1153.599976 pos = 35.2741,137.9291 diff = 213.200073'
});
data_peak.push({
lat: 3.5671777779e+01,
lng: 1.3798400000e+02,
cert : false,
content:' Peak = 1444.099976 pos = 35.6718,137.9840 diff = 276.299927'
});
data_saddle.push({
lat: 3.5673000001e+01,
lng: 1.3801411111e+02,
content:'Saddle = 1167.800049 pos = 35.6730,138.0141 diff = 276.299927'
});
data_peak.push({
lat: 3.5420333336e+01,
lng: 1.3820688889e+02,
cert : false,
content:' Peak = 1572.300049 pos = 35.4203,138.2069 diff = 383.300049'
});
data_saddle.push({
lat: 3.5430888891e+01,
lng: 1.3820511111e+02,
content:'Saddle = 1189.000000 pos = 35.4309,138.2051 diff = 383.300049'
});
data_peak.push({
lat: 3.5158222226e+01,
lng: 1.3791444444e+02,
cert : false,
content:' Peak = 1434.400024 pos = 35.1582,137.9144 diff = 213.099976'
});
data_saddle.push({
lat: 3.5150888892e+01,
lng: 1.3792766667e+02,
content:'Saddle = 1221.300049 pos = 35.1509,137.9277 diff = 213.099976'
});
data_peak.push({
lat: 3.5106111115e+01,
lng: 1.3794255556e+02,
cert : false,
content:' Peak = 1433.500000 pos = 35.1061,137.9426 diff = 211.400024'
});
data_saddle.push({
lat: 3.5100333337e+01,
lng: 1.3795200000e+02,
content:'Saddle = 1222.099976 pos = 35.1003,137.9520 diff = 211.400024'
});
data_peak.push({
lat: 3.5967555556e+01,
lng: 1.3809344444e+02,
cert : true,
content:'Name = Moriyasan(JA/NN-108) peak = 1650.199951 pos = 35.9676,138.0934 diff = 413.599976'
});
data_saddle.push({
lat: 3.5970111111e+01,
lng: 1.3812377778e+02,
content:'Saddle = 1236.599976 pos = 35.9701,138.1238 diff = 413.599976'
});
data_peak.push({
lat: 3.5913333334e+01,
lng: 1.3806044444e+02,
cert : true,
content:'Name = JA/NN-120(JA/NN-120) peak = 1527.400024 pos = 35.9133,138.0604 diff = 240.200073'
});
data_saddle.push({
lat: 3.5947222222e+01,
lng: 1.3809077778e+02,
content:'Saddle = 1287.199951 pos = 35.9472,138.0908 diff = 240.200073'
});
data_peak.push({
lat: 3.5156444448e+01,
lng: 1.3810744444e+02,
cert : false,
content:' Peak = 1423.900024 pos = 35.1564,138.1074 diff = 170.599976'
});
data_saddle.push({
lat: 3.5155666670e+01,
lng: 1.3809500000e+02,
content:'Saddle = 1253.300049 pos = 35.1557,138.0950 diff = 170.599976'
});
data_peak.push({
lat: 3.5632444446e+01,
lng: 1.3802022222e+02,
cert : false,
content:' Peak = 1444.300049 pos = 35.6324,138.0202 diff = 182.000000'
});
data_saddle.push({
lat: 3.5633222224e+01,
lng: 1.3802644444e+02,
content:'Saddle = 1262.300049 pos = 35.6332,138.0264 diff = 182.000000'
});
data_peak.push({
lat: 3.5096000004e+01,
lng: 1.3796588889e+02,
cert : false,
content:' Peak = 1465.099976 pos = 35.0960,137.9659 diff = 181.799927'
});
data_saddle.push({
lat: 3.5101111115e+01,
lng: 1.3797366667e+02,
content:'Saddle = 1283.300049 pos = 35.1011,137.9737 diff = 181.799927'
});
data_peak.push({
lat: 3.5099888892e+01,
lng: 1.3801055556e+02,
cert : true,
content:'Name = JA/SO-028(JA/SO-028) peak = 1501.500000 pos = 35.0999,138.0106 diff = 208.800049'
});
data_saddle.push({
lat: 3.5106333337e+01,
lng: 1.3800888889e+02,
content:'Saddle = 1292.699951 pos = 35.1063,138.0089 diff = 208.800049'
});
data_peak.push({
lat: 3.5745000001e+01,
lng: 1.3805188889e+02,
cert : true,
content:'Name = Tokurayama (Inafuji)(JA/NN-098) peak = 1680.400024 pos = 35.7450,138.0519 diff = 387.700073'
});
data_saddle.push({
lat: 3.5715555557e+01,
lng: 1.3806300000e+02,
content:'Saddle = 1292.699951 pos = 35.7156,138.0630 diff = 387.700073'
});
data_peak.push({
lat: 3.5492111113e+01,
lng: 1.3799011111e+02,
cert : true,
content:'Name = Kimenzan(JA/NN-079) peak = 1887.300049 pos = 35.4921,137.9901 diff = 589.000000'
});
data_saddle.push({
lat: 3.5481222224e+01,
lng: 1.3801155556e+02,
content:'Saddle = 1298.300049 pos = 35.4812,138.0116 diff = 589.000000'
});
data_peak.push({
lat: 3.5344777780e+01,
lng: 1.3792388889e+02,
cert : false,
content:' Peak = 1473.500000 pos = 35.3448,137.9239 diff = 161.699951'
});
data_saddle.push({
lat: 3.5353888891e+01,
lng: 1.3792366667e+02,
content:'Saddle = 1311.800049 pos = 35.3539,137.9237 diff = 161.699951'
});
data_peak.push({
lat: 3.5409111113e+01,
lng: 1.3793966667e+02,
cert : true,
content:'Name = JA/NN-096(JA/NN-096) peak = 1700.800049 pos = 35.4091,137.9397 diff = 228.300049'
});
data_saddle.push({
lat: 3.5443555558e+01,
lng: 1.3796300000e+02,
content:'Saddle = 1472.500000 pos = 35.4436,137.9630 diff = 228.300049'
});
data_peak.push({
lat: 3.5488111113e+01,
lng: 1.3836988889e+02,
cert : true,
content:'Name = JA/YN-040(JA/YN-040) peak = 1668.800049 pos = 35.4881,138.3699 diff = 296.300049'
});
data_saddle.push({
lat: 3.5508888891e+01,
lng: 1.3835988889e+02,
content:'Saddle = 1372.500000 pos = 35.5089,138.3599 diff = 296.300049'
});
data_peak.push({
lat: 3.5137444448e+01,
lng: 1.3805722222e+02,
cert : false,
content:' Peak = 1561.599976 pos = 35.1374,138.0572 diff = 169.500000'
});
data_saddle.push({
lat: 3.5135000003e+01,
lng: 1.3804622222e+02,
content:'Saddle = 1392.099976 pos = 35.1350,138.0462 diff = 169.500000'
});
data_peak.push({
lat: 3.5674777779e+01,
lng: 1.3804400000e+02,
cert : true,
content:'Name = JA/NN-093(JA/NN-093) peak = 1741.199951 pos = 35.6748,138.0440 diff = 329.699951'
});
data_saddle.push({
lat: 3.5699333335e+01,
lng: 1.3806677778e+02,
content:'Saddle = 1411.500000 pos = 35.6993,138.0668 diff = 329.699951'
});
data_peak.push({
lat: 3.5243555559e+01,
lng: 1.3838577778e+02,
cert : false,
content:' Peak = 1732.199951 pos = 35.2436,138.3858 diff = 308.899902'
});
data_saddle.push({
lat: 3.5317555558e+01,
lng: 1.3835800000e+02,
content:'Saddle = 1423.300049 pos = 35.3176,138.3580 diff = 308.899902'
});
data_peak.push({
lat: 3.5298888892e+01,
lng: 1.3837244444e+02,
cert : true,
content:'Name = JA/YN-039(JA/YN-039) peak = 1671.300049 pos = 35.2989,138.3724 diff = 237.900024'
});
data_saddle.push({
lat: 3.5268333336e+01,
lng: 1.3836944444e+02,
content:'Saddle = 1433.400024 pos = 35.2683,138.3694 diff = 237.900024'
});
data_peak.push({
lat: 3.5126111115e+01,
lng: 1.3803466667e+02,
cert : true,
content:'Name = Sobatsubuyama(JA/SO-025) peak = 1623.400024 pos = 35.1261,138.0347 diff = 191.599976'
});
data_saddle.push({
lat: 3.5127777781e+01,
lng: 1.3802422222e+02,
content:'Saddle = 1431.800049 pos = 35.1278,138.0242 diff = 191.599976'
});
data_peak.push({
lat: 3.5258777781e+01,
lng: 1.3807877778e+02,
cert : true,
content:'Name = JA/SO-024(JA/SO-024) peak = 1744.400024 pos = 35.2588,138.0788 diff = 261.800049'
});
data_saddle.push({
lat: 3.5266777781e+01,
lng: 1.3806977778e+02,
content:'Saddle = 1482.599976 pos = 35.2668,138.0698 diff = 261.800049'
});
data_peak.push({
lat: 3.5194888892e+01,
lng: 1.3798544444e+02,
cert : true,
content:'Name = JA/SO-022(JA/SO-022) peak = 1781.000000 pos = 35.1949,137.9854 diff = 249.400024'
});
data_saddle.push({
lat: 3.5194555559e+01,
lng: 1.3799877778e+02,
content:'Saddle = 1531.599976 pos = 35.1946,137.9988 diff = 249.400024'
});
data_peak.push({
lat: 3.5590888891e+01,
lng: 1.3837033333e+02,
cert : false,
content:' Peak = 2054.699951 pos = 35.5909,138.3703 diff = 522.000000'
});
data_saddle.push({
lat: 3.5598000002e+01,
lng: 1.3833522222e+02,
content:'Saddle = 1532.699951 pos = 35.5980,138.3352 diff = 522.000000'
});
data_peak.push({
lat: 3.5587666668e+01,
lng: 1.3832722222e+02,
cert : false,
content:' Peak = 1800.800049 pos = 35.5877,138.3272 diff = 163.400024'
});
data_saddle.push({
lat: 3.5589444446e+01,
lng: 1.3833300000e+02,
content:'Saddle = 1637.400024 pos = 35.5894,138.3330 diff = 163.400024'
});
data_peak.push({
lat: 3.5567444446e+01,
lng: 1.3834522222e+02,
cert : true,
content:'Name = JA/YN-028(JA/YN-028) peak = 1910.099976 pos = 35.5674,138.3452 diff = 237.599976'
});
data_saddle.push({
lat: 3.5570000002e+01,
lng: 1.3835655556e+02,
content:'Saddle = 1672.500000 pos = 35.5700,138.3566 diff = 237.599976'
});
data_peak.push({
lat: 3.5553111113e+01,
lng: 1.3836244444e+02,
cert : true,
content:'Name = JA/YN-029(JA/YN-029) peak = 1906.400024 pos = 35.5531,138.3624 diff = 230.300049'
});
data_saddle.push({
lat: 3.5563111113e+01,
lng: 1.3835500000e+02,
content:'Saddle = 1676.099976 pos = 35.5631,138.3550 diff = 230.300049'
});
data_peak.push({
lat: 3.5240777781e+01,
lng: 1.3821744444e+02,
cert : false,
content:' Peak = 1711.199951 pos = 35.2408,138.2174 diff = 178.299927'
});
data_saddle.push({
lat: 3.5257222225e+01,
lng: 1.3821044444e+02,
content:'Saddle = 1532.900024 pos = 35.2572,138.2104 diff = 178.299927'
});
data_peak.push({
lat: 3.5268333336e+01,
lng: 1.3827644444e+02,
cert : true,
content:'Name = JA/SO-023(JA/SO-023) peak = 1762.400024 pos = 35.2683,138.2764 diff = 200.700073'
});
data_saddle.push({
lat: 3.5276555558e+01,
lng: 1.3828044444e+02,
content:'Saddle = 1561.699951 pos = 35.2766,138.2804 diff = 200.700073'
});
data_peak.push({
lat: 3.5235444448e+01,
lng: 1.3804111111e+02,
cert : true,
content:'Name = Fudougatake(JA/SO-016) peak = 2170.399902 pos = 35.2354,138.0411 diff = 567.099854'
});
data_saddle.push({
lat: 3.5239888892e+01,
lng: 1.3801577778e+02,
content:'Saddle = 1603.300049 pos = 35.2399,138.0158 diff = 567.099854'
});
data_peak.push({
lat: 3.5187333337e+01,
lng: 1.3807033333e+02,
cert : true,
content:'Name = JA/SO-020(JA/SO-020) peak = 1942.099976 pos = 35.1873,138.0703 diff = 288.400024'
});
data_saddle.push({
lat: 3.5188111114e+01,
lng: 1.3805711111e+02,
content:'Saddle = 1653.699951 pos = 35.1881,138.0571 diff = 288.400024'
});
data_peak.push({
lat: 3.5196111114e+01,
lng: 1.3802922222e+02,
cert : true,
content:'Name = Kuroboushigatake(JA/SO-017) peak = 2064.899902 pos = 35.1961,138.0292 diff = 203.399902'
});
data_saddle.push({
lat: 3.5203666670e+01,
lng: 1.3802988889e+02,
content:'Saddle = 1861.500000 pos = 35.2037,138.0299 diff = 203.399902'
});
data_peak.push({
lat: 3.5206888892e+01,
lng: 1.3813222222e+02,
cert : true,
content:'Name = JA/SO-021(JA/SO-021) peak = 1825.500000 pos = 35.2069,138.1322 diff = 204.599976'
});
data_saddle.push({
lat: 3.5212666670e+01,
lng: 1.3813011111e+02,
content:'Saddle = 1620.900024 pos = 35.2127,138.1301 diff = 204.599976'
});
data_peak.push({
lat: 3.5812888890e+01,
lng: 1.3812900000e+02,
cert : false,
content:' Peak = 1884.699951 pos = 35.8129,138.1290 diff = 261.199951'
});
data_saddle.push({
lat: 3.5857111112e+01,
lng: 1.3814500000e+02,
content:'Saddle = 1623.500000 pos = 35.8571,138.1450 diff = 261.199951'
});
data_peak.push({
lat: 3.5826333334e+01,
lng: 1.3823555556e+02,
cert : true,
content:'Name = JA/YN-026(JA/YN-026) peak = 2035.900024 pos = 35.8263,138.2356 diff = 353.000000'
});
data_saddle.push({
lat: 3.5816666667e+01,
lng: 1.3823844444e+02,
content:'Saddle = 1682.900024 pos = 35.8167,138.2384 diff = 353.000000'
});
data_peak.push({
lat: 3.5360555558e+01,
lng: 1.3835000000e+02,
cert : false,
content:' Peak = 1992.400024 pos = 35.3606,138.3500 diff = 261.099976'
});
data_saddle.push({
lat: 3.5336888892e+01,
lng: 1.3834122222e+02,
content:'Saddle = 1731.300049 pos = 35.3369,138.3412 diff = 261.099976'
});
data_peak.push({
lat: 3.5616111113e+01,
lng: 1.3813588889e+02,
cert : false,
content:' Peak = 1980.199951 pos = 35.6161,138.1359 diff = 188.099976'
});
data_saddle.push({
lat: 3.5631000001e+01,
lng: 1.3813877778e+02,
content:'Saddle = 1792.099976 pos = 35.6310,138.1388 diff = 188.099976'
});
data_peak.push({
lat: 3.5256000003e+01,
lng: 1.3816144444e+02,
cert : true,
content:'Name = Daimugenzan(JA/SO-013) peak = 2328.199951 pos = 35.2560,138.1614 diff = 535.599976'
});
data_saddle.push({
lat: 3.5287777781e+01,
lng: 1.3813088889e+02,
content:'Saddle = 1792.599976 pos = 35.2878,138.1309 diff = 535.599976'
});
data_peak.push({
lat: 3.5283333336e+01,
lng: 1.3813722222e+02,
cert : true,
content:'Name = JA/SO-015(JA/SO-015) peak = 2240.699951 pos = 35.2833,138.1372 diff = 392.099976'
});
data_saddle.push({
lat: 3.5268333336e+01,
lng: 1.3813800000e+02,
content:'Saddle = 1848.599976 pos = 35.2683,138.1380 diff = 392.099976'
});
data_peak.push({
lat: 3.5563333335e+01,
lng: 1.3809333333e+02,
cert : false,
content:' Peak = 2081.199951 pos = 35.5633,138.0933 diff = 268.500000'
});
data_saddle.push({
lat: 3.5562222224e+01,
lng: 1.3810300000e+02,
content:'Saddle = 1812.699951 pos = 35.5622,138.1030 diff = 268.500000'
});
data_peak.push({
lat: 3.5304333336e+01,
lng: 1.3828522222e+02,
cert : true,
content:'Name = Yanbushi(JA/SO-018) peak = 2013.199951 pos = 35.3043,138.2852 diff = 190.599976'
});
data_saddle.push({
lat: 3.5309888892e+01,
lng: 1.3827555556e+02,
content:'Saddle = 1822.599976 pos = 35.3099,138.2756 diff = 190.599976'
});
data_peak.push({
lat: 3.5674444446e+01,
lng: 1.3835188889e+02,
cert : true,
content:'Name = JA/YN-021(JA/YN-021) peak = 2140.600098 pos = 35.6744,138.3519 diff = 248.500122'
});
data_saddle.push({
lat: 3.5673000001e+01,
lng: 1.3834355556e+02,
content:'Saddle = 1892.099976 pos = 35.6730,138.3436 diff = 248.500122'
});
data_peak.push({
lat: 3.5285000003e+01,
lng: 1.3804255556e+02,
cert : false,
content:' Peak = 2147.199951 pos = 35.2850,138.0426 diff = 204.500000'
});
data_saddle.push({
lat: 3.5290777781e+01,
lng: 1.3803666667e+02,
content:'Saddle = 1942.699951 pos = 35.2908,138.0367 diff = 204.500000'
});
data_peak.push({
lat: 3.5814444445e+01,
lng: 1.3817466667e+02,
cert : true,
content:'Name = JA/NN-049(JA/NN-049) peak = 2266.800049 pos = 35.8144,138.1747 diff = 323.700073'
});
data_saddle.push({
lat: 3.5783666668e+01,
lng: 1.3818288889e+02,
content:'Saddle = 1943.099976 pos = 35.7837,138.1829 diff = 323.700073'
});
data_peak.push({
lat: 3.5348777780e+01,
lng: 1.3825566667e+02,
cert : true,
content:'Name = JA/YN-020(JA/YN-020) peak = 2204.399902 pos = 35.3488,138.2557 diff = 251.699951'
});
data_saddle.push({
lat: 3.5367111114e+01,
lng: 1.3824688889e+02,
content:'Saddle = 1952.699951 pos = 35.3671,138.2469 diff = 251.699951'
});
data_peak.push({
lat: 3.5424111113e+01,
lng: 1.3825944444e+02,
cert : true,
content:'Name = Zarugatake(JA/YN-011) peak = 2626.500000 pos = 35.4241,138.2594 diff = 648.900024'
});
data_saddle.push({
lat: 3.5545111113e+01,
lng: 1.3825988889e+02,
content:'Saddle = 1977.599976 pos = 35.5451,138.2599 diff = 648.900024'
});
data_peak.push({
lat: 3.5513888891e+01,
lng: 1.3827111111e+02,
cert : true,
content:'Name = JA/YN-019(JA/YN-019) peak = 2224.800049 pos = 35.5139,138.2711 diff = 240.400024'
});
data_saddle.push({
lat: 3.5502222224e+01,
lng: 1.3825977778e+02,
content:'Saddle = 1984.400024 pos = 35.5022,138.2598 diff = 240.400024'
});
data_peak.push({
lat: 3.5370111114e+01,
lng: 1.3822888889e+02,
cert : false,
content:' Peak = 2406.100098 pos = 35.3701,138.2289 diff = 373.500122'
});
data_saddle.push({
lat: 3.5394333336e+01,
lng: 1.3824722222e+02,
content:'Saddle = 2032.599976 pos = 35.3943,138.2472 diff = 373.500122'
});
data_peak.push({
lat: 3.5446111113e+01,
lng: 1.3825622222e+02,
cert : true,
content:'Name = JA/YN-014(JA/YN-014) peak = 2545.100098 pos = 35.4461,138.2562 diff = 223.300049'
});
data_saddle.push({
lat: 3.5439777780e+01,
lng: 1.3825555556e+02,
content:'Saddle = 2321.800049 pos = 35.4398,138.2556 diff = 223.300049'
});
data_peak.push({
lat: 3.5408555558e+01,
lng: 1.3825811111e+02,
cert : false,
content:' Peak = 2582.699951 pos = 35.4086,138.2581 diff = 164.500000'
});
data_saddle.push({
lat: 3.5417777780e+01,
lng: 1.3825811111e+02,
content:'Saddle = 2418.199951 pos = 35.4178,138.2581 diff = 164.500000'
});
data_peak.push({
lat: 3.5781555556e+01,
lng: 1.3818766667e+02,
cert : true,
content:'Name = JA/NN-056(JA/NN-056) peak = 2141.699951 pos = 35.7816,138.1877 diff = 160.000000'
});
data_saddle.push({
lat: 3.5782111112e+01,
lng: 1.3819122222e+02,
content:'Saddle = 1981.699951 pos = 35.7821,138.1912 diff = 160.000000'
});
data_peak.push({
lat: 3.5648666668e+01,
lng: 1.3810255556e+02,
cert : true,
content:'Name = JA/NN-050(JA/NN-050) peak = 2240.600098 pos = 35.6487,138.1026 diff = 207.900146'
});
data_saddle.push({
lat: 3.5605222224e+01,
lng: 1.3810744444e+02,
content:'Saddle = 2032.699951 pos = 35.6052,138.1074 diff = 207.900146'
});
data_peak.push({
lat: 3.5758000001e+01,
lng: 1.3823677778e+02,
cert : true,
content:'Name = Komagatake(JA/YN-005) peak = 2964.399902 pos = 35.7580,138.2368 diff = 925.999878'
});
data_saddle.push({
lat: 3.5743111112e+01,
lng: 1.3821122222e+02,
content:'Saddle = 2038.400024 pos = 35.7431,138.2112 diff = 925.999878'
});
data_peak.push({
lat: 3.5794333334e+01,
lng: 1.3823111111e+02,
cert : false,
content:' Peak = 2317.600098 pos = 35.7943,138.2311 diff = 164.500000'
});
data_saddle.push({
lat: 3.5790777779e+01,
lng: 1.3823122222e+02,
content:'Saddle = 2153.100098 pos = 35.7908,138.2312 diff = 164.500000'
});
data_peak.push({
lat: 3.5701888890e+01,
lng: 1.3830455556e+02,
cert : true,
content:'Name = Kannongadake(JA/YN-007) peak = 2840.199951 pos = 35.7019,138.3046 diff = 572.599854'
});
data_saddle.push({
lat: 3.5745777779e+01,
lng: 1.3823388889e+02,
content:'Saddle = 2267.600098 pos = 35.7458,138.2339 diff = 572.599854'
});
data_peak.push({
lat: 3.5731777779e+01,
lng: 1.3824133333e+02,
cert : true,
content:'Name = Asayomine(JA/YN-008) peak = 2796.699951 pos = 35.7318,138.2413 diff = 454.000000'
});
data_saddle.push({
lat: 3.5719222223e+01,
lng: 1.3826911111e+02,
content:'Saddle = 2342.699951 pos = 35.7192,138.2691 diff = 454.000000'
});
data_peak.push({
lat: 3.5709777779e+01,
lng: 1.3828766667e+02,
cert : false,
content:' Peak = 2776.300049 pos = 35.7098,138.2877 diff = 152.300049'
});
data_saddle.push({
lat: 3.5707222223e+01,
lng: 1.3830000000e+02,
content:'Saddle = 2624.000000 pos = 35.7072,138.3000 diff = 152.300049'
});
data_peak.push({
lat: 3.5779111112e+01,
lng: 1.3821000000e+02,
cert : true,
content:'Name = Nokogiriyama(JA/YN-010) peak = 2681.000000 pos = 35.7791,138.2100 diff = 193.800049'
});
data_saddle.push({
lat: 3.5774888890e+01,
lng: 1.3821477778e+02,
content:'Saddle = 2487.199951 pos = 35.7749,138.2148 diff = 193.800049'
});
data_peak.push({
lat: 3.5294222225e+01,
lng: 1.3801755556e+02,
cert : true,
content:'Name = JA/SO-014(JA/SO-014) peak = 2292.000000 pos = 35.2942,138.0176 diff = 221.399902'
});
data_saddle.push({
lat: 3.5321000003e+01,
lng: 1.3802744444e+02,
content:'Saddle = 2070.600098 pos = 35.3210,138.0274 diff = 221.399902'
});
data_peak.push({
lat: 3.5684777779e+01,
lng: 1.3816266667e+02,
cert : true,
content:'Name = JA/NN-047(JA/NN-047) peak = 2291.500000 pos = 35.6848,138.1627 diff = 218.399902'
});
data_saddle.push({
lat: 3.5701444446e+01,
lng: 1.3816000000e+02,
content:'Saddle = 2073.100098 pos = 35.7014,138.1600 diff = 218.399902'
});
data_peak.push({
lat: 3.5307111114e+01,
lng: 1.3809833333e+02,
cert : true,
content:'Name = JA/SO-012(JA/SO-012) peak = 2331.600098 pos = 35.3071,138.0983 diff = 254.200195'
});
data_saddle.push({
lat: 3.5314777781e+01,
lng: 1.3809222222e+02,
content:'Saddle = 2077.399902 pos = 35.3148,138.0922 diff = 254.200195'
});
data_peak.push({
lat: 3.5330222225e+01,
lng: 1.3803822222e+02,
cert : true,
content:'Name = Ikeguchidake(JA/SO-011) peak = 2391.199951 pos = 35.3302,138.0382 diff = 233.800049'
});
data_saddle.push({
lat: 3.5335222225e+01,
lng: 1.3804488889e+02,
content:'Saddle = 2157.399902 pos = 35.3352,138.0449 diff = 233.800049'
});
data_peak.push({
lat: 3.5485000002e+01,
lng: 1.3806900000e+02,
cert : true,
content:'Name = Okuchausuyama(JA/NN-033) peak = 2472.699951 pos = 35.4850,138.0690 diff = 301.899902'
});
data_saddle.push({
lat: 3.5481111113e+01,
lng: 1.3808888889e+02,
content:'Saddle = 2170.800049 pos = 35.4811,138.0889 diff = 301.899902'
});
data_peak.push({
lat: 3.5338222225e+01,
lng: 1.3808377778e+02,
cert : true,
content:'Name = Tekaridake(JA/SO-010) peak = 2590.100098 pos = 35.3382,138.0838 diff = 399.100098'
});
data_saddle.push({
lat: 3.5351555558e+01,
lng: 1.3809444444e+02,
content:'Saddle = 2191.000000 pos = 35.3516,138.0944 diff = 399.100098'
});
data_peak.push({
lat: 3.5347222225e+01,
lng: 1.3806122222e+02,
cert : false,
content:' Peak = 2428.600098 pos = 35.3472,138.0612 diff = 167.000000'
});
data_saddle.push({
lat: 3.5344333336e+01,
lng: 1.3807522222e+02,
content:'Saddle = 2261.600098 pos = 35.3443,138.0752 diff = 167.000000'
});
data_peak.push({
lat: 3.5474777780e+01,
lng: 1.3809466667e+02,
cert : false,
content:' Peak = 2373.100098 pos = 35.4748,138.0947 diff = 152.300049'
});
data_saddle.push({
lat: 3.5473333335e+01,
lng: 1.3810522222e+02,
content:'Saddle = 2220.800049 pos = 35.4733,138.1052 diff = 152.300049'
});
data_peak.push({
lat: 3.5383777780e+01,
lng: 1.3817444444e+02,
cert : false,
content:' Peak = 2422.100098 pos = 35.3838,138.1744 diff = 160.300049'
});
data_saddle.push({
lat: 3.5385333336e+01,
lng: 1.3817077778e+02,
content:'Saddle = 2261.800049 pos = 35.3853,138.1708 diff = 160.300049'
});
data_peak.push({
lat: 3.5389555558e+01,
lng: 1.3815266667e+02,
cert : true,
content:'Name = Kamikouchidake(JA/SO-008) peak = 2800.600098 pos = 35.3896,138.1527 diff = 521.700195'
});
data_saddle.push({
lat: 3.5406000002e+01,
lng: 1.3813977778e+02,
content:'Saddle = 2278.899902 pos = 35.4060,138.1398 diff = 521.700195'
});
data_peak.push({
lat: 3.5720111112e+01,
lng: 1.3818355556e+02,
cert : true,
content:'Name = Senjyougatake(JA/YN-004) peak = 3031.600098 pos = 35.7201,138.1836 diff = 738.700195'
});
data_saddle.push({
lat: 3.5669333335e+01,
lng: 1.3819900000e+02,
content:'Saddle = 2292.899902 pos = 35.6693,138.1990 diff = 738.700195'
});
data_peak.push({
lat: 3.5500777780e+01,
lng: 1.3818233333e+02,
cert : true,
content:'Name = Warusawadake(JA/SO-002) peak = 3140.699951 pos = 35.5008,138.1823 diff = 749.399902'
});
data_saddle.push({
lat: 3.5503666669e+01,
lng: 1.3814044444e+02,
content:'Saddle = 2391.300049 pos = 35.5037,138.1404 diff = 749.399902'
});
data_peak.push({
lat: 3.5422555558e+01,
lng: 1.3813955556e+02,
cert : true,
content:'Name = Hijiridake (Maehijiridake)(JA/SO-007) peak = 3010.699951 pos = 35.4226,138.1396 diff = 468.199951'
});
data_saddle.push({
lat: 3.5454444447e+01,
lng: 1.3812822222e+02,
content:'Saddle = 2542.500000 pos = 35.4544,138.1282 diff = 468.199951'
});
data_peak.push({
lat: 3.5449444447e+01,
lng: 1.3812022222e+02,
cert : false,
content:' Peak = 2823.300049 pos = 35.4494,138.1202 diff = 211.699951'
});
data_saddle.push({
lat: 3.5427222225e+01,
lng: 1.3812822222e+02,
content:'Saddle = 2611.600098 pos = 35.4272,138.1282 diff = 211.699951'
});
data_peak.push({
lat: 3.5428666669e+01,
lng: 1.3812111111e+02,
cert : true,
content:'Name = Usagidake(JA/NN-015) peak = 2815.300049 pos = 35.4287,138.1211 diff = 182.600098'
});
data_saddle.push({
lat: 3.5438777780e+01,
lng: 1.3812300000e+02,
content:'Saddle = 2632.699951 pos = 35.4388,138.1230 diff = 182.600098'
});
data_peak.push({
lat: 3.5461111113e+01,
lng: 1.3815733333e+02,
cert : true,
content:'Name = Akaishidake(JA/SO-003) peak = 3120.000000 pos = 35.4611,138.1573 diff = 420.500000'
});
data_saddle.push({
lat: 3.5477555558e+01,
lng: 1.3815655556e+02,
content:'Saddle = 2699.500000 pos = 35.4776,138.1566 diff = 420.500000'
});
data_peak.push({
lat: 3.5496666669e+01,
lng: 1.3816700000e+02,
cert : true,
content:'Name = Arakawadake (Nakadake)(JA/SO-004) peak = 3080.600098 pos = 35.4967,138.1670 diff = 159.900146'
});
data_saddle.push({
lat: 3.5498777780e+01,
lng: 1.3817588889e+02,
content:'Saddle = 2920.699951 pos = 35.4988,138.1759 diff = 159.900146'
});
data_peak.push({
lat: 3.5537777780e+01,
lng: 1.3815300000e+02,
cert : true,
content:'Name = Kogouchidake(JA/SO-009) peak = 2801.300049 pos = 35.5378,138.1530 diff = 310.100098'
});
data_saddle.push({
lat: 3.5565222224e+01,
lng: 1.3815044444e+02,
content:'Saddle = 2491.199951 pos = 35.5652,138.1504 diff = 310.100098'
});
data_peak.push({
lat: 3.5573888891e+01,
lng: 1.3818311111e+02,
cert : true,
content:'Name = Shiomidake(JA/SO-006) peak = 3042.199951 pos = 35.5739,138.1831 diff = 501.500000'
});
data_saddle.push({
lat: 3.5599444446e+01,
lng: 1.3820033333e+02,
content:'Saddle = 2540.699951 pos = 35.5994,138.2003 diff = 501.500000'
});
data_peak.push({
lat: 3.5625000002e+01,
lng: 1.3822955556e+02,
cert : true,
content:'Name = Noutoridake (Nishinoutoridake)(JA/SO-005) peak = 3053.300049 pos = 35.6250,138.2296 diff = 266.000000'
});
data_saddle.push({
lat: 3.5634333335e+01,
lng: 1.3823022222e+02,
content:'Saddle = 2787.300049 pos = 35.6343,138.2302 diff = 266.000000'
});
data_peak.push({
lat: 3.5645777779e+01,
lng: 1.3822911111e+02,
cert : true,
content:'Name = Ainodake(JA/YN-002) peak = 3181.399902 pos = 35.6458,138.2291 diff = 293.899902'
});
data_saddle.push({
lat: 3.5664444446e+01,
lng: 1.3823266667e+02,
content:'Saddle = 2887.500000 pos = 35.6644,138.2327 diff = 293.899902'
});
data_peak.push({
lat: 3.5426000002e+01,
lng: 1.3910566667e+02,
cert : false,
content:' Peak = 1175.900024 pos = 35.4260,139.1057 diff = 217.300049'
});
data_saddle.push({
lat: 3.5443444447e+01,
lng: 1.3912733333e+02,
content:'Saddle = 958.599976 pos = 35.4434,139.1273 diff = 217.300049'
});
data_peak.push({
lat: 3.5970888889e+01,
lng: 1.3837011111e+02,
cert : true,
content:'Name = Akadake(JA/YN-006) peak = 2894.800049 pos = 35.9709,138.3701 diff = 1910.500000'
});
data_saddle.push({
lat: 3.5446444447e+01,
lng: 1.3861111111e+02,
content:'Saddle = 984.299988 pos = 35.4464,138.6111 diff = 1910.500000'
});
data_peak.push({
lat: 3.5830000001e+01,
lng: 1.3910177778e+02,
cert : true,
content:'Name = Honitayama(JA/TK-008) peak = 1222.599976 pos = 35.8300,139.1018 diff = 230.000000'
});
data_saddle.push({
lat: 3.5838000001e+01,
lng: 1.3910666667e+02,
content:'Saddle = 992.599976 pos = 35.8380,139.1067 diff = 230.000000'
});
data_peak.push({
lat: 3.6000000000e+01,
lng: 1.3876211111e+02,
cert : false,
content:' Peak = 1316.300049 pos = 36.0000,138.7621 diff = 277.000000'
});
data_saddle.push({
lat: 3.6000000000e+01,
lng: 1.3875433333e+02,
content:'Saddle = 1039.300049 pos = 36.0000,138.7543 diff = 277.000000'
});
data_peak.push({
lat: 3.5548333335e+01,
lng: 1.3861555556e+02,
cert : false,
content:' Peak = 1244.599976 pos = 35.5483,138.6156 diff = 202.599976'
});
data_saddle.push({
lat: 3.5560333335e+01,
lng: 1.3864022222e+02,
content:'Saddle = 1042.000000 pos = 35.5603,138.6402 diff = 202.599976'
});
data_peak.push({
lat: 3.5667888890e+01,
lng: 1.3902133333e+02,
cert : true,
content:'Name = Gongenyama(JA/YN-054) peak = 1311.199951 pos = 35.6679,139.0213 diff = 268.099976'
});
data_saddle.push({
lat: 3.5694222223e+01,
lng: 1.3898022222e+02,
content:'Saddle = 1043.099976 pos = 35.6942,138.9802 diff = 268.099976'
});
data_peak.push({
lat: 3.5562111113e+01,
lng: 1.3865255556e+02,
cert : false,
content:' Peak = 1235.099976 pos = 35.5621,138.6526 diff = 167.000000'
});
data_saddle.push({
lat: 3.5563000002e+01,
lng: 1.3867655556e+02,
content:'Saddle = 1068.099976 pos = 35.5630,138.6766 diff = 167.000000'
});
data_peak.push({
lat: 3.5415777780e+01,
lng: 1.3854366667e+02,
cert : true,
content:'Name = Kenashiyama(JA/SO-019) peak = 1962.000000 pos = 35.4158,138.5437 diff = 891.599976'
});
data_saddle.push({
lat: 3.5476000002e+01,
lng: 1.3857266667e+02,
content:'Saddle = 1070.400024 pos = 35.4760,138.5727 diff = 891.599976'
});
data_peak.push({
lat: 3.5340333336e+01,
lng: 1.3852200000e+02,
cert : false,
content:' Peak = 1300.400024 pos = 35.3403,138.5220 diff = 162.800049'
});
data_saddle.push({
lat: 3.5344000003e+01,
lng: 1.3852700000e+02,
content:'Saddle = 1137.599976 pos = 35.3440,138.5270 diff = 162.800049'
});
data_peak.push({
lat: 3.5446777780e+01,
lng: 1.3858355556e+02,
cert : false,
content:' Peak = 1484.199951 pos = 35.4468,138.5836 diff = 231.799927'
});
data_saddle.push({
lat: 3.5439666669e+01,
lng: 1.3857122222e+02,
content:'Saddle = 1252.400024 pos = 35.4397,138.5712 diff = 231.799927'
});
data_peak.push({
lat: 3.5381333336e+01,
lng: 1.3851255556e+02,
cert : true,
content:'Name = JA/YN-042(JA/YN-042) peak = 1633.500000 pos = 35.3813,138.5126 diff = 270.599976'
});
data_saddle.push({
lat: 3.5382666669e+01,
lng: 1.3853066667e+02,
content:'Saddle = 1362.900024 pos = 35.3827,138.5307 diff = 270.599976'
});
data_peak.push({
lat: 3.5519000002e+01,
lng: 1.3853577778e+02,
cert : true,
content:'Name = JA/YN-056(JA/YN-056) peak = 1272.099976 pos = 35.5190,138.5358 diff = 183.299927'
});
data_saddle.push({
lat: 3.5517777780e+01,
lng: 1.3858555556e+02,
content:'Saddle = 1088.800049 pos = 35.5178,138.5856 diff = 183.299927'
});
data_peak.push({
lat: 3.5552111113e+01,
lng: 1.3874933333e+02,
cert : false,
content:' Peak = 1792.099976 pos = 35.5521,138.7493 diff = 693.400024'
});
data_saddle.push({
lat: 3.5613111113e+01,
lng: 1.3878000000e+02,
content:'Saddle = 1098.699951 pos = 35.6131,138.7800 diff = 693.400024'
});
data_peak.push({
lat: 3.5504777780e+01,
lng: 1.3860255556e+02,
cert : true,
content:'Name = JA/YN-051(JA/YN-051) peak = 1420.900024 pos = 35.5048,138.6026 diff = 233.500000'
});
data_saddle.push({
lat: 3.5504000002e+01,
lng: 1.3861022222e+02,
content:'Saddle = 1187.400024 pos = 35.5040,138.6102 diff = 233.500000'
});
data_peak.push({
lat: 3.5580888891e+01,
lng: 1.3869977778e+02,
cert : false,
content:' Peak = 1413.500000 pos = 35.5809,138.6998 diff = 202.699951'
});
data_saddle.push({
lat: 3.5570222224e+01,
lng: 1.3870455556e+02,
content:'Saddle = 1210.800049 pos = 35.5702,138.7046 diff = 202.699951'
});
data_peak.push({
lat: 3.5605888890e+01,
lng: 1.3875922222e+02,
cert : true,
content:'Name = JA/YN-046(JA/YN-046) peak = 1485.500000 pos = 35.6059,138.7592 diff = 198.699951'
});
data_saddle.push({
lat: 3.5597333335e+01,
lng: 1.3877122222e+02,
content:'Saddle = 1286.800049 pos = 35.5973,138.7712 diff = 198.699951'
});
data_peak.push({
lat: 3.5549333335e+01,
lng: 1.3880911111e+02,
cert : true,
content:'Name = Mitsutougeyama(JA/YN-032) peak = 1783.699951 pos = 35.5493,138.8091 diff = 356.099976'
});
data_saddle.push({
lat: 3.5559222224e+01,
lng: 1.3878066667e+02,
content:'Saddle = 1427.599976 pos = 35.5592,138.7807 diff = 356.099976'
});
data_peak.push({
lat: 3.5574888891e+01,
lng: 1.3880733333e+02,
cert : true,
content:'Name = JA/YN-043(JA/YN-043) peak = 1630.500000 pos = 35.5749,138.8073 diff = 177.699951'
});
data_saddle.push({
lat: 3.5566111113e+01,
lng: 1.3879922222e+02,
content:'Saddle = 1452.800049 pos = 35.5661,138.7992 diff = 177.699951'
});
data_peak.push({
lat: 3.5562888891e+01,
lng: 1.3872088889e+02,
cert : false,
content:' Peak = 1640.300049 pos = 35.5629,138.7209 diff = 188.100098'
});
data_saddle.push({
lat: 3.5561777780e+01,
lng: 1.3873955556e+02,
content:'Saddle = 1452.199951 pos = 35.5618,138.7396 diff = 188.100098'
});
data_peak.push({
lat: 3.5528555557e+01,
lng: 1.3868333333e+02,
cert : false,
content:' Peak = 1735.400024 pos = 35.5286,138.6833 diff = 224.300049'
});
data_saddle.push({
lat: 3.5535777780e+01,
lng: 1.3870288889e+02,
content:'Saddle = 1511.099976 pos = 35.5358,138.7029 diff = 224.300049'
});
data_peak.push({
lat: 3.5622111113e+01,
lng: 1.3881333333e+02,
cert : true,
content:'Name = JA/YN-050(JA/YN-050) peak = 1433.699951 pos = 35.6221,138.8133 diff = 303.899902'
});
data_saddle.push({
lat: 3.5627888890e+01,
lng: 1.3881877778e+02,
content:'Saddle = 1129.800049 pos = 35.6279,138.8188 diff = 303.899902'
});
data_peak.push({
lat: 3.5775777779e+01,
lng: 1.3854244444e+02,
cert : false,
content:' Peak = 1321.699951 pos = 35.7758,138.5424 diff = 159.099976'
});
data_saddle.push({
lat: 3.5781333334e+01,
lng: 1.3854433333e+02,
content:'Saddle = 1162.599976 pos = 35.7813,138.5443 diff = 159.099976'
});
data_peak.push({
lat: 3.5850777778e+01,
lng: 1.3910688889e+02,
cert : false,
content:' Peak = 1362.199951 pos = 35.8508,139.1069 diff = 185.500000'
});
data_saddle.push({
lat: 3.5859333334e+01,
lng: 1.3910188889e+02,
content:'Saddle = 1176.699951 pos = 35.8593,139.1019 diff = 185.500000'
});
data_peak.push({
lat: 3.5778222223e+01,
lng: 1.3858811111e+02,
cert : true,
content:'Name = JA/YN-048(JA/YN-048) peak = 1474.000000 pos = 35.7782,138.5881 diff = 191.699951'
});
data_saddle.push({
lat: 3.5783000001e+01,
lng: 1.3859222222e+02,
content:'Saddle = 1282.300049 pos = 35.7830,138.5922 diff = 191.699951'
});
data_peak.push({
lat: 3.5767444445e+01,
lng: 1.3888811111e+02,
cert : false,
content:' Peak = 1540.900024 pos = 35.7674,138.8881 diff = 178.900024'
});
data_saddle.push({
lat: 3.5759888890e+01,
lng: 1.3887600000e+02,
content:'Saddle = 1362.000000 pos = 35.7599,138.8760 diff = 178.900024'
});
data_peak.push({
lat: 3.5758444445e+01,
lng: 1.3860477778e+02,
cert : true,
content:'Name = JA/YN-045(JA/YN-045) peak = 1552.800049 pos = 35.7584,138.6048 diff = 189.400024'
});
data_saddle.push({
lat: 3.5770777779e+01,
lng: 1.3860977778e+02,
content:'Saddle = 1363.400024 pos = 35.7708,138.6098 diff = 189.400024'
});
data_peak.push({
lat: 3.5803222223e+01,
lng: 1.3850933333e+02,
cert : true,
content:'Name = JA/YN-035(JA/YN-035) peak = 1763.599976 pos = 35.8032,138.5093 diff = 391.299927'
});
data_saddle.push({
lat: 3.5805666667e+01,
lng: 1.3852388889e+02,
content:'Saddle = 1372.300049 pos = 35.8057,138.5239 diff = 391.299927'
});
data_peak.push({
lat: 3.5868666667e+01,
lng: 1.3867066667e+02,
cert : true,
content:'Name = Kitaokusenjyoudake(JA/YN-012) peak = 2600.699951 pos = 35.8687,138.6707 diff = 1224.500000'
});
data_saddle.push({
lat: 3.5944777778e+01,
lng: 1.3845211111e+02,
content:'Saddle = 1376.199951 pos = 35.9448,138.4521 diff = 1224.500000'
});
data_peak.push({
lat: 3.5816666667e+01,
lng: 1.3883922222e+02,
cert : true,
content:'Name = JA/YN-044(JA/YN-044) peak = 1605.300049 pos = 35.8167,138.8392 diff = 226.900024'
});
data_saddle.push({
lat: 3.5822777778e+01,
lng: 1.3883066667e+02,
content:'Saddle = 1378.400024 pos = 35.8228,138.8307 diff = 226.900024'
});
data_peak.push({
lat: 3.5961555556e+01,
lng: 1.3858411111e+02,
cert : true,
content:'Name = JA/NN-104(JA/NN-104) peak = 1662.800049 pos = 35.9616,138.5841 diff = 231.500000'
});
data_saddle.push({
lat: 3.5950777778e+01,
lng: 1.3858511111e+02,
content:'Saddle = 1431.300049 pos = 35.9508,138.5851 diff = 231.500000'
});
data_peak.push({
lat: 3.5918777778e+01,
lng: 1.3852111111e+02,
cert : true,
content:'Name = Yokooyama(JA/YN-030) peak = 1814.400024 pos = 35.9188,138.5211 diff = 347.500000'
});
data_saddle.push({
lat: 3.5915111111e+01,
lng: 1.3854233333e+02,
content:'Saddle = 1466.900024 pos = 35.9151,138.5423 diff = 347.500000'
});
data_peak.push({
lat: 3.5938555556e+01,
lng: 1.3852433333e+02,
cert : false,
content:' Peak = 1731.500000 pos = 35.9386,138.5243 diff = 169.699951'
});
data_saddle.push({
lat: 3.5932666667e+01,
lng: 1.3852000000e+02,
content:'Saddle = 1561.800049 pos = 35.9327,138.5200 diff = 169.699951'
});
data_peak.push({
lat: 3.5748777779e+01,
lng: 1.3884544444e+02,
cert : true,
content:'Name = Daibosatsurei(JA/YN-024) peak = 2056.399902 pos = 35.7488,138.8454 diff = 579.499878'
});
data_saddle.push({
lat: 3.5777111112e+01,
lng: 1.3880211111e+02,
content:'Saddle = 1476.900024 pos = 35.7771,138.8021 diff = 579.499878'
});
data_peak.push({
lat: 3.5788555556e+01,
lng: 1.3883555556e+02,
cert : false,
content:' Peak = 1714.000000 pos = 35.7886,138.8356 diff = 157.500000'
});
data_saddle.push({
lat: 3.5787333334e+01,
lng: 1.3882644444e+02,
content:'Saddle = 1556.500000 pos = 35.7873,138.8264 diff = 157.500000'
});
data_peak.push({
lat: 3.5686777779e+01,
lng: 1.3888477778e+02,
cert : false,
content:' Peak = 1873.099976 pos = 35.6868,138.8848 diff = 311.900024'
});
data_saddle.push({
lat: 3.5687111112e+01,
lng: 1.3887766667e+02,
content:'Saddle = 1561.199951 pos = 35.6871,138.8777 diff = 311.900024'
});
data_peak.push({
lat: 3.5811777779e+01,
lng: 1.3878311111e+02,
cert : true,
content:'Name = JA/YN-033(JA/YN-033) peak = 1773.599976 pos = 35.8118,138.7831 diff = 285.699951'
});
data_saddle.push({
lat: 3.5831111112e+01,
lng: 1.3878777778e+02,
content:'Saddle = 1487.900024 pos = 35.8311,138.7878 diff = 285.699951'
});
data_peak.push({
lat: 3.5874444445e+01,
lng: 1.3857200000e+02,
cert : false,
content:' Peak = 1703.099976 pos = 35.8744,138.5720 diff = 185.699951'
});
data_saddle.push({
lat: 3.5876000000e+01,
lng: 1.3857811111e+02,
content:'Saddle = 1517.400024 pos = 35.8760,138.5781 diff = 185.699951'
});
data_peak.push({
lat: 3.5781666668e+01,
lng: 1.3866411111e+02,
cert : true,
content:'Name = Konarayama(JA/YN-037) peak = 1712.099976 pos = 35.7817,138.6641 diff = 183.699951'
});
data_saddle.push({
lat: 3.5796333334e+01,
lng: 1.3864888889e+02,
content:'Saddle = 1528.400024 pos = 35.7963,138.6489 diff = 183.699951'
});
data_peak.push({
lat: 3.5864555556e+01,
lng: 1.3898988889e+02,
cert : false,
content:' Peak = 1722.199951 pos = 35.8646,138.9899 diff = 180.500000'
});
data_saddle.push({
lat: 3.5871000001e+01,
lng: 1.3898388889e+02,
content:'Saddle = 1541.699951 pos = 35.8710,138.9839 diff = 180.500000'
});
data_peak.push({
lat: 3.5897111112e+01,
lng: 1.3901022222e+02,
cert : true,
content:'Name = Toridaniyama(JA/TK-004) peak = 1716.900024 pos = 35.8971,139.0102 diff = 166.800049'
});
data_saddle.push({
lat: 3.5891000000e+01,
lng: 1.3900644444e+02,
content:'Saddle = 1550.099976 pos = 35.8910,139.0064 diff = 166.800049'
});
data_peak.push({
lat: 3.5829888890e+01,
lng: 1.3901233333e+02,
cert : true,
content:'Name = Takanosuyama(JA/TK-003) peak = 1734.699951 pos = 35.8299,139.0123 diff = 181.599976'
});
data_saddle.push({
lat: 3.5828222223e+01,
lng: 1.3900200000e+02,
content:'Saddle = 1553.099976 pos = 35.8282,139.0020 diff = 181.599976'
});
data_peak.push({
lat: 3.5828777778e+01,
lng: 1.3857177778e+02,
cert : true,
content:'Name = JA/YN-034(JA/YN-034) peak = 1773.900024 pos = 35.8288,138.5718 diff = 181.400024'
});
data_saddle.push({
lat: 3.5829222223e+01,
lng: 1.3858055556e+02,
content:'Saddle = 1592.500000 pos = 35.8292,138.5806 diff = 181.400024'
});
data_peak.push({
lat: 3.5991777778e+01,
lng: 1.3856900000e+02,
cert : true,
content:'Name = JA/NN-081(JA/NN-081) peak = 1880.699951 pos = 35.9918,138.5690 diff = 268.399902'
});
data_saddle.push({
lat: 3.5991444444e+01,
lng: 1.3862600000e+02,
content:'Saddle = 1612.300049 pos = 35.9914,138.6260 diff = 268.399902'
});
data_peak.push({
lat: 3.5991111111e+01,
lng: 1.3860100000e+02,
cert : true,
content:'Name = JA/NN-087(JA/NN-087) peak = 1821.500000 pos = 35.9911,138.6010 diff = 204.400024'
});
data_saddle.push({
lat: 3.5993222222e+01,
lng: 1.3857866667e+02,
content:'Saddle = 1617.099976 pos = 35.9932,138.5787 diff = 204.400024'
});
data_peak.push({
lat: 3.5993888889e+01,
lng: 1.3854744444e+02,
cert : false,
content:' Peak = 1853.500000 pos = 35.9939,138.5474 diff = 160.800049'
});
data_saddle.push({
lat: 3.5993555556e+01,
lng: 1.3856277778e+02,
content:'Saddle = 1692.699951 pos = 35.9936,138.5628 diff = 160.800049'
});
data_peak.push({
lat: 3.5960666667e+01,
lng: 1.3877433333e+02,
cert : false,
content:' Peak = 1815.900024 pos = 35.9607,138.7743 diff = 182.800049'
});
data_saddle.push({
lat: 3.5958777778e+01,
lng: 1.3876477778e+02,
content:'Saddle = 1633.099976 pos = 35.9588,138.7648 diff = 182.800049'
});
data_peak.push({
lat: 3.5874111112e+01,
lng: 1.3895422222e+02,
cert : true,
content:'Name = Imotokinodokke(JA/TK-002) peak = 1944.800049 pos = 35.8741,138.9542 diff = 241.900024'
});
data_saddle.push({
lat: 3.5866222223e+01,
lng: 1.3894566667e+02,
content:'Saddle = 1702.900024 pos = 35.8662,138.9457 diff = 241.900024'
});
data_peak.push({
lat: 3.5991777778e+01,
lng: 1.3868888889e+02,
cert : true,
content:'Name = JA/NN-071(JA/NN-071) peak = 1976.800049 pos = 35.9918,138.6889 diff = 254.900024'
});
data_saddle.push({
lat: 3.5976888889e+01,
lng: 1.3871177778e+02,
content:'Saddle = 1721.900024 pos = 35.9769,138.7118 diff = 254.900024'
});
data_peak.push({
lat: 3.5855555556e+01,
lng: 1.3894388889e+02,
cert : true,
content:'Name = Kumotoriyama(JA/TK-001) peak = 2015.699951 pos = 35.8556,138.9439 diff = 273.500000'
});
data_saddle.push({
lat: 3.5850666667e+01,
lng: 1.3892100000e+02,
content:'Saddle = 1742.199951 pos = 35.8507,138.9210 diff = 273.500000'
});
data_peak.push({
lat: 3.5867777778e+01,
lng: 1.3884533333e+02,
cert : true,
content:'Name = Karamatsuoyama(JA/YN-022) peak = 2108.199951 pos = 35.8678,138.8453 diff = 325.500000'
});
data_saddle.push({
lat: 3.5864777778e+01,
lng: 1.3881111111e+02,
content:'Saddle = 1782.699951 pos = 35.8648,138.8111 diff = 325.500000'
});
data_peak.push({
lat: 3.5839888890e+01,
lng: 1.3889222222e+02,
cert : true,
content:'Name = Ooborayama (Hiryuuyama)(JA/YN-023) peak = 2074.300049 pos = 35.8399,138.8922 diff = 277.200073'
});
data_saddle.push({
lat: 3.5859000001e+01,
lng: 1.3886255556e+02,
content:'Saddle = 1797.099976 pos = 35.8590,138.8626 diff = 277.200073'
});
data_peak.push({
lat: 3.5855000001e+01,
lng: 1.3887222222e+02,
cert : false,
content:' Peak = 2011.000000 pos = 35.8550,138.8722 diff = 187.900024'
});
data_saddle.push({
lat: 3.5844444445e+01,
lng: 1.3888755556e+02,
content:'Saddle = 1823.099976 pos = 35.8444,138.8876 diff = 187.900024'
});
data_peak.push({
lat: 3.5841333334e+01,
lng: 1.3870977778e+02,
cert : true,
content:'Name = JA/YN-018(JA/YN-018) peak = 2231.300049 pos = 35.8413,138.7098 diff = 268.300049'
});
data_saddle.push({
lat: 3.5837000001e+01,
lng: 1.3869700000e+02,
content:'Saddle = 1963.000000 pos = 35.8370,138.6970 diff = 268.300049'
});
data_peak.push({
lat: 3.5909444445e+01,
lng: 1.3861255556e+02,
cert : true,
content:'Name = JA/NN-036(JA/NN-036) peak = 2413.199951 pos = 35.9094,138.6126 diff = 360.699951'
});
data_saddle.push({
lat: 3.5886444445e+01,
lng: 1.3860611111e+02,
content:'Saddle = 2052.500000 pos = 35.8864,138.6061 diff = 360.699951'
});
data_peak.push({
lat: 3.5901888889e+01,
lng: 1.3875866667e+02,
cert : true,
content:'Name = JA/YN-017(JA/YN-017) peak = 2316.699951 pos = 35.9019,138.7587 diff = 233.800049'
});
data_saddle.push({
lat: 3.5902111112e+01,
lng: 1.3875066667e+02,
content:'Saddle = 2082.899902 pos = 35.9021,138.7507 diff = 233.800049'
});
data_peak.push({
lat: 3.5917888889e+01,
lng: 1.3872744444e+02,
cert : true,
content:'Name = Sanpouyama(JA/ST-001) peak = 2483.899902 pos = 35.9179,138.7274 diff = 332.000000'
});
data_saddle.push({
lat: 3.5889333334e+01,
lng: 1.3868455556e+02,
content:'Saddle = 2151.899902 pos = 35.8893,138.6846 diff = 332.000000'
});
data_peak.push({
lat: 3.5871666667e+01,
lng: 1.3862544444e+02,
cert : true,
content:'Name = Kinpusan(JA/YN-013) peak = 2597.899902 pos = 35.8717,138.6254 diff = 234.899902'
});
data_saddle.push({
lat: 3.5873222223e+01,
lng: 1.3866255556e+02,
content:'Saddle = 2363.000000 pos = 35.8732,138.6626 diff = 234.899902'
});
data_peak.push({
lat: 3.5949888889e+01,
lng: 1.3835966667e+02,
cert : true,
content:'Name = Gongendake(JA/YN-009) peak = 2708.399902 pos = 35.9499,138.3597 diff = 256.699951'
});
data_saddle.push({
lat: 3.5964000000e+01,
lng: 1.3836333333e+02,
content:'Saddle = 2451.699951 pos = 35.9640,138.3633 diff = 256.699951'
});
data_peak.push({
lat: 3.5972555556e+01,
lng: 1.3835866667e+02,
cert : false,
content:' Peak = 2802.399902 pos = 35.9726,138.3587 diff = 160.899902'
});
data_saddle.push({
lat: 3.5972000000e+01,
lng: 1.3836133333e+02,
content:'Saddle = 2641.500000 pos = 35.9720,138.3613 diff = 160.899902'
});
data_peak.push({
lat: 3.5494222224e+01,
lng: 1.3870755556e+02,
cert : true,
content:'Name = JA/YN-053(JA/YN-053) peak = 1353.900024 pos = 35.4942,138.7076 diff = 345.600037'
});
data_saddle.push({
lat: 3.5481444447e+01,
lng: 1.3867266667e+02,
content:'Saddle = 1008.299988 pos = 35.4814,138.6727 diff = 345.600037'
});
data_peak.push({
lat: 3.5487000002e+01,
lng: 1.3893155556e+02,
cert : true,
content:'Name = Mishoutaiyama(JA/YN-038) peak = 1681.300049 pos = 35.4870,138.9316 diff = 633.400024'
});
data_saddle.push({
lat: 3.5428333336e+01,
lng: 1.3892966667e+02,
content:'Saddle = 1047.900024 pos = 35.4283,138.9297 diff = 633.400024'
});
data_peak.push({
lat: 3.5486333335e+01,
lng: 1.3913888889e+02,
cert : true,
content:'Name = Tanzawasan (Hirugatake)(JA/KN-001) peak = 1672.500000 pos = 35.4863,139.1389 diff = 611.099976'
});
data_saddle.push({
lat: 3.5495111113e+01,
lng: 1.3907733333e+02,
content:'Saddle = 1061.400024 pos = 35.4951,139.0773 diff = 611.099976'
});
data_peak.push({
lat: 3.5479000002e+01,
lng: 1.3910266667e+02,
cert : true,
content:'Name = Hinokiboramaru(JA/KN-002) peak = 1600.699951 pos = 35.4790,139.1027 diff = 343.599976'
});
data_saddle.push({
lat: 3.5477222224e+01,
lng: 1.3912077778e+02,
content:'Saddle = 1257.099976 pos = 35.4772,139.1208 diff = 343.599976'
});
data_peak.push({
lat: 3.5465888891e+01,
lng: 1.3910455556e+02,
cert : false,
content:' Peak = 1490.599976 pos = 35.4659,139.1046 diff = 167.900024'
});
data_saddle.push({
lat: 3.5471111113e+01,
lng: 1.3910122222e+02,
content:'Saddle = 1322.699951 pos = 35.4711,139.1012 diff = 167.900024'
});
data_peak.push({
lat: 3.5544333335e+01,
lng: 1.3902444444e+02,
cert : false,
content:' Peak = 1298.199951 pos = 35.5443,139.0244 diff = 226.000000'
});
data_saddle.push({
lat: 3.5534444446e+01,
lng: 1.3900644444e+02,
content:'Saddle = 1072.199951 pos = 35.5344,139.0064 diff = 226.000000'
});
data_peak.push({
lat: 3.5508111113e+01,
lng: 1.3885577778e+02,
cert : false,
content:' Peak = 1254.900024 pos = 35.5081,138.8558 diff = 162.200073'
});
data_saddle.push({
lat: 3.5499444446e+01,
lng: 1.3885677778e+02,
content:'Saddle = 1092.699951 pos = 35.4994,138.8568 diff = 162.200073'
});
data_peak.push({
lat: 3.5521888891e+01,
lng: 1.3896955556e+02,
cert : true,
content:'Name = JA/YN-047(JA/YN-047) peak = 1482.099976 pos = 35.5219,138.9696 diff = 369.099976'
});
data_saddle.push({
lat: 3.5510000002e+01,
lng: 1.3897088889e+02,
content:'Saddle = 1113.000000 pos = 35.5100,138.9709 diff = 369.099976'
});
data_peak.push({
lat: 3.5510888891e+01,
lng: 1.3906833333e+02,
cert : true,
content:'Name = Oomuroyama(JA/KN-003) peak = 1586.400024 pos = 35.5109,139.0683 diff = 463.599976'
});
data_saddle.push({
lat: 3.5481222224e+01,
lng: 1.3902488889e+02,
content:'Saddle = 1122.800049 pos = 35.4812,139.0249 diff = 463.599976'
});
data_peak.push({
lat: 3.5463777780e+01,
lng: 1.3897844444e+02,
cert : true,
content:'Name = Komotsurushiyama(JA/KN-005) peak = 1375.500000 pos = 35.4638,138.9784 diff = 233.599976'
});
data_saddle.push({
lat: 3.5451888891e+01,
lng: 1.3893188889e+02,
content:'Saddle = 1141.900024 pos = 35.4519,138.9319 diff = 233.599976'
});
data_peak.push({
lat: 3.5485777780e+01,
lng: 1.3887622222e+02,
cert : true,
content:'Name = JA/YN-041(JA/YN-041) peak = 1640.199951 pos = 35.4858,138.8762 diff = 487.500000'
});
data_saddle.push({
lat: 3.5457111113e+01,
lng: 1.3889255556e+02,
content:'Saddle = 1152.699951 pos = 35.4571,138.8926 diff = 487.500000'
});
data_peak.push({
lat: 3.5389666669e+01,
lng: 1.3889177778e+02,
cert : true,
content:'Name = JA/SO-031(JA/SO-031) peak = 1382.800049 pos = 35.3897,138.8918 diff = 274.700073'
});
data_saddle.push({
lat: 3.5393333336e+01,
lng: 1.3886377778e+02,
content:'Saddle = 1108.099976 pos = 35.3933,138.8638 diff = 274.700073'
});
data_peak.push({
lat: 3.5440888891e+01,
lng: 1.3865355556e+02,
cert : false,
content:' Peak = 1467.599976 pos = 35.4409,138.6536 diff = 203.500000'
});
data_saddle.push({
lat: 3.5434000002e+01,
lng: 1.3865644444e+02,
content:'Saddle = 1264.099976 pos = 35.4340,138.6564 diff = 203.500000'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:36,
       south:34.6667,
       east:141,
       west:137}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
