function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.9099444445e+01,
lng: 1.4004877778e+02,
cert : true,
content:'Name = Chyoukaizan (Shinzan)(JA/YM-001) peak = 2234.899902 pos = 39.0994,140.0488 diff = 2234.899902'
});
data_saddle.push({
lat: 3.9293000000e+01,
lng: 1.3995800000e+02,
content:'Saddle = 0.000000 pos = 39.2930,139.9580 diff = 2234.899902'
});
data_peak.push({
lat: 3.8453888889e+01,
lng: 1.3923844444e+02,
cert : false,
content:' Peak = 264.799988 pos = 38.4539,139.2384 diff = 264.799988'
});
data_saddle.push({
lat: 3.8436000000e+01,
lng: 1.3922300000e+02,
content:'Saddle = 0.000000 pos = 38.4360,139.2230 diff = 264.799988'
});
data_peak.push({
lat: 3.8736333334e+01,
lng: 1.3971088889e+02,
cert : true,
content:'Name = JA/YM-110(JA/YM-110) peak = 306.600006 pos = 38.7363,139.7109 diff = 230.100006'
});
data_saddle.push({
lat: 3.8719777778e+01,
lng: 1.3970888889e+02,
content:'Saddle = 76.500000 pos = 38.7198,139.7089 diff = 230.100006'
});
data_peak.push({
lat: 3.8763000000e+01,
lng: 1.3974744444e+02,
cert : true,
content:'Name = Takadateyama(JA/YM-111) peak = 273.700012 pos = 38.7630,139.7474 diff = 174.700012'
});
data_saddle.push({
lat: 3.8737777778e+01,
lng: 1.3972666667e+02,
content:'Saddle = 99.000000 pos = 38.7378,139.7267 diff = 174.700012'
});
data_peak.push({
lat: 3.8127777778e+01,
lng: 1.3951433333e+02,
cert : true,
content:'Name = JA/NI-131(JA/NI-131) peak = 437.299988 pos = 38.1278,139.5143 diff = 331.000000'
});
data_saddle.push({
lat: 3.8147777778e+01,
lng: 1.3952644444e+02,
content:'Saddle = 106.300003 pos = 38.1478,139.5264 diff = 331.000000'
});
data_peak.push({
lat: 3.8020666667e+01,
lng: 1.3942755556e+02,
cert : true,
content:'Name = JA/NI-111(JA/NI-111) peak = 567.000000 pos = 38.0207,139.4276 diff = 452.500000'
});
data_saddle.push({
lat: 3.8030666667e+01,
lng: 1.3946966667e+02,
content:'Saddle = 114.500000 pos = 38.0307,139.4697 diff = 452.500000'
});
data_peak.push({
lat: 3.8079000000e+01,
lng: 1.3948322222e+02,
cert : false,
content:' Peak = 573.500000 pos = 38.0790,139.4832 diff = 445.100006'
});
data_saddle.push({
lat: 3.8049111112e+01,
lng: 1.3949077778e+02,
content:'Saddle = 128.399994 pos = 38.0491,139.4908 diff = 445.100006'
});
data_peak.push({
lat: 3.8613111111e+01,
lng: 1.3958811111e+02,
cert : false,
content:' Peak = 290.299988 pos = 38.6131,139.5881 diff = 152.099991'
});
data_saddle.push({
lat: 3.8608444445e+01,
lng: 1.3959733333e+02,
content:'Saddle = 138.199997 pos = 38.6084,139.5973 diff = 152.099991'
});
data_peak.push({
lat: 3.8831666667e+01,
lng: 1.4020000000e+02,
cert : true,
content:'Name = JA/YM-109(JA/YM-109) peak = 321.799988 pos = 38.8317,140.2000 diff = 183.599991'
});
data_saddle.push({
lat: 3.8842000000e+01,
lng: 1.4020322222e+02,
content:'Saddle = 138.199997 pos = 38.8420,140.2032 diff = 183.599991'
});
data_peak.push({
lat: 3.8000111112e+01,
lng: 1.3950555556e+02,
cert : false,
content:' Peak = 419.000000 pos = 38.0001,139.5056 diff = 273.399994'
});
data_saddle.push({
lat: 3.8000444445e+01,
lng: 1.3952433333e+02,
content:'Saddle = 145.600006 pos = 38.0004,139.5243 diff = 273.399994'
});
data_peak.push({
lat: 3.8000111112e+01,
lng: 1.3951344444e+02,
cert : false,
content:' Peak = 411.500000 pos = 38.0001,139.5134 diff = 174.699997'
});
data_saddle.push({
lat: 3.8000222223e+01,
lng: 1.3950988889e+02,
content:'Saddle = 236.800003 pos = 38.0002,139.5099 diff = 174.699997'
});
data_peak.push({
lat: 3.8459444445e+01,
lng: 1.3958411111e+02,
cert : true,
content:'Name = JA/NI-132(JA/NI-132) peak = 410.799988 pos = 38.4594,139.5841 diff = 232.399994'
});
data_saddle.push({
lat: 3.8453444445e+01,
lng: 1.3959633333e+02,
content:'Saddle = 178.399994 pos = 38.4534,139.5963 diff = 232.399994'
});
data_peak.push({
lat: 3.8471000000e+01,
lng: 1.3957588889e+02,
cert : false,
content:' Peak = 403.799988 pos = 38.4710,139.5759 diff = 151.099991'
});
data_saddle.push({
lat: 3.8467333334e+01,
lng: 1.3958133333e+02,
content:'Saddle = 252.699997 pos = 38.4673,139.5813 diff = 151.099991'
});
data_peak.push({
lat: 3.9328888889e+01,
lng: 1.4015877778e+02,
cert : false,
content:' Peak = 356.799988 pos = 39.3289,140.1588 diff = 171.399994'
});
data_saddle.push({
lat: 3.9309555556e+01,
lng: 1.4016811111e+02,
content:'Saddle = 185.399994 pos = 39.3096,140.1681 diff = 171.399994'
});
data_peak.push({
lat: 3.8000444445e+01,
lng: 1.3964022222e+02,
cert : false,
content:' Peak = 970.900024 pos = 38.0004,139.6402 diff = 784.900024'
});
data_saddle.push({
lat: 3.8000111112e+01,
lng: 1.3967655556e+02,
content:'Saddle = 186.000000 pos = 38.0001,139.6766 diff = 784.900024'
});
data_peak.push({
lat: 3.8006888889e+01,
lng: 1.3956166667e+02,
cert : false,
content:' Peak = 686.599976 pos = 38.0069,139.5617 diff = 473.299988'
});
data_saddle.push({
lat: 3.8000111112e+01,
lng: 1.3958777778e+02,
content:'Saddle = 213.300003 pos = 38.0001,139.5878 diff = 473.299988'
});
data_peak.push({
lat: 3.8003000000e+01,
lng: 1.3953533333e+02,
cert : false,
content:' Peak = 503.700012 pos = 38.0030,139.5353 diff = 159.800018'
});
data_saddle.push({
lat: 3.8000333334e+01,
lng: 1.3953933333e+02,
content:'Saddle = 343.899994 pos = 38.0003,139.5393 diff = 159.800018'
});
data_peak.push({
lat: 3.8000111112e+01,
lng: 1.3955411111e+02,
cert : false,
content:' Peak = 665.000000 pos = 38.0001,139.5541 diff = 212.000000'
});
data_saddle.push({
lat: 3.8000111112e+01,
lng: 1.3956055556e+02,
content:'Saddle = 453.000000 pos = 38.0001,139.5606 diff = 212.000000'
});
data_peak.push({
lat: 3.8014555556e+01,
lng: 1.3953188889e+02,
cert : false,
content:' Peak = 615.900024 pos = 38.0146,139.5319 diff = 158.600037'
});
data_saddle.push({
lat: 3.8000111112e+01,
lng: 1.3954666667e+02,
content:'Saddle = 457.299988 pos = 38.0001,139.5467 diff = 158.600037'
});
data_peak.push({
lat: 3.8003555556e+01,
lng: 1.3957266667e+02,
cert : false,
content:' Peak = 656.299988 pos = 38.0036,139.5727 diff = 169.199982'
});
data_saddle.push({
lat: 3.8000111112e+01,
lng: 1.3956922222e+02,
content:'Saddle = 487.100006 pos = 38.0001,139.5692 diff = 169.199982'
});
data_peak.push({
lat: 3.8000111112e+01,
lng: 1.3959900000e+02,
cert : false,
content:' Peak = 584.799988 pos = 38.0001,139.5990 diff = 337.599976'
});
data_saddle.push({
lat: 3.8000333334e+01,
lng: 1.3961044444e+02,
content:'Saddle = 247.199997 pos = 38.0003,139.6104 diff = 337.599976'
});
data_peak.push({
lat: 3.8051333334e+01,
lng: 1.3964855556e+02,
cert : false,
content:' Peak = 628.099976 pos = 38.0513,139.6486 diff = 150.699982'
});
data_saddle.push({
lat: 3.8036666667e+01,
lng: 1.3965722222e+02,
content:'Saddle = 477.399994 pos = 38.0367,139.6572 diff = 150.699982'
});
data_peak.push({
lat: 3.8022000000e+01,
lng: 1.3960744444e+02,
cert : false,
content:' Peak = 800.400024 pos = 38.0220,139.6074 diff = 212.600037'
});
data_saddle.push({
lat: 3.8014000000e+01,
lng: 1.3961333333e+02,
content:'Saddle = 587.799988 pos = 38.0140,139.6133 diff = 212.600037'
});
data_peak.push({
lat: 3.8503111111e+01,
lng: 1.3958566667e+02,
cert : true,
content:'Name = JA/NI-121(JA/NI-121) peak = 512.000000 pos = 38.5031,139.5857 diff = 325.600006'
});
data_saddle.push({
lat: 3.8495000000e+01,
lng: 1.3960477778e+02,
content:'Saddle = 186.399994 pos = 38.4950,139.6048 diff = 325.600006'
});
data_peak.push({
lat: 3.8911222222e+01,
lng: 1.4029555556e+02,
cert : true,
content:'Name = JA/YM-108(JA/YM-108) peak = 380.500000 pos = 38.9112,140.2956 diff = 191.300003'
});
data_saddle.push({
lat: 3.8910888889e+01,
lng: 1.4031388889e+02,
content:'Saddle = 189.199997 pos = 38.9109,140.3139 diff = 191.300003'
});
data_peak.push({
lat: 3.8525222223e+01,
lng: 1.3959677778e+02,
cert : true,
content:'Name = JA/NI-112(JA/NI-112) peak = 553.599976 pos = 38.5252,139.5968 diff = 357.199982'
});
data_saddle.push({
lat: 3.8524777778e+01,
lng: 1.3960755556e+02,
content:'Saddle = 196.399994 pos = 38.5248,139.6076 diff = 357.199982'
});
data_peak.push({
lat: 3.8308333334e+01,
lng: 1.4039822222e+02,
cert : false,
content:' Peak = 370.200012 pos = 38.3083,140.3982 diff = 173.200012'
});
data_saddle.push({
lat: 3.8308555556e+01,
lng: 1.4040611111e+02,
content:'Saddle = 197.000000 pos = 38.3086,140.4061 diff = 173.200012'
});
data_peak.push({
lat: 3.8458333334e+01,
lng: 1.3953233333e+02,
cert : true,
content:'Name = JA/NI-125(JA/NI-125) peak = 488.200012 pos = 38.4583,139.5323 diff = 286.700012'
});
data_saddle.push({
lat: 3.8427444445e+01,
lng: 1.3957911111e+02,
content:'Saddle = 201.500000 pos = 38.4274,139.5791 diff = 286.700012'
});
data_peak.push({
lat: 3.8306777778e+01,
lng: 1.3958477778e+02,
cert : true,
content:'Name = JA/NI-133(JA/NI-133) peak = 410.500000 pos = 38.3068,139.5848 diff = 208.000000'
});
data_saddle.push({
lat: 3.8303222223e+01,
lng: 1.3959922222e+02,
content:'Saddle = 202.500000 pos = 38.3032,139.5992 diff = 208.000000'
});
data_peak.push({
lat: 3.8361222223e+01,
lng: 1.3951077778e+02,
cert : true,
content:'Name = Shinbodake(JA/NI-080) peak = 851.799988 pos = 38.3612,139.5108 diff = 642.199951'
});
data_saddle.push({
lat: 3.8382666667e+01,
lng: 1.3955611111e+02,
content:'Saddle = 209.600006 pos = 38.3827,139.5561 diff = 642.199951'
});
data_peak.push({
lat: 3.8272777778e+01,
lng: 1.3948788889e+02,
cert : true,
content:'Name = JA/NI-130(JA/NI-130) peak = 441.600006 pos = 38.2728,139.4879 diff = 177.500000'
});
data_saddle.push({
lat: 3.8284777778e+01,
lng: 1.3949800000e+02,
content:'Saddle = 264.100006 pos = 38.2848,139.4980 diff = 177.500000'
});
data_peak.push({
lat: 3.8345000000e+01,
lng: 1.3950277778e+02,
cert : true,
content:'Name = JA/NI-083(JA/NI-083) peak = 818.099976 pos = 38.3450,139.5028 diff = 236.099976'
});
data_saddle.push({
lat: 3.8354222223e+01,
lng: 1.3950855556e+02,
content:'Saddle = 582.000000 pos = 38.3542,139.5086 diff = 236.099976'
});
data_peak.push({
lat: 3.8396888889e+01,
lng: 1.3953322222e+02,
cert : false,
content:' Peak = 794.700012 pos = 38.3969,139.5332 diff = 178.000000'
});
data_saddle.push({
lat: 3.8374444445e+01,
lng: 1.3952677778e+02,
content:'Saddle = 616.700012 pos = 38.3744,139.5268 diff = 178.000000'
});
data_peak.push({
lat: 3.8549222223e+01,
lng: 1.4002688889e+02,
cert : true,
content:'Name = Gassan(JA/YM-002) peak = 1983.199951 pos = 38.5492,140.0269 diff = 1773.299927'
});
data_saddle.push({
lat: 3.8000666667e+01,
lng: 1.4013844444e+02,
content:'Saddle = 209.899994 pos = 38.0007,140.1384 diff = 1773.299927'
});
data_peak.push({
lat: 3.8666111111e+01,
lng: 1.3965211111e+02,
cert : true,
content:'Name = JA/YM-104(JA/YM-104) peak = 490.899994 pos = 38.6661,139.6521 diff = 268.700012'
});
data_saddle.push({
lat: 3.8671111111e+01,
lng: 1.3966555556e+02,
content:'Saddle = 222.199997 pos = 38.6711,139.6656 diff = 268.700012'
});
data_peak.push({
lat: 3.8474111111e+01,
lng: 1.3959366667e+02,
cert : false,
content:' Peak = 385.200012 pos = 38.4741,139.5937 diff = 157.500015'
});
data_saddle.push({
lat: 3.8472222223e+01,
lng: 1.3959888889e+02,
content:'Saddle = 227.699997 pos = 38.4722,139.5989 diff = 157.500015'
});
data_peak.push({
lat: 3.8001333334e+01,
lng: 1.3969544444e+02,
cert : false,
content:' Peak = 625.200012 pos = 38.0013,139.6954 diff = 397.100006'
});
data_saddle.push({
lat: 3.8000111112e+01,
lng: 1.3971922222e+02,
content:'Saddle = 228.100006 pos = 38.0001,139.7192 diff = 397.100006'
});
data_peak.push({
lat: 3.8493777778e+01,
lng: 1.3962622222e+02,
cert : true,
content:'Name = JA/NI-129(JA/NI-129) peak = 452.200012 pos = 38.4938,139.6262 diff = 220.900009'
});
data_saddle.push({
lat: 3.8492777778e+01,
lng: 1.3963444444e+02,
content:'Saddle = 231.300003 pos = 38.4928,139.6344 diff = 220.900009'
});
data_peak.push({
lat: 3.8165000000e+01,
lng: 1.3957944444e+02,
cert : false,
content:' Peak = 578.099976 pos = 38.1650,139.5794 diff = 331.099976'
});
data_saddle.push({
lat: 3.8165111112e+01,
lng: 1.3962166667e+02,
content:'Saddle = 247.000000 pos = 38.1651,139.6217 diff = 331.099976'
});
data_peak.push({
lat: 3.8583111111e+01,
lng: 1.3966500000e+02,
cert : true,
content:'Name = JA/YM-081(JA/YM-081) peak = 681.099976 pos = 38.5831,139.6650 diff = 429.099976'
});
data_saddle.push({
lat: 3.8577555556e+01,
lng: 1.3970122222e+02,
content:'Saddle = 252.000000 pos = 38.5776,139.7012 diff = 429.099976'
});
data_peak.push({
lat: 3.8591777778e+01,
lng: 1.3963555556e+02,
cert : true,
content:'Name = JA/YM-092(JA/YM-092) peak = 610.000000 pos = 38.5918,139.6356 diff = 276.299988'
});
data_saddle.push({
lat: 3.8589888889e+01,
lng: 1.3964266667e+02,
content:'Saddle = 333.700012 pos = 38.5899,139.6427 diff = 276.299988'
});
data_peak.push({
lat: 3.8008111112e+01,
lng: 1.3998444444e+02,
cert : false,
content:' Peak = 411.500000 pos = 38.0081,139.9844 diff = 157.300003'
});
data_saddle.push({
lat: 3.8000111112e+01,
lng: 1.3996077778e+02,
content:'Saddle = 254.199997 pos = 38.0001,139.9608 diff = 157.300003'
});
data_peak.push({
lat: 3.8061222223e+01,
lng: 1.3971900000e+02,
cert : true,
content:'Name = JA/YM-096(JA/YM-096) peak = 550.400024 pos = 38.0612,139.7190 diff = 289.200012'
});
data_saddle.push({
lat: 3.8000111112e+01,
lng: 1.3980511111e+02,
content:'Saddle = 261.200012 pos = 38.0001,139.8051 diff = 289.200012'
});
data_peak.push({
lat: 3.8038666667e+01,
lng: 1.3981022222e+02,
cert : false,
content:' Peak = 522.799988 pos = 38.0387,139.8102 diff = 178.399994'
});
data_saddle.push({
lat: 3.8000333334e+01,
lng: 1.3976044444e+02,
content:'Saddle = 344.399994 pos = 38.0003,139.7604 diff = 178.399994'
});
data_peak.push({
lat: 3.8522111111e+01,
lng: 1.3963133333e+02,
cert : true,
content:'Name = JA/YM-105(JA/YM-105) peak = 482.399994 pos = 38.5221,139.6313 diff = 201.799988'
});
data_saddle.push({
lat: 3.8510888889e+01,
lng: 1.3964022222e+02,
content:'Saddle = 280.600006 pos = 38.5109,139.6402 diff = 201.799988'
});
data_peak.push({
lat: 3.8207333334e+01,
lng: 1.3961544444e+02,
cert : true,
content:'Name = JA/NI-123(JA/NI-123) peak = 503.700012 pos = 38.2073,139.6154 diff = 222.000000'
});
data_saddle.push({
lat: 3.8204444445e+01,
lng: 1.3962155556e+02,
content:'Saddle = 281.700012 pos = 38.2044,139.6216 diff = 222.000000'
});
data_peak.push({
lat: 3.8548000000e+01,
lng: 1.3964533333e+02,
cert : true,
content:'Name = JA/YM-091(JA/YM-091) peak = 610.500000 pos = 38.5480,139.6453 diff = 322.100006'
});
data_saddle.push({
lat: 3.8531111111e+01,
lng: 1.3968533333e+02,
content:'Saddle = 288.399994 pos = 38.5311,139.6853 diff = 322.100006'
});
data_peak.push({
lat: 3.8572666667e+01,
lng: 1.3959388889e+02,
cert : true,
content:'Name = JA/YM-100(JA/YM-100) peak = 533.299988 pos = 38.5727,139.5939 diff = 230.399994'
});
data_saddle.push({
lat: 3.8566444445e+01,
lng: 1.3959844444e+02,
content:'Saddle = 302.899994 pos = 38.5664,139.5984 diff = 230.399994'
});
data_peak.push({
lat: 3.8562666667e+01,
lng: 1.3960944444e+02,
cert : true,
content:'Name = JA/YM-094(JA/YM-094) peak = 593.500000 pos = 38.5627,139.6094 diff = 289.899994'
});
data_saddle.push({
lat: 3.8554888889e+01,
lng: 1.3962888889e+02,
content:'Saddle = 303.600006 pos = 38.5549,139.6289 diff = 289.899994'
});
data_peak.push({
lat: 3.8620222222e+01,
lng: 1.3963055556e+02,
cert : true,
content:'Name = Atsumidake(JA/YM-073) peak = 734.299988 pos = 38.6202,139.6306 diff = 445.899994'
});
data_saddle.push({
lat: 3.8605888889e+01,
lng: 1.3972122222e+02,
content:'Saddle = 288.399994 pos = 38.6059,139.7212 diff = 445.899994'
});
data_peak.push({
lat: 3.8617666667e+01,
lng: 1.3966466667e+02,
cert : true,
content:'Name = JA/YM-079(JA/YM-079) peak = 683.700012 pos = 38.6177,139.6647 diff = 341.400024'
});
data_saddle.push({
lat: 3.8620333334e+01,
lng: 1.3964333333e+02,
content:'Saddle = 342.299988 pos = 38.6203,139.6433 diff = 341.400024'
});
data_peak.push({
lat: 3.8608333334e+01,
lng: 1.3969088889e+02,
cert : true,
content:'Name = JA/YM-093(JA/YM-093) peak = 605.799988 pos = 38.6083,139.6909 diff = 173.799988'
});
data_saddle.push({
lat: 3.8607000000e+01,
lng: 1.3967322222e+02,
content:'Saddle = 432.000000 pos = 38.6070,139.6732 diff = 173.799988'
});
data_peak.push({
lat: 3.8194555556e+01,
lng: 1.3960455556e+02,
cert : true,
content:'Name = JA/NI-114(JA/NI-114) peak = 536.900024 pos = 38.1946,139.6046 diff = 248.000031'
});
data_saddle.push({
lat: 3.8191333334e+01,
lng: 1.3961777778e+02,
content:'Saddle = 288.899994 pos = 38.1913,139.6178 diff = 248.000031'
});
data_peak.push({
lat: 3.8508666667e+01,
lng: 1.3966377778e+02,
cert : true,
content:'Name = JA/NI-120(JA/NI-120) peak = 512.200012 pos = 38.5087,139.6638 diff = 214.600006'
});
data_saddle.push({
lat: 3.8505222223e+01,
lng: 1.3967888889e+02,
content:'Saddle = 297.600006 pos = 38.5052,139.6789 diff = 214.600006'
});
data_peak.push({
lat: 3.8039888889e+01,
lng: 1.3985166667e+02,
cert : true,
content:'Name = JA/YM-089(JA/YM-089) peak = 640.099976 pos = 38.0399,139.8517 diff = 318.999969'
});
data_saddle.push({
lat: 3.8000111112e+01,
lng: 1.3986811111e+02,
content:'Saddle = 321.100006 pos = 38.0001,139.8681 diff = 318.999969'
});
data_peak.push({
lat: 3.8004000000e+01,
lng: 1.3985911111e+02,
cert : false,
content:' Peak = 562.000000 pos = 38.0040,139.8591 diff = 163.100006'
});
data_saddle.push({
lat: 3.8000111112e+01,
lng: 1.3985522222e+02,
content:'Saddle = 398.899994 pos = 38.0001,139.8552 diff = 163.100006'
});
data_peak.push({
lat: 3.8000111112e+01,
lng: 1.3983888889e+02,
cert : false,
content:' Peak = 579.400024 pos = 38.0001,139.8389 diff = 165.400024'
});
data_saddle.push({
lat: 3.8000333334e+01,
lng: 1.3982933333e+02,
content:'Saddle = 414.000000 pos = 38.0003,139.8293 diff = 165.400024'
});
data_peak.push({
lat: 3.8662666667e+01,
lng: 1.3968555556e+02,
cert : true,
content:'Name = JA/YM-085(JA/YM-085) peak = 651.299988 pos = 38.6627,139.6856 diff = 328.399994'
});
data_saddle.push({
lat: 3.8634666667e+01,
lng: 1.3973488889e+02,
content:'Saddle = 322.899994 pos = 38.6347,139.7349 diff = 328.399994'
});
data_peak.push({
lat: 3.8350444445e+01,
lng: 1.3962188889e+02,
cert : false,
content:' Peak = 500.000000 pos = 38.3504,139.6219 diff = 166.500000'
});
data_saddle.push({
lat: 3.8356888889e+01,
lng: 1.3962022222e+02,
content:'Saddle = 333.500000 pos = 38.3569,139.6202 diff = 166.500000'
});
data_peak.push({
lat: 3.8575888889e+01,
lng: 1.4031755556e+02,
cert : true,
content:'Name = JA/YM-098(JA/YM-098) peak = 542.400024 pos = 38.5759,140.3176 diff = 205.700012'
});
data_saddle.push({
lat: 3.8573888889e+01,
lng: 1.4028600000e+02,
content:'Saddle = 336.700012 pos = 38.5739,140.2860 diff = 205.700012'
});
data_peak.push({
lat: 3.8129333334e+01,
lng: 1.3977733333e+02,
cert : true,
content:'Name = JA/YM-099(JA/YM-099) peak = 542.799988 pos = 38.1293,139.7773 diff = 201.299988'
});
data_saddle.push({
lat: 3.8135555556e+01,
lng: 1.3978755556e+02,
content:'Saddle = 341.500000 pos = 38.1356,139.7876 diff = 201.299988'
});
data_peak.push({
lat: 3.8393444445e+01,
lng: 1.3960455556e+02,
cert : true,
content:'Name = JA/NI-088(JA/NI-088) peak = 707.700012 pos = 38.3934,139.6046 diff = 360.600006'
});
data_saddle.push({
lat: 3.8396666667e+01,
lng: 1.3963000000e+02,
content:'Saddle = 347.100006 pos = 38.3967,139.6300 diff = 360.600006'
});
data_peak.push({
lat: 3.8392222223e+01,
lng: 1.3963266667e+02,
cert : false,
content:' Peak = 544.099976 pos = 38.3922,139.6327 diff = 171.699982'
});
data_saddle.push({
lat: 3.8391666667e+01,
lng: 1.3962577778e+02,
content:'Saddle = 372.399994 pos = 38.3917,139.6258 diff = 171.699982'
});
data_peak.push({
lat: 3.8375444445e+01,
lng: 1.3961833333e+02,
cert : true,
content:'Name = JA/NI-099(JA/NI-099) peak = 630.299988 pos = 38.3754,139.6183 diff = 182.899994'
});
data_saddle.push({
lat: 3.8377000000e+01,
lng: 1.3961488889e+02,
content:'Saddle = 447.399994 pos = 38.3770,139.6149 diff = 182.899994'
});
data_peak.push({
lat: 3.8451333334e+01,
lng: 1.3963422222e+02,
cert : false,
content:' Peak = 541.700012 pos = 38.4513,139.6342 diff = 163.600006'
});
data_saddle.push({
lat: 3.8453111111e+01,
lng: 1.3964155556e+02,
content:'Saddle = 378.100006 pos = 38.4531,139.6416 diff = 163.600006'
});
data_peak.push({
lat: 3.8260111112e+01,
lng: 1.3967644444e+02,
cert : false,
content:' Peak = 551.799988 pos = 38.2601,139.6764 diff = 154.899994'
});
data_saddle.push({
lat: 3.8256222223e+01,
lng: 1.3967900000e+02,
content:'Saddle = 396.899994 pos = 38.2562,139.6790 diff = 154.899994'
});
data_peak.push({
lat: 3.8065777778e+01,
lng: 1.3981644444e+02,
cert : false,
content:' Peak = 565.200012 pos = 38.0658,139.8164 diff = 153.500000'
});
data_saddle.push({
lat: 3.8081333334e+01,
lng: 1.3983655556e+02,
content:'Saddle = 411.700012 pos = 38.0813,139.8366 diff = 153.500000'
});
data_peak.push({
lat: 3.8222000000e+01,
lng: 1.3966900000e+02,
cert : true,
content:'Name = Washigasuyama(JA/NI-050) peak = 1091.699951 pos = 38.2220,139.6690 diff = 678.599976'
});
data_saddle.push({
lat: 3.8201888889e+01,
lng: 1.3973444444e+02,
content:'Saddle = 413.100006 pos = 38.2019,139.7344 diff = 678.599976'
});
data_peak.push({
lat: 3.8103888889e+01,
lng: 1.3964544444e+02,
cert : true,
content:'Name = JA/NI-082(JA/NI-082) peak = 821.700012 pos = 38.1039,139.6454 diff = 283.500000'
});
data_saddle.push({
lat: 3.8111888889e+01,
lng: 1.3966066667e+02,
content:'Saddle = 538.200012 pos = 38.1119,139.6607 diff = 283.500000'
});
data_peak.push({
lat: 3.8114666667e+01,
lng: 1.3962455556e+02,
cert : true,
content:'Name = JA/NI-087(JA/NI-087) peak = 724.299988 pos = 38.1147,139.6246 diff = 161.099976'
});
data_saddle.push({
lat: 3.8109222223e+01,
lng: 1.3963422222e+02,
content:'Saddle = 563.200012 pos = 38.1092,139.6342 diff = 161.099976'
});
data_peak.push({
lat: 3.8145777778e+01,
lng: 1.3966255556e+02,
cert : true,
content:'Name = JA/NI-060(JA/NI-060) peak = 1010.099976 pos = 38.1458,139.6626 diff = 467.199951'
});
data_saddle.push({
lat: 3.8184666667e+01,
lng: 1.3969344444e+02,
content:'Saddle = 542.900024 pos = 38.1847,139.6934 diff = 467.199951'
});
data_peak.push({
lat: 3.8119111112e+01,
lng: 1.3969055556e+02,
cert : true,
content:'Name = JA/YM-059(JA/YM-059) peak = 840.299988 pos = 38.1191,139.6906 diff = 257.599976'
});
data_saddle.push({
lat: 3.8140111112e+01,
lng: 1.3971044444e+02,
content:'Saddle = 582.700012 pos = 38.1401,139.7104 diff = 257.599976'
});
data_peak.push({
lat: 3.8149111112e+01,
lng: 1.3963566667e+02,
cert : true,
content:'Name = JA/NI-067(JA/NI-067) peak = 964.900024 pos = 38.1491,139.6357 diff = 323.100037'
});
data_saddle.push({
lat: 3.8150111112e+01,
lng: 1.3964233333e+02,
content:'Saddle = 641.799988 pos = 38.1501,139.6423 diff = 323.100037'
});
data_peak.push({
lat: 3.8150000000e+01,
lng: 1.3969044444e+02,
cert : true,
content:'Name = JA/YM-049(JA/YM-049) peak = 961.500000 pos = 38.1500,139.6904 diff = 239.400024'
});
data_saddle.push({
lat: 3.8159000000e+01,
lng: 1.3967488889e+02,
content:'Saddle = 722.099976 pos = 38.1590,139.6749 diff = 239.400024'
});
data_peak.push({
lat: 3.8260444445e+01,
lng: 1.3972622222e+02,
cert : true,
content:'Name = JA/NI-102(JA/NI-102) peak = 628.700012 pos = 38.2604,139.7262 diff = 205.700012'
});
data_saddle.push({
lat: 3.8251888889e+01,
lng: 1.3973866667e+02,
content:'Saddle = 423.000000 pos = 38.2519,139.7387 diff = 205.700012'
});
data_peak.push({
lat: 3.8192888889e+01,
lng: 1.3975588889e+02,
cert : true,
content:'Name = JA/YM-072(JA/YM-072) peak = 740.799988 pos = 38.1929,139.7559 diff = 308.899994'
});
data_saddle.push({
lat: 3.8198111112e+01,
lng: 1.3976788889e+02,
content:'Saddle = 431.899994 pos = 38.1981,139.7679 diff = 308.899994'
});
data_peak.push({
lat: 3.8411444445e+01,
lng: 1.3963644444e+02,
cert : true,
content:'Name = JA/NI-100(JA/NI-100) peak = 632.400024 pos = 38.4114,139.6364 diff = 190.000031'
});
data_saddle.push({
lat: 3.8401888889e+01,
lng: 1.3965722222e+02,
content:'Saddle = 442.399994 pos = 38.4019,139.6572 diff = 190.000031'
});
data_peak.push({
lat: 3.8408111111e+01,
lng: 1.4009822222e+02,
cert : false,
content:' Peak = 598.500000 pos = 38.4081,140.0982 diff = 151.799988'
});
data_saddle.push({
lat: 3.8405333334e+01,
lng: 1.4008788889e+02,
content:'Saddle = 446.700012 pos = 38.4053,140.0879 diff = 151.799988'
});
data_peak.push({
lat: 3.8058333334e+01,
lng: 1.3983144444e+02,
cert : false,
content:' Peak = 597.900024 pos = 38.0583,139.8314 diff = 150.500031'
});
data_saddle.push({
lat: 3.8065333334e+01,
lng: 1.3983877778e+02,
content:'Saddle = 447.399994 pos = 38.0653,139.8388 diff = 150.500031'
});
data_peak.push({
lat: 3.8000111112e+01,
lng: 1.3990355556e+02,
cert : false,
content:' Peak = 651.200012 pos = 38.0001,139.9036 diff = 153.500000'
});
data_saddle.push({
lat: 3.8011444445e+01,
lng: 1.3992033333e+02,
content:'Saddle = 497.700012 pos = 38.0114,139.9203 diff = 153.500000'
});
data_peak.push({
lat: 3.8429111111e+01,
lng: 1.3965011111e+02,
cert : false,
content:' Peak = 691.900024 pos = 38.4291,139.6501 diff = 171.500000'
});
data_saddle.push({
lat: 3.8426555556e+01,
lng: 1.3965588889e+02,
content:'Saddle = 520.400024 pos = 38.4266,139.6559 diff = 171.500000'
});
data_peak.push({
lat: 3.8318666667e+01,
lng: 1.4009322222e+02,
cert : false,
content:' Peak = 702.799988 pos = 38.3187,140.0932 diff = 165.299988'
});
data_saddle.push({
lat: 3.8316555556e+01,
lng: 1.4008177778e+02,
content:'Saddle = 537.500000 pos = 38.3166,140.0818 diff = 165.299988'
});
data_peak.push({
lat: 3.8369111111e+01,
lng: 1.3967077778e+02,
cert : false,
content:' Peak = 774.700012 pos = 38.3691,139.6708 diff = 236.000000'
});
data_saddle.push({
lat: 3.8367000000e+01,
lng: 1.3967600000e+02,
content:'Saddle = 538.700012 pos = 38.3670,139.6760 diff = 236.000000'
});
data_peak.push({
lat: 3.8129666667e+01,
lng: 1.3993355556e+02,
cert : false,
content:' Peak = 707.500000 pos = 38.1297,139.9336 diff = 160.400024'
});
data_saddle.push({
lat: 3.8133333334e+01,
lng: 1.3992333333e+02,
content:'Saddle = 547.099976 pos = 38.1333,139.9233 diff = 160.400024'
});
data_peak.push({
lat: 3.8187888889e+01,
lng: 1.3978933333e+02,
cert : true,
content:'Name = JA/YM-067(JA/YM-067) peak = 786.299988 pos = 38.1879,139.7893 diff = 233.599976'
});
data_saddle.push({
lat: 3.8197111112e+01,
lng: 1.3978933333e+02,
content:'Saddle = 552.700012 pos = 38.1971,139.7893 diff = 233.599976'
});
data_peak.push({
lat: 3.8278000000e+01,
lng: 1.3968988889e+02,
cert : false,
content:' Peak = 773.200012 pos = 38.2780,139.6899 diff = 154.799988'
});
data_saddle.push({
lat: 3.8282333334e+01,
lng: 1.3969577778e+02,
content:'Saddle = 618.400024 pos = 38.2823,139.6958 diff = 154.799988'
});
data_peak.push({
lat: 3.8354111111e+01,
lng: 1.4000700000e+02,
cert : true,
content:'Name = JA/YM-044(JA/YM-044) peak = 984.400024 pos = 38.3541,140.0070 diff = 337.200012'
});
data_saddle.push({
lat: 3.8332888889e+01,
lng: 1.3999288889e+02,
content:'Saddle = 647.200012 pos = 38.3329,139.9929 diff = 337.200012'
});
data_peak.push({
lat: 3.8206777778e+01,
lng: 1.3980533333e+02,
cert : true,
content:'Name = JA/YM-056(JA/YM-056) peak = 870.500000 pos = 38.2068,139.8053 diff = 217.099976'
});
data_saddle.push({
lat: 3.8212777778e+01,
lng: 1.3981566667e+02,
content:'Saddle = 653.400024 pos = 38.2128,139.8157 diff = 217.099976'
});
data_peak.push({
lat: 3.8273333334e+01,
lng: 1.3965088889e+02,
cert : true,
content:'Name = JA/NI-081(JA/NI-081) peak = 832.000000 pos = 38.2733,139.6509 diff = 168.599976'
});
data_saddle.push({
lat: 3.8293666667e+01,
lng: 1.3966211111e+02,
content:'Saddle = 663.400024 pos = 38.2937,139.6621 diff = 168.599976'
});
data_peak.push({
lat: 3.8506666667e+01,
lng: 1.3984633333e+02,
cert : true,
content:'Name = JA/YM-040(JA/YM-040) peak = 991.099976 pos = 38.5067,139.8463 diff = 319.699951'
});
data_saddle.push({
lat: 3.8488666667e+01,
lng: 1.3982133333e+02,
content:'Saddle = 671.400024 pos = 38.4887,139.8213 diff = 319.699951'
});
data_peak.push({
lat: 3.8300000000e+01,
lng: 1.3969266667e+02,
cert : true,
content:'Name = JA/NI-066(JA/NI-066) peak = 966.299988 pos = 38.3000,139.6927 diff = 276.000000'
});
data_saddle.push({
lat: 3.8330111111e+01,
lng: 1.3968400000e+02,
content:'Saddle = 690.299988 pos = 38.3301,139.6840 diff = 276.000000'
});
data_peak.push({
lat: 3.8315555556e+01,
lng: 1.3965622222e+02,
cert : true,
content:'Name = JA/NI-068(JA/NI-068) peak = 953.000000 pos = 38.3156,139.6562 diff = 230.599976'
});
data_saddle.push({
lat: 3.8317555556e+01,
lng: 1.3967422222e+02,
content:'Saddle = 722.400024 pos = 38.3176,139.6742 diff = 230.599976'
});
data_peak.push({
lat: 3.8468000000e+01,
lng: 1.4007588889e+02,
cert : true,
content:'Name = JA/YM-057(JA/YM-057) peak = 867.299988 pos = 38.4680,140.0759 diff = 174.599976'
});
data_saddle.push({
lat: 3.8473000000e+01,
lng: 1.4008011111e+02,
content:'Saddle = 692.700012 pos = 38.4730,140.0801 diff = 174.599976'
});
data_peak.push({
lat: 3.8355555556e+01,
lng: 1.3969555556e+02,
cert : false,
content:' Peak = 852.200012 pos = 38.3556,139.6956 diff = 154.600037'
});
data_saddle.push({
lat: 3.8372111111e+01,
lng: 1.3969422222e+02,
content:'Saddle = 697.599976 pos = 38.3721,139.6942 diff = 154.600037'
});
data_peak.push({
lat: 3.8520444445e+01,
lng: 1.3972788889e+02,
cert : true,
content:'Name = Mayasan(JA/YM-034) peak = 1013.299988 pos = 38.5204,139.7279 diff = 301.000000'
});
data_saddle.push({
lat: 3.8447666667e+01,
lng: 1.3971777778e+02,
content:'Saddle = 712.299988 pos = 38.4477,139.7178 diff = 301.000000'
});
data_peak.push({
lat: 3.8605777778e+01,
lng: 1.3977877778e+02,
cert : true,
content:'Name = JA/YM-048(JA/YM-048) peak = 961.099976 pos = 38.6058,139.7788 diff = 228.799988'
});
data_saddle.push({
lat: 3.8577444445e+01,
lng: 1.3976066667e+02,
content:'Saddle = 732.299988 pos = 38.5774,139.7607 diff = 228.799988'
});
data_peak.push({
lat: 3.8314555556e+01,
lng: 1.4001944444e+02,
cert : false,
content:' Peak = 1014.900024 pos = 38.3146,140.0194 diff = 297.000000'
});
data_saddle.push({
lat: 3.8302777778e+01,
lng: 1.4000688889e+02,
content:'Saddle = 717.900024 pos = 38.3028,140.0069 diff = 297.000000'
});
data_peak.push({
lat: 3.8486000000e+01,
lng: 1.4018044444e+02,
cert : true,
content:'Name = JA/YM-051(JA/YM-051) peak = 922.400024 pos = 38.4860,140.1804 diff = 200.500000'
});
data_saddle.push({
lat: 3.8501111111e+01,
lng: 1.4016866667e+02,
content:'Saddle = 721.900024 pos = 38.5011,140.1687 diff = 200.500000'
});
data_peak.push({
lat: 3.8653000000e+01,
lng: 1.4003988889e+02,
cert : true,
content:'Name = JA/YM-026(JA/YM-026) peak = 1091.099976 pos = 38.6530,140.0399 diff = 340.599976'
});
data_saddle.push({
lat: 3.8640666667e+01,
lng: 1.4006655556e+02,
content:'Saddle = 750.500000 pos = 38.6407,140.0666 diff = 340.599976'
});
data_peak.push({
lat: 3.8192666667e+01,
lng: 1.3983200000e+02,
cert : true,
content:'Name = JA/YM-036(JA/YM-036) peak = 1009.500000 pos = 38.1927,139.8320 diff = 256.299988'
});
data_saddle.push({
lat: 3.8193222223e+01,
lng: 1.3983977778e+02,
content:'Saddle = 753.200012 pos = 38.1932,139.8398 diff = 256.299988'
});
data_peak.push({
lat: 3.8416222223e+01,
lng: 1.3971333333e+02,
cert : true,
content:'Name = JA/YM-031(JA/YM-031) peak = 1026.500000 pos = 38.4162,139.7133 diff = 249.599976'
});
data_saddle.push({
lat: 3.8389222223e+01,
lng: 1.3971500000e+02,
content:'Saddle = 776.900024 pos = 38.3892,139.7150 diff = 249.599976'
});
data_peak.push({
lat: 3.8401888889e+01,
lng: 1.3973400000e+02,
cert : true,
content:'Name = JA/YM-033(JA/YM-033) peak = 1020.099976 pos = 38.4019,139.7340 diff = 237.000000'
});
data_saddle.push({
lat: 3.8375444445e+01,
lng: 1.3972988889e+02,
content:'Saddle = 783.099976 pos = 38.3754,139.7299 diff = 237.000000'
});
data_peak.push({
lat: 3.8140000000e+01,
lng: 1.3996077778e+02,
cert : true,
content:'Name = JA/YM-046(JA/YM-046) peak = 980.599976 pos = 38.1400,139.9608 diff = 190.500000'
});
data_saddle.push({
lat: 3.8153444445e+01,
lng: 1.3998500000e+02,
content:'Saddle = 790.099976 pos = 38.1534,139.9850 diff = 190.500000'
});
data_peak.push({
lat: 3.8621444445e+01,
lng: 1.4010266667e+02,
cert : true,
content:'Name = JA/YM-028(JA/YM-028) peak = 1080.000000 pos = 38.6214,140.1027 diff = 267.200012'
});
data_saddle.push({
lat: 3.8606777778e+01,
lng: 1.4010655556e+02,
content:'Saddle = 812.799988 pos = 38.6068,140.1066 diff = 267.200012'
});
data_peak.push({
lat: 3.8176444445e+01,
lng: 1.3984277778e+02,
cert : false,
content:' Peak = 1053.800049 pos = 38.1764,139.8428 diff = 230.700073'
});
data_saddle.push({
lat: 3.8181777778e+01,
lng: 1.3985000000e+02,
content:'Saddle = 823.099976 pos = 38.1818,139.8500 diff = 230.700073'
});
data_peak.push({
lat: 3.8270111112e+01,
lng: 1.4007044444e+02,
cert : false,
content:' Peak = 991.000000 pos = 38.2701,140.0704 diff = 159.299988'
});
data_saddle.push({
lat: 3.8251777778e+01,
lng: 1.4004755556e+02,
content:'Saddle = 831.700012 pos = 38.2518,140.0476 diff = 159.299988'
});
data_peak.push({
lat: 3.8439444445e+01,
lng: 1.3987000000e+02,
cert : false,
content:' Peak = 1023.799988 pos = 38.4394,139.8700 diff = 172.899963'
});
data_saddle.push({
lat: 3.8440777778e+01,
lng: 1.3987755556e+02,
content:'Saddle = 850.900024 pos = 38.4408,139.8776 diff = 172.899963'
});
data_peak.push({
lat: 3.8529333334e+01,
lng: 1.4021044444e+02,
cert : true,
content:'Name = Hayama(JA/YM-007) peak = 1461.599976 pos = 38.5293,140.2104 diff = 594.000000'
});
data_saddle.push({
lat: 3.8496555556e+01,
lng: 1.4011088889e+02,
content:'Saddle = 867.599976 pos = 38.4966,140.1109 diff = 594.000000'
});
data_peak.push({
lat: 3.8519777778e+01,
lng: 1.4015344444e+02,
cert : true,
content:'Name = JA/YM-027(JA/YM-027) peak = 1082.599976 pos = 38.5198,140.1534 diff = 209.599976'
});
data_saddle.push({
lat: 3.8525444445e+01,
lng: 1.4015888889e+02,
content:'Saddle = 873.000000 pos = 38.5254,140.1589 diff = 209.599976'
});
data_peak.push({
lat: 3.8563000000e+01,
lng: 1.4012044444e+02,
cert : false,
content:' Peak = 1060.900024 pos = 38.5630,140.1204 diff = 158.100037'
});
data_saddle.push({
lat: 3.8568888889e+01,
lng: 1.4011722222e+02,
content:'Saddle = 902.799988 pos = 38.5689,140.1172 diff = 158.100037'
});
data_peak.push({
lat: 3.8260555556e+01,
lng: 1.3992233333e+02,
cert : true,
content:'Name = Asahidake (Ooasahidake)(JA/YM-003) peak = 1870.099976 pos = 38.2606,139.9223 diff = 953.299988'
});
data_saddle.push({
lat: 3.8514444445e+01,
lng: 1.3995344444e+02,
content:'Saddle = 916.799988 pos = 38.5144,139.9534 diff = 953.299988'
});
data_peak.push({
lat: 3.8241444445e+01,
lng: 1.3981566667e+02,
cert : false,
content:' Peak = 1214.500000 pos = 38.2414,139.8157 diff = 282.700012'
});
data_saddle.push({
lat: 3.8251666667e+01,
lng: 1.3983577778e+02,
content:'Saddle = 931.799988 pos = 38.2517,139.8358 diff = 282.700012'
});
data_peak.push({
lat: 3.8197666667e+01,
lng: 1.3987955556e+02,
cert : true,
content:'Name = Iwaigameyama(JA/YM-009) peak = 1416.199951 pos = 38.1977,139.8796 diff = 454.099976'
});
data_saddle.push({
lat: 3.8209888889e+01,
lng: 1.3988844444e+02,
content:'Saddle = 962.099976 pos = 38.2099,139.8884 diff = 454.099976'
});
data_peak.push({
lat: 3.8137000000e+01,
lng: 1.3988722222e+02,
cert : true,
content:'Name = JA/YM-011(JA/YM-011) peak = 1292.900024 pos = 38.1370,139.8872 diff = 302.400024'
});
data_saddle.push({
lat: 3.8180666667e+01,
lng: 1.3988000000e+02,
content:'Saddle = 990.500000 pos = 38.1807,139.8800 diff = 302.400024'
});
data_peak.push({
lat: 3.8156333334e+01,
lng: 1.3988277778e+02,
cert : true,
content:'Name = JA/YM-015(JA/YM-015) peak = 1260.099976 pos = 38.1563,139.8828 diff = 267.500000'
});
data_saddle.push({
lat: 3.8149555556e+01,
lng: 1.3989533333e+02,
content:'Saddle = 992.599976 pos = 38.1496,139.8953 diff = 267.500000'
});
data_peak.push({
lat: 3.8453777778e+01,
lng: 1.3983611111e+02,
cert : true,
content:'Name = JA/YM-016(JA/YM-016) peak = 1243.800049 pos = 38.4538,139.8361 diff = 250.700073'
});
data_saddle.push({
lat: 3.8441777778e+01,
lng: 1.3983166667e+02,
content:'Saddle = 993.099976 pos = 38.4418,139.8317 diff = 250.700073'
});
data_peak.push({
lat: 3.8244555556e+01,
lng: 1.4002288889e+02,
cert : true,
content:'Name = JA/YM-018(JA/YM-018) peak = 1204.000000 pos = 38.2446,140.0229 diff = 187.299988'
});
data_saddle.push({
lat: 3.8230111112e+01,
lng: 1.4000733333e+02,
content:'Saddle = 1016.700012 pos = 38.2301,140.0073 diff = 187.299988'
});
data_peak.push({
lat: 3.8191555556e+01,
lng: 1.3996833333e+02,
cert : true,
content:'Name = JA/YM-012(JA/YM-012) peak = 1288.199951 pos = 38.1916,139.9683 diff = 195.599976'
});
data_saddle.push({
lat: 3.8205777778e+01,
lng: 1.3995344444e+02,
content:'Saddle = 1092.599976 pos = 38.2058,139.9534 diff = 195.599976'
});
data_peak.push({
lat: 3.8361000000e+01,
lng: 1.3976166667e+02,
cert : false,
content:' Peak = 1330.000000 pos = 38.3610,139.7617 diff = 171.400024'
});
data_saddle.push({
lat: 3.8353333334e+01,
lng: 1.3978066667e+02,
content:'Saddle = 1158.599976 pos = 38.3533,139.7807 diff = 171.400024'
});
data_peak.push({
lat: 3.8381000000e+01,
lng: 1.3991077778e+02,
cert : true,
content:'Name = JA/YM-006(JA/YM-006) peak = 1482.900024 pos = 38.3810,139.9108 diff = 310.800049'
});
data_saddle.push({
lat: 3.8351222223e+01,
lng: 1.3990477778e+02,
content:'Saddle = 1172.099976 pos = 38.3512,139.9048 diff = 310.800049'
});
data_peak.push({
lat: 3.8448222223e+01,
lng: 1.3993344444e+02,
cert : true,
content:'Name = JA/YM-008(JA/YM-008) peak = 1441.300049 pos = 38.4482,139.9334 diff = 213.400024'
});
data_saddle.push({
lat: 3.8398000000e+01,
lng: 1.3991900000e+02,
content:'Saddle = 1227.900024 pos = 38.3980,139.9190 diff = 213.400024'
});
data_peak.push({
lat: 3.8418444445e+01,
lng: 1.3991722222e+02,
cert : false,
content:' Peak = 1402.099976 pos = 38.4184,139.9172 diff = 170.900024'
});
data_saddle.push({
lat: 3.8424000000e+01,
lng: 1.3992966667e+02,
content:'Saddle = 1231.199951 pos = 38.4240,139.9297 diff = 170.900024'
});
data_peak.push({
lat: 3.8208777778e+01,
lng: 1.3994044444e+02,
cert : false,
content:' Peak = 1341.000000 pos = 38.2088,139.9404 diff = 160.300049'
});
data_saddle.push({
lat: 3.8213333334e+01,
lng: 1.3994166667e+02,
content:'Saddle = 1180.699951 pos = 38.2133,139.9417 diff = 160.300049'
});
data_peak.push({
lat: 3.8355222223e+01,
lng: 1.3980444444e+02,
cert : false,
content:' Peak = 1501.099976 pos = 38.3552,139.8044 diff = 187.900024'
});
data_saddle.push({
lat: 3.8352222223e+01,
lng: 1.3981944444e+02,
content:'Saddle = 1313.199951 pos = 38.3522,139.8194 diff = 187.900024'
});
data_peak.push({
lat: 3.8343000000e+01,
lng: 1.3984900000e+02,
cert : true,
content:'Name = Itoudake(JA/YM-005) peak = 1771.099976 pos = 38.3430,139.8490 diff = 333.299927'
});
data_saddle.push({
lat: 3.8321555556e+01,
lng: 1.3986722222e+02,
content:'Saddle = 1437.800049 pos = 38.3216,139.8672 diff = 333.299927'
});
data_peak.push({
lat: 3.8273555556e+01,
lng: 1.3994500000e+02,
cert : false,
content:' Peak = 1645.800049 pos = 38.2736,139.9450 diff = 173.800049'
});
data_saddle.push({
lat: 3.8272000000e+01,
lng: 1.3994022222e+02,
content:'Saddle = 1472.000000 pos = 38.2720,139.9402 diff = 173.800049'
});
data_peak.push({
lat: 3.8306333334e+01,
lng: 1.3987900000e+02,
cert : false,
content:' Peak = 1693.400024 pos = 38.3063,139.8790 diff = 160.700073'
});
data_saddle.push({
lat: 3.8301333334e+01,
lng: 1.3988655556e+02,
content:'Saddle = 1532.699951 pos = 38.3013,139.8866 diff = 160.700073'
});
data_peak.push({
lat: 3.8609111111e+01,
lng: 1.4008455556e+02,
cert : false,
content:' Peak = 1181.099976 pos = 38.6091,140.0846 diff = 168.399963'
});
data_saddle.push({
lat: 3.8590222222e+01,
lng: 1.4009533333e+02,
content:'Saddle = 1012.700012 pos = 38.5902,140.0953 diff = 168.399963'
});
data_peak.push({
lat: 3.8567666667e+01,
lng: 1.4009666667e+02,
cert : false,
content:' Peak = 1223.300049 pos = 38.5677,140.0967 diff = 151.900024'
});
data_saddle.push({
lat: 3.8552000000e+01,
lng: 1.4008233333e+02,
content:'Saddle = 1071.400024 pos = 38.5520,140.0823 diff = 151.900024'
});
data_peak.push({
lat: 3.8531000000e+01,
lng: 1.3998477778e+02,
cert : false,
content:' Peak = 1498.699951 pos = 38.5310,139.9848 diff = 155.000000'
});
data_saddle.push({
lat: 3.8538888889e+01,
lng: 1.3999433333e+02,
content:'Saddle = 1343.699951 pos = 38.5389,139.9943 diff = 155.000000'
});
data_peak.push({
lat: 3.8901888889e+01,
lng: 1.4032066667e+02,
cert : true,
content:'Name = JA/YM-107(JA/YM-107) peak = 412.700012 pos = 38.9019,140.3207 diff = 195.700012'
});
data_saddle.push({
lat: 3.8900888889e+01,
lng: 1.4032733333e+02,
content:'Saddle = 217.000000 pos = 38.9009,140.3273 diff = 195.700012'
});
data_peak.push({
lat: 3.9326444444e+01,
lng: 1.4031433333e+02,
cert : true,
content:'Name = JA/AT-120(JA/AT-120) peak = 441.899994 pos = 39.3264,140.3143 diff = 203.899994'
});
data_saddle.push({
lat: 3.9276555556e+01,
lng: 1.4033766667e+02,
content:'Saddle = 238.000000 pos = 39.2766,140.3377 diff = 203.899994'
});
data_peak.push({
lat: 3.9296000000e+01,
lng: 1.4034555556e+02,
cert : false,
content:' Peak = 413.700012 pos = 39.2960,140.3456 diff = 160.600006'
});
data_saddle.push({
lat: 3.9316888889e+01,
lng: 1.4034111111e+02,
content:'Saddle = 253.100006 pos = 39.3169,140.3411 diff = 160.600006'
});
data_peak.push({
lat: 3.8886333333e+01,
lng: 1.4036066667e+02,
cert : false,
content:' Peak = 412.500000 pos = 38.8863,140.3607 diff = 174.300003'
});
data_saddle.push({
lat: 3.8885222222e+01,
lng: 1.4037800000e+02,
content:'Saddle = 238.199997 pos = 38.8852,140.3780 diff = 174.300003'
});
data_peak.push({
lat: 3.8927333333e+01,
lng: 1.4030266667e+02,
cert : false,
content:' Peak = 460.100006 pos = 38.9273,140.3027 diff = 218.200012'
});
data_saddle.push({
lat: 3.8932222222e+01,
lng: 1.4030433333e+02,
content:'Saddle = 241.899994 pos = 38.9322,140.3043 diff = 218.200012'
});
data_peak.push({
lat: 3.9266333333e+01,
lng: 1.4059222222e+02,
cert : false,
content:' Peak = 402.600006 pos = 39.2663,140.5922 diff = 159.300003'
});
data_saddle.push({
lat: 3.9255888889e+01,
lng: 1.4059544444e+02,
content:'Saddle = 243.300003 pos = 39.2559,140.5954 diff = 159.300003'
});
data_peak.push({
lat: 3.8893000000e+01,
lng: 1.4032900000e+02,
cert : false,
content:' Peak = 436.200012 pos = 38.8930,140.3290 diff = 180.200012'
});
data_saddle.push({
lat: 3.8895777778e+01,
lng: 1.4033122222e+02,
content:'Saddle = 256.000000 pos = 38.8958,140.3312 diff = 180.200012'
});
data_peak.push({
lat: 3.9202888889e+01,
lng: 1.4034766667e+02,
cert : false,
content:' Peak = 481.500000 pos = 39.2029,140.3477 diff = 224.100006'
});
data_saddle.push({
lat: 3.9169222222e+01,
lng: 1.4032666667e+02,
content:'Saddle = 257.399994 pos = 39.1692,140.3267 diff = 224.100006'
});
data_peak.push({
lat: 3.8902888889e+01,
lng: 1.4036822222e+02,
cert : true,
content:'Name = JA/YM-101(JA/YM-101) peak = 520.500000 pos = 38.9029,140.3682 diff = 251.299988'
});
data_saddle.push({
lat: 3.8911333333e+01,
lng: 1.4037522222e+02,
content:'Saddle = 269.200012 pos = 38.9113,140.3752 diff = 251.299988'
});
data_peak.push({
lat: 3.8909666667e+01,
lng: 1.4015955556e+02,
cert : false,
content:' Peak = 441.100006 pos = 38.9097,140.1596 diff = 168.500000'
});
data_saddle.push({
lat: 3.8920777778e+01,
lng: 1.4015166667e+02,
content:'Saddle = 272.600006 pos = 38.9208,140.1517 diff = 168.500000'
});
data_peak.push({
lat: 3.9098666667e+01,
lng: 1.4051711111e+02,
cert : true,
content:'Name = JA/AT-060(JA/AT-060) peak = 772.500000 pos = 39.0987,140.5171 diff = 489.000000'
});
data_saddle.push({
lat: 3.9088666667e+01,
lng: 1.4055133333e+02,
content:'Saddle = 283.500000 pos = 39.0887,140.5513 diff = 489.000000'
});
data_peak.push({
lat: 3.9138444444e+01,
lng: 1.4052544444e+02,
cert : true,
content:'Name = JA/AT-110(JA/AT-110) peak = 490.399994 pos = 39.1384,140.5254 diff = 199.000000'
});
data_saddle.push({
lat: 3.9123555556e+01,
lng: 1.4054144444e+02,
content:'Saddle = 291.399994 pos = 39.1236,140.5414 diff = 199.000000'
});
data_peak.push({
lat: 3.8222666667e+01,
lng: 1.4017300000e+02,
cert : true,
content:'Name = Shiratakayama(JA/YM-039) peak = 993.500000 pos = 38.2227,140.1730 diff = 705.799988'
});
data_saddle.push({
lat: 3.8068777778e+01,
lng: 1.4018177778e+02,
content:'Saddle = 287.700012 pos = 38.0688,140.1818 diff = 705.799988'
});
data_peak.push({
lat: 3.8079222223e+01,
lng: 1.4016744444e+02,
cert : false,
content:' Peak = 563.799988 pos = 38.0792,140.1674 diff = 196.000000'
});
data_saddle.push({
lat: 3.8087777778e+01,
lng: 1.4017055556e+02,
content:'Saddle = 367.799988 pos = 38.0878,140.1706 diff = 196.000000'
});
data_peak.push({
lat: 3.8099888889e+01,
lng: 1.4018144444e+02,
cert : false,
content:' Peak = 617.299988 pos = 38.0999,140.1814 diff = 199.899994'
});
data_saddle.push({
lat: 3.8111444445e+01,
lng: 1.4018600000e+02,
content:'Saddle = 417.399994 pos = 38.1114,140.1860 diff = 199.899994'
});
data_peak.push({
lat: 3.8163666667e+01,
lng: 1.4023866667e+02,
cert : true,
content:'Name = JA/YM-076(JA/YM-076) peak = 713.799988 pos = 38.1637,140.2387 diff = 217.099976'
});
data_saddle.push({
lat: 3.8154555556e+01,
lng: 1.4023344444e+02,
content:'Saddle = 496.700012 pos = 38.1546,140.2334 diff = 217.099976'
});
data_peak.push({
lat: 3.8163555556e+01,
lng: 1.4020544444e+02,
cert : true,
content:'Name = JA/YM-062(JA/YM-062) peak = 810.500000 pos = 38.1636,140.2054 diff = 291.799988'
});
data_saddle.push({
lat: 3.8192666667e+01,
lng: 1.4019366667e+02,
content:'Saddle = 518.700012 pos = 38.1927,140.1937 diff = 291.799988'
});
data_peak.push({
lat: 3.8250888889e+01,
lng: 1.4019533333e+02,
cert : false,
content:' Peak = 762.599976 pos = 38.2509,140.1953 diff = 189.199951'
});
data_saddle.push({
lat: 3.8245777778e+01,
lng: 1.4019755556e+02,
content:'Saddle = 573.400024 pos = 38.2458,140.1976 diff = 189.199951'
});
data_peak.push({
lat: 3.8148444445e+01,
lng: 1.4012800000e+02,
cert : true,
content:'Name = JA/YM-064(JA/YM-064) peak = 803.000000 pos = 38.1484,140.1280 diff = 185.000000'
});
data_saddle.push({
lat: 3.8206444445e+01,
lng: 1.4016477778e+02,
content:'Saddle = 618.000000 pos = 38.2064,140.1648 diff = 185.000000'
});
data_peak.push({
lat: 3.8430000000e+01,
lng: 1.4044877778e+02,
cert : false,
content:' Peak = 441.600006 pos = 38.4300,140.4488 diff = 153.500000'
});
data_saddle.push({
lat: 3.8428888889e+01,
lng: 1.4045588889e+02,
content:'Saddle = 288.100006 pos = 38.4289,140.4559 diff = 153.500000'
});
data_peak.push({
lat: 3.9329444444e+01,
lng: 1.4071022222e+02,
cert : true,
content:'Name = JA/IT-103(JA/IT-103) peak = 771.900024 pos = 39.3294,140.7102 diff = 482.900024'
});
data_saddle.push({
lat: 3.9292111111e+01,
lng: 1.4071777778e+02,
content:'Saddle = 289.000000 pos = 39.2921,140.7178 diff = 482.900024'
});
data_peak.push({
lat: 3.9226666667e+01,
lng: 1.4058922222e+02,
cert : true,
content:'Name = JA/AT-113(JA/AT-113) peak = 478.399994 pos = 39.2267,140.5892 diff = 176.500000'
});
data_saddle.push({
lat: 3.9202888889e+01,
lng: 1.4062177778e+02,
content:'Saddle = 301.899994 pos = 39.2029,140.6218 diff = 176.500000'
});
data_peak.push({
lat: 3.9272111111e+01,
lng: 1.4067888889e+02,
cert : false,
content:' Peak = 482.399994 pos = 39.2721,140.6789 diff = 174.399994'
});
data_saddle.push({
lat: 3.9264111111e+01,
lng: 1.4069366667e+02,
content:'Saddle = 308.000000 pos = 39.2641,140.6937 diff = 174.399994'
});
data_peak.push({
lat: 3.8030000000e+01,
lng: 1.4021911111e+02,
cert : true,
content:'Name = JA/YM-103(JA/YM-103) peak = 504.000000 pos = 38.0300,140.2191 diff = 193.200012'
});
data_saddle.push({
lat: 3.8043111112e+01,
lng: 1.4022366667e+02,
content:'Saddle = 310.799988 pos = 38.0431,140.2237 diff = 193.200012'
});
data_peak.push({
lat: 3.9236666667e+01,
lng: 1.4022766667e+02,
cert : true,
content:'Name = Yashioyama(JA/AT-073) peak = 713.000000 pos = 39.2367,140.2277 diff = 396.299988'
});
data_saddle.push({
lat: 3.9185333333e+01,
lng: 1.4025711111e+02,
content:'Saddle = 316.700012 pos = 39.1853,140.2571 diff = 396.299988'
});
data_peak.push({
lat: 3.8930777778e+01,
lng: 1.4036166667e+02,
cert : true,
content:'Name = JA/YM-102(JA/YM-102) peak = 510.799988 pos = 38.9308,140.3617 diff = 187.899994'
});
data_saddle.push({
lat: 3.8935444445e+01,
lng: 1.4036977778e+02,
content:'Saddle = 322.899994 pos = 38.9354,140.3698 diff = 187.899994'
});
data_peak.push({
lat: 3.9288333333e+01,
lng: 1.4085577778e+02,
cert : false,
content:' Peak = 515.900024 pos = 39.2883,140.8558 diff = 188.700012'
});
data_saddle.push({
lat: 3.9281555556e+01,
lng: 1.4085511111e+02,
content:'Saddle = 327.200012 pos = 39.2816,140.8551 diff = 188.700012'
});
data_peak.push({
lat: 3.9158111111e+01,
lng: 1.4028044444e+02,
cert : true,
content:'Name = JA/AT-094(JA/AT-094) peak = 603.500000 pos = 39.1581,140.2804 diff = 274.299988'
});
data_saddle.push({
lat: 3.9135666667e+01,
lng: 1.4030000000e+02,
content:'Saddle = 329.200012 pos = 39.1357,140.3000 diff = 274.299988'
});
data_peak.push({
lat: 3.9175222222e+01,
lng: 1.4060544444e+02,
cert : true,
content:'Name = JA/AT-109(JA/AT-109) peak = 493.600006 pos = 39.1752,140.6054 diff = 162.100006'
});
data_saddle.push({
lat: 3.9160111111e+01,
lng: 1.4061444444e+02,
content:'Saddle = 331.500000 pos = 39.1601,140.6144 diff = 162.100006'
});
data_peak.push({
lat: 3.8143777778e+01,
lng: 1.4043988889e+02,
cert : true,
content:'Name = Zaouzan (Kumanodake)(JA/YM-004) peak = 1840.699951 pos = 38.1438,140.4399 diff = 1502.699951'
});
data_saddle.push({
lat: 3.8736222222e+01,
lng: 1.4060988889e+02,
content:'Saddle = 338.000000 pos = 38.7362,140.6099 diff = 1502.699951'
});
data_peak.push({
lat: 3.8320555556e+01,
lng: 1.4069488889e+02,
cert : true,
content:'Name = JA/MG-048(JA/MG-048) peak = 500.799988 pos = 38.3206,140.6949 diff = 162.299988'
});
data_saddle.push({
lat: 3.8336222223e+01,
lng: 1.4068233333e+02,
content:'Saddle = 338.500000 pos = 38.3362,140.6823 diff = 162.299988'
});
data_peak.push({
lat: 3.8139444445e+01,
lng: 1.4031166667e+02,
cert : false,
content:' Peak = 684.099976 pos = 38.1394,140.3117 diff = 285.399963'
});
data_saddle.push({
lat: 3.8131444445e+01,
lng: 1.4033866667e+02,
content:'Saddle = 398.700012 pos = 38.1314,140.3387 diff = 285.399963'
});
data_peak.push({
lat: 3.8264777778e+01,
lng: 1.4059377778e+02,
cert : true,
content:'Name = JA/MG-036(JA/MG-036) peak = 704.400024 pos = 38.2648,140.5938 diff = 295.100037'
});
data_saddle.push({
lat: 3.8265333334e+01,
lng: 1.4057566667e+02,
content:'Saddle = 409.299988 pos = 38.2653,140.5757 diff = 295.100037'
});
data_peak.push({
lat: 3.8430666667e+01,
lng: 1.4046566667e+02,
cert : false,
content:' Peak = 591.000000 pos = 38.4307,140.4657 diff = 158.600006'
});
data_saddle.push({
lat: 3.8432000000e+01,
lng: 1.4047111111e+02,
content:'Saddle = 432.399994 pos = 38.4320,140.4711 diff = 158.600006'
});
data_peak.push({
lat: 3.8291888889e+01,
lng: 1.4061022222e+02,
cert : true,
content:'Name = JA/MG-037(JA/MG-037) peak = 643.599976 pos = 38.2919,140.6102 diff = 207.499969'
});
data_saddle.push({
lat: 3.8293222223e+01,
lng: 1.4060577778e+02,
content:'Saddle = 436.100006 pos = 38.2932,140.6058 diff = 207.499969'
});
data_peak.push({
lat: 3.8436000000e+01,
lng: 1.4076500000e+02,
cert : true,
content:'Name = JA/MG-038(JA/MG-038) peak = 622.700012 pos = 38.4360,140.7650 diff = 185.700012'
});
data_saddle.push({
lat: 3.8436222223e+01,
lng: 1.4075588889e+02,
content:'Saddle = 437.000000 pos = 38.4362,140.7559 diff = 185.700012'
});
data_peak.push({
lat: 3.8046777778e+01,
lng: 1.4023722222e+02,
cert : true,
content:'Name = JA/YM-090(JA/YM-090) peak = 631.099976 pos = 38.0468,140.2372 diff = 178.999969'
});
data_saddle.push({
lat: 3.8059000000e+01,
lng: 1.4022922222e+02,
content:'Saddle = 452.100006 pos = 38.0590,140.2292 diff = 178.999969'
});
data_peak.push({
lat: 3.8382222223e+01,
lng: 1.4045944444e+02,
cert : false,
content:' Peak = 662.400024 pos = 38.3822,140.4594 diff = 205.700012'
});
data_saddle.push({
lat: 3.8375666667e+01,
lng: 1.4046566667e+02,
content:'Saddle = 456.700012 pos = 38.3757,140.4657 diff = 205.700012'
});
data_peak.push({
lat: 3.8721333334e+01,
lng: 1.4045988889e+02,
cert : false,
content:' Peak = 820.900024 pos = 38.7213,140.4599 diff = 349.600037'
});
data_saddle.push({
lat: 3.8691555556e+01,
lng: 1.4051977778e+02,
content:'Saddle = 471.299988 pos = 38.6916,140.5198 diff = 349.600037'
});
data_peak.push({
lat: 3.8679222222e+01,
lng: 1.4044422222e+02,
cert : true,
content:'Name = JA/YM-088(JA/YM-088) peak = 641.700012 pos = 38.6792,140.4442 diff = 161.100006'
});
data_saddle.push({
lat: 3.8690444445e+01,
lng: 1.4045055556e+02,
content:'Saddle = 480.600006 pos = 38.6904,140.4506 diff = 161.100006'
});
data_peak.push({
lat: 3.8691666667e+01,
lng: 1.4049088889e+02,
cert : true,
content:'Name = JA/YM-070(JA/YM-070) peak = 763.799988 pos = 38.6917,140.4909 diff = 217.599976'
});
data_saddle.push({
lat: 3.8701333334e+01,
lng: 1.4047177778e+02,
content:'Saddle = 546.200012 pos = 38.7013,140.4718 diff = 217.599976'
});
data_peak.push({
lat: 3.8741333334e+01,
lng: 1.4043555556e+02,
cert : false,
content:' Peak = 820.200012 pos = 38.7413,140.4356 diff = 198.000000'
});
data_saddle.push({
lat: 3.8731111111e+01,
lng: 1.4045155556e+02,
content:'Saddle = 622.200012 pos = 38.7311,140.4516 diff = 198.000000'
});
data_peak.push({
lat: 3.8644555556e+01,
lng: 1.4062477778e+02,
cert : false,
content:' Peak = 675.099976 pos = 38.6446,140.6248 diff = 201.799988'
});
data_saddle.push({
lat: 3.8642222222e+01,
lng: 1.4061911111e+02,
content:'Saddle = 473.299988 pos = 38.6422,140.6191 diff = 201.799988'
});
data_peak.push({
lat: 3.8086555556e+01,
lng: 1.4060166667e+02,
cert : true,
content:'Name = JA/MG-026(JA/MG-026) peak = 821.299988 pos = 38.0866,140.6017 diff = 343.399994'
});
data_saddle.push({
lat: 3.8075777778e+01,
lng: 1.4056488889e+02,
content:'Saddle = 477.899994 pos = 38.0758,140.5649 diff = 343.399994'
});
data_peak.push({
lat: 3.8109222223e+01,
lng: 1.4034166667e+02,
cert : false,
content:' Peak = 653.500000 pos = 38.1092,140.3417 diff = 166.600006'
});
data_saddle.push({
lat: 3.8107888889e+01,
lng: 1.4034800000e+02,
content:'Saddle = 486.899994 pos = 38.1079,140.3480 diff = 166.600006'
});
data_peak.push({
lat: 3.8066444445e+01,
lng: 1.4020400000e+02,
cert : true,
content:'Name = JA/YM-078(JA/YM-078) peak = 691.900024 pos = 38.0664,140.2040 diff = 200.300018'
});
data_saddle.push({
lat: 3.8069777778e+01,
lng: 1.4021066667e+02,
content:'Saddle = 491.600006 pos = 38.0698,140.2107 diff = 200.300018'
});
data_peak.push({
lat: 3.8080888889e+01,
lng: 1.4023011111e+02,
cert : false,
content:' Peak = 800.599976 pos = 38.0809,140.2301 diff = 302.399963'
});
data_saddle.push({
lat: 3.8074000000e+01,
lng: 1.4025844444e+02,
content:'Saddle = 498.200012 pos = 38.0740,140.2584 diff = 302.399963'
});
data_peak.push({
lat: 3.8237555556e+01,
lng: 1.4059300000e+02,
cert : false,
content:' Peak = 682.599976 pos = 38.2376,140.5930 diff = 170.799988'
});
data_saddle.push({
lat: 3.8243111112e+01,
lng: 1.4058111111e+02,
content:'Saddle = 511.799988 pos = 38.2431,140.5811 diff = 170.799988'
});
data_peak.push({
lat: 3.8222555556e+01,
lng: 1.4056277778e+02,
cert : false,
content:' Peak = 752.400024 pos = 38.2226,140.5628 diff = 240.000000'
});
data_saddle.push({
lat: 3.8229777778e+01,
lng: 1.4054744444e+02,
content:'Saddle = 512.400024 pos = 38.2298,140.5474 diff = 240.000000'
});
data_peak.push({
lat: 3.8650888889e+01,
lng: 1.4054477778e+02,
cert : false,
content:' Peak = 1074.199951 pos = 38.6509,140.5448 diff = 560.099976'
});
data_saddle.push({
lat: 3.8603777778e+01,
lng: 1.4056000000e+02,
content:'Saddle = 514.099976 pos = 38.6038,140.5600 diff = 560.099976'
});
data_peak.push({
lat: 3.8699777778e+01,
lng: 1.4062355556e+02,
cert : true,
content:'Name = JA/MG-023(JA/MG-023) peak = 861.099976 pos = 38.6998,140.6236 diff = 329.199951'
});
data_saddle.push({
lat: 3.8674888889e+01,
lng: 1.4061955556e+02,
content:'Saddle = 531.900024 pos = 38.6749,140.6196 diff = 329.199951'
});
data_peak.push({
lat: 3.8636777778e+01,
lng: 1.4059388889e+02,
cert : true,
content:'Name = JA/MG-025(JA/MG-025) peak = 823.099976 pos = 38.6368,140.5939 diff = 180.500000'
});
data_saddle.push({
lat: 3.8637444445e+01,
lng: 1.4057311111e+02,
content:'Saddle = 642.599976 pos = 38.6374,140.5731 diff = 180.500000'
});
data_peak.push({
lat: 3.8248000000e+01,
lng: 1.4057722222e+02,
cert : true,
content:'Name = JA/MG-033(JA/MG-033) peak = 710.700012 pos = 38.2480,140.5772 diff = 179.100037'
});
data_saddle.push({
lat: 3.8253111112e+01,
lng: 1.4057411111e+02,
content:'Saddle = 531.599976 pos = 38.2531,140.5741 diff = 179.100037'
});
data_peak.push({
lat: 3.8004888889e+01,
lng: 1.4052622222e+02,
cert : false,
content:' Peak = 818.500000 pos = 38.0049,140.5262 diff = 275.500000'
});
data_saddle.push({
lat: 3.8010000000e+01,
lng: 1.4051311111e+02,
content:'Saddle = 543.000000 pos = 38.0100,140.5131 diff = 275.500000'
});
data_peak.push({
lat: 3.8359666667e+01,
lng: 1.4062666667e+02,
cert : true,
content:'Name = JA/MG-029(JA/MG-029) peak = 780.799988 pos = 38.3597,140.6267 diff = 232.500000'
});
data_saddle.push({
lat: 3.8368333334e+01,
lng: 1.4062955556e+02,
content:'Saddle = 548.299988 pos = 38.3683,140.6296 diff = 232.500000'
});
data_peak.push({
lat: 3.8008000000e+01,
lng: 1.4029144444e+02,
cert : false,
content:' Peak = 911.799988 pos = 38.0080,140.2914 diff = 363.500000'
});
data_saddle.push({
lat: 3.8017555556e+01,
lng: 1.4028800000e+02,
content:'Saddle = 548.299988 pos = 38.0176,140.2880 diff = 363.500000'
});
data_peak.push({
lat: 3.8000555556e+01,
lng: 1.4026777778e+02,
cert : false,
content:' Peak = 830.900024 pos = 38.0006,140.2678 diff = 205.200012'
});
data_saddle.push({
lat: 3.8000222223e+01,
lng: 1.4027444444e+02,
content:'Saddle = 625.700012 pos = 38.0002,140.2744 diff = 205.200012'
});
data_peak.push({
lat: 3.8340555556e+01,
lng: 1.4044655556e+02,
cert : false,
content:' Peak = 906.200012 pos = 38.3406,140.4466 diff = 314.700012'
});
data_saddle.push({
lat: 3.8337000000e+01,
lng: 1.4046833333e+02,
content:'Saddle = 591.500000 pos = 38.3370,140.4683 diff = 314.700012'
});
data_peak.push({
lat: 3.8526777778e+01,
lng: 1.4056244444e+02,
cert : true,
content:'Name = JA/YM-065(JA/YM-065) peak = 790.799988 pos = 38.5268,140.5624 diff = 193.700012'
});
data_saddle.push({
lat: 3.8521666667e+01,
lng: 1.4056855556e+02,
content:'Saddle = 597.099976 pos = 38.5217,140.5686 diff = 193.700012'
});
data_peak.push({
lat: 3.8285888889e+01,
lng: 1.4043822222e+02,
cert : false,
content:' Peak = 782.599976 pos = 38.2859,140.4382 diff = 180.500000'
});
data_saddle.push({
lat: 3.8282666667e+01,
lng: 1.4044500000e+02,
content:'Saddle = 602.099976 pos = 38.2827,140.4450 diff = 180.500000'
});
data_peak.push({
lat: 3.8416777778e+01,
lng: 1.4074211111e+02,
cert : false,
content:' Peak = 789.099976 pos = 38.4168,140.7421 diff = 165.500000'
});
data_saddle.push({
lat: 3.8418777778e+01,
lng: 1.4073944444e+02,
content:'Saddle = 623.599976 pos = 38.4188,140.7394 diff = 165.500000'
});
data_peak.push({
lat: 3.8388888889e+01,
lng: 1.4051111111e+02,
cert : false,
content:' Peak = 1002.799988 pos = 38.3889,140.5111 diff = 379.000000'
});
data_saddle.push({
lat: 3.8382888889e+01,
lng: 1.4051355556e+02,
content:'Saddle = 623.799988 pos = 38.3829,140.5136 diff = 379.000000'
});
data_peak.push({
lat: 3.8056222223e+01,
lng: 1.4027700000e+02,
cert : false,
content:' Peak = 805.000000 pos = 38.0562,140.2770 diff = 177.000000'
});
data_saddle.push({
lat: 3.8056555556e+01,
lng: 1.4029688889e+02,
content:'Saddle = 628.000000 pos = 38.0566,140.2969 diff = 177.000000'
});
data_peak.push({
lat: 3.8403333334e+01,
lng: 1.4054622222e+02,
cert : true,
content:'Name = JA/YM-052(JA/YM-052) peak = 905.000000 pos = 38.4033,140.5462 diff = 253.500000'
});
data_saddle.push({
lat: 3.8408111111e+01,
lng: 1.4055500000e+02,
content:'Saddle = 651.500000 pos = 38.4081,140.5550 diff = 253.500000'
});
data_peak.push({
lat: 3.8297777778e+01,
lng: 1.4058522222e+02,
cert : false,
content:' Peak = 862.900024 pos = 38.2978,140.5852 diff = 179.800049'
});
data_saddle.push({
lat: 3.8304000000e+01,
lng: 1.4057455556e+02,
content:'Saddle = 683.099976 pos = 38.3040,140.5746 diff = 179.800049'
});
data_peak.push({
lat: 3.8455444445e+01,
lng: 1.4061977778e+02,
cert : false,
content:' Peak = 1500.099976 pos = 38.4554,140.6198 diff = 799.299988'
});
data_saddle.push({
lat: 3.8389111111e+01,
lng: 1.4057244444e+02,
content:'Saddle = 700.799988 pos = 38.3891,140.5724 diff = 799.299988'
});
data_peak.push({
lat: 3.8487111111e+01,
lng: 1.4044733333e+02,
cert : false,
content:' Peak = 1013.500000 pos = 38.4871,140.4473 diff = 181.700012'
});
data_saddle.push({
lat: 3.8486777778e+01,
lng: 1.4045644444e+02,
content:'Saddle = 831.799988 pos = 38.4868,140.4564 diff = 181.700012'
});
data_peak.push({
lat: 3.8499888889e+01,
lng: 1.4050466667e+02,
cert : false,
content:' Peak = 1056.000000 pos = 38.4999,140.5047 diff = 183.200012'
});
data_saddle.push({
lat: 3.8497666667e+01,
lng: 1.4050833333e+02,
content:'Saddle = 872.799988 pos = 38.4977,140.5083 diff = 183.200012'
});
data_peak.push({
lat: 3.8501111111e+01,
lng: 1.4056577778e+02,
cert : false,
content:' Peak = 1083.099976 pos = 38.5011,140.5658 diff = 176.399963'
});
data_saddle.push({
lat: 3.8495000000e+01,
lng: 1.4057400000e+02,
content:'Saddle = 906.700012 pos = 38.4950,140.5740 diff = 176.399963'
});
data_peak.push({
lat: 3.8491888889e+01,
lng: 1.4058500000e+02,
cert : true,
content:'Name = JA/YM-014(JA/YM-014) peak = 1270.500000 pos = 38.4919,140.5850 diff = 322.900024'
});
data_saddle.push({
lat: 3.8476666667e+01,
lng: 1.4060366667e+02,
content:'Saddle = 947.599976 pos = 38.4767,140.6037 diff = 322.900024'
});
data_peak.push({
lat: 3.8422222223e+01,
lng: 1.4069722222e+02,
cert : false,
content:' Peak = 1252.599976 pos = 38.4222,140.6972 diff = 295.699951'
});
data_saddle.push({
lat: 3.8428888889e+01,
lng: 1.4067988889e+02,
content:'Saddle = 956.900024 pos = 38.4289,140.6799 diff = 295.699951'
});
data_peak.push({
lat: 3.8412111111e+01,
lng: 1.4070866667e+02,
cert : false,
content:' Peak = 1174.500000 pos = 38.4121,140.7087 diff = 152.200012'
});
data_saddle.push({
lat: 3.8415000000e+01,
lng: 1.4070088889e+02,
content:'Saddle = 1022.299988 pos = 38.4150,140.7009 diff = 152.200012'
});
data_peak.push({
lat: 3.8435666667e+01,
lng: 1.4058055556e+02,
cert : true,
content:'Name = JA/MG-008(JA/MG-008) peak = 1294.000000 pos = 38.4357,140.5806 diff = 291.299988'
});
data_saddle.push({
lat: 3.8444444445e+01,
lng: 1.4060600000e+02,
content:'Saddle = 1002.700012 pos = 38.4444,140.6060 diff = 291.299988'
});
data_peak.push({
lat: 3.8451888889e+01,
lng: 1.4056077778e+02,
cert : true,
content:'Name = JA/YM-013(JA/YM-013) peak = 1274.400024 pos = 38.4519,140.5608 diff = 181.599976'
});
data_saddle.push({
lat: 3.8451333334e+01,
lng: 1.4056400000e+02,
content:'Saddle = 1092.800049 pos = 38.4513,140.5640 diff = 181.599976'
});
data_peak.push({
lat: 3.8263333334e+01,
lng: 1.4053966667e+02,
cert : false,
content:' Peak = 970.700012 pos = 38.2633,140.5397 diff = 189.500000'
});
data_saddle.push({
lat: 3.8260555556e+01,
lng: 1.4053555556e+02,
content:'Saddle = 781.200012 pos = 38.2606,140.5356 diff = 189.500000'
});
data_peak.push({
lat: 3.8043444445e+01,
lng: 1.4032677778e+02,
cert : false,
content:' Peak = 1020.500000 pos = 38.0434,140.3268 diff = 157.200012'
});
data_saddle.push({
lat: 3.8047222223e+01,
lng: 1.4031633333e+02,
content:'Saddle = 863.299988 pos = 38.0472,140.3163 diff = 157.200012'
});
data_peak.push({
lat: 3.8302111111e+01,
lng: 1.4052344444e+02,
cert : true,
content:'Name = Daitoudake(JA/MG-005) peak = 1365.400024 pos = 38.3021,140.5234 diff = 456.200012'
});
data_saddle.push({
lat: 3.8228000000e+01,
lng: 1.4046911111e+02,
content:'Saddle = 909.200012 pos = 38.2280,140.4691 diff = 456.200012'
});
data_peak.push({
lat: 3.8348777778e+01,
lng: 1.4052211111e+02,
cert : true,
content:'Name = Omoshiroyama(JA/MG-009) peak = 1263.199951 pos = 38.3488,140.5221 diff = 350.599976'
});
data_saddle.push({
lat: 3.8334666667e+01,
lng: 1.4052533333e+02,
content:'Saddle = 912.599976 pos = 38.3347,140.5253 diff = 350.599976'
});
data_peak.push({
lat: 3.8255666667e+01,
lng: 1.4048544444e+02,
cert : true,
content:'Name = Kamurodake(JA/MG-006) peak = 1353.400024 pos = 38.2557,140.4854 diff = 420.600037'
});
data_saddle.push({
lat: 3.8275888889e+01,
lng: 1.4049011111e+02,
content:'Saddle = 932.799988 pos = 38.2759,140.4901 diff = 420.600037'
});
data_peak.push({
lat: 3.8250888889e+01,
lng: 1.4047111111e+02,
cert : false,
content:' Peak = 1342.900024 pos = 38.2509,140.4711 diff = 160.599976'
});
data_saddle.push({
lat: 3.8253444445e+01,
lng: 1.4047900000e+02,
content:'Saddle = 1182.300049 pos = 38.2534,140.4790 diff = 160.599976'
});
data_peak.push({
lat: 3.8283444445e+01,
lng: 1.4049688889e+02,
cert : true,
content:'Name = JA/MG-012(JA/MG-012) peak = 1226.300049 pos = 38.2834,140.4969 diff = 255.200073'
});
data_saddle.push({
lat: 3.8311111111e+01,
lng: 1.4051277778e+02,
content:'Saddle = 971.099976 pos = 38.3111,140.5128 diff = 255.200073'
});
data_peak.push({
lat: 3.8314222223e+01,
lng: 1.4050400000e+02,
cert : true,
content:'Name = JA/MG-013(JA/MG-013) peak = 1221.699951 pos = 38.3142,140.5040 diff = 238.899963'
});
data_saddle.push({
lat: 3.8298333334e+01,
lng: 1.4049244444e+02,
content:'Saddle = 982.799988 pos = 38.2983,140.4924 diff = 238.899963'
});
data_peak.push({
lat: 3.8057666667e+01,
lng: 1.4037511111e+02,
cert : true,
content:'Name = JA/MG-007(JA/MG-007) peak = 1324.099976 pos = 38.0577,140.3751 diff = 331.299988'
});
data_saddle.push({
lat: 3.8071111112e+01,
lng: 1.4038533333e+02,
content:'Saddle = 992.799988 pos = 38.0711,140.3853 diff = 331.299988'
});
data_peak.push({
lat: 3.8194555556e+01,
lng: 1.4047877778e+02,
cert : true,
content:'Name = JA/MG-004(JA/MG-004) peak = 1484.199951 pos = 38.1946,140.4788 diff = 292.799927'
});
data_saddle.push({
lat: 3.8172666667e+01,
lng: 1.4047144444e+02,
content:'Saddle = 1191.400024 pos = 38.1727,140.4714 diff = 292.799927'
});
data_peak.push({
lat: 3.8183000000e+01,
lng: 1.4039477778e+02,
cert : false,
content:' Peak = 1363.000000 pos = 38.1830,140.3948 diff = 170.000000'
});
data_saddle.push({
lat: 3.8181111112e+01,
lng: 1.4040422222e+02,
content:'Saddle = 1193.000000 pos = 38.1811,140.4042 diff = 170.000000'
});
data_peak.push({
lat: 3.8110111112e+01,
lng: 1.4048966667e+02,
cert : false,
content:' Peak = 1680.199951 pos = 38.1101,140.4897 diff = 175.299927'
});
data_saddle.push({
lat: 3.8107555556e+01,
lng: 1.4048344444e+02,
content:'Saddle = 1504.900024 pos = 38.1076,140.4834 diff = 175.299927'
});
data_peak.push({
lat: 3.8095777778e+01,
lng: 1.4047600000e+02,
cert : true,
content:'Name = Zaouzan (Byoubudake)(JA/MG-001) peak = 1824.300049 pos = 38.0958,140.4760 diff = 287.500000'
});
data_saddle.push({
lat: 3.8117777778e+01,
lng: 1.4045366667e+02,
content:'Saddle = 1536.800049 pos = 38.1178,140.4537 diff = 287.500000'
});
data_peak.push({
lat: 3.8827222222e+01,
lng: 1.4087022222e+02,
cert : true,
content:'Name = JA/MG-039(JA/MG-039) peak = 580.099976 pos = 38.8272,140.8702 diff = 218.599976'
});
data_saddle.push({
lat: 3.8832777778e+01,
lng: 1.4086066667e+02,
content:'Saddle = 361.500000 pos = 38.8328,140.8607 diff = 218.599976'
});
data_peak.push({
lat: 3.8951222222e+01,
lng: 1.4030011111e+02,
cert : false,
content:' Peak = 530.700012 pos = 38.9512,140.3001 diff = 157.300018'
});
data_saddle.push({
lat: 3.8954555556e+01,
lng: 1.4030655556e+02,
content:'Saddle = 373.399994 pos = 38.9546,140.3066 diff = 157.300018'
});
data_peak.push({
lat: 3.8978333333e+01,
lng: 1.4017711111e+02,
cert : true,
content:'Name = JA/YM-097(JA/YM-097) peak = 550.900024 pos = 38.9783,140.1771 diff = 173.400024'
});
data_saddle.push({
lat: 3.8986111111e+01,
lng: 1.4020433333e+02,
content:'Saddle = 377.500000 pos = 38.9861,140.2043 diff = 173.400024'
});
data_peak.push({
lat: 3.8923000000e+01,
lng: 1.4037033333e+02,
cert : false,
content:' Peak = 551.000000 pos = 38.9230,140.3703 diff = 159.600006'
});
data_saddle.push({
lat: 3.8927222222e+01,
lng: 1.4038411111e+02,
content:'Saddle = 391.399994 pos = 38.9272,140.3841 diff = 159.600006'
});
data_peak.push({
lat: 3.9099666667e+01,
lng: 1.4043288889e+02,
cert : false,
content:' Peak = 633.799988 pos = 39.0997,140.4329 diff = 235.399994'
});
data_saddle.push({
lat: 3.9111777778e+01,
lng: 1.4040922222e+02,
content:'Saddle = 398.399994 pos = 39.1118,140.4092 diff = 235.399994'
});
data_peak.push({
lat: 3.8949555556e+01,
lng: 1.4031177778e+02,
cert : false,
content:' Peak = 573.200012 pos = 38.9496,140.3118 diff = 172.000000'
});
data_saddle.push({
lat: 3.8955777778e+01,
lng: 1.4031944444e+02,
content:'Saddle = 401.200012 pos = 38.9558,140.3194 diff = 172.000000'
});
data_peak.push({
lat: 3.8945222222e+01,
lng: 1.4036333333e+02,
cert : false,
content:' Peak = 560.400024 pos = 38.9452,140.3633 diff = 158.100037'
});
data_saddle.push({
lat: 3.8948222222e+01,
lng: 1.4036966667e+02,
content:'Saddle = 402.299988 pos = 38.9482,140.3697 diff = 158.100037'
});
data_peak.push({
lat: 3.9288555556e+01,
lng: 1.4093622222e+02,
cert : true,
content:'Name = JA/IT-144(JA/IT-144) peak = 599.299988 pos = 39.2886,140.9362 diff = 191.199982'
});
data_saddle.push({
lat: 3.9283111111e+01,
lng: 1.4093366667e+02,
content:'Saddle = 408.100006 pos = 39.2831,140.9337 diff = 191.199982'
});
data_peak.push({
lat: 3.8921222222e+01,
lng: 1.4012400000e+02,
cert : true,
content:'Name = JA/YM-055(JA/YM-055) peak = 884.400024 pos = 38.9212,140.1240 diff = 473.400024'
});
data_saddle.push({
lat: 3.8977666667e+01,
lng: 1.4014322222e+02,
content:'Saddle = 411.000000 pos = 38.9777,140.1432 diff = 473.400024'
});
data_peak.push({
lat: 3.8792888889e+01,
lng: 1.4006933333e+02,
cert : true,
content:'Name = JA/YM-083(JA/YM-083) peak = 661.000000 pos = 38.7929,140.0693 diff = 197.000000'
});
data_saddle.push({
lat: 3.8801888889e+01,
lng: 1.4008511111e+02,
content:'Saddle = 464.000000 pos = 38.8019,140.0851 diff = 197.000000'
});
data_peak.push({
lat: 3.8814555556e+01,
lng: 1.4007933333e+02,
cert : true,
content:'Name = JA/YM-069(JA/YM-069) peak = 781.099976 pos = 38.8146,140.0793 diff = 310.499969'
});
data_saddle.push({
lat: 3.8909000000e+01,
lng: 1.4013622222e+02,
content:'Saddle = 470.600006 pos = 38.9090,140.1362 diff = 310.499969'
});
data_peak.push({
lat: 3.8866666667e+01,
lng: 1.4010411111e+02,
cert : false,
content:' Peak = 733.700012 pos = 38.8667,140.1041 diff = 181.100037'
});
data_saddle.push({
lat: 3.8821555556e+01,
lng: 1.4011744444e+02,
content:'Saddle = 552.599976 pos = 38.8216,140.1174 diff = 181.100037'
});
data_peak.push({
lat: 3.8883000000e+01,
lng: 1.4006211111e+02,
cert : false,
content:' Peak = 733.400024 pos = 38.8830,140.0621 diff = 162.100037'
});
data_saddle.push({
lat: 3.8870111111e+01,
lng: 1.4008666667e+02,
content:'Saddle = 571.299988 pos = 38.8701,140.0867 diff = 162.100037'
});
data_peak.push({
lat: 3.8955555556e+01,
lng: 1.4009244444e+02,
cert : false,
content:' Peak = 672.299988 pos = 38.9556,140.0924 diff = 159.000000'
});
data_saddle.push({
lat: 3.8957333333e+01,
lng: 1.4010422222e+02,
content:'Saddle = 513.299988 pos = 38.9573,140.1042 diff = 159.000000'
});
data_peak.push({
lat: 3.9130777778e+01,
lng: 1.4022800000e+02,
cert : false,
content:' Peak = 571.799988 pos = 39.1308,140.2280 diff = 153.799988'
});
data_saddle.push({
lat: 3.9119444444e+01,
lng: 1.4024177778e+02,
content:'Saddle = 418.000000 pos = 39.1194,140.2418 diff = 153.799988'
});
data_peak.push({
lat: 3.9275111111e+01,
lng: 1.4092977778e+02,
cert : true,
content:'Name = JA/IT-143(JA/IT-143) peak = 602.500000 pos = 39.2751,140.9298 diff = 184.399994'
});
data_saddle.push({
lat: 3.9271222222e+01,
lng: 1.4091633333e+02,
content:'Saddle = 418.100006 pos = 39.2712,140.9163 diff = 184.399994'
});
data_peak.push({
lat: 3.8954333333e+01,
lng: 1.4034377778e+02,
cert : true,
content:'Name = JA/YM-086(JA/YM-086) peak = 646.500000 pos = 38.9543,140.3438 diff = 228.399994'
});
data_saddle.push({
lat: 3.8963555556e+01,
lng: 1.4035622222e+02,
content:'Saddle = 418.100006 pos = 38.9636,140.3562 diff = 228.399994'
});
data_peak.push({
lat: 3.9066555556e+01,
lng: 1.4055866667e+02,
cert : true,
content:'Name = JA/AT-078(JA/AT-078) peak = 697.900024 pos = 39.0666,140.5587 diff = 278.800018'
});
data_saddle.push({
lat: 3.9053222222e+01,
lng: 1.4057733333e+02,
content:'Saddle = 419.100006 pos = 39.0532,140.5773 diff = 278.800018'
});
data_peak.push({
lat: 3.8961000000e+01,
lng: 1.4078833333e+02,
cert : true,
content:'Name = Kurikomayama(JA/MG-002) peak = 1627.099976 pos = 38.9610,140.7883 diff = 1197.699951'
});
data_saddle.push({
lat: 3.9005111111e+01,
lng: 1.4036844444e+02,
content:'Saddle = 429.399994 pos = 39.0051,140.3684 diff = 1197.699951'
});
data_peak.push({
lat: 3.9233444444e+01,
lng: 1.4067344444e+02,
cert : false,
content:' Peak = 680.799988 pos = 39.2334,140.6734 diff = 232.000000'
});
data_saddle.push({
lat: 3.9227666667e+01,
lng: 1.4066900000e+02,
content:'Saddle = 448.799988 pos = 39.2277,140.6690 diff = 232.000000'
});
data_peak.push({
lat: 3.8744444445e+01,
lng: 1.4057011111e+02,
cert : false,
content:' Peak = 620.799988 pos = 38.7444,140.5701 diff = 168.199982'
});
data_saddle.push({
lat: 3.8752666667e+01,
lng: 1.4057622222e+02,
content:'Saddle = 452.600006 pos = 38.7527,140.5762 diff = 168.199982'
});
data_peak.push({
lat: 3.9097111111e+01,
lng: 1.4090444444e+02,
cert : true,
content:'Name = JA/IT-128(JA/IT-128) peak = 683.099976 pos = 39.0971,140.9044 diff = 211.899963'
});
data_saddle.push({
lat: 3.9084333333e+01,
lng: 1.4090211111e+02,
content:'Saddle = 471.200012 pos = 39.0843,140.9021 diff = 211.899963'
});
data_peak.push({
lat: 3.9102000000e+01,
lng: 1.4060444444e+02,
cert : true,
content:'Name = JA/AT-076(JA/AT-076) peak = 703.000000 pos = 39.1020,140.6044 diff = 231.600006'
});
data_saddle.push({
lat: 3.9107000000e+01,
lng: 1.4064022222e+02,
content:'Saddle = 471.399994 pos = 39.1070,140.6402 diff = 231.600006'
});
data_peak.push({
lat: 3.9126111111e+01,
lng: 1.4062366667e+02,
cert : false,
content:' Peak = 640.599976 pos = 39.1261,140.6237 diff = 152.299988'
});
data_saddle.push({
lat: 3.9121888889e+01,
lng: 1.4061577778e+02,
content:'Saddle = 488.299988 pos = 39.1219,140.6158 diff = 152.299988'
});
data_peak.push({
lat: 3.9209111111e+01,
lng: 1.4066566667e+02,
cert : true,
content:'Name = JA/AT-058(JA/AT-058) peak = 780.500000 pos = 39.2091,140.6657 diff = 292.899994'
});
data_saddle.push({
lat: 3.9188444444e+01,
lng: 1.4069477778e+02,
content:'Saddle = 487.600006 pos = 39.1884,140.6948 diff = 292.899994'
});
data_peak.push({
lat: 3.9037111111e+01,
lng: 1.4059155556e+02,
cert : true,
content:'Name = JA/AT-065(JA/AT-065) peak = 760.299988 pos = 39.0371,140.5916 diff = 258.399994'
});
data_saddle.push({
lat: 3.9023000000e+01,
lng: 1.4061588889e+02,
content:'Saddle = 501.899994 pos = 39.0230,140.6159 diff = 258.399994'
});
data_peak.push({
lat: 3.9061333333e+01,
lng: 1.4090466667e+02,
cert : true,
content:'Name = JA/IT-065(JA/IT-065) peak = 926.200012 pos = 39.0613,140.9047 diff = 414.100037'
});
data_saddle.push({
lat: 3.9038666667e+01,
lng: 1.4085588889e+02,
content:'Saddle = 512.099976 pos = 39.0387,140.8559 diff = 414.100037'
});
data_peak.push({
lat: 3.9048666667e+01,
lng: 1.4094977778e+02,
cert : true,
content:'Name = JA/IT-096(JA/IT-096) peak = 787.000000 pos = 39.0487,140.9498 diff = 196.900024'
});
data_saddle.push({
lat: 3.9050888889e+01,
lng: 1.4093000000e+02,
content:'Saddle = 590.099976 pos = 39.0509,140.9300 diff = 196.900024'
});
data_peak.push({
lat: 3.9047222222e+01,
lng: 1.4086000000e+02,
cert : false,
content:' Peak = 762.299988 pos = 39.0472,140.8600 diff = 154.200012'
});
data_saddle.push({
lat: 3.9044000000e+01,
lng: 1.4086966667e+02,
content:'Saddle = 608.099976 pos = 39.0440,140.8697 diff = 154.200012'
});
data_peak.push({
lat: 3.9029444445e+01,
lng: 1.4089811111e+02,
cert : true,
content:'Name = JA/IT-086(JA/IT-086) peak = 861.700012 pos = 39.0294,140.8981 diff = 235.200012'
});
data_saddle.push({
lat: 3.9043333333e+01,
lng: 1.4090111111e+02,
content:'Saddle = 626.500000 pos = 39.0433,140.9011 diff = 235.200012'
});
data_peak.push({
lat: 3.8849888889e+01,
lng: 1.4079277778e+02,
cert : false,
content:' Peak = 671.900024 pos = 38.8499,140.7928 diff = 151.300049'
});
data_saddle.push({
lat: 3.8855777778e+01,
lng: 1.4080877778e+02,
content:'Saddle = 520.599976 pos = 38.8558,140.8088 diff = 151.300049'
});
data_peak.push({
lat: 3.8843777778e+01,
lng: 1.4068733333e+02,
cert : true,
content:'Name = JA/MG-018(JA/MG-018) peak = 988.200012 pos = 38.8438,140.6873 diff = 450.000000'
});
data_saddle.push({
lat: 3.8821222222e+01,
lng: 1.4074288889e+02,
content:'Saddle = 538.200012 pos = 38.8212,140.7429 diff = 450.000000'
});
data_peak.push({
lat: 3.8994555556e+01,
lng: 1.4037611111e+02,
cert : false,
content:' Peak = 750.599976 pos = 38.9946,140.3761 diff = 207.799988'
});
data_saddle.push({
lat: 3.8994111111e+01,
lng: 1.4038455556e+02,
content:'Saddle = 542.799988 pos = 38.9941,140.3846 diff = 207.799988'
});
data_peak.push({
lat: 3.8834444445e+01,
lng: 1.4076388889e+02,
cert : true,
content:'Name = JA/MG-028(JA/MG-028) peak = 792.299988 pos = 38.8344,140.7639 diff = 206.099976'
});
data_saddle.push({
lat: 3.8874222222e+01,
lng: 1.4074655556e+02,
content:'Saddle = 586.200012 pos = 38.8742,140.7466 diff = 206.099976'
});
data_peak.push({
lat: 3.8858333333e+01,
lng: 1.4073211111e+02,
cert : true,
content:'Name = JA/MG-030(JA/MG-030) peak = 773.299988 pos = 38.8583,140.7321 diff = 185.399963'
});
data_saddle.push({
lat: 3.8840666667e+01,
lng: 1.4074744444e+02,
content:'Saddle = 587.900024 pos = 38.8407,140.7474 diff = 185.399963'
});
data_peak.push({
lat: 3.8847333333e+01,
lng: 1.4073377778e+02,
cert : true,
content:'Name = JA/MG-031(JA/MG-031) peak = 770.400024 pos = 38.8473,140.7338 diff = 168.200012'
});
data_saddle.push({
lat: 3.8863888889e+01,
lng: 1.4074877778e+02,
content:'Saddle = 602.200012 pos = 38.8639,140.7488 diff = 168.200012'
});
data_peak.push({
lat: 3.8851333333e+01,
lng: 1.4074900000e+02,
cert : false,
content:' Peak = 761.299988 pos = 38.8513,140.7490 diff = 154.399963'
});
data_saddle.push({
lat: 3.8846111111e+01,
lng: 1.4074055556e+02,
content:'Saddle = 606.900024 pos = 38.8461,140.7406 diff = 154.399963'
});
data_peak.push({
lat: 3.9140555556e+01,
lng: 1.4068722222e+02,
cert : true,
content:'Name = JA/AT-062(JA/AT-062) peak = 766.000000 pos = 39.1406,140.6872 diff = 168.700012'
});
data_saddle.push({
lat: 3.9120777778e+01,
lng: 1.4068477778e+02,
content:'Saddle = 597.299988 pos = 39.1208,140.6848 diff = 168.700012'
});
data_peak.push({
lat: 3.9003777778e+01,
lng: 1.4040544444e+02,
cert : true,
content:'Name = JA/AT-041(JA/AT-041) peak = 953.099976 pos = 39.0038,140.4054 diff = 290.699951'
});
data_saddle.push({
lat: 3.8991777778e+01,
lng: 1.4041866667e+02,
content:'Saddle = 662.400024 pos = 38.9918,140.4187 diff = 290.699951'
});
data_peak.push({
lat: 3.9247444444e+01,
lng: 1.4091500000e+02,
cert : false,
content:' Peak = 913.099976 pos = 39.2474,140.9150 diff = 243.599976'
});
data_saddle.push({
lat: 3.9246555556e+01,
lng: 1.4090700000e+02,
content:'Saddle = 669.500000 pos = 39.2466,140.9070 diff = 243.599976'
});
data_peak.push({
lat: 3.9250333333e+01,
lng: 1.4093166667e+02,
cert : true,
content:'Name = JA/IT-070(JA/IT-070) peak = 910.599976 pos = 39.2503,140.9317 diff = 168.799988'
});
data_saddle.push({
lat: 3.9248333333e+01,
lng: 1.4092155556e+02,
content:'Saddle = 741.799988 pos = 39.2483,140.9216 diff = 168.799988'
});
data_peak.push({
lat: 3.8899000000e+01,
lng: 1.4080466667e+02,
cert : false,
content:' Peak = 866.900024 pos = 38.8990,140.8047 diff = 196.100037'
});
data_saddle.push({
lat: 3.8909333333e+01,
lng: 1.4080900000e+02,
content:'Saddle = 670.799988 pos = 38.9093,140.8090 diff = 196.100037'
});
data_peak.push({
lat: 3.9260222222e+01,
lng: 1.4082366667e+02,
cert : false,
content:' Peak = 842.900024 pos = 39.2602,140.8237 diff = 171.700012'
});
data_saddle.push({
lat: 3.9250111111e+01,
lng: 1.4081855556e+02,
content:'Saddle = 671.200012 pos = 39.2501,140.8186 diff = 171.700012'
});
data_peak.push({
lat: 3.8889555556e+01,
lng: 1.4069811111e+02,
cert : true,
content:'Name = JA/MG-019(JA/MG-019) peak = 950.500000 pos = 38.8896,140.6981 diff = 259.500000'
});
data_saddle.push({
lat: 3.8895444445e+01,
lng: 1.4069422222e+02,
content:'Saddle = 691.000000 pos = 38.8954,140.6942 diff = 259.500000'
});
data_peak.push({
lat: 3.9026555556e+01,
lng: 1.4070355556e+02,
cert : true,
content:'Name = JA/AT-024(JA/AT-024) peak = 1083.000000 pos = 39.0266,140.7036 diff = 390.200012'
});
data_saddle.push({
lat: 3.9003888889e+01,
lng: 1.4071777778e+02,
content:'Saddle = 692.799988 pos = 39.0039,140.7178 diff = 390.200012'
});
data_peak.push({
lat: 3.9020333333e+01,
lng: 1.4084300000e+02,
cert : true,
content:'Name = JA/IT-052(JA/IT-052) peak = 989.000000 pos = 39.0203,140.8430 diff = 286.000000'
});
data_saddle.push({
lat: 3.9019777778e+01,
lng: 1.4082077778e+02,
content:'Saddle = 703.000000 pos = 39.0198,140.8208 diff = 286.000000'
});
data_peak.push({
lat: 3.8904444445e+01,
lng: 1.4061866667e+02,
cert : false,
content:' Peak = 1435.800049 pos = 38.9044,140.6187 diff = 703.800049'
});
data_saddle.push({
lat: 3.8918777778e+01,
lng: 1.4069100000e+02,
content:'Saddle = 732.000000 pos = 38.9188,140.6910 diff = 703.800049'
});
data_peak.push({
lat: 3.9020888889e+01,
lng: 1.4052055556e+02,
cert : true,
content:'Name = JA/AT-036(JA/AT-036) peak = 1001.900024 pos = 39.0209,140.5206 diff = 259.300049'
});
data_saddle.push({
lat: 3.9010111111e+01,
lng: 1.4053100000e+02,
content:'Saddle = 742.599976 pos = 39.0101,140.5310 diff = 259.300049'
});
data_peak.push({
lat: 3.8819555556e+01,
lng: 1.4049422222e+02,
cert : false,
content:' Peak = 930.799988 pos = 38.8196,140.4942 diff = 183.399963'
});
data_saddle.push({
lat: 3.8829555556e+01,
lng: 1.4048211111e+02,
content:'Saddle = 747.400024 pos = 38.8296,140.4821 diff = 183.399963'
});
data_peak.push({
lat: 3.8767000000e+01,
lng: 1.4064933333e+02,
cert : true,
content:'Name = JA/MG-014(JA/MG-014) peak = 1104.300049 pos = 38.7670,140.6493 diff = 308.400024'
});
data_saddle.push({
lat: 3.8790777778e+01,
lng: 1.4060088889e+02,
content:'Saddle = 795.900024 pos = 38.7908,140.6009 diff = 308.400024'
});
data_peak.push({
lat: 3.8775000000e+01,
lng: 1.4062466667e+02,
cert : true,
content:'Name = JA/YM-029(JA/YM-029) peak = 1054.199951 pos = 38.7750,140.6247 diff = 239.499939'
});
data_saddle.push({
lat: 3.8777444445e+01,
lng: 1.4063677778e+02,
content:'Saddle = 814.700012 pos = 38.7774,140.6368 diff = 239.499939'
});
data_peak.push({
lat: 3.8789666667e+01,
lng: 1.4040122222e+02,
cert : false,
content:' Peak = 1021.700012 pos = 38.7897,140.4012 diff = 209.900024'
});
data_saddle.push({
lat: 3.8800333334e+01,
lng: 1.4040333333e+02,
content:'Saddle = 811.799988 pos = 38.8003,140.4033 diff = 209.900024'
});
data_peak.push({
lat: 3.8902333333e+01,
lng: 1.4049222222e+02,
cert : true,
content:'Name = Kamurosan(JA/AT-006) peak = 1363.000000 pos = 38.9023,140.4922 diff = 545.700012'
});
data_saddle.push({
lat: 3.8878222222e+01,
lng: 1.4057411111e+02,
content:'Saddle = 817.299988 pos = 38.8782,140.5741 diff = 545.700012'
});
data_peak.push({
lat: 3.8811000000e+01,
lng: 1.4059500000e+02,
cert : true,
content:'Name = Kamurodake (Kokaburayama)(JA/MG-010) peak = 1261.500000 pos = 38.8110,140.5950 diff = 372.099976'
});
data_saddle.push({
lat: 3.8877333333e+01,
lng: 1.4054377778e+02,
content:'Saddle = 889.400024 pos = 38.8773,140.5438 diff = 372.099976'
});
data_peak.push({
lat: 3.8860222222e+01,
lng: 1.4054944444e+02,
cert : true,
content:'Name = JA/YM-021(JA/YM-021) peak = 1117.099976 pos = 38.8602,140.5494 diff = 224.599976'
});
data_saddle.push({
lat: 3.8840555556e+01,
lng: 1.4058177778e+02,
content:'Saddle = 892.500000 pos = 38.8406,140.5818 diff = 224.599976'
});
data_peak.push({
lat: 3.8801666667e+01,
lng: 1.4041855556e+02,
cert : true,
content:'Name = JA/YM-025(JA/YM-025) peak = 1097.699951 pos = 38.8017,140.4186 diff = 157.699951'
});
data_saddle.push({
lat: 3.8815000000e+01,
lng: 1.4042644444e+02,
content:'Saddle = 940.000000 pos = 38.8150,140.4264 diff = 157.699951'
});
data_peak.push({
lat: 3.8892777778e+01,
lng: 1.4054511111e+02,
cert : false,
content:' Peak = 1192.699951 pos = 38.8928,140.5451 diff = 242.399963'
});
data_saddle.push({
lat: 3.8899666667e+01,
lng: 1.4051366667e+02,
content:'Saddle = 950.299988 pos = 38.8997,140.5137 diff = 242.399963'
});
data_peak.push({
lat: 3.8840222222e+01,
lng: 1.4044844444e+02,
cert : false,
content:' Peak = 1232.599976 pos = 38.8402,140.4484 diff = 231.299988'
});
data_saddle.push({
lat: 3.8845666667e+01,
lng: 1.4045977778e+02,
content:'Saddle = 1001.299988 pos = 38.8457,140.4598 diff = 231.299988'
});
data_peak.push({
lat: 3.8862888889e+01,
lng: 1.4048555556e+02,
cert : false,
content:' Peak = 1361.900024 pos = 38.8629,140.4856 diff = 241.200073'
});
data_saddle.push({
lat: 3.8886444445e+01,
lng: 1.4048722222e+02,
content:'Saddle = 1120.699951 pos = 38.8864,140.4872 diff = 241.200073'
});
data_peak.push({
lat: 3.8866333333e+01,
lng: 1.4060488889e+02,
cert : true,
content:'Name = JA/MG-017(JA/MG-017) peak = 1043.099976 pos = 38.8663,140.6049 diff = 214.399963'
});
data_saddle.push({
lat: 3.8870333333e+01,
lng: 1.4059455556e+02,
content:'Saddle = 828.700012 pos = 38.8703,140.5946 diff = 214.399963'
});
data_peak.push({
lat: 3.8967777778e+01,
lng: 1.4060622222e+02,
cert : true,
content:'Name = Takamatsudake(JA/AT-007) peak = 1347.500000 pos = 38.9678,140.6062 diff = 460.200012'
});
data_saddle.push({
lat: 3.8933555556e+01,
lng: 1.4060011111e+02,
content:'Saddle = 887.299988 pos = 38.9336,140.6001 diff = 460.200012'
});
data_peak.push({
lat: 3.8964777778e+01,
lng: 1.4065011111e+02,
cert : false,
content:' Peak = 1221.199951 pos = 38.9648,140.6501 diff = 190.699951'
});
data_saddle.push({
lat: 3.8964222222e+01,
lng: 1.4063877778e+02,
content:'Saddle = 1030.500000 pos = 38.9642,140.6388 diff = 190.699951'
});
data_peak.push({
lat: 3.8922111111e+01,
lng: 1.4061877778e+02,
cert : false,
content:' Peak = 1186.699951 pos = 38.9221,140.6188 diff = 253.599976'
});
data_saddle.push({
lat: 3.8912444445e+01,
lng: 1.4062555556e+02,
content:'Saddle = 933.099976 pos = 38.9124,140.6256 diff = 253.599976'
});
data_peak.push({
lat: 3.8933111111e+01,
lng: 1.4070288889e+02,
cert : false,
content:' Peak = 953.299988 pos = 38.9331,140.7029 diff = 212.700012'
});
data_saddle.push({
lat: 3.8934000000e+01,
lng: 1.4072344444e+02,
content:'Saddle = 740.599976 pos = 38.9340,140.7234 diff = 212.700012'
});
data_peak.push({
lat: 3.9235888889e+01,
lng: 1.4085122222e+02,
cert : false,
content:' Peak = 941.099976 pos = 39.2359,140.8512 diff = 182.699951'
});
data_saddle.push({
lat: 3.9232777778e+01,
lng: 1.4085288889e+02,
content:'Saddle = 758.400024 pos = 39.2328,140.8529 diff = 182.699951'
});
data_peak.push({
lat: 3.9020555556e+01,
lng: 1.4074011111e+02,
cert : true,
content:'Name = JA/AT-034(JA/AT-034) peak = 1014.700012 pos = 39.0206,140.7401 diff = 219.799988'
});
data_saddle.push({
lat: 3.9012555556e+01,
lng: 1.4074300000e+02,
content:'Saddle = 794.900024 pos = 39.0126,140.7430 diff = 219.799988'
});
data_peak.push({
lat: 3.9163777778e+01,
lng: 1.4082877778e+02,
cert : true,
content:'Name = Yakeishidake(JA/IT-006) peak = 1546.300049 pos = 39.1638,140.8288 diff = 723.400024'
});
data_saddle.push({
lat: 3.9117333333e+01,
lng: 1.4075588889e+02,
content:'Saddle = 822.900024 pos = 39.1173,140.7559 diff = 723.400024'
});
data_peak.push({
lat: 3.9124000000e+01,
lng: 1.4079922222e+02,
cert : false,
content:' Peak = 1091.300049 pos = 39.1240,140.7992 diff = 228.900024'
});
data_saddle.push({
lat: 3.9136777778e+01,
lng: 1.4074977778e+02,
content:'Saddle = 862.400024 pos = 39.1368,140.7498 diff = 228.900024'
});
data_peak.push({
lat: 3.9209222222e+01,
lng: 1.4076733333e+02,
cert : true,
content:'Name = JA/IT-037(JA/IT-037) peak = 1105.599976 pos = 39.2092,140.7673 diff = 227.399963'
});
data_saddle.push({
lat: 3.9200222222e+01,
lng: 1.4076644444e+02,
content:'Saddle = 878.200012 pos = 39.2002,140.7664 diff = 227.399963'
});
data_peak.push({
lat: 3.9230000000e+01,
lng: 1.4088188889e+02,
cert : false,
content:' Peak = 1097.800049 pos = 39.2300,140.8819 diff = 160.000061'
});
data_saddle.push({
lat: 3.9224666667e+01,
lng: 1.4087633333e+02,
content:'Saddle = 937.799988 pos = 39.2247,140.8763 diff = 160.000061'
});
data_peak.push({
lat: 3.9194777778e+01,
lng: 1.4077866667e+02,
cert : true,
content:'Name = JA/AT-019(JA/AT-019) peak = 1161.599976 pos = 39.1948,140.7787 diff = 159.899963'
});
data_saddle.push({
lat: 3.9188666667e+01,
lng: 1.4078922222e+02,
content:'Saddle = 1001.700012 pos = 39.1887,140.7892 diff = 159.899963'
});
data_peak.push({
lat: 3.9181000000e+01,
lng: 1.4088877778e+02,
cert : true,
content:'Name = JA/IT-009(JA/IT-009) peak = 1370.900024 pos = 39.1810,140.8888 diff = 198.000000'
});
data_saddle.push({
lat: 3.9177555556e+01,
lng: 1.4088111111e+02,
content:'Saddle = 1172.900024 pos = 39.1776,140.8811 diff = 198.000000'
});
data_peak.push({
lat: 3.9201777778e+01,
lng: 1.4086022222e+02,
cert : false,
content:' Peak = 1338.900024 pos = 39.2018,140.8602 diff = 150.900024'
});
data_saddle.push({
lat: 3.9189111111e+01,
lng: 1.4085533333e+02,
content:'Saddle = 1188.000000 pos = 39.1891,140.8553 diff = 150.900024'
});
data_peak.push({
lat: 3.9085555556e+01,
lng: 1.4075855556e+02,
cert : false,
content:' Peak = 1122.800049 pos = 39.0856,140.7586 diff = 240.600037'
});
data_saddle.push({
lat: 3.9082111111e+01,
lng: 1.4077866667e+02,
content:'Saddle = 882.200012 pos = 39.0821,140.7787 diff = 240.600037'
});
data_peak.push({
lat: 3.9038777778e+01,
lng: 1.4077800000e+02,
cert : true,
content:'Name = JA/AT-017(JA/AT-017) peak = 1164.099976 pos = 39.0388,140.7780 diff = 243.899963'
});
data_saddle.push({
lat: 3.9035888889e+01,
lng: 1.4079600000e+02,
content:'Saddle = 920.200012 pos = 39.0359,140.7960 diff = 243.899963'
});
data_peak.push({
lat: 3.9021666667e+01,
lng: 1.4078555556e+02,
cert : true,
content:'Name = JA/IT-030(JA/IT-030) peak = 1164.099976 pos = 39.0217,140.7856 diff = 196.199951'
});
data_saddle.push({
lat: 3.8994666667e+01,
lng: 1.4076688889e+02,
content:'Saddle = 967.900024 pos = 38.9947,140.7669 diff = 196.199951'
});
data_peak.push({
lat: 3.9127555556e+01,
lng: 1.4017388889e+02,
cert : true,
content:'Name = JA/AT-091(JA/AT-091) peak = 618.299988 pos = 39.1276,140.1739 diff = 180.399994'
});
data_saddle.push({
lat: 3.9123444444e+01,
lng: 1.4020011111e+02,
content:'Saddle = 437.899994 pos = 39.1234,140.2001 diff = 180.399994'
});
data_peak.push({
lat: 3.9025888889e+01,
lng: 1.4036233333e+02,
cert : true,
content:'Name = JA/AT-079(JA/AT-079) peak = 696.099976 pos = 39.0259,140.3623 diff = 182.699951'
});
data_saddle.push({
lat: 3.9026333333e+01,
lng: 1.4034322222e+02,
content:'Saddle = 513.400024 pos = 39.0263,140.3432 diff = 182.699951'
});
data_peak.push({
lat: 3.8987888889e+01,
lng: 1.4008422222e+02,
cert : true,
content:'Name = JA/YM-068(JA/YM-068) peak = 780.299988 pos = 38.9879,140.0842 diff = 207.099976'
});
data_saddle.push({
lat: 3.9000111111e+01,
lng: 1.4011800000e+02,
content:'Saddle = 573.200012 pos = 39.0001,140.1180 diff = 207.099976'
});
data_peak.push({
lat: 3.8983888889e+01,
lng: 1.4024977778e+02,
cert : false,
content:' Peak = 783.799988 pos = 38.9839,140.2498 diff = 171.099976'
});
data_saddle.push({
lat: 3.8985444445e+01,
lng: 1.4025488889e+02,
content:'Saddle = 612.700012 pos = 38.9854,140.2549 diff = 171.099976'
});
data_peak.push({
lat: 3.9006888889e+01,
lng: 1.4033211111e+02,
cert : false,
content:' Peak = 783.599976 pos = 39.0069,140.3321 diff = 160.699951'
});
data_saddle.push({
lat: 3.9008888889e+01,
lng: 1.4032500000e+02,
content:'Saddle = 622.900024 pos = 39.0089,140.3250 diff = 160.699951'
});
data_peak.push({
lat: 3.9083888889e+01,
lng: 1.4034177778e+02,
cert : true,
content:'Name = JA/AT-043(JA/AT-043) peak = 925.900024 pos = 39.0839,140.3418 diff = 297.500000'
});
data_saddle.push({
lat: 3.9065222222e+01,
lng: 1.4033488889e+02,
content:'Saddle = 628.400024 pos = 39.0652,140.3349 diff = 297.500000'
});
data_peak.push({
lat: 3.9014777778e+01,
lng: 1.4011288889e+02,
cert : true,
content:'Name = JA/YM-058(JA/YM-058) peak = 864.200012 pos = 39.0148,140.1129 diff = 211.900024'
});
data_saddle.push({
lat: 3.9024333333e+01,
lng: 1.4011833333e+02,
content:'Saddle = 652.299988 pos = 39.0243,140.1183 diff = 211.900024'
});
data_peak.push({
lat: 3.9045666667e+01,
lng: 1.4034266667e+02,
cert : true,
content:'Name = JA/AT-044(JA/AT-044) peak = 920.400024 pos = 39.0457,140.3427 diff = 258.400024'
});
data_saddle.push({
lat: 3.9032333333e+01,
lng: 1.4032133333e+02,
content:'Saddle = 662.000000 pos = 39.0323,140.3213 diff = 258.400024'
});
data_peak.push({
lat: 3.9032111111e+01,
lng: 1.4021922222e+02,
cert : true,
content:'Name = Hinotodake(JA/YM-019) peak = 1145.099976 pos = 39.0321,140.2192 diff = 462.000000'
});
data_saddle.push({
lat: 3.9043777778e+01,
lng: 1.4020255556e+02,
content:'Saddle = 683.099976 pos = 39.0438,140.2026 diff = 462.000000'
});
data_peak.push({
lat: 3.9012111111e+01,
lng: 1.4031044444e+02,
cert : true,
content:'Name = Koshikiyama (Otokokoshikiyama)(JA/YM-047) peak = 980.500000 pos = 39.0121,140.3104 diff = 258.400024'
});
data_saddle.push({
lat: 3.9015111111e+01,
lng: 1.4030377778e+02,
content:'Saddle = 722.099976 pos = 39.0151,140.3038 diff = 258.400024'
});
data_peak.push({
lat: 3.9001222222e+01,
lng: 1.4025911111e+02,
cert : false,
content:' Peak = 922.099976 pos = 39.0012,140.2591 diff = 161.299988'
});
data_saddle.push({
lat: 3.9004666667e+01,
lng: 1.4025966667e+02,
content:'Saddle = 760.799988 pos = 39.0047,140.2597 diff = 161.299988'
});
data_peak.push({
lat: 3.9028111111e+01,
lng: 1.4028644444e+02,
cert : false,
content:' Peak = 941.900024 pos = 39.0281,140.2864 diff = 159.300049'
});
data_saddle.push({
lat: 3.9029888889e+01,
lng: 1.4027900000e+02,
content:'Saddle = 782.599976 pos = 39.0299,140.2790 diff = 159.300049'
});
data_peak.push({
lat: 3.9000000000e+01,
lng: 1.4022155556e+02,
cert : false,
content:' Peak = 963.700012 pos = 39.0000,140.2216 diff = 150.100037'
});
data_saddle.push({
lat: 3.9006777778e+01,
lng: 1.4022377778e+02,
content:'Saddle = 813.599976 pos = 39.0068,140.2238 diff = 150.100037'
});
data_peak.push({
lat: 3.9009777778e+01,
lng: 1.4025944444e+02,
cert : false,
content:' Peak = 994.200012 pos = 39.0098,140.2594 diff = 157.799988'
});
data_saddle.push({
lat: 3.9018000000e+01,
lng: 1.4026044444e+02,
content:'Saddle = 836.400024 pos = 39.0180,140.2604 diff = 157.799988'
});
data_peak.push({
lat: 3.9016666667e+01,
lng: 1.4022600000e+02,
cert : true,
content:'Name = JA/YM-030(JA/YM-030) peak = 1043.800049 pos = 39.0167,140.2260 diff = 200.500061'
});
data_saddle.push({
lat: 3.9022777778e+01,
lng: 1.4022755556e+02,
content:'Saddle = 843.299988 pos = 39.0228,140.2276 diff = 200.500061'
});
data_peak.push({
lat: 3.9030666667e+01,
lng: 1.4024411111e+02,
cert : false,
content:' Peak = 1103.699951 pos = 39.0307,140.2441 diff = 212.299927'
});
data_saddle.push({
lat: 3.9027666667e+01,
lng: 1.4023555556e+02,
content:'Saddle = 891.400024 pos = 39.0277,140.2356 diff = 212.299927'
});
data_peak.push({
lat: 3.9032777778e+01,
lng: 1.4012966667e+02,
cert : false,
content:' Peak = 933.200012 pos = 39.0328,140.1297 diff = 150.600037'
});
data_saddle.push({
lat: 3.9040777778e+01,
lng: 1.4013411111e+02,
content:'Saddle = 782.599976 pos = 39.0408,140.1341 diff = 150.600037'
});
data_peak.push({
lat: 3.9081666667e+01,
lng: 1.4019177778e+02,
cert : true,
content:'Name = JA/AT-035(JA/AT-035) peak = 1007.799988 pos = 39.0817,140.1918 diff = 209.399963'
});
data_saddle.push({
lat: 3.9062666667e+01,
lng: 1.4014077778e+02,
content:'Saddle = 798.400024 pos = 39.0627,140.1408 diff = 209.399963'
});
data_peak.push({
lat: 3.9051111111e+01,
lng: 1.4017111111e+02,
cert : true,
content:'Name = JA/YM-043(JA/YM-043) peak = 981.299988 pos = 39.0511,140.1711 diff = 180.899963'
});
data_saddle.push({
lat: 3.9074222222e+01,
lng: 1.4018833333e+02,
content:'Saddle = 800.400024 pos = 39.0742,140.1883 diff = 180.899963'
});
data_peak.push({
lat: 3.9054111111e+01,
lng: 1.4011444444e+02,
cert : true,
content:'Name = JA/YM-042(JA/YM-042) peak = 994.400024 pos = 39.0541,140.1144 diff = 193.200012'
});
data_saddle.push({
lat: 3.9079333333e+01,
lng: 1.4011133333e+02,
content:'Saddle = 801.200012 pos = 39.0793,140.1113 diff = 193.200012'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:39.3333,
       south:38,
       east:142,
       west:139}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
