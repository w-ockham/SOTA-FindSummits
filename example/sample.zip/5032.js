function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.3914111111e+01,
lng: 1.3224522222e+02,
cert : true,
content:'Name = Kanōsan(JA/YG-031) peak = 690.799988 pos = 33.9141,132.2452 diff = 690.799988'
});
data_saddle.push({
lat: 3.3996222222e+01,
lng: 1.3220755556e+02,
content:'Saddle = 0.000000 pos = 33.9962,132.2076 diff = 690.799988'
});
data_peak.push({
lat: 3.3952222222e+01,
lng: 1.3234977778e+02,
cert : true,
content:'Name = JA/YG-175(JA/YG-175) peak = 164.000000 pos = 33.9522,132.3498 diff = 164.000000'
});
data_saddle.push({
lat: 3.3939333334e+01,
lng: 1.3235277778e+02,
content:'Saddle = 0.000000 pos = 33.9393,132.3528 diff = 164.000000'
});
data_peak.push({
lat: 3.3973444445e+01,
lng: 1.3214911111e+02,
cert : true,
content:'Name = Kotoishiyama(JA/YG-077) peak = 544.799988 pos = 33.9734,132.1491 diff = 544.799988'
});
data_saddle.push({
lat: 3.3856777778e+01,
lng: 1.3220811111e+02,
content:'Saddle = 0.000000 pos = 33.8568,132.2081 diff = 544.799988'
});
data_peak.push({
lat: 3.3849777778e+01,
lng: 1.3237033333e+02,
cert : false,
content:' Peak = 180.300003 pos = 33.8498,132.3703 diff = 180.300003'
});
data_saddle.push({
lat: 3.3846777778e+01,
lng: 1.3236611111e+02,
content:'Saddle = 0.000000 pos = 33.8468,132.3661 diff = 180.300003'
});
data_peak.push({
lat: 3.3792555556e+01,
lng: 1.3222533333e+02,
cert : true,
content:'Name = JA/YG-097(JA/YG-097) peak = 466.600006 pos = 33.7926,132.2253 diff = 466.600006'
});
data_saddle.push({
lat: 3.3831555556e+01,
lng: 1.3213866667e+02,
content:'Saddle = 0.000000 pos = 33.8316,132.1387 diff = 466.600006'
});
data_peak.push({
lat: 3.3812777779e+01,
lng: 1.3225300000e+02,
cert : true,
content:'Name = JA/YG-172(JA/YG-172) peak = 200.600006 pos = 33.8128,132.2530 diff = 200.600006'
});
data_saddle.push({
lat: 3.3806444445e+01,
lng: 1.3225277778e+02,
content:'Saddle = 0.000000 pos = 33.8064,132.2528 diff = 200.600006'
});
data_peak.push({
lat: 3.3806000001e+01,
lng: 1.3239488889e+02,
cert : true,
content:'Name = JA/YG-166(JA/YG-166) peak = 231.699997 pos = 33.8060,132.3949 diff = 231.699997'
});
data_saddle.push({
lat: 3.3801777779e+01,
lng: 1.3239488889e+02,
content:'Saddle = 0.000000 pos = 33.8018,132.3949 diff = 231.699997'
});
data_peak.push({
lat: 3.3834222223e+01,
lng: 1.3209344444e+02,
cert : true,
content:'Name = JA/YG-154(JA/YG-154) peak = 313.700012 pos = 33.8342,132.0934 diff = 313.700012'
});
data_saddle.push({
lat: 3.3784555556e+01,
lng: 1.3204988889e+02,
content:'Saddle = 0.000000 pos = 33.7846,132.0499 diff = 313.700012'
});
data_peak.push({
lat: 3.3793555556e+01,
lng: 1.3205000000e+02,
cert : true,
content:'Name = JA/YG-173(JA/YG-173) peak = 182.500000 pos = 33.7936,132.0500 diff = 156.000000'
});
data_saddle.push({
lat: 3.3802333334e+01,
lng: 1.3205855556e+02,
content:'Saddle = 26.500000 pos = 33.8023,132.0586 diff = 156.000000'
});
data_peak.push({
lat: 3.2829111116e+01,
lng: 1.3200077778e+02,
cert : true,
content:'Name = JA6/OT-092(JA6/OT-092) peak = 412.100006 pos = 32.8291,132.0008 diff = 412.100006'
});
data_saddle.push({
lat: 3.3766444445e+01,
lng: 1.3225655556e+02,
content:'Saddle = 0.000000 pos = 33.7664,132.2566 diff = 412.100006'
});
data_peak.push({
lat: 3.2888111116e+01,
lng: 1.3200011111e+02,
cert : false,
content:' Peak = 213.100006 pos = 32.8881,132.0001 diff = 213.100006'
});
data_saddle.push({
lat: 3.2884111116e+01,
lng: 1.3200011111e+02,
content:'Saddle = 0.000000 pos = 32.8841,132.0001 diff = 213.100006'
});
data_peak.push({
lat: 3.2960888893e+01,
lng: 1.3207133333e+02,
cert : false,
content:' Peak = 190.300003 pos = 32.9609,132.0713 diff = 190.300003'
});
data_saddle.push({
lat: 3.2952666671e+01,
lng: 1.3207288889e+02,
content:'Saddle = 0.000000 pos = 32.9527,132.0729 diff = 190.300003'
});
data_peak.push({
lat: 3.3104000004e+01,
lng: 1.3201144444e+02,
cert : false,
content:' Peak = 173.399994 pos = 33.1040,132.0114 diff = 173.399994'
});
data_saddle.push({
lat: 3.3097111115e+01,
lng: 1.3200377778e+02,
content:'Saddle = 0.000000 pos = 33.0971,132.0038 diff = 173.399994'
});
data_peak.push({
lat: 3.3057666670e+01,
lng: 1.3200922222e+02,
cert : false,
content:' Peak = 200.000000 pos = 33.0577,132.0092 diff = 200.000000'
});
data_saddle.push({
lat: 3.3054333337e+01,
lng: 1.3200266667e+02,
content:'Saddle = 0.000000 pos = 33.0543,132.0027 diff = 200.000000'
});
data_peak.push({
lat: 3.3718000001e+01,
lng: 1.3213422222e+02,
cert : false,
content:' Peak = 279.799988 pos = 33.7180,132.1342 diff = 279.799988'
});
data_saddle.push({
lat: 3.3712888890e+01,
lng: 1.3213400000e+02,
content:'Saddle = 0.000000 pos = 33.7129,132.1340 diff = 279.799988'
});
data_peak.push({
lat: 3.2919888893e+01,
lng: 1.3200244444e+02,
cert : false,
content:' Peak = 292.399994 pos = 32.9199,132.0024 diff = 292.399994'
});
data_saddle.push({
lat: 3.2905444449e+01,
lng: 1.3201000000e+02,
content:'Saddle = 0.000000 pos = 32.9054,132.0100 diff = 292.399994'
});
data_peak.push({
lat: 3.2942555560e+01,
lng: 1.3204722222e+02,
cert : false,
content:' Peak = 261.600006 pos = 32.9426,132.0472 diff = 212.100006'
});
data_saddle.push({
lat: 3.2937222226e+01,
lng: 1.3203155556e+02,
content:'Saddle = 49.500000 pos = 32.9372,132.0316 diff = 212.100006'
});
data_peak.push({
lat: 3.3853111112e+01,
lng: 1.3214233333e+02,
cert : true,
content:'Name = Oozasan(JA/YG-086) peak = 525.299988 pos = 33.8531,132.1423 diff = 516.000000'
});
data_saddle.push({
lat: 3.3961555556e+01,
lng: 1.3205577778e+02,
content:'Saddle = 9.300000 pos = 33.9616,132.0558 diff = 516.000000'
});
data_peak.push({
lat: 3.3956666667e+01,
lng: 1.3207844444e+02,
cert : false,
content:' Peak = 230.300003 pos = 33.9567,132.0784 diff = 207.800003'
});
data_saddle.push({
lat: 3.3956555556e+01,
lng: 1.3209588889e+02,
content:'Saddle = 22.500000 pos = 33.9566,132.0959 diff = 207.800003'
});
data_peak.push({
lat: 3.3910666667e+01,
lng: 1.3209577778e+02,
cert : true,
content:'Name = JA/YG-107(JA/YG-107) peak = 436.299988 pos = 33.9107,132.0958 diff = 367.299988'
});
data_saddle.push({
lat: 3.3880666667e+01,
lng: 1.3212233333e+02,
content:'Saddle = 69.000000 pos = 33.8807,132.1223 diff = 367.299988'
});
data_peak.push({
lat: 3.3932666667e+01,
lng: 1.3200066667e+02,
cert : false,
content:' Peak = 281.700012 pos = 33.9327,132.0007 diff = 244.100006'
});
data_saddle.push({
lat: 3.3976333333e+01,
lng: 1.3200000000e+02,
content:'Saddle = 37.599998 pos = 33.9763,132.0000 diff = 244.100006'
});
data_peak.push({
lat: 3.3987666667e+01,
lng: 1.3203922222e+02,
cert : true,
content:'Name = JA/YG-140(JA/YG-140) peak = 361.100006 pos = 33.9877,132.0392 diff = 298.899994'
});
data_saddle.push({
lat: 3.3999888889e+01,
lng: 1.3211900000e+02,
content:'Saddle = 62.200001 pos = 33.9999,132.1190 diff = 298.899994'
});
data_peak.push({
lat: 3.3999888889e+01,
lng: 1.3201966667e+02,
cert : false,
content:' Peak = 232.300003 pos = 33.9999,132.0197 diff = 158.500000'
});
data_saddle.push({
lat: 3.4000000000e+01,
lng: 1.3202522222e+02,
content:'Saddle = 73.800003 pos = 34.0000,132.0252 diff = 158.500000'
});
data_peak.push({
lat: 3.3989444444e+01,
lng: 1.3207755556e+02,
cert : false,
content:' Peak = 313.299988 pos = 33.9894,132.0776 diff = 185.099991'
});
data_saddle.push({
lat: 3.3988888889e+01,
lng: 1.3205488889e+02,
content:'Saddle = 128.199997 pos = 33.9889,132.0549 diff = 185.099991'
});
data_peak.push({
lat: 3.3999666667e+01,
lng: 1.3219344444e+02,
cert : false,
content:' Peak = 360.899994 pos = 33.9997,132.1934 diff = 233.199997'
});
data_saddle.push({
lat: 3.3979000000e+01,
lng: 1.3216722222e+02,
content:'Saddle = 127.699997 pos = 33.9790,132.1672 diff = 233.199997'
});
data_peak.push({
lat: 3.3981888889e+01,
lng: 1.3217755556e+02,
cert : true,
content:'Name = JA/YG-145(JA/YG-145) peak = 352.500000 pos = 33.9819,132.1776 diff = 220.699997'
});
data_saddle.push({
lat: 3.3994777778e+01,
lng: 1.3218111111e+02,
content:'Saddle = 131.800003 pos = 33.9948,132.1811 diff = 220.699997'
});
data_peak.push({
lat: 3.3888555556e+01,
lng: 1.3235111111e+02,
cert : true,
content:'Name = JA/YG-134(JA/YG-134) peak = 373.399994 pos = 33.8886,132.3511 diff = 364.799988'
});
data_saddle.push({
lat: 3.3891111112e+01,
lng: 1.3232888889e+02,
content:'Saddle = 8.600000 pos = 33.8911,132.3289 diff = 364.799988'
});
data_peak.push({
lat: 3.3890222223e+01,
lng: 1.3221922222e+02,
cert : true,
content:'Name = JA/YG-083(JA/YG-083) peak = 536.799988 pos = 33.8902,132.2192 diff = 199.199982'
});
data_saddle.push({
lat: 3.3891222223e+01,
lng: 1.3223288889e+02,
content:'Saddle = 337.600006 pos = 33.8912,132.2329 diff = 199.199982'
});
data_peak.push({
lat: 3.3912888889e+01,
lng: 1.3227088889e+02,
cert : false,
content:' Peak = 617.599976 pos = 33.9129,132.2709 diff = 165.699982'
});
data_saddle.push({
lat: 3.3915333334e+01,
lng: 1.3226544444e+02,
content:'Saddle = 451.899994 pos = 33.9153,132.2654 diff = 165.699982'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:34,
       south:32.6667,
       east:135,
       west:132}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
