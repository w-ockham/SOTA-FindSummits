function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.1934111111e+01,
lng: 1.3086177778e+02,
cert : true,
content:'Name = Kirishimayama (Karakunidake)(JA6/KG-003) peak = 1700.000000 pos = 31.9341,130.8618 diff = 1700.000000'
});
data_saddle.push({
lat: 3.1991888889e+01,
lng: 1.3017433333e+02,
content:'Saddle = 0.000000 pos = 31.9919,130.1743 diff = 1700.000000'
});
data_peak.push({
lat: 3.1195555556e+01,
lng: 1.2944777778e+02,
cert : false,
content:' Peak = 315.399994 pos = 31.1956,129.4478 diff = 315.399994'
});
data_saddle.push({
lat: 3.1175777778e+01,
lng: 1.2943522222e+02,
content:'Saddle = 0.000000 pos = 31.1758,129.4352 diff = 315.399994'
});
data_peak.push({
lat: 3.1801000000e+01,
lng: 1.2983000000e+02,
cert : false,
content:' Peak = 295.200012 pos = 31.8010,129.8300 diff = 295.200012'
});
data_saddle.push({
lat: 3.1774111111e+01,
lng: 1.2982622222e+02,
content:'Saddle = 0.000000 pos = 31.7741,129.8262 diff = 295.200012'
});
data_peak.push({
lat: 3.1833777778e+01,
lng: 1.2989711111e+02,
cert : true,
content:'Name = JA6/KG-093(JA6/KG-093) peak = 421.299988 pos = 31.8338,129.8971 diff = 421.299988'
});
data_saddle.push({
lat: 3.1800777778e+01,
lng: 1.2987222222e+02,
content:'Saddle = 0.000000 pos = 31.8008,129.8722 diff = 421.299988'
});
data_peak.push({
lat: 3.1860333333e+01,
lng: 1.2991455556e+02,
cert : false,
content:' Peak = 251.100006 pos = 31.8603,129.9146 diff = 246.400009'
});
data_saddle.push({
lat: 3.1849666667e+01,
lng: 1.2992066667e+02,
content:'Saddle = 4.700000 pos = 31.8497,129.9207 diff = 246.400009'
});
data_peak.push({
lat: 3.1858777778e+01,
lng: 1.2982322222e+02,
cert : true,
content:'Name = JA6/KG-125(JA6/KG-125) peak = 305.299988 pos = 31.8588,129.8232 diff = 282.899994'
});
data_saddle.push({
lat: 3.1863222222e+01,
lng: 1.2986855556e+02,
content:'Saddle = 22.400000 pos = 31.8632,129.8686 diff = 282.899994'
});
data_peak.push({
lat: 3.1864333333e+01,
lng: 1.2985466667e+02,
cert : false,
content:' Peak = 227.000000 pos = 31.8643,129.8547 diff = 154.300003'
});
data_saddle.push({
lat: 3.1877666667e+01,
lng: 1.2985655556e+02,
content:'Saddle = 72.699997 pos = 31.8777,129.8566 diff = 154.300003'
});
data_peak.push({
lat: 3.1844333333e+01,
lng: 1.2987433333e+02,
cert : true,
content:'Name = JA6/KG-127(JA6/KG-127) peak = 290.600006 pos = 31.8443,129.8743 diff = 192.000000'
});
data_saddle.push({
lat: 3.1840000000e+01,
lng: 1.2988711111e+02,
content:'Saddle = 98.599998 pos = 31.8400,129.8871 diff = 192.000000'
});
data_peak.push({
lat: 3.1824000000e+01,
lng: 1.2992433333e+02,
cert : false,
content:' Peak = 311.899994 pos = 31.8240,129.9243 diff = 155.099991'
});
data_saddle.push({
lat: 3.1829222222e+01,
lng: 1.2991777778e+02,
content:'Saddle = 156.800003 pos = 31.8292,129.9178 diff = 155.099991'
});
data_peak.push({
lat: 3.1723333333e+01,
lng: 1.2973933333e+02,
cert : true,
content:'Name = Otake(JA6/KG-044) peak = 603.900024 pos = 31.7233,129.7393 diff = 603.900024'
});
data_saddle.push({
lat: 3.1621222222e+01,
lng: 1.2968888889e+02,
content:'Saddle = 0.000000 pos = 31.6212,129.6889 diff = 603.900024'
});
data_peak.push({
lat: 3.1625555556e+01,
lng: 1.2971311111e+02,
cert : false,
content:' Peak = 163.800003 pos = 31.6256,129.7131 diff = 160.500000'
});
data_saddle.push({
lat: 3.1633444445e+01,
lng: 1.2971144444e+02,
content:'Saddle = 3.300000 pos = 31.6334,129.7114 diff = 160.500000'
});
data_peak.push({
lat: 3.1658444445e+01,
lng: 1.2971355556e+02,
cert : false,
content:' Peak = 482.700012 pos = 31.6584,129.7136 diff = 161.700012'
});
data_saddle.push({
lat: 3.1660666667e+01,
lng: 1.2970755556e+02,
content:'Saddle = 321.000000 pos = 31.6607,129.7076 diff = 161.700012'
});
data_peak.push({
lat: 3.0793111112e+01,
lng: 1.3030522222e+02,
cert : true,
content:'Name = Ioudake(JA6/KG-027) peak = 700.700012 pos = 30.7931,130.3052 diff = 700.700012'
});
data_saddle.push({
lat: 3.0994222223e+01,
lng: 1.3066055556e+02,
content:'Saddle = 0.000000 pos = 30.9942,130.6606 diff = 700.700012'
});
data_peak.push({
lat: 3.0812444445e+01,
lng: 1.3043277778e+02,
cert : false,
content:' Peak = 218.500000 pos = 30.8124,130.4328 diff = 218.500000'
});
data_saddle.push({
lat: 3.0800111112e+01,
lng: 1.3044222222e+02,
content:'Saddle = 0.000000 pos = 30.8001,130.4422 diff = 218.500000'
});
data_peak.push({
lat: 3.0745333334e+01,
lng: 1.3105488889e+02,
cert : false,
content:' Peak = 242.800003 pos = 30.7453,131.0549 diff = 242.800003'
});
data_saddle.push({
lat: 3.0772444445e+01,
lng: 1.3027788889e+02,
content:'Saddle = 0.000000 pos = 30.7724,130.2779 diff = 242.800003'
});
data_peak.push({
lat: 3.0666777778e+01,
lng: 1.3098011111e+02,
cert : false,
content:' Peak = 231.699997 pos = 30.6668,130.9801 diff = 157.699997'
});
data_saddle.push({
lat: 3.0746666667e+01,
lng: 1.3101244444e+02,
content:'Saddle = 74.000000 pos = 30.7467,131.0124 diff = 157.699997'
});
data_peak.push({
lat: 3.0828444445e+01,
lng: 1.2993744444e+02,
cert : true,
content:'Name = Yaguradake(JA6/KG-041) peak = 620.299988 pos = 30.8284,129.9374 diff = 620.299988'
});
data_saddle.push({
lat: 3.0811777778e+01,
lng: 1.2993011111e+02,
content:'Saddle = 0.000000 pos = 30.8118,129.9301 diff = 620.299988'
});
data_peak.push({
lat: 3.0782888889e+01,
lng: 1.3028844444e+02,
cert : false,
content:' Peak = 240.600006 pos = 30.7829,130.2884 diff = 162.400009'
});
data_saddle.push({
lat: 3.0787111112e+01,
lng: 1.3029111111e+02,
content:'Saddle = 78.199997 pos = 30.7871,130.2911 diff = 162.400009'
});
data_peak.push({
lat: 3.0794333334e+01,
lng: 1.3028433333e+02,
cert : true,
content:'Name = JA6/KG-114(JA6/KG-114) peak = 346.100006 pos = 30.7943,130.2843 diff = 234.100006'
});
data_saddle.push({
lat: 3.0794222223e+01,
lng: 1.3029344444e+02,
content:'Saddle = 112.000000 pos = 30.7942,130.2934 diff = 234.100006'
});
data_peak.push({
lat: 3.1262111111e+01,
lng: 1.3065422222e+02,
cert : false,
content:' Peak = 212.899994 pos = 31.2621,130.6542 diff = 201.799988'
});
data_saddle.push({
lat: 3.1268777778e+01,
lng: 1.3063544444e+02,
content:'Saddle = 11.100000 pos = 31.2688,130.6354 diff = 201.799988'
});
data_peak.push({
lat: 3.1001666667e+01,
lng: 1.3066211111e+02,
cert : false,
content:' Peak = 220.399994 pos = 31.0017,130.6621 diff = 198.199997'
});
data_saddle.push({
lat: 3.1012222223e+01,
lng: 1.3066600000e+02,
content:'Saddle = 22.200001 pos = 31.0122,130.6660 diff = 198.199997'
});
data_peak.push({
lat: 3.1592666667e+01,
lng: 1.3065655556e+02,
cert : true,
content:'Name = Ontake (Kitadake)(JA6/KG-008) peak = 1116.099976 pos = 31.5927,130.6566 diff = 1089.000000'
});
data_saddle.push({
lat: 3.1556222222e+01,
lng: 1.3069911111e+02,
content:'Saddle = 27.100000 pos = 31.5562,130.6991 diff = 1089.000000'
});
data_peak.push({
lat: 3.1610111111e+01,
lng: 1.3139922222e+02,
cert : false,
content:' Peak = 202.600006 pos = 31.6101,131.3992 diff = 175.400009'
});
data_saddle.push({
lat: 3.1621777778e+01,
lng: 1.3140511111e+02,
content:'Saddle = 27.200001 pos = 31.6218,131.4051 diff = 175.400009'
});
data_peak.push({
lat: 3.1565555556e+01,
lng: 1.3138188889e+02,
cert : false,
content:' Peak = 211.199997 pos = 31.5656,131.3819 diff = 183.000000'
});
data_saddle.push({
lat: 3.1571666667e+01,
lng: 1.3136755556e+02,
content:'Saddle = 28.200001 pos = 31.5717,131.3676 diff = 183.000000'
});
data_peak.push({
lat: 3.1182222223e+01,
lng: 1.3062555556e+02,
cert : false,
content:' Peak = 200.399994 pos = 31.1822,130.6256 diff = 165.699997'
});
data_saddle.push({
lat: 3.1188000000e+01,
lng: 1.3062133333e+02,
content:'Saddle = 34.700001 pos = 31.1880,130.6213 diff = 165.699997'
});
data_peak.push({
lat: 3.1569777778e+01,
lng: 1.3139300000e+02,
cert : false,
content:' Peak = 227.199997 pos = 31.5698,131.3930 diff = 186.100006'
});
data_saddle.push({
lat: 3.1580222222e+01,
lng: 1.3137033333e+02,
content:'Saddle = 41.099998 pos = 31.5802,131.3703 diff = 186.100006'
});
data_peak.push({
lat: 3.1180000000e+01,
lng: 1.3052833333e+02,
cert : true,
content:'Name = Kaimondake(JA6/KG-016) peak = 923.599976 pos = 31.1800,130.5283 diff = 881.399963'
});
data_saddle.push({
lat: 3.1204111111e+01,
lng: 1.3053233333e+02,
content:'Saddle = 42.200001 pos = 31.2041,130.5323 diff = 881.399963'
});
data_peak.push({
lat: 3.1015333334e+01,
lng: 1.3068288889e+02,
cert : false,
content:' Peak = 217.800003 pos = 31.0153,130.6829 diff = 174.399994'
});
data_saddle.push({
lat: 3.1028000000e+01,
lng: 1.3067744444e+02,
content:'Saddle = 43.400002 pos = 31.0280,130.6774 diff = 174.399994'
});
data_peak.push({
lat: 3.1545000000e+01,
lng: 1.3132822222e+02,
cert : true,
content:'Name = JA6/MZ-130(JA6/MZ-130) peak = 344.000000 pos = 31.5450,131.3282 diff = 298.100006'
});
data_saddle.push({
lat: 3.1558333334e+01,
lng: 1.3131500000e+02,
content:'Saddle = 45.900002 pos = 31.5583,131.3150 diff = 298.100006'
});
data_peak.push({
lat: 3.1264222223e+01,
lng: 1.3099011111e+02,
cert : true,
content:'Name = Hoyoshidake(JA6/KG-013) peak = 965.599976 pos = 31.2642,130.9901 diff = 903.199951'
});
data_saddle.push({
lat: 3.1361333334e+01,
lng: 1.3082233333e+02,
content:'Saddle = 62.400002 pos = 31.3613,130.8223 diff = 903.199951'
});
data_peak.push({
lat: 3.1204000000e+01,
lng: 1.3075911111e+02,
cert : false,
content:' Peak = 230.300003 pos = 31.2040,130.7591 diff = 162.700012'
});
data_saddle.push({
lat: 3.1197888889e+01,
lng: 1.3077300000e+02,
content:'Saddle = 67.599998 pos = 31.1979,130.7730 diff = 162.700012'
});
data_peak.push({
lat: 3.1328111111e+01,
lng: 1.3097066667e+02,
cert : true,
content:'Name = JA6/KG-132(JA6/KG-132) peak = 280.399994 pos = 31.3281,130.9707 diff = 168.299988'
});
data_saddle.push({
lat: 3.1330444445e+01,
lng: 1.3097833333e+02,
content:'Saddle = 112.099998 pos = 31.3304,130.9783 diff = 168.299988'
});
data_peak.push({
lat: 3.1286777778e+01,
lng: 1.3090066667e+02,
cert : false,
content:' Peak = 281.299988 pos = 31.2868,130.9007 diff = 163.899994'
});
data_saddle.push({
lat: 3.1274666667e+01,
lng: 1.3090288889e+02,
content:'Saddle = 117.400002 pos = 31.2747,130.9029 diff = 163.899994'
});
data_peak.push({
lat: 3.1301333334e+01,
lng: 1.3094911111e+02,
cert : true,
content:'Name = JA6/KG-118(JA6/KG-118) peak = 321.600006 pos = 31.3013,130.9491 diff = 191.000000'
});
data_saddle.push({
lat: 3.1294111111e+01,
lng: 1.3094244444e+02,
content:'Saddle = 130.600006 pos = 31.2941,130.9424 diff = 191.000000'
});
data_peak.push({
lat: 3.1295111111e+01,
lng: 1.3086500000e+02,
cert : false,
content:' Peak = 484.500000 pos = 31.2951,130.8650 diff = 303.600006'
});
data_saddle.push({
lat: 3.1253777778e+01,
lng: 1.3086200000e+02,
content:'Saddle = 180.899994 pos = 31.2538,130.8620 diff = 303.600006'
});
data_peak.push({
lat: 3.1056555556e+01,
lng: 1.3070377778e+02,
cert : true,
content:'Name = JA6/KG-116(JA6/KG-116) peak = 347.600006 pos = 31.0566,130.7038 diff = 156.900009'
});
data_saddle.push({
lat: 3.1081222223e+01,
lng: 1.3070911111e+02,
content:'Saddle = 190.699997 pos = 31.0812,130.7091 diff = 156.900009'
});
data_peak.push({
lat: 3.1270333334e+01,
lng: 1.3092844444e+02,
cert : false,
content:' Peak = 460.899994 pos = 31.2703,130.9284 diff = 161.799988'
});
data_saddle.push({
lat: 3.1263888889e+01,
lng: 1.3093133333e+02,
content:'Saddle = 299.100006 pos = 31.2639,130.9313 diff = 161.799988'
});
data_peak.push({
lat: 3.1129555556e+01,
lng: 1.3088011111e+02,
cert : true,
content:'Name = JA6/KG-014(JA6/KG-014) peak = 956.200012 pos = 31.1296,130.8801 diff = 489.200012'
});
data_saddle.push({
lat: 3.1173666667e+01,
lng: 1.3093066667e+02,
content:'Saddle = 467.000000 pos = 31.1737,130.9307 diff = 489.200012'
});
data_peak.push({
lat: 3.1136444445e+01,
lng: 1.3077044444e+02,
cert : true,
content:'Name = JA6/KG-018(JA6/KG-018) peak = 896.500000 pos = 31.1364,130.7704 diff = 298.700012'
});
data_saddle.push({
lat: 3.1131666667e+01,
lng: 1.3078622222e+02,
content:'Saddle = 597.799988 pos = 31.1317,130.7862 diff = 298.700012'
});
data_peak.push({
lat: 3.1125555556e+01,
lng: 1.3080700000e+02,
cert : true,
content:'Name = JA6/KG-019(JA6/KG-019) peak = 890.799988 pos = 31.1256,130.8070 diff = 237.299988'
});
data_saddle.push({
lat: 3.1128777778e+01,
lng: 1.3084188889e+02,
content:'Saddle = 653.500000 pos = 31.1288,130.8419 diff = 237.299988'
});
data_peak.push({
lat: 3.1226777778e+01,
lng: 1.3092533333e+02,
cert : true,
content:'Name = JA6/KG-015(JA6/KG-015) peak = 940.000000 pos = 31.2268,130.9253 diff = 443.500000'
});
data_saddle.push({
lat: 3.1249333334e+01,
lng: 1.3097500000e+02,
content:'Saddle = 496.500000 pos = 31.2493,130.9750 diff = 443.500000'
});
data_peak.push({
lat: 3.1184888889e+01,
lng: 1.3094455556e+02,
cert : true,
content:'Name = JA6/KG-024(JA6/KG-024) peak = 751.799988 pos = 31.1849,130.9446 diff = 214.200012'
});
data_saddle.push({
lat: 3.1193111111e+01,
lng: 1.3093566667e+02,
content:'Saddle = 537.599976 pos = 31.1931,130.9357 diff = 214.200012'
});
data_peak.push({
lat: 3.1249555556e+01,
lng: 1.3100522222e+02,
cert : true,
content:'Name = JA6/KG-025(JA6/KG-025) peak = 741.799988 pos = 31.2496,131.0052 diff = 169.599976'
});
data_saddle.push({
lat: 3.1253555556e+01,
lng: 1.3099844444e+02,
content:'Saddle = 572.200012 pos = 31.2536,130.9984 diff = 169.599976'
});
data_peak.push({
lat: 3.1290111111e+01,
lng: 1.3099100000e+02,
cert : true,
content:'Name = JA6/KG-017(JA6/KG-017) peak = 912.200012 pos = 31.2901,130.9910 diff = 181.900024'
});
data_saddle.push({
lat: 3.1285111111e+01,
lng: 1.3099322222e+02,
content:'Saddle = 730.299988 pos = 31.2851,130.9932 diff = 181.900024'
});
data_peak.push({
lat: 3.1583888889e+01,
lng: 1.3136177778e+02,
cert : false,
content:' Peak = 220.899994 pos = 31.5839,131.3618 diff = 153.699997'
});
data_saddle.push({
lat: 3.1591333333e+01,
lng: 1.3135755556e+02,
content:'Saddle = 67.199997 pos = 31.5913,131.3576 diff = 153.699997'
});
data_peak.push({
lat: 3.1867666667e+01,
lng: 1.3041066667e+02,
cert : false,
content:' Peak = 240.100006 pos = 31.8677,130.4107 diff = 162.400009'
});
data_saddle.push({
lat: 3.1876444444e+01,
lng: 1.3040333333e+02,
content:'Saddle = 77.699997 pos = 31.8764,130.4033 diff = 162.400009'
});
data_peak.push({
lat: 3.1998222222e+01,
lng: 1.3121233333e+02,
cert : false,
content:' Peak = 230.600006 pos = 31.9982,131.2123 diff = 152.800003'
});
data_saddle.push({
lat: 3.1999888889e+01,
lng: 1.3119788889e+02,
content:'Saddle = 77.800003 pos = 31.9999,131.1979 diff = 152.800003'
});
data_peak.push({
lat: 3.1274111111e+01,
lng: 1.3024588889e+02,
cert : false,
content:' Peak = 261.700012 pos = 31.2741,130.2459 diff = 183.700012'
});
data_saddle.push({
lat: 3.1286555556e+01,
lng: 1.3025533333e+02,
content:'Saddle = 78.000000 pos = 31.2866,130.2553 diff = 183.700012'
});
data_peak.push({
lat: 3.1830666667e+01,
lng: 1.3034666667e+02,
cert : true,
content:'Name = JA6/KG-123(JA6/KG-123) peak = 310.299988 pos = 31.8307,130.3467 diff = 231.499985'
});
data_saddle.push({
lat: 3.1819555556e+01,
lng: 1.3035388889e+02,
content:'Saddle = 78.800003 pos = 31.8196,130.3539 diff = 231.499985'
});
data_peak.push({
lat: 3.1612000000e+01,
lng: 1.3035000000e+02,
cert : false,
content:' Peak = 241.300003 pos = 31.6120,130.3500 diff = 154.500000'
});
data_saddle.push({
lat: 3.1620666667e+01,
lng: 1.3036077778e+02,
content:'Saddle = 86.800003 pos = 31.6207,130.3608 diff = 154.500000'
});
data_peak.push({
lat: 3.1490000000e+01,
lng: 1.3134388889e+02,
cert : false,
content:' Peak = 369.799988 pos = 31.4900,131.3439 diff = 282.199982'
});
data_saddle.push({
lat: 3.1496444445e+01,
lng: 1.3131877778e+02,
content:'Saddle = 87.599998 pos = 31.4964,131.3188 diff = 282.199982'
});
data_peak.push({
lat: 3.1483777778e+01,
lng: 1.3137266667e+02,
cert : true,
content:'Name = JA6/MZ-136(JA6/MZ-136) peak = 271.000000 pos = 31.4838,131.3727 diff = 152.000000'
});
data_saddle.push({
lat: 3.1492444445e+01,
lng: 1.3136555556e+02,
content:'Saddle = 119.000000 pos = 31.4924,131.3656 diff = 152.000000'
});
data_peak.push({
lat: 3.1776777778e+01,
lng: 1.3024177778e+02,
cert : true,
content:'Name = JA6/KG-061(JA6/KG-061) peak = 527.099976 pos = 31.7768,130.2418 diff = 439.199982'
});
data_saddle.push({
lat: 3.1753111111e+01,
lng: 1.3029677778e+02,
content:'Saddle = 87.900002 pos = 31.7531,130.2968 diff = 439.199982'
});
data_peak.push({
lat: 3.1404555556e+01,
lng: 1.3015822222e+02,
cert : true,
content:'Name = Nomadake(JA6/KG-047) peak = 591.000000 pos = 31.4046,130.1582 diff = 502.700012'
});
data_saddle.push({
lat: 3.1347666667e+01,
lng: 1.3027611111e+02,
content:'Saddle = 88.300003 pos = 31.3477,130.2761 diff = 502.700012'
});
data_peak.push({
lat: 3.1380333334e+01,
lng: 1.3026722222e+02,
cert : true,
content:'Name = JA6/KG-069(JA6/KG-069) peak = 513.099976 pos = 31.3803,130.2672 diff = 420.699982'
});
data_saddle.push({
lat: 3.1378222222e+01,
lng: 1.3017111111e+02,
content:'Saddle = 92.400002 pos = 31.3782,130.1711 diff = 420.699982'
});
data_peak.push({
lat: 3.1380222222e+01,
lng: 1.3018322222e+02,
cert : false,
content:' Peak = 360.200012 pos = 31.3802,130.1832 diff = 192.400009'
});
data_saddle.push({
lat: 3.1374111111e+01,
lng: 1.3019211111e+02,
content:'Saddle = 167.800003 pos = 31.3741,130.1921 diff = 192.400009'
});
data_peak.push({
lat: 3.1329000000e+01,
lng: 1.3022411111e+02,
cert : true,
content:'Name = JA6/KG-081(JA6/KG-081) peak = 462.799988 pos = 31.3290,130.2241 diff = 294.500000'
});
data_saddle.push({
lat: 3.1354777778e+01,
lng: 1.3026200000e+02,
content:'Saddle = 168.300003 pos = 31.3548,130.2620 diff = 294.500000'
});
data_peak.push({
lat: 3.1304333334e+01,
lng: 1.3024722222e+02,
cert : true,
content:'Name = JA6/KG-086(JA6/KG-086) peak = 444.200012 pos = 31.3043,130.2472 diff = 206.500015'
});
data_saddle.push({
lat: 3.1325555556e+01,
lng: 1.3023188889e+02,
content:'Saddle = 237.699997 pos = 31.3256,130.2319 diff = 206.500015'
});
data_peak.push({
lat: 3.1607888889e+01,
lng: 1.3136011111e+02,
cert : false,
content:' Peak = 274.200012 pos = 31.6079,131.3601 diff = 177.200012'
});
data_saddle.push({
lat: 3.1599777778e+01,
lng: 1.3131600000e+02,
content:'Saddle = 97.000000 pos = 31.5998,131.3160 diff = 177.200012'
});
data_peak.push({
lat: 3.1989444444e+01,
lng: 1.3022688889e+02,
cert : true,
content:'Name = JA6/KG-120(JA6/KG-120) peak = 320.799988 pos = 31.9894,130.2269 diff = 223.499985'
});
data_saddle.push({
lat: 3.1986777778e+01,
lng: 1.3023655556e+02,
content:'Saddle = 97.300003 pos = 31.9868,130.2366 diff = 223.499985'
});
data_peak.push({
lat: 3.1222888889e+01,
lng: 1.3059500000e+02,
cert : true,
content:'Name = JA6/KG-100(JA6/KG-100) peak = 411.100006 pos = 31.2229,130.5950 diff = 312.600006'
});
data_saddle.push({
lat: 3.1261555556e+01,
lng: 1.3056533333e+02,
content:'Saddle = 98.500000 pos = 31.2616,130.5653 diff = 312.600006'
});
data_peak.push({
lat: 3.1787000000e+01,
lng: 1.3035344444e+02,
cert : true,
content:'Name = JA6/KG-117(JA6/KG-117) peak = 340.000000 pos = 31.7870,130.3534 diff = 237.399994'
});
data_saddle.push({
lat: 3.1776222222e+01,
lng: 1.3037611111e+02,
content:'Saddle = 102.599998 pos = 31.7762,130.3761 diff = 237.399994'
});
data_peak.push({
lat: 3.1443777778e+01,
lng: 1.3133566667e+02,
cert : true,
content:'Name = JA6/MZ-111(JA6/MZ-111) peak = 532.599976 pos = 31.4438,131.3357 diff = 427.099976'
});
data_saddle.push({
lat: 3.1539111111e+01,
lng: 1.3127811111e+02,
content:'Saddle = 105.500000 pos = 31.5391,131.2781 diff = 427.099976'
});
data_peak.push({
lat: 3.1372555556e+01,
lng: 1.3133111111e+02,
cert : false,
content:' Peak = 298.399994 pos = 31.3726,131.3311 diff = 185.500000'
});
data_saddle.push({
lat: 3.1397333334e+01,
lng: 1.3132011111e+02,
content:'Saddle = 112.900002 pos = 31.3973,131.3201 diff = 185.500000'
});
data_peak.push({
lat: 3.1525777778e+01,
lng: 1.3129011111e+02,
cert : true,
content:'Name = JA6/MZ-127(JA6/MZ-127) peak = 365.200012 pos = 31.5258,131.2901 diff = 237.700012'
});
data_saddle.push({
lat: 3.1514000000e+01,
lng: 1.3128911111e+02,
content:'Saddle = 127.500000 pos = 31.5140,131.2891 diff = 237.700012'
});
data_peak.push({
lat: 3.1493777778e+01,
lng: 1.3130366667e+02,
cert : true,
content:'Name = JA6/MZ-128(JA6/MZ-128) peak = 361.700012 pos = 31.4938,131.3037 diff = 200.700012'
});
data_saddle.push({
lat: 3.1488444445e+01,
lng: 1.3128800000e+02,
content:'Saddle = 161.000000 pos = 31.4884,131.2880 diff = 200.700012'
});
data_peak.push({
lat: 3.1905333333e+01,
lng: 1.3029100000e+02,
cert : false,
content:' Peak = 263.100006 pos = 31.9053,130.2910 diff = 156.600006'
});
data_saddle.push({
lat: 3.1914333333e+01,
lng: 1.3028000000e+02,
content:'Saddle = 106.500000 pos = 31.9143,130.2800 diff = 156.600006'
});
data_peak.push({
lat: 3.1431666667e+01,
lng: 1.3035711111e+02,
cert : true,
content:'Name = JA6/KG-130(JA6/KG-130) peak = 286.899994 pos = 31.4317,130.3571 diff = 176.399994'
});
data_saddle.push({
lat: 3.1438000000e+01,
lng: 1.3036888889e+02,
content:'Saddle = 110.500000 pos = 31.4380,130.3689 diff = 176.399994'
});
data_peak.push({
lat: 3.1507444445e+01,
lng: 1.3104177778e+02,
cert : false,
content:' Peak = 273.600006 pos = 31.5074,131.0418 diff = 161.500000'
});
data_saddle.push({
lat: 3.1520777778e+01,
lng: 1.3103466667e+02,
content:'Saddle = 112.099998 pos = 31.5208,131.0347 diff = 161.500000'
});
data_peak.push({
lat: 3.1486777778e+01,
lng: 1.3114577778e+02,
cert : true,
content:'Name = JA6/KG-113(JA6/KG-113) peak = 344.899994 pos = 31.4868,131.1458 diff = 230.899994'
});
data_saddle.push({
lat: 3.1488777778e+01,
lng: 1.3116622222e+02,
content:'Saddle = 114.000000 pos = 31.4888,131.1662 diff = 230.899994'
});
data_peak.push({
lat: 3.1472000000e+01,
lng: 1.3117800000e+02,
cert : false,
content:' Peak = 283.200012 pos = 31.4720,131.1780 diff = 164.400009'
});
data_saddle.push({
lat: 3.1472111111e+01,
lng: 1.3116955556e+02,
content:'Saddle = 118.800003 pos = 31.4721,131.1696 diff = 164.400009'
});
data_peak.push({
lat: 3.1508000000e+01,
lng: 1.3121022222e+02,
cert : false,
content:' Peak = 504.299988 pos = 31.5080,131.2102 diff = 377.799988'
});
data_saddle.push({
lat: 3.1522444445e+01,
lng: 1.3120411111e+02,
content:'Saddle = 126.500000 pos = 31.5224,131.2041 diff = 377.799988'
});
data_peak.push({
lat: 3.1486666667e+01,
lng: 1.3118288889e+02,
cert : false,
content:' Peak = 333.799988 pos = 31.4867,131.1829 diff = 161.199982'
});
data_saddle.push({
lat: 3.1493222222e+01,
lng: 1.3118133333e+02,
content:'Saddle = 172.600006 pos = 31.4932,131.1813 diff = 161.199982'
});
data_peak.push({
lat: 3.1871666667e+01,
lng: 1.3046366667e+02,
cert : true,
content:'Name = JA6/KG-107(JA6/KG-107) peak = 383.399994 pos = 31.8717,130.4637 diff = 256.599976'
});
data_saddle.push({
lat: 3.1876333333e+01,
lng: 1.3051366667e+02,
content:'Saddle = 126.800003 pos = 31.8763,130.5137 diff = 256.599976'
});
data_peak.push({
lat: 3.1339777778e+01,
lng: 1.3030244444e+02,
cert : true,
content:'Name = JA6/KG-078(JA6/KG-078) peak = 474.500000 pos = 31.3398,130.3024 diff = 332.200012'
});
data_saddle.push({
lat: 3.1321555556e+01,
lng: 1.3042688889e+02,
content:'Saddle = 142.300003 pos = 31.3216,130.4269 diff = 332.200012'
});
data_peak.push({
lat: 3.1311333334e+01,
lng: 1.3035300000e+02,
cert : true,
content:'Name = JA6/KG-098(JA6/KG-098) peak = 413.899994 pos = 31.3113,130.3530 diff = 216.099991'
});
data_saddle.push({
lat: 3.1317555556e+01,
lng: 1.3032633333e+02,
content:'Saddle = 197.800003 pos = 31.3176,130.3263 diff = 216.099991'
});
data_peak.push({
lat: 3.1294333334e+01,
lng: 1.3033455556e+02,
cert : true,
content:'Name = JA6/KG-103(JA6/KG-103) peak = 390.799988 pos = 31.2943,130.3346 diff = 191.599991'
});
data_saddle.push({
lat: 3.1308666667e+01,
lng: 1.3034777778e+02,
content:'Saddle = 199.199997 pos = 31.3087,130.3478 diff = 191.599991'
});
data_peak.push({
lat: 3.1980888889e+01,
lng: 1.3036755556e+02,
cert : true,
content:'Name = Shibisan (Jyougusan)(JA6/KG-010) peak = 1066.300049 pos = 31.9809,130.3676 diff = 919.500061'
});
data_saddle.push({
lat: 3.2000000000e+01,
lng: 1.3047288889e+02,
content:'Saddle = 146.800003 pos = 32.0000,130.4729 diff = 919.500061'
});
data_peak.push({
lat: 3.1999666667e+01,
lng: 1.3044766667e+02,
cert : false,
content:' Peak = 390.399994 pos = 31.9997,130.4477 diff = 241.000000'
});
data_saddle.push({
lat: 3.1999888889e+01,
lng: 1.3043277778e+02,
content:'Saddle = 149.399994 pos = 31.9999,130.4328 diff = 241.000000'
});
data_peak.push({
lat: 3.2000000000e+01,
lng: 1.3046033333e+02,
cert : false,
content:' Peak = 363.000000 pos = 32.0000,130.4603 diff = 204.800003'
});
data_saddle.push({
lat: 3.2000000000e+01,
lng: 1.3045533333e+02,
content:'Saddle = 158.199997 pos = 32.0000,130.4553 diff = 204.800003'
});
data_peak.push({
lat: 3.1904666667e+01,
lng: 1.3027677778e+02,
cert : true,
content:'Name = JA6/KG-110(JA6/KG-110) peak = 364.799988 pos = 31.9047,130.2768 diff = 198.099991'
});
data_saddle.push({
lat: 3.1911444444e+01,
lng: 1.3027188889e+02,
content:'Saddle = 166.699997 pos = 31.9114,130.2719 diff = 198.099991'
});
data_peak.push({
lat: 3.1891888889e+01,
lng: 1.3036500000e+02,
cert : false,
content:' Peak = 431.399994 pos = 31.8919,130.3650 diff = 161.899994'
});
data_saddle.push({
lat: 3.1914666667e+01,
lng: 1.3037344444e+02,
content:'Saddle = 269.500000 pos = 31.9147,130.3734 diff = 161.899994'
});
data_peak.push({
lat: 3.1967444444e+01,
lng: 1.3026788889e+02,
cert : true,
content:'Name = JA6/KG-046(JA6/KG-046) peak = 603.500000 pos = 31.9674,130.2679 diff = 190.399994'
});
data_saddle.push({
lat: 3.1955000000e+01,
lng: 1.3028400000e+02,
content:'Saddle = 413.100006 pos = 31.9550,130.2840 diff = 190.399994'
});
data_peak.push({
lat: 3.1944888889e+01,
lng: 1.3034211111e+02,
cert : false,
content:' Peak = 682.400024 pos = 31.9449,130.3421 diff = 150.300049'
});
data_saddle.push({
lat: 3.1954333333e+01,
lng: 1.3034488889e+02,
content:'Saddle = 532.099976 pos = 31.9543,130.3449 diff = 150.300049'
});
data_peak.push({
lat: 3.1598222222e+01,
lng: 1.3038111111e+02,
cert : true,
content:'Name = JA6/KG-124(JA6/KG-124) peak = 310.600006 pos = 31.5982,130.3811 diff = 159.900009'
});
data_saddle.push({
lat: 3.1602555556e+01,
lng: 1.3039333333e+02,
content:'Saddle = 150.699997 pos = 31.6026,130.3933 diff = 159.900009'
});
data_peak.push({
lat: 3.1602777778e+01,
lng: 1.3129777778e+02,
cert : false,
content:' Peak = 313.399994 pos = 31.6028,131.2978 diff = 160.899994'
});
data_saddle.push({
lat: 3.1606555556e+01,
lng: 1.3128855556e+02,
content:'Saddle = 152.500000 pos = 31.6066,131.2886 diff = 160.899994'
});
data_peak.push({
lat: 3.1467777778e+01,
lng: 1.3038288889e+02,
cert : true,
content:'Name = Kinpouzan(JA6/KG-039) peak = 632.099976 pos = 31.4678,130.3829 diff = 472.499969'
});
data_saddle.push({
lat: 3.1685666667e+01,
lng: 1.3045966667e+02,
content:'Saddle = 159.600006 pos = 31.6857,130.4597 diff = 472.499969'
});
data_peak.push({
lat: 3.1384111111e+01,
lng: 1.3050633333e+02,
cert : true,
content:'Name = JA6/KG-043(JA6/KG-043) peak = 604.599976 pos = 31.3841,130.5063 diff = 359.899963'
});
data_saddle.push({
lat: 3.1476555556e+01,
lng: 1.3039466667e+02,
content:'Saddle = 244.699997 pos = 31.4766,130.3947 diff = 359.899963'
});
data_peak.push({
lat: 3.1256000000e+01,
lng: 1.3051666667e+02,
cert : true,
content:'Name = JA6/KG-080(JA6/KG-080) peak = 463.299988 pos = 31.2560,130.5167 diff = 211.499985'
});
data_saddle.push({
lat: 3.1261777778e+01,
lng: 1.3052733333e+02,
content:'Saddle = 251.800003 pos = 31.2618,130.5273 diff = 211.499985'
});
data_peak.push({
lat: 3.1470555556e+01,
lng: 1.3042933333e+02,
cert : true,
content:'Name = JA6/KG-059(JA6/KG-059) peak = 531.500000 pos = 31.4706,130.4293 diff = 250.000000'
});
data_saddle.push({
lat: 3.1480333334e+01,
lng: 1.3047855556e+02,
content:'Saddle = 281.500000 pos = 31.4803,130.4786 diff = 250.000000'
});
data_peak.push({
lat: 3.1504222222e+01,
lng: 1.3046677778e+02,
cert : false,
content:' Peak = 483.799988 pos = 31.5042,130.4668 diff = 170.399994'
});
data_saddle.push({
lat: 3.1499555556e+01,
lng: 1.3042777778e+02,
content:'Saddle = 313.399994 pos = 31.4996,130.4278 diff = 170.399994'
});
data_peak.push({
lat: 3.1310666667e+01,
lng: 1.3052633333e+02,
cert : true,
content:'Name = JA6/KG-052(JA6/KG-052) peak = 576.500000 pos = 31.3107,130.5263 diff = 242.500000'
});
data_saddle.push({
lat: 3.1329666667e+01,
lng: 1.3050777778e+02,
content:'Saddle = 334.000000 pos = 31.3297,130.5078 diff = 242.500000'
});
data_peak.push({
lat: 3.1455222222e+01,
lng: 1.3046377778e+02,
cert : false,
content:' Peak = 588.000000 pos = 31.4552,130.4638 diff = 242.899994'
});
data_saddle.push({
lat: 3.1405111111e+01,
lng: 1.3050288889e+02,
content:'Saddle = 345.100006 pos = 31.4051,130.5029 diff = 242.899994'
});
data_peak.push({
lat: 3.1425888889e+01,
lng: 1.3047755556e+02,
cert : true,
content:'Name = JA6/KG-049(JA6/KG-049) peak = 584.500000 pos = 31.4259,130.4776 diff = 222.500000'
});
data_saddle.push({
lat: 3.1464111111e+01,
lng: 1.3048000000e+02,
content:'Saddle = 362.000000 pos = 31.4641,130.4800 diff = 222.500000'
});
data_peak.push({
lat: 3.1991888889e+01,
lng: 1.3048300000e+02,
cert : false,
content:' Peak = 401.700012 pos = 31.9919,130.4830 diff = 240.700012'
});
data_saddle.push({
lat: 3.1989111111e+01,
lng: 1.3049200000e+02,
content:'Saddle = 161.000000 pos = 31.9891,130.4920 diff = 240.700012'
});
data_peak.push({
lat: 3.1559444445e+01,
lng: 1.3106388889e+02,
cert : false,
content:' Peak = 420.000000 pos = 31.5594,131.0639 diff = 259.000000'
});
data_saddle.push({
lat: 3.1572222222e+01,
lng: 1.3107222222e+02,
content:'Saddle = 161.000000 pos = 31.5722,131.0722 diff = 259.000000'
});
data_peak.push({
lat: 3.1999111111e+01,
lng: 1.3109500000e+02,
cert : false,
content:' Peak = 620.700012 pos = 31.9991,131.0950 diff = 452.300018'
});
data_saddle.push({
lat: 3.1999888889e+01,
lng: 1.3099477778e+02,
content:'Saddle = 168.399994 pos = 31.9999,130.9948 diff = 452.300018'
});
data_peak.push({
lat: 3.2000000000e+01,
lng: 1.3106111111e+02,
cert : false,
content:' Peak = 592.200012 pos = 32.0000,131.0611 diff = 318.900024'
});
data_saddle.push({
lat: 3.2000000000e+01,
lng: 1.3107055556e+02,
content:'Saddle = 273.299988 pos = 32.0000,131.0706 diff = 318.900024'
});
data_peak.push({
lat: 3.2000000000e+01,
lng: 1.3113355556e+02,
cert : false,
content:' Peak = 523.200012 pos = 32.0000,131.1336 diff = 227.100006'
});
data_saddle.push({
lat: 3.2000000000e+01,
lng: 1.3111666667e+02,
content:'Saddle = 296.100006 pos = 32.0000,131.1167 diff = 227.100006'
});
data_peak.push({
lat: 3.1739222222e+01,
lng: 1.3029488889e+02,
cert : true,
content:'Name = JA6/KG-115(JA6/KG-115) peak = 346.799988 pos = 31.7392,130.2949 diff = 174.799988'
});
data_saddle.push({
lat: 3.1747111111e+01,
lng: 1.3031233333e+02,
content:'Saddle = 172.000000 pos = 31.7471,130.3123 diff = 174.799988'
});
data_peak.push({
lat: 3.1568333334e+01,
lng: 1.3127633333e+02,
cert : true,
content:'Name = JA6/MZ-115(JA6/MZ-115) peak = 483.600006 pos = 31.5683,131.2763 diff = 308.500000'
});
data_saddle.push({
lat: 3.1575888889e+01,
lng: 1.3126877778e+02,
content:'Saddle = 175.100006 pos = 31.5759,131.2688 diff = 308.500000'
});
data_peak.push({
lat: 3.1910444444e+01,
lng: 1.3111477778e+02,
cert : true,
content:'Name = JA6/MZ-124(JA6/MZ-124) peak = 374.100006 pos = 31.9104,131.1148 diff = 197.100006'
});
data_saddle.push({
lat: 3.1923000000e+01,
lng: 1.3110244444e+02,
content:'Saddle = 177.000000 pos = 31.9230,131.1024 diff = 197.100006'
});
data_peak.push({
lat: 3.1768888889e+01,
lng: 1.3126944444e+02,
cert : true,
content:'Name = Wanitsukayama(JA6/MZ-036) peak = 1117.400024 pos = 31.7689,131.2694 diff = 933.300049'
});
data_saddle.push({
lat: 3.1642777778e+01,
lng: 1.3100966667e+02,
content:'Saddle = 184.100006 pos = 31.6428,131.0097 diff = 933.300049'
});
data_peak.push({
lat: 3.1896666667e+01,
lng: 1.3127455556e+02,
cert : true,
content:'Name = JA6/MZ-120(JA6/MZ-120) peak = 453.700012 pos = 31.8967,131.2746 diff = 266.400024'
});
data_saddle.push({
lat: 3.1859444445e+01,
lng: 1.3127911111e+02,
content:'Saddle = 187.300003 pos = 31.8594,131.2791 diff = 266.400024'
});
data_peak.push({
lat: 3.1832111111e+01,
lng: 1.3114811111e+02,
cert : false,
content:' Peak = 373.500000 pos = 31.8321,131.1481 diff = 170.600006'
});
data_saddle.push({
lat: 3.1818222222e+01,
lng: 1.3116311111e+02,
content:'Saddle = 202.899994 pos = 31.8182,131.1631 diff = 170.600006'
});
data_peak.push({
lat: 3.1906888889e+01,
lng: 1.3115000000e+02,
cert : false,
content:' Peak = 363.899994 pos = 31.9069,131.1500 diff = 155.899994'
});
data_saddle.push({
lat: 3.1903111111e+01,
lng: 1.3116188889e+02,
content:'Saddle = 208.000000 pos = 31.9031,131.1619 diff = 155.899994'
});
data_peak.push({
lat: 3.1892444444e+01,
lng: 1.3117455556e+02,
cert : false,
content:' Peak = 372.899994 pos = 31.8924,131.1746 diff = 164.799988'
});
data_saddle.push({
lat: 3.1886111111e+01,
lng: 1.3116911111e+02,
content:'Saddle = 208.100006 pos = 31.8861,131.1691 diff = 164.799988'
});
data_peak.push({
lat: 3.1590888889e+01,
lng: 1.3108255556e+02,
cert : true,
content:'Name = JA6/KG-066(JA6/KG-066) peak = 523.099976 pos = 31.5909,131.0826 diff = 270.399963'
});
data_saddle.push({
lat: 3.1594666667e+01,
lng: 1.3109344444e+02,
content:'Saddle = 252.699997 pos = 31.5947,131.0934 diff = 270.399963'
});
data_peak.push({
lat: 3.1585111111e+01,
lng: 1.3111544444e+02,
cert : false,
content:' Peak = 450.899994 pos = 31.5851,131.1154 diff = 196.500000'
});
data_saddle.push({
lat: 3.1624111111e+01,
lng: 1.3112411111e+02,
content:'Saddle = 254.399994 pos = 31.6241,131.1241 diff = 196.500000'
});
data_peak.push({
lat: 3.1550333334e+01,
lng: 1.3117144444e+02,
cert : true,
content:'Name = JA6/KG-094(JA6/KG-094) peak = 422.600006 pos = 31.5503,131.1714 diff = 165.399994'
});
data_saddle.push({
lat: 3.1571444445e+01,
lng: 1.3116433333e+02,
content:'Saddle = 257.200012 pos = 31.5714,131.1643 diff = 165.399994'
});
data_peak.push({
lat: 3.1580444445e+01,
lng: 1.3115411111e+02,
cert : true,
content:'Name = JA6/KG-060(JA6/KG-060) peak = 533.500000 pos = 31.5804,131.1541 diff = 241.000000'
});
data_saddle.push({
lat: 3.1596666667e+01,
lng: 1.3116433333e+02,
content:'Saddle = 292.500000 pos = 31.5967,131.1643 diff = 241.000000'
});
data_peak.push({
lat: 3.1851111111e+01,
lng: 1.3121033333e+02,
cert : true,
content:'Name = JA6/MZ-107(JA6/MZ-107) peak = 563.900024 pos = 31.8511,131.2103 diff = 256.200012'
});
data_saddle.push({
lat: 3.1801555556e+01,
lng: 1.3120788889e+02,
content:'Saddle = 307.700012 pos = 31.8016,131.2079 diff = 256.200012'
});
data_peak.push({
lat: 3.1798222222e+01,
lng: 1.3137577778e+02,
cert : true,
content:'Name = JA6/MZ-112(JA6/MZ-112) peak = 507.299988 pos = 31.7982,131.3758 diff = 194.299988'
});
data_saddle.push({
lat: 3.1787555556e+01,
lng: 1.3136955556e+02,
content:'Saddle = 313.000000 pos = 31.7876,131.3696 diff = 194.299988'
});
data_peak.push({
lat: 3.1752333333e+01,
lng: 1.3139588889e+02,
cert : true,
content:'Name = JA6/MZ-084(JA6/MZ-084) peak = 732.099976 pos = 31.7523,131.3959 diff = 384.899963'
});
data_saddle.push({
lat: 3.1759000000e+01,
lng: 1.3136188889e+02,
content:'Saddle = 347.200012 pos = 31.7590,131.3619 diff = 384.899963'
});
data_peak.push({
lat: 3.1749777778e+01,
lng: 1.3136366667e+02,
cert : false,
content:' Peak = 586.000000 pos = 31.7498,131.3637 diff = 178.899994'
});
data_saddle.push({
lat: 3.1755888889e+01,
lng: 1.3138288889e+02,
content:'Saddle = 407.100006 pos = 31.7559,131.3829 diff = 178.899994'
});
data_peak.push({
lat: 3.1669666667e+01,
lng: 1.3133888889e+02,
cert : true,
content:'Name = JA6/MZ-103(JA6/MZ-103) peak = 612.000000 pos = 31.6697,131.3389 diff = 259.500000'
});
data_saddle.push({
lat: 3.1670888889e+01,
lng: 1.3131911111e+02,
content:'Saddle = 352.500000 pos = 31.6709,131.3191 diff = 259.500000'
});
data_peak.push({
lat: 3.1633000000e+01,
lng: 1.3109200000e+02,
cert : false,
content:' Peak = 520.099976 pos = 31.6330,131.0920 diff = 162.499969'
});
data_saddle.push({
lat: 3.1651777778e+01,
lng: 1.3109288889e+02,
content:'Saddle = 357.600006 pos = 31.6518,131.0929 diff = 162.499969'
});
data_peak.push({
lat: 3.1809888889e+01,
lng: 1.3133466667e+02,
cert : true,
content:'Name = JA6/MZ-102(JA6/MZ-102) peak = 610.599976 pos = 31.8099,131.3347 diff = 233.399963'
});
data_saddle.push({
lat: 3.1804555556e+01,
lng: 1.3132888889e+02,
content:'Saddle = 377.200012 pos = 31.8046,131.3289 diff = 233.399963'
});
data_peak.push({
lat: 3.1612777778e+01,
lng: 1.3125800000e+02,
cert : true,
content:'Name = JA6/MZ-080(JA6/MZ-080) peak = 783.099976 pos = 31.6128,131.2580 diff = 405.299988'
});
data_saddle.push({
lat: 3.1626555556e+01,
lng: 1.3123322222e+02,
content:'Saddle = 377.799988 pos = 31.6266,131.2332 diff = 405.299988'
});
data_peak.push({
lat: 3.1802666667e+01,
lng: 1.3131833333e+02,
cert : true,
content:'Name = JA6/MZ-093(JA6/MZ-093) peak = 678.400024 pos = 31.8027,131.3183 diff = 231.400024'
});
data_saddle.push({
lat: 3.1790111111e+01,
lng: 1.3131922222e+02,
content:'Saddle = 447.000000 pos = 31.7901,131.3192 diff = 231.400024'
});
data_peak.push({
lat: 3.1786888889e+01,
lng: 1.3133677778e+02,
cert : true,
content:'Name = JA6/MZ-100(JA6/MZ-100) peak = 636.400024 pos = 31.7869,131.3368 diff = 188.600037'
});
data_saddle.push({
lat: 3.1781222222e+01,
lng: 1.3132900000e+02,
content:'Saddle = 447.799988 pos = 31.7812,131.3290 diff = 188.600037'
});
data_peak.push({
lat: 3.1672444445e+01,
lng: 1.3121066667e+02,
cert : false,
content:' Peak = 791.400024 pos = 31.6724,131.2107 diff = 313.600037'
});
data_saddle.push({
lat: 3.1683222222e+01,
lng: 1.3120622222e+02,
content:'Saddle = 477.799988 pos = 31.6832,131.2062 diff = 313.600037'
});
data_peak.push({
lat: 3.1630000000e+01,
lng: 1.3117966667e+02,
cert : true,
content:'Name = JA6/MZ-091(JA6/MZ-091) peak = 701.099976 pos = 31.6300,131.1797 diff = 209.299988'
});
data_saddle.push({
lat: 3.1645555556e+01,
lng: 1.3117000000e+02,
content:'Saddle = 491.799988 pos = 31.6456,131.1700 diff = 209.299988'
});
data_peak.push({
lat: 3.1644777778e+01,
lng: 1.3119377778e+02,
cert : true,
content:'Name = JA6/MZ-081(JA6/MZ-081) peak = 764.299988 pos = 31.6448,131.1938 diff = 201.200012'
});
data_saddle.push({
lat: 3.1655888889e+01,
lng: 1.3118011111e+02,
content:'Saddle = 563.099976 pos = 31.6559,131.1801 diff = 201.200012'
});
data_peak.push({
lat: 3.1625888889e+01,
lng: 1.3121611111e+02,
cert : false,
content:' Peak = 744.400024 pos = 31.6259,131.2161 diff = 161.600037'
});
data_saddle.push({
lat: 3.1635000000e+01,
lng: 1.3120966667e+02,
content:'Saddle = 582.799988 pos = 31.6350,131.2097 diff = 161.600037'
});
data_peak.push({
lat: 3.1620555556e+01,
lng: 1.3120833333e+02,
cert : false,
content:' Peak = 740.599976 pos = 31.6206,131.2083 diff = 157.799988'
});
data_saddle.push({
lat: 3.1624444445e+01,
lng: 1.3121066667e+02,
content:'Saddle = 582.799988 pos = 31.6244,131.2107 diff = 157.799988'
});
data_peak.push({
lat: 3.1722000000e+01,
lng: 1.3128222222e+02,
cert : true,
content:'Name = JA6/MZ-079(JA6/MZ-079) peak = 793.200012 pos = 31.7220,131.2822 diff = 221.799988'
});
data_saddle.push({
lat: 3.1757444445e+01,
lng: 1.3130888889e+02,
content:'Saddle = 571.400024 pos = 31.7574,131.3089 diff = 221.799988'
});
data_peak.push({
lat: 3.1781444445e+01,
lng: 1.3130644444e+02,
cert : true,
content:'Name = JA6/MZ-072(JA6/MZ-072) peak = 833.799988 pos = 31.7814,131.3064 diff = 241.899963'
});
data_saddle.push({
lat: 3.1767222222e+01,
lng: 1.3129955556e+02,
content:'Saddle = 591.900024 pos = 31.7672,131.2996 diff = 241.899963'
});
data_peak.push({
lat: 3.1685333333e+01,
lng: 1.3127600000e+02,
cert : false,
content:' Peak = 987.700012 pos = 31.6853,131.2760 diff = 368.400024'
});
data_saddle.push({
lat: 3.1682555556e+01,
lng: 1.3123555556e+02,
content:'Saddle = 619.299988 pos = 31.6826,131.2356 diff = 368.400024'
});
data_peak.push({
lat: 3.1715111111e+01,
lng: 1.3121044444e+02,
cert : false,
content:' Peak = 951.700012 pos = 31.7151,131.2104 diff = 288.700012'
});
data_saddle.push({
lat: 3.1725222222e+01,
lng: 1.3123488889e+02,
content:'Saddle = 663.000000 pos = 31.7252,131.2349 diff = 288.700012'
});
data_peak.push({
lat: 3.1669333333e+01,
lng: 1.3115866667e+02,
cert : true,
content:'Name = JA6/MZ-058(JA6/MZ-058) peak = 917.099976 pos = 31.6693,131.1587 diff = 235.099976'
});
data_saddle.push({
lat: 3.1676777778e+01,
lng: 1.3116444444e+02,
content:'Saddle = 682.000000 pos = 31.6768,131.1644 diff = 235.099976'
});
data_peak.push({
lat: 3.1728777778e+01,
lng: 1.3123833333e+02,
cert : true,
content:'Name = JA6/MZ-070(JA6/MZ-070) peak = 845.700012 pos = 31.7288,131.2383 diff = 178.400024'
});
data_saddle.push({
lat: 3.1738000000e+01,
lng: 1.3126100000e+02,
content:'Saddle = 667.299988 pos = 31.7380,131.2610 diff = 178.400024'
});
data_peak.push({
lat: 3.1779444445e+01,
lng: 1.3122733333e+02,
cert : false,
content:' Peak = 910.599976 pos = 31.7794,131.2273 diff = 177.299988'
});
data_saddle.push({
lat: 3.1770333333e+01,
lng: 1.3123366667e+02,
content:'Saddle = 733.299988 pos = 31.7703,131.2337 diff = 177.299988'
});
data_peak.push({
lat: 3.1749222222e+01,
lng: 1.3033177778e+02,
cert : true,
content:'Name = Kanmuridake (Nishidake)(JA6/KG-068) peak = 512.900024 pos = 31.7492,130.3318 diff = 326.500031'
});
data_saddle.push({
lat: 3.1734111111e+01,
lng: 1.3041388889e+02,
content:'Saddle = 186.399994 pos = 31.7341,130.4139 diff = 326.500031'
});
data_peak.push({
lat: 3.1732222222e+01,
lng: 1.3035744444e+02,
cert : true,
content:'Name = JA6/KG-092(JA6/KG-092) peak = 430.299988 pos = 31.7322,130.3574 diff = 199.999985'
});
data_saddle.push({
lat: 3.1745666667e+01,
lng: 1.3038800000e+02,
content:'Saddle = 230.300003 pos = 31.7457,130.3880 diff = 199.999985'
});
data_peak.push({
lat: 3.1734555556e+01,
lng: 1.3044833333e+02,
cert : true,
content:'Name = Yaeyama(JA6/KG-032) peak = 676.400024 pos = 31.7346,130.4483 diff = 481.000031'
});
data_saddle.push({
lat: 3.1766444445e+01,
lng: 1.3049222222e+02,
content:'Saddle = 195.399994 pos = 31.7664,130.4922 diff = 481.000031'
});
data_peak.push({
lat: 3.1737000000e+01,
lng: 1.3053155556e+02,
cert : true,
content:'Name = JA6/KG-111(JA6/KG-111) peak = 360.600006 pos = 31.7370,130.5316 diff = 162.500000'
});
data_saddle.push({
lat: 3.1739888889e+01,
lng: 1.3052488889e+02,
content:'Saddle = 198.100006 pos = 31.7399,130.5249 diff = 162.500000'
});
data_peak.push({
lat: 3.1701222222e+01,
lng: 1.3038166667e+02,
cert : false,
content:' Peak = 371.600006 pos = 31.7012,130.3817 diff = 163.500000'
});
data_saddle.push({
lat: 3.1714444445e+01,
lng: 1.3039533333e+02,
content:'Saddle = 208.100006 pos = 31.7144,130.3953 diff = 163.500000'
});
data_peak.push({
lat: 3.1745777778e+01,
lng: 1.3051377778e+02,
cert : true,
content:'Name = JA6/KG-088(JA6/KG-088) peak = 434.299988 pos = 31.7458,130.5138 diff = 212.099991'
});
data_saddle.push({
lat: 3.1742333333e+01,
lng: 1.3051077778e+02,
content:'Saddle = 222.199997 pos = 31.7423,130.5108 diff = 212.099991'
});
data_peak.push({
lat: 3.1697333333e+01,
lng: 1.3058288889e+02,
cert : false,
content:' Peak = 580.900024 pos = 31.6973,130.5829 diff = 356.100037'
});
data_saddle.push({
lat: 3.1687222222e+01,
lng: 1.3056177778e+02,
content:'Saddle = 224.800003 pos = 31.6872,130.5618 diff = 356.100037'
});
data_peak.push({
lat: 3.1690333333e+01,
lng: 1.3052100000e+02,
cert : true,
content:'Name = JA6/KG-074(JA6/KG-074) peak = 484.399994 pos = 31.6903,130.5210 diff = 241.599991'
});
data_saddle.push({
lat: 3.1700777778e+01,
lng: 1.3052266667e+02,
content:'Saddle = 242.800003 pos = 31.7008,130.5227 diff = 241.599991'
});
data_peak.push({
lat: 3.1699444445e+01,
lng: 1.3042044444e+02,
cert : true,
content:'Name = JA6/KG-065(JA6/KG-065) peak = 522.500000 pos = 31.6994,130.4204 diff = 255.399994'
});
data_saddle.push({
lat: 3.1716111111e+01,
lng: 1.3042688889e+02,
content:'Saddle = 267.100006 pos = 31.7161,130.4269 diff = 255.399994'
});
data_peak.push({
lat: 3.1720111111e+01,
lng: 1.3051166667e+02,
cert : false,
content:' Peak = 542.500000 pos = 31.7201,130.5117 diff = 234.100006'
});
data_saddle.push({
lat: 3.1724777778e+01,
lng: 1.3049444444e+02,
content:'Saddle = 308.399994 pos = 31.7248,130.4944 diff = 234.100006'
});
data_peak.push({
lat: 3.1749111111e+01,
lng: 1.3048744444e+02,
cert : true,
content:'Name = JA6/KG-055(JA6/KG-055) peak = 543.000000 pos = 31.7491,130.4874 diff = 200.500000'
});
data_saddle.push({
lat: 3.1742111111e+01,
lng: 1.3048066667e+02,
content:'Saddle = 342.500000 pos = 31.7421,130.4807 diff = 200.500000'
});
data_peak.push({
lat: 3.1916666667e+01,
lng: 1.3105733333e+02,
cert : true,
content:'Name = JA6/MZ-125(JA6/MZ-125) peak = 374.200012 pos = 31.9167,131.0573 diff = 178.700012'
});
data_saddle.push({
lat: 3.1931111111e+01,
lng: 1.3103300000e+02,
content:'Saddle = 195.500000 pos = 31.9311,131.0330 diff = 178.700012'
});
data_peak.push({
lat: 3.1866000000e+01,
lng: 1.3100022222e+02,
cert : false,
content:' Peak = 450.399994 pos = 31.8660,131.0002 diff = 251.399994'
});
data_saddle.push({
lat: 3.1838444445e+01,
lng: 1.3100011111e+02,
content:'Saddle = 199.000000 pos = 31.8384,131.0001 diff = 251.399994'
});
data_peak.push({
lat: 3.1870111111e+01,
lng: 1.3102311111e+02,
cert : false,
content:' Peak = 430.799988 pos = 31.8701,131.0231 diff = 183.999985'
});
data_saddle.push({
lat: 3.1873444444e+01,
lng: 1.3100011111e+02,
content:'Saddle = 246.800003 pos = 31.8734,131.0001 diff = 183.999985'
});
data_peak.push({
lat: 3.1822555556e+01,
lng: 1.3046111111e+02,
cert : true,
content:'Name = JA6/KG-070(JA6/KG-070) peak = 504.000000 pos = 31.8226,130.4611 diff = 302.500000'
});
data_saddle.push({
lat: 3.1823888889e+01,
lng: 1.3049477778e+02,
content:'Saddle = 201.500000 pos = 31.8239,130.4948 diff = 302.500000'
});
data_peak.push({
lat: 3.1837000000e+01,
lng: 1.3049555556e+02,
cert : true,
content:'Name = JA6/KG-087(JA6/KG-087) peak = 441.600006 pos = 31.8370,130.4956 diff = 239.700012'
});
data_saddle.push({
lat: 3.1826666667e+01,
lng: 1.3048922222e+02,
content:'Saddle = 201.899994 pos = 31.8267,130.4892 diff = 239.700012'
});
data_peak.push({
lat: 3.1776666667e+01,
lng: 1.3051366667e+02,
cert : true,
content:'Name = JA6/KG-095(JA6/KG-095) peak = 421.200012 pos = 31.7767,130.5137 diff = 184.500015'
});
data_saddle.push({
lat: 3.1779000000e+01,
lng: 1.3051122222e+02,
content:'Saddle = 236.699997 pos = 31.7790,130.5112 diff = 184.500015'
});
data_peak.push({
lat: 3.1874888889e+01,
lng: 1.3060600000e+02,
cert : true,
content:'Name = JA6/KG-028(JA6/KG-028) peak = 702.099976 pos = 31.8749,130.6060 diff = 464.499969'
});
data_saddle.push({
lat: 3.1925555556e+01,
lng: 1.3072577778e+02,
content:'Saddle = 237.600006 pos = 31.9256,130.7258 diff = 464.499969'
});
data_peak.push({
lat: 3.1766222222e+01,
lng: 1.3050877778e+02,
cert : true,
content:'Name = JA6/KG-079(JA6/KG-079) peak = 474.200012 pos = 31.7662,130.5088 diff = 236.400009'
});
data_saddle.push({
lat: 3.1807333333e+01,
lng: 1.3050977778e+02,
content:'Saddle = 237.800003 pos = 31.8073,130.5098 diff = 236.400009'
});
data_peak.push({
lat: 3.1788111111e+01,
lng: 1.3051200000e+02,
cert : false,
content:' Peak = 401.899994 pos = 31.7881,130.5120 diff = 150.299988'
});
data_saddle.push({
lat: 3.1789444445e+01,
lng: 1.3050811111e+02,
content:'Saddle = 251.600006 pos = 31.7894,130.5081 diff = 150.299988'
});
data_peak.push({
lat: 3.1785111111e+01,
lng: 1.3049211111e+02,
cert : false,
content:' Peak = 423.500000 pos = 31.7851,130.4921 diff = 161.200012'
});
data_saddle.push({
lat: 3.1784666667e+01,
lng: 1.3049633333e+02,
content:'Saddle = 262.299988 pos = 31.7847,130.4963 diff = 161.200012'
});
data_peak.push({
lat: 3.1794000000e+01,
lng: 1.3050766667e+02,
cert : false,
content:' Peak = 453.700012 pos = 31.7940,130.5077 diff = 151.000000'
});
data_saddle.push({
lat: 3.1779000000e+01,
lng: 1.3050288889e+02,
content:'Saddle = 302.700012 pos = 31.7790,130.5029 diff = 151.000000'
});
data_peak.push({
lat: 3.1989000000e+01,
lng: 1.3054177778e+02,
cert : true,
content:'Name = JA6/KG-089(JA6/KG-089) peak = 436.299988 pos = 31.9890,130.5418 diff = 187.999985'
});
data_saddle.push({
lat: 3.1962222222e+01,
lng: 1.3055233333e+02,
content:'Saddle = 248.300003 pos = 31.9622,130.5523 diff = 187.999985'
});
data_peak.push({
lat: 3.1808888889e+01,
lng: 1.3051466667e+02,
cert : false,
content:' Peak = 421.500000 pos = 31.8089,130.5147 diff = 164.700012'
});
data_saddle.push({
lat: 3.1818333333e+01,
lng: 1.3051144444e+02,
content:'Saddle = 256.799988 pos = 31.8183,130.5114 diff = 164.700012'
});
data_peak.push({
lat: 3.1833888889e+01,
lng: 1.3053511111e+02,
cert : false,
content:' Peak = 515.099976 pos = 31.8339,130.5351 diff = 217.099976'
});
data_saddle.push({
lat: 3.1847111111e+01,
lng: 1.3054333333e+02,
content:'Saddle = 298.000000 pos = 31.8471,130.5433 diff = 217.099976'
});
data_peak.push({
lat: 3.1927888889e+01,
lng: 1.3063677778e+02,
cert : true,
content:'Name = JA6/KG-037(JA6/KG-037) peak = 647.900024 pos = 31.9279,130.6368 diff = 300.400024'
});
data_saddle.push({
lat: 3.1898111111e+01,
lng: 1.3062755556e+02,
content:'Saddle = 347.500000 pos = 31.8981,130.6276 diff = 300.400024'
});
data_peak.push({
lat: 3.1909888889e+01,
lng: 1.3060622222e+02,
cert : true,
content:'Name = Chayagaoka(JA6/KG-054) peak = 564.000000 pos = 31.9099,130.6062 diff = 186.799988'
});
data_saddle.push({
lat: 3.1887222222e+01,
lng: 1.3062188889e+02,
content:'Saddle = 377.200012 pos = 31.8872,130.6219 diff = 186.799988'
});
data_peak.push({
lat: 3.1902555556e+01,
lng: 1.3058233333e+02,
cert : false,
content:' Peak = 650.700012 pos = 31.9026,130.5823 diff = 217.900024'
});
data_saddle.push({
lat: 3.1898444444e+01,
lng: 1.3058233333e+02,
content:'Saddle = 432.799988 pos = 31.8984,130.5823 diff = 217.900024'
});
data_peak.push({
lat: 3.1856666667e+01,
lng: 1.3057488889e+02,
cert : false,
content:' Peak = 665.299988 pos = 31.8567,130.5749 diff = 187.599976'
});
data_saddle.push({
lat: 3.1872222222e+01,
lng: 1.3057566667e+02,
content:'Saddle = 477.700012 pos = 31.8722,130.5757 diff = 187.599976'
});
data_peak.push({
lat: 3.1846444445e+01,
lng: 1.3063466667e+02,
cert : true,
content:'Name = JA6/KG-031(JA6/KG-031) peak = 681.099976 pos = 31.8464,130.6347 diff = 168.399963'
});
data_saddle.push({
lat: 3.1866888889e+01,
lng: 1.3061700000e+02,
content:'Saddle = 512.700012 pos = 31.8669,130.6170 diff = 168.399963'
});
data_peak.push({
lat: 3.1485888889e+01,
lng: 1.3081900000e+02,
cert : true,
content:'Name = Takakumayama (Oonogaradake)(JA6/KG-006) peak = 1232.199951 pos = 31.4859,130.8190 diff = 870.499939'
});
data_saddle.push({
lat: 3.1833888889e+01,
lng: 1.3087488889e+02,
content:'Saddle = 361.700012 pos = 31.8339,130.8749 diff = 870.499939'
});
data_peak.push({
lat: 3.1828777778e+01,
lng: 1.3088755556e+02,
cert : false,
content:' Peak = 574.000000 pos = 31.8288,130.8876 diff = 206.600006'
});
data_saddle.push({
lat: 3.1779888889e+01,
lng: 1.3089222222e+02,
content:'Saddle = 367.399994 pos = 31.7799,130.8922 diff = 206.600006'
});
data_peak.push({
lat: 3.1728222222e+01,
lng: 1.3090111111e+02,
cert : false,
content:' Peak = 604.500000 pos = 31.7282,130.9011 diff = 221.899994'
});
data_saddle.push({
lat: 3.1669111111e+01,
lng: 1.3084388889e+02,
content:'Saddle = 382.600006 pos = 31.6691,130.8439 diff = 221.899994'
});
data_peak.push({
lat: 3.1767222222e+01,
lng: 1.3087800000e+02,
cert : false,
content:' Peak = 570.299988 pos = 31.7672,130.8780 diff = 158.199982'
});
data_saddle.push({
lat: 3.1743888889e+01,
lng: 1.3086722222e+02,
content:'Saddle = 412.100006 pos = 31.7439,130.8672 diff = 158.199982'
});
data_peak.push({
lat: 3.1546111111e+01,
lng: 1.3078755556e+02,
cert : true,
content:'Name = JA6/KG-020(JA6/KG-020) peak = 881.900024 pos = 31.5461,130.7876 diff = 350.300049'
});
data_saddle.push({
lat: 3.1524666667e+01,
lng: 1.3077111111e+02,
content:'Saddle = 531.599976 pos = 31.5247,130.7711 diff = 350.300049'
});
data_peak.push({
lat: 3.1506555556e+01,
lng: 1.3079811111e+02,
cert : true,
content:'Name = JA6/KG-021(JA6/KG-021) peak = 881.000000 pos = 31.5066,130.7981 diff = 173.400024'
});
data_saddle.push({
lat: 3.1500777778e+01,
lng: 1.3080622222e+02,
content:'Saddle = 707.599976 pos = 31.5008,130.8062 diff = 173.400024'
});
data_peak.push({
lat: 3.1461888889e+01,
lng: 1.3079466667e+02,
cert : false,
content:' Peak = 1101.500000 pos = 31.4619,130.7947 diff = 163.299988'
});
data_saddle.push({
lat: 3.1464222222e+01,
lng: 1.3080011111e+02,
content:'Saddle = 938.200012 pos = 31.4642,130.8001 diff = 163.299988'
});
data_peak.push({
lat: 3.1460333334e+01,
lng: 1.3082055556e+02,
cert : false,
content:' Peak = 1181.000000 pos = 31.4603,130.8206 diff = 178.500000'
});
data_saddle.push({
lat: 3.1464444445e+01,
lng: 1.3081477778e+02,
content:'Saddle = 1002.500000 pos = 31.4644,130.8148 diff = 178.500000'
});
data_peak.push({
lat: 3.1981666667e+01,
lng: 1.3079622222e+02,
cert : true,
content:'Name = JA6/MZ-071(JA6/MZ-071) peak = 846.200012 pos = 31.9817,130.7962 diff = 206.799988'
});
data_saddle.push({
lat: 3.1974333333e+01,
lng: 1.3079522222e+02,
content:'Saddle = 639.400024 pos = 31.9743,130.7952 diff = 206.799988'
});
data_peak.push({
lat: 3.1954666667e+01,
lng: 1.3079166667e+02,
cert : true,
content:'Name = JA6/KG-009(JA6/KG-009) peak = 1101.599976 pos = 31.9547,130.7917 diff = 159.299988'
});
data_saddle.push({
lat: 3.1947777778e+01,
lng: 1.3080777778e+02,
content:'Saddle = 942.299988 pos = 31.9478,130.8078 diff = 159.299988'
});
data_peak.push({
lat: 3.1950777778e+01,
lng: 1.3090844444e+02,
cert : false,
content:' Peak = 1340.800049 pos = 31.9508,130.9084 diff = 188.600098'
});
data_saddle.push({
lat: 3.1945444444e+01,
lng: 1.3090777778e+02,
content:'Saddle = 1152.199951 pos = 31.9454,130.9078 diff = 188.600098'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:32,
       south:30.6667,
       east:132,
       west:129}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
