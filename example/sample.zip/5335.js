function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.4173555556e+01,
lng: 1.3590744444e+02,
cert : true,
content:'Name = Hakkyougadake(JA/NR-001) peak = 1911.500000 pos = 34.1736,135.9074 diff = 1911.500000'
});
data_saddle.push({
lat: 3.4727111112e+01,
lng: 1.3533544444e+02,
content:'Saddle = 0.000000 pos = 34.7271,135.3354 diff = 1911.500000'
});
data_peak.push({
lat: 3.4565888889e+01,
lng: 1.3500477778e+02,
cert : false,
content:' Peak = 242.800003 pos = 34.5659,135.0048 diff = 242.800003'
});
data_saddle.push({
lat: 3.4550555556e+01,
lng: 1.3500188889e+02,
content:'Saddle = 0.000000 pos = 34.5506,135.0019 diff = 242.800003'
});
data_peak.push({
lat: 3.4184333334e+01,
lng: 1.3519533333e+02,
cert : false,
content:' Peak = 227.500000 pos = 34.1843,135.1953 diff = 221.000000'
});
data_saddle.push({
lat: 3.4181666667e+01,
lng: 1.3521222222e+02,
content:'Saddle = 6.500000 pos = 34.1817,135.2122 diff = 221.000000'
});
data_peak.push({
lat: 3.4256666667e+01,
lng: 1.3654544444e+02,
cert : false,
content:' Peak = 162.800003 pos = 34.2567,136.5454 diff = 156.199997'
});
data_saddle.push({
lat: 3.4262000001e+01,
lng: 1.3654344444e+02,
content:'Saddle = 6.600000 pos = 34.2620,136.5434 diff = 156.199997'
});
data_peak.push({
lat: 3.4090666667e+01,
lng: 1.3629588889e+02,
cert : false,
content:' Peak = 173.399994 pos = 34.0907,136.2959 diff = 166.699997'
});
data_saddle.push({
lat: 3.4096111112e+01,
lng: 1.3629800000e+02,
content:'Saddle = 6.700000 pos = 34.0961,136.2980 diff = 166.699997'
});
data_peak.push({
lat: 3.3668444445e+01,
lng: 1.3536755556e+02,
cert : false,
content:' Peak = 162.399994 pos = 33.6684,135.3676 diff = 154.500000'
});
data_saddle.push({
lat: 3.3677222223e+01,
lng: 1.3538500000e+02,
content:'Saddle = 7.900000 pos = 33.6772,135.3850 diff = 154.500000'
});
data_peak.push({
lat: 3.4269444445e+01,
lng: 1.3654922222e+02,
cert : false,
content:' Peak = 191.199997 pos = 34.2694,136.5492 diff = 181.399994'
});
data_saddle.push({
lat: 3.4275555556e+01,
lng: 1.3654211111e+02,
content:'Saddle = 9.800000 pos = 34.2756,136.5421 diff = 181.399994'
});
data_peak.push({
lat: 3.4093555556e+01,
lng: 1.3627422222e+02,
cert : false,
content:' Peak = 300.899994 pos = 34.0936,136.2742 diff = 288.100006'
});
data_saddle.push({
lat: 3.4133444445e+01,
lng: 1.3626522222e+02,
content:'Saddle = 12.800000 pos = 34.1334,136.2652 diff = 288.100006'
});
data_peak.push({
lat: 3.4074222223e+01,
lng: 1.3512166667e+02,
cert : false,
content:' Peak = 174.199997 pos = 34.0742,135.1217 diff = 157.599991'
});
data_saddle.push({
lat: 3.4063888890e+01,
lng: 1.3513933333e+02,
content:'Saddle = 16.600000 pos = 34.0639,135.1393 diff = 157.599991'
});
data_peak.push({
lat: 3.3885222223e+01,
lng: 1.3506311111e+02,
cert : false,
content:' Peak = 201.199997 pos = 33.8852,135.0631 diff = 183.599991'
});
data_saddle.push({
lat: 3.3891888890e+01,
lng: 1.3506855556e+02,
content:'Saddle = 17.600000 pos = 33.8919,135.0686 diff = 183.599991'
});
data_peak.push({
lat: 3.4063222223e+01,
lng: 1.3516388889e+02,
cert : false,
content:' Peak = 244.300003 pos = 34.0632,135.1639 diff = 225.100006'
});
data_saddle.push({
lat: 3.4060777779e+01,
lng: 1.3519833333e+02,
content:'Saddle = 19.200001 pos = 34.0608,135.1983 diff = 225.100006'
});
data_peak.push({
lat: 3.5433444445e+01,
lng: 1.3678144444e+02,
cert : true,
content:'Name = Kinkazan(JA/GF-204) peak = 327.100006 pos = 35.4334,136.7814 diff = 302.000000'
});
data_saddle.push({
lat: 3.5433888889e+01,
lng: 1.3680433333e+02,
content:'Saddle = 25.100000 pos = 35.4339,136.8043 diff = 302.000000'
});
data_peak.push({
lat: 3.5438555556e+01,
lng: 1.3682466667e+02,
cert : false,
content:' Peak = 268.200012 pos = 35.4386,136.8247 diff = 235.700012'
});
data_saddle.push({
lat: 3.5441777778e+01,
lng: 1.3684200000e+02,
content:'Saddle = 32.500000 pos = 35.4418,136.8420 diff = 235.700012'
});
data_peak.push({
lat: 3.5429777778e+01,
lng: 1.3682922222e+02,
cert : false,
content:' Peak = 243.199997 pos = 35.4298,136.8292 diff = 198.000000'
});
data_saddle.push({
lat: 3.5433000000e+01,
lng: 1.3682500000e+02,
content:'Saddle = 45.200001 pos = 35.4330,136.8250 diff = 198.000000'
});
data_peak.push({
lat: 3.5476333334e+01,
lng: 1.3675155556e+02,
cert : false,
content:' Peak = 286.100006 pos = 35.4763,136.7516 diff = 249.600006'
});
data_saddle.push({
lat: 3.5515000000e+01,
lng: 1.3675722222e+02,
content:'Saddle = 36.500000 pos = 35.5150,136.7572 diff = 249.600006'
});
data_peak.push({
lat: 3.5477555556e+01,
lng: 1.3676911111e+02,
cert : false,
content:' Peak = 230.899994 pos = 35.4776,136.7691 diff = 187.599991'
});
data_saddle.push({
lat: 3.5487777778e+01,
lng: 1.3676544444e+02,
content:'Saddle = 43.299999 pos = 35.4878,136.7654 diff = 187.599991'
});
data_peak.push({
lat: 3.5499444445e+01,
lng: 1.3676355556e+02,
cert : true,
content:'Name = JA/GF-207(JA/GF-207) peak = 274.700012 pos = 35.4994,136.7636 diff = 176.300018'
});
data_saddle.push({
lat: 3.5495000000e+01,
lng: 1.3675566667e+02,
content:'Saddle = 98.400002 pos = 35.4950,136.7557 diff = 176.300018'
});
data_peak.push({
lat: 3.5463222222e+01,
lng: 1.3680011111e+02,
cert : false,
content:' Peak = 415.600006 pos = 35.4632,136.8001 diff = 377.200012'
});
data_saddle.push({
lat: 3.5490888889e+01,
lng: 1.3683155556e+02,
content:'Saddle = 38.400002 pos = 35.4909,136.8316 diff = 377.200012'
});
data_peak.push({
lat: 3.4347333334e+01,
lng: 1.3675344444e+02,
cert : false,
content:' Peak = 212.000000 pos = 34.3473,136.7534 diff = 165.300003'
});
data_saddle.push({
lat: 3.4355555556e+01,
lng: 1.3675066667e+02,
content:'Saddle = 46.700001 pos = 34.3556,136.7507 diff = 165.300003'
});
data_peak.push({
lat: 3.4324222223e+01,
lng: 1.3678811111e+02,
cert : false,
content:' Peak = 201.399994 pos = 34.3242,136.7881 diff = 152.899994'
});
data_saddle.push({
lat: 3.4342111112e+01,
lng: 1.3678322222e+02,
content:'Saddle = 48.500000 pos = 34.3421,136.7832 diff = 152.899994'
});
data_peak.push({
lat: 3.5417555556e+01,
lng: 1.3698477778e+02,
cert : true,
content:'Name = JA/GF-203(JA/GF-203) peak = 338.600006 pos = 35.4176,136.9848 diff = 290.200012'
});
data_saddle.push({
lat: 3.5423666667e+01,
lng: 1.3699888889e+02,
content:'Saddle = 48.400002 pos = 35.4237,136.9989 diff = 290.200012'
});
data_peak.push({
lat: 3.5333777778e+01,
lng: 1.3697966667e+02,
cert : false,
content:' Peak = 292.000000 pos = 35.3338,136.9797 diff = 202.000000'
});
data_saddle.push({
lat: 3.5338444445e+01,
lng: 1.3699044444e+02,
content:'Saddle = 90.000000 pos = 35.3384,136.9904 diff = 202.000000'
});
data_peak.push({
lat: 3.5344555556e+01,
lng: 1.3698400000e+02,
cert : false,
content:' Peak = 273.500000 pos = 35.3446,136.9840 diff = 157.100006'
});
data_saddle.push({
lat: 3.5353444445e+01,
lng: 1.3698955556e+02,
content:'Saddle = 116.400002 pos = 35.3534,136.9896 diff = 157.100006'
});
data_peak.push({
lat: 3.4239555556e+01,
lng: 1.3530911111e+02,
cert : true,
content:'Name = JA/WK-099(JA/WK-099) peak = 278.600006 pos = 34.2396,135.3091 diff = 219.400009'
});
data_saddle.push({
lat: 3.4161888890e+01,
lng: 1.3527377778e+02,
content:'Saddle = 59.200001 pos = 34.1619,135.2738 diff = 219.400009'
});
data_peak.push({
lat: 3.4168111112e+01,
lng: 1.3526233333e+02,
cert : false,
content:' Peak = 246.800003 pos = 34.1681,135.2623 diff = 187.500000'
});
data_saddle.push({
lat: 3.4204777778e+01,
lng: 1.3528622222e+02,
content:'Saddle = 59.299999 pos = 34.2048,135.2862 diff = 187.500000'
});
data_peak.push({
lat: 3.3854555556e+01,
lng: 1.3519322222e+02,
cert : false,
content:' Peak = 240.800003 pos = 33.8546,135.1932 diff = 173.700012'
});
data_saddle.push({
lat: 3.3870888890e+01,
lng: 1.3522055556e+02,
content:'Saddle = 67.099998 pos = 33.8709,135.2206 diff = 173.700012'
});
data_peak.push({
lat: 3.5505777778e+01,
lng: 1.3671322222e+02,
cert : true,
content:'Name = JA/GF-206(JA/GF-206) peak = 315.899994 pos = 35.5058,136.7132 diff = 248.099991'
});
data_saddle.push({
lat: 3.5521555556e+01,
lng: 1.3671000000e+02,
content:'Saddle = 67.800003 pos = 35.5216,136.7100 diff = 248.099991'
});
data_peak.push({
lat: 3.5479111111e+01,
lng: 1.3671177778e+02,
cert : false,
content:' Peak = 224.000000 pos = 35.4791,136.7118 diff = 155.699997'
});
data_saddle.push({
lat: 3.5483333334e+01,
lng: 1.3670900000e+02,
content:'Saddle = 68.300003 pos = 35.4833,136.7090 diff = 155.699997'
});
data_peak.push({
lat: 3.3902666668e+01,
lng: 1.3510388889e+02,
cert : true,
content:'Name = JA/WK-098(JA/WK-098) peak = 337.100006 pos = 33.9027,135.1039 diff = 269.000000'
});
data_saddle.push({
lat: 3.3920222223e+01,
lng: 1.3509855556e+02,
content:'Saddle = 68.099998 pos = 33.9202,135.0986 diff = 269.000000'
});
data_peak.push({
lat: 3.4408888890e+01,
lng: 1.3682411111e+02,
cert : true,
content:'Name = JA/ME-099(JA/ME-099) peak = 334.799988 pos = 34.4089,136.8241 diff = 258.299988'
});
data_saddle.push({
lat: 3.4413555556e+01,
lng: 1.3681588889e+02,
content:'Saddle = 76.500000 pos = 34.4136,136.8159 diff = 258.299988'
});
data_peak.push({
lat: 3.4678444445e+01,
lng: 1.3567888889e+02,
cert : true,
content:'Name = Ikomayama(JA/NR-049) peak = 640.900024 pos = 34.6784,135.6789 diff = 563.200012'
});
data_saddle.push({
lat: 3.4699000001e+01,
lng: 1.3580300000e+02,
content:'Saddle = 77.699997 pos = 34.6990,135.8030 diff = 563.200012'
});
data_peak.push({
lat: 3.4780888889e+01,
lng: 1.3570777778e+02,
cert : true,
content:'Name = JA/NR-057(JA/NR-057) peak = 343.299988 pos = 34.7809,135.7078 diff = 187.199982'
});
data_saddle.push({
lat: 3.4712555556e+01,
lng: 1.3570122222e+02,
content:'Saddle = 156.100006 pos = 34.7126,135.7012 diff = 187.199982'
});
data_peak.push({
lat: 3.4654777778e+01,
lng: 1.3572866667e+02,
cert : true,
content:'Name = JA/NR-058(JA/NR-058) peak = 341.200012 pos = 34.6548,135.7287 diff = 183.500015'
});
data_saddle.push({
lat: 3.4724111112e+01,
lng: 1.3571011111e+02,
content:'Saddle = 157.699997 pos = 34.7241,135.7101 diff = 183.500015'
});
data_peak.push({
lat: 3.5428111111e+01,
lng: 1.3694544444e+02,
cert : true,
content:'Name = JA/GF-201(JA/GF-201) peak = 382.600006 pos = 35.4281,136.9454 diff = 304.700012'
});
data_saddle.push({
lat: 3.5470666667e+01,
lng: 1.3699988889e+02,
content:'Saddle = 77.900002 pos = 35.4707,136.9999 diff = 304.700012'
});
data_peak.push({
lat: 3.5430111111e+01,
lng: 1.3691044444e+02,
cert : false,
content:' Peak = 261.100006 pos = 35.4301,136.9104 diff = 153.100006'
});
data_saddle.push({
lat: 3.5432444445e+01,
lng: 1.3691444444e+02,
content:'Saddle = 108.000000 pos = 35.4324,136.9144 diff = 153.100006'
});
data_peak.push({
lat: 3.5426111111e+01,
lng: 1.3692144444e+02,
cert : false,
content:' Peak = 281.200012 pos = 35.4261,136.9214 diff = 150.200012'
});
data_saddle.push({
lat: 3.5428333334e+01,
lng: 1.3692533333e+02,
content:'Saddle = 131.000000 pos = 35.4283,136.9253 diff = 150.200012'
});
data_peak.push({
lat: 3.5444555556e+01,
lng: 1.3686822222e+02,
cert : true,
content:'Name = JA/GF-205(JA/GF-205) peak = 315.600006 pos = 35.4446,136.8682 diff = 168.500000'
});
data_saddle.push({
lat: 3.5445777778e+01,
lng: 1.3688622222e+02,
content:'Saddle = 147.100006 pos = 35.4458,136.8862 diff = 168.500000'
});
data_peak.push({
lat: 3.3962555556e+01,
lng: 1.3509333333e+02,
cert : false,
content:' Peak = 262.299988 pos = 33.9626,135.0933 diff = 183.999985'
});
data_saddle.push({
lat: 3.3968222223e+01,
lng: 1.3509388889e+02,
content:'Saddle = 78.300003 pos = 33.9682,135.0939 diff = 183.999985'
});
data_peak.push({
lat: 3.3633444445e+01,
lng: 1.3585100000e+02,
cert : false,
content:' Peak = 250.100006 pos = 33.6334,135.8510 diff = 167.100006'
});
data_saddle.push({
lat: 3.3637666668e+01,
lng: 1.3585011111e+02,
content:'Saddle = 83.000000 pos = 33.6377,135.8501 diff = 167.100006'
});
data_peak.push({
lat: 3.3877666668e+01,
lng: 1.3522566667e+02,
cert : false,
content:' Peak = 233.399994 pos = 33.8777,135.2257 diff = 150.199997'
});
data_saddle.push({
lat: 3.3876444445e+01,
lng: 1.3523466667e+02,
content:'Saddle = 83.199997 pos = 33.8764,135.2347 diff = 150.199997'
});
data_peak.push({
lat: 3.4448888890e+01,
lng: 1.3658166667e+02,
cert : true,
content:'Name = JA/ME-090(JA/ME-090) peak = 410.200012 pos = 34.4489,136.5817 diff = 324.100006'
});
data_saddle.push({
lat: 3.4463222223e+01,
lng: 1.3651600000e+02,
content:'Saddle = 86.099998 pos = 34.4632,136.5160 diff = 324.100006'
});
data_peak.push({
lat: 3.4448333334e+01,
lng: 1.3653188889e+02,
cert : false,
content:' Peak = 314.799988 pos = 34.4483,136.5319 diff = 211.399994'
});
data_saddle.push({
lat: 3.4460444445e+01,
lng: 1.3655111111e+02,
content:'Saddle = 103.400002 pos = 34.4604,136.5511 diff = 211.399994'
});
data_peak.push({
lat: 3.4485000001e+01,
lng: 1.3651244444e+02,
cert : true,
content:'Name = JA/ME-105(JA/ME-105) peak = 290.899994 pos = 34.4850,136.5124 diff = 203.699997'
});
data_saddle.push({
lat: 3.4458555556e+01,
lng: 1.3648111111e+02,
content:'Saddle = 87.199997 pos = 34.4586,136.4811 diff = 203.699997'
});
data_peak.push({
lat: 3.4274111112e+01,
lng: 1.3659944444e+02,
cert : false,
content:' Peak = 256.700012 pos = 34.2741,136.5994 diff = 169.200012'
});
data_saddle.push({
lat: 3.4276222223e+01,
lng: 1.3661144444e+02,
content:'Saddle = 87.500000 pos = 34.2762,136.6114 diff = 169.200012'
});
data_peak.push({
lat: 3.4485444445e+01,
lng: 1.3646322222e+02,
cert : false,
content:' Peak = 263.500000 pos = 34.4854,136.4632 diff = 175.899994'
});
data_saddle.push({
lat: 3.4489111112e+01,
lng: 1.3645844444e+02,
content:'Saddle = 87.599998 pos = 34.4891,136.4584 diff = 175.899994'
});
data_peak.push({
lat: 3.5144000000e+01,
lng: 1.3608244444e+02,
cert : false,
content:' Peak = 282.799988 pos = 35.1440,136.0824 diff = 193.299988'
});
data_saddle.push({
lat: 3.5140555556e+01,
lng: 1.3609088889e+02,
content:'Saddle = 89.500000 pos = 35.1406,136.0909 diff = 193.299988'
});
data_peak.push({
lat: 3.5233666667e+01,
lng: 1.3619777778e+02,
cert : false,
content:' Peak = 283.500000 pos = 35.2337,136.1978 diff = 193.800003'
});
data_saddle.push({
lat: 3.5228666667e+01,
lng: 1.3620300000e+02,
content:'Saddle = 89.699997 pos = 35.2287,136.2030 diff = 193.800003'
});
data_peak.push({
lat: 3.3839111112e+01,
lng: 1.3525155556e+02,
cert : false,
content:' Peak = 270.600006 pos = 33.8391,135.2516 diff = 178.200012'
});
data_saddle.push({
lat: 3.3855888890e+01,
lng: 1.3525355556e+02,
content:'Saddle = 92.400002 pos = 33.8559,135.2536 diff = 178.200012'
});
data_peak.push({
lat: 3.5499444445e+01,
lng: 1.3698922222e+02,
cert : false,
content:' Peak = 277.200012 pos = 35.4994,136.9892 diff = 181.300018'
});
data_saddle.push({
lat: 3.5537888889e+01,
lng: 1.3699966667e+02,
content:'Saddle = 95.900002 pos = 35.5379,136.9997 diff = 181.300018'
});
data_peak.push({
lat: 3.4735444445e+01,
lng: 1.3643222222e+02,
cert : false,
content:' Peak = 323.299988 pos = 34.7354,136.4322 diff = 226.499985'
});
data_saddle.push({
lat: 3.4724444445e+01,
lng: 1.3641188889e+02,
content:'Saddle = 96.800003 pos = 34.7244,136.4119 diff = 226.499985'
});
data_peak.push({
lat: 3.4427888890e+01,
lng: 1.3654366667e+02,
cert : false,
content:' Peak = 286.000000 pos = 34.4279,136.5437 diff = 189.100006'
});
data_saddle.push({
lat: 3.4420888890e+01,
lng: 1.3654855556e+02,
content:'Saddle = 96.900002 pos = 34.4209,136.5486 diff = 189.100006'
});
data_peak.push({
lat: 3.4422777778e+01,
lng: 1.3652300000e+02,
cert : false,
content:' Peak = 266.100006 pos = 34.4228,136.5230 diff = 168.500000'
});
data_saddle.push({
lat: 3.4415444445e+01,
lng: 1.3652500000e+02,
content:'Saddle = 97.599998 pos = 34.4154,136.5250 diff = 168.500000'
});
data_peak.push({
lat: 3.4573000001e+01,
lng: 1.3567266667e+02,
cert : false,
content:' Peak = 273.600006 pos = 34.5730,135.6727 diff = 175.800003'
});
data_saddle.push({
lat: 3.4554222223e+01,
lng: 1.3567477778e+02,
content:'Saddle = 97.800003 pos = 34.5542,135.6748 diff = 175.800003'
});
data_peak.push({
lat: 3.4297222223e+01,
lng: 1.3509677778e+02,
cert : false,
content:' Peak = 283.100006 pos = 34.2972,135.0968 diff = 178.700012'
});
data_saddle.push({
lat: 3.4276111112e+01,
lng: 1.3512866667e+02,
content:'Saddle = 104.400002 pos = 34.2761,135.1287 diff = 178.700012'
});
data_peak.push({
lat: 3.3750222223e+01,
lng: 1.3598166667e+02,
cert : true,
content:'Name = JA/ME-098(JA/ME-098) peak = 336.200012 pos = 33.7502,135.9817 diff = 229.800018'
});
data_saddle.push({
lat: 3.3763333334e+01,
lng: 1.3599911111e+02,
content:'Saddle = 106.400002 pos = 33.7633,135.9991 diff = 229.800018'
});
data_peak.push({
lat: 3.3929777779e+01,
lng: 1.3522766667e+02,
cert : false,
content:' Peak = 263.000000 pos = 33.9298,135.2277 diff = 154.699997'
});
data_saddle.push({
lat: 3.3936333334e+01,
lng: 1.3522455556e+02,
content:'Saddle = 108.300003 pos = 33.9363,135.2246 diff = 154.699997'
});
data_peak.push({
lat: 3.5147444445e+01,
lng: 1.3615944444e+02,
cert : true,
content:'Name = JA/SI-058(JA/SI-058) peak = 441.100006 pos = 35.1474,136.1594 diff = 331.600006'
});
data_saddle.push({
lat: 3.5143666667e+01,
lng: 1.3617644444e+02,
content:'Saddle = 109.500000 pos = 35.1437,136.1764 diff = 331.600006'
});
data_peak.push({
lat: 3.5349777778e+01,
lng: 1.3650655556e+02,
cert : false,
content:' Peak = 421.399994 pos = 35.3498,136.5066 diff = 310.700012'
});
data_saddle.push({
lat: 3.5358888889e+01,
lng: 1.3647488889e+02,
content:'Saddle = 110.699997 pos = 35.3589,136.4749 diff = 310.700012'
});
data_peak.push({
lat: 3.4126111112e+01,
lng: 1.3623833333e+02,
cert : true,
content:'Name = JA/ME-094(JA/ME-094) peak = 380.100006 pos = 34.1261,136.2383 diff = 267.900024'
});
data_saddle.push({
lat: 3.4141333334e+01,
lng: 1.3625900000e+02,
content:'Saddle = 112.199997 pos = 34.1413,136.2590 diff = 267.900024'
});
data_peak.push({
lat: 3.5076555556e+01,
lng: 1.3614577778e+02,
cert : true,
content:'Name = JA/SI-070(JA/SI-070) peak = 307.500000 pos = 35.0766,136.1458 diff = 193.100006'
});
data_saddle.push({
lat: 3.5062888889e+01,
lng: 1.3616100000e+02,
content:'Saddle = 114.400002 pos = 35.0629,136.1610 diff = 193.100006'
});
data_peak.push({
lat: 3.4282777778e+01,
lng: 1.3662177778e+02,
cert : true,
content:'Name = JA/ME-102(JA/ME-102) peak = 310.500000 pos = 34.2828,136.6218 diff = 192.800003'
});
data_saddle.push({
lat: 3.4293888890e+01,
lng: 1.3662455556e+02,
content:'Saddle = 117.699997 pos = 34.2939,136.6246 diff = 192.800003'
});
data_peak.push({
lat: 3.5505555556e+01,
lng: 1.3663600000e+02,
cert : true,
content:'Name = JA/GF-198(JA/GF-198) peak = 428.700012 pos = 35.5056,136.6360 diff = 310.300018'
});
data_saddle.push({
lat: 3.5490111111e+01,
lng: 1.3660577778e+02,
content:'Saddle = 118.400002 pos = 35.4901,136.6058 diff = 310.300018'
});
data_peak.push({
lat: 3.4333555556e+01,
lng: 1.3664633333e+02,
cert : true,
content:'Name = JA/ME-104(JA/ME-104) peak = 292.399994 pos = 34.3336,136.6463 diff = 170.099991'
});
data_saddle.push({
lat: 3.4328555556e+01,
lng: 1.3664377778e+02,
content:'Saddle = 122.300003 pos = 34.3286,136.6438 diff = 170.099991'
});
data_peak.push({
lat: 3.4240666667e+01,
lng: 1.3647466667e+02,
cert : false,
content:' Peak = 294.100006 pos = 34.2407,136.4747 diff = 168.200012'
});
data_saddle.push({
lat: 3.4260888890e+01,
lng: 1.3647444444e+02,
content:'Saddle = 125.900002 pos = 34.2609,136.4744 diff = 168.200012'
});
data_peak.push({
lat: 3.5088666667e+01,
lng: 1.3552522222e+02,
cert : false,
content:' Peak = 294.399994 pos = 35.0887,135.5252 diff = 167.799988'
});
data_saddle.push({
lat: 3.5103777778e+01,
lng: 1.3552533333e+02,
content:'Saddle = 126.599998 pos = 35.1038,135.5253 diff = 167.799988'
});
data_peak.push({
lat: 3.3920222223e+01,
lng: 1.3592922222e+02,
cert : true,
content:'Name = JA/ME-106(JA/ME-106) peak = 296.100006 pos = 33.9202,135.9292 diff = 168.300003'
});
data_saddle.push({
lat: 3.3920222223e+01,
lng: 1.3591877778e+02,
content:'Saddle = 127.800003 pos = 33.9202,135.9188 diff = 168.300003'
});
data_peak.push({
lat: 3.4397000001e+01,
lng: 1.3644077778e+02,
cert : false,
content:' Peak = 383.000000 pos = 34.3970,136.4408 diff = 255.100006'
});
data_saddle.push({
lat: 3.4403000001e+01,
lng: 1.3643722222e+02,
content:'Saddle = 127.900002 pos = 34.4030,136.4372 diff = 255.100006'
});
data_peak.push({
lat: 3.5123444445e+01,
lng: 1.3617677778e+02,
cert : false,
content:' Peak = 373.000000 pos = 35.1234,136.1768 diff = 243.800003'
});
data_saddle.push({
lat: 3.5111888889e+01,
lng: 1.3619533333e+02,
content:'Saddle = 129.199997 pos = 35.1119,136.1953 diff = 243.800003'
});
data_peak.push({
lat: 3.5533555556e+01,
lng: 1.3691855556e+02,
cert : false,
content:' Peak = 315.299988 pos = 35.5336,136.9186 diff = 178.099991'
});
data_saddle.push({
lat: 3.5542444445e+01,
lng: 1.3693444444e+02,
content:'Saddle = 137.199997 pos = 35.5424,136.9344 diff = 178.099991'
});
data_peak.push({
lat: 3.4665666667e+01,
lng: 1.3510833333e+02,
cert : false,
content:' Peak = 311.100006 pos = 34.6657,135.1083 diff = 173.100006'
});
data_saddle.push({
lat: 3.4681111112e+01,
lng: 1.3510377778e+02,
content:'Saddle = 138.000000 pos = 34.6811,135.1038 diff = 173.100006'
});
data_peak.push({
lat: 3.4543888889e+01,
lng: 1.3564855556e+02,
cert : false,
content:' Peak = 293.200012 pos = 34.5439,135.6486 diff = 154.800018'
});
data_saddle.push({
lat: 3.4538444445e+01,
lng: 1.3565900000e+02,
content:'Saddle = 138.399994 pos = 34.5384,135.6590 diff = 154.800018'
});
data_peak.push({
lat: 3.5123666667e+01,
lng: 1.3549255556e+02,
cert : true,
content:'Name = JA/KT-100(JA/KT-100) peak = 320.100006 pos = 35.1237,135.4926 diff = 180.600006'
});
data_saddle.push({
lat: 3.5133444445e+01,
lng: 1.3548566667e+02,
content:'Saddle = 139.500000 pos = 35.1334,135.4857 diff = 180.600006'
});
data_peak.push({
lat: 3.5031666667e+01,
lng: 1.3605111111e+02,
cert : true,
content:'Name = JA/SI-068(JA/SI-068) peak = 352.799988 pos = 35.0317,136.0511 diff = 211.999985'
});
data_saddle.push({
lat: 3.5032555556e+01,
lng: 1.3606200000e+02,
content:'Saddle = 140.800003 pos = 35.0326,136.0620 diff = 211.999985'
});
data_peak.push({
lat: 3.3522222223e+01,
lng: 1.3575533333e+02,
cert : false,
content:' Peak = 309.100006 pos = 33.5222,135.7553 diff = 161.300003'
});
data_saddle.push({
lat: 3.3517333334e+01,
lng: 1.3574266667e+02,
content:'Saddle = 147.800003 pos = 33.5173,135.7427 diff = 161.300003'
});
data_peak.push({
lat: 3.4864888889e+01,
lng: 1.3582922222e+02,
cert : true,
content:'Name = JA/KT-091(JA/KT-091) peak = 365.200012 pos = 34.8649,135.8292 diff = 215.700012'
});
data_saddle.push({
lat: 3.4845111112e+01,
lng: 1.3584200000e+02,
content:'Saddle = 149.500000 pos = 34.8451,135.8420 diff = 215.700012'
});
data_peak.push({
lat: 3.5450333334e+01,
lng: 1.3620622222e+02,
cert : false,
content:' Peak = 323.799988 pos = 35.4503,136.2062 diff = 170.699982'
});
data_saddle.push({
lat: 3.5475444445e+01,
lng: 1.3619400000e+02,
content:'Saddle = 153.100006 pos = 35.4754,136.1940 diff = 170.699982'
});
data_peak.push({
lat: 3.5379888889e+01,
lng: 1.3633744444e+02,
cert : true,
content:'Name = JA/SI-069(JA/SI-069) peak = 320.100006 pos = 35.3799,136.3374 diff = 165.100006'
});
data_saddle.push({
lat: 3.5390777778e+01,
lng: 1.3634733333e+02,
content:'Saddle = 155.000000 pos = 35.3908,136.3473 diff = 165.100006'
});
data_peak.push({
lat: 3.4507666667e+01,
lng: 1.3647111111e+02,
cert : true,
content:'Name = JA/ME-093(JA/ME-093) peak = 400.000000 pos = 34.5077,136.4711 diff = 242.500000'
});
data_saddle.push({
lat: 3.4505555556e+01,
lng: 1.3645233333e+02,
content:'Saddle = 157.500000 pos = 34.5056,136.4523 diff = 242.500000'
});
data_peak.push({
lat: 3.5514555556e+01,
lng: 1.3668522222e+02,
cert : true,
content:'Name = JA/GF-202(JA/GF-202) peak = 373.799988 pos = 35.5146,136.6852 diff = 215.999985'
});
data_saddle.push({
lat: 3.5536555556e+01,
lng: 1.3668222222e+02,
content:'Saddle = 157.800003 pos = 35.5366,136.6822 diff = 215.999985'
});
data_peak.push({
lat: 3.5569444445e+01,
lng: 1.3664266667e+02,
cert : false,
content:' Peak = 321.299988 pos = 35.5694,136.6427 diff = 163.299988'
});
data_saddle.push({
lat: 3.5579000000e+01,
lng: 1.3664111111e+02,
content:'Saddle = 158.000000 pos = 35.5790,136.6411 diff = 163.299988'
});
data_peak.push({
lat: 3.5050666667e+01,
lng: 1.3603755556e+02,
cert : true,
content:'Name = Mikamiyama(JA/SI-060) peak = 431.000000 pos = 35.0507,136.0376 diff = 272.799988'
});
data_saddle.push({
lat: 3.5056111111e+01,
lng: 1.3604622222e+02,
content:'Saddle = 158.199997 pos = 35.0561,136.0462 diff = 272.799988'
});
data_peak.push({
lat: 3.5018777778e+01,
lng: 1.3610388889e+02,
cert : true,
content:'Name = JA/SI-064(JA/SI-064) peak = 403.700012 pos = 35.0188,136.1039 diff = 243.900009'
});
data_saddle.push({
lat: 3.5004666667e+01,
lng: 1.3612333333e+02,
content:'Saddle = 159.800003 pos = 35.0047,136.1233 diff = 243.900009'
});
data_peak.push({
lat: 3.5066666667e+01,
lng: 1.3608155556e+02,
cert : false,
content:' Peak = 383.000000 pos = 35.0667,136.0816 diff = 184.699997'
});
data_saddle.push({
lat: 3.5043111111e+01,
lng: 1.3607944444e+02,
content:'Saddle = 198.300003 pos = 35.0431,136.0794 diff = 184.699997'
});
data_peak.push({
lat: 3.3974111112e+01,
lng: 1.3536822222e+02,
cert : true,
content:'Name = JA/WK-090(JA/WK-090) peak = 428.000000 pos = 33.9741,135.3682 diff = 264.899994'
});
data_saddle.push({
lat: 3.3968444445e+01,
lng: 1.3536188889e+02,
content:'Saddle = 163.100006 pos = 33.9684,135.3619 diff = 264.899994'
});
data_peak.push({
lat: 3.4741333334e+01,
lng: 1.3607633333e+02,
cert : true,
content:'Name = JA/ME-097(JA/ME-097) peak = 361.799988 pos = 34.7413,136.0763 diff = 194.599991'
});
data_saddle.push({
lat: 3.4725777778e+01,
lng: 1.3608277778e+02,
content:'Saddle = 167.199997 pos = 34.7258,136.0828 diff = 194.599991'
});
data_peak.push({
lat: 3.4460555556e+01,
lng: 1.3642000000e+02,
cert : true,
content:'Name = JA/ME-082(JA/ME-082) peak = 543.400024 pos = 34.4606,136.4200 diff = 375.800018'
});
data_saddle.push({
lat: 3.4448555556e+01,
lng: 1.3642000000e+02,
content:'Saddle = 167.600006 pos = 34.4486,136.4200 diff = 375.800018'
});
data_peak.push({
lat: 3.5477666667e+01,
lng: 1.3606566667e+02,
cert : true,
content:'Name = JA/SI-057(JA/SI-057) peak = 442.000000 pos = 35.4777,136.0657 diff = 274.200012'
});
data_saddle.push({
lat: 3.5482555556e+01,
lng: 1.3608277778e+02,
content:'Saddle = 167.800003 pos = 35.4826,136.0828 diff = 274.200012'
});
data_peak.push({
lat: 3.4958555556e+01,
lng: 1.3585911111e+02,
cert : true,
content:'Name = JA/KT-042(JA/KT-042) peak = 600.700012 pos = 34.9586,135.8591 diff = 432.800018'
});
data_saddle.push({
lat: 3.4994222223e+01,
lng: 1.3585477778e+02,
content:'Saddle = 167.899994 pos = 34.9942,135.8548 diff = 432.800018'
});
data_peak.push({
lat: 3.4927333334e+01,
lng: 1.3589655556e+02,
cert : true,
content:'Name = JA/SI-065(JA/SI-065) peak = 390.700012 pos = 34.9273,135.8966 diff = 212.300018'
});
data_saddle.push({
lat: 3.4930111112e+01,
lng: 1.3588844444e+02,
content:'Saddle = 178.399994 pos = 34.9301,135.8884 diff = 212.300018'
});
data_peak.push({
lat: 3.4676555556e+01,
lng: 1.3513022222e+02,
cert : false,
content:' Peak = 325.899994 pos = 34.6766,135.1302 diff = 157.899994'
});
data_saddle.push({
lat: 3.4680666667e+01,
lng: 1.3512866667e+02,
content:'Saddle = 168.000000 pos = 34.6807,135.1287 diff = 157.899994'
});
data_peak.push({
lat: 3.3835777779e+01,
lng: 1.3530900000e+02,
cert : true,
content:'Name = JA/WK-095(JA/WK-095) peak = 386.100006 pos = 33.8358,135.3090 diff = 214.000000'
});
data_saddle.push({
lat: 3.3847555556e+01,
lng: 1.3531211111e+02,
content:'Saddle = 172.100006 pos = 33.8476,135.3121 diff = 214.000000'
});
data_peak.push({
lat: 3.5211111111e+01,
lng: 1.3629177778e+02,
cert : false,
content:' Peak = 332.899994 pos = 35.2111,136.2918 diff = 156.500000'
});
data_saddle.push({
lat: 3.5210666667e+01,
lng: 1.3629922222e+02,
content:'Saddle = 176.399994 pos = 35.2107,136.2992 diff = 156.500000'
});
data_peak.push({
lat: 3.3771000001e+01,
lng: 1.3600788889e+02,
cert : false,
content:' Peak = 361.500000 pos = 33.7710,136.0079 diff = 182.800003'
});
data_saddle.push({
lat: 3.3783888890e+01,
lng: 1.3600722222e+02,
content:'Saddle = 178.699997 pos = 33.7839,136.0072 diff = 182.800003'
});
data_peak.push({
lat: 3.6000000000e+01,
lng: 1.3683888889e+02,
cert : false,
content:' Peak = 1679.699951 pos = 36.0000,136.8389 diff = 1499.899902'
});
data_saddle.push({
lat: 3.5347444445e+01,
lng: 1.3641888889e+02,
content:'Saddle = 179.800003 pos = 35.3474,136.4189 diff = 1499.899902'
});
data_peak.push({
lat: 3.4971666667e+01,
lng: 1.3500000000e+02,
cert : false,
content:' Peak = 360.799988 pos = 34.9717,135.0000 diff = 179.499985'
});
data_saddle.push({
lat: 3.4963555556e+01,
lng: 1.3501222222e+02,
content:'Saddle = 181.300003 pos = 34.9636,135.0122 diff = 179.499985'
});
data_peak.push({
lat: 3.5558555556e+01,
lng: 1.3693166667e+02,
cert : true,
content:'Name = JA/GF-196(JA/GF-196) peak = 434.000000 pos = 35.5586,136.9317 diff = 246.399994'
});
data_saddle.push({
lat: 3.5552222222e+01,
lng: 1.3694377778e+02,
content:'Saddle = 187.600006 pos = 35.5522,136.9438 diff = 246.399994'
});
data_peak.push({
lat: 3.5069000000e+01,
lng: 1.3548400000e+02,
cert : true,
content:'Name = JA/KT-072(JA/KT-072) peak = 462.000000 pos = 35.0690,135.4840 diff = 270.899994'
});
data_saddle.push({
lat: 3.5049888889e+01,
lng: 1.3549811111e+02,
content:'Saddle = 191.100006 pos = 35.0499,135.4981 diff = 270.899994'
});
data_peak.push({
lat: 3.5075000000e+01,
lng: 1.3546255556e+02,
cert : false,
content:' Peak = 400.399994 pos = 35.0750,135.4626 diff = 163.000000'
});
data_saddle.push({
lat: 3.5075333334e+01,
lng: 1.3547266667e+02,
content:'Saddle = 237.399994 pos = 35.0753,135.4727 diff = 163.000000'
});
data_peak.push({
lat: 3.4778000000e+01,
lng: 1.3526366667e+02,
cert : true,
content:'Name = Rokkousan(JA/HG-029) peak = 931.000000 pos = 34.7780,135.2637 diff = 736.799988'
});
data_saddle.push({
lat: 3.4954444445e+01,
lng: 1.3514522222e+02,
content:'Saddle = 194.199997 pos = 34.9544,135.1452 diff = 736.799988'
});
data_peak.push({
lat: 3.4783666667e+01,
lng: 1.3514000000e+02,
cert : true,
content:'Name = JA/HG-086(JA/HG-086) peak = 594.400024 pos = 34.7837,135.1400 diff = 246.100037'
});
data_saddle.push({
lat: 3.4780888889e+01,
lng: 1.3519777778e+02,
content:'Saddle = 348.299988 pos = 34.7809,135.1978 diff = 246.100037'
});
data_peak.push({
lat: 3.4978666667e+01,
lng: 1.3518944444e+02,
cert : true,
content:'Name = JA/HG-152(JA/HG-152) peak = 440.000000 pos = 34.9787,135.1894 diff = 242.399994'
});
data_saddle.push({
lat: 3.4958555556e+01,
lng: 1.3514800000e+02,
content:'Saddle = 197.600006 pos = 34.9586,135.1480 diff = 242.399994'
});
data_peak.push({
lat: 3.5039333334e+01,
lng: 1.3550577778e+02,
cert : true,
content:'Name = JA/KT-073(JA/KT-073) peak = 460.600006 pos = 35.0393,135.5058 diff = 263.000000'
});
data_saddle.push({
lat: 3.5023000000e+01,
lng: 1.3549844444e+02,
content:'Saddle = 197.600006 pos = 35.0230,135.4984 diff = 263.000000'
});
data_peak.push({
lat: 3.5561111111e+01,
lng: 1.3686688889e+02,
cert : true,
content:'Name = JA/GF-188(JA/GF-188) peak = 537.200012 pos = 35.5611,136.8669 diff = 339.000000'
});
data_saddle.push({
lat: 3.5609222222e+01,
lng: 1.3680088889e+02,
content:'Saddle = 198.199997 pos = 35.6092,136.8009 diff = 339.000000'
});
data_peak.push({
lat: 3.5604111111e+01,
lng: 1.3680122222e+02,
cert : true,
content:'Name = JA/GF-193(JA/GF-193) peak = 442.899994 pos = 35.6041,136.8012 diff = 225.500000'
});
data_saddle.push({
lat: 3.5596222222e+01,
lng: 1.3679722222e+02,
content:'Saddle = 217.399994 pos = 35.5962,136.7972 diff = 225.500000'
});
data_peak.push({
lat: 3.5568777778e+01,
lng: 1.3682177778e+02,
cert : false,
content:' Peak = 520.900024 pos = 35.5688,136.8218 diff = 293.700012'
});
data_saddle.push({
lat: 3.5561111111e+01,
lng: 1.3683144444e+02,
content:'Saddle = 227.199997 pos = 35.5611,136.8314 diff = 293.700012'
});
data_peak.push({
lat: 3.5595444445e+01,
lng: 1.3683144444e+02,
cert : false,
content:' Peak = 467.000000 pos = 35.5954,136.8314 diff = 154.500000'
});
data_saddle.push({
lat: 3.5592000000e+01,
lng: 1.3682144444e+02,
content:'Saddle = 312.500000 pos = 35.5920,136.8214 diff = 154.500000'
});
data_peak.push({
lat: 3.5563666667e+01,
lng: 1.3683888889e+02,
cert : true,
content:'Name = JA/GF-190(JA/GF-190) peak = 514.500000 pos = 35.5637,136.8389 diff = 242.500000'
});
data_saddle.push({
lat: 3.5554555556e+01,
lng: 1.3685288889e+02,
content:'Saddle = 272.000000 pos = 35.5546,136.8529 diff = 242.500000'
});
data_peak.push({
lat: 3.5557444445e+01,
lng: 1.3688833333e+02,
cert : false,
content:' Peak = 501.000000 pos = 35.5574,136.8883 diff = 163.600006'
});
data_saddle.push({
lat: 3.5556444445e+01,
lng: 1.3688233333e+02,
content:'Saddle = 337.399994 pos = 35.5564,136.8823 diff = 163.600006'
});
data_peak.push({
lat: 3.5127333334e+01,
lng: 1.3524477778e+02,
cert : true,
content:'Name = Mitake(JA/HG-048) peak = 792.200012 pos = 35.1273,135.2448 diff = 593.300049'
});
data_saddle.push({
lat: 3.5198666667e+01,
lng: 1.3545811111e+02,
content:'Saddle = 198.899994 pos = 35.1987,135.4581 diff = 593.300049'
});
data_peak.push({
lat: 3.5046000000e+01,
lng: 1.3513477778e+02,
cert : true,
content:'Name = Shiragadake(JA/HG-058) peak = 721.000000 pos = 35.0460,135.1348 diff = 521.500000'
});
data_saddle.push({
lat: 3.5035333334e+01,
lng: 1.3517400000e+02,
content:'Saddle = 199.500000 pos = 35.0353,135.1740 diff = 521.500000'
});
data_peak.push({
lat: 3.4945444445e+01,
lng: 1.3503633333e+02,
cert : true,
content:'Name = JA/HG-161(JA/HG-161) peak = 422.100006 pos = 34.9454,135.0363 diff = 215.500000'
});
data_saddle.push({
lat: 3.4974333334e+01,
lng: 1.3505266667e+02,
content:'Saddle = 206.600006 pos = 34.9743,135.0527 diff = 215.500000'
});
data_peak.push({
lat: 3.4954444445e+01,
lng: 1.3506144444e+02,
cert : false,
content:' Peak = 404.200012 pos = 34.9544,135.0614 diff = 166.200012'
});
data_saddle.push({
lat: 3.4953333334e+01,
lng: 1.3504644444e+02,
content:'Saddle = 238.000000 pos = 34.9533,135.0464 diff = 166.200012'
});
data_peak.push({
lat: 3.5018666667e+01,
lng: 1.3515977778e+02,
cert : false,
content:' Peak = 403.899994 pos = 35.0187,135.1598 diff = 187.199997'
});
data_saddle.push({
lat: 3.5021777778e+01,
lng: 1.3515577778e+02,
content:'Saddle = 216.699997 pos = 35.0218,135.1558 diff = 187.199997'
});
data_peak.push({
lat: 3.5021444445e+01,
lng: 1.3501177778e+02,
cert : true,
content:'Name = JA/HG-143(JA/HG-143) peak = 455.200012 pos = 35.0214,135.0118 diff = 236.000015'
});
data_saddle.push({
lat: 3.5026111112e+01,
lng: 1.3502188889e+02,
content:'Saddle = 219.199997 pos = 35.0261,135.0219 diff = 236.000015'
});
data_peak.push({
lat: 3.4967111112e+01,
lng: 1.3502777778e+02,
cert : true,
content:'Name = JA/HG-138(JA/HG-138) peak = 457.100006 pos = 34.9671,135.0278 diff = 209.200012'
});
data_saddle.push({
lat: 3.4968666667e+01,
lng: 1.3503988889e+02,
content:'Saddle = 247.899994 pos = 34.9687,135.0399 diff = 209.200012'
});
data_peak.push({
lat: 3.4984222223e+01,
lng: 1.3513888889e+02,
cert : true,
content:'Name = JA/HG-088(JA/HG-088) peak = 592.000000 pos = 34.9842,135.1389 diff = 335.299988'
});
data_saddle.push({
lat: 3.5004222223e+01,
lng: 1.3513677778e+02,
content:'Saddle = 256.700012 pos = 35.0042,135.1368 diff = 335.299988'
});
data_peak.push({
lat: 3.5010111112e+01,
lng: 1.3513833333e+02,
cert : true,
content:'Name = JA/HG-135(JA/HG-135) peak = 470.399994 pos = 35.0101,135.1383 diff = 212.600006'
});
data_saddle.push({
lat: 3.5015888889e+01,
lng: 1.3513977778e+02,
content:'Saddle = 257.799988 pos = 35.0159,135.1398 diff = 212.600006'
});
data_peak.push({
lat: 3.4952444445e+01,
lng: 1.3507722222e+02,
cert : true,
content:'Name = Yokawa Royal GC  (6th hole Yokawa course)(JA/HG-157) peak = 431.799988 pos = 34.9524,135.0772 diff = 173.899994'
});
data_saddle.push({
lat: 3.4967777778e+01,
lng: 1.3508588889e+02,
content:'Saddle = 257.899994 pos = 34.9678,135.0859 diff = 173.899994'
});
data_peak.push({
lat: 3.4992333334e+01,
lng: 1.3511344444e+02,
cert : true,
content:'Name = JA/HG-089(JA/HG-089) peak = 590.900024 pos = 34.9923,135.1134 diff = 329.400024'
});
data_saddle.push({
lat: 3.5006777778e+01,
lng: 1.3511255556e+02,
content:'Saddle = 261.500000 pos = 35.0068,135.1126 diff = 329.400024'
});
data_peak.push({
lat: 3.5021555556e+01,
lng: 1.3513866667e+02,
cert : false,
content:' Peak = 500.500000 pos = 35.0216,135.1387 diff = 214.100006'
});
data_saddle.push({
lat: 3.5024777778e+01,
lng: 1.3513577778e+02,
content:'Saddle = 286.399994 pos = 35.0248,135.1358 diff = 214.100006'
});
data_peak.push({
lat: 3.4993222223e+01,
lng: 1.3507255556e+02,
cert : true,
content:'Name = JA/HG-104(JA/HG-104) peak = 550.799988 pos = 34.9932,135.0726 diff = 234.099976'
});
data_saddle.push({
lat: 3.4999555556e+01,
lng: 1.3507266667e+02,
content:'Saddle = 316.700012 pos = 34.9996,135.0727 diff = 234.099976'
});
data_peak.push({
lat: 3.4974555556e+01,
lng: 1.3508255556e+02,
cert : true,
content:'Name = JA/HG-108(JA/HG-108) peak = 540.900024 pos = 34.9746,135.0826 diff = 223.300018'
});
data_saddle.push({
lat: 3.4988555556e+01,
lng: 1.3508044444e+02,
content:'Saddle = 317.600006 pos = 34.9886,135.0804 diff = 223.300018'
});
data_peak.push({
lat: 3.5017000000e+01,
lng: 1.3506544444e+02,
cert : true,
content:'Name = JA/HG-060(JA/HG-060) peak = 711.099976 pos = 35.0170,135.0654 diff = 287.899963'
});
data_saddle.push({
lat: 3.5032555556e+01,
lng: 1.3508011111e+02,
content:'Saddle = 423.200012 pos = 35.0326,135.0801 diff = 287.899963'
});
data_peak.push({
lat: 3.5053777778e+01,
lng: 1.3503677778e+02,
cert : true,
content:'Name = JA/HG-081(JA/HG-081) peak = 633.799988 pos = 35.0538,135.0368 diff = 196.500000'
});
data_saddle.push({
lat: 3.5050666667e+01,
lng: 1.3506177778e+02,
content:'Saddle = 437.299988 pos = 35.0507,135.0618 diff = 196.500000'
});
data_peak.push({
lat: 3.5053777778e+01,
lng: 1.3505933333e+02,
cert : false,
content:' Peak = 620.000000 pos = 35.0538,135.0593 diff = 172.500000'
});
data_saddle.push({
lat: 3.5051666667e+01,
lng: 1.3505133333e+02,
content:'Saddle = 447.500000 pos = 35.0517,135.0513 diff = 172.500000'
});
data_peak.push({
lat: 3.5017555556e+01,
lng: 1.3511233333e+02,
cert : true,
content:'Name = JA/HG-077(JA/HG-077) peak = 644.400024 pos = 35.0176,135.1123 diff = 202.800018'
});
data_saddle.push({
lat: 3.5025888889e+01,
lng: 1.3510866667e+02,
content:'Saddle = 441.600006 pos = 35.0259,135.1087 diff = 202.800018'
});
data_peak.push({
lat: 3.5051777778e+01,
lng: 1.3508111111e+02,
cert : true,
content:'Name = JA/HG-072(JA/HG-072) peak = 653.299988 pos = 35.0518,135.0811 diff = 210.500000'
});
data_saddle.push({
lat: 3.5057888889e+01,
lng: 1.3510477778e+02,
content:'Saddle = 442.799988 pos = 35.0579,135.1048 diff = 210.500000'
});
data_peak.push({
lat: 3.4855333334e+01,
lng: 1.3533200000e+02,
cert : true,
content:'Name = JA/HG-103(JA/HG-103) peak = 551.500000 pos = 34.8553,135.3320 diff = 351.700012'
});
data_saddle.push({
lat: 3.4916444445e+01,
lng: 1.3531344444e+02,
content:'Saddle = 199.800003 pos = 34.9164,135.3134 diff = 351.700012'
});
data_peak.push({
lat: 3.4885888889e+01,
lng: 1.3528033333e+02,
cert : false,
content:' Peak = 382.899994 pos = 34.8859,135.2803 diff = 154.399994'
});
data_saddle.push({
lat: 3.4892888889e+01,
lng: 1.3530333333e+02,
content:'Saddle = 228.500000 pos = 34.8929,135.3033 diff = 154.399994'
});
data_peak.push({
lat: 3.4883222223e+01,
lng: 1.3531755556e+02,
cert : true,
content:'Name = JA/HG-139(JA/HG-139) peak = 458.799988 pos = 34.8832,135.3176 diff = 216.999985'
});
data_saddle.push({
lat: 3.4878333334e+01,
lng: 1.3533200000e+02,
content:'Saddle = 241.800003 pos = 34.8783,135.3320 diff = 216.999985'
});
data_peak.push({
lat: 3.5108000000e+01,
lng: 1.3503222222e+02,
cert : true,
content:'Name = JA/HG-106(JA/HG-106) peak = 545.799988 pos = 35.1080,135.0322 diff = 338.799988'
});
data_saddle.push({
lat: 3.5106888889e+01,
lng: 1.3506777778e+02,
content:'Saddle = 207.000000 pos = 35.1069,135.0678 diff = 338.799988'
});
data_peak.push({
lat: 3.5248222223e+01,
lng: 1.3536666667e+02,
cert : true,
content:'Name = JA/KT-030(JA/KT-030) peak = 667.299988 pos = 35.2482,135.3667 diff = 459.799988'
});
data_saddle.push({
lat: 3.5177111111e+01,
lng: 1.3535633333e+02,
content:'Saddle = 207.500000 pos = 35.1771,135.3563 diff = 459.799988'
});
data_peak.push({
lat: 3.5284000000e+01,
lng: 1.3520466667e+02,
cert : false,
content:' Peak = 413.100006 pos = 35.2840,135.2047 diff = 195.800003'
});
data_saddle.push({
lat: 3.5271777778e+01,
lng: 1.3523033333e+02,
content:'Saddle = 217.300003 pos = 35.2718,135.2303 diff = 195.800003'
});
data_peak.push({
lat: 3.5208666667e+01,
lng: 1.3541822222e+02,
cert : false,
content:' Peak = 390.799988 pos = 35.2087,135.4182 diff = 163.399994'
});
data_saddle.push({
lat: 3.5203333334e+01,
lng: 1.3540533333e+02,
content:'Saddle = 227.399994 pos = 35.2033,135.4053 diff = 163.399994'
});
data_peak.push({
lat: 3.5224222223e+01,
lng: 1.3526500000e+02,
cert : true,
content:'Name = JA/KT-069(JA/KT-069) peak = 481.700012 pos = 35.2242,135.2650 diff = 231.000015'
});
data_saddle.push({
lat: 3.5227111111e+01,
lng: 1.3527988889e+02,
content:'Saddle = 250.699997 pos = 35.2271,135.2799 diff = 231.000015'
});
data_peak.push({
lat: 3.5266000000e+01,
lng: 1.3526211111e+02,
cert : true,
content:'Name = JA/KT-075(JA/KT-075) peak = 451.299988 pos = 35.2660,135.2621 diff = 183.399994'
});
data_saddle.push({
lat: 3.5269888889e+01,
lng: 1.3526700000e+02,
content:'Saddle = 267.899994 pos = 35.2699,135.2670 diff = 183.399994'
});
data_peak.push({
lat: 3.5214555556e+01,
lng: 1.3532411111e+02,
cert : true,
content:'Name = JA/KT-047(JA/KT-047) peak = 568.000000 pos = 35.2146,135.3241 diff = 270.799988'
});
data_saddle.push({
lat: 3.5222111111e+01,
lng: 1.3532377778e+02,
content:'Saddle = 297.200012 pos = 35.2221,135.3238 diff = 270.799988'
});
data_peak.push({
lat: 3.5231333334e+01,
lng: 1.3532366667e+02,
cert : true,
content:'Name = JA/KT-048(JA/KT-048) peak = 567.200012 pos = 35.2313,135.3237 diff = 195.500000'
});
data_saddle.push({
lat: 3.5240666667e+01,
lng: 1.3531700000e+02,
content:'Saddle = 371.700012 pos = 35.2407,135.3170 diff = 195.500000'
});
data_peak.push({
lat: 3.4923888889e+01,
lng: 1.3523033333e+02,
cert : false,
content:' Peak = 371.500000 pos = 34.9239,135.2303 diff = 162.699997'
});
data_saddle.push({
lat: 3.4921333334e+01,
lng: 1.3523988889e+02,
content:'Saddle = 208.800003 pos = 34.9213,135.2399 diff = 162.699997'
});
data_peak.push({
lat: 3.5177555556e+01,
lng: 1.3525766667e+02,
cert : false,
content:' Peak = 370.899994 pos = 35.1776,135.2577 diff = 153.099991'
});
data_saddle.push({
lat: 3.5174444445e+01,
lng: 1.3524666667e+02,
content:'Saddle = 217.800003 pos = 35.1744,135.2467 diff = 153.099991'
});
data_peak.push({
lat: 3.5191777778e+01,
lng: 1.3544733333e+02,
cert : true,
content:'Name = JA/KT-081(JA/KT-081) peak = 421.100006 pos = 35.1918,135.4473 diff = 203.300003'
});
data_saddle.push({
lat: 3.5187888889e+01,
lng: 1.3545522222e+02,
content:'Saddle = 217.800003 pos = 35.1879,135.4552 diff = 203.300003'
});
data_peak.push({
lat: 3.5166444445e+01,
lng: 1.3546877778e+02,
cert : false,
content:' Peak = 394.799988 pos = 35.1664,135.4688 diff = 172.299988'
});
data_saddle.push({
lat: 3.5164222223e+01,
lng: 1.3545833333e+02,
content:'Saddle = 222.500000 pos = 35.1642,135.4583 diff = 172.299988'
});
data_peak.push({
lat: 3.4930666667e+01,
lng: 1.3540311111e+02,
cert : true,
content:'Name = JA/HG-160(JA/HG-160) peak = 426.600006 pos = 34.9307,135.4031 diff = 197.900009'
});
data_saddle.push({
lat: 3.4931555556e+01,
lng: 1.3538977778e+02,
content:'Saddle = 228.699997 pos = 34.9316,135.3898 diff = 197.900009'
});
data_peak.push({
lat: 3.4932888889e+01,
lng: 1.3532900000e+02,
cert : false,
content:' Peak = 411.100006 pos = 34.9329,135.3290 diff = 179.300003'
});
data_saddle.push({
lat: 3.4936888889e+01,
lng: 1.3532411111e+02,
content:'Saddle = 231.800003 pos = 34.9369,135.3241 diff = 179.300003'
});
data_peak.push({
lat: 3.5225888889e+01,
lng: 1.3515100000e+02,
cert : true,
content:'Name = JA/HG-149(JA/HG-149) peak = 440.399994 pos = 35.2259,135.1510 diff = 203.199997'
});
data_saddle.push({
lat: 3.5203333334e+01,
lng: 1.3518144444e+02,
content:'Saddle = 237.199997 pos = 35.2033,135.1814 diff = 203.199997'
});
data_peak.push({
lat: 3.5052111111e+01,
lng: 1.3519000000e+02,
cert : true,
content:'Name = JA/HG-136(JA/HG-136) peak = 466.399994 pos = 35.0521,135.1900 diff = 227.099991'
});
data_saddle.push({
lat: 3.5046000000e+01,
lng: 1.3520455556e+02,
content:'Saddle = 239.300003 pos = 35.0460,135.2046 diff = 227.099991'
});
data_peak.push({
lat: 3.4918666667e+01,
lng: 1.3526788889e+02,
cert : true,
content:'Name = JA/HG-117(JA/HG-117) peak = 523.700012 pos = 34.9187,135.2679 diff = 276.100006'
});
data_saddle.push({
lat: 3.4933111112e+01,
lng: 1.3525900000e+02,
content:'Saddle = 247.600006 pos = 34.9331,135.2590 diff = 276.100006'
});
data_peak.push({
lat: 3.5164777778e+01,
lng: 1.3528900000e+02,
cert : true,
content:'Name = JA/KT-071(JA/KT-071) peak = 465.100006 pos = 35.1648,135.2890 diff = 217.400009'
});
data_saddle.push({
lat: 3.5159222223e+01,
lng: 1.3529044444e+02,
content:'Saddle = 247.699997 pos = 35.1592,135.2904 diff = 217.400009'
});
data_peak.push({
lat: 3.5075000000e+01,
lng: 1.3542133333e+02,
cert : false,
content:' Peak = 430.399994 pos = 35.0750,135.4213 diff = 172.899994'
});
data_saddle.push({
lat: 3.5064000000e+01,
lng: 1.3541966667e+02,
content:'Saddle = 257.500000 pos = 35.0640,135.4197 diff = 172.899994'
});
data_peak.push({
lat: 3.5017333334e+01,
lng: 1.3564800000e+02,
cert : true,
content:'Name = JA/KT-068(JA/KT-068) peak = 481.799988 pos = 35.0173,135.6480 diff = 224.199982'
});
data_saddle.push({
lat: 3.4987555556e+01,
lng: 1.3563600000e+02,
content:'Saddle = 257.600006 pos = 34.9876,135.6360 diff = 224.199982'
});
data_peak.push({
lat: 3.5153666667e+01,
lng: 1.3544033333e+02,
cert : true,
content:'Name = JA/KT-067(JA/KT-067) peak = 481.000000 pos = 35.1537,135.4403 diff = 223.100006'
});
data_saddle.push({
lat: 3.5114222223e+01,
lng: 1.3542644444e+02,
content:'Saddle = 257.899994 pos = 35.1142,135.4264 diff = 223.100006'
});
data_peak.push({
lat: 3.4916777778e+01,
lng: 1.3543444444e+02,
cert : true,
content:'Name = Kodaijiyama(JA/OS-013) peak = 487.700012 pos = 34.9168,135.4344 diff = 229.700012'
});
data_saddle.push({
lat: 3.4919111112e+01,
lng: 1.3545011111e+02,
content:'Saddle = 258.000000 pos = 34.9191,135.4501 diff = 229.700012'
});
data_peak.push({
lat: 3.4960111112e+01,
lng: 1.3542088889e+02,
cert : false,
content:' Peak = 461.500000 pos = 34.9601,135.4209 diff = 194.600006'
});
data_saddle.push({
lat: 3.4963666667e+01,
lng: 1.3542233333e+02,
content:'Saddle = 266.899994 pos = 34.9637,135.4223 diff = 194.600006'
});
data_peak.push({
lat: 3.5011333334e+01,
lng: 1.3551055556e+02,
cert : true,
content:'Name = JA/KT-074(JA/KT-074) peak = 462.899994 pos = 35.0113,135.5106 diff = 195.299988'
});
data_saddle.push({
lat: 3.4997000000e+01,
lng: 1.3549044444e+02,
content:'Saddle = 267.600006 pos = 34.9970,135.4904 diff = 195.299988'
});
data_peak.push({
lat: 3.5122555556e+01,
lng: 1.3514277778e+02,
cert : false,
content:' Peak = 620.400024 pos = 35.1226,135.1428 diff = 352.000031'
});
data_saddle.push({
lat: 3.5133666667e+01,
lng: 1.3522077778e+02,
content:'Saddle = 268.399994 pos = 35.1337,135.2208 diff = 352.000031'
});
data_peak.push({
lat: 3.5114111111e+01,
lng: 1.3511388889e+02,
cert : false,
content:' Peak = 537.799988 pos = 35.1141,135.1139 diff = 155.899994'
});
data_saddle.push({
lat: 3.5121333334e+01,
lng: 1.3511900000e+02,
content:'Saddle = 381.899994 pos = 35.1213,135.1190 diff = 155.899994'
});
data_peak.push({
lat: 3.5134000000e+01,
lng: 1.3510400000e+02,
cert : true,
content:'Name = JA/HG-087(JA/HG-087) peak = 593.299988 pos = 35.1340,135.1040 diff = 205.000000'
});
data_saddle.push({
lat: 3.5124444445e+01,
lng: 1.3512700000e+02,
content:'Saddle = 388.299988 pos = 35.1244,135.1270 diff = 205.000000'
});
data_peak.push({
lat: 3.5127555556e+01,
lng: 1.3517777778e+02,
cert : false,
content:' Peak = 604.700012 pos = 35.1276,135.1778 diff = 177.100006'
});
data_saddle.push({
lat: 3.5126555556e+01,
lng: 1.3516466667e+02,
content:'Saddle = 427.600006 pos = 35.1266,135.1647 diff = 177.100006'
});
data_peak.push({
lat: 3.4887111112e+01,
lng: 1.3550066667e+02,
cert : false,
content:' Peak = 680.000000 pos = 34.8871,135.5007 diff = 402.700012'
});
data_saddle.push({
lat: 3.4993777778e+01,
lng: 1.3547633333e+02,
content:'Saddle = 277.299988 pos = 34.9938,135.4763 diff = 402.700012'
});
data_peak.push({
lat: 3.4935222223e+01,
lng: 1.3562377778e+02,
cert : false,
content:' Peak = 678.099976 pos = 34.9352,135.6238 diff = 390.899963'
});
data_saddle.push({
lat: 3.4952111112e+01,
lng: 1.3553977778e+02,
content:'Saddle = 287.200012 pos = 34.9521,135.5398 diff = 390.899963'
});
data_peak.push({
lat: 3.4968000000e+01,
lng: 1.3555266667e+02,
cert : false,
content:' Peak = 470.000000 pos = 34.9680,135.5527 diff = 163.299988'
});
data_saddle.push({
lat: 3.4966111112e+01,
lng: 1.3556411111e+02,
content:'Saddle = 306.700012 pos = 34.9661,135.5641 diff = 163.299988'
});
data_peak.push({
lat: 3.4932666667e+01,
lng: 1.3558522222e+02,
cert : false,
content:' Peak = 561.200012 pos = 34.9327,135.5852 diff = 213.900024'
});
data_saddle.push({
lat: 3.4954666667e+01,
lng: 1.3558533333e+02,
content:'Saddle = 347.299988 pos = 34.9547,135.5853 diff = 213.900024'
});
data_peak.push({
lat: 3.4961777778e+01,
lng: 1.3563411111e+02,
cert : true,
content:'Name = JA/KT-035(JA/KT-035) peak = 641.099976 pos = 34.9618,135.6341 diff = 194.199982'
});
data_saddle.push({
lat: 3.4949444445e+01,
lng: 1.3563666667e+02,
content:'Saddle = 446.899994 pos = 34.9494,135.6367 diff = 194.199982'
});
data_peak.push({
lat: 3.4898666667e+01,
lng: 1.3554866667e+02,
cert : true,
content:'Name = Ryuuouzan(JA/OS-012) peak = 512.500000 pos = 34.8987,135.5487 diff = 195.600006'
});
data_saddle.push({
lat: 3.4898333334e+01,
lng: 1.3553833333e+02,
content:'Saddle = 316.899994 pos = 34.8983,135.5383 diff = 195.600006'
});
data_peak.push({
lat: 3.4985222223e+01,
lng: 1.3551644444e+02,
cert : true,
content:'Name = Reisen Golf Course  (Nr 4th green)(JA/KT-053) peak = 553.599976 pos = 34.9852,135.5164 diff = 216.199982'
});
data_saddle.push({
lat: 3.4974333334e+01,
lng: 1.3551255556e+02,
content:'Saddle = 337.399994 pos = 34.9743,135.5126 diff = 216.199982'
});
data_peak.push({
lat: 3.4974111112e+01,
lng: 1.3547666667e+02,
cert : false,
content:' Peak = 553.099976 pos = 34.9741,135.4767 diff = 160.899963'
});
data_saddle.push({
lat: 3.4967666667e+01,
lng: 1.3547588889e+02,
content:'Saddle = 392.200012 pos = 34.9677,135.4759 diff = 160.899963'
});
data_peak.push({
lat: 3.4929000000e+01,
lng: 1.3546733333e+02,
cert : true,
content:'Name = Myoukensan(JA/OS-007) peak = 662.599976 pos = 34.9290,135.4673 diff = 268.799988'
});
data_saddle.push({
lat: 3.4940111112e+01,
lng: 1.3549588889e+02,
content:'Saddle = 393.799988 pos = 34.9401,135.4959 diff = 268.799988'
});
data_peak.push({
lat: 3.4945888889e+01,
lng: 1.3550600000e+02,
cert : true,
content:'Name = Kounoyama(JA/OS-004) peak = 678.400024 pos = 34.9459,135.5060 diff = 231.600037'
});
data_saddle.push({
lat: 3.4907777778e+01,
lng: 1.3551611111e+02,
content:'Saddle = 446.799988 pos = 34.9078,135.5161 diff = 231.600037'
});
data_peak.push({
lat: 3.4935777778e+01,
lng: 1.3552844444e+02,
cert : true,
content:'Name = JA/KT-041(JA/KT-041) peak = 622.099976 pos = 34.9358,135.5284 diff = 150.799988'
});
data_saddle.push({
lat: 3.4936111112e+01,
lng: 1.3551544444e+02,
content:'Saddle = 471.299988 pos = 34.9361,135.5154 diff = 150.799988'
});
data_peak.push({
lat: 3.4888444445e+01,
lng: 1.3547788889e+02,
cert : true,
content:'Name = Akegataoyama(JA/OS-008) peak = 618.599976 pos = 34.8884,135.4779 diff = 169.899963'
});
data_saddle.push({
lat: 3.4890777778e+01,
lng: 1.3548900000e+02,
content:'Saddle = 448.700012 pos = 34.8908,135.4890 diff = 169.899963'
});
data_peak.push({
lat: 3.4951666667e+01,
lng: 1.3525900000e+02,
cert : true,
content:'Name = JA/HG-110(JA/HG-110) peak = 536.599976 pos = 34.9517,135.2590 diff = 258.899963'
});
data_saddle.push({
lat: 3.4973333334e+01,
lng: 1.3525855556e+02,
content:'Saddle = 277.700012 pos = 34.9733,135.2586 diff = 258.899963'
});
data_peak.push({
lat: 3.5041888889e+01,
lng: 1.3537733333e+02,
cert : true,
content:'Name = JA/KT-014(JA/KT-014) peak = 790.900024 pos = 35.0419,135.3773 diff = 474.800018'
});
data_saddle.push({
lat: 3.5068777778e+01,
lng: 1.3538222222e+02,
content:'Saddle = 316.100006 pos = 35.0688,135.3822 diff = 474.800018'
});
data_peak.push({
lat: 3.4970888889e+01,
lng: 1.3534800000e+02,
cert : true,
content:'Name = Doutokoyama(JA/OS-010) peak = 584.200012 pos = 34.9709,135.3480 diff = 266.500000'
});
data_saddle.push({
lat: 3.4982444445e+01,
lng: 1.3535955556e+02,
content:'Saddle = 317.700012 pos = 34.9824,135.3596 diff = 266.500000'
});
data_peak.push({
lat: 3.4966555556e+01,
lng: 1.3533233333e+02,
cert : false,
content:' Peak = 513.000000 pos = 34.9666,135.3323 diff = 171.399994'
});
data_saddle.push({
lat: 3.4965777778e+01,
lng: 1.3533811111e+02,
content:'Saddle = 341.600006 pos = 34.9658,135.3381 diff = 171.399994'
});
data_peak.push({
lat: 3.4961555556e+01,
lng: 1.3536211111e+02,
cert : false,
content:' Peak = 567.799988 pos = 34.9616,135.3621 diff = 180.799988'
});
data_saddle.push({
lat: 3.4971888889e+01,
lng: 1.3535622222e+02,
content:'Saddle = 387.000000 pos = 34.9719,135.3562 diff = 180.799988'
});
data_peak.push({
lat: 3.5058000000e+01,
lng: 1.3540977778e+02,
cert : true,
content:'Name = JA/KT-051(JA/KT-051) peak = 556.799988 pos = 35.0580,135.4098 diff = 236.000000'
});
data_saddle.push({
lat: 3.5051444445e+01,
lng: 1.3541844444e+02,
content:'Saddle = 320.799988 pos = 35.0514,135.4184 diff = 236.000000'
});
data_peak.push({
lat: 3.4967333334e+01,
lng: 1.3522188889e+02,
cert : true,
content:'Name = JA/HG-090(JA/HG-090) peak = 584.099976 pos = 34.9673,135.2219 diff = 211.399963'
});
data_saddle.push({
lat: 3.4976666667e+01,
lng: 1.3522177778e+02,
content:'Saddle = 372.700012 pos = 34.9767,135.2218 diff = 211.399963'
});
data_peak.push({
lat: 3.5001444445e+01,
lng: 1.3545766667e+02,
cert : true,
content:'Name = Kowadayama(JA/OS-009) peak = 611.599976 pos = 35.0014,135.4577 diff = 233.299988'
});
data_saddle.push({
lat: 3.5010111112e+01,
lng: 1.3545411111e+02,
content:'Saddle = 378.299988 pos = 35.0101,135.4541 diff = 233.299988'
});
data_peak.push({
lat: 3.4957888889e+01,
lng: 1.3528211111e+02,
cert : true,
content:'Name = JA/HG-076(JA/HG-076) peak = 650.299988 pos = 34.9579,135.2821 diff = 233.699982'
});
data_saddle.push({
lat: 3.4961555556e+01,
lng: 1.3528522222e+02,
content:'Saddle = 416.600006 pos = 34.9616,135.2852 diff = 233.699982'
});
data_peak.push({
lat: 3.4975888889e+01,
lng: 1.3529788889e+02,
cert : false,
content:' Peak = 592.599976 pos = 34.9759,135.2979 diff = 173.699982'
});
data_saddle.push({
lat: 3.4991777778e+01,
lng: 1.3530366667e+02,
content:'Saddle = 418.899994 pos = 34.9918,135.3037 diff = 173.699982'
});
data_peak.push({
lat: 3.5011333334e+01,
lng: 1.3525811111e+02,
cert : true,
content:'Name = JA/HG-063(JA/HG-063) peak = 697.200012 pos = 35.0113,135.2581 diff = 239.400024'
});
data_saddle.push({
lat: 3.5038555556e+01,
lng: 1.3529888889e+02,
content:'Saddle = 457.799988 pos = 35.0386,135.2989 diff = 239.400024'
});
data_peak.push({
lat: 3.5009333334e+01,
lng: 1.3521588889e+02,
cert : false,
content:' Peak = 635.900024 pos = 35.0093,135.2159 diff = 157.300018'
});
data_saddle.push({
lat: 3.5017444445e+01,
lng: 1.3521644444e+02,
content:'Saddle = 478.600006 pos = 35.0174,135.2164 diff = 157.300018'
});
data_peak.push({
lat: 3.5017666667e+01,
lng: 1.3519222222e+02,
cert : true,
content:'Name = JA/HG-074(JA/HG-074) peak = 658.799988 pos = 35.0177,135.1922 diff = 172.000000'
});
data_saddle.push({
lat: 3.5028444445e+01,
lng: 1.3524544444e+02,
content:'Saddle = 486.799988 pos = 35.0284,135.2454 diff = 172.000000'
});
data_peak.push({
lat: 3.5028777778e+01,
lng: 1.3523522222e+02,
cert : false,
content:' Peak = 646.900024 pos = 35.0288,135.2352 diff = 150.300018'
});
data_saddle.push({
lat: 3.5028222223e+01,
lng: 1.3523055556e+02,
content:'Saddle = 496.600006 pos = 35.0282,135.2306 diff = 150.300018'
});
data_peak.push({
lat: 3.5010222223e+01,
lng: 1.3531277778e+02,
cert : true,
content:'Name = JA/HG-052(JA/HG-052) peak = 752.299988 pos = 35.0102,135.3128 diff = 284.399994'
});
data_saddle.push({
lat: 3.5019555556e+01,
lng: 1.3532133333e+02,
content:'Saddle = 467.899994 pos = 35.0196,135.3213 diff = 284.399994'
});
data_peak.push({
lat: 3.5029888889e+01,
lng: 1.3545166667e+02,
cert : true,
content:'Name = JA/KT-017(JA/KT-017) peak = 771.400024 pos = 35.0299,135.4517 diff = 273.800018'
});
data_saddle.push({
lat: 3.5028666667e+01,
lng: 1.3542555556e+02,
content:'Saddle = 497.600006 pos = 35.0287,135.4256 diff = 273.800018'
});
data_peak.push({
lat: 3.5048666667e+01,
lng: 1.3532577778e+02,
cert : false,
content:' Peak = 724.099976 pos = 35.0487,135.3258 diff = 226.199982'
});
data_saddle.push({
lat: 3.5042111111e+01,
lng: 1.3535266667e+02,
content:'Saddle = 497.899994 pos = 35.0421,135.3527 diff = 226.199982'
});
data_peak.push({
lat: 3.5027888889e+01,
lng: 1.3541644444e+02,
cert : false,
content:' Peak = 691.000000 pos = 35.0279,135.4164 diff = 150.200012'
});
data_saddle.push({
lat: 3.5025888889e+01,
lng: 1.3540066667e+02,
content:'Saddle = 540.799988 pos = 35.0259,135.4007 diff = 150.200012'
});
data_peak.push({
lat: 3.5001777778e+01,
lng: 1.3535311111e+02,
cert : false,
content:' Peak = 721.700012 pos = 35.0018,135.3531 diff = 155.600037'
});
data_saddle.push({
lat: 3.5024444445e+01,
lng: 1.3536611111e+02,
content:'Saddle = 566.099976 pos = 35.0244,135.3661 diff = 155.600037'
});
data_peak.push({
lat: 3.5009444445e+01,
lng: 1.3539566667e+02,
cert : true,
content:'Name = JA/OS-003(JA/OS-003) peak = 784.000000 pos = 35.0094,135.3957 diff = 202.000000'
});
data_saddle.push({
lat: 3.5018555556e+01,
lng: 1.3537800000e+02,
content:'Saddle = 582.000000 pos = 35.0186,135.3780 diff = 202.000000'
});
data_peak.push({
lat: 3.5178000000e+01,
lng: 1.3523055556e+02,
cert : false,
content:' Peak = 544.000000 pos = 35.1780,135.2306 diff = 217.399994'
});
data_saddle.push({
lat: 3.5172777778e+01,
lng: 1.3522977778e+02,
content:'Saddle = 326.600006 pos = 35.1728,135.2298 diff = 217.399994'
});
data_peak.push({
lat: 3.5135666667e+01,
lng: 1.3534311111e+02,
cert : true,
content:'Name = JA/HG-080(JA/HG-080) peak = 632.299988 pos = 35.1357,135.3431 diff = 304.699982'
});
data_saddle.push({
lat: 3.5141333334e+01,
lng: 1.3533922222e+02,
content:'Saddle = 327.600006 pos = 35.1413,135.3392 diff = 304.699982'
});
data_peak.push({
lat: 3.5147555556e+01,
lng: 1.3536855556e+02,
cert : true,
content:'Name = JA/KT-054(JA/KT-054) peak = 549.200012 pos = 35.1476,135.3686 diff = 204.500000'
});
data_saddle.push({
lat: 3.5141888889e+01,
lng: 1.3537222222e+02,
content:'Saddle = 344.700012 pos = 35.1419,135.3722 diff = 204.500000'
});
data_peak.push({
lat: 3.5096222223e+01,
lng: 1.3538700000e+02,
cert : false,
content:' Peak = 507.399994 pos = 35.0962,135.3870 diff = 150.500000'
});
data_saddle.push({
lat: 3.5120888889e+01,
lng: 1.3538633333e+02,
content:'Saddle = 356.899994 pos = 35.1209,135.3863 diff = 150.500000'
});
data_peak.push({
lat: 3.5132222223e+01,
lng: 1.3536900000e+02,
cert : false,
content:' Peak = 581.700012 pos = 35.1322,135.3690 diff = 153.800018'
});
data_saddle.push({
lat: 3.5134222223e+01,
lng: 1.3535777778e+02,
content:'Saddle = 427.899994 pos = 35.1342,135.3578 diff = 153.800018'
});
data_peak.push({
lat: 3.5172666667e+01,
lng: 1.3516100000e+02,
cert : true,
content:'Name = JA/HG-099(JA/HG-099) peak = 562.200012 pos = 35.1727,135.1610 diff = 231.200012'
});
data_saddle.push({
lat: 3.5137222223e+01,
lng: 1.3524122222e+02,
content:'Saddle = 331.000000 pos = 35.1372,135.2412 diff = 231.200012'
});
data_peak.push({
lat: 3.5146222223e+01,
lng: 1.3523311111e+02,
cert : false,
content:' Peak = 542.700012 pos = 35.1462,135.2331 diff = 164.800018'
});
data_saddle.push({
lat: 3.5164222223e+01,
lng: 1.3522411111e+02,
content:'Saddle = 377.899994 pos = 35.1642,135.2241 diff = 164.800018'
});
data_peak.push({
lat: 3.5149555556e+01,
lng: 1.3534477778e+02,
cert : true,
content:'Name = JA/KT-049(JA/KT-049) peak = 560.400024 pos = 35.1496,135.3448 diff = 222.500031'
});
data_saddle.push({
lat: 3.5146333334e+01,
lng: 1.3532144444e+02,
content:'Saddle = 337.899994 pos = 35.1463,135.3214 diff = 222.500031'
});
data_peak.push({
lat: 3.5134222223e+01,
lng: 1.3531900000e+02,
cert : true,
content:'Name = JA/HG-068(JA/HG-068) peak = 675.500000 pos = 35.1342,135.3190 diff = 221.500000'
});
data_saddle.push({
lat: 3.5128777778e+01,
lng: 1.3528888889e+02,
content:'Saddle = 454.000000 pos = 35.1288,135.2889 diff = 221.500000'
});
data_peak.push({
lat: 3.5126666667e+01,
lng: 1.3526611111e+02,
cert : true,
content:'Name = JA/HG-056(JA/HG-056) peak = 722.799988 pos = 35.1267,135.2661 diff = 211.699982'
});
data_saddle.push({
lat: 3.5130333334e+01,
lng: 1.3525577778e+02,
content:'Saddle = 511.100006 pos = 35.1303,135.2558 diff = 211.699982'
});
data_peak.push({
lat: 3.5524222222e+01,
lng: 1.3623044444e+02,
cert : true,
content:'Name = JA/SI-050(JA/SI-050) peak = 531.599976 pos = 35.5242,136.2304 diff = 326.099976'
});
data_saddle.push({
lat: 3.5547888889e+01,
lng: 1.3622188889e+02,
content:'Saddle = 205.500000 pos = 35.5479,136.2219 diff = 326.099976'
});
data_peak.push({
lat: 3.5543888889e+01,
lng: 1.3665977778e+02,
cert : true,
content:'Name = JA/GF-191(JA/GF-191) peak = 454.200012 pos = 35.5439,136.6598 diff = 247.500015'
});
data_saddle.push({
lat: 3.5559888889e+01,
lng: 1.3665722222e+02,
content:'Saddle = 206.699997 pos = 35.5599,136.6572 diff = 247.500015'
});
data_peak.push({
lat: 3.5808000000e+01,
lng: 1.3608722222e+02,
cert : true,
content:'Name = JA/FI-075(JA/FI-075) peak = 398.399994 pos = 35.8080,136.0872 diff = 191.000000'
});
data_saddle.push({
lat: 3.5799555556e+01,
lng: 1.3609111111e+02,
content:'Saddle = 207.399994 pos = 35.7996,136.0911 diff = 191.000000'
});
data_peak.push({
lat: 3.5899666667e+01,
lng: 1.3626633333e+02,
cert : false,
content:' Peak = 382.600006 pos = 35.8997,136.2663 diff = 160.600006'
});
data_saddle.push({
lat: 3.5895555556e+01,
lng: 1.3626744444e+02,
content:'Saddle = 222.000000 pos = 35.8956,136.2674 diff = 160.600006'
});
data_peak.push({
lat: 3.5466888889e+01,
lng: 1.3613555556e+02,
cert : true,
content:'Name = JA/SI-055(JA/SI-055) peak = 471.100006 pos = 35.4669,136.1356 diff = 248.400009'
});
data_saddle.push({
lat: 3.5497444445e+01,
lng: 1.3615544444e+02,
content:'Saddle = 222.699997 pos = 35.4974,136.1554 diff = 248.400009'
});
data_peak.push({
lat: 3.5484555556e+01,
lng: 1.3614522222e+02,
cert : false,
content:' Peak = 458.000000 pos = 35.4846,136.1452 diff = 169.899994'
});
data_saddle.push({
lat: 3.5474000000e+01,
lng: 1.3614255556e+02,
content:'Saddle = 288.100006 pos = 35.4740,136.1426 diff = 169.899994'
});
data_peak.push({
lat: 3.5514111111e+01,
lng: 1.3613866667e+02,
cert : true,
content:'Name = JA/SI-062(JA/SI-062) peak = 412.399994 pos = 35.5141,136.1387 diff = 186.199997'
});
data_saddle.push({
lat: 3.5557777778e+01,
lng: 1.3612644444e+02,
content:'Saddle = 226.199997 pos = 35.5578,136.1264 diff = 186.199997'
});
data_peak.push({
lat: 3.5542888889e+01,
lng: 1.3613600000e+02,
cert : true,
content:'Name = JA/SI-063(JA/SI-063) peak = 410.899994 pos = 35.5429,136.1360 diff = 168.299988'
});
data_saddle.push({
lat: 3.5528555556e+01,
lng: 1.3613800000e+02,
content:'Saddle = 242.600006 pos = 35.5286,136.1380 diff = 168.299988'
});
data_peak.push({
lat: 3.5171777778e+01,
lng: 1.3550755556e+02,
cert : false,
content:' Peak = 380.600006 pos = 35.1718,135.5076 diff = 152.100006'
});
data_saddle.push({
lat: 3.5175888889e+01,
lng: 1.3550688889e+02,
content:'Saddle = 228.500000 pos = 35.1759,135.5069 diff = 152.100006'
});
data_peak.push({
lat: 3.5549777778e+01,
lng: 1.3695922222e+02,
cert : true,
content:'Name = JA/GF-197(JA/GF-197) peak = 433.799988 pos = 35.5498,136.9592 diff = 204.999985'
});
data_saddle.push({
lat: 3.5553666667e+01,
lng: 1.3695844444e+02,
content:'Saddle = 228.800003 pos = 35.5537,136.9584 diff = 204.999985'
});
data_peak.push({
lat: 3.5691111111e+01,
lng: 1.3695400000e+02,
cert : true,
content:'Name = JA/GF-192(JA/GF-192) peak = 445.299988 pos = 35.6911,136.9540 diff = 209.199982'
});
data_saddle.push({
lat: 3.5693333333e+01,
lng: 1.3696322222e+02,
content:'Saddle = 236.100006 pos = 35.6933,136.9632 diff = 209.199982'
});
data_peak.push({
lat: 3.5524333334e+01,
lng: 1.3653788889e+02,
cert : true,
content:'Name = JA/GF-194(JA/GF-194) peak = 442.399994 pos = 35.5243,136.5379 diff = 205.599991'
});
data_saddle.push({
lat: 3.5532333334e+01,
lng: 1.3657344444e+02,
content:'Saddle = 236.800003 pos = 35.5323,136.5734 diff = 205.599991'
});
data_peak.push({
lat: 3.5352222222e+01,
lng: 1.3641300000e+02,
cert : false,
content:' Peak = 390.700012 pos = 35.3522,136.4130 diff = 152.900009'
});
data_saddle.push({
lat: 3.5376444445e+01,
lng: 1.3642177778e+02,
content:'Saddle = 237.800003 pos = 35.3764,136.4218 diff = 152.900009'
});
data_peak.push({
lat: 3.5465777778e+01,
lng: 1.3627344444e+02,
cert : false,
content:' Peak = 494.200012 pos = 35.4658,136.2734 diff = 238.400009'
});
data_saddle.push({
lat: 3.5473222222e+01,
lng: 1.3628577778e+02,
content:'Saddle = 255.800003 pos = 35.4732,136.2858 diff = 238.400009'
});
data_peak.push({
lat: 3.5264666667e+01,
lng: 1.3589688889e+02,
cert : true,
content:'Name = Bunagadake(JA/SI-004) peak = 1213.300049 pos = 35.2647,135.8969 diff = 955.800049'
});
data_saddle.push({
lat: 3.5574888889e+01,
lng: 1.3612255556e+02,
content:'Saddle = 257.500000 pos = 35.5749,136.1226 diff = 955.800049'
});
data_peak.push({
lat: 3.5098777778e+01,
lng: 1.3578177778e+02,
cert : true,
content:'Name = JA/KT-078(JA/KT-078) peak = 432.100006 pos = 35.0988,135.7818 diff = 166.500000'
});
data_saddle.push({
lat: 3.5102222223e+01,
lng: 1.3579133333e+02,
content:'Saddle = 265.600006 pos = 35.1022,135.7913 diff = 166.500000'
});
data_peak.push({
lat: 3.5482222222e+01,
lng: 1.3595588889e+02,
cert : true,
content:'Name = JA/SI-012(JA/SI-012) peak = 973.700012 pos = 35.4822,135.9559 diff = 696.900024'
});
data_saddle.push({
lat: 3.5423333334e+01,
lng: 1.3593777778e+02,
content:'Saddle = 276.799988 pos = 35.4233,135.9378 diff = 696.900024'
});
data_peak.push({
lat: 3.5598555556e+01,
lng: 1.3597455556e+02,
cert : true,
content:'Name = JA/FI-063(JA/FI-063) peak = 547.200012 pos = 35.5986,135.9746 diff = 214.600006'
});
data_saddle.push({
lat: 3.5600222222e+01,
lng: 1.3598333333e+02,
content:'Saddle = 332.600006 pos = 35.6002,135.9833 diff = 214.600006'
});
data_peak.push({
lat: 3.5462555556e+01,
lng: 1.3609322222e+02,
cert : true,
content:'Name = JA/SI-048(JA/SI-048) peak = 591.200012 pos = 35.4626,136.0932 diff = 208.500000'
});
data_saddle.push({
lat: 3.5495666667e+01,
lng: 1.3610022222e+02,
content:'Saddle = 382.700012 pos = 35.4957,136.1002 diff = 208.500000'
});
data_peak.push({
lat: 3.5553111111e+01,
lng: 1.3610677778e+02,
cert : true,
content:'Name = JA/SI-043(JA/SI-043) peak = 653.400024 pos = 35.5531,136.1068 diff = 262.500031'
});
data_saddle.push({
lat: 3.5535000000e+01,
lng: 1.3609588889e+02,
content:'Saddle = 390.899994 pos = 35.5350,136.0959 diff = 262.500031'
});
data_peak.push({
lat: 3.5552333334e+01,
lng: 1.3594511111e+02,
cert : true,
content:'Name = JA/FI-035(JA/FI-035) peak = 787.799988 pos = 35.5523,135.9451 diff = 340.899994'
});
data_saddle.push({
lat: 3.5534777778e+01,
lng: 1.3595400000e+02,
content:'Saddle = 446.899994 pos = 35.5348,135.9540 diff = 340.899994'
});
data_peak.push({
lat: 3.5442666667e+01,
lng: 1.3598644444e+02,
cert : false,
content:' Peak = 691.500000 pos = 35.4427,135.9864 diff = 198.100006'
});
data_saddle.push({
lat: 3.5458666667e+01,
lng: 1.3599688889e+02,
content:'Saddle = 493.399994 pos = 35.4587,135.9969 diff = 198.100006'
});
data_peak.push({
lat: 3.5589666667e+01,
lng: 1.3602455556e+02,
cert : true,
content:'Name = Nosakadake(JA/FI-028) peak = 913.099976 pos = 35.5897,136.0246 diff = 346.599976'
});
data_saddle.push({
lat: 3.5543555556e+01,
lng: 1.3602488889e+02,
content:'Saddle = 566.500000 pos = 35.5436,136.0249 diff = 346.599976'
});
data_peak.push({
lat: 3.5563777778e+01,
lng: 1.3602522222e+02,
cert : true,
content:'Name = JA/FI-031(JA/FI-031) peak = 865.599976 pos = 35.5638,136.0252 diff = 171.699951'
});
data_saddle.push({
lat: 3.5578555556e+01,
lng: 1.3602888889e+02,
content:'Saddle = 693.900024 pos = 35.5786,136.0289 diff = 171.699951'
});
data_peak.push({
lat: 3.5532555556e+01,
lng: 1.3607733333e+02,
cert : true,
content:'Name = JA/SI-023(JA/SI-023) peak = 864.400024 pos = 35.5326,136.0773 diff = 296.100037'
});
data_saddle.push({
lat: 3.5531888889e+01,
lng: 1.3603911111e+02,
content:'Saddle = 568.299988 pos = 35.5319,136.0391 diff = 296.100037'
});
data_peak.push({
lat: 3.5529666667e+01,
lng: 1.3602644444e+02,
cert : true,
content:'Name = JA/SI-021(JA/SI-021) peak = 874.099976 pos = 35.5297,136.0264 diff = 299.500000'
});
data_saddle.push({
lat: 3.5491222222e+01,
lng: 1.3599244444e+02,
content:'Saddle = 574.599976 pos = 35.4912,135.9924 diff = 299.500000'
});
data_peak.push({
lat: 3.5453222222e+01,
lng: 1.3593833333e+02,
cert : true,
content:'Name = JA/SI-022(JA/SI-022) peak = 864.599976 pos = 35.4532,135.9383 diff = 222.699951'
});
data_saddle.push({
lat: 3.5468777778e+01,
lng: 1.3593966667e+02,
content:'Saddle = 641.900024 pos = 35.4688,135.9397 diff = 222.699951'
});
data_peak.push({
lat: 3.5492111111e+01,
lng: 1.3593011111e+02,
cert : true,
content:'Name = JA/SI-026(JA/SI-026) peak = 841.799988 pos = 35.4921,135.9301 diff = 199.399963'
});
data_saddle.push({
lat: 3.5517444445e+01,
lng: 1.3593900000e+02,
content:'Saddle = 642.400024 pos = 35.5174,135.9390 diff = 199.399963'
});
data_peak.push({
lat: 3.5500222222e+01,
lng: 1.3597233333e+02,
cert : true,
content:'Name = JA/FI-026(JA/FI-026) peak = 954.500000 pos = 35.5002,135.9723 diff = 230.900024'
});
data_saddle.push({
lat: 3.5502555556e+01,
lng: 1.3596033333e+02,
content:'Saddle = 723.599976 pos = 35.5026,135.9603 diff = 230.900024'
});
data_peak.push({
lat: 3.5153222223e+01,
lng: 1.3561022222e+02,
cert : false,
content:' Peak = 510.299988 pos = 35.1532,135.6102 diff = 232.500000'
});
data_saddle.push({
lat: 3.5172666667e+01,
lng: 1.3562088889e+02,
content:'Saddle = 277.799988 pos = 35.1727,135.6209 diff = 232.500000'
});
data_peak.push({
lat: 3.5436444445e+01,
lng: 1.3545177778e+02,
cert : true,
content:'Name = JA/KT-031(JA/KT-031) peak = 664.599976 pos = 35.4364,135.4518 diff = 386.699982'
});
data_saddle.push({
lat: 3.5439000000e+01,
lng: 1.3548844444e+02,
content:'Saddle = 277.899994 pos = 35.4390,135.4884 diff = 386.699982'
});
data_peak.push({
lat: 3.5391222222e+01,
lng: 1.3537800000e+02,
cert : true,
content:'Name = JA/KT-032(JA/KT-032) peak = 662.400024 pos = 35.3912,135.3780 diff = 299.500031'
});
data_saddle.push({
lat: 3.5391666667e+01,
lng: 1.3540122222e+02,
content:'Saddle = 362.899994 pos = 35.3917,135.4012 diff = 299.500031'
});
data_peak.push({
lat: 3.5409111111e+01,
lng: 1.3544911111e+02,
cert : true,
content:'Name = JA/KT-044(JA/KT-044) peak = 591.299988 pos = 35.4091,135.4491 diff = 209.299988'
});
data_saddle.push({
lat: 3.5420888889e+01,
lng: 1.3545755556e+02,
content:'Saddle = 382.000000 pos = 35.4209,135.4576 diff = 209.299988'
});
data_peak.push({
lat: 3.5415555556e+01,
lng: 1.3592500000e+02,
cert : true,
content:'Name = JA/SI-045(JA/SI-045) peak = 610.900024 pos = 35.4156,135.9250 diff = 332.300018'
});
data_saddle.push({
lat: 3.5393111111e+01,
lng: 1.3591800000e+02,
content:'Saddle = 278.600006 pos = 35.3931,135.9180 diff = 332.300018'
});
data_peak.push({
lat: 3.5384666667e+01,
lng: 1.3593400000e+02,
cert : true,
content:'Name = JA/SI-051(JA/SI-051) peak = 511.899994 pos = 35.3847,135.9340 diff = 184.299988'
});
data_saddle.push({
lat: 3.5394111111e+01,
lng: 1.3592877778e+02,
content:'Saddle = 327.600006 pos = 35.3941,135.9288 diff = 184.299988'
});
data_peak.push({
lat: 3.5452000000e+01,
lng: 1.3566011111e+02,
cert : true,
content:'Name = Hanseizan(JA/FI-061) peak = 581.799988 pos = 35.4520,135.6601 diff = 284.000000'
});
data_saddle.push({
lat: 3.5441222222e+01,
lng: 1.3560877778e+02,
content:'Saddle = 297.799988 pos = 35.4412,135.6088 diff = 284.000000'
});
data_peak.push({
lat: 3.5417222222e+01,
lng: 1.3561022222e+02,
cert : true,
content:'Name = JA/FI-067(JA/FI-067) peak = 523.299988 pos = 35.4172,135.6102 diff = 222.000000'
});
data_saddle.push({
lat: 3.5436666667e+01,
lng: 1.3556555556e+02,
content:'Saddle = 301.299988 pos = 35.4367,135.5656 diff = 222.000000'
});
data_peak.push({
lat: 3.5092888889e+01,
lng: 1.3580855556e+02,
cert : false,
content:' Peak = 532.500000 pos = 35.0929,135.8086 diff = 209.100006'
});
data_saddle.push({
lat: 3.5111555556e+01,
lng: 1.3580911111e+02,
content:'Saddle = 323.399994 pos = 35.1116,135.8091 diff = 209.100006'
});
data_peak.push({
lat: 3.5136333334e+01,
lng: 1.3556844444e+02,
cert : false,
content:' Peak = 550.700012 pos = 35.1363,135.5684 diff = 216.800018'
});
data_saddle.push({
lat: 3.5143555556e+01,
lng: 1.3556722222e+02,
content:'Saddle = 333.899994 pos = 35.1436,135.5672 diff = 216.800018'
});
data_peak.push({
lat: 3.5161222223e+01,
lng: 1.3556800000e+02,
cert : true,
content:'Name = JA/KT-046(JA/KT-046) peak = 566.200012 pos = 35.1612,135.5680 diff = 228.200012'
});
data_saddle.push({
lat: 3.5196555556e+01,
lng: 1.3559144444e+02,
content:'Saddle = 338.000000 pos = 35.1966,135.5914 diff = 228.200012'
});
data_peak.push({
lat: 3.5160333334e+01,
lng: 1.3557811111e+02,
cert : false,
content:' Peak = 541.099976 pos = 35.1603,135.5781 diff = 173.899963'
});
data_saddle.push({
lat: 3.5168333334e+01,
lng: 1.3558300000e+02,
content:'Saddle = 367.200012 pos = 35.1683,135.5830 diff = 173.899963'
});
data_peak.push({
lat: 3.5179222223e+01,
lng: 1.3557566667e+02,
cert : false,
content:' Peak = 553.299988 pos = 35.1792,135.5757 diff = 155.699982'
});
data_saddle.push({
lat: 3.5167888889e+01,
lng: 1.3557255556e+02,
content:'Saddle = 397.600006 pos = 35.1679,135.5726 diff = 155.699982'
});
data_peak.push({
lat: 3.5113222223e+01,
lng: 1.3553711111e+02,
cert : false,
content:' Peak = 510.100006 pos = 35.1132,135.5371 diff = 163.800018'
});
data_saddle.push({
lat: 3.5107666667e+01,
lng: 1.3555044444e+02,
content:'Saddle = 346.299988 pos = 35.1077,135.5504 diff = 163.800018'
});
data_peak.push({
lat: 3.5059444445e+01,
lng: 1.3569133333e+02,
cert : true,
content:'Name = JA/KT-062(JA/KT-062) peak = 521.599976 pos = 35.0594,135.6913 diff = 169.599976'
});
data_saddle.push({
lat: 3.5063111111e+01,
lng: 1.3570600000e+02,
content:'Saddle = 352.000000 pos = 35.0631,135.7060 diff = 169.599976'
});
data_peak.push({
lat: 3.5134000000e+01,
lng: 1.3558044444e+02,
cert : false,
content:' Peak = 512.799988 pos = 35.1340,135.5804 diff = 160.000000'
});
data_saddle.push({
lat: 3.5127777778e+01,
lng: 1.3557811111e+02,
content:'Saddle = 352.799988 pos = 35.1278,135.5781 diff = 160.000000'
});
data_peak.push({
lat: 3.5124777778e+01,
lng: 1.3561355556e+02,
cert : true,
content:'Name = JA/KT-059(JA/KT-059) peak = 536.000000 pos = 35.1248,135.6136 diff = 179.100006'
});
data_saddle.push({
lat: 3.5128000000e+01,
lng: 1.3562266667e+02,
content:'Saddle = 356.899994 pos = 35.1280,135.6227 diff = 179.100006'
});
data_peak.push({
lat: 3.5117666667e+01,
lng: 1.3557755556e+02,
cert : false,
content:' Peak = 627.400024 pos = 35.1177,135.5776 diff = 260.500031'
});
data_saddle.push({
lat: 3.5111444445e+01,
lng: 1.3558333333e+02,
content:'Saddle = 366.899994 pos = 35.1114,135.5833 diff = 260.500031'
});
data_peak.push({
lat: 3.5065888889e+01,
lng: 1.3583444444e+02,
cert : true,
content:'Name = Hieizan (Daihiei)(JA/SI-025) peak = 847.599976 pos = 35.0659,135.8344 diff = 469.399963'
});
data_saddle.push({
lat: 3.5160000000e+01,
lng: 1.3585266667e+02,
content:'Saddle = 378.200012 pos = 35.1600,135.8527 diff = 469.399963'
});
data_peak.push({
lat: 3.5085777778e+01,
lng: 1.3569888889e+02,
cert : true,
content:'Name = JA/KT-045(JA/KT-045) peak = 570.500000 pos = 35.0858,135.6989 diff = 181.500000'
});
data_saddle.push({
lat: 3.5113000000e+01,
lng: 1.3571022222e+02,
content:'Saddle = 389.000000 pos = 35.1130,135.7102 diff = 181.500000'
});
data_peak.push({
lat: 3.5106555556e+01,
lng: 1.3571277778e+02,
cert : false,
content:' Peak = 563.500000 pos = 35.1066,135.7128 diff = 165.600006'
});
data_saddle.push({
lat: 3.5085666667e+01,
lng: 1.3572688889e+02,
content:'Saddle = 397.899994 pos = 35.0857,135.7269 diff = 165.600006'
});
data_peak.push({
lat: 3.5425000000e+01,
lng: 1.3549577778e+02,
cert : false,
content:' Peak = 572.799988 pos = 35.4250,135.4958 diff = 165.099976'
});
data_saddle.push({
lat: 3.5424111111e+01,
lng: 1.3551155556e+02,
content:'Saddle = 407.700012 pos = 35.4241,135.5116 diff = 165.099976'
});
data_peak.push({
lat: 3.5076333334e+01,
lng: 1.3559066667e+02,
cert : true,
content:'Name = JA/KT-040(JA/KT-040) peak = 624.200012 pos = 35.0763,135.5907 diff = 215.700012'
});
data_saddle.push({
lat: 3.5081444445e+01,
lng: 1.3560144444e+02,
content:'Saddle = 408.500000 pos = 35.0814,135.6014 diff = 215.700012'
});
data_peak.push({
lat: 3.5279444445e+01,
lng: 1.3542100000e+02,
cert : true,
content:'Name = JA/KT-038(JA/KT-038) peak = 623.099976 pos = 35.2794,135.4210 diff = 199.599976'
});
data_saddle.push({
lat: 3.5295666667e+01,
lng: 1.3540711111e+02,
content:'Saddle = 423.500000 pos = 35.2957,135.4071 diff = 199.599976'
});
data_peak.push({
lat: 3.5247888889e+01,
lng: 1.3551944444e+02,
cert : true,
content:'Name = JA/KT-019(JA/KT-019) peak = 755.599976 pos = 35.2479,135.5194 diff = 326.799988'
});
data_saddle.push({
lat: 3.5220666667e+01,
lng: 1.3558888889e+02,
content:'Saddle = 428.799988 pos = 35.2207,135.5889 diff = 326.799988'
});
data_peak.push({
lat: 3.5075444445e+01,
lng: 1.3562344444e+02,
cert : true,
content:'Name = JA/KT-003(JA/KT-003) peak = 946.500000 pos = 35.0754,135.6234 diff = 499.299988'
});
data_saddle.push({
lat: 3.5116222223e+01,
lng: 1.3565988889e+02,
content:'Saddle = 447.200012 pos = 35.1162,135.6599 diff = 499.299988'
});
data_peak.push({
lat: 3.5110000000e+01,
lng: 1.3559744444e+02,
cert : false,
content:' Peak = 621.700012 pos = 35.1100,135.5974 diff = 153.600006'
});
data_saddle.push({
lat: 3.5102333334e+01,
lng: 1.3559888889e+02,
content:'Saddle = 468.100006 pos = 35.1023,135.5989 diff = 153.600006'
});
data_peak.push({
lat: 3.5100333334e+01,
lng: 1.3561844444e+02,
cert : false,
content:' Peak = 731.599976 pos = 35.1003,135.6184 diff = 158.399963'
});
data_saddle.push({
lat: 3.5093555556e+01,
lng: 1.3561566667e+02,
content:'Saddle = 573.200012 pos = 35.0936,135.6157 diff = 158.399963'
});
data_peak.push({
lat: 3.5407666667e+01,
lng: 1.3556955556e+02,
cert : true,
content:'Name = JA/FI-052(JA/FI-052) peak = 670.700012 pos = 35.4077,135.5696 diff = 207.200012'
});
data_saddle.push({
lat: 3.5425000000e+01,
lng: 1.3554311111e+02,
content:'Saddle = 463.500000 pos = 35.4250,135.5431 diff = 207.200012'
});
data_peak.push({
lat: 3.5302111111e+01,
lng: 1.3537855556e+02,
cert : false,
content:' Peak = 623.200012 pos = 35.3021,135.3786 diff = 153.900024'
});
data_saddle.push({
lat: 3.5305666667e+01,
lng: 1.3537955556e+02,
content:'Saddle = 469.299988 pos = 35.3057,135.3796 diff = 153.900024'
});
data_peak.push({
lat: 3.5451111111e+01,
lng: 1.3576255556e+02,
cert : true,
content:'Name = JA/FI-046(JA/FI-046) peak = 711.200012 pos = 35.4511,135.7626 diff = 228.900024'
});
data_saddle.push({
lat: 3.5441888889e+01,
lng: 1.3576000000e+02,
content:'Saddle = 482.299988 pos = 35.4419,135.7600 diff = 228.900024'
});
data_peak.push({
lat: 3.5303333334e+01,
lng: 1.3547400000e+02,
cert : true,
content:'Name = Chyourougadake(JA/KT-006) peak = 916.299988 pos = 35.3033,135.4740 diff = 409.099976'
});
data_saddle.push({
lat: 3.5369777778e+01,
lng: 1.3559133333e+02,
content:'Saddle = 507.200012 pos = 35.3698,135.5913 diff = 409.099976'
});
data_peak.push({
lat: 3.5377444445e+01,
lng: 1.3553444444e+02,
cert : true,
content:'Name = Toukinzan(JA/KT-010) peak = 870.599976 pos = 35.3774,135.5344 diff = 219.199951'
});
data_saddle.push({
lat: 3.5354888889e+01,
lng: 1.3550177778e+02,
content:'Saddle = 651.400024 pos = 35.3549,135.5018 diff = 219.199951'
});
data_peak.push({
lat: 3.5325222222e+01,
lng: 1.3550255556e+02,
cert : true,
content:'Name = JA/KT-008(JA/KT-008) peak = 893.200012 pos = 35.3252,135.5026 diff = 181.200012'
});
data_saddle.push({
lat: 3.5315888889e+01,
lng: 1.3548444444e+02,
content:'Saddle = 712.000000 pos = 35.3159,135.4844 diff = 181.200012'
});
data_peak.push({
lat: 3.5300666667e+01,
lng: 1.3586422222e+02,
cert : false,
content:' Peak = 948.000000 pos = 35.3007,135.8642 diff = 440.200012'
});
data_saddle.push({
lat: 3.5364555556e+01,
lng: 1.3580455556e+02,
content:'Saddle = 507.799988 pos = 35.3646,135.8046 diff = 440.200012'
});
data_peak.push({
lat: 3.5245333334e+01,
lng: 1.3562888889e+02,
cert : false,
content:' Peak = 676.099976 pos = 35.2453,135.6289 diff = 165.799988'
});
data_saddle.push({
lat: 3.5253888889e+01,
lng: 1.3563633333e+02,
content:'Saddle = 510.299988 pos = 35.2539,135.6363 diff = 165.799988'
});
data_peak.push({
lat: 3.5289666667e+01,
lng: 1.3597088889e+02,
cert : false,
content:' Peak = 701.799988 pos = 35.2897,135.9709 diff = 150.899963'
});
data_saddle.push({
lat: 3.5282111111e+01,
lng: 1.3595577778e+02,
content:'Saddle = 550.900024 pos = 35.2821,135.9558 diff = 150.899963'
});
data_peak.push({
lat: 3.5136777778e+01,
lng: 1.3581633333e+02,
cert : false,
content:' Peak = 713.700012 pos = 35.1368,135.8163 diff = 150.799988'
});
data_saddle.push({
lat: 3.5143222223e+01,
lng: 1.3580833333e+02,
content:'Saddle = 562.900024 pos = 35.1432,135.8083 diff = 150.799988'
});
data_peak.push({
lat: 3.5202222223e+01,
lng: 1.3583522222e+02,
cert : true,
content:'Name = Minakoyama(JA/SI-013) peak = 970.299988 pos = 35.2022,135.8352 diff = 393.000000'
});
data_saddle.push({
lat: 3.5187777778e+01,
lng: 1.3586011111e+02,
content:'Saddle = 577.299988 pos = 35.1878,135.8601 diff = 393.000000'
});
data_peak.push({
lat: 3.5225333334e+01,
lng: 1.3576122222e+02,
cert : true,
content:'Name = JA/KT-018(JA/KT-018) peak = 760.299988 pos = 35.2253,135.7612 diff = 178.099976'
});
data_saddle.push({
lat: 3.5231444445e+01,
lng: 1.3576111111e+02,
content:'Saddle = 582.200012 pos = 35.2314,135.7611 diff = 178.099976'
});
data_peak.push({
lat: 3.5334666667e+01,
lng: 1.3560877778e+02,
cert : false,
content:' Peak = 782.000000 pos = 35.3347,135.6088 diff = 189.900024'
});
data_saddle.push({
lat: 3.5355222222e+01,
lng: 1.3561777778e+02,
content:'Saddle = 592.099976 pos = 35.3552,135.6178 diff = 189.900024'
});
data_peak.push({
lat: 3.5287888889e+01,
lng: 1.3562288889e+02,
cert : false,
content:' Peak = 752.700012 pos = 35.2879,135.6229 diff = 159.600037'
});
data_saddle.push({
lat: 3.5279444445e+01,
lng: 1.3562700000e+02,
content:'Saddle = 593.099976 pos = 35.2794,135.6270 diff = 159.600037'
});
data_peak.push({
lat: 3.5357222222e+01,
lng: 1.3566800000e+02,
cert : true,
content:'Name = JA/FI-033(JA/FI-033) peak = 800.000000 pos = 35.3572,135.6680 diff = 203.000000'
});
data_saddle.push({
lat: 3.5346111111e+01,
lng: 1.3569211111e+02,
content:'Saddle = 597.000000 pos = 35.3461,135.6921 diff = 203.000000'
});
data_peak.push({
lat: 3.5302111111e+01,
lng: 1.3567866667e+02,
cert : true,
content:'Name = JA/KT-013(JA/KT-013) peak = 822.299988 pos = 35.3021,135.6787 diff = 224.700012'
});
data_saddle.push({
lat: 3.5244555556e+01,
lng: 1.3569544444e+02,
content:'Saddle = 597.599976 pos = 35.2446,135.6954 diff = 224.700012'
});
data_peak.push({
lat: 3.5365222222e+01,
lng: 1.3583966667e+02,
cert : true,
content:'Name = JA/SI-032(JA/SI-032) peak = 791.200012 pos = 35.3652,135.8397 diff = 183.000000'
});
data_saddle.push({
lat: 3.5372666667e+01,
lng: 1.3583166667e+02,
content:'Saddle = 608.200012 pos = 35.3727,135.8317 diff = 183.000000'
});
data_peak.push({
lat: 3.5391777778e+01,
lng: 1.3581011111e+02,
cert : true,
content:'Name = Hyakurigadake(JA/SI-016) peak = 930.900024 pos = 35.3918,135.8101 diff = 308.700012'
});
data_saddle.push({
lat: 3.5360111111e+01,
lng: 1.3577022222e+02,
content:'Saddle = 622.200012 pos = 35.3601,135.7702 diff = 308.700012'
});
data_peak.push({
lat: 3.5371777778e+01,
lng: 1.3578077778e+02,
cert : true,
content:'Name = JA/SI-031(JA/SI-031) peak = 801.799988 pos = 35.3718,135.7808 diff = 170.299988'
});
data_saddle.push({
lat: 3.5377888889e+01,
lng: 1.3578644444e+02,
content:'Saddle = 631.500000 pos = 35.3779,135.7864 diff = 170.299988'
});
data_peak.push({
lat: 3.5413222222e+01,
lng: 1.3581422222e+02,
cert : true,
content:'Name = JA/SI-028(JA/SI-028) peak = 824.500000 pos = 35.4132,135.8142 diff = 172.099976'
});
data_saddle.push({
lat: 3.5405777778e+01,
lng: 1.3581055556e+02,
content:'Saddle = 652.400024 pos = 35.4058,135.8106 diff = 172.099976'
});
data_peak.push({
lat: 3.5178777778e+01,
lng: 1.3584344444e+02,
cert : true,
content:'Name = JA/SI-030(JA/SI-030) peak = 811.700012 pos = 35.1788,135.8434 diff = 175.200012'
});
data_saddle.push({
lat: 3.5160444445e+01,
lng: 1.3581166667e+02,
content:'Saddle = 636.500000 pos = 35.1604,135.8117 diff = 175.200012'
});
data_peak.push({
lat: 3.5164777778e+01,
lng: 1.3582555556e+02,
cert : false,
content:' Peak = 811.299988 pos = 35.1648,135.8256 diff = 158.799988'
});
data_saddle.push({
lat: 3.5178888889e+01,
lng: 1.3583544444e+02,
content:'Saddle = 652.500000 pos = 35.1789,135.8354 diff = 158.799988'
});
data_peak.push({
lat: 3.5318666667e+01,
lng: 1.3570366667e+02,
cert : false,
content:' Peak = 812.099976 pos = 35.3187,135.7037 diff = 175.199951'
});
data_saddle.push({
lat: 3.5352777778e+01,
lng: 1.3571255556e+02,
content:'Saddle = 636.900024 pos = 35.3528,135.7126 diff = 175.199951'
});
data_peak.push({
lat: 3.5320666667e+01,
lng: 1.3579388889e+02,
cert : true,
content:'Name = JA/KT-002(JA/KT-002) peak = 956.400024 pos = 35.3207,135.7939 diff = 304.400024'
});
data_saddle.push({
lat: 3.5266333334e+01,
lng: 1.3579511111e+02,
content:'Saddle = 652.000000 pos = 35.2663,135.7951 diff = 304.400024'
});
data_peak.push({
lat: 3.5328666667e+01,
lng: 1.3575900000e+02,
cert : false,
content:' Peak = 934.799988 pos = 35.3287,135.7590 diff = 260.299988'
});
data_saddle.push({
lat: 3.5355666667e+01,
lng: 1.3575311111e+02,
content:'Saddle = 674.500000 pos = 35.3557,135.7531 diff = 260.299988'
});
data_peak.push({
lat: 3.5255444445e+01,
lng: 1.3573344444e+02,
cert : false,
content:' Peak = 890.799988 pos = 35.2554,135.7334 diff = 159.200012'
});
data_saddle.push({
lat: 3.5274000000e+01,
lng: 1.3572800000e+02,
content:'Saddle = 731.599976 pos = 35.2740,135.7280 diff = 159.200012'
});
data_peak.push({
lat: 3.5291555556e+01,
lng: 1.3582033333e+02,
cert : true,
content:'Name = JA/SI-017(JA/SI-017) peak = 906.799988 pos = 35.2916,135.8203 diff = 164.500000'
});
data_saddle.push({
lat: 3.5304000000e+01,
lng: 1.3581544444e+02,
content:'Saddle = 742.299988 pos = 35.3040,135.8154 diff = 164.500000'
});
data_peak.push({
lat: 3.5180222223e+01,
lng: 1.3576711111e+02,
cert : false,
content:' Peak = 913.900024 pos = 35.1802,135.7671 diff = 261.500000'
});
data_saddle.push({
lat: 3.5202333334e+01,
lng: 1.3579966667e+02,
content:'Saddle = 652.400024 pos = 35.2023,135.7997 diff = 261.500000'
});
data_peak.push({
lat: 3.5159222223e+01,
lng: 1.3571722222e+02,
cert : true,
content:'Name = Sajikigadake(JA/KT-009) peak = 894.400024 pos = 35.1592,135.7172 diff = 197.700012'
});
data_saddle.push({
lat: 3.5148888889e+01,
lng: 1.3575677778e+02,
content:'Saddle = 696.700012 pos = 35.1489,135.7568 diff = 197.700012'
});
data_peak.push({
lat: 3.5237555556e+01,
lng: 1.3582366667e+02,
cert : true,
content:'Name = JA/KT-001(JA/KT-001) peak = 967.900024 pos = 35.2376,135.8237 diff = 241.000000'
});
data_saddle.push({
lat: 3.5211888889e+01,
lng: 1.3581188889e+02,
content:'Saddle = 726.900024 pos = 35.2119,135.8119 diff = 241.000000'
});
data_peak.push({
lat: 3.5254111111e+01,
lng: 1.3579422222e+02,
cert : true,
content:'Name = JA/KT-005(JA/KT-005) peak = 931.200012 pos = 35.2541,135.7942 diff = 194.100037'
});
data_saddle.push({
lat: 3.5247555556e+01,
lng: 1.3580966667e+02,
content:'Saddle = 737.099976 pos = 35.2476,135.8097 diff = 194.100037'
});
data_peak.push({
lat: 3.5320444445e+01,
lng: 1.3592855556e+02,
cert : true,
content:'Name = JA/SI-019(JA/SI-019) peak = 901.599976 pos = 35.3204,135.9286 diff = 258.799988'
});
data_saddle.push({
lat: 3.5299666667e+01,
lng: 1.3592011111e+02,
content:'Saddle = 642.799988 pos = 35.2997,135.9201 diff = 258.799988'
});
data_peak.push({
lat: 3.5209555556e+01,
lng: 1.3588566667e+02,
cert : true,
content:'Name = Houraisan(JA/SI-006) peak = 1173.599976 pos = 35.2096,135.8857 diff = 290.799988'
});
data_saddle.push({
lat: 3.5247444445e+01,
lng: 1.3590655556e+02,
content:'Saddle = 882.799988 pos = 35.2474,135.9066 diff = 290.799988'
});
data_peak.push({
lat: 3.5751666667e+01,
lng: 1.3699377778e+02,
cert : true,
content:'Name = JA/GF-156(JA/GF-156) peak = 815.799988 pos = 35.7517,136.9938 diff = 541.599976'
});
data_saddle.push({
lat: 3.5780444445e+01,
lng: 1.3699988889e+02,
content:'Saddle = 274.200012 pos = 35.7804,136.9999 diff = 541.599976'
});
data_peak.push({
lat: 3.5619000000e+01,
lng: 1.3698644444e+02,
cert : true,
content:'Name = JA/GF-186(JA/GF-186) peak = 567.400024 pos = 35.6190,136.9864 diff = 179.300018'
});
data_saddle.push({
lat: 3.5631333333e+01,
lng: 1.3698333333e+02,
content:'Saddle = 388.100006 pos = 35.6313,136.9833 diff = 179.300018'
});
data_peak.push({
lat: 3.5728666667e+01,
lng: 1.3696266667e+02,
cert : false,
content:' Peak = 618.000000 pos = 35.7287,136.9627 diff = 213.799988'
});
data_saddle.push({
lat: 3.5736444445e+01,
lng: 1.3696488889e+02,
content:'Saddle = 404.200012 pos = 35.7364,136.9649 diff = 213.799988'
});
data_peak.push({
lat: 3.5730777778e+01,
lng: 1.3699988889e+02,
cert : true,
content:'Name = JA/GF-164(JA/GF-164) peak = 748.700012 pos = 35.7308,136.9999 diff = 191.700012'
});
data_saddle.push({
lat: 3.5734888889e+01,
lng: 1.3698788889e+02,
content:'Saddle = 557.000000 pos = 35.7349,136.9879 diff = 191.700012'
});
data_peak.push({
lat: 3.5802333333e+01,
lng: 1.3621955556e+02,
cert : true,
content:'Name = JA/FI-069(JA/FI-069) peak = 491.299988 pos = 35.8023,136.2196 diff = 209.599976'
});
data_saddle.push({
lat: 3.5804222222e+01,
lng: 1.3623455556e+02,
content:'Saddle = 281.700012 pos = 35.8042,136.2346 diff = 209.599976'
});
data_peak.push({
lat: 3.5571222222e+01,
lng: 1.3620333333e+02,
cert : false,
content:' Peak = 482.500000 pos = 35.5712,136.2033 diff = 164.399994'
});
data_saddle.push({
lat: 3.5577111111e+01,
lng: 1.3620355556e+02,
content:'Saddle = 318.100006 pos = 35.5771,136.2036 diff = 164.399994'
});
data_peak.push({
lat: 3.5639777778e+01,
lng: 1.3613366667e+02,
cert : true,
content:'Name = JA/FI-057(JA/FI-057) peak = 646.099976 pos = 35.6398,136.1337 diff = 324.799988'
});
data_saddle.push({
lat: 3.5655444445e+01,
lng: 1.3612722222e+02,
content:'Saddle = 321.299988 pos = 35.6554,136.1272 diff = 324.799988'
});
data_peak.push({
lat: 3.5541000000e+01,
lng: 1.3624455556e+02,
cert : false,
content:' Peak = 504.399994 pos = 35.5410,136.2446 diff = 182.100006'
});
data_saddle.push({
lat: 3.5562888889e+01,
lng: 1.3624088889e+02,
content:'Saddle = 322.299988 pos = 35.5629,136.2409 diff = 182.100006'
});
data_peak.push({
lat: 3.5842444445e+01,
lng: 1.3608477778e+02,
cert : false,
content:' Peak = 483.500000 pos = 35.8424,136.0848 diff = 154.100006'
});
data_saddle.push({
lat: 3.5845444445e+01,
lng: 1.3611922222e+02,
content:'Saddle = 329.399994 pos = 35.8454,136.1192 diff = 154.100006'
});
data_peak.push({
lat: 3.5602555556e+01,
lng: 1.3666333333e+02,
cert : true,
content:'Name = JA/GF-165(JA/GF-165) peak = 744.000000 pos = 35.6026,136.6633 diff = 406.700012'
});
data_saddle.push({
lat: 3.5620444445e+01,
lng: 1.3666811111e+02,
content:'Saddle = 337.299988 pos = 35.6204,136.6681 diff = 406.700012'
});
data_peak.push({
lat: 3.5973888889e+01,
lng: 1.3633300000e+02,
cert : true,
content:'Name = JA/FI-042(JA/FI-042) peak = 740.400024 pos = 35.9739,136.3330 diff = 402.800018'
});
data_saddle.push({
lat: 3.5864444444e+01,
lng: 1.3628533333e+02,
content:'Saddle = 337.600006 pos = 35.8644,136.2853 diff = 402.800018'
});
data_peak.push({
lat: 3.5905333333e+01,
lng: 1.3632044444e+02,
cert : true,
content:'Name = JA/FI-047(JA/FI-047) peak = 700.700012 pos = 35.9053,136.3204 diff = 308.300018'
});
data_saddle.push({
lat: 3.5920666667e+01,
lng: 1.3632577778e+02,
content:'Saddle = 392.399994 pos = 35.9207,136.3258 diff = 308.300018'
});
data_peak.push({
lat: 3.5873777778e+01,
lng: 1.3630511111e+02,
cert : true,
content:'Name = JA/FI-059(JA/FI-059) peak = 620.299988 pos = 35.8738,136.3051 diff = 197.000000'
});
data_saddle.push({
lat: 3.5884000000e+01,
lng: 1.3630688889e+02,
content:'Saddle = 423.299988 pos = 35.8840,136.3069 diff = 197.000000'
});
data_peak.push({
lat: 3.5794555556e+01,
lng: 1.3614888889e+02,
cert : true,
content:'Name = JA/FI-041(JA/FI-041) peak = 745.200012 pos = 35.7946,136.1489 diff = 358.400024'
});
data_saddle.push({
lat: 3.5769666667e+01,
lng: 1.3611411111e+02,
content:'Saddle = 386.799988 pos = 35.7697,136.1141 diff = 358.400024'
});
data_peak.push({
lat: 3.5982888889e+01,
lng: 1.3661866667e+02,
cert : false,
content:' Peak = 999.799988 pos = 35.9829,136.6187 diff = 604.199951'
});
data_saddle.push({
lat: 3.6000000000e+01,
lng: 1.3665122222e+02,
content:'Saddle = 395.600006 pos = 36.0000,136.6512 diff = 604.199951'
});
data_peak.push({
lat: 3.5999666667e+01,
lng: 1.3664344444e+02,
cert : false,
content:' Peak = 820.200012 pos = 35.9997,136.6434 diff = 269.000000'
});
data_saddle.push({
lat: 3.6000000000e+01,
lng: 1.3663766667e+02,
content:'Saddle = 551.200012 pos = 36.0000,136.6377 diff = 269.000000'
});
data_peak.push({
lat: 3.5586666667e+01,
lng: 1.3616244444e+02,
cert : false,
content:' Peak = 663.000000 pos = 35.5867,136.1624 diff = 265.200012'
});
data_saddle.push({
lat: 3.5594111111e+01,
lng: 1.3617633333e+02,
content:'Saddle = 397.799988 pos = 35.5941,136.1763 diff = 265.200012'
});
data_peak.push({
lat: 3.5974000000e+01,
lng: 1.3639944444e+02,
cert : true,
content:'Name = JA/FI-056(JA/FI-056) peak = 651.799988 pos = 35.9740,136.3994 diff = 249.299988'
});
data_saddle.push({
lat: 3.5972888889e+01,
lng: 1.3642966667e+02,
content:'Saddle = 402.500000 pos = 35.9729,136.4297 diff = 249.299988'
});
data_peak.push({
lat: 3.5423777778e+01,
lng: 1.3635733333e+02,
cert : true,
content:'Name = JA/SI-039(JA/SI-039) peak = 690.500000 pos = 35.4238,136.3573 diff = 283.500000'
});
data_saddle.push({
lat: 3.5459666667e+01,
lng: 1.3634300000e+02,
content:'Saddle = 407.000000 pos = 35.4597,136.3430 diff = 283.500000'
});
data_peak.push({
lat: 3.5544888889e+01,
lng: 1.3659611111e+02,
cert : true,
content:'Name = JA/GF-176(JA/GF-176) peak = 662.799988 pos = 35.5449,136.5961 diff = 224.599976'
});
data_saddle.push({
lat: 3.5562555556e+01,
lng: 1.3656855556e+02,
content:'Saddle = 438.200012 pos = 35.5626,136.5686 diff = 224.599976'
});
data_peak.push({
lat: 3.5863555556e+01,
lng: 1.3634677778e+02,
cert : false,
content:' Peak = 653.500000 pos = 35.8636,136.3468 diff = 201.600006'
});
data_saddle.push({
lat: 3.5855666667e+01,
lng: 1.3634233333e+02,
content:'Saddle = 451.899994 pos = 35.8557,136.3423 diff = 201.600006'
});
data_peak.push({
lat: 3.5840333333e+01,
lng: 1.3689511111e+02,
cert : true,
content:'Name = JA/GF-180(JA/GF-180) peak = 639.400024 pos = 35.8403,136.8951 diff = 181.000031'
});
data_saddle.push({
lat: 3.5865666667e+01,
lng: 1.3689922222e+02,
content:'Saddle = 458.399994 pos = 35.8657,136.8992 diff = 181.000031'
});
data_peak.push({
lat: 3.5859222222e+01,
lng: 1.3620744444e+02,
cert : true,
content:'Name = Hinosan(JA/FI-034) peak = 793.799988 pos = 35.8592,136.2074 diff = 312.000000'
});
data_saddle.push({
lat: 3.5856222222e+01,
lng: 1.3622100000e+02,
content:'Saddle = 481.799988 pos = 35.8562,136.2210 diff = 312.000000'
});
data_peak.push({
lat: 3.5794555556e+01,
lng: 1.3699633333e+02,
cert : false,
content:' Peak = 662.000000 pos = 35.7946,136.9963 diff = 170.500000'
});
data_saddle.push({
lat: 3.5810222222e+01,
lng: 1.3699977778e+02,
content:'Saddle = 491.500000 pos = 35.8102,136.9998 diff = 170.500000'
});
data_peak.push({
lat: 3.5578666667e+01,
lng: 1.3624744444e+02,
cert : true,
content:'Name = JA/SI-036(JA/SI-036) peak = 734.599976 pos = 35.5787,136.2474 diff = 233.599976'
});
data_saddle.push({
lat: 3.5586777778e+01,
lng: 1.3625666667e+02,
content:'Saddle = 501.000000 pos = 35.5868,136.2567 diff = 233.599976'
});
data_peak.push({
lat: 3.5550888889e+01,
lng: 1.3653611111e+02,
cert : true,
content:'Name = JA/GF-170(JA/GF-170) peak = 721.400024 pos = 35.5509,136.5361 diff = 217.700012'
});
data_saddle.push({
lat: 3.5566666667e+01,
lng: 1.3654177778e+02,
content:'Saddle = 503.700012 pos = 35.5667,136.5418 diff = 217.700012'
});
data_peak.push({
lat: 3.5617444445e+01,
lng: 1.3619400000e+02,
cert : true,
content:'Name = JA/SI-018(JA/SI-018) peak = 900.900024 pos = 35.6174,136.1940 diff = 396.600037'
});
data_saddle.push({
lat: 3.5639444445e+01,
lng: 1.3616255556e+02,
content:'Saddle = 504.299988 pos = 35.6394,136.1626 diff = 396.600037'
});
data_peak.push({
lat: 3.5643444445e+01,
lng: 1.3617255556e+02,
cert : true,
content:'Name = JA/SI-020(JA/SI-020) peak = 891.000000 pos = 35.6434,136.1726 diff = 208.299988'
});
data_saddle.push({
lat: 3.5625111111e+01,
lng: 1.3618166667e+02,
content:'Saddle = 682.700012 pos = 35.6251,136.1817 diff = 208.299988'
});
data_peak.push({
lat: 3.5823888889e+01,
lng: 1.3627277778e+02,
cert : true,
content:'Name = JA/FI-036(JA/FI-036) peak = 774.000000 pos = 35.8239,136.2728 diff = 266.899994'
});
data_saddle.push({
lat: 3.5820888889e+01,
lng: 1.3631366667e+02,
content:'Saddle = 507.100006 pos = 35.8209,136.3137 diff = 266.899994'
});
data_peak.push({
lat: 3.5830555556e+01,
lng: 1.3630177778e+02,
cert : true,
content:'Name = JA/FI-045(JA/FI-045) peak = 727.700012 pos = 35.8306,136.3018 diff = 220.300018'
});
data_saddle.push({
lat: 3.5824666667e+01,
lng: 1.3629644444e+02,
content:'Saddle = 507.399994 pos = 35.8247,136.2964 diff = 220.300018'
});
data_peak.push({
lat: 3.5849666667e+01,
lng: 1.3623511111e+02,
cert : false,
content:' Peak = 712.200012 pos = 35.8497,136.2351 diff = 150.200012'
});
data_saddle.push({
lat: 3.5847111111e+01,
lng: 1.3623922222e+02,
content:'Saddle = 562.000000 pos = 35.8471,136.2392 diff = 150.200012'
});
data_peak.push({
lat: 3.5857333333e+01,
lng: 1.3627255556e+02,
cert : true,
content:'Name = JA/FI-043(JA/FI-043) peak = 735.700012 pos = 35.8573,136.2726 diff = 164.799988'
});
data_saddle.push({
lat: 3.5850222222e+01,
lng: 1.3626644444e+02,
content:'Saddle = 570.900024 pos = 35.8502,136.2664 diff = 164.799988'
});
data_peak.push({
lat: 3.5615888889e+01,
lng: 1.3678855556e+02,
cert : false,
content:' Peak = 671.200012 pos = 35.6159,136.7886 diff = 151.500000'
});
data_saddle.push({
lat: 3.5625777778e+01,
lng: 1.3677677778e+02,
content:'Saddle = 519.700012 pos = 35.6258,136.7768 diff = 151.500000'
});
data_peak.push({
lat: 3.5721333333e+01,
lng: 1.3613388889e+02,
cert : true,
content:'Name = JA/FI-040(JA/FI-040) peak = 761.200012 pos = 35.7213,136.1339 diff = 223.900024'
});
data_saddle.push({
lat: 3.5698444445e+01,
lng: 1.3615944444e+02,
content:'Saddle = 537.299988 pos = 35.6984,136.1594 diff = 223.900024'
});
data_peak.push({
lat: 3.5694444445e+01,
lng: 1.3615000000e+02,
cert : false,
content:' Peak = 751.299988 pos = 35.6944,136.1500 diff = 158.700012'
});
data_saddle.push({
lat: 3.5709000000e+01,
lng: 1.3614855556e+02,
content:'Saddle = 592.599976 pos = 35.7090,136.1486 diff = 158.700012'
});
data_peak.push({
lat: 3.5441111111e+01,
lng: 1.3651688889e+02,
cert : true,
content:'Name = JA/GF-136(JA/GF-136) peak = 923.299988 pos = 35.4411,136.5169 diff = 381.299988'
});
data_saddle.push({
lat: 3.5415888889e+01,
lng: 1.3647877778e+02,
content:'Saddle = 542.000000 pos = 35.4159,136.4788 diff = 381.299988'
});
data_peak.push({
lat: 3.5436444445e+01,
lng: 1.3646522222e+02,
cert : true,
content:'Name = JA/GF-137(JA/GF-137) peak = 918.599976 pos = 35.4364,136.4652 diff = 241.399963'
});
data_saddle.push({
lat: 3.5431666667e+01,
lng: 1.3650488889e+02,
content:'Saddle = 677.200012 pos = 35.4317,136.5049 diff = 241.399963'
});
data_peak.push({
lat: 3.5915666667e+01,
lng: 1.3639766667e+02,
cert : false,
content:' Peak = 711.200012 pos = 35.9157,136.3977 diff = 168.100037'
});
data_saddle.push({
lat: 3.5906444444e+01,
lng: 1.3639800000e+02,
content:'Saddle = 543.099976 pos = 35.9064,136.3980 diff = 168.100037'
});
data_peak.push({
lat: 3.5824000000e+01,
lng: 1.3632533333e+02,
cert : true,
content:'Name = JA/FI-044(JA/FI-044) peak = 734.000000 pos = 35.8240,136.3253 diff = 186.599976'
});
data_saddle.push({
lat: 3.5813111111e+01,
lng: 1.3634933333e+02,
content:'Saddle = 547.400024 pos = 35.8131,136.3493 diff = 186.599976'
});
data_peak.push({
lat: 3.5413555556e+01,
lng: 1.3646000000e+02,
cert : true,
content:'Name = JA/GF-159(JA/GF-159) peak = 795.700012 pos = 35.4136,136.4600 diff = 232.900024'
});
data_saddle.push({
lat: 3.5399888889e+01,
lng: 1.3646366667e+02,
content:'Saddle = 562.799988 pos = 35.3999,136.4637 diff = 232.900024'
});
data_peak.push({
lat: 3.5761444445e+01,
lng: 1.3625155556e+02,
cert : true,
content:'Name = JA/FI-039(JA/FI-039) peak = 761.500000 pos = 35.7614,136.2516 diff = 190.700012'
});
data_saddle.push({
lat: 3.5764000000e+01,
lng: 1.3626588889e+02,
content:'Saddle = 570.799988 pos = 35.7640,136.2659 diff = 190.700012'
});
data_peak.push({
lat: 3.5707555556e+01,
lng: 1.3692677778e+02,
cert : false,
content:' Peak = 734.200012 pos = 35.7076,136.9268 diff = 162.600037'
});
data_saddle.push({
lat: 3.5699333333e+01,
lng: 1.3691800000e+02,
content:'Saddle = 571.599976 pos = 35.6993,136.9180 diff = 162.600037'
});
data_peak.push({
lat: 3.5735000000e+01,
lng: 1.3658933333e+02,
cert : true,
content:'Name = JA/GF-149(JA/GF-149) peak = 874.500000 pos = 35.7350,136.5893 diff = 285.799988'
});
data_saddle.push({
lat: 3.5746333333e+01,
lng: 1.3658844444e+02,
content:'Saddle = 588.700012 pos = 35.7463,136.5884 diff = 285.799988'
});
data_peak.push({
lat: 3.5967000000e+01,
lng: 1.3645711111e+02,
cert : true,
content:'Name = JA/FI-030(JA/FI-030) peak = 883.700012 pos = 35.9670,136.4571 diff = 272.200012'
});
data_saddle.push({
lat: 3.5943666667e+01,
lng: 1.3646177778e+02,
content:'Saddle = 611.500000 pos = 35.9437,136.4618 diff = 272.200012'
});
data_peak.push({
lat: 3.5620111111e+01,
lng: 1.3651922222e+02,
cert : true,
content:'Name = JA/GF-094(JA/GF-094) peak = 1181.699951 pos = 35.6201,136.5192 diff = 560.299927'
});
data_saddle.push({
lat: 3.5678333333e+01,
lng: 1.3651800000e+02,
content:'Saddle = 621.400024 pos = 35.6783,136.5180 diff = 560.299927'
});
data_peak.push({
lat: 3.5596777778e+01,
lng: 1.3659855556e+02,
cert : false,
content:' Peak = 940.700012 pos = 35.5968,136.5986 diff = 179.400024'
});
data_saddle.push({
lat: 3.5580222222e+01,
lng: 1.3657833333e+02,
content:'Saddle = 761.299988 pos = 35.5802,136.5783 diff = 179.400024'
});
data_peak.push({
lat: 3.5638666667e+01,
lng: 1.3654622222e+02,
cert : false,
content:' Peak = 1170.199951 pos = 35.6387,136.5462 diff = 307.299927'
});
data_saddle.push({
lat: 3.5631000000e+01,
lng: 1.3653644444e+02,
content:'Saddle = 862.900024 pos = 35.6310,136.5364 diff = 307.299927'
});
data_peak.push({
lat: 3.5599333333e+01,
lng: 1.3656188889e+02,
cert : false,
content:' Peak = 1065.599976 pos = 35.5993,136.5619 diff = 156.799988'
});
data_saddle.push({
lat: 3.5616888889e+01,
lng: 1.3656011111e+02,
content:'Saddle = 908.799988 pos = 35.6169,136.5601 diff = 156.799988'
});
data_peak.push({
lat: 3.5597555556e+01,
lng: 1.3649433333e+02,
cert : true,
content:'Name = JA/GF-098(JA/GF-098) peak = 1156.900024 pos = 35.5976,136.4943 diff = 274.000000'
});
data_saddle.push({
lat: 3.5607222222e+01,
lng: 1.3650811111e+02,
content:'Saddle = 882.900024 pos = 35.6072,136.5081 diff = 274.000000'
});
data_peak.push({
lat: 3.5722666667e+01,
lng: 1.3681477778e+02,
cert : false,
content:' Peak = 792.200012 pos = 35.7227,136.8148 diff = 170.500000'
});
data_saddle.push({
lat: 3.5729888889e+01,
lng: 1.3681977778e+02,
content:'Saddle = 621.700012 pos = 35.7299,136.8198 diff = 170.500000'
});
data_peak.push({
lat: 3.5645666667e+01,
lng: 1.3675733333e+02,
cert : true,
content:'Name = JA/GF-147(JA/GF-147) peak = 880.700012 pos = 35.6457,136.7573 diff = 249.100037'
});
data_saddle.push({
lat: 3.5653666667e+01,
lng: 1.3675711111e+02,
content:'Saddle = 631.599976 pos = 35.6537,136.7571 diff = 249.100037'
});
data_peak.push({
lat: 3.5446222222e+01,
lng: 1.3638755556e+02,
cert : true,
content:'Name = JA/SI-024(JA/SI-024) peak = 861.599976 pos = 35.4462,136.3876 diff = 219.699951'
});
data_saddle.push({
lat: 3.5449222222e+01,
lng: 1.3640888889e+02,
content:'Saddle = 641.900024 pos = 35.4492,136.4089 diff = 219.699951'
});
data_peak.push({
lat: 3.5922888889e+01,
lng: 1.3644622222e+02,
cert : false,
content:' Peak = 809.500000 pos = 35.9229,136.4462 diff = 161.599976'
});
data_saddle.push({
lat: 3.5919222222e+01,
lng: 1.3646055556e+02,
content:'Saddle = 647.900024 pos = 35.9192,136.4606 diff = 161.599976'
});
data_peak.push({
lat: 3.5571222222e+01,
lng: 1.3643622222e+02,
cert : true,
content:'Name = JA/GF-153(JA/GF-153) peak = 824.299988 pos = 35.5712,136.4362 diff = 172.200012'
});
data_saddle.push({
lat: 3.5543666667e+01,
lng: 1.3642544444e+02,
content:'Saddle = 652.099976 pos = 35.5437,136.4254 diff = 172.200012'
});
data_peak.push({
lat: 3.5840666667e+01,
lng: 1.3653466667e+02,
cert : true,
content:'Name = JA/FI-027(JA/FI-027) peak = 928.400024 pos = 35.8407,136.5347 diff = 274.800049'
});
data_saddle.push({
lat: 3.5834000000e+01,
lng: 1.3652844444e+02,
content:'Saddle = 653.599976 pos = 35.8340,136.5284 diff = 274.800049'
});
data_peak.push({
lat: 3.5679000000e+01,
lng: 1.3676944444e+02,
cert : true,
content:'Name = JA/GF-109(JA/GF-109) peak = 1105.099976 pos = 35.6790,136.7694 diff = 445.799988'
});
data_saddle.push({
lat: 3.5683555556e+01,
lng: 1.3674755556e+02,
content:'Saddle = 659.299988 pos = 35.6836,136.7476 diff = 445.799988'
});
data_peak.push({
lat: 3.5668444445e+01,
lng: 1.3677922222e+02,
cert : false,
content:' Peak = 1086.599976 pos = 35.6684,136.7792 diff = 195.000000'
});
data_saddle.push({
lat: 3.5671111111e+01,
lng: 1.3677111111e+02,
content:'Saddle = 891.599976 pos = 35.6711,136.7711 diff = 195.000000'
});
data_peak.push({
lat: 3.5501666667e+01,
lng: 1.3649922222e+02,
cert : true,
content:'Name = JA/GF-139(JA/GF-139) peak = 912.099976 pos = 35.5017,136.4992 diff = 249.399963'
});
data_saddle.push({
lat: 3.5514000000e+01,
lng: 1.3648722222e+02,
content:'Saddle = 662.700012 pos = 35.5140,136.4872 diff = 249.399963'
});
data_peak.push({
lat: 3.5671888889e+01,
lng: 1.3685922222e+02,
cert : true,
content:'Name = Kougasan(JA/GF-087) peak = 1223.300049 pos = 35.6719,136.8592 diff = 554.700073'
});
data_saddle.push({
lat: 3.5710333333e+01,
lng: 1.3684466667e+02,
content:'Saddle = 668.599976 pos = 35.7103,136.8447 diff = 554.700073'
});
data_peak.push({
lat: 3.5669111111e+01,
lng: 1.3684266667e+02,
cert : true,
content:'Name = JA/GF-120(JA/GF-120) peak = 1053.099976 pos = 35.6691,136.8427 diff = 195.599976'
});
data_saddle.push({
lat: 3.5670666667e+01,
lng: 1.3684788889e+02,
content:'Saddle = 857.500000 pos = 35.6707,136.8479 diff = 195.599976'
});
data_peak.push({
lat: 3.5632111111e+01,
lng: 1.3687788889e+02,
cert : true,
content:'Name = JA/GF-122(JA/GF-122) peak = 1047.099976 pos = 35.6321,136.8779 diff = 171.799988'
});
data_saddle.push({
lat: 3.5648555556e+01,
lng: 1.3687077778e+02,
content:'Saddle = 875.299988 pos = 35.6486,136.8708 diff = 171.799988'
});
data_peak.push({
lat: 3.5818000000e+01,
lng: 1.3699988889e+02,
cert : false,
content:' Peak = 870.599976 pos = 35.8180,136.9999 diff = 200.199951'
});
data_saddle.push({
lat: 3.5831000000e+01,
lng: 1.3699988889e+02,
content:'Saddle = 670.400024 pos = 35.8310,136.9999 diff = 200.199951'
});
data_peak.push({
lat: 3.5754111111e+01,
lng: 1.3691233333e+02,
cert : false,
content:' Peak = 831.000000 pos = 35.7541,136.9123 diff = 158.799988'
});
data_saddle.push({
lat: 3.5761777778e+01,
lng: 1.3690488889e+02,
content:'Saddle = 672.200012 pos = 35.7618,136.9049 diff = 158.799988'
});
data_peak.push({
lat: 3.5929333333e+01,
lng: 1.3685488889e+02,
cert : true,
content:'Name = JA/GF-138(JA/GF-138) peak = 916.599976 pos = 35.9293,136.8549 diff = 238.799988'
});
data_saddle.push({
lat: 3.5915555556e+01,
lng: 1.3686100000e+02,
content:'Saddle = 677.799988 pos = 35.9156,136.8610 diff = 238.799988'
});
data_peak.push({
lat: 3.5736555556e+01,
lng: 1.3679944444e+02,
cert : false,
content:' Peak = 1062.599976 pos = 35.7366,136.7994 diff = 356.099976'
});
data_saddle.push({
lat: 3.5758666667e+01,
lng: 1.3681633333e+02,
content:'Saddle = 706.500000 pos = 35.7587,136.8163 diff = 356.099976'
});
data_peak.push({
lat: 3.5890444444e+01,
lng: 1.3666688889e+02,
cert : true,
content:'Name = JA/FI-025(JA/FI-025) peak = 1010.299988 pos = 35.8904,136.6669 diff = 297.599976'
});
data_saddle.push({
lat: 3.5879000000e+01,
lng: 1.3664644444e+02,
content:'Saddle = 712.700012 pos = 35.8790,136.6464 diff = 297.599976'
});
data_peak.push({
lat: 3.5992777778e+01,
lng: 1.3672211111e+02,
cert : true,
content:'Name = JA/FI-003(JA/FI-003) peak = 1601.099976 pos = 35.9928,136.7221 diff = 875.500000'
});
data_saddle.push({
lat: 3.6000000000e+01,
lng: 1.3676766667e+02,
content:'Saddle = 725.599976 pos = 36.0000,136.7677 diff = 875.500000'
});
data_peak.push({
lat: 3.5957000000e+01,
lng: 1.3666844444e+02,
cert : true,
content:'Name = JA/FI-010(JA/FI-010) peak = 1327.400024 pos = 35.9570,136.6684 diff = 356.400024'
});
data_saddle.push({
lat: 3.5966777778e+01,
lng: 1.3669622222e+02,
content:'Saddle = 971.000000 pos = 35.9668,136.6962 diff = 356.400024'
});
data_peak.push({
lat: 3.5731333333e+01,
lng: 1.3675588889e+02,
cert : true,
content:'Name = JA/GF-133(JA/GF-133) peak = 951.400024 pos = 35.7313,136.7559 diff = 224.800049'
});
data_saddle.push({
lat: 3.5720444445e+01,
lng: 1.3674822222e+02,
content:'Saddle = 726.599976 pos = 35.7204,136.7482 diff = 224.800049'
});
data_peak.push({
lat: 3.5679666667e+01,
lng: 1.3659488889e+02,
cert : false,
content:' Peak = 926.400024 pos = 35.6797,136.5949 diff = 199.400024'
});
data_saddle.push({
lat: 3.5684111111e+01,
lng: 1.3660144444e+02,
content:'Saddle = 727.000000 pos = 35.6841,136.6014 diff = 199.400024'
});
data_peak.push({
lat: 3.5698333333e+01,
lng: 1.3674311111e+02,
cert : true,
content:'Name = JA/GF-124(JA/GF-124) peak = 1032.300049 pos = 35.6983,136.7431 diff = 305.200073'
});
data_saddle.push({
lat: 3.5694444445e+01,
lng: 1.3672366667e+02,
content:'Saddle = 727.099976 pos = 35.6944,136.7237 diff = 305.200073'
});
data_peak.push({
lat: 3.5417888889e+01,
lng: 1.3640622222e+02,
cert : true,
content:'Name = Ibukiyama(JA/SI-001) peak = 1376.900024 pos = 35.4179,136.4062 diff = 649.000000'
});
data_saddle.push({
lat: 3.5595888889e+01,
lng: 1.3632133333e+02,
content:'Saddle = 727.900024 pos = 35.5959,136.3213 diff = 649.000000'
});
data_peak.push({
lat: 3.5521000000e+01,
lng: 1.3647166667e+02,
cert : false,
content:' Peak = 1054.300049 pos = 35.5210,136.4717 diff = 321.100037'
});
data_saddle.push({
lat: 3.5526555556e+01,
lng: 1.3646022222e+02,
content:'Saddle = 733.200012 pos = 35.5266,136.4602 diff = 321.100037'
});
data_peak.push({
lat: 3.5550222222e+01,
lng: 1.3633711111e+02,
cert : true,
content:'Name = Kanakusodake(JA/GF-072) peak = 1316.500000 pos = 35.5502,136.3371 diff = 470.099976'
});
data_saddle.push({
lat: 3.5467333334e+01,
lng: 1.3641322222e+02,
content:'Saddle = 846.400024 pos = 35.4673,136.4132 diff = 470.099976'
});
data_peak.push({
lat: 3.5507222222e+01,
lng: 1.3639655556e+02,
cert : true,
content:'Name = JA/GF-081(JA/GF-081) peak = 1258.900024 pos = 35.5072,136.3966 diff = 360.900024'
});
data_saddle.push({
lat: 3.5550000000e+01,
lng: 1.3636044444e+02,
content:'Saddle = 898.000000 pos = 35.5500,136.3604 diff = 360.900024'
});
data_peak.push({
lat: 3.5471666667e+01,
lng: 1.3640155556e+02,
cert : false,
content:' Peak = 1183.800049 pos = 35.4717,136.4016 diff = 172.200073'
});
data_saddle.push({
lat: 3.5482777778e+01,
lng: 1.3639511111e+02,
content:'Saddle = 1011.599976 pos = 35.4828,136.3951 diff = 172.200073'
});
data_peak.push({
lat: 3.5518000000e+01,
lng: 1.3642200000e+02,
cert : true,
content:'Name = JA/GF-084(JA/GF-084) peak = 1233.400024 pos = 35.5180,136.4220 diff = 205.099976'
});
data_saddle.push({
lat: 3.5516222222e+01,
lng: 1.3641400000e+02,
content:'Saddle = 1028.300049 pos = 35.5162,136.4140 diff = 205.099976'
});
data_peak.push({
lat: 3.5461777778e+01,
lng: 1.3642111111e+02,
cert : true,
content:'Name = JA/GF-108(JA/GF-108) peak = 1125.599976 pos = 35.4618,136.4211 diff = 184.399963'
});
data_saddle.push({
lat: 3.5437222222e+01,
lng: 1.3642088889e+02,
content:'Saddle = 941.200012 pos = 35.4372,136.4209 diff = 184.399963'
});
data_peak.push({
lat: 3.5706777778e+01,
lng: 1.3663400000e+02,
cert : true,
content:'Name = JA/GF-085(JA/GF-085) peak = 1233.800049 pos = 35.7068,136.6340 diff = 475.700073'
});
data_saddle.push({
lat: 3.5724666667e+01,
lng: 1.3664055556e+02,
content:'Saddle = 758.099976 pos = 35.7247,136.6406 diff = 475.700073'
});
data_peak.push({
lat: 3.5675222222e+01,
lng: 1.3661855556e+02,
cert : true,
content:'Name = JA/GF-121(JA/GF-121) peak = 1044.599976 pos = 35.6752,136.6186 diff = 252.500000'
});
data_saddle.push({
lat: 3.5688000000e+01,
lng: 1.3662922222e+02,
content:'Saddle = 792.099976 pos = 35.6880,136.6292 diff = 252.500000'
});
data_peak.push({
lat: 3.5934333333e+01,
lng: 1.3660122222e+02,
cert : true,
content:'Name = Arashimadake(JA/FI-005) peak = 1523.199951 pos = 35.9343,136.6012 diff = 750.799927'
});
data_saddle.push({
lat: 3.5836555556e+01,
lng: 1.3662611111e+02,
content:'Saddle = 772.400024 pos = 35.8366,136.6261 diff = 750.799927'
});
data_peak.push({
lat: 3.5848555556e+01,
lng: 1.3662411111e+02,
cert : false,
content:' Peak = 1284.599976 pos = 35.8486,136.6241 diff = 377.000000'
});
data_saddle.push({
lat: 3.5895000000e+01,
lng: 1.3657366667e+02,
content:'Saddle = 907.599976 pos = 35.8950,136.5737 diff = 377.000000'
});
data_peak.push({
lat: 3.5878444444e+01,
lng: 1.3653655556e+02,
cert : true,
content:'Name = JA/FI-021(JA/FI-021) peak = 1187.599976 pos = 35.8784,136.5366 diff = 235.099976'
});
data_saddle.push({
lat: 3.5866000000e+01,
lng: 1.3655522222e+02,
content:'Saddle = 952.500000 pos = 35.8660,136.5552 diff = 235.099976'
});
data_peak.push({
lat: 3.5866444444e+01,
lng: 1.3656566667e+02,
cert : true,
content:'Name = JA/FI-017(JA/FI-017) peak = 1204.099976 pos = 35.8664,136.5657 diff = 250.799988'
});
data_saddle.push({
lat: 3.5858777778e+01,
lng: 1.3657588889e+02,
content:'Saddle = 953.299988 pos = 35.8588,136.5759 diff = 250.799988'
});
data_peak.push({
lat: 3.5865666667e+01,
lng: 1.3665300000e+02,
cert : true,
content:'Name = JA/FI-020(JA/FI-020) peak = 1182.000000 pos = 35.8657,136.6530 diff = 179.299988'
});
data_saddle.push({
lat: 3.5861000000e+01,
lng: 1.3663944444e+02,
content:'Saddle = 1002.700012 pos = 35.8610,136.6394 diff = 179.299988'
});
data_peak.push({
lat: 3.5903333333e+01,
lng: 1.3658688889e+02,
cert : true,
content:'Name = JA/FI-011(JA/FI-011) peak = 1314.000000 pos = 35.9033,136.5869 diff = 174.199951'
});
data_saddle.push({
lat: 3.5919888889e+01,
lng: 1.3658766667e+02,
content:'Saddle = 1139.800049 pos = 35.9199,136.5877 diff = 174.199951'
});
data_peak.push({
lat: 3.5762444445e+01,
lng: 1.3651400000e+02,
cert : true,
content:'Name = Nougouhakusan (Gongensan)(JA/GF-031) peak = 1617.099976 pos = 35.7624,136.5140 diff = 839.399963'
});
data_saddle.push({
lat: 3.5869111111e+01,
lng: 1.3682744444e+02,
content:'Saddle = 777.700012 pos = 35.8691,136.8274 diff = 839.399963'
});
data_peak.push({
lat: 3.5648333333e+01,
lng: 1.3640277778e+02,
cert : true,
content:'Name = JA/GF-075(JA/GF-075) peak = 1291.199951 pos = 35.6483,136.4028 diff = 498.199951'
});
data_saddle.push({
lat: 3.5639777778e+01,
lng: 1.3637400000e+02,
content:'Saddle = 793.000000 pos = 35.6398,136.3740 diff = 498.199951'
});
data_peak.push({
lat: 3.5614777778e+01,
lng: 1.3638355556e+02,
cert : true,
content:'Name = JA/GF-113(JA/GF-113) peak = 1078.099976 pos = 35.6148,136.3836 diff = 177.299988'
});
data_saddle.push({
lat: 3.5632111111e+01,
lng: 1.3638133333e+02,
content:'Saddle = 900.799988 pos = 35.6321,136.3813 diff = 177.299988'
});
data_peak.push({
lat: 3.5635888889e+01,
lng: 1.3642666667e+02,
cert : true,
content:'Name = JA/GF-093(JA/GF-093) peak = 1191.800049 pos = 35.6359,136.4267 diff = 189.300049'
});
data_saddle.push({
lat: 3.5652222222e+01,
lng: 1.3642066667e+02,
content:'Saddle = 1002.500000 pos = 35.6522,136.4207 diff = 189.300049'
});
data_peak.push({
lat: 3.5750555556e+01,
lng: 1.3686055556e+02,
cert : true,
content:'Name = JA/GF-105(JA/GF-105) peak = 1131.699951 pos = 35.7506,136.8606 diff = 326.199951'
});
data_saddle.push({
lat: 3.5777111111e+01,
lng: 1.3683633333e+02,
content:'Saddle = 805.500000 pos = 35.7771,136.8363 diff = 326.199951'
});
data_peak.push({
lat: 3.5767888889e+01,
lng: 1.3684466667e+02,
cert : false,
content:' Peak = 993.599976 pos = 35.7679,136.8447 diff = 156.199951'
});
data_saddle.push({
lat: 3.5765888889e+01,
lng: 1.3683788889e+02,
content:'Saddle = 837.400024 pos = 35.7659,136.8379 diff = 156.199951'
});
data_peak.push({
lat: 3.5756888889e+01,
lng: 1.3635355556e+02,
cert : true,
content:'Name = JA/GF-096(JA/GF-096) peak = 1174.199951 pos = 35.7569,136.3536 diff = 366.999939'
});
data_saddle.push({
lat: 3.5766333333e+01,
lng: 1.3634411111e+02,
content:'Saddle = 807.200012 pos = 35.7663,136.3441 diff = 366.999939'
});
data_peak.push({
lat: 3.5795444445e+01,
lng: 1.3686533333e+02,
cert : true,
content:'Name = JA/GF-118(JA/GF-118) peak = 1051.900024 pos = 35.7954,136.8653 diff = 200.700012'
});
data_saddle.push({
lat: 3.5805666667e+01,
lng: 1.3686511111e+02,
content:'Saddle = 851.200012 pos = 35.8057,136.8651 diff = 200.700012'
});
data_peak.push({
lat: 3.5886222222e+01,
lng: 1.3643922222e+02,
cert : true,
content:'Name = Hekosan(JA/FI-006) peak = 1462.800049 pos = 35.8862,136.4392 diff = 610.200073'
});
data_saddle.push({
lat: 3.5818777778e+01,
lng: 1.3642255556e+02,
content:'Saddle = 852.599976 pos = 35.8188,136.4226 diff = 610.200073'
});
data_peak.push({
lat: 3.5849888889e+01,
lng: 1.3643644444e+02,
cert : true,
content:'Name = JA/FI-016(JA/FI-016) peak = 1217.500000 pos = 35.8499,136.4364 diff = 260.700012'
});
data_saddle.push({
lat: 3.5862444444e+01,
lng: 1.3642944444e+02,
content:'Saddle = 956.799988 pos = 35.8624,136.4294 diff = 260.700012'
});
data_peak.push({
lat: 3.5837555556e+01,
lng: 1.3642322222e+02,
cert : false,
content:' Peak = 1182.000000 pos = 35.8376,136.4232 diff = 180.200012'
});
data_saddle.push({
lat: 3.5841666667e+01,
lng: 1.3642933333e+02,
content:'Saddle = 1001.799988 pos = 35.8417,136.4293 diff = 180.200012'
});
data_peak.push({
lat: 3.5886555556e+01,
lng: 1.3646477778e+02,
cert : true,
content:'Name = JA/FI-009(JA/FI-009) peak = 1440.599976 pos = 35.8866,136.4648 diff = 183.400024'
});
data_saddle.push({
lat: 3.5891222222e+01,
lng: 1.3644355556e+02,
content:'Saddle = 1257.199951 pos = 35.8912,136.4436 diff = 183.400024'
});
data_peak.push({
lat: 3.5625000000e+01,
lng: 1.3631733333e+02,
cert : false,
content:' Peak = 1075.199951 pos = 35.6250,136.3173 diff = 207.399963'
});
data_saddle.push({
lat: 3.5617444445e+01,
lng: 1.3629788889e+02,
content:'Saddle = 867.799988 pos = 35.6174,136.2979 diff = 207.399963'
});
data_peak.push({
lat: 3.5658333333e+01,
lng: 1.3668144444e+02,
cert : true,
content:'Name = JA/GF-123(JA/GF-123) peak = 1040.199951 pos = 35.6583,136.6814 diff = 158.399963'
});
data_saddle.push({
lat: 3.5669444445e+01,
lng: 1.3669155556e+02,
content:'Saddle = 881.799988 pos = 35.6694,136.6916 diff = 158.399963'
});
data_peak.push({
lat: 3.5649444445e+01,
lng: 1.3635855556e+02,
cert : false,
content:' Peak = 1094.400024 pos = 35.6494,136.3586 diff = 207.000000'
});
data_saddle.push({
lat: 3.5658444445e+01,
lng: 1.3635033333e+02,
content:'Saddle = 887.400024 pos = 35.6584,136.3503 diff = 207.000000'
});
data_peak.push({
lat: 3.5600888889e+01,
lng: 1.3627000000e+02,
cert : false,
content:' Peak = 1133.800049 pos = 35.6009,136.2700 diff = 231.300049'
});
data_saddle.push({
lat: 3.5615111111e+01,
lng: 1.3629077778e+02,
content:'Saddle = 902.500000 pos = 35.6151,136.2908 diff = 231.300049'
});
data_peak.push({
lat: 3.5672333333e+01,
lng: 1.3631677778e+02,
cert : true,
content:'Name = JA/GF-073(JA/GF-073) peak = 1315.500000 pos = 35.6723,136.3168 diff = 411.900024'
});
data_saddle.push({
lat: 3.5794666667e+01,
lng: 1.3637877778e+02,
content:'Saddle = 903.599976 pos = 35.7947,136.3788 diff = 411.900024'
});
data_peak.push({
lat: 3.5787000000e+01,
lng: 1.3636011111e+02,
cert : true,
content:'Name = JA/GF-086(JA/GF-086) peak = 1225.500000 pos = 35.7870,136.3601 diff = 303.000000'
});
data_saddle.push({
lat: 3.5752888889e+01,
lng: 1.3631922222e+02,
content:'Saddle = 922.500000 pos = 35.7529,136.3192 diff = 303.000000'
});
data_peak.push({
lat: 3.5673666667e+01,
lng: 1.3624466667e+02,
cert : true,
content:'Name = JA/SI-005(JA/SI-005) peak = 1195.699951 pos = 35.6737,136.2447 diff = 258.199951'
});
data_saddle.push({
lat: 3.5666666667e+01,
lng: 1.3627088889e+02,
content:'Saddle = 937.500000 pos = 35.6667,136.2709 diff = 258.199951'
});
data_peak.push({
lat: 3.5722666667e+01,
lng: 1.3632044444e+02,
cert : false,
content:' Peak = 1293.000000 pos = 35.7227,136.3204 diff = 260.900024'
});
data_saddle.push({
lat: 3.5695666667e+01,
lng: 1.3630066667e+02,
content:'Saddle = 1032.099976 pos = 35.6957,136.3007 diff = 260.900024'
});
data_peak.push({
lat: 3.5723666667e+01,
lng: 1.3637166667e+02,
cert : true,
content:'Name = JA/GF-083(JA/GF-083) peak = 1244.099976 pos = 35.7237,136.3717 diff = 157.199951'
});
data_saddle.push({
lat: 3.5724777778e+01,
lng: 1.3634033333e+02,
content:'Saddle = 1086.900024 pos = 35.7248,136.3403 diff = 157.199951'
});
data_peak.push({
lat: 3.5683777778e+01,
lng: 1.3630011111e+02,
cert : true,
content:'Name = Sanshyuugatake(JA/GF-077) peak = 1291.099976 pos = 35.6838,136.3001 diff = 182.799927'
});
data_saddle.push({
lat: 3.5674555556e+01,
lng: 1.3630822222e+02,
content:'Saddle = 1108.300049 pos = 35.6746,136.3082 diff = 182.799927'
});
data_peak.push({
lat: 3.5853666667e+01,
lng: 1.3679955556e+02,
cert : true,
content:'Name = JA/FI-019(JA/FI-019) peak = 1191.800049 pos = 35.8537,136.7996 diff = 269.800049'
});
data_saddle.push({
lat: 3.5813666667e+01,
lng: 1.3679655556e+02,
content:'Saddle = 922.000000 pos = 35.8137,136.7966 diff = 269.800049'
});
data_peak.push({
lat: 3.5850222222e+01,
lng: 1.3682733333e+02,
cert : false,
content:' Peak = 1114.900024 pos = 35.8502,136.8273 diff = 153.400024'
});
data_saddle.push({
lat: 3.5842888889e+01,
lng: 1.3681644444e+02,
content:'Saddle = 961.500000 pos = 35.8429,136.8164 diff = 153.400024'
});
data_peak.push({
lat: 3.5839444445e+01,
lng: 1.3674622222e+02,
cert : true,
content:'Name = JA/FI-015(JA/FI-015) peak = 1246.000000 pos = 35.8394,136.7462 diff = 319.400024'
});
data_saddle.push({
lat: 3.5825888889e+01,
lng: 1.3673911111e+02,
content:'Saddle = 926.599976 pos = 35.8259,136.7391 diff = 319.400024'
});
data_peak.push({
lat: 3.5801111111e+01,
lng: 1.3674066667e+02,
cert : true,
content:'Name = JA/GF-044(JA/GF-044) peak = 1449.500000 pos = 35.8011,136.7407 diff = 506.799988'
});
data_saddle.push({
lat: 3.5793000000e+01,
lng: 1.3660588889e+02,
content:'Saddle = 942.700012 pos = 35.7930,136.6059 diff = 506.799988'
});
data_peak.push({
lat: 3.5821555556e+01,
lng: 1.3663011111e+02,
cert : true,
content:'Name = JA/FI-022(JA/FI-022) peak = 1180.300049 pos = 35.8216,136.6301 diff = 233.300049'
});
data_saddle.push({
lat: 3.5816111111e+01,
lng: 1.3663677778e+02,
content:'Saddle = 947.000000 pos = 35.8161,136.6368 diff = 233.300049'
});
data_peak.push({
lat: 3.5752000000e+01,
lng: 1.3669566667e+02,
cert : true,
content:'Name = JA/GF-069(JA/GF-069) peak = 1330.500000 pos = 35.7520,136.6957 diff = 353.900024'
});
data_saddle.push({
lat: 3.5763333333e+01,
lng: 1.3668433333e+02,
content:'Saddle = 976.599976 pos = 35.7633,136.6843 diff = 353.900024'
});
data_peak.push({
lat: 3.5720222222e+01,
lng: 1.3670266667e+02,
cert : true,
content:'Name = JA/GF-090(JA/GF-090) peak = 1214.099976 pos = 35.7202,136.7027 diff = 201.599976'
});
data_saddle.push({
lat: 3.5721222222e+01,
lng: 1.3668988889e+02,
content:'Saddle = 1012.500000 pos = 35.7212,136.6899 diff = 201.599976'
});
data_peak.push({
lat: 3.5731444445e+01,
lng: 1.3668644444e+02,
cert : false,
content:' Peak = 1181.500000 pos = 35.7314,136.6864 diff = 163.900024'
});
data_saddle.push({
lat: 3.5736000000e+01,
lng: 1.3668811111e+02,
content:'Saddle = 1017.599976 pos = 35.7360,136.6881 diff = 163.900024'
});
data_peak.push({
lat: 3.5796888889e+01,
lng: 1.3662655556e+02,
cert : true,
content:'Name = Byoubuzan(JA/GF-064) peak = 1353.099976 pos = 35.7969,136.6266 diff = 370.000000'
});
data_saddle.push({
lat: 3.5803777778e+01,
lng: 1.3664855556e+02,
content:'Saddle = 983.099976 pos = 35.8038,136.6486 diff = 370.000000'
});
data_peak.push({
lat: 3.5773444445e+01,
lng: 1.3668500000e+02,
cert : false,
content:' Peak = 1251.099976 pos = 35.7734,136.6850 diff = 214.699951'
});
data_saddle.push({
lat: 3.5789666667e+01,
lng: 1.3668255556e+02,
content:'Saddle = 1036.400024 pos = 35.7897,136.6826 diff = 214.699951'
});
data_peak.push({
lat: 3.5797888889e+01,
lng: 1.3677422222e+02,
cert : true,
content:'Name = JA/GF-050(JA/GF-050) peak = 1411.199951 pos = 35.7979,136.7742 diff = 298.599976'
});
data_saddle.push({
lat: 3.5809666667e+01,
lng: 1.3675711111e+02,
content:'Saddle = 1112.599976 pos = 35.8097,136.7571 diff = 298.599976'
});
data_peak.push({
lat: 3.5809888889e+01,
lng: 1.3671888889e+02,
cert : true,
content:'Name = Heikegadake(JA/FI-008) peak = 1440.800049 pos = 35.8099,136.7189 diff = 238.400024'
});
data_saddle.push({
lat: 3.5807111111e+01,
lng: 1.3673133333e+02,
content:'Saddle = 1202.400024 pos = 35.8071,136.7313 diff = 238.400024'
});
data_peak.push({
lat: 3.5816888889e+01,
lng: 1.3660188889e+02,
cert : true,
content:'Name = JA/FI-018(JA/FI-018) peak = 1200.300049 pos = 35.8169,136.6019 diff = 238.500061'
});
data_saddle.push({
lat: 3.5779666667e+01,
lng: 1.3656577778e+02,
content:'Saddle = 961.799988 pos = 35.7797,136.5658 diff = 238.500061'
});
data_peak.push({
lat: 3.5851000000e+01,
lng: 1.3648922222e+02,
cert : false,
content:' Peak = 1141.400024 pos = 35.8510,136.4892 diff = 159.000000'
});
data_saddle.push({
lat: 3.5837666667e+01,
lng: 1.3649377778e+02,
content:'Saddle = 982.400024 pos = 35.8377,136.4938 diff = 159.000000'
});
data_peak.push({
lat: 3.5809444445e+01,
lng: 1.3650577778e+02,
cert : true,
content:'Name = Ubagatake(JA/FI-007) peak = 1453.199951 pos = 35.8094,136.5058 diff = 430.999939'
});
data_saddle.push({
lat: 3.5779444445e+01,
lng: 1.3651855556e+02,
content:'Saddle = 1022.200012 pos = 35.7794,136.5186 diff = 430.999939'
});
data_peak.push({
lat: 3.5772666667e+01,
lng: 1.3644577778e+02,
cert : false,
content:' Peak = 1284.900024 pos = 35.7727,136.4458 diff = 182.099976'
});
data_saddle.push({
lat: 3.5770555556e+01,
lng: 1.3648988889e+02,
content:'Saddle = 1102.800049 pos = 35.7706,136.4899 diff = 182.099976'
});
data_peak.push({
lat: 3.5776777778e+01,
lng: 1.3648511111e+02,
cert : true,
content:'Name = JA/FI-013(JA/FI-013) peak = 1281.300049 pos = 35.7768,136.4851 diff = 163.300049'
});
data_saddle.push({
lat: 3.5777333333e+01,
lng: 1.3645444444e+02,
content:'Saddle = 1118.000000 pos = 35.7773,136.4544 diff = 163.300049'
});
data_peak.push({
lat: 3.5940333333e+01,
lng: 1.3697155556e+02,
cert : true,
content:'Name = Washigatake(JA/GF-025) peak = 1670.699951 pos = 35.9403,136.9716 diff = 849.199951'
});
data_saddle.push({
lat: 3.6000000000e+01,
lng: 1.3689000000e+02,
content:'Saddle = 821.500000 pos = 36.0000,136.8900 diff = 849.199951'
});
data_peak.push({
lat: 3.5884555556e+01,
lng: 1.3696955556e+02,
cert : false,
content:' Peak = 1342.099976 pos = 35.8846,136.9696 diff = 199.400024'
});
data_saddle.push({
lat: 3.5891666667e+01,
lng: 1.3697277778e+02,
content:'Saddle = 1142.699951 pos = 35.8917,136.9728 diff = 199.400024'
});
data_peak.push({
lat: 3.5981333333e+01,
lng: 1.3696000000e+02,
cert : false,
content:' Peak = 1351.800049 pos = 35.9813,136.9600 diff = 174.700073'
});
data_saddle.push({
lat: 3.5960888889e+01,
lng: 1.3696655556e+02,
content:'Saddle = 1177.099976 pos = 35.9609,136.9666 diff = 174.700073'
});
data_peak.push({
lat: 3.5958222222e+01,
lng: 1.3699988889e+02,
cert : false,
content:' Peak = 1516.599976 pos = 35.9582,136.9999 diff = 166.199951'
});
data_saddle.push({
lat: 3.5950666667e+01,
lng: 1.3699988889e+02,
content:'Saddle = 1350.400024 pos = 35.9507,136.9999 diff = 166.199951'
});
data_peak.push({
lat: 3.5934111111e+01,
lng: 1.3699788889e+02,
cert : false,
content:' Peak = 1624.400024 pos = 35.9341,136.9979 diff = 203.599976'
});
data_saddle.push({
lat: 3.5927000000e+01,
lng: 1.3699055556e+02,
content:'Saddle = 1420.800049 pos = 35.9270,136.9906 diff = 203.599976'
});
data_peak.push({
lat: 3.5939222222e+01,
lng: 1.3679233333e+02,
cert : true,
content:'Name = JA/GF-056(JA/GF-056) peak = 1384.500000 pos = 35.9392,136.7923 diff = 437.099976'
});
data_saddle.push({
lat: 3.5960111111e+01,
lng: 1.3680788889e+02,
content:'Saddle = 947.400024 pos = 35.9601,136.8079 diff = 437.099976'
});
data_peak.push({
lat: 3.5897000000e+01,
lng: 1.3672977778e+02,
cert : true,
content:'Name = JA/FI-023(JA/FI-023) peak = 1160.599976 pos = 35.8970,136.7298 diff = 178.899963'
});
data_saddle.push({
lat: 3.5896333333e+01,
lng: 1.3674522222e+02,
content:'Saddle = 981.700012 pos = 35.8963,136.7452 diff = 178.899963'
});
data_peak.push({
lat: 3.5890888889e+01,
lng: 1.3681111111e+02,
cert : true,
content:'Name = JA/FI-014(JA/FI-014) peak = 1270.000000 pos = 35.8909,136.8111 diff = 206.900024'
});
data_saddle.push({
lat: 3.5913111111e+01,
lng: 1.3680844444e+02,
content:'Saddle = 1063.099976 pos = 35.9131,136.8084 diff = 206.900024'
});
data_peak.push({
lat: 3.5927666667e+01,
lng: 1.3678377778e+02,
cert : true,
content:'Name = JA/GF-063(JA/GF-063) peak = 1358.900024 pos = 35.9277,136.7838 diff = 205.900024'
});
data_saddle.push({
lat: 3.5934222222e+01,
lng: 1.3678755556e+02,
content:'Saddle = 1153.000000 pos = 35.9342,136.7876 diff = 205.900024'
});
data_peak.push({
lat: 3.3862777779e+01,
lng: 1.3586211111e+02,
cert : false,
content:' Peak = 334.600006 pos = 33.8628,135.8621 diff = 152.000000'
});
data_saddle.push({
lat: 3.3859111112e+01,
lng: 1.3587200000e+02,
content:'Saddle = 182.600006 pos = 33.8591,135.8720 diff = 152.000000'
});
data_peak.push({
lat: 3.5348888889e+01,
lng: 1.3638355556e+02,
cert : true,
content:'Name = JA/SI-059(JA/SI-059) peak = 437.899994 pos = 35.3489,136.3836 diff = 251.000000'
});
data_saddle.push({
lat: 3.5333777778e+01,
lng: 1.3638522222e+02,
content:'Saddle = 186.899994 pos = 35.3338,136.3852 diff = 251.000000'
});
data_peak.push({
lat: 3.4376111112e+01,
lng: 1.3539844444e+02,
cert : false,
content:' Peak = 358.000000 pos = 34.3761,135.3984 diff = 170.600006'
});
data_saddle.push({
lat: 3.4368555556e+01,
lng: 1.3540233333e+02,
content:'Saddle = 187.399994 pos = 34.3686,135.4023 diff = 170.600006'
});
data_peak.push({
lat: 3.4049111112e+01,
lng: 1.3529744444e+02,
cert : false,
content:' Peak = 373.000000 pos = 34.0491,135.2974 diff = 185.600006'
});
data_saddle.push({
lat: 3.4058333334e+01,
lng: 1.3530400000e+02,
content:'Saddle = 187.399994 pos = 34.0583,135.3040 diff = 185.600006'
});
data_peak.push({
lat: 3.4301444445e+01,
lng: 1.3523466667e+02,
cert : true,
content:'Name = JA/WK-080(JA/WK-080) peak = 484.200012 pos = 34.3014,135.2347 diff = 296.300018'
});
data_saddle.push({
lat: 3.4293000001e+01,
lng: 1.3527111111e+02,
content:'Saddle = 187.899994 pos = 34.2930,135.2711 diff = 296.300018'
});
data_peak.push({
lat: 3.3679222223e+01,
lng: 1.3557222222e+02,
cert : false,
content:' Peak = 361.899994 pos = 33.6792,135.5722 diff = 173.899994'
});
data_saddle.push({
lat: 3.3675888890e+01,
lng: 1.3556900000e+02,
content:'Saddle = 188.000000 pos = 33.6759,135.5690 diff = 173.899994'
});
data_peak.push({
lat: 3.3534000001e+01,
lng: 1.3570488889e+02,
cert : false,
content:' Peak = 484.200012 pos = 33.5340,135.7049 diff = 291.200012'
});
data_saddle.push({
lat: 3.3525111112e+01,
lng: 1.3565388889e+02,
content:'Saddle = 193.000000 pos = 33.5251,135.6539 diff = 291.200012'
});
data_peak.push({
lat: 3.3833777779e+01,
lng: 1.3533122222e+02,
cert : true,
content:'Name = JA/WK-097(JA/WK-097) peak = 370.299988 pos = 33.8338,135.3312 diff = 176.999985'
});
data_saddle.push({
lat: 3.3854222223e+01,
lng: 1.3532333333e+02,
content:'Saddle = 193.300003 pos = 33.8542,135.3233 diff = 176.999985'
});
data_peak.push({
lat: 3.4785000000e+01,
lng: 1.3617166667e+02,
cert : false,
content:' Peak = 350.000000 pos = 34.7850,136.1717 diff = 156.199997'
});
data_saddle.push({
lat: 3.4788555556e+01,
lng: 1.3619866667e+02,
content:'Saddle = 193.800003 pos = 34.7886,136.1987 diff = 156.199997'
});
data_peak.push({
lat: 3.4419444445e+01,
lng: 1.3567288889e+02,
cert : true,
content:'Name = Kongouzan(JA/NR-029) peak = 1124.000000 pos = 34.4194,135.6729 diff = 926.799988'
});
data_saddle.push({
lat: 3.4392000001e+01,
lng: 1.3571577778e+02,
content:'Saddle = 197.199997 pos = 34.3920,135.7158 diff = 926.799988'
});
data_peak.push({
lat: 3.4318000001e+01,
lng: 1.3528255556e+02,
cert : false,
content:' Peak = 383.500000 pos = 34.3180,135.2826 diff = 165.100006'
});
data_saddle.push({
lat: 3.4303666667e+01,
lng: 1.3530666667e+02,
content:'Saddle = 218.399994 pos = 34.3037,135.3067 diff = 165.100006'
});
data_peak.push({
lat: 3.4525666667e+01,
lng: 1.3567755556e+02,
cert : true,
content:'Name = Nijyousan (Odake)(JA/NR-056) peak = 516.599976 pos = 34.5257,135.6776 diff = 227.299988'
});
data_saddle.push({
lat: 3.4515888889e+01,
lng: 1.3567666667e+02,
content:'Saddle = 289.299988 pos = 34.5159,135.6767 diff = 227.299988'
});
data_peak.push({
lat: 3.4329555556e+01,
lng: 1.3536522222e+02,
cert : true,
content:'Name = JA/WK-066(JA/WK-066) peak = 575.299988 pos = 34.3296,135.3652 diff = 216.399994'
});
data_saddle.push({
lat: 3.4306888890e+01,
lng: 1.3537388889e+02,
content:'Saddle = 358.899994 pos = 34.3069,135.3739 diff = 216.399994'
});
data_peak.push({
lat: 3.4357222223e+01,
lng: 1.3553911111e+02,
cert : true,
content:'Name = JA/WK-021(JA/WK-021) peak = 924.099976 pos = 34.3572,135.5391 diff = 537.399963'
});
data_saddle.push({
lat: 3.4377777778e+01,
lng: 1.3560366667e+02,
content:'Saddle = 386.700012 pos = 34.3778,135.6037 diff = 537.399963'
});
data_peak.push({
lat: 3.4364666667e+01,
lng: 1.3548777778e+02,
cert : true,
content:'Name = Mikuniyama(JA/OS-002) peak = 883.799988 pos = 34.3647,135.4878 diff = 326.299988'
});
data_saddle.push({
lat: 3.4339444445e+01,
lng: 1.3551344444e+02,
content:'Saddle = 557.500000 pos = 34.3394,135.5134 diff = 326.299988'
});
data_peak.push({
lat: 3.4347444445e+01,
lng: 1.3544266667e+02,
cert : true,
content:'Name = JA/WK-028(JA/WK-028) peak = 864.299988 pos = 34.3474,135.4427 diff = 196.500000'
});
data_saddle.push({
lat: 3.4348000001e+01,
lng: 1.3546644444e+02,
content:'Saddle = 667.799988 pos = 34.3480,135.4664 diff = 196.500000'
});
data_peak.push({
lat: 3.4358777778e+01,
lng: 1.3557722222e+02,
cert : false,
content:' Peak = 743.299988 pos = 34.3588,135.5772 diff = 170.000000'
});
data_saddle.push({
lat: 3.4361666667e+01,
lng: 1.3557522222e+02,
content:'Saddle = 573.299988 pos = 34.3617,135.5752 diff = 170.000000'
});
data_peak.push({
lat: 3.4456222223e+01,
lng: 1.3568222222e+02,
cert : true,
content:'Name = Katsuragisan(JA/OS-001) peak = 958.599976 pos = 34.4562,135.6822 diff = 442.000000'
});
data_saddle.push({
lat: 3.4443555556e+01,
lng: 1.3568155556e+02,
content:'Saddle = 516.599976 pos = 34.4436,135.6816 diff = 442.000000'
});
data_peak.push({
lat: 3.3826555556e+01,
lng: 1.3576522222e+02,
cert : false,
content:' Peak = 366.700012 pos = 33.8266,135.7652 diff = 169.200012'
});
data_saddle.push({
lat: 3.3836000001e+01,
lng: 1.3575755556e+02,
content:'Saddle = 197.500000 pos = 33.8360,135.7576 diff = 169.200012'
});
data_peak.push({
lat: 3.3749333334e+01,
lng: 1.3591833333e+02,
cert : true,
content:'Name = JA/WK-087(JA/WK-087) peak = 452.299988 pos = 33.7493,135.9183 diff = 254.599991'
});
data_saddle.push({
lat: 3.3752444445e+01,
lng: 1.3591177778e+02,
content:'Saddle = 197.699997 pos = 33.7524,135.9118 diff = 254.599991'
});
data_peak.push({
lat: 3.3918222223e+01,
lng: 1.3594288889e+02,
cert : true,
content:'Name = JA/ME-085(JA/ME-085) peak = 511.799988 pos = 33.9182,135.9429 diff = 308.799988'
});
data_saddle.push({
lat: 3.3919000001e+01,
lng: 1.3596366667e+02,
content:'Saddle = 203.000000 pos = 33.9190,135.9637 diff = 308.799988'
});
data_peak.push({
lat: 3.3839888890e+01,
lng: 1.3587388889e+02,
cert : true,
content:'Name = JA/ME-089(JA/ME-089) peak = 434.600006 pos = 33.8399,135.8739 diff = 230.900009'
});
data_saddle.push({
lat: 3.3848666668e+01,
lng: 1.3589866667e+02,
content:'Saddle = 203.699997 pos = 33.8487,135.8987 diff = 230.900009'
});
data_peak.push({
lat: 3.3789000001e+01,
lng: 1.3537700000e+02,
cert : false,
content:' Peak = 380.500000 pos = 33.7890,135.3770 diff = 174.000000'
});
data_saddle.push({
lat: 3.3795555556e+01,
lng: 1.3538577778e+02,
content:'Saddle = 206.500000 pos = 33.7956,135.3858 diff = 174.000000'
});
data_peak.push({
lat: 3.3914333334e+01,
lng: 1.3524344444e+02,
cert : true,
content:'Name = JA/WK-081(JA/WK-081) peak = 486.399994 pos = 33.9143,135.2434 diff = 278.799988'
});
data_saddle.push({
lat: 3.3916333334e+01,
lng: 1.3527355556e+02,
content:'Saddle = 207.600006 pos = 33.9163,135.2736 diff = 278.799988'
});
data_peak.push({
lat: 3.3944444445e+01,
lng: 1.3528177778e+02,
cert : true,
content:'Name = JA/WK-085(JA/WK-085) peak = 473.700012 pos = 33.9444,135.2818 diff = 238.200012'
});
data_saddle.push({
lat: 3.3921444445e+01,
lng: 1.3526644444e+02,
content:'Saddle = 235.500000 pos = 33.9214,135.2664 diff = 238.200012'
});
data_peak.push({
lat: 3.5256666667e+01,
lng: 1.3629155556e+02,
cert : false,
content:' Peak = 362.000000 pos = 35.2567,136.2916 diff = 153.699997'
});
data_saddle.push({
lat: 3.5260555556e+01,
lng: 1.3630522222e+02,
content:'Saddle = 208.300003 pos = 35.2606,136.3052 diff = 153.699997'
});
data_peak.push({
lat: 3.4781666667e+01,
lng: 1.3589888889e+02,
cert : true,
content:'Name = JA/KT-089(JA/KT-089) peak = 380.399994 pos = 34.7817,135.8989 diff = 171.899994'
});
data_saddle.push({
lat: 3.4774000000e+01,
lng: 1.3590855556e+02,
content:'Saddle = 208.500000 pos = 34.7740,135.9086 diff = 171.899994'
});
data_peak.push({
lat: 3.4658888889e+01,
lng: 1.3607144444e+02,
cert : true,
content:'Name = JA/ME-096(JA/ME-096) peak = 364.000000 pos = 34.6589,136.0714 diff = 151.800003'
});
data_saddle.push({
lat: 3.4658444445e+01,
lng: 1.3613955556e+02,
content:'Saddle = 212.199997 pos = 34.6584,136.1396 diff = 151.800003'
});
data_peak.push({
lat: 3.4461222223e+01,
lng: 1.3678155556e+02,
cert : true,
content:'Name = Asamagatake(JA/ME-077) peak = 554.200012 pos = 34.4612,136.7816 diff = 341.900024'
});
data_saddle.push({
lat: 3.4329666667e+01,
lng: 1.3659822222e+02,
content:'Saddle = 212.300003 pos = 34.3297,136.5982 diff = 341.900024'
});
data_peak.push({
lat: 3.4363666667e+01,
lng: 1.3667766667e+02,
cert : true,
content:'Name = JA/ME-092(JA/ME-092) peak = 400.700012 pos = 34.3637,136.6777 diff = 177.600006'
});
data_saddle.push({
lat: 3.4367222223e+01,
lng: 1.3668333333e+02,
content:'Saddle = 223.100006 pos = 34.3672,136.6833 diff = 177.600006'
});
data_peak.push({
lat: 3.4386888890e+01,
lng: 1.3663755556e+02,
cert : true,
content:'Name = JA/ME-079(JA/ME-079) peak = 550.599976 pos = 34.3869,136.6376 diff = 317.899963'
});
data_saddle.push({
lat: 3.4406777778e+01,
lng: 1.3675822222e+02,
content:'Saddle = 232.699997 pos = 34.4068,136.7582 diff = 317.899963'
});
data_peak.push({
lat: 3.4426000001e+01,
lng: 1.3669155556e+02,
cert : true,
content:'Name = JA/ME-080(JA/ME-080) peak = 546.900024 pos = 34.4260,136.6916 diff = 274.800018'
});
data_saddle.push({
lat: 3.4391444445e+01,
lng: 1.3669400000e+02,
content:'Saddle = 272.100006 pos = 34.3914,136.6940 diff = 274.800018'
});
data_peak.push({
lat: 3.4416444445e+01,
lng: 1.3664355556e+02,
cert : true,
content:'Name = JA/ME-087(JA/ME-087) peak = 491.600006 pos = 34.4164,136.6436 diff = 155.100006'
});
data_saddle.push({
lat: 3.4407777778e+01,
lng: 1.3664277778e+02,
content:'Saddle = 336.500000 pos = 34.4078,136.6428 diff = 155.100006'
});
data_peak.push({
lat: 3.4435777778e+01,
lng: 1.3674055556e+02,
cert : false,
content:' Peak = 401.799988 pos = 34.4358,136.7406 diff = 155.599991'
});
data_saddle.push({
lat: 3.4412444445e+01,
lng: 1.3676311111e+02,
content:'Saddle = 246.199997 pos = 34.4124,136.7631 diff = 155.599991'
});
data_peak.push({
lat: 3.3627888890e+01,
lng: 1.3549277778e+02,
cert : true,
content:'Name = JA/WK-079(JA/WK-079) peak = 491.000000 pos = 33.6279,135.4928 diff = 278.000000'
});
data_saddle.push({
lat: 3.3619444445e+01,
lng: 1.3549777778e+02,
content:'Saddle = 213.000000 pos = 33.6194,135.4978 diff = 278.000000'
});
data_peak.push({
lat: 3.4020888890e+01,
lng: 1.3626066667e+02,
cert : false,
content:' Peak = 392.100006 pos = 34.0209,136.2607 diff = 173.800003'
});
data_saddle.push({
lat: 3.4024666667e+01,
lng: 1.3625722222e+02,
content:'Saddle = 218.300003 pos = 34.0247,136.2572 diff = 173.800003'
});
data_peak.push({
lat: 3.4872444445e+01,
lng: 1.3585677778e+02,
cert : true,
content:'Name = JA/KT-063(JA/KT-063) peak = 512.400024 pos = 34.8724,135.8568 diff = 294.000031'
});
data_saddle.push({
lat: 3.4873000000e+01,
lng: 1.3588911111e+02,
content:'Saddle = 218.399994 pos = 34.8730,135.8891 diff = 294.000031'
});
data_peak.push({
lat: 3.4338000001e+01,
lng: 1.3651211111e+02,
cert : true,
content:'Name = JA/ME-042(JA/ME-042) peak = 784.900024 pos = 34.3380,136.5121 diff = 565.400024'
});
data_saddle.push({
lat: 3.4257333334e+01,
lng: 1.3640322222e+02,
content:'Saddle = 219.500000 pos = 34.2573,136.4032 diff = 565.400024'
});
data_peak.push({
lat: 3.4234111112e+01,
lng: 1.3641777778e+02,
cert : true,
content:'Name = JA/ME-086(JA/ME-086) peak = 502.000000 pos = 34.2341,136.4178 diff = 181.000000'
});
data_saddle.push({
lat: 3.4257222223e+01,
lng: 1.3641911111e+02,
content:'Saddle = 321.000000 pos = 34.2572,136.4191 diff = 181.000000'
});
data_peak.push({
lat: 3.4299333334e+01,
lng: 1.3655555556e+02,
cert : false,
content:' Peak = 496.299988 pos = 34.2993,136.5556 diff = 159.299988'
});
data_saddle.push({
lat: 3.4304555556e+01,
lng: 1.3655477778e+02,
content:'Saddle = 337.000000 pos = 34.3046,136.5548 diff = 159.299988'
});
data_peak.push({
lat: 3.4265777778e+01,
lng: 1.3642177778e+02,
cert : false,
content:' Peak = 554.200012 pos = 34.2658,136.4218 diff = 177.900024'
});
data_saddle.push({
lat: 3.4287000001e+01,
lng: 1.3643633333e+02,
content:'Saddle = 376.299988 pos = 34.2870,136.4363 diff = 177.900024'
});
data_peak.push({
lat: 3.4285333334e+01,
lng: 1.3641966667e+02,
cert : false,
content:' Peak = 543.200012 pos = 34.2853,136.4197 diff = 151.100006'
});
data_saddle.push({
lat: 3.4279333334e+01,
lng: 1.3642266667e+02,
content:'Saddle = 392.100006 pos = 34.2793,136.4227 diff = 151.100006'
});
data_peak.push({
lat: 3.4373000001e+01,
lng: 1.3651555556e+02,
cert : true,
content:'Name = Nanahoragatake(JA/ME-044) peak = 772.700012 pos = 34.3730,136.5156 diff = 390.300018'
});
data_saddle.push({
lat: 3.4355444445e+01,
lng: 1.3651722222e+02,
content:'Saddle = 382.399994 pos = 34.3554,136.5172 diff = 390.300018'
});
data_peak.push({
lat: 3.4364333334e+01,
lng: 1.3655288889e+02,
cert : false,
content:' Peak = 573.599976 pos = 34.3643,136.5529 diff = 166.699982'
});
data_saddle.push({
lat: 3.4370444445e+01,
lng: 1.3654811111e+02,
content:'Saddle = 406.899994 pos = 34.3704,136.5481 diff = 166.699982'
});
data_peak.push({
lat: 3.4356000001e+01,
lng: 1.3645311111e+02,
cert : true,
content:'Name = JA/ME-055(JA/ME-055) peak = 730.200012 pos = 34.3560,136.4531 diff = 279.000000'
});
data_saddle.push({
lat: 3.4340444445e+01,
lng: 1.3646511111e+02,
content:'Saddle = 451.200012 pos = 34.3404,136.4651 diff = 279.000000'
});
data_peak.push({
lat: 3.4329111112e+01,
lng: 1.3647044444e+02,
cert : true,
content:'Name = JA/ME-054(JA/ME-054) peak = 732.200012 pos = 34.3291,136.4704 diff = 214.000000'
});
data_saddle.push({
lat: 3.4325888890e+01,
lng: 1.3649188889e+02,
content:'Saddle = 518.200012 pos = 34.3259,136.4919 diff = 214.000000'
});
data_peak.push({
lat: 3.4091444445e+01,
lng: 1.3620888889e+02,
cert : true,
content:'Name = JA/ME-084(JA/ME-084) peak = 521.700012 pos = 34.0914,136.2089 diff = 299.500000'
});
data_saddle.push({
lat: 3.4091333334e+01,
lng: 1.3619733333e+02,
content:'Saddle = 222.199997 pos = 34.0913,136.1973 diff = 299.500000'
});
data_peak.push({
lat: 3.3720666668e+01,
lng: 1.3591844444e+02,
cert : false,
content:' Peak = 383.600006 pos = 33.7207,135.9184 diff = 160.200012'
});
data_saddle.push({
lat: 3.3714222223e+01,
lng: 1.3592277778e+02,
content:'Saddle = 223.399994 pos = 33.7142,135.9228 diff = 160.200012'
});
data_peak.push({
lat: 3.5283666667e+01,
lng: 1.3651111111e+02,
cert : true,
content:'Name = Shougadake(JA/GF-142) peak = 906.299988 pos = 35.2837,136.5111 diff = 682.500000'
});
data_saddle.push({
lat: 3.5236777778e+01,
lng: 1.3647500000e+02,
content:'Saddle = 223.800003 pos = 35.2368,136.4750 diff = 682.500000'
});
data_peak.push({
lat: 3.5175111111e+01,
lng: 1.3658788889e+02,
cert : true,
content:'Name = JA/ME-060(JA/ME-060) peak = 693.700012 pos = 35.1751,136.5879 diff = 261.200012'
});
data_saddle.push({
lat: 3.5215555556e+01,
lng: 1.3655900000e+02,
content:'Saddle = 432.500000 pos = 35.2156,136.5590 diff = 261.200012'
});
data_peak.push({
lat: 3.5263222223e+01,
lng: 1.3652322222e+02,
cert : false,
content:' Peak = 858.099976 pos = 35.2632,136.5232 diff = 150.099976'
});
data_saddle.push({
lat: 3.5284888889e+01,
lng: 1.3652133333e+02,
content:'Saddle = 708.000000 pos = 35.2849,136.5213 diff = 150.099976'
});
data_peak.push({
lat: 3.3833777779e+01,
lng: 1.3535500000e+02,
cert : true,
content:'Name = JA/WK-092(JA/WK-092) peak = 412.299988 pos = 33.8338,135.3550 diff = 182.099991'
});
data_saddle.push({
lat: 3.3830777779e+01,
lng: 1.3536366667e+02,
content:'Saddle = 230.199997 pos = 33.8308,135.3637 diff = 182.099991'
});
data_peak.push({
lat: 3.4840333334e+01,
lng: 1.3608611111e+02,
cert : false,
content:' Peak = 741.299988 pos = 34.8403,136.0861 diff = 510.199982'
});
data_saddle.push({
lat: 3.4872666667e+01,
lng: 1.3619333333e+02,
content:'Saddle = 231.100006 pos = 34.8727,136.1933 diff = 510.199982'
});
data_peak.push({
lat: 3.4833444445e+01,
lng: 1.3592444444e+02,
cert : true,
content:'Name = JA/KT-028(JA/KT-028) peak = 682.900024 pos = 34.8334,135.9244 diff = 359.300018'
});
data_saddle.push({
lat: 3.4854444445e+01,
lng: 1.3596133333e+02,
content:'Saddle = 323.600006 pos = 34.8544,135.9613 diff = 359.300018'
});
data_peak.push({
lat: 3.4812111112e+01,
lng: 1.3588011111e+02,
cert : false,
content:' Peak = 521.000000 pos = 34.8121,135.8801 diff = 153.700012'
});
data_saddle.push({
lat: 3.4813111112e+01,
lng: 1.3589188889e+02,
content:'Saddle = 367.299988 pos = 34.8131,135.8919 diff = 153.700012'
});
data_peak.push({
lat: 3.4966555556e+01,
lng: 1.3606088889e+02,
cert : true,
content:'Name = JA/SI-038(JA/SI-038) peak = 692.500000 pos = 34.9666,136.0609 diff = 353.799988'
});
data_saddle.push({
lat: 3.4925888889e+01,
lng: 1.3611577778e+02,
content:'Saddle = 338.700012 pos = 34.9259,136.1158 diff = 353.799988'
});
data_peak.push({
lat: 3.4958222223e+01,
lng: 1.3603377778e+02,
cert : false,
content:' Peak = 610.599976 pos = 34.9582,136.0338 diff = 182.099976'
});
data_saddle.push({
lat: 3.4960888889e+01,
lng: 1.3604166667e+02,
content:'Saddle = 428.500000 pos = 34.9609,136.0417 diff = 182.099976'
});
data_peak.push({
lat: 3.4944222223e+01,
lng: 1.3610977778e+02,
cert : true,
content:'Name = JA/SI-042(JA/SI-042) peak = 663.700012 pos = 34.9442,136.1098 diff = 185.700012'
});
data_saddle.push({
lat: 3.4953777778e+01,
lng: 1.3609777778e+02,
content:'Saddle = 478.000000 pos = 34.9538,136.0978 diff = 185.700012'
});
data_peak.push({
lat: 3.4872222223e+01,
lng: 1.3607288889e+02,
cert : false,
content:' Peak = 551.599976 pos = 34.8722,136.0729 diff = 204.399963'
});
data_saddle.push({
lat: 3.4865555556e+01,
lng: 1.3608800000e+02,
content:'Saddle = 347.200012 pos = 34.8656,136.0880 diff = 204.399963'
});
data_peak.push({
lat: 3.4887111112e+01,
lng: 1.3599533333e+02,
cert : true,
content:'Name = JA/SI-044(JA/SI-044) peak = 623.000000 pos = 34.8871,135.9953 diff = 274.799988'
});
data_saddle.push({
lat: 3.4855555556e+01,
lng: 1.3600322222e+02,
content:'Saddle = 348.200012 pos = 34.8556,136.0032 diff = 274.799988'
});
data_peak.push({
lat: 3.4893888889e+01,
lng: 1.3597144444e+02,
cert : false,
content:' Peak = 553.900024 pos = 34.8939,135.9714 diff = 155.700012'
});
data_saddle.push({
lat: 3.4889333334e+01,
lng: 1.3597800000e+02,
content:'Saddle = 398.200012 pos = 34.8893,135.9780 diff = 155.700012'
});
data_peak.push({
lat: 3.4922777778e+01,
lng: 1.3604100000e+02,
cert : false,
content:' Peak = 566.799988 pos = 34.9228,136.0410 diff = 160.099976'
});
data_saddle.push({
lat: 3.4876000000e+01,
lng: 1.3601788889e+02,
content:'Saddle = 406.700012 pos = 34.8760,136.0179 diff = 160.099976'
});
data_peak.push({
lat: 3.3607666668e+01,
lng: 1.3544055556e+02,
cert : true,
content:'Name = JA/WK-089(JA/WK-089) peak = 450.000000 pos = 33.6077,135.4406 diff = 218.500000'
});
data_saddle.push({
lat: 3.3617333334e+01,
lng: 1.3543655556e+02,
content:'Saddle = 231.500000 pos = 33.6173,135.4366 diff = 218.500000'
});
data_peak.push({
lat: 3.3552000001e+01,
lng: 1.3566188889e+02,
cert : true,
content:'Name = JA/WK-094(JA/WK-094) peak = 403.399994 pos = 33.5520,135.6619 diff = 170.199997'
});
data_saddle.push({
lat: 3.3563000001e+01,
lng: 1.3565266667e+02,
content:'Saddle = 233.199997 pos = 33.5630,135.6527 diff = 170.199997'
});
data_peak.push({
lat: 3.3948000001e+01,
lng: 1.3531155556e+02,
cert : true,
content:'Name = JA/WK-075(JA/WK-075) peak = 521.400024 pos = 33.9480,135.3116 diff = 284.300018'
});
data_saddle.push({
lat: 3.3958000001e+01,
lng: 1.3530977778e+02,
content:'Saddle = 237.100006 pos = 33.9580,135.3098 diff = 284.300018'
});
data_peak.push({
lat: 3.4095000001e+01,
lng: 1.3618366667e+02,
cert : true,
content:'Name = JA/ME-070(JA/ME-070) peak = 598.200012 pos = 34.0950,136.1837 diff = 357.000000'
});
data_saddle.push({
lat: 3.4080222223e+01,
lng: 1.3617388889e+02,
content:'Saddle = 241.199997 pos = 34.0802,136.1739 diff = 357.000000'
});
data_peak.push({
lat: 3.4267333334e+01,
lng: 1.3637922222e+02,
cert : true,
content:'Name = JA/ME-067(JA/ME-067) peak = 631.799988 pos = 34.2673,136.3792 diff = 390.500000'
});
data_saddle.push({
lat: 3.4237222223e+01,
lng: 1.3635777778e+02,
content:'Saddle = 241.300003 pos = 34.2372,136.3578 diff = 390.500000'
});
data_peak.push({
lat: 3.3994777779e+01,
lng: 1.3517488889e+02,
cert : false,
content:' Peak = 412.899994 pos = 33.9948,135.1749 diff = 165.099991'
});
data_saddle.push({
lat: 3.3989555556e+01,
lng: 1.3517477778e+02,
content:'Saddle = 247.800003 pos = 33.9896,135.1748 diff = 165.099991'
});
data_peak.push({
lat: 3.3899555556e+01,
lng: 1.3590622222e+02,
cert : true,
content:'Name = JA/ME-059(JA/ME-059) peak = 701.700012 pos = 33.8996,135.9062 diff = 450.900024'
});
data_saddle.push({
lat: 3.3890555556e+01,
lng: 1.3594844444e+02,
content:'Saddle = 250.800003 pos = 33.8906,135.9484 diff = 450.900024'
});
data_peak.push({
lat: 3.3899222223e+01,
lng: 1.3592800000e+02,
cert : false,
content:' Peak = 626.000000 pos = 33.8992,135.9280 diff = 155.500000'
});
data_saddle.push({
lat: 3.3892111112e+01,
lng: 1.3592922222e+02,
content:'Saddle = 470.500000 pos = 33.8921,135.9292 diff = 155.500000'
});
data_peak.push({
lat: 3.3794666668e+01,
lng: 1.3593044444e+02,
cert : true,
content:'Name = Nenotomariyama(JA/ME-029) peak = 904.500000 pos = 33.7947,135.9304 diff = 645.700012'
});
data_saddle.push({
lat: 3.3860333334e+01,
lng: 1.3596533333e+02,
content:'Saddle = 258.799988 pos = 33.8603,135.9653 diff = 645.700012'
});
data_peak.push({
lat: 3.3820222223e+01,
lng: 1.3598411111e+02,
cert : true,
content:'Name = JA/ME-069(JA/ME-069) peak = 600.299988 pos = 33.8202,135.9841 diff = 278.000000'
});
data_saddle.push({
lat: 3.3825666668e+01,
lng: 1.3596855556e+02,
content:'Saddle = 322.299988 pos = 33.8257,135.9686 diff = 278.000000'
});
data_peak.push({
lat: 3.3845000001e+01,
lng: 1.3595955556e+02,
cert : true,
content:'Name = JA/ME-068(JA/ME-068) peak = 622.700012 pos = 33.8450,135.9596 diff = 257.900024'
});
data_saddle.push({
lat: 3.3846111112e+01,
lng: 1.3594777778e+02,
content:'Saddle = 364.799988 pos = 33.8461,135.9478 diff = 257.900024'
});
data_peak.push({
lat: 3.3856555556e+01,
lng: 1.3592455556e+02,
cert : false,
content:' Peak = 800.200012 pos = 33.8566,135.9246 diff = 283.100037'
});
data_saddle.push({
lat: 3.3815333334e+01,
lng: 1.3594366667e+02,
content:'Saddle = 517.099976 pos = 33.8153,135.9437 diff = 283.100037'
});
data_peak.push({
lat: 3.3835666668e+01,
lng: 1.3593488889e+02,
cert : true,
content:'Name = JA/ME-045(JA/ME-045) peak = 770.799988 pos = 33.8357,135.9349 diff = 238.599976'
});
data_saddle.push({
lat: 3.3851000001e+01,
lng: 1.3593144444e+02,
content:'Saddle = 532.200012 pos = 33.8510,135.9314 diff = 238.599976'
});
data_peak.push({
lat: 3.3823666668e+01,
lng: 1.3591255556e+02,
cert : true,
content:'Name = JA/ME-037(JA/ME-037) peak = 814.700012 pos = 33.8237,135.9126 diff = 173.000000'
});
data_saddle.push({
lat: 3.3808666668e+01,
lng: 1.3592344444e+02,
content:'Saddle = 641.700012 pos = 33.8087,135.9234 diff = 173.000000'
});
data_peak.push({
lat: 3.3962333334e+01,
lng: 1.3530700000e+02,
cert : false,
content:' Peak = 441.600006 pos = 33.9623,135.3070 diff = 182.300018'
});
data_saddle.push({
lat: 3.3972111112e+01,
lng: 1.3530988889e+02,
content:'Saddle = 259.299988 pos = 33.9721,135.3099 diff = 182.300018'
});
data_peak.push({
lat: 3.3876222223e+01,
lng: 1.3532533333e+02,
cert : false,
content:' Peak = 428.399994 pos = 33.8762,135.3253 diff = 159.899994'
});
data_saddle.push({
lat: 3.3879111112e+01,
lng: 1.3533900000e+02,
content:'Saddle = 268.500000 pos = 33.8791,135.3390 diff = 159.899994'
});
data_peak.push({
lat: 3.4064333334e+01,
lng: 1.3529633333e+02,
cert : true,
content:'Name = JA/WK-086(JA/WK-086) peak = 470.100006 pos = 34.0643,135.2963 diff = 196.500000'
});
data_saddle.push({
lat: 3.4064222223e+01,
lng: 1.3531466667e+02,
content:'Saddle = 273.600006 pos = 34.0642,135.3147 diff = 196.500000'
});
data_peak.push({
lat: 3.4089333334e+01,
lng: 1.3541411111e+02,
cert : true,
content:'Name = JA/WK-088(JA/WK-088) peak = 451.500000 pos = 34.0893,135.4141 diff = 174.799988'
});
data_saddle.push({
lat: 3.4093222223e+01,
lng: 1.3541888889e+02,
content:'Saddle = 276.700012 pos = 34.0932,135.4189 diff = 174.799988'
});
data_peak.push({
lat: 3.3997555556e+01,
lng: 1.3600400000e+02,
cert : true,
content:'Name = JA/ME-088(JA/ME-088) peak = 444.399994 pos = 33.9976,136.0040 diff = 161.600006'
});
data_saddle.push({
lat: 3.4003111112e+01,
lng: 1.3600722222e+02,
content:'Saddle = 282.799988 pos = 34.0031,136.0072 diff = 161.600006'
});
data_peak.push({
lat: 3.3791000001e+01,
lng: 1.3540422222e+02,
cert : true,
content:'Name = JA/WK-071(JA/WK-071) peak = 547.799988 pos = 33.7910,135.4042 diff = 260.799988'
});
data_saddle.push({
lat: 3.3820333334e+01,
lng: 1.3540866667e+02,
content:'Saddle = 287.000000 pos = 33.8203,135.4087 diff = 260.799988'
});
data_peak.push({
lat: 3.3775888890e+01,
lng: 1.3542644444e+02,
cert : true,
content:'Name = JA/WK-064(JA/WK-064) peak = 604.299988 pos = 33.7759,135.4264 diff = 316.599976'
});
data_saddle.push({
lat: 3.3792111112e+01,
lng: 1.3543944444e+02,
content:'Saddle = 287.700012 pos = 33.7921,135.4394 diff = 316.599976'
});
data_peak.push({
lat: 3.3815222223e+01,
lng: 1.3553188889e+02,
cert : false,
content:' Peak = 454.899994 pos = 33.8152,135.5319 diff = 158.299988'
});
data_saddle.push({
lat: 3.3823777779e+01,
lng: 1.3553322222e+02,
content:'Saddle = 296.600006 pos = 33.8238,135.5332 diff = 158.299988'
});
data_peak.push({
lat: 3.3813666668e+01,
lng: 1.3550711111e+02,
cert : true,
content:'Name = JA/WK-082(JA/WK-082) peak = 484.299988 pos = 33.8137,135.5071 diff = 186.699982'
});
data_saddle.push({
lat: 3.3825666668e+01,
lng: 1.3550066667e+02,
content:'Saddle = 297.600006 pos = 33.8257,135.5007 diff = 186.699982'
});
data_peak.push({
lat: 3.4184333334e+01,
lng: 1.3536722222e+02,
cert : false,
content:' Peak = 480.799988 pos = 34.1843,135.3672 diff = 182.399994'
});
data_saddle.push({
lat: 3.4186111112e+01,
lng: 1.3538222222e+02,
content:'Saddle = 298.399994 pos = 34.1861,135.3822 diff = 182.399994'
});
data_peak.push({
lat: 3.3986444445e+01,
lng: 1.3601544444e+02,
cert : true,
content:'Name = JA/ME-071(JA/ME-071) peak = 593.700012 pos = 33.9864,136.0154 diff = 292.000000'
});
data_saddle.push({
lat: 3.3979333334e+01,
lng: 1.3602733333e+02,
content:'Saddle = 301.700012 pos = 33.9793,136.0273 diff = 292.000000'
});
data_peak.push({
lat: 3.4856333334e+01,
lng: 1.3634922222e+02,
cert : true,
content:'Name = JA/ME-074(JA/ME-074) peak = 560.700012 pos = 34.8563,136.3492 diff = 253.600006'
});
data_saddle.push({
lat: 3.4859777778e+01,
lng: 1.3634144444e+02,
content:'Saddle = 307.100006 pos = 34.8598,136.3414 diff = 253.600006'
});
data_peak.push({
lat: 3.3630666668e+01,
lng: 1.3544788889e+02,
cert : true,
content:'Name = JA/WK-077(JA/WK-077) peak = 515.400024 pos = 33.6307,135.4479 diff = 206.100037'
});
data_saddle.push({
lat: 3.3649666668e+01,
lng: 1.3545055556e+02,
content:'Saddle = 309.299988 pos = 33.6497,135.4506 diff = 206.100037'
});
data_peak.push({
lat: 3.3640555556e+01,
lng: 1.3582877778e+02,
cert : false,
content:' Peak = 480.399994 pos = 33.6406,135.8288 diff = 167.299988'
});
data_saddle.push({
lat: 3.3650888890e+01,
lng: 1.3582511111e+02,
content:'Saddle = 313.100006 pos = 33.6509,135.8251 diff = 167.299988'
});
data_peak.push({
lat: 3.5178555556e+01,
lng: 1.3641466667e+02,
cert : true,
content:'Name = Oikedake(JA/SI-002) peak = 1246.500000 pos = 35.1786,136.4147 diff = 928.799988'
});
data_saddle.push({
lat: 3.4845666667e+01,
lng: 1.3628288889e+02,
content:'Saddle = 317.700012 pos = 34.8457,136.2829 diff = 928.799988'
});
data_peak.push({
lat: 3.4889555556e+01,
lng: 1.3638577778e+02,
cert : true,
content:'Name = JA/ME-075(JA/ME-075) peak = 563.400024 pos = 34.8896,136.3858 diff = 203.500031'
});
data_saddle.push({
lat: 3.4892888889e+01,
lng: 1.3637855556e+02,
content:'Saddle = 359.899994 pos = 34.8929,136.3786 diff = 203.500031'
});
data_peak.push({
lat: 3.4875888889e+01,
lng: 1.3629788889e+02,
cert : true,
content:'Name = JA/ME-040(JA/ME-040) peak = 798.500000 pos = 34.8759,136.2979 diff = 420.700012'
});
data_saddle.push({
lat: 3.4894777778e+01,
lng: 1.3633677778e+02,
content:'Saddle = 377.799988 pos = 34.8948,136.3368 diff = 420.700012'
});
data_peak.push({
lat: 3.4855555556e+01,
lng: 1.3628422222e+02,
cert : false,
content:' Peak = 716.000000 pos = 34.8556,136.2842 diff = 153.799988'
});
data_saddle.push({
lat: 3.4863666667e+01,
lng: 1.3628066667e+02,
content:'Saddle = 562.200012 pos = 34.8637,136.2807 diff = 153.799988'
});
data_peak.push({
lat: 3.5296444445e+01,
lng: 1.3632655556e+02,
cert : true,
content:'Name = JA/SI-047(JA/SI-047) peak = 600.900024 pos = 35.2964,136.3266 diff = 163.400024'
});
data_saddle.push({
lat: 3.5288555556e+01,
lng: 1.3633388889e+02,
content:'Saddle = 437.500000 pos = 35.2886,136.3339 diff = 163.400024'
});
data_peak.push({
lat: 3.4974666667e+01,
lng: 1.3632155556e+02,
cert : true,
content:'Name = JA/SI-037(JA/SI-037) peak = 721.500000 pos = 34.9747,136.3216 diff = 283.899994'
});
data_saddle.push({
lat: 3.4980555556e+01,
lng: 1.3632811111e+02,
content:'Saddle = 437.600006 pos = 34.9806,136.3281 diff = 283.899994'
});
data_peak.push({
lat: 3.5088666667e+01,
lng: 1.3647111111e+02,
cert : false,
content:' Peak = 596.299988 pos = 35.0887,136.4711 diff = 153.099976'
});
data_saddle.push({
lat: 3.5087666667e+01,
lng: 1.3646611111e+02,
content:'Saddle = 443.200012 pos = 35.0877,136.4661 diff = 153.099976'
});
data_peak.push({
lat: 3.4902888889e+01,
lng: 1.3635944444e+02,
cert : true,
content:'Name = JA/ME-065(JA/ME-065) peak = 665.200012 pos = 34.9029,136.3594 diff = 214.200012'
});
data_saddle.push({
lat: 3.4910888889e+01,
lng: 1.3636466667e+02,
content:'Saddle = 451.000000 pos = 34.9109,136.3647 diff = 214.200012'
});
data_peak.push({
lat: 3.5265111111e+01,
lng: 1.3633977778e+02,
cert : false,
content:' Peak = 686.799988 pos = 35.2651,136.3398 diff = 214.899994'
});
data_saddle.push({
lat: 3.5274666667e+01,
lng: 1.3635511111e+02,
content:'Saddle = 471.899994 pos = 35.2747,136.3551 diff = 214.899994'
});
data_peak.push({
lat: 3.5279444445e+01,
lng: 1.3632377778e+02,
cert : true,
content:'Name = JA/SI-040(JA/SI-040) peak = 682.500000 pos = 35.2794,136.3238 diff = 165.200012'
});
data_saddle.push({
lat: 3.5272333334e+01,
lng: 1.3631844444e+02,
content:'Saddle = 517.299988 pos = 35.2723,136.3184 diff = 165.200012'
});
data_peak.push({
lat: 3.5164111111e+01,
lng: 1.3630288889e+02,
cert : false,
content:' Peak = 640.700012 pos = 35.1641,136.3029 diff = 168.400024'
});
data_saddle.push({
lat: 3.5159000000e+01,
lng: 1.3630922222e+02,
content:'Saddle = 472.299988 pos = 35.1590,136.3092 diff = 168.400024'
});
data_peak.push({
lat: 3.5255444445e+01,
lng: 1.3642811111e+02,
cert : true,
content:'Name = JA/GF-171(JA/GF-171) peak = 710.599976 pos = 35.2554,136.4281 diff = 233.699982'
});
data_saddle.push({
lat: 3.5269000000e+01,
lng: 1.3643066667e+02,
content:'Saddle = 476.899994 pos = 35.2690,136.4307 diff = 233.699982'
});
data_peak.push({
lat: 3.5279222223e+01,
lng: 1.3638111111e+02,
cert : true,
content:'Name = Ryouzenzan(JA/SI-010) peak = 1092.099976 pos = 35.2792,136.3811 diff = 585.000000'
});
data_saddle.push({
lat: 3.5240333334e+01,
lng: 1.3638188889e+02,
content:'Saddle = 507.100006 pos = 35.2403,136.3819 diff = 585.000000'
});
data_peak.push({
lat: 3.5102222223e+01,
lng: 1.3634233333e+02,
cert : true,
content:'Name = JA/SI-015(JA/SI-015) peak = 933.200012 pos = 35.1022,136.3423 diff = 422.600006'
});
data_saddle.push({
lat: 3.5132222223e+01,
lng: 1.3636177778e+02,
content:'Saddle = 510.600006 pos = 35.1322,136.3618 diff = 422.600006'
});
data_peak.push({
lat: 3.5138444445e+01,
lng: 1.3630277778e+02,
cert : true,
content:'Name = JA/SI-033(JA/SI-033) peak = 771.299988 pos = 35.1384,136.3028 diff = 233.000000'
});
data_saddle.push({
lat: 3.5120111111e+01,
lng: 1.3630711111e+02,
content:'Saddle = 538.299988 pos = 35.1201,136.3071 diff = 233.000000'
});
data_peak.push({
lat: 3.5143777778e+01,
lng: 1.3633577778e+02,
cert : false,
content:' Peak = 763.700012 pos = 35.1438,136.3358 diff = 212.000000'
});
data_saddle.push({
lat: 3.5138333334e+01,
lng: 1.3632600000e+02,
content:'Saddle = 551.700012 pos = 35.1383,136.3260 diff = 212.000000'
});
data_peak.push({
lat: 3.5245666667e+01,
lng: 1.3635933333e+02,
cert : true,
content:'Name = JA/SI-027(JA/SI-027) peak = 837.599976 pos = 35.2457,136.3593 diff = 265.699951'
});
data_saddle.push({
lat: 3.5222555556e+01,
lng: 1.3637300000e+02,
content:'Saddle = 571.900024 pos = 35.2226,136.3730 diff = 265.699951'
});
data_peak.push({
lat: 3.5220222223e+01,
lng: 1.3635344444e+02,
cert : true,
content:'Name = JA/SI-029(JA/SI-029) peak = 817.299988 pos = 35.2202,136.3534 diff = 195.299988'
});
data_saddle.push({
lat: 3.5233555556e+01,
lng: 1.3635288889e+02,
content:'Saddle = 622.000000 pos = 35.2336,136.3529 diff = 195.299988'
});
data_peak.push({
lat: 3.5105333334e+01,
lng: 1.3641544444e+02,
cert : false,
content:' Peak = 752.599976 pos = 35.1053,136.4154 diff = 154.199951'
});
data_saddle.push({
lat: 3.5101888889e+01,
lng: 1.3642288889e+02,
content:'Saddle = 598.400024 pos = 35.1019,136.4229 diff = 154.199951'
});
data_peak.push({
lat: 3.5021333334e+01,
lng: 1.3638388889e+02,
cert : false,
content:' Peak = 1235.500000 pos = 35.0213,136.3839 diff = 550.099976'
});
data_saddle.push({
lat: 3.5108333334e+01,
lng: 1.3644133333e+02,
content:'Saddle = 685.400024 pos = 35.1083,136.4413 diff = 550.099976'
});
data_peak.push({
lat: 3.4999111112e+01,
lng: 1.3644877778e+02,
cert : true,
content:'Name = JA/ME-031(JA/ME-031) peak = 887.299988 pos = 34.9991,136.4488 diff = 175.000000'
});
data_saddle.push({
lat: 3.5000555556e+01,
lng: 1.3643611111e+02,
content:'Saddle = 712.299988 pos = 35.0006,136.4361 diff = 175.000000'
});
data_peak.push({
lat: 3.4975777778e+01,
lng: 1.3637033333e+02,
cert : false,
content:' Peak = 913.599976 pos = 34.9758,136.3703 diff = 193.399963'
});
data_saddle.push({
lat: 3.4972111112e+01,
lng: 1.3639122222e+02,
content:'Saddle = 720.200012 pos = 34.9721,136.3912 diff = 193.399963'
});
data_peak.push({
lat: 3.4947222223e+01,
lng: 1.3641411111e+02,
cert : false,
content:' Peak = 873.700012 pos = 34.9472,136.4141 diff = 152.100037'
});
data_saddle.push({
lat: 3.4950111112e+01,
lng: 1.3640433333e+02,
content:'Saddle = 721.599976 pos = 34.9501,136.4043 diff = 152.100037'
});
data_peak.push({
lat: 3.5088666667e+01,
lng: 1.3640722222e+02,
cert : false,
content:' Peak = 930.700012 pos = 35.0887,136.4072 diff = 168.299988'
});
data_saddle.push({
lat: 3.5082111111e+01,
lng: 1.3642288889e+02,
content:'Saddle = 762.400024 pos = 35.0821,136.4229 diff = 168.299988'
});
data_peak.push({
lat: 3.5013777778e+01,
lng: 1.3634177778e+02,
cert : true,
content:'Name = JA/SI-009(JA/SI-009) peak = 1113.199951 pos = 35.0138,136.3418 diff = 320.699951'
});
data_saddle.push({
lat: 3.5022333334e+01,
lng: 1.3636011111e+02,
content:'Saddle = 792.500000 pos = 35.0223,136.3601 diff = 320.699951'
});
data_peak.push({
lat: 3.5065666667e+01,
lng: 1.3644133333e+02,
cert : true,
content:'Name = JA/ME-016(JA/ME-016) peak = 1091.300049 pos = 35.0657,136.4413 diff = 290.200073'
});
data_saddle.push({
lat: 3.5036666667e+01,
lng: 1.3641655556e+02,
content:'Saddle = 801.099976 pos = 35.0367,136.4166 diff = 290.200073'
});
data_peak.push({
lat: 3.4951888889e+01,
lng: 1.3639533333e+02,
cert : false,
content:' Peak = 960.799988 pos = 34.9519,136.3953 diff = 157.099976'
});
data_saddle.push({
lat: 3.4955666667e+01,
lng: 1.3639622222e+02,
content:'Saddle = 803.700012 pos = 34.9557,136.3962 diff = 157.099976'
});
data_peak.push({
lat: 3.5001222223e+01,
lng: 1.3642111111e+02,
cert : true,
content:'Name = JA/ME-012(JA/ME-012) peak = 1160.300049 pos = 35.0012,136.4211 diff = 278.600037'
});
data_saddle.push({
lat: 3.5010555556e+01,
lng: 1.3641722222e+02,
content:'Saddle = 881.700012 pos = 35.0106,136.4172 diff = 278.600037'
});
data_peak.push({
lat: 3.5020444445e+01,
lng: 1.3641800000e+02,
cert : true,
content:'Name = Gozaishoyama(JA/ME-011) peak = 1211.500000 pos = 35.0204,136.4180 diff = 309.099976'
});
data_saddle.push({
lat: 3.5016555556e+01,
lng: 1.3639977778e+02,
content:'Saddle = 902.400024 pos = 35.0166,136.3998 diff = 309.099976'
});
data_peak.push({
lat: 3.5228222223e+01,
lng: 1.3643333333e+02,
cert : false,
content:' Peak = 870.299988 pos = 35.2282,136.4333 diff = 160.399963'
});
data_saddle.push({
lat: 3.5225888889e+01,
lng: 1.3642588889e+02,
content:'Saddle = 709.900024 pos = 35.2259,136.4259 diff = 160.399963'
});
data_peak.push({
lat: 3.5119333334e+01,
lng: 1.3644500000e+02,
cert : true,
content:'Name = Ryuugadake(JA/ME-014) peak = 1098.699951 pos = 35.1193,136.4450 diff = 347.399963'
});
data_saddle.push({
lat: 3.5145777778e+01,
lng: 1.3644377778e+02,
content:'Saddle = 751.299988 pos = 35.1458,136.4438 diff = 347.399963'
});
data_peak.push({
lat: 3.5131000000e+01,
lng: 1.3643455556e+02,
cert : false,
content:' Peak = 1085.699951 pos = 35.1310,136.4346 diff = 162.599976'
});
data_saddle.push({
lat: 3.5127333334e+01,
lng: 1.3644344444e+02,
content:'Saddle = 923.099976 pos = 35.1273,136.4434 diff = 162.599976'
});
data_peak.push({
lat: 3.5214777778e+01,
lng: 1.3641622222e+02,
cert : false,
content:' Peak = 912.299988 pos = 35.2148,136.4162 diff = 154.099976'
});
data_saddle.push({
lat: 3.5210666667e+01,
lng: 1.3641600000e+02,
content:'Saddle = 758.200012 pos = 35.2107,136.4160 diff = 154.099976'
});
data_peak.push({
lat: 3.5151555556e+01,
lng: 1.3639133333e+02,
cert : true,
content:'Name = JA/SI-011(JA/SI-011) peak = 985.400024 pos = 35.1516,136.3913 diff = 213.800049'
});
data_saddle.push({
lat: 3.5189333334e+01,
lng: 1.3638122222e+02,
content:'Saddle = 771.599976 pos = 35.1893,136.3812 diff = 213.800049'
});
data_peak.push({
lat: 3.5166222223e+01,
lng: 1.3644511111e+02,
cert : true,
content:'Name = JA/SI-007(JA/SI-007) peak = 1170.500000 pos = 35.1662,136.4451 diff = 229.599976'
});
data_saddle.push({
lat: 3.5184333334e+01,
lng: 1.3642411111e+02,
content:'Saddle = 940.900024 pos = 35.1843,136.4241 diff = 229.599976'
});
data_peak.push({
lat: 3.3875888890e+01,
lng: 1.3577355556e+02,
cert : false,
content:' Peak = 487.299988 pos = 33.8759,135.7736 diff = 165.399994'
});
data_saddle.push({
lat: 3.3880222223e+01,
lng: 1.3577666667e+02,
content:'Saddle = 321.899994 pos = 33.8802,135.7767 diff = 165.399994'
});
data_peak.push({
lat: 3.3956333334e+01,
lng: 1.3518966667e+02,
cert : false,
content:' Peak = 530.099976 pos = 33.9563,135.1897 diff = 207.899963'
});
data_saddle.push({
lat: 3.3952444445e+01,
lng: 1.3523344444e+02,
content:'Saddle = 322.200012 pos = 33.9524,135.2334 diff = 207.899963'
});
data_peak.push({
lat: 3.4206111112e+01,
lng: 1.3542033333e+02,
cert : true,
content:'Name = JA/WK-078(JA/WK-078) peak = 506.100006 pos = 34.2061,135.4203 diff = 179.700012'
});
data_saddle.push({
lat: 3.4215222223e+01,
lng: 1.3542300000e+02,
content:'Saddle = 326.399994 pos = 34.2152,135.4230 diff = 179.700012'
});
data_peak.push({
lat: 3.3977333334e+01,
lng: 1.3538277778e+02,
cert : false,
content:' Peak = 505.000000 pos = 33.9773,135.3828 diff = 177.500000'
});
data_saddle.push({
lat: 3.3982444445e+01,
lng: 1.3538177778e+02,
content:'Saddle = 327.500000 pos = 33.9824,135.3818 diff = 177.500000'
});
data_peak.push({
lat: 3.4068555556e+01,
lng: 1.3597266667e+02,
cert : false,
content:' Peak = 489.500000 pos = 34.0686,135.9727 diff = 161.799988'
});
data_saddle.push({
lat: 3.4070888890e+01,
lng: 1.3597100000e+02,
content:'Saddle = 327.700012 pos = 34.0709,135.9710 diff = 161.799988'
});
data_peak.push({
lat: 3.4183000001e+01,
lng: 1.3624800000e+02,
cert : false,
content:' Peak = 571.400024 pos = 34.1830,136.2480 diff = 239.800018'
});
data_saddle.push({
lat: 3.4201333334e+01,
lng: 1.3623688889e+02,
content:'Saddle = 331.600006 pos = 34.2013,136.2369 diff = 239.800018'
});
data_peak.push({
lat: 3.3539222223e+01,
lng: 1.3563222222e+02,
cert : true,
content:'Name = JA/WK-072(JA/WK-072) peak = 547.900024 pos = 33.5392,135.6322 diff = 215.200012'
});
data_saddle.push({
lat: 3.3542777779e+01,
lng: 1.3560411111e+02,
content:'Saddle = 332.700012 pos = 33.5428,135.6041 diff = 215.200012'
});
data_peak.push({
lat: 3.3528444445e+01,
lng: 1.3561888889e+02,
cert : false,
content:' Peak = 497.100006 pos = 33.5284,135.6189 diff = 158.500000'
});
data_saddle.push({
lat: 3.3532333334e+01,
lng: 1.3562422222e+02,
content:'Saddle = 338.600006 pos = 33.5323,135.6242 diff = 158.500000'
});
data_peak.push({
lat: 3.4534222223e+01,
lng: 1.3597222222e+02,
cert : true,
content:'Name = JA/NR-055(JA/NR-055) peak = 520.799988 pos = 34.5342,135.9722 diff = 186.099976'
});
data_saddle.push({
lat: 3.4541333334e+01,
lng: 1.3597044444e+02,
content:'Saddle = 334.700012 pos = 34.5413,135.9704 diff = 186.099976'
});
data_peak.push({
lat: 3.3588888890e+01,
lng: 1.3572688889e+02,
cert : false,
content:' Peak = 552.099976 pos = 33.5889,135.7269 diff = 215.699982'
});
data_saddle.push({
lat: 3.3601888890e+01,
lng: 1.3572177778e+02,
content:'Saddle = 336.399994 pos = 33.6019,135.7218 diff = 215.699982'
});
data_peak.push({
lat: 3.3562444445e+01,
lng: 1.3560966667e+02,
cert : true,
content:'Name = JA/WK-076(JA/WK-076) peak = 518.400024 pos = 33.5624,135.6097 diff = 180.900024'
});
data_saddle.push({
lat: 3.3549000001e+01,
lng: 1.3559900000e+02,
content:'Saddle = 337.500000 pos = 33.5490,135.5990 diff = 180.900024'
});
data_peak.push({
lat: 3.4022555556e+01,
lng: 1.3598966667e+02,
cert : false,
content:' Peak = 540.200012 pos = 34.0226,135.9897 diff = 202.600006'
});
data_saddle.push({
lat: 3.4018000001e+01,
lng: 1.3597955556e+02,
content:'Saddle = 337.600006 pos = 34.0180,135.9796 diff = 202.600006'
});
data_peak.push({
lat: 3.3952000001e+01,
lng: 1.3547000000e+02,
cert : false,
content:' Peak = 490.399994 pos = 33.9520,135.4700 diff = 151.399994'
});
data_saddle.push({
lat: 3.3954666667e+01,
lng: 1.3547188889e+02,
content:'Saddle = 339.000000 pos = 33.9547,135.4719 diff = 151.399994'
});
data_peak.push({
lat: 3.4600444445e+01,
lng: 1.3633555556e+02,
cert : true,
content:'Name = JA/ME-081(JA/ME-081) peak = 543.099976 pos = 34.6004,136.3356 diff = 203.099976'
});
data_saddle.push({
lat: 3.4594555556e+01,
lng: 1.3634933333e+02,
content:'Saddle = 340.000000 pos = 34.5946,136.3493 diff = 203.099976'
});
data_peak.push({
lat: 3.3667555556e+01,
lng: 1.3549888889e+02,
cert : true,
content:'Name = JA/WK-070(JA/WK-070) peak = 554.099976 pos = 33.6676,135.4989 diff = 213.599976'
});
data_saddle.push({
lat: 3.3683666668e+01,
lng: 1.3549700000e+02,
content:'Saddle = 340.500000 pos = 33.6837,135.4970 diff = 213.599976'
});
data_peak.push({
lat: 3.3968000001e+01,
lng: 1.3534555556e+02,
cert : false,
content:' Peak = 531.200012 pos = 33.9680,135.3456 diff = 189.600006'
});
data_saddle.push({
lat: 3.3963222223e+01,
lng: 1.3534955556e+02,
content:'Saddle = 341.600006 pos = 33.9632,135.3496 diff = 189.600006'
});
data_peak.push({
lat: 3.4560333334e+01,
lng: 1.3594622222e+02,
cert : true,
content:'Name = JA/NR-042(JA/NR-042) peak = 821.799988 pos = 34.5603,135.9462 diff = 480.000000'
});
data_saddle.push({
lat: 3.4526555556e+01,
lng: 1.3594022222e+02,
content:'Saddle = 341.799988 pos = 34.5266,135.9402 diff = 480.000000'
});
data_peak.push({
lat: 3.4580555556e+01,
lng: 1.3600388889e+02,
cert : false,
content:' Peak = 622.900024 pos = 34.5806,136.0039 diff = 155.700012'
});
data_saddle.push({
lat: 3.4584777778e+01,
lng: 1.3598100000e+02,
content:'Saddle = 467.200012 pos = 34.5848,135.9810 diff = 155.700012'
});
data_peak.push({
lat: 3.4634888889e+01,
lng: 1.3590122222e+02,
cert : true,
content:'Name = JA/NR-048(JA/NR-048) peak = 679.000000 pos = 34.6349,135.9012 diff = 203.399994'
});
data_saddle.push({
lat: 3.4594444445e+01,
lng: 1.3593811111e+02,
content:'Saddle = 475.600006 pos = 34.5944,135.9381 diff = 203.399994'
});
data_peak.push({
lat: 3.4558888889e+01,
lng: 1.3596922222e+02,
cert : true,
content:'Name = JA/NR-043(JA/NR-043) peak = 812.200012 pos = 34.5589,135.9692 diff = 264.799988'
});
data_saddle.push({
lat: 3.4560333334e+01,
lng: 1.3595888889e+02,
content:'Saddle = 547.400024 pos = 34.5603,135.9589 diff = 264.799988'
});
data_peak.push({
lat: 3.3755111112e+01,
lng: 1.3581033333e+02,
cert : false,
content:' Peak = 551.500000 pos = 33.7551,135.8103 diff = 209.399994'
});
data_saddle.push({
lat: 3.3740555556e+01,
lng: 1.3581277778e+02,
content:'Saddle = 342.100006 pos = 33.7406,135.8128 diff = 209.399994'
});
data_peak.push({
lat: 3.3660666668e+01,
lng: 1.3555100000e+02,
cert : false,
content:' Peak = 504.200012 pos = 33.6607,135.5510 diff = 156.600006'
});
data_saddle.push({
lat: 3.3626222223e+01,
lng: 1.3554644444e+02,
content:'Saddle = 347.600006 pos = 33.6262,135.5464 diff = 156.600006'
});
data_peak.push({
lat: 3.4420444445e+01,
lng: 1.3642466667e+02,
cert : false,
content:' Peak = 511.500000 pos = 34.4204,136.4247 diff = 160.299988'
});
data_saddle.push({
lat: 3.4416777778e+01,
lng: 1.3641266667e+02,
content:'Saddle = 351.200012 pos = 34.4168,136.4127 diff = 160.299988'
});
data_peak.push({
lat: 3.4243444445e+01,
lng: 1.3634077778e+02,
cert : false,
content:' Peak = 533.900024 pos = 34.2434,136.3408 diff = 181.800018'
});
data_saddle.push({
lat: 3.4243333334e+01,
lng: 1.3632733333e+02,
content:'Saddle = 352.100006 pos = 34.2433,136.3273 diff = 181.800018'
});
data_peak.push({
lat: 3.3727666668e+01,
lng: 1.3555900000e+02,
cert : true,
content:'Name = JA/WK-046(JA/WK-046) peak = 723.900024 pos = 33.7277,135.5590 diff = 366.900024'
});
data_saddle.push({
lat: 3.3775444445e+01,
lng: 1.3554911111e+02,
content:'Saddle = 357.000000 pos = 33.7754,135.5491 diff = 366.900024'
});
data_peak.push({
lat: 3.3763666668e+01,
lng: 1.3557288889e+02,
cert : true,
content:'Name = JA/WK-047(JA/WK-047) peak = 711.200012 pos = 33.7637,135.5729 diff = 248.800018'
});
data_saddle.push({
lat: 3.3764111112e+01,
lng: 1.3555155556e+02,
content:'Saddle = 462.399994 pos = 33.7641,135.5516 diff = 248.800018'
});
data_peak.push({
lat: 3.3754666668e+01,
lng: 1.3553022222e+02,
cert : false,
content:' Peak = 683.099976 pos = 33.7547,135.5302 diff = 211.799988'
});
data_saddle.push({
lat: 3.3740888890e+01,
lng: 1.3554155556e+02,
content:'Saddle = 471.299988 pos = 33.7409,135.5416 diff = 211.799988'
});
data_peak.push({
lat: 3.3635000001e+01,
lng: 1.3579411111e+02,
cert : false,
content:' Peak = 527.599976 pos = 33.6350,135.7941 diff = 165.799988'
});
data_saddle.push({
lat: 3.3636444445e+01,
lng: 1.3580033333e+02,
content:'Saddle = 361.799988 pos = 33.6364,135.8003 diff = 165.799988'
});
data_peak.push({
lat: 3.4529888889e+01,
lng: 1.3625866667e+02,
cert : false,
content:' Peak = 569.500000 pos = 34.5299,136.2587 diff = 207.600006'
});
data_saddle.push({
lat: 3.4526111112e+01,
lng: 1.3624855556e+02,
content:'Saddle = 361.899994 pos = 34.5261,136.2486 diff = 207.600006'
});
data_peak.push({
lat: 3.4383444445e+01,
lng: 1.3632455556e+02,
cert : true,
content:'Name = JA/ME-083(JA/ME-083) peak = 541.500000 pos = 34.3834,136.3246 diff = 178.700012'
});
data_saddle.push({
lat: 3.4396111112e+01,
lng: 1.3632144444e+02,
content:'Saddle = 362.799988 pos = 34.3961,136.3214 diff = 178.700012'
});
data_peak.push({
lat: 3.3593666668e+01,
lng: 1.3554688889e+02,
cert : true,
content:'Name = Zenjinomoriyama(JA/WK-065) peak = 590.099976 pos = 33.5937,135.5469 diff = 225.099976'
});
data_saddle.push({
lat: 3.3583777779e+01,
lng: 1.3557244444e+02,
content:'Saddle = 365.000000 pos = 33.5838,135.5724 diff = 225.099976'
});
data_peak.push({
lat: 3.4821444445e+01,
lng: 1.3635566667e+02,
cert : true,
content:'Name = JA/ME-063(JA/ME-063) peak = 672.099976 pos = 34.8214,136.3557 diff = 305.299988'
});
data_saddle.push({
lat: 3.4818888889e+01,
lng: 1.3634222222e+02,
content:'Saddle = 366.799988 pos = 34.8189,136.3422 diff = 305.299988'
});
data_peak.push({
lat: 3.4518444445e+01,
lng: 1.3591077778e+02,
cert : true,
content:'Name = JA/NR-054(JA/NR-054) peak = 524.200012 pos = 34.5184,135.9108 diff = 156.200012'
});
data_saddle.push({
lat: 3.4508666667e+01,
lng: 1.3591166667e+02,
content:'Saddle = 368.000000 pos = 34.5087,135.9117 diff = 156.200012'
});
data_peak.push({
lat: 3.4092111112e+01,
lng: 1.3520622222e+02,
cert : true,
content:'Name = JA/WK-073(JA/WK-073) peak = 541.099976 pos = 34.0921,135.2062 diff = 173.099976'
});
data_saddle.push({
lat: 3.4106777779e+01,
lng: 1.3521444444e+02,
content:'Saddle = 368.000000 pos = 34.1068,135.2144 diff = 173.099976'
});
data_peak.push({
lat: 3.4581333334e+01,
lng: 1.3635422222e+02,
cert : false,
content:' Peak = 550.599976 pos = 34.5813,136.3542 diff = 181.599976'
});
data_saddle.push({
lat: 3.4579222223e+01,
lng: 1.3636422222e+02,
content:'Saddle = 369.000000 pos = 34.5792,136.3642 diff = 181.599976'
});
data_peak.push({
lat: 3.3888111112e+01,
lng: 1.3527566667e+02,
cert : false,
content:' Peak = 522.599976 pos = 33.8881,135.2757 diff = 151.099976'
});
data_saddle.push({
lat: 3.3904111112e+01,
lng: 1.3532366667e+02,
content:'Saddle = 371.500000 pos = 33.9041,135.3237 diff = 151.099976'
});
data_peak.push({
lat: 3.3913777779e+01,
lng: 1.3588933333e+02,
cert : true,
content:'Name = JA/NR-053(JA/NR-053) peak = 541.200012 pos = 33.9138,135.8893 diff = 168.000000'
});
data_saddle.push({
lat: 3.3921222223e+01,
lng: 1.3588900000e+02,
content:'Saddle = 373.200012 pos = 33.9212,135.8890 diff = 168.000000'
});
data_peak.push({
lat: 3.4545444445e+01,
lng: 1.3639155556e+02,
cert : false,
content:' Peak = 541.400024 pos = 34.5454,136.3916 diff = 163.900024'
});
data_saddle.push({
lat: 3.4539888889e+01,
lng: 1.3639455556e+02,
content:'Saddle = 377.500000 pos = 34.5399,136.3946 diff = 163.900024'
});
data_peak.push({
lat: 3.4212888890e+01,
lng: 1.3625311111e+02,
cert : false,
content:' Peak = 542.099976 pos = 34.2129,136.2531 diff = 160.699982'
});
data_saddle.push({
lat: 3.4216444445e+01,
lng: 1.3625177778e+02,
content:'Saddle = 381.399994 pos = 34.2164,136.2518 diff = 160.699982'
});
data_peak.push({
lat: 3.4303444445e+01,
lng: 1.3574922222e+02,
cert : true,
content:'Name = JA/NR-052(JA/NR-052) peak = 617.299988 pos = 34.3034,135.7492 diff = 230.000000'
});
data_saddle.push({
lat: 3.4338444445e+01,
lng: 1.3578244444e+02,
content:'Saddle = 387.299988 pos = 34.3384,135.7824 diff = 230.000000'
});
data_peak.push({
lat: 3.3800666668e+01,
lng: 1.3582355556e+02,
cert : true,
content:'Name = JA/WK-062(JA/WK-062) peak = 608.799988 pos = 33.8007,135.8236 diff = 220.899994'
});
data_saddle.push({
lat: 3.3790555556e+01,
lng: 1.3582011111e+02,
content:'Saddle = 387.899994 pos = 33.7906,135.8201 diff = 220.899994'
});
data_peak.push({
lat: 3.3912555556e+01,
lng: 1.3603900000e+02,
cert : true,
content:'Name = JA/ME-033(JA/ME-033) peak = 850.299988 pos = 33.9126,136.0390 diff = 458.500000'
});
data_saddle.push({
lat: 3.3927888890e+01,
lng: 1.3609477778e+02,
content:'Saddle = 391.799988 pos = 33.9279,136.0948 diff = 458.500000'
});
data_peak.push({
lat: 3.3932111112e+01,
lng: 1.3600622222e+02,
cert : true,
content:'Name = JA/ME-058(JA/ME-058) peak = 721.500000 pos = 33.9321,136.0062 diff = 223.899994'
});
data_saddle.push({
lat: 3.3925666667e+01,
lng: 1.3601433333e+02,
content:'Saddle = 497.600006 pos = 33.9257,136.0143 diff = 223.899994'
});
data_peak.push({
lat: 3.3879111112e+01,
lng: 1.3598277778e+02,
cert : true,
content:'Name = JA/ME-038(JA/ME-038) peak = 813.599976 pos = 33.8791,135.9828 diff = 261.500000'
});
data_saddle.push({
lat: 3.3892444445e+01,
lng: 1.3602233333e+02,
content:'Saddle = 552.099976 pos = 33.8924,136.0223 diff = 261.500000'
});
data_peak.push({
lat: 3.4099000001e+01,
lng: 1.3526877778e+02,
cert : true,
content:'Name = JA/WK-061(JA/WK-061) peak = 613.599976 pos = 34.0990,135.2688 diff = 216.499969'
});
data_saddle.push({
lat: 3.4125000001e+01,
lng: 1.3528733333e+02,
content:'Saddle = 397.100006 pos = 34.1250,135.2873 diff = 216.499969'
});
data_peak.push({
lat: 3.4093111112e+01,
lng: 1.3523411111e+02,
cert : false,
content:' Peak = 584.900024 pos = 34.0931,135.2341 diff = 152.400024'
});
data_saddle.push({
lat: 3.4115555556e+01,
lng: 1.3523555556e+02,
content:'Saddle = 432.500000 pos = 34.1156,135.2356 diff = 152.400024'
});
data_peak.push({
lat: 3.4017777779e+01,
lng: 1.3596344444e+02,
cert : false,
content:' Peak = 702.599976 pos = 34.0178,135.9634 diff = 304.999969'
});
data_saddle.push({
lat: 3.4028111112e+01,
lng: 1.3595588889e+02,
content:'Saddle = 397.600006 pos = 34.0281,135.9559 diff = 304.999969'
});
data_peak.push({
lat: 3.4466111112e+01,
lng: 1.3589200000e+02,
cert : true,
content:'Name = JA/NR-039(JA/NR-039) peak = 903.599976 pos = 34.4661,135.8920 diff = 505.199982'
});
data_saddle.push({
lat: 3.4458111112e+01,
lng: 1.3593433333e+02,
content:'Saddle = 398.399994 pos = 34.4581,135.9343 diff = 505.199982'
});
data_peak.push({
lat: 3.4440777778e+01,
lng: 1.3589766667e+02,
cert : false,
content:' Peak = 903.200012 pos = 34.4408,135.8977 diff = 175.400024'
});
data_saddle.push({
lat: 3.4448777778e+01,
lng: 1.3589166667e+02,
content:'Saddle = 727.799988 pos = 34.4488,135.8917 diff = 175.400024'
});
data_peak.push({
lat: 3.3591333334e+01,
lng: 1.3557777778e+02,
cert : true,
content:'Name = JA/WK-063(JA/WK-063) peak = 606.700012 pos = 33.5913,135.5778 diff = 204.700012'
});
data_saddle.push({
lat: 3.3601666668e+01,
lng: 1.3557855556e+02,
content:'Saddle = 402.000000 pos = 33.6017,135.5786 diff = 204.700012'
});
data_peak.push({
lat: 3.4574000001e+01,
lng: 1.3637000000e+02,
cert : true,
content:'Name = JA/ME-056(JA/ME-056) peak = 730.400024 pos = 34.5740,136.3700 diff = 324.000031'
});
data_saddle.push({
lat: 3.4557222223e+01,
lng: 1.3636211111e+02,
content:'Saddle = 406.399994 pos = 34.5572,136.3621 diff = 324.000031'
});
data_peak.push({
lat: 3.3759000001e+01,
lng: 1.3560466667e+02,
cert : true,
content:'Name = JA/WK-067(JA/WK-067) peak = 571.500000 pos = 33.7590,135.6047 diff = 164.200012'
});
data_saddle.push({
lat: 3.3783777779e+01,
lng: 1.3561077778e+02,
content:'Saddle = 407.299988 pos = 33.7838,135.6108 diff = 164.200012'
});
data_peak.push({
lat: 3.3956666667e+01,
lng: 1.3616866667e+02,
cert : false,
content:' Peak = 580.500000 pos = 33.9567,136.1687 diff = 166.399994'
});
data_saddle.push({
lat: 3.3958111112e+01,
lng: 1.3615966667e+02,
content:'Saddle = 414.100006 pos = 33.9581,136.1597 diff = 166.399994'
});
data_peak.push({
lat: 3.4238111112e+01,
lng: 1.3541455556e+02,
cert : false,
content:' Peak = 753.400024 pos = 34.2381,135.4146 diff = 337.100037'
});
data_saddle.push({
lat: 3.4237777778e+01,
lng: 1.3549177778e+02,
content:'Saddle = 416.299988 pos = 34.2378,135.4918 diff = 337.100037'
});
data_peak.push({
lat: 3.4245555556e+01,
lng: 1.3547811111e+02,
cert : false,
content:' Peak = 616.799988 pos = 34.2456,135.4781 diff = 150.699982'
});
data_saddle.push({
lat: 3.4249444445e+01,
lng: 1.3547422222e+02,
content:'Saddle = 466.100006 pos = 34.2494,135.4742 diff = 150.699982'
});
data_peak.push({
lat: 3.4243777778e+01,
lng: 1.3544944444e+02,
cert : false,
content:' Peak = 744.599976 pos = 34.2438,135.4494 diff = 176.199951'
});
data_saddle.push({
lat: 3.4244555556e+01,
lng: 1.3543944444e+02,
content:'Saddle = 568.400024 pos = 34.2446,135.4394 diff = 176.199951'
});
data_peak.push({
lat: 3.3911888890e+01,
lng: 1.3533433333e+02,
cert : false,
content:' Peak = 623.500000 pos = 33.9119,135.3343 diff = 206.700012'
});
data_saddle.push({
lat: 3.3912555556e+01,
lng: 1.3534366667e+02,
content:'Saddle = 416.799988 pos = 33.9126,135.3437 diff = 206.700012'
});
data_peak.push({
lat: 3.4504888889e+01,
lng: 1.3596666667e+02,
cert : true,
content:'Name = JA/NR-050(JA/NR-050) peak = 635.000000 pos = 34.5049,135.9667 diff = 217.799988'
});
data_saddle.push({
lat: 3.4495111112e+01,
lng: 1.3599022222e+02,
content:'Saddle = 417.200012 pos = 34.4951,135.9902 diff = 217.799988'
});
data_peak.push({
lat: 3.4408555556e+01,
lng: 1.3632955556e+02,
cert : true,
content:'Name = JA/ME-064(JA/ME-064) peak = 674.599976 pos = 34.4086,136.3296 diff = 254.899963'
});
data_saddle.push({
lat: 3.4394000001e+01,
lng: 1.3626277778e+02,
content:'Saddle = 419.700012 pos = 34.3940,136.2628 diff = 254.899963'
});
data_peak.push({
lat: 3.4401888890e+01,
lng: 1.3635488889e+02,
cert : false,
content:' Peak = 611.900024 pos = 34.4019,136.3549 diff = 169.600037'
});
data_saddle.push({
lat: 3.4405444445e+01,
lng: 1.3634622222e+02,
content:'Saddle = 442.299988 pos = 34.4054,136.3462 diff = 169.600037'
});
data_peak.push({
lat: 3.4084555556e+01,
lng: 1.3537744444e+02,
cert : true,
content:'Name = JA/WK-060(JA/WK-060) peak = 617.799988 pos = 34.0846,135.3774 diff = 197.399994'
});
data_saddle.push({
lat: 3.4077555556e+01,
lng: 1.3537733333e+02,
content:'Saddle = 420.399994 pos = 34.0776,135.3773 diff = 197.399994'
});
data_peak.push({
lat: 3.3785666668e+01,
lng: 1.3547344444e+02,
cert : true,
content:'Name = JA/WK-034(JA/WK-034) peak = 795.200012 pos = 33.7857,135.4734 diff = 372.400024'
});
data_saddle.push({
lat: 3.3828666668e+01,
lng: 1.3546422222e+02,
content:'Saddle = 422.799988 pos = 33.8287,135.4642 diff = 372.400024'
});
data_peak.push({
lat: 3.4505888889e+01,
lng: 1.3640733333e+02,
cert : true,
content:'Name = JA/ME-035(JA/ME-035) peak = 817.700012 pos = 34.5059,136.4073 diff = 386.000000'
});
data_saddle.push({
lat: 3.4490444445e+01,
lng: 1.3633733333e+02,
content:'Saddle = 431.700012 pos = 34.4904,136.3373 diff = 386.000000'
});
data_peak.push({
lat: 3.4546666667e+01,
lng: 1.3643288889e+02,
cert : true,
content:'Name = Hossakasan(JA/ME-050) peak = 750.799988 pos = 34.5467,136.4329 diff = 313.199982'
});
data_saddle.push({
lat: 3.4535222223e+01,
lng: 1.3641055556e+02,
content:'Saddle = 437.600006 pos = 34.5352,136.4106 diff = 313.199982'
});
data_peak.push({
lat: 3.4550111112e+01,
lng: 1.3636055556e+02,
cert : true,
content:'Name = JA/ME-061(JA/ME-061) peak = 681.099976 pos = 34.5501,136.3606 diff = 209.299988'
});
data_saddle.push({
lat: 3.4537777778e+01,
lng: 1.3634833333e+02,
content:'Saddle = 471.799988 pos = 34.5378,136.3483 diff = 209.299988'
});
data_peak.push({
lat: 3.4532666667e+01,
lng: 1.3632677778e+02,
cert : false,
content:' Peak = 693.099976 pos = 34.5327,136.3268 diff = 154.299988'
});
data_saddle.push({
lat: 3.4529000001e+01,
lng: 1.3633777778e+02,
content:'Saddle = 538.799988 pos = 34.5290,136.3378 diff = 154.299988'
});
data_peak.push({
lat: 3.4002666667e+01,
lng: 1.3527633333e+02,
cert : true,
content:'Name = JA/WK-058(JA/WK-058) peak = 661.000000 pos = 34.0027,135.2763 diff = 229.200012'
});
data_saddle.push({
lat: 3.4005444445e+01,
lng: 1.3529666667e+02,
content:'Saddle = 431.799988 pos = 34.0054,135.2967 diff = 229.200012'
});
data_peak.push({
lat: 3.3974000001e+01,
lng: 1.3525911111e+02,
cert : false,
content:' Peak = 650.400024 pos = 33.9740,135.2591 diff = 163.800018'
});
data_saddle.push({
lat: 3.3984111112e+01,
lng: 1.3525788889e+02,
content:'Saddle = 486.600006 pos = 33.9841,135.2579 diff = 163.800018'
});
data_peak.push({
lat: 3.3710666668e+01,
lng: 1.3586088889e+02,
cert : false,
content:' Peak = 964.700012 pos = 33.7107,135.8609 diff = 527.200012'
});
data_saddle.push({
lat: 3.3697555556e+01,
lng: 1.3580822222e+02,
content:'Saddle = 437.500000 pos = 33.6976,135.8082 diff = 527.200012'
});
data_peak.push({
lat: 3.3777111112e+01,
lng: 1.3586633333e+02,
cert : false,
content:' Peak = 640.900024 pos = 33.7771,135.8663 diff = 155.000031'
});
data_saddle.push({
lat: 3.3772333334e+01,
lng: 1.3586522222e+02,
content:'Saddle = 485.899994 pos = 33.7723,135.8652 diff = 155.000031'
});
data_peak.push({
lat: 3.3680777779e+01,
lng: 1.3592033333e+02,
cert : false,
content:' Peak = 683.900024 pos = 33.6808,135.9203 diff = 190.600037'
});
data_saddle.push({
lat: 3.3684000001e+01,
lng: 1.3590622222e+02,
content:'Saddle = 493.299988 pos = 33.6840,135.9062 diff = 190.600037'
});
data_peak.push({
lat: 3.3659777779e+01,
lng: 1.3588333333e+02,
cert : true,
content:'Name = JA/WK-044(JA/WK-044) peak = 748.099976 pos = 33.6598,135.8833 diff = 205.799988'
});
data_saddle.push({
lat: 3.3669111112e+01,
lng: 1.3588133333e+02,
content:'Saddle = 542.299988 pos = 33.6691,135.8813 diff = 205.799988'
});
data_peak.push({
lat: 3.3699333334e+01,
lng: 1.3589100000e+02,
cert : true,
content:'Name = JA/WK-018(JA/WK-018) peak = 935.700012 pos = 33.6993,135.8910 diff = 204.000000'
});
data_saddle.push({
lat: 3.3696555556e+01,
lng: 1.3588077778e+02,
content:'Saddle = 731.700012 pos = 33.6966,135.8808 diff = 204.000000'
});
data_peak.push({
lat: 3.4554333334e+01,
lng: 1.3629155556e+02,
cert : true,
content:'Name = JA/ME-047(JA/ME-047) peak = 773.099976 pos = 34.5543,136.2916 diff = 335.099976'
});
data_saddle.push({
lat: 3.4526666667e+01,
lng: 1.3629000000e+02,
content:'Saddle = 438.000000 pos = 34.5267,136.2900 diff = 335.099976'
});
data_peak.push({
lat: 3.4571111112e+01,
lng: 1.3631366667e+02,
cert : true,
content:'Name = JA/ME-052(JA/ME-052) peak = 744.500000 pos = 34.5711,136.3137 diff = 167.200012'
});
data_saddle.push({
lat: 3.4560444445e+01,
lng: 1.3629888889e+02,
content:'Saddle = 577.299988 pos = 34.5604,136.2989 diff = 167.200012'
});
data_peak.push({
lat: 3.3630555557e+01,
lng: 1.3573977778e+02,
cert : true,
content:'Name = JA/WK-059(JA/WK-059) peak = 632.200012 pos = 33.6306,135.7398 diff = 190.600006'
});
data_saddle.push({
lat: 3.3648777779e+01,
lng: 1.3574477778e+02,
content:'Saddle = 441.600006 pos = 33.6488,135.7448 diff = 190.600006'
});
data_peak.push({
lat: 3.3728555556e+01,
lng: 1.3579288889e+02,
cert : true,
content:'Name = JA/WK-039(JA/WK-039) peak = 771.400024 pos = 33.7286,135.7929 diff = 325.600037'
});
data_saddle.push({
lat: 3.3712000001e+01,
lng: 1.3579577778e+02,
content:'Saddle = 445.799988 pos = 33.7120,135.7958 diff = 325.600037'
});
data_peak.push({
lat: 3.3955222223e+01,
lng: 1.3535200000e+02,
cert : false,
content:' Peak = 635.599976 pos = 33.9552,135.3520 diff = 184.399963'
});
data_saddle.push({
lat: 3.3945222223e+01,
lng: 1.3535044444e+02,
content:'Saddle = 451.200012 pos = 33.9452,135.3504 diff = 184.399963'
});
data_peak.push({
lat: 3.4327555556e+01,
lng: 1.3580511111e+02,
cert : true,
content:'Name = JA/NR-051(JA/NR-051) peak = 634.599976 pos = 34.3276,135.8051 diff = 178.099976'
});
data_saddle.push({
lat: 3.4335111112e+01,
lng: 1.3581277778e+02,
content:'Saddle = 456.500000 pos = 34.3351,135.8128 diff = 178.099976'
});
data_peak.push({
lat: 3.4407777778e+01,
lng: 1.3598877778e+02,
cert : false,
content:' Peak = 687.500000 pos = 34.4078,135.9888 diff = 230.799988'
});
data_saddle.push({
lat: 3.4423000001e+01,
lng: 1.3601466667e+02,
content:'Saddle = 456.700012 pos = 34.4230,136.0147 diff = 230.799988'
});
data_peak.push({
lat: 3.3936222223e+01,
lng: 1.3539300000e+02,
cert : true,
content:'Name = JA/WK-024(JA/WK-024) peak = 872.299988 pos = 33.9362,135.3930 diff = 408.799988'
});
data_saddle.push({
lat: 3.3880555556e+01,
lng: 1.3541933333e+02,
content:'Saddle = 463.500000 pos = 33.8806,135.4193 diff = 408.799988'
});
data_peak.push({
lat: 3.3912222223e+01,
lng: 1.3542800000e+02,
cert : false,
content:' Peak = 633.900024 pos = 33.9122,135.4280 diff = 158.700012'
});
data_saddle.push({
lat: 3.3908777779e+01,
lng: 1.3542388889e+02,
content:'Saddle = 475.200012 pos = 33.9088,135.4239 diff = 158.700012'
});
data_peak.push({
lat: 3.3886111112e+01,
lng: 1.3538622222e+02,
cert : true,
content:'Name = JA/WK-041(JA/WK-041) peak = 771.000000 pos = 33.8861,135.3862 diff = 258.099976'
});
data_saddle.push({
lat: 3.3913888890e+01,
lng: 1.3539555556e+02,
content:'Saddle = 512.900024 pos = 33.9139,135.3956 diff = 258.099976'
});
data_peak.push({
lat: 3.3932555556e+01,
lng: 1.3535544444e+02,
cert : true,
content:'Name = JA/WK-031(JA/WK-031) peak = 810.599976 pos = 33.9326,135.3554 diff = 291.799988'
});
data_saddle.push({
lat: 3.3921777779e+01,
lng: 1.3536277778e+02,
content:'Saddle = 518.799988 pos = 33.9218,135.3628 diff = 291.799988'
});
data_peak.push({
lat: 3.3915000001e+01,
lng: 1.3536355556e+02,
cert : true,
content:'Name = JA/WK-043(JA/WK-043) peak = 750.799988 pos = 33.9150,135.3636 diff = 173.599976'
});
data_saddle.push({
lat: 3.3917666667e+01,
lng: 1.3539355556e+02,
content:'Saddle = 577.200012 pos = 33.9177,135.3936 diff = 173.599976'
});
data_peak.push({
lat: 3.4078111112e+01,
lng: 1.3533544444e+02,
cert : true,
content:'Name = JA/WK-052(JA/WK-052) peak = 685.799988 pos = 34.0781,135.3354 diff = 219.299988'
});
data_saddle.push({
lat: 3.4084555556e+01,
lng: 1.3534455556e+02,
content:'Saddle = 466.500000 pos = 34.0846,135.3446 diff = 219.299988'
});
data_peak.push({
lat: 3.4538666667e+01,
lng: 1.3621488889e+02,
cert : true,
content:'Name = JA/ME-022(JA/ME-022) peak = 1012.099976 pos = 34.5387,136.2149 diff = 543.899963'
});
data_saddle.push({
lat: 3.4516666667e+01,
lng: 1.3620288889e+02,
content:'Saddle = 468.200012 pos = 34.5167,136.2029 diff = 543.899963'
});
data_peak.push({
lat: 3.4766555556e+01,
lng: 1.3637433333e+02,
cert : true,
content:'Name = Kyougamine(JA/ME-036) peak = 818.200012 pos = 34.7666,136.3743 diff = 321.600006'
});
data_saddle.push({
lat: 3.4761666667e+01,
lng: 1.3632688889e+02,
content:'Saddle = 496.600006 pos = 34.7617,136.3269 diff = 321.600006'
});
data_peak.push({
lat: 3.4809222223e+01,
lng: 1.3630122222e+02,
cert : true,
content:'Name = JA/ME-041(JA/ME-041) peak = 793.700012 pos = 34.8092,136.3012 diff = 291.300018'
});
data_saddle.push({
lat: 3.4779888889e+01,
lng: 1.3633677778e+02,
content:'Saddle = 502.399994 pos = 34.7799,136.3368 diff = 291.300018'
});
data_peak.push({
lat: 3.4817222223e+01,
lng: 1.3626044444e+02,
cert : true,
content:'Name = Reisan(JA/ME-049) peak = 765.500000 pos = 34.8172,136.2604 diff = 213.400024'
});
data_saddle.push({
lat: 3.4812333334e+01,
lng: 1.3628366667e+02,
content:'Saddle = 552.099976 pos = 34.8123,136.2837 diff = 213.400024'
});
data_peak.push({
lat: 3.4734000001e+01,
lng: 1.3629633333e+02,
cert : true,
content:'Name = Kasatoriyama(JA/ME-034) peak = 841.400024 pos = 34.7340,136.2963 diff = 343.000031'
});
data_saddle.push({
lat: 3.4670666667e+01,
lng: 1.3626811111e+02,
content:'Saddle = 498.399994 pos = 34.6707,136.2681 diff = 343.000031'
});
data_peak.push({
lat: 3.4601111112e+01,
lng: 1.3624977778e+02,
cert : true,
content:'Name = JA/ME-043(JA/ME-043) peak = 777.700012 pos = 34.6011,136.2498 diff = 204.600037'
});
data_saddle.push({
lat: 3.4592000001e+01,
lng: 1.3625666667e+02,
content:'Saddle = 573.099976 pos = 34.5920,136.2567 diff = 204.600037'
});
data_peak.push({
lat: 3.4579333334e+01,
lng: 1.3622877778e+02,
cert : false,
content:' Peak = 763.000000 pos = 34.5793,136.2288 diff = 175.000000'
});
data_saddle.push({
lat: 3.4573444445e+01,
lng: 1.3622388889e+02,
content:'Saddle = 588.000000 pos = 34.5734,136.2239 diff = 175.000000'
});
data_peak.push({
lat: 3.4557333334e+01,
lng: 1.3621955556e+02,
cert : true,
content:'Name = Amagadake(JA/ME-024) peak = 960.700012 pos = 34.5573,136.2196 diff = 209.600037'
});
data_saddle.push({
lat: 3.4551666667e+01,
lng: 1.3621433333e+02,
content:'Saddle = 751.099976 pos = 34.5517,136.2143 diff = 209.600037'
});
data_peak.push({
lat: 3.3770777779e+01,
lng: 1.3578666667e+02,
cert : true,
content:'Name = JA/WK-051(JA/WK-051) peak = 693.000000 pos = 33.7708,135.7867 diff = 220.799988'
});
data_saddle.push({
lat: 3.3769666668e+01,
lng: 1.3577144444e+02,
content:'Saddle = 472.200012 pos = 33.7697,135.7714 diff = 220.799988'
});
data_peak.push({
lat: 3.4270777778e+01,
lng: 1.3634177778e+02,
cert : true,
content:'Name = JA/ME-066(JA/ME-066) peak = 635.799988 pos = 34.2708,136.3418 diff = 163.000000'
});
data_saddle.push({
lat: 3.4279444445e+01,
lng: 1.3634366667e+02,
content:'Saddle = 472.799988 pos = 34.2794,136.3437 diff = 163.000000'
});
data_peak.push({
lat: 3.3985222223e+01,
lng: 1.3540266667e+02,
cert : true,
content:'Name = JA/WK-057(JA/WK-057) peak = 672.000000 pos = 33.9852,135.4027 diff = 199.000000'
});
data_saddle.push({
lat: 3.3993222223e+01,
lng: 1.3539344444e+02,
content:'Saddle = 473.000000 pos = 33.9932,135.3934 diff = 199.000000'
});
data_peak.push({
lat: 3.3957777779e+01,
lng: 1.3596133333e+02,
cert : true,
content:'Name = JA/WK-049(JA/WK-049) peak = 701.700012 pos = 33.9578,135.9613 diff = 219.500000'
});
data_saddle.push({
lat: 3.3962000001e+01,
lng: 1.3595922222e+02,
content:'Saddle = 482.200012 pos = 33.9620,135.9592 diff = 219.500000'
});
data_peak.push({
lat: 3.3622333334e+01,
lng: 1.3563200000e+02,
cert : true,
content:'Name = JA/WK-054(JA/WK-054) peak = 682.599976 pos = 33.6223,135.6320 diff = 200.099976'
});
data_saddle.push({
lat: 3.3626555557e+01,
lng: 1.3564255556e+02,
content:'Saddle = 482.500000 pos = 33.6266,135.6426 diff = 200.099976'
});
data_peak.push({
lat: 3.4197555556e+01,
lng: 1.3546766667e+02,
cert : true,
content:'Name = JA/WK-040(JA/WK-040) peak = 773.099976 pos = 34.1976,135.4677 diff = 289.399963'
});
data_saddle.push({
lat: 3.4219555556e+01,
lng: 1.3553733333e+02,
content:'Saddle = 483.700012 pos = 34.2196,135.5373 diff = 289.399963'
});
data_peak.push({
lat: 3.4267333334e+01,
lng: 1.3553155556e+02,
cert : false,
content:' Peak = 683.200012 pos = 34.2673,135.5316 diff = 180.400024'
});
data_saddle.push({
lat: 3.4223111112e+01,
lng: 1.3552044444e+02,
content:'Saddle = 502.799988 pos = 34.2231,135.5204 diff = 180.400024'
});
data_peak.push({
lat: 3.4251222223e+01,
lng: 1.3550322222e+02,
cert : false,
content:' Peak = 674.599976 pos = 34.2512,135.5032 diff = 156.299988'
});
data_saddle.push({
lat: 3.4257111112e+01,
lng: 1.3550022222e+02,
content:'Saddle = 518.299988 pos = 34.2571,135.5002 diff = 156.299988'
});
data_peak.push({
lat: 3.3931333334e+01,
lng: 1.3611577778e+02,
cert : true,
content:'Name = JA/ME-062(JA/ME-062) peak = 686.299988 pos = 33.9313,136.1158 diff = 197.099976'
});
data_saddle.push({
lat: 3.3944666667e+01,
lng: 1.3610988889e+02,
content:'Saddle = 489.200012 pos = 33.9447,136.1099 diff = 197.099976'
});
data_peak.push({
lat: 3.4067111112e+01,
lng: 1.3540666667e+02,
cert : true,
content:'Name = JA/WK-050(JA/WK-050) peak = 700.599976 pos = 34.0671,135.4067 diff = 189.799988'
});
data_saddle.push({
lat: 3.4056444445e+01,
lng: 1.3543477778e+02,
content:'Saddle = 510.799988 pos = 34.0564,135.4348 diff = 189.799988'
});
data_peak.push({
lat: 3.4536666667e+01,
lng: 1.3602477778e+02,
cert : false,
content:' Peak = 676.400024 pos = 34.5367,136.0248 diff = 163.800049'
});
data_saddle.push({
lat: 3.4531444445e+01,
lng: 1.3603366667e+02,
content:'Saddle = 512.599976 pos = 34.5314,136.0337 diff = 163.800049'
});
data_peak.push({
lat: 3.4317444445e+01,
lng: 1.3583855556e+02,
cert : true,
content:'Name = JA/NR-046(JA/NR-046) peak = 692.500000 pos = 34.3174,135.8386 diff = 170.700012'
});
data_saddle.push({
lat: 3.4320444445e+01,
lng: 1.3584833333e+02,
content:'Saddle = 521.799988 pos = 34.3204,135.8483 diff = 170.700012'
});
data_peak.push({
lat: 3.3676444445e+01,
lng: 1.3560344444e+02,
cert : true,
content:'Name = JA/WK-048(JA/WK-048) peak = 713.000000 pos = 33.6764,135.6034 diff = 181.700012'
});
data_saddle.push({
lat: 3.3682555556e+01,
lng: 1.3560422222e+02,
content:'Saddle = 531.299988 pos = 33.6826,135.6042 diff = 181.700012'
});
data_peak.push({
lat: 3.4023111112e+01,
lng: 1.3619922222e+02,
cert : true,
content:'Name = JA/ME-051(JA/ME-051) peak = 751.400024 pos = 34.0231,136.1992 diff = 218.500000'
});
data_saddle.push({
lat: 3.4017666667e+01,
lng: 1.3618755556e+02,
content:'Saddle = 532.900024 pos = 34.0177,136.1876 diff = 218.500000'
});
data_peak.push({
lat: 3.4498777778e+01,
lng: 1.3631611111e+02,
cert : false,
content:' Peak = 691.799988 pos = 34.4988,136.3161 diff = 153.099976'
});
data_saddle.push({
lat: 3.4487888889e+01,
lng: 1.3632511111e+02,
content:'Saddle = 538.700012 pos = 34.4879,136.3251 diff = 153.099976'
});
data_peak.push({
lat: 3.3726888890e+01,
lng: 1.3571377778e+02,
cert : true,
content:'Name = Ootouzan(JA/WK-004) peak = 1121.599976 pos = 33.7269,135.7138 diff = 582.699951'
});
data_saddle.push({
lat: 3.3835555556e+01,
lng: 1.3565700000e+02,
content:'Saddle = 538.900024 pos = 33.8356,135.6570 diff = 582.699951'
});
data_peak.push({
lat: 3.3795555556e+01,
lng: 1.3570033333e+02,
cert : false,
content:' Peak = 740.200012 pos = 33.7956,135.7003 diff = 158.000000'
});
data_saddle.push({
lat: 3.3798555556e+01,
lng: 1.3569077778e+02,
content:'Saddle = 582.200012 pos = 33.7986,135.6908 diff = 158.000000'
});
data_peak.push({
lat: 3.3749555556e+01,
lng: 1.3574900000e+02,
cert : true,
content:'Name = JA/WK-036(JA/WK-036) peak = 784.000000 pos = 33.7496,135.7490 diff = 197.599976'
});
data_saddle.push({
lat: 3.3745000001e+01,
lng: 1.3574644444e+02,
content:'Saddle = 586.400024 pos = 33.7450,135.7464 diff = 197.599976'
});
data_peak.push({
lat: 3.3764888890e+01,
lng: 1.3562355556e+02,
cert : false,
content:' Peak = 846.200012 pos = 33.7649,135.6236 diff = 183.700012'
});
data_saddle.push({
lat: 3.3774888890e+01,
lng: 1.3564788889e+02,
content:'Saddle = 662.500000 pos = 33.7749,135.6479 diff = 183.700012'
});
data_peak.push({
lat: 3.3779888890e+01,
lng: 1.3568044444e+02,
cert : true,
content:'Name = JA/WK-011(JA/WK-011) peak = 971.500000 pos = 33.7799,135.6804 diff = 298.799988'
});
data_saddle.push({
lat: 3.3742555556e+01,
lng: 1.3569755556e+02,
content:'Saddle = 672.700012 pos = 33.7426,135.6976 diff = 298.799988'
});
data_peak.push({
lat: 3.3817222223e+01,
lng: 1.3565344444e+02,
cert : true,
content:'Name = JA/WK-020(JA/WK-020) peak = 922.500000 pos = 33.8172,135.6534 diff = 245.000000'
});
data_saddle.push({
lat: 3.3797111112e+01,
lng: 1.3566600000e+02,
content:'Saddle = 677.500000 pos = 33.7971,135.6660 diff = 245.000000'
});
data_peak.push({
lat: 3.3700333334e+01,
lng: 1.3562277778e+02,
cert : true,
content:'Name = JA/WK-025(JA/WK-025) peak = 872.299988 pos = 33.7003,135.6228 diff = 193.599976'
});
data_saddle.push({
lat: 3.3720222223e+01,
lng: 1.3564277778e+02,
content:'Saddle = 678.700012 pos = 33.7202,135.6428 diff = 193.599976'
});
data_peak.push({
lat: 3.3687111112e+01,
lng: 1.3565433333e+02,
cert : true,
content:'Name = JA/WK-017(JA/WK-017) peak = 941.200012 pos = 33.6871,135.6543 diff = 238.799988'
});
data_saddle.push({
lat: 3.3700555556e+01,
lng: 1.3568588889e+02,
content:'Saddle = 702.400024 pos = 33.7006,135.6859 diff = 238.799988'
});
data_peak.push({
lat: 3.3726000001e+01,
lng: 1.3566533333e+02,
cert : true,
content:'Name = Houshiyama(JA/WK-005) peak = 1120.099976 pos = 33.7260,135.6653 diff = 289.299988'
});
data_saddle.push({
lat: 3.3724555556e+01,
lng: 1.3569766667e+02,
content:'Saddle = 830.799988 pos = 33.7246,135.6977 diff = 289.299988'
});
data_peak.push({
lat: 3.4263111112e+01,
lng: 1.3630833333e+02,
cert : true,
content:'Name = JA/ME-053(JA/ME-053) peak = 733.500000 pos = 34.2631,136.3083 diff = 191.700012'
});
data_saddle.push({
lat: 3.4265555556e+01,
lng: 1.3629722222e+02,
content:'Saddle = 541.799988 pos = 34.2656,136.2972 diff = 191.700012'
});
data_peak.push({
lat: 3.4494777778e+01,
lng: 1.3628333333e+02,
cert : true,
content:'Name = JA/ME-057(JA/ME-057) peak = 725.700012 pos = 34.4948,136.2833 diff = 181.600037'
});
data_saddle.push({
lat: 3.4487333334e+01,
lng: 1.3628433333e+02,
content:'Saddle = 544.099976 pos = 34.4873,136.2843 diff = 181.600037'
});
data_peak.push({
lat: 3.3843888890e+01,
lng: 1.3570233333e+02,
cert : true,
content:'Name = JA/WK-038(JA/WK-038) peak = 776.000000 pos = 33.8439,135.7023 diff = 223.299988'
});
data_saddle.push({
lat: 3.3848222223e+01,
lng: 1.3569733333e+02,
content:'Saddle = 552.700012 pos = 33.8482,135.6973 diff = 223.299988'
});
data_peak.push({
lat: 3.4332555556e+01,
lng: 1.3584033333e+02,
cert : false,
content:' Peak = 721.299988 pos = 34.3326,135.8403 diff = 163.099976'
});
data_saddle.push({
lat: 3.4327777778e+01,
lng: 1.3585688889e+02,
content:'Saddle = 558.200012 pos = 34.3278,135.8569 diff = 163.099976'
});
data_peak.push({
lat: 3.4531000001e+01,
lng: 1.3617033333e+02,
cert : true,
content:'Name = Kurosoyama(JA/ME-018) peak = 1036.599976 pos = 34.5310,136.1703 diff = 478.399963'
});
data_saddle.push({
lat: 3.4486111112e+01,
lng: 1.3615322222e+02,
content:'Saddle = 558.200012 pos = 34.4861,136.1532 diff = 478.399963'
});
data_peak.push({
lat: 3.4494000001e+01,
lng: 1.3612811111e+02,
cert : true,
content:'Name = JA/NR-044(JA/NR-044) peak = 791.799988 pos = 34.4940,136.1281 diff = 173.200012'
});
data_saddle.push({
lat: 3.4496333334e+01,
lng: 1.3614366667e+02,
content:'Saddle = 618.599976 pos = 34.4963,136.1437 diff = 173.200012'
});
data_peak.push({
lat: 3.4502666667e+01,
lng: 1.3615155556e+02,
cert : false,
content:' Peak = 956.099976 pos = 34.5027,136.1516 diff = 269.599976'
});
data_saddle.push({
lat: 3.4514888889e+01,
lng: 1.3615966667e+02,
content:'Saddle = 686.500000 pos = 34.5149,136.1597 diff = 269.599976'
});
data_peak.push({
lat: 3.4548444445e+01,
lng: 1.3616200000e+02,
cert : true,
content:'Name = JA/ME-032(JA/ME-032) peak = 881.400024 pos = 34.5484,136.1620 diff = 169.900024'
});
data_saddle.push({
lat: 3.4542222223e+01,
lng: 1.3616422222e+02,
content:'Saddle = 711.500000 pos = 34.5422,136.1642 diff = 169.900024'
});
data_peak.push({
lat: 3.3802111112e+01,
lng: 1.3556822222e+02,
cert : true,
content:'Name = JA/WK-037(JA/WK-037) peak = 781.200012 pos = 33.8021,135.5682 diff = 222.400024'
});
data_saddle.push({
lat: 3.3814666668e+01,
lng: 1.3558411111e+02,
content:'Saddle = 558.799988 pos = 33.8147,135.5841 diff = 222.400024'
});
data_peak.push({
lat: 3.3791111112e+01,
lng: 1.3554877778e+02,
cert : false,
content:' Peak = 735.500000 pos = 33.7911,135.5488 diff = 174.099976'
});
data_saddle.push({
lat: 3.3797666668e+01,
lng: 1.3555677778e+02,
content:'Saddle = 561.400024 pos = 33.7977,135.5568 diff = 174.099976'
});
data_peak.push({
lat: 3.3973888890e+01,
lng: 1.3578411111e+02,
cert : true,
content:'Name = JA/NR-041(JA/NR-041) peak = 862.700012 pos = 33.9739,135.7841 diff = 290.400024'
});
data_saddle.push({
lat: 3.3981888890e+01,
lng: 1.3577722222e+02,
content:'Saddle = 572.299988 pos = 33.9819,135.7772 diff = 290.400024'
});
data_peak.push({
lat: 3.3836555556e+01,
lng: 1.3560044444e+02,
cert : true,
content:'Name = JA/WK-030(JA/WK-030) peak = 821.000000 pos = 33.8366,135.6004 diff = 237.599976'
});
data_saddle.push({
lat: 3.3847444445e+01,
lng: 1.3559777778e+02,
content:'Saddle = 583.400024 pos = 33.8474,135.5978 diff = 237.599976'
});
data_peak.push({
lat: 3.3960888890e+01,
lng: 1.3613055556e+02,
cert : true,
content:'Name = JA/ME-046(JA/ME-046) peak = 774.200012 pos = 33.9609,136.1306 diff = 182.200012'
});
data_saddle.push({
lat: 3.3963777779e+01,
lng: 1.3613577778e+02,
content:'Saddle = 592.000000 pos = 33.9638,136.1358 diff = 182.200012'
});
data_peak.push({
lat: 3.4257888890e+01,
lng: 1.3567444444e+02,
cert : true,
content:'Name = JA/WK-023(JA/WK-023) peak = 890.700012 pos = 34.2579,135.6744 diff = 293.700012'
});
data_saddle.push({
lat: 3.4261777778e+01,
lng: 1.3569800000e+02,
content:'Saddle = 597.000000 pos = 34.2618,135.6980 diff = 293.700012'
});
data_peak.push({
lat: 3.4104888890e+01,
lng: 1.3533433333e+02,
cert : true,
content:'Name = Oishigamine(JA/WK-027) peak = 870.000000 pos = 34.1049,135.3343 diff = 272.700012'
});
data_saddle.push({
lat: 3.4120888890e+01,
lng: 1.3540088889e+02,
content:'Saddle = 597.299988 pos = 34.1209,135.4009 diff = 272.700012'
});
data_peak.push({
lat: 3.4113222223e+01,
lng: 1.3537455556e+02,
cert : true,
content:'Name = JA/WK-026(JA/WK-026) peak = 869.400024 pos = 34.1132,135.3746 diff = 270.600037'
});
data_saddle.push({
lat: 3.4114111112e+01,
lng: 1.3534000000e+02,
content:'Saddle = 598.799988 pos = 34.1141,135.3400 diff = 270.600037'
});
data_peak.push({
lat: 3.4246222223e+01,
lng: 1.3621733333e+02,
cert : true,
content:'Name = JA/ME-013(JA/ME-013) peak = 1094.599976 pos = 34.2462,136.2173 diff = 497.299988'
});
data_saddle.push({
lat: 3.4200111112e+01,
lng: 1.3618977778e+02,
content:'Saddle = 597.299988 pos = 34.2001,136.1898 diff = 497.299988'
});
data_peak.push({
lat: 3.4289111112e+01,
lng: 1.3626911111e+02,
cert : true,
content:'Name = JA/ME-017(JA/ME-017) peak = 1037.599976 pos = 34.2891,136.2691 diff = 338.599976'
});
data_saddle.push({
lat: 3.4263666667e+01,
lng: 1.3625200000e+02,
content:'Saddle = 699.000000 pos = 34.2637,136.2520 diff = 338.599976'
});
data_peak.push({
lat: 3.4321000001e+01,
lng: 1.3632277778e+02,
cert : true,
content:'Name = JA/ME-026(JA/ME-026) peak = 951.700012 pos = 34.3210,136.3228 diff = 224.500000'
});
data_saddle.push({
lat: 3.4310777778e+01,
lng: 1.3632100000e+02,
content:'Saddle = 727.200012 pos = 34.3108,136.3210 diff = 224.500000'
});
data_peak.push({
lat: 3.4225000001e+01,
lng: 1.3619044444e+02,
cert : true,
content:'Name = JA/ME-030(JA/ME-030) peak = 888.700012 pos = 34.2250,136.1904 diff = 176.200012'
});
data_saddle.push({
lat: 3.4221777778e+01,
lng: 1.3620755556e+02,
content:'Saddle = 712.500000 pos = 34.2218,136.2076 diff = 176.200012'
});
data_peak.push({
lat: 3.4404444445e+01,
lng: 1.3615644444e+02,
cert : true,
content:'Name = JA/ME-025(JA/ME-025) peak = 953.500000 pos = 34.4044,136.1564 diff = 336.799988'
});
data_saddle.push({
lat: 3.4399888890e+01,
lng: 1.3613800000e+02,
content:'Saddle = 616.700012 pos = 34.3999,136.1380 diff = 336.799988'
});
data_peak.push({
lat: 3.3856555556e+01,
lng: 1.3569511111e+02,
cert : true,
content:'Name = JA/WK-032(JA/WK-032) peak = 805.200012 pos = 33.8566,135.6951 diff = 182.299988'
});
data_saddle.push({
lat: 3.3864666668e+01,
lng: 1.3568133333e+02,
content:'Saddle = 622.900024 pos = 33.8647,135.6813 diff = 182.299988'
});
data_peak.push({
lat: 3.4035777779e+01,
lng: 1.3601811111e+02,
cert : true,
content:'Name = JA/ME-023(JA/ME-023) peak = 990.500000 pos = 34.0358,136.0181 diff = 358.200012'
});
data_saddle.push({
lat: 3.4016444445e+01,
lng: 1.3605722222e+02,
content:'Saddle = 632.299988 pos = 34.0164,136.0572 diff = 358.200012'
});
data_peak.push({
lat: 3.3905777779e+01,
lng: 1.3554788889e+02,
cert : false,
content:' Peak = 795.299988 pos = 33.9058,135.5479 diff = 162.099976'
});
data_saddle.push({
lat: 3.3922888890e+01,
lng: 1.3556188889e+02,
content:'Saddle = 633.200012 pos = 33.9229,135.5619 diff = 162.099976'
});
data_peak.push({
lat: 3.4516555556e+01,
lng: 1.3609333333e+02,
cert : true,
content:'Name = JA/NR-036(JA/NR-036) peak = 1013.299988 pos = 34.5166,136.0933 diff = 371.000000'
});
data_saddle.push({
lat: 3.4496111112e+01,
lng: 1.3608500000e+02,
content:'Saddle = 642.299988 pos = 34.4961,136.0850 diff = 371.000000'
});
data_peak.push({
lat: 3.4525888889e+01,
lng: 1.3612055556e+02,
cert : true,
content:'Name = JA/NR-038(JA/NR-038) peak = 922.700012 pos = 34.5259,136.1206 diff = 265.700012'
});
data_saddle.push({
lat: 3.4528000001e+01,
lng: 1.3611566667e+02,
content:'Saddle = 657.000000 pos = 34.5280,136.1157 diff = 265.700012'
});
data_peak.push({
lat: 3.4528888889e+01,
lng: 1.3613022222e+02,
cert : false,
content:' Peak = 892.599976 pos = 34.5289,136.1302 diff = 164.399963'
});
data_saddle.push({
lat: 3.4529777778e+01,
lng: 1.3612455556e+02,
content:'Saddle = 728.200012 pos = 34.5298,136.1246 diff = 164.399963'
});
data_peak.push({
lat: 3.4114444445e+01,
lng: 1.3545844444e+02,
cert : true,
content:'Name = JA/WK-033(JA/WK-033) peak = 800.799988 pos = 34.1144,135.4584 diff = 158.399963'
});
data_saddle.push({
lat: 3.4118333334e+01,
lng: 1.3545544444e+02,
content:'Saddle = 642.400024 pos = 34.1183,135.4554 diff = 158.399963'
});
data_peak.push({
lat: 3.3981333334e+01,
lng: 1.3612055556e+02,
cert : false,
content:' Peak = 853.500000 pos = 33.9813,136.1206 diff = 201.799988'
});
data_saddle.push({
lat: 3.3984333334e+01,
lng: 1.3612633333e+02,
content:'Saddle = 651.700012 pos = 33.9843,136.1263 diff = 201.799988'
});
data_peak.push({
lat: 3.3927222223e+01,
lng: 1.3556544444e+02,
cert : false,
content:' Peak = 819.799988 pos = 33.9272,135.5654 diff = 167.599976'
});
data_saddle.push({
lat: 3.3929666667e+01,
lng: 1.3557422222e+02,
content:'Saddle = 652.200012 pos = 33.9297,135.5742 diff = 167.599976'
});
data_peak.push({
lat: 3.3832666668e+01,
lng: 1.3567644444e+02,
cert : true,
content:'Name = JA/WK-019(JA/WK-019) peak = 925.500000 pos = 33.8327,135.6764 diff = 269.299988'
});
data_saddle.push({
lat: 3.3843777779e+01,
lng: 1.3567244444e+02,
content:'Saddle = 656.200012 pos = 33.8438,135.6724 diff = 269.299988'
});
data_peak.push({
lat: 3.3906666668e+01,
lng: 1.3580833333e+02,
cert : true,
content:'Name = JA/WK-006(JA/WK-006) peak = 1076.699951 pos = 33.9067,135.8083 diff = 419.599976'
});
data_saddle.push({
lat: 3.3959777779e+01,
lng: 1.3585311111e+02,
content:'Saddle = 657.099976 pos = 33.9598,135.8531 diff = 419.599976'
});
data_peak.push({
lat: 3.3927111112e+01,
lng: 1.3583188889e+02,
cert : true,
content:'Name = Tamakiyama(JA/NR-035) peak = 1074.099976 pos = 33.9271,135.8319 diff = 330.899963'
});
data_saddle.push({
lat: 3.3910555556e+01,
lng: 1.3582455556e+02,
content:'Saddle = 743.200012 pos = 33.9106,135.8246 diff = 330.899963'
});
data_peak.push({
lat: 3.4058777779e+01,
lng: 1.3557422222e+02,
cert : true,
content:'Name = Ryuujindake(JA/WK-001) peak = 1381.699951 pos = 34.0588,135.5742 diff = 723.599976'
});
data_saddle.push({
lat: 3.4218777778e+01,
lng: 1.3572200000e+02,
content:'Saddle = 658.099976 pos = 34.2188,135.7220 diff = 723.599976'
});
data_peak.push({
lat: 3.3875222223e+01,
lng: 1.3556088889e+02,
cert : true,
content:'Name = JA/WK-007(JA/WK-007) peak = 1044.300049 pos = 33.8752,135.5609 diff = 382.600037'
});
data_saddle.push({
lat: 3.3889222223e+01,
lng: 1.3558077778e+02,
content:'Saddle = 661.700012 pos = 33.8892,135.5808 diff = 382.600037'
});
data_peak.push({
lat: 3.3909555556e+01,
lng: 1.3557522222e+02,
cert : true,
content:'Name = JA/WK-029(JA/WK-029) peak = 851.500000 pos = 33.9096,135.5752 diff = 164.500000'
});
data_saddle.push({
lat: 3.3918000001e+01,
lng: 1.3557666667e+02,
content:'Saddle = 687.000000 pos = 33.9180,135.5767 diff = 164.500000'
});
data_peak.push({
lat: 3.3944555556e+01,
lng: 1.3554055556e+02,
cert : true,
content:'Name = JA/WK-022(JA/WK-022) peak = 904.000000 pos = 33.9446,135.5406 diff = 203.200012'
});
data_saddle.push({
lat: 3.3964666667e+01,
lng: 1.3554311111e+02,
content:'Saddle = 700.799988 pos = 33.9647,135.5431 diff = 203.200012'
});
data_peak.push({
lat: 3.3842888890e+01,
lng: 1.3565177778e+02,
cert : true,
content:'Name = JA/WK-016(JA/WK-016) peak = 940.900024 pos = 33.8429,135.6518 diff = 238.900024'
});
data_saddle.push({
lat: 3.3869444445e+01,
lng: 1.3567011111e+02,
content:'Saddle = 702.000000 pos = 33.8694,135.6701 diff = 238.900024'
});
data_peak.push({
lat: 3.4178666667e+01,
lng: 1.3551533333e+02,
cert : true,
content:'Name = JA/WK-012(JA/WK-012) peak = 966.200012 pos = 34.1787,135.5153 diff = 247.500000'
});
data_saddle.push({
lat: 3.4160222223e+01,
lng: 1.3552688889e+02,
content:'Saddle = 718.700012 pos = 34.1602,135.5269 diff = 247.500000'
});
data_peak.push({
lat: 3.4150555556e+01,
lng: 1.3548100000e+02,
cert : true,
content:'Name = JA/WK-015(JA/WK-015) peak = 947.900024 pos = 34.1506,135.4810 diff = 177.300049'
});
data_saddle.push({
lat: 3.4165666667e+01,
lng: 1.3549500000e+02,
content:'Saddle = 770.599976 pos = 34.1657,135.4950 diff = 177.300049'
});
data_peak.push({
lat: 3.3920222223e+01,
lng: 1.3558211111e+02,
cert : false,
content:' Peak = 893.299988 pos = 33.9202,135.5821 diff = 150.399963'
});
data_saddle.push({
lat: 3.3928444445e+01,
lng: 1.3558233333e+02,
content:'Saddle = 742.900024 pos = 33.9284,135.5823 diff = 150.399963'
});
data_peak.push({
lat: 3.4015888890e+01,
lng: 1.3537211111e+02,
cert : true,
content:'Name = Shiramayama(JA/WK-014) peak = 955.299988 pos = 34.0159,135.3721 diff = 198.599976'
});
data_saddle.push({
lat: 3.4024000001e+01,
lng: 1.3541533333e+02,
content:'Saddle = 756.700012 pos = 34.0240,135.4153 diff = 198.599976'
});
data_peak.push({
lat: 3.3899111112e+01,
lng: 1.3565266667e+02,
cert : true,
content:'Name = Hiyamizuyama(JA/NR-018) peak = 1261.099976 pos = 33.8991,135.6527 diff = 503.299988'
});
data_saddle.push({
lat: 3.3923777779e+01,
lng: 1.3562388889e+02,
content:'Saddle = 757.799988 pos = 33.9238,135.6239 diff = 503.299988'
});
data_peak.push({
lat: 3.3872000001e+01,
lng: 1.3561755556e+02,
cert : true,
content:'Name = JA/WK-008(JA/WK-008) peak = 1021.000000 pos = 33.8720,135.6176 diff = 247.400024'
});
data_saddle.push({
lat: 3.3886555556e+01,
lng: 1.3562611111e+02,
content:'Saddle = 773.599976 pos = 33.8866,135.6261 diff = 247.400024'
});
data_peak.push({
lat: 3.4148000001e+01,
lng: 1.3555522222e+02,
cert : true,
content:'Name = JA/WK-010(JA/WK-010) peak = 971.299988 pos = 34.1480,135.5552 diff = 184.299988'
});
data_saddle.push({
lat: 3.4203333334e+01,
lng: 1.3556622222e+02,
content:'Saddle = 787.000000 pos = 34.2033,135.5662 diff = 184.299988'
});
data_peak.push({
lat: 3.4190777779e+01,
lng: 1.3559733333e+02,
cert : true,
content:'Name = JA/WK-009(JA/WK-009) peak = 1013.000000 pos = 34.1908,135.5973 diff = 208.700012'
});
data_saddle.push({
lat: 3.4220222223e+01,
lng: 1.3559933333e+02,
content:'Saddle = 804.299988 pos = 34.2202,135.5993 diff = 208.700012'
});
data_peak.push({
lat: 3.4220444445e+01,
lng: 1.3557244444e+02,
cert : false,
content:' Peak = 983.400024 pos = 34.2204,135.5724 diff = 156.000000'
});
data_saddle.push({
lat: 3.4212222223e+01,
lng: 1.3558033333e+02,
content:'Saddle = 827.400024 pos = 34.2122,135.5803 diff = 156.000000'
});
data_peak.push({
lat: 3.3954666667e+01,
lng: 1.3561822222e+02,
cert : true,
content:'Name = JA/NR-023(JA/NR-023) peak = 1211.199951 pos = 33.9547,135.6182 diff = 399.299927'
});
data_saddle.push({
lat: 3.3963666667e+01,
lng: 1.3563911111e+02,
content:'Saddle = 811.900024 pos = 33.9637,135.6391 diff = 399.299927'
});
data_peak.push({
lat: 3.4152333334e+01,
lng: 1.3565455556e+02,
cert : true,
content:'Name = JA/NR-019(JA/NR-019) peak = 1251.599976 pos = 34.1523,135.6546 diff = 374.399963'
});
data_saddle.push({
lat: 3.4170111112e+01,
lng: 1.3563622222e+02,
content:'Saddle = 877.200012 pos = 34.1701,135.6362 diff = 374.399963'
});
data_peak.push({
lat: 3.4155666667e+01,
lng: 1.3561655556e+02,
cert : true,
content:'Name = JA/NR-026(JA/NR-026) peak = 1183.199951 pos = 34.1557,135.6166 diff = 291.599976'
});
data_saddle.push({
lat: 3.4121555556e+01,
lng: 1.3557966667e+02,
content:'Saddle = 891.599976 pos = 34.1216,135.5797 diff = 291.599976'
});
data_peak.push({
lat: 3.4161777779e+01,
lng: 1.3572522222e+02,
cert : true,
content:'Name = JA/NR-028(JA/NR-028) peak = 1172.400024 pos = 34.1618,135.7252 diff = 279.900024'
});
data_saddle.push({
lat: 3.4174333334e+01,
lng: 1.3570600000e+02,
content:'Saddle = 892.500000 pos = 34.1743,135.7060 diff = 279.900024'
});
data_peak.push({
lat: 3.4203888890e+01,
lng: 1.3563466667e+02,
cert : true,
content:'Name = JA/NR-034(JA/NR-034) peak = 1105.099976 pos = 34.2039,135.6347 diff = 162.799988'
});
data_saddle.push({
lat: 3.4181555556e+01,
lng: 1.3563900000e+02,
content:'Saddle = 942.299988 pos = 34.1816,135.6390 diff = 162.799988'
});
data_peak.push({
lat: 3.4018888890e+01,
lng: 1.3568166667e+02,
cert : false,
content:' Peak = 1063.400024 pos = 34.0189,135.6817 diff = 160.400024'
});
data_saddle.push({
lat: 3.4013000001e+01,
lng: 1.3568000000e+02,
content:'Saddle = 903.000000 pos = 34.0130,135.6800 diff = 160.400024'
});
data_peak.push({
lat: 3.4026222223e+01,
lng: 1.3573311111e+02,
cert : true,
content:'Name = JA/NR-024(JA/NR-024) peak = 1191.099976 pos = 34.0262,135.7331 diff = 278.699951'
});
data_saddle.push({
lat: 3.4005444445e+01,
lng: 1.3569888889e+02,
content:'Saddle = 912.400024 pos = 34.0054,135.6989 diff = 278.699951'
});
data_peak.push({
lat: 3.3998333334e+01,
lng: 1.3576688889e+02,
cert : false,
content:' Peak = 1090.599976 pos = 33.9983,135.7669 diff = 170.299988'
});
data_saddle.push({
lat: 3.4010111112e+01,
lng: 1.3575266667e+02,
content:'Saddle = 920.299988 pos = 34.0101,135.7527 diff = 170.299988'
});
data_peak.push({
lat: 3.4112777779e+01,
lng: 1.3556988889e+02,
cert : false,
content:' Peak = 1080.599976 pos = 34.1128,135.5699 diff = 157.599976'
});
data_saddle.push({
lat: 3.4109666667e+01,
lng: 1.3556055556e+02,
content:'Saddle = 923.000000 pos = 34.1097,135.5606 diff = 157.599976'
});
data_peak.push({
lat: 3.3996666667e+01,
lng: 1.3550677778e+02,
cert : false,
content:' Peak = 1201.099976 pos = 33.9967,135.5068 diff = 210.299988'
});
data_saddle.push({
lat: 3.4016222223e+01,
lng: 1.3548066667e+02,
content:'Saddle = 990.799988 pos = 34.0162,135.4807 diff = 210.299988'
});
data_peak.push({
lat: 3.4007222223e+01,
lng: 1.3562533333e+02,
cert : true,
content:'Name = JA/NR-014(JA/NR-014) peak = 1316.500000 pos = 34.0072,135.6253 diff = 288.900024'
});
data_saddle.push({
lat: 3.4017333334e+01,
lng: 1.3559233333e+02,
content:'Saddle = 1027.599976 pos = 34.0173,135.5923 diff = 288.900024'
});
data_peak.push({
lat: 3.4028888890e+01,
lng: 1.3559577778e+02,
cert : true,
content:'Name = JA/NR-021(JA/NR-021) peak = 1240.199951 pos = 34.0289,135.5958 diff = 177.799927'
});
data_saddle.push({
lat: 3.4038000001e+01,
lng: 1.3559555556e+02,
content:'Saddle = 1062.400024 pos = 34.0380,135.5956 diff = 177.799927'
});
data_peak.push({
lat: 3.4109111112e+01,
lng: 1.3569488889e+02,
cert : true,
content:'Name = JA/NR-020(JA/NR-020) peak = 1253.400024 pos = 34.1091,135.6949 diff = 186.099976'
});
data_saddle.push({
lat: 3.4100555556e+01,
lng: 1.3568988889e+02,
content:'Saddle = 1067.300049 pos = 34.1006,135.6899 diff = 186.099976'
});
data_peak.push({
lat: 3.4087666667e+01,
lng: 1.3563522222e+02,
cert : false,
content:' Peak = 1343.099976 pos = 34.0877,135.6352 diff = 161.400024'
});
data_saddle.push({
lat: 3.4081111112e+01,
lng: 1.3564511111e+02,
content:'Saddle = 1181.699951 pos = 34.0811,135.6451 diff = 161.400024'
});
data_peak.push({
lat: 3.4508111112e+01,
lng: 1.3602711111e+02,
cert : false,
content:' Peak = 873.599976 pos = 34.5081,136.0271 diff = 206.699951'
});
data_saddle.push({
lat: 3.4483111112e+01,
lng: 1.3604033333e+02,
content:'Saddle = 666.900024 pos = 34.4831,136.0403 diff = 206.699951'
});
data_peak.push({
lat: 3.4064111112e+01,
lng: 1.3607255556e+02,
cert : true,
content:'Name = JA/NR-027(JA/NR-027) peak = 1181.599976 pos = 34.0641,136.0726 diff = 488.899963'
});
data_saddle.push({
lat: 3.4056666667e+01,
lng: 1.3611377778e+02,
content:'Saddle = 692.700012 pos = 34.0567,136.1138 diff = 488.899963'
});
data_peak.push({
lat: 3.3985666667e+01,
lng: 1.3613344444e+02,
cert : false,
content:' Peak = 921.799988 pos = 33.9857,136.1334 diff = 192.000000'
});
data_saddle.push({
lat: 3.4010222223e+01,
lng: 1.3614088889e+02,
content:'Saddle = 729.799988 pos = 34.0102,136.1409 diff = 192.000000'
});
data_peak.push({
lat: 3.3966000001e+01,
lng: 1.3608744444e+02,
cert : false,
content:' Peak = 901.599976 pos = 33.9660,136.0874 diff = 159.500000'
});
data_saddle.push({
lat: 3.3969555556e+01,
lng: 1.3608766667e+02,
content:'Saddle = 742.099976 pos = 33.9696,136.0877 diff = 159.500000'
});
data_peak.push({
lat: 3.4008555556e+01,
lng: 1.3606333333e+02,
cert : true,
content:'Name = JA/ME-028(JA/ME-028) peak = 932.200012 pos = 34.0086,136.0633 diff = 189.700012'
});
data_saddle.push({
lat: 3.3998333334e+01,
lng: 1.3607788889e+02,
content:'Saddle = 742.500000 pos = 33.9983,136.0779 diff = 189.700012'
});
data_peak.push({
lat: 3.3987555556e+01,
lng: 1.3608344444e+02,
cert : true,
content:'Name = JA/ME-027(JA/ME-027) peak = 942.900024 pos = 33.9876,136.0834 diff = 185.800049'
});
data_saddle.push({
lat: 3.3992666667e+01,
lng: 1.3608888889e+02,
content:'Saddle = 757.099976 pos = 33.9927,136.0889 diff = 185.800049'
});
data_peak.push({
lat: 3.4003888890e+01,
lng: 1.3609400000e+02,
cert : false,
content:' Peak = 1032.000000 pos = 34.0039,136.0940 diff = 250.200012'
});
data_saddle.push({
lat: 3.4010666667e+01,
lng: 1.3611377778e+02,
content:'Saddle = 781.799988 pos = 34.0107,136.1138 diff = 250.200012'
});
data_peak.push({
lat: 3.4032000001e+01,
lng: 1.3614711111e+02,
cert : false,
content:' Peak = 1043.500000 pos = 34.0320,136.1471 diff = 160.400024'
});
data_saddle.push({
lat: 3.4027000001e+01,
lng: 1.3613300000e+02,
content:'Saddle = 883.099976 pos = 34.0270,136.1330 diff = 160.400024'
});
data_peak.push({
lat: 3.4047111112e+01,
lng: 1.3609455556e+02,
cert : false,
content:' Peak = 1150.099976 pos = 34.0471,136.0946 diff = 166.099976'
});
data_saddle.push({
lat: 3.4058222223e+01,
lng: 1.3607844444e+02,
content:'Saddle = 984.000000 pos = 34.0582,136.0784 diff = 166.099976'
});
data_peak.push({
lat: 3.3977333334e+01,
lng: 1.3596222222e+02,
cert : false,
content:' Peak = 871.000000 pos = 33.9773,135.9622 diff = 168.599976'
});
data_saddle.push({
lat: 3.3986111112e+01,
lng: 1.3595355556e+02,
content:'Saddle = 702.400024 pos = 33.9861,135.9536 diff = 168.599976'
});
data_peak.push({
lat: 3.4467666667e+01,
lng: 1.3615322222e+02,
cert : false,
content:' Peak = 860.000000 pos = 34.4677,136.1532 diff = 151.900024'
});
data_saddle.push({
lat: 3.4455444445e+01,
lng: 1.3615111111e+02,
content:'Saddle = 708.099976 pos = 34.4554,136.1511 diff = 151.900024'
});
data_peak.push({
lat: 3.4460555556e+01,
lng: 1.3632700000e+02,
cert : true,
content:'Name = Tsubonegadake(JA/ME-020) peak = 1020.599976 pos = 34.4606,136.3270 diff = 307.799988'
});
data_saddle.push({
lat: 3.4462444445e+01,
lng: 1.3629488889e+02,
content:'Saddle = 712.799988 pos = 34.4624,136.2949 diff = 307.799988'
});
data_peak.push({
lat: 3.4448777778e+01,
lng: 1.3620622222e+02,
cert : true,
content:'Name = Miuneyama(JA/ME-010) peak = 1234.900024 pos = 34.4488,136.2062 diff = 483.000000'
});
data_saddle.push({
lat: 3.4443000001e+01,
lng: 1.3612011111e+02,
content:'Saddle = 751.900024 pos = 34.4430,136.1201 diff = 483.000000'
});
data_peak.push({
lat: 3.4475000001e+01,
lng: 1.3618233333e+02,
cert : false,
content:' Peak = 907.200012 pos = 34.4750,136.1823 diff = 154.900024'
});
data_saddle.push({
lat: 3.4461666667e+01,
lng: 1.3618088889e+02,
content:'Saddle = 752.299988 pos = 34.4617,136.1809 diff = 154.900024'
});
data_peak.push({
lat: 3.4492000001e+01,
lng: 1.3622977778e+02,
cert : true,
content:'Name = JA/ME-021(JA/ME-021) peak = 1021.000000 pos = 34.4920,136.2298 diff = 258.900024'
});
data_saddle.push({
lat: 3.4472666667e+01,
lng: 1.3621466667e+02,
content:'Saddle = 762.099976 pos = 34.4727,136.2147 diff = 258.900024'
});
data_peak.push({
lat: 3.4450222223e+01,
lng: 1.3625611111e+02,
cert : true,
content:'Name = JA/ME-015(JA/ME-015) peak = 1092.500000 pos = 34.4502,136.2561 diff = 163.799988'
});
data_saddle.push({
lat: 3.4448111112e+01,
lng: 1.3624922222e+02,
content:'Saddle = 928.700012 pos = 34.4481,136.2492 diff = 163.799988'
});
data_peak.push({
lat: 3.3945888890e+01,
lng: 1.3590777778e+02,
cert : true,
content:'Name = JA/WK-003(JA/WK-003) peak = 1122.099976 pos = 33.9459,135.9078 diff = 273.500000'
});
data_saddle.push({
lat: 3.3960111112e+01,
lng: 1.3591344444e+02,
content:'Saddle = 848.599976 pos = 33.9601,135.9134 diff = 273.500000'
});
data_peak.push({
lat: 3.4211000001e+01,
lng: 1.3578922222e+02,
cert : true,
content:'Name = JA/NR-030(JA/NR-030) peak = 1117.800049 pos = 34.2110,135.7892 diff = 267.100037'
});
data_saddle.push({
lat: 3.4264444445e+01,
lng: 1.3584322222e+02,
content:'Saddle = 850.700012 pos = 34.2644,135.8432 diff = 267.100037'
});
data_peak.push({
lat: 3.4234777778e+01,
lng: 1.3580500000e+02,
cert : true,
content:'Name = JA/NR-033(JA/NR-033) peak = 1110.300049 pos = 34.2348,135.8050 diff = 191.900024'
});
data_saddle.push({
lat: 3.4234000001e+01,
lng: 1.3579622222e+02,
content:'Saddle = 918.400024 pos = 34.2340,135.7962 diff = 191.900024'
});
data_peak.push({
lat: 3.4428666667e+01,
lng: 1.3608833333e+02,
cert : true,
content:'Name = Takamiyama(JA/ME-009) peak = 1246.300049 pos = 34.4287,136.0883 diff = 354.300049'
});
data_saddle.push({
lat: 3.4421222223e+01,
lng: 1.3609077778e+02,
content:'Saddle = 892.000000 pos = 34.4212,136.0908 diff = 354.300049'
});
data_peak.push({
lat: 3.4192000001e+01,
lng: 1.3575844444e+02,
cert : true,
content:'Name = JA/NR-031(JA/NR-031) peak = 1115.300049 pos = 34.1920,135.7584 diff = 182.600037'
});
data_saddle.push({
lat: 3.4180888890e+01,
lng: 1.3579033333e+02,
content:'Saddle = 932.700012 pos = 34.1809,135.7903 diff = 182.600037'
});
data_peak.push({
lat: 3.4097888890e+01,
lng: 1.3602355556e+02,
cert : true,
content:'Name = JA/NR-032(JA/NR-032) peak = 1112.599976 pos = 34.0979,136.0236 diff = 170.199951'
});
data_saddle.push({
lat: 3.4109000001e+01,
lng: 1.3602666667e+02,
content:'Saddle = 942.400024 pos = 34.1090,136.0267 diff = 170.199951'
});
data_peak.push({
lat: 3.4348888890e+01,
lng: 1.3597744444e+02,
cert : false,
content:' Peak = 1174.000000 pos = 34.3489,135.9774 diff = 203.500000'
});
data_saddle.push({
lat: 3.4353222223e+01,
lng: 1.3598755556e+02,
content:'Saddle = 970.500000 pos = 34.3532,135.9876 diff = 203.500000'
});
data_peak.push({
lat: 3.4185222223e+01,
lng: 1.3610911111e+02,
cert : true,
content:'Name = Oodaigaharazan (Hinodegatake)(JA/ME-001) peak = 1693.900024 pos = 34.1852,136.1091 diff = 696.800049'
});
data_saddle.push({
lat: 3.4233666667e+01,
lng: 1.3601188889e+02,
content:'Saddle = 997.099976 pos = 34.2337,136.0119 diff = 696.800049'
});
data_peak.push({
lat: 3.4370333334e+01,
lng: 1.3609122222e+02,
cert : false,
content:' Peak = 1432.300049 pos = 34.3703,136.0912 diff = 430.500061'
});
data_saddle.push({
lat: 3.4234111112e+01,
lng: 1.3611744444e+02,
content:'Saddle = 1001.799988 pos = 34.2341,136.1174 diff = 430.500061'
});
data_peak.push({
lat: 3.4249222223e+01,
lng: 1.3615600000e+02,
cert : false,
content:' Peak = 1293.500000 pos = 34.2492,136.1560 diff = 276.200012'
});
data_saddle.push({
lat: 3.4269000001e+01,
lng: 1.3612088889e+02,
content:'Saddle = 1017.299988 pos = 34.2690,136.1209 diff = 276.200012'
});
data_peak.push({
lat: 3.4280888890e+01,
lng: 1.3614633333e+02,
cert : true,
content:'Name = JA/ME-006(JA/ME-006) peak = 1283.800049 pos = 34.2809,136.1463 diff = 261.900024'
});
data_saddle.push({
lat: 3.4263888890e+01,
lng: 1.3611855556e+02,
content:'Saddle = 1021.900024 pos = 34.2639,136.1186 diff = 261.900024'
});
data_peak.push({
lat: 3.4350111112e+01,
lng: 1.3620755556e+02,
cert : true,
content:'Name = Mayoidake(JA/ME-005) peak = 1305.300049 pos = 34.3501,136.2076 diff = 271.900024'
});
data_saddle.push({
lat: 3.4335444445e+01,
lng: 1.3618844444e+02,
content:'Saddle = 1033.400024 pos = 34.3354,136.1884 diff = 271.900024'
});
data_peak.push({
lat: 3.4322111112e+01,
lng: 1.3616311111e+02,
cert : true,
content:'Name = JA/ME-008(JA/ME-008) peak = 1267.400024 pos = 34.3221,136.1631 diff = 205.800049'
});
data_saddle.push({
lat: 3.4317555556e+01,
lng: 1.3615911111e+02,
content:'Saddle = 1061.599976 pos = 34.3176,136.1591 diff = 205.800049'
});
data_peak.push({
lat: 3.4293000001e+01,
lng: 1.3604688889e+02,
cert : true,
content:'Name = Shirahigedake(JA/NR-010) peak = 1374.599976 pos = 34.2930,136.0469 diff = 272.099976'
});
data_saddle.push({
lat: 3.4298555556e+01,
lng: 1.3605811111e+02,
content:'Saddle = 1102.500000 pos = 34.2986,136.0581 diff = 272.099976'
});
data_peak.push({
lat: 3.4343333334e+01,
lng: 1.3602700000e+02,
cert : true,
content:'Name = JA/NR-015(JA/NR-015) peak = 1311.800049 pos = 34.3433,136.0270 diff = 189.200073'
});
data_saddle.push({
lat: 3.4346333334e+01,
lng: 1.3605822222e+02,
content:'Saddle = 1122.599976 pos = 34.3463,136.0582 diff = 189.200073'
});
data_peak.push({
lat: 3.4327111112e+01,
lng: 1.3611444444e+02,
cert : true,
content:'Name = JA/NR-008(JA/NR-008) peak = 1401.800049 pos = 34.3271,136.1144 diff = 198.400024'
});
data_saddle.push({
lat: 3.4338111112e+01,
lng: 1.3610122222e+02,
content:'Saddle = 1203.400024 pos = 34.3381,136.1012 diff = 198.400024'
});
data_peak.push({
lat: 3.4097666667e+01,
lng: 1.3608500000e+02,
cert : false,
content:' Peak = 1164.500000 pos = 34.0977,136.0850 diff = 160.400024'
});
data_saddle.push({
lat: 3.4102777779e+01,
lng: 1.3608966667e+02,
content:'Saddle = 1004.099976 pos = 34.1028,136.0897 diff = 160.400024'
});
data_peak.push({
lat: 3.4119777779e+01,
lng: 1.3605522222e+02,
cert : true,
content:'Name = JA/NR-017(JA/NR-017) peak = 1266.199951 pos = 34.1198,136.0552 diff = 236.000000'
});
data_saddle.push({
lat: 3.4133111112e+01,
lng: 1.3605177778e+02,
content:'Saddle = 1030.199951 pos = 34.1331,136.0518 diff = 236.000000'
});
data_peak.push({
lat: 3.4209444445e+01,
lng: 1.3613600000e+02,
cert : false,
content:' Peak = 1354.300049 pos = 34.2094,136.1360 diff = 162.500000'
});
data_saddle.push({
lat: 3.4207000001e+01,
lng: 1.3610688889e+02,
content:'Saddle = 1191.800049 pos = 34.2070,136.1069 diff = 162.500000'
});
data_peak.push({
lat: 3.4146444445e+01,
lng: 1.3606155556e+02,
cert : false,
content:' Peak = 1374.699951 pos = 34.1464,136.0616 diff = 169.099976'
});
data_saddle.push({
lat: 3.4157444445e+01,
lng: 1.3606444444e+02,
content:'Saddle = 1205.599976 pos = 34.1574,136.0644 diff = 169.099976'
});
data_peak.push({
lat: 3.4186444445e+01,
lng: 1.3615333333e+02,
cert : true,
content:'Name = JA/ME-003(JA/ME-003) peak = 1382.400024 pos = 34.1864,136.1533 diff = 171.400024'
});
data_saddle.push({
lat: 3.4168111112e+01,
lng: 1.3614222222e+02,
content:'Saddle = 1211.000000 pos = 34.1681,136.1422 diff = 171.400024'
});
data_peak.push({
lat: 3.4164555556e+01,
lng: 1.3577777778e+02,
cert : true,
content:'Name = JA/NR-025(JA/NR-025) peak = 1187.900024 pos = 34.1646,135.7778 diff = 176.300049'
});
data_saddle.push({
lat: 3.4181000001e+01,
lng: 1.3580433333e+02,
content:'Saddle = 1011.599976 pos = 34.1810,135.8043 diff = 176.300049'
});
data_peak.push({
lat: 3.4321000001e+01,
lng: 1.3590988889e+02,
cert : true,
content:'Name = JA/NR-022(JA/NR-022) peak = 1234.400024 pos = 34.3210,135.9099 diff = 212.500000'
});
data_saddle.push({
lat: 3.4303666667e+01,
lng: 1.3591288889e+02,
content:'Saddle = 1021.900024 pos = 34.3037,135.9129 diff = 212.500000'
});
data_peak.push({
lat: 3.3982888890e+01,
lng: 1.3589833333e+02,
cert : true,
content:'Name = Kasasuteyama(JA/NR-012) peak = 1350.900024 pos = 33.9829,135.8983 diff = 313.900024'
});
data_saddle.push({
lat: 3.3996111112e+01,
lng: 1.3590466667e+02,
content:'Saddle = 1037.000000 pos = 33.9961,135.9047 diff = 313.900024'
});
data_peak.push({
lat: 3.4024666667e+01,
lng: 1.3590966667e+02,
cert : true,
content:'Name = JA/NR-016(JA/NR-016) peak = 1280.699951 pos = 34.0247,135.9097 diff = 227.599976'
});
data_saddle.push({
lat: 3.4041888890e+01,
lng: 1.3589688889e+02,
content:'Saddle = 1053.099976 pos = 34.0419,135.8969 diff = 227.599976'
});
data_peak.push({
lat: 3.4084222223e+01,
lng: 1.3592800000e+02,
cert : true,
content:'Name = JA/NR-013(JA/NR-013) peak = 1333.000000 pos = 34.0842,135.9280 diff = 210.800049'
});
data_saddle.push({
lat: 3.4089555556e+01,
lng: 1.3591855556e+02,
content:'Saddle = 1122.199951 pos = 34.0896,135.9186 diff = 210.800049'
});
data_peak.push({
lat: 3.4028777779e+01,
lng: 1.3586066667e+02,
cert : true,
content:'Name = JA/NR-007(JA/NR-007) peak = 1407.099976 pos = 34.0288,135.8607 diff = 265.199951'
});
data_saddle.push({
lat: 3.4042222223e+01,
lng: 1.3587288889e+02,
content:'Saddle = 1141.900024 pos = 34.0422,135.8729 diff = 265.199951'
});
data_peak.push({
lat: 3.4139000001e+01,
lng: 1.3584733333e+02,
cert : false,
content:' Peak = 1354.599976 pos = 34.1390,135.8473 diff = 163.699951'
});
data_saddle.push({
lat: 3.4149444445e+01,
lng: 1.3586800000e+02,
content:'Saddle = 1190.900024 pos = 34.1494,135.8680 diff = 163.699951'
});
data_peak.push({
lat: 3.4058222223e+01,
lng: 1.3589677778e+02,
cert : true,
content:'Name = Nehandake(JA/NR-011) peak = 1374.199951 pos = 34.0582,135.8968 diff = 180.199951'
});
data_saddle.push({
lat: 3.4062444445e+01,
lng: 1.3589511111e+02,
content:'Saddle = 1194.000000 pos = 34.0624,135.8951 diff = 180.199951'
});
data_peak.push({
lat: 3.4284666667e+01,
lng: 1.3591433333e+02,
cert : true,
content:'Name = JA/NR-006(JA/NR-006) peak = 1437.000000 pos = 34.2847,135.9143 diff = 226.500000'
});
data_saddle.push({
lat: 3.4279111112e+01,
lng: 1.3592500000e+02,
content:'Saddle = 1210.500000 pos = 34.2791,135.9250 diff = 226.500000'
});
data_peak.push({
lat: 3.4254444445e+01,
lng: 1.3589388889e+02,
cert : true,
content:'Name = JA/NR-009(JA/NR-009) peak = 1383.500000 pos = 34.2544,135.8939 diff = 166.000000'
});
data_saddle.push({
lat: 3.4258111112e+01,
lng: 1.3590644444e+02,
content:'Saddle = 1217.500000 pos = 34.2581,135.9064 diff = 166.000000'
});
data_peak.push({
lat: 3.4227888890e+01,
lng: 1.3596277778e+02,
cert : true,
content:'Name = Daifugendake(JA/NR-003) peak = 1777.800049 pos = 34.2279,135.9628 diff = 365.500000'
});
data_saddle.push({
lat: 3.4187555556e+01,
lng: 1.3594500000e+02,
content:'Saddle = 1412.300049 pos = 34.1876,135.9450 diff = 365.500000'
});
data_peak.push({
lat: 3.4237666667e+01,
lng: 1.3592366667e+02,
cert : true,
content:'Name = JA/NR-004(JA/NR-004) peak = 1723.500000 pos = 34.2377,135.9237 diff = 210.599976'
});
data_saddle.push({
lat: 3.4250111112e+01,
lng: 1.3593511111e+02,
content:'Saddle = 1512.900024 pos = 34.2501,135.9351 diff = 210.599976'
});
data_peak.push({
lat: 3.4244333334e+01,
lng: 1.3595522222e+02,
cert : true,
content:'Name = JA/NR-005(JA/NR-005) peak = 1724.099976 pos = 34.2443,135.9552 diff = 180.799927'
});
data_saddle.push({
lat: 3.4237666667e+01,
lng: 1.3596411111e+02,
content:'Saddle = 1543.300049 pos = 34.2377,135.9641 diff = 180.799927'
});
data_peak.push({
lat: 3.4134555556e+01,
lng: 1.3591311111e+02,
cert : true,
content:'Name = Busshougadake(JA/NR-002) peak = 1804.199951 pos = 34.1346,135.9131 diff = 210.799927'
});
data_saddle.push({
lat: 3.4141777779e+01,
lng: 1.3590633333e+02,
content:'Saddle = 1593.400024 pos = 34.1418,135.9063 diff = 210.799927'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:36,
       south:33.3333,
       east:137,
       west:135}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
