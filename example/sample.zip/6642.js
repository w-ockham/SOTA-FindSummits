function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 4.3663555548e+01,
lng: 1.4285400000e+02,
cert : true,
content:'Name = Taisetsuzan (Asahidake)(JA8/KK-001) peak = 2290.100098 pos = 43.6636,142.8540 diff = 2251.900146'
});
data_saddle.push({
lat: 4.3571999992e+01,
lng: 1.4200000000e+02,
content:'Saddle = 38.200001 pos = 43.5720,142.0000 diff = 2251.900146'
});
data_peak.push({
lat: 4.3498222213e+01,
lng: 1.4222266667e+02,
cert : true,
content:'Name = JA8/SC-065(JA8/SC-065) peak = 312.799988 pos = 43.4982,142.2227 diff = 164.899994'
});
data_saddle.push({
lat: 4.3494666658e+01,
lng: 1.4223933333e+02,
content:'Saddle = 147.899994 pos = 43.4947,142.2393 diff = 164.899994'
});
data_peak.push({
lat: 4.3826888883e+01,
lng: 1.4228777778e+02,
cert : true,
content:'Name = JA8/KK-127(JA8/KK-127) peak = 422.299988 pos = 43.8269,142.2878 diff = 233.899994'
});
data_saddle.push({
lat: 4.3844555549e+01,
lng: 1.4228755556e+02,
content:'Saddle = 188.399994 pos = 43.8446,142.2876 diff = 233.899994'
});
data_peak.push({
lat: 4.3518999991e+01,
lng: 1.4200633333e+02,
cert : true,
content:'Name = JA8/SC-060(JA8/SC-060) peak = 467.000000 pos = 43.5190,142.0063 diff = 269.899994'
});
data_saddle.push({
lat: 4.3525444436e+01,
lng: 1.4206900000e+02,
content:'Saddle = 197.100006 pos = 43.5254,142.0690 diff = 269.899994'
});
data_peak.push({
lat: 4.3629333325e+01,
lng: 1.4211022222e+02,
cert : true,
content:'Name = Irumukeppuyama(JA8/SC-021) peak = 862.200012 pos = 43.6293,142.1102 diff = 663.300049'
});
data_saddle.push({
lat: 4.3635888881e+01,
lng: 1.4220144444e+02,
content:'Saddle = 198.899994 pos = 43.6359,142.2014 diff = 663.300049'
});
data_peak.push({
lat: 4.3870333327e+01,
lng: 1.4228977778e+02,
cert : true,
content:'Name = JA8/KK-129(JA8/KK-129) peak = 383.299988 pos = 43.8703,142.2898 diff = 164.299988'
});
data_saddle.push({
lat: 4.3881555550e+01,
lng: 1.4227911111e+02,
content:'Saddle = 219.000000 pos = 43.8816,142.2791 diff = 164.299988'
});
data_peak.push({
lat: 4.3539111102e+01,
lng: 1.4222522222e+02,
cert : true,
content:'Name = JA8/SC-062(JA8/SC-062) peak = 381.600006 pos = 43.5391,142.2252 diff = 153.800003'
});
data_saddle.push({
lat: 4.3561666658e+01,
lng: 1.4223655556e+02,
content:'Saddle = 227.800003 pos = 43.5617,142.2366 diff = 153.800003'
});
data_peak.push({
lat: 4.3894999994e+01,
lng: 1.4227122222e+02,
cert : true,
content:'Name = JA8/KK-122(JA8/KK-122) peak = 468.799988 pos = 43.8950,142.2712 diff = 227.199982'
});
data_saddle.push({
lat: 4.3924444439e+01,
lng: 1.4227955556e+02,
content:'Saddle = 241.600006 pos = 43.9244,142.2796 diff = 227.199982'
});
data_peak.push({
lat: 4.4355666665e+01,
lng: 1.4203200000e+02,
cert : true,
content:'Name = Pisshirizan(JA8/RM-004) peak = 1031.300049 pos = 44.3557,142.0320 diff = 770.000061'
});
data_saddle.push({
lat: 4.4230999997e+01,
lng: 1.4220488889e+02,
content:'Saddle = 261.299988 pos = 44.2310,142.2049 diff = 770.000061'
});
data_peak.push({
lat: 4.4282444442e+01,
lng: 1.4217855556e+02,
cert : true,
content:'Name = Yanisamanaidake(JA8/KK-123) peak = 445.899994 pos = 44.2824,142.1786 diff = 165.100006'
});
data_saddle.push({
lat: 4.4292666664e+01,
lng: 1.4220355556e+02,
content:'Saddle = 280.799988 pos = 44.2927,142.2036 diff = 165.100006'
});
data_peak.push({
lat: 4.4650444445e+01,
lng: 1.4222466667e+02,
cert : true,
content:'Name = JA8/KK-116(JA8/KK-116) peak = 533.700012 pos = 44.6504,142.2247 diff = 162.900024'
});
data_saddle.push({
lat: 4.4621444444e+01,
lng: 1.4221777778e+02,
content:'Saddle = 370.799988 pos = 44.6214,142.2178 diff = 162.900024'
});
data_peak.push({
lat: 4.4648666667e+01,
lng: 1.4214300000e+02,
cert : false,
content:' Peak = 581.299988 pos = 44.6487,142.1430 diff = 203.199982'
});
data_saddle.push({
lat: 4.4653777778e+01,
lng: 1.4215966667e+02,
content:'Saddle = 378.100006 pos = 44.6538,142.1597 diff = 203.199982'
});
data_peak.push({
lat: 4.4091555551e+01,
lng: 1.4208566667e+02,
cert : true,
content:'Name = Santousan(JA8/KK-049) peak = 1008.099976 pos = 44.0916,142.0857 diff = 620.099976'
});
data_saddle.push({
lat: 4.4200333330e+01,
lng: 1.4205777778e+02,
content:'Saddle = 388.000000 pos = 44.2003,142.0578 diff = 620.099976'
});
data_peak.push({
lat: 4.3967999995e+01,
lng: 1.4202877778e+02,
cert : true,
content:'Name = JA8/SC-032(JA8/SC-032) peak = 773.599976 pos = 43.9680,142.0288 diff = 345.999969'
});
data_saddle.push({
lat: 4.4012666662e+01,
lng: 1.4204677778e+02,
content:'Saddle = 427.600006 pos = 44.0127,142.0468 diff = 345.999969'
});
data_peak.push({
lat: 4.3999444439e+01,
lng: 1.4204033333e+02,
cert : false,
content:' Peak = 622.099976 pos = 43.9994,142.0403 diff = 192.899963'
});
data_saddle.push({
lat: 4.3993555551e+01,
lng: 1.4200000000e+02,
content:'Saddle = 429.200012 pos = 43.9936,142.0000 diff = 192.899963'
});
data_peak.push({
lat: 4.3987666662e+01,
lng: 1.4208044444e+02,
cert : true,
content:'Name = JA8/SC-050(JA8/SC-050) peak = 601.599976 pos = 43.9877,142.0804 diff = 159.699982'
});
data_saddle.push({
lat: 4.3995555551e+01,
lng: 1.4205166667e+02,
content:'Saddle = 441.899994 pos = 43.9956,142.0517 diff = 159.699982'
});
data_peak.push({
lat: 4.3914777772e+01,
lng: 1.4203977778e+02,
cert : true,
content:'Name = JA8/SC-041(JA8/SC-041) peak = 676.000000 pos = 43.9148,142.0398 diff = 215.600006'
});
data_saddle.push({
lat: 4.3943888883e+01,
lng: 1.4202244444e+02,
content:'Saddle = 460.399994 pos = 43.9439,142.0224 diff = 215.600006'
});
data_peak.push({
lat: 4.4011666662e+01,
lng: 1.4206011111e+02,
cert : true,
content:'Name = JA8/SC-042(JA8/SC-042) peak = 671.299988 pos = 44.0117,142.0601 diff = 223.299988'
});
data_saddle.push({
lat: 4.4019999995e+01,
lng: 1.4205466667e+02,
content:'Saddle = 448.000000 pos = 44.0200,142.0547 diff = 223.299988'
});
data_peak.push({
lat: 4.4044666662e+01,
lng: 1.4209366667e+02,
cert : true,
content:'Name = JA8/KK-077(JA8/KK-077) peak = 803.700012 pos = 44.0447,142.0937 diff = 328.700012'
});
data_saddle.push({
lat: 4.4053555551e+01,
lng: 1.4205677778e+02,
content:'Saddle = 475.000000 pos = 44.0536,142.0568 diff = 328.700012'
});
data_peak.push({
lat: 4.4102222218e+01,
lng: 1.4205244444e+02,
cert : true,
content:'Name = JA8/RM-007(JA8/RM-007) peak = 872.000000 pos = 44.1022,142.0524 diff = 186.000000'
});
data_saddle.push({
lat: 4.4109444440e+01,
lng: 1.4205922222e+02,
content:'Saddle = 686.000000 pos = 44.1094,142.0592 diff = 186.000000'
});
data_peak.push({
lat: 4.4154999996e+01,
lng: 1.4207233333e+02,
cert : true,
content:'Name = JA8/KK-054(JA8/KK-054) peak = 980.900024 pos = 44.1550,142.0723 diff = 243.500000'
});
data_saddle.push({
lat: 4.4125444440e+01,
lng: 1.4207477778e+02,
content:'Saddle = 737.400024 pos = 44.1254,142.0748 diff = 243.500000'
});
data_peak.push({
lat: 4.4264555553e+01,
lng: 1.4202766667e+02,
cert : true,
content:'Name = JA8/RM-010(JA8/RM-010) peak = 642.500000 pos = 44.2646,142.0277 diff = 248.000000'
});
data_saddle.push({
lat: 4.4288999997e+01,
lng: 1.4204388889e+02,
content:'Saddle = 394.500000 pos = 44.2890,142.0439 diff = 248.000000'
});
data_peak.push({
lat: 4.4228222219e+01,
lng: 1.4208833333e+02,
cert : false,
content:' Peak = 624.200012 pos = 44.2282,142.0883 diff = 192.500000'
});
data_saddle.push({
lat: 4.4251444441e+01,
lng: 1.4205777778e+02,
content:'Saddle = 431.700012 pos = 44.2514,142.0578 diff = 192.500000'
});
data_peak.push({
lat: 4.4256999997e+01,
lng: 1.4208511111e+02,
cert : true,
content:'Name = JA8/KK-102(JA8/KK-102) peak = 623.099976 pos = 44.2570,142.0851 diff = 160.899963'
});
data_saddle.push({
lat: 4.4244222219e+01,
lng: 1.4207011111e+02,
content:'Saddle = 462.200012 pos = 44.2442,142.0701 diff = 160.899963'
});
data_peak.push({
lat: 4.4376444442e+01,
lng: 1.4232100000e+02,
cert : true,
content:'Name = JA8/KK-101(JA8/KK-101) peak = 624.599976 pos = 44.3764,142.3210 diff = 192.799988'
});
data_saddle.push({
lat: 4.4423999998e+01,
lng: 1.4223577778e+02,
content:'Saddle = 431.799988 pos = 44.4240,142.2358 diff = 192.799988'
});
data_peak.push({
lat: 4.4605000000e+01,
lng: 1.4218833333e+02,
cert : true,
content:'Name = JA8/KK-098(JA8/KK-098) peak = 636.700012 pos = 44.6050,142.1883 diff = 198.000000'
});
data_saddle.push({
lat: 4.4592444444e+01,
lng: 1.4218433333e+02,
content:'Saddle = 438.700012 pos = 44.5924,142.1843 diff = 198.000000'
});
data_peak.push({
lat: 4.4479999999e+01,
lng: 1.4211200000e+02,
cert : true,
content:'Name = JA8/RM-006(JA8/RM-006) peak = 893.799988 pos = 44.4800,142.1120 diff = 441.899994'
});
data_saddle.push({
lat: 4.4407999998e+01,
lng: 1.4205122222e+02,
content:'Saddle = 451.899994 pos = 44.4080,142.0512 diff = 441.899994'
});
data_peak.push({
lat: 4.4424555554e+01,
lng: 1.4214155556e+02,
cert : true,
content:'Name = JA8/KK-093(JA8/KK-093) peak = 683.200012 pos = 44.4246,142.1416 diff = 176.400024'
});
data_saddle.push({
lat: 4.4447222221e+01,
lng: 1.4213922222e+02,
content:'Saddle = 506.799988 pos = 44.4472,142.1392 diff = 176.400024'
});
data_peak.push({
lat: 4.4430222221e+01,
lng: 1.4207933333e+02,
cert : true,
content:'Name = JA8/RM-008(JA8/RM-008) peak = 796.599976 pos = 44.4302,142.0793 diff = 185.199951'
});
data_saddle.push({
lat: 4.4437555554e+01,
lng: 1.4208622222e+02,
content:'Saddle = 611.400024 pos = 44.4376,142.0862 diff = 185.199951'
});
data_peak.push({
lat: 4.4069222218e+01,
lng: 1.4218800000e+02,
cert : true,
content:'Name = JA8/KK-085(JA8/KK-085) peak = 745.700012 pos = 44.0692,142.1880 diff = 478.800018'
});
data_saddle.push({
lat: 4.3966555550e+01,
lng: 1.4245444444e+02,
content:'Saddle = 266.899994 pos = 43.9666,142.4544 diff = 478.800018'
});
data_peak.push({
lat: 4.3981222217e+01,
lng: 1.4244333333e+02,
cert : true,
content:'Name = JA8/KK-124(JA8/KK-124) peak = 443.299988 pos = 43.9812,142.4433 diff = 171.299988'
});
data_saddle.push({
lat: 4.3957888884e+01,
lng: 1.4243488889e+02,
content:'Saddle = 272.000000 pos = 43.9579,142.4349 diff = 171.299988'
});
data_peak.push({
lat: 4.3953555550e+01,
lng: 1.4241255556e+02,
cert : true,
content:'Name = JA8/KK-117(JA8/KK-117) peak = 520.799988 pos = 43.9536,142.4126 diff = 244.000000'
});
data_saddle.push({
lat: 4.3957999995e+01,
lng: 1.4237333333e+02,
content:'Saddle = 276.799988 pos = 43.9580,142.3733 diff = 244.000000'
});
data_peak.push({
lat: 4.3932666661e+01,
lng: 1.4212211111e+02,
cert : true,
content:'Name = JA8/KK-114(JA8/KK-114) peak = 551.400024 pos = 43.9327,142.1221 diff = 273.500031'
});
data_saddle.push({
lat: 4.3921888883e+01,
lng: 1.4213433333e+02,
content:'Saddle = 277.899994 pos = 43.9219,142.1343 diff = 273.500031'
});
data_peak.push({
lat: 4.3956666661e+01,
lng: 1.4230655556e+02,
cert : false,
content:' Peak = 575.700012 pos = 43.9567,142.3066 diff = 267.600006'
});
data_saddle.push({
lat: 4.3946111106e+01,
lng: 1.4229855556e+02,
content:'Saddle = 308.100006 pos = 43.9461,142.2986 diff = 267.600006'
});
data_peak.push({
lat: 4.3961333328e+01,
lng: 1.4234433333e+02,
cert : true,
content:'Name = JA8/KK-109(JA8/KK-109) peak = 574.200012 pos = 43.9613,142.3443 diff = 262.500000'
});
data_saddle.push({
lat: 4.3955555550e+01,
lng: 1.4232844444e+02,
content:'Saddle = 311.700012 pos = 43.9556,142.3284 diff = 262.500000'
});
data_peak.push({
lat: 4.3905444439e+01,
lng: 1.4214922222e+02,
cert : true,
content:'Name = JA8/KK-095(JA8/KK-095) peak = 653.500000 pos = 43.9054,142.1492 diff = 324.299988'
});
data_saddle.push({
lat: 4.3978888884e+01,
lng: 1.4225311111e+02,
content:'Saddle = 329.200012 pos = 43.9789,142.2531 diff = 324.299988'
});
data_peak.push({
lat: 4.3837999994e+01,
lng: 1.4220855556e+02,
cert : true,
content:'Name = JA8/SC-048(JA8/SC-048) peak = 612.799988 pos = 43.8380,142.2086 diff = 250.000000'
});
data_saddle.push({
lat: 4.3867999994e+01,
lng: 1.4218477778e+02,
content:'Saddle = 362.799988 pos = 43.8680,142.1848 diff = 250.000000'
});
data_peak.push({
lat: 4.3761666660e+01,
lng: 1.4220466667e+02,
cert : true,
content:'Name = JA8/KK-108(JA8/KK-108) peak = 591.700012 pos = 43.7617,142.2047 diff = 188.700012'
});
data_saddle.push({
lat: 4.3803999993e+01,
lng: 1.4223733333e+02,
content:'Saddle = 403.000000 pos = 43.8040,142.2373 diff = 188.700012'
});
data_peak.push({
lat: 4.3869999994e+01,
lng: 1.4216855556e+02,
cert : true,
content:'Name = JA8/KK-110(JA8/KK-110) peak = 577.500000 pos = 43.8700,142.1686 diff = 150.399994'
});
data_saddle.push({
lat: 4.3883222216e+01,
lng: 1.4215933333e+02,
content:'Saddle = 427.100006 pos = 43.8832,142.1593 diff = 150.399994'
});
data_peak.push({
lat: 4.3949222217e+01,
lng: 1.4221044444e+02,
cert : true,
content:'Name = JA8/KK-097(JA8/KK-097) peak = 641.000000 pos = 43.9492,142.2104 diff = 185.799988'
});
data_saddle.push({
lat: 4.3914666661e+01,
lng: 1.4216222222e+02,
content:'Saddle = 455.200012 pos = 43.9147,142.1622 diff = 185.799988'
});
data_peak.push({
lat: 4.3993555551e+01,
lng: 1.4225000000e+02,
cert : false,
content:' Peak = 534.599976 pos = 43.9936,142.2500 diff = 192.699982'
});
data_saddle.push({
lat: 4.4001777773e+01,
lng: 1.4224411111e+02,
content:'Saddle = 341.899994 pos = 44.0018,142.2441 diff = 192.699982'
});
data_peak.push({
lat: 4.4145111107e+01,
lng: 1.4218644444e+02,
cert : true,
content:'Name = JA8/KK-104(JA8/KK-104) peak = 620.299988 pos = 44.1451,142.1864 diff = 229.799988'
});
data_saddle.push({
lat: 4.4106888885e+01,
lng: 1.4219233333e+02,
content:'Saddle = 390.500000 pos = 44.1069,142.1923 diff = 229.799988'
});
data_peak.push({
lat: 4.4037777773e+01,
lng: 1.4221011111e+02,
cert : false,
content:' Peak = 561.799988 pos = 44.0378,142.2101 diff = 169.099976'
});
data_saddle.push({
lat: 4.4040222218e+01,
lng: 1.4219266667e+02,
content:'Saddle = 392.700012 pos = 44.0402,142.1927 diff = 169.099976'
});
data_peak.push({
lat: 4.3605999992e+01,
lng: 1.4227155556e+02,
cert : true,
content:'Name = JA8/SC-018(JA8/SC-018) peak = 901.099976 pos = 43.6060,142.2716 diff = 627.599976'
});
data_saddle.push({
lat: 4.3520444436e+01,
lng: 1.4247433333e+02,
content:'Saddle = 273.500000 pos = 43.5204,142.4743 diff = 627.599976'
});
data_peak.push({
lat: 4.3410111101e+01,
lng: 1.4235333333e+02,
cert : true,
content:'Name = JA8/SC-055(JA8/SC-055) peak = 542.500000 pos = 43.4101,142.3533 diff = 265.899994'
});
data_saddle.push({
lat: 4.3406555546e+01,
lng: 1.4238188889e+02,
content:'Saddle = 276.600006 pos = 43.4066,142.3819 diff = 265.899994'
});
data_peak.push({
lat: 4.3428888879e+01,
lng: 1.4236144444e+02,
cert : false,
content:' Peak = 623.700012 pos = 43.4289,142.3614 diff = 155.700012'
});
data_saddle.push({
lat: 4.3433999990e+01,
lng: 1.4236766667e+02,
content:'Saddle = 468.000000 pos = 43.4340,142.3677 diff = 155.700012'
});
data_peak.push({
lat: 4.3466333324e+01,
lng: 1.4235711111e+02,
cert : false,
content:' Peak = 817.700012 pos = 43.4663,142.3571 diff = 264.500000'
});
data_saddle.push({
lat: 4.3482222213e+01,
lng: 1.4236522222e+02,
content:'Saddle = 553.200012 pos = 43.4822,142.3652 diff = 264.500000'
});
data_peak.push({
lat: 4.3689666659e+01,
lng: 1.4221877778e+02,
cert : true,
content:'Name = JA8/KK-078(JA8/KK-078) peak = 793.799988 pos = 43.6897,142.2188 diff = 202.000000'
});
data_saddle.push({
lat: 4.3693666659e+01,
lng: 1.4223533333e+02,
content:'Saddle = 591.799988 pos = 43.6937,142.2353 diff = 202.000000'
});
data_peak.push({
lat: 4.3544333325e+01,
lng: 1.4232177778e+02,
cert : true,
content:'Name = JA8/KK-067(JA8/KK-067) peak = 858.400024 pos = 43.5443,142.3218 diff = 208.200012'
});
data_saddle.push({
lat: 4.3563111103e+01,
lng: 1.4229911111e+02,
content:'Saddle = 650.200012 pos = 43.5631,142.2991 diff = 208.200012'
});
data_peak.push({
lat: 4.4665888889e+01,
lng: 1.4241200000e+02,
cert : true,
content:'Name = Hakodake(JA8/KK-042) peak = 1127.699951 pos = 44.6659,142.4120 diff = 830.099976'
});
data_saddle.push({
lat: 4.4328333331e+01,
lng: 1.4281100000e+02,
content:'Saddle = 297.600006 pos = 44.3283,142.8110 diff = 830.099976'
});
data_peak.push({
lat: 4.4641777778e+01,
lng: 1.4274500000e+02,
cert : true,
content:'Name = JA8/SY-014(JA8/SY-014) peak = 524.700012 pos = 44.6418,142.7450 diff = 214.200012'
});
data_saddle.push({
lat: 4.4632111111e+01,
lng: 1.4271900000e+02,
content:'Saddle = 310.500000 pos = 44.6321,142.7190 diff = 214.200012'
});
data_peak.push({
lat: 4.4352888887e+01,
lng: 1.4263511111e+02,
cert : true,
content:'Name = JA8/KK-112(JA8/KK-112) peak = 560.500000 pos = 44.3529,142.6351 diff = 227.200012'
});
data_saddle.push({
lat: 4.4357444442e+01,
lng: 1.4262866667e+02,
content:'Saddle = 333.299988 pos = 44.3574,142.6287 diff = 227.200012'
});
data_peak.push({
lat: 4.4458444443e+01,
lng: 1.4280755556e+02,
cert : true,
content:'Name = JA8/KK-058(JA8/KK-058) peak = 916.900024 pos = 44.4584,142.8076 diff = 579.400024'
});
data_saddle.push({
lat: 4.4472222221e+01,
lng: 1.4269988889e+02,
content:'Saddle = 337.500000 pos = 44.4722,142.6999 diff = 579.400024'
});
data_peak.push({
lat: 4.4348111109e+01,
lng: 1.4281277778e+02,
cert : true,
content:'Name = JA8/KK-103(JA8/KK-103) peak = 621.299988 pos = 44.3481,142.8128 diff = 259.199982'
});
data_saddle.push({
lat: 4.4364111109e+01,
lng: 1.4282100000e+02,
content:'Saddle = 362.100006 pos = 44.3641,142.8210 diff = 259.199982'
});
data_peak.push({
lat: 4.4463999999e+01,
lng: 1.4271855556e+02,
cert : false,
content:' Peak = 628.200012 pos = 44.4640,142.7186 diff = 169.700012'
});
data_saddle.push({
lat: 4.4459999999e+01,
lng: 1.4274233333e+02,
content:'Saddle = 458.500000 pos = 44.4600,142.7423 diff = 169.700012'
});
data_peak.push({
lat: 4.4470333332e+01,
lng: 1.4291511111e+02,
cert : true,
content:'Name = JA8/OH-062(JA8/OH-062) peak = 740.200012 pos = 44.4703,142.9151 diff = 207.100037'
});
data_saddle.push({
lat: 4.4450777776e+01,
lng: 1.4289544444e+02,
content:'Saddle = 533.099976 pos = 44.4508,142.8954 diff = 207.100037'
});
data_peak.push({
lat: 4.4469111110e+01,
lng: 1.4276988889e+02,
cert : false,
content:' Peak = 774.599976 pos = 44.4691,142.7699 diff = 156.699951'
});
data_saddle.push({
lat: 4.4457888888e+01,
lng: 1.4278577778e+02,
content:'Saddle = 617.900024 pos = 44.4579,142.7858 diff = 156.699951'
});
data_peak.push({
lat: 4.4432111110e+01,
lng: 1.4259288889e+02,
cert : false,
content:' Peak = 990.799988 pos = 44.4321,142.5929 diff = 615.599976'
});
data_saddle.push({
lat: 4.4598666666e+01,
lng: 1.4258411111e+02,
content:'Saddle = 375.200012 pos = 44.5987,142.5841 diff = 615.599976'
});
data_peak.push({
lat: 4.4560666666e+01,
lng: 1.4274355556e+02,
cert : false,
content:' Peak = 534.599976 pos = 44.5607,142.7436 diff = 157.399963'
});
data_saddle.push({
lat: 4.4576888889e+01,
lng: 1.4272922222e+02,
content:'Saddle = 377.200012 pos = 44.5769,142.7292 diff = 157.399963'
});
data_peak.push({
lat: 4.4590000000e+01,
lng: 1.4264700000e+02,
cert : true,
content:'Name = JA8/SY-003(JA8/SY-003) peak = 903.799988 pos = 44.5900,142.6470 diff = 476.399994'
});
data_saddle.push({
lat: 4.4531111110e+01,
lng: 1.4264511111e+02,
content:'Saddle = 427.399994 pos = 44.5311,142.6451 diff = 476.399994'
});
data_peak.push({
lat: 4.4579000000e+01,
lng: 1.4270300000e+02,
cert : true,
content:'Name = JA8/OH-077(JA8/OH-077) peak = 633.400024 pos = 44.5790,142.7030 diff = 154.900024'
});
data_saddle.push({
lat: 4.4582888889e+01,
lng: 1.4269911111e+02,
content:'Saddle = 478.500000 pos = 44.5829,142.6991 diff = 154.900024'
});
data_peak.push({
lat: 4.4572666666e+01,
lng: 1.4267211111e+02,
cert : true,
content:'Name = JA8/OH-056(JA8/OH-056) peak = 778.000000 pos = 44.5727,142.6721 diff = 188.599976'
});
data_saddle.push({
lat: 4.4573111111e+01,
lng: 1.4266366667e+02,
content:'Saddle = 589.400024 pos = 44.5731,142.6637 diff = 188.599976'
});
data_peak.push({
lat: 4.4415666665e+01,
lng: 1.4251011111e+02,
cert : true,
content:'Name = JA8/KK-094(JA8/KK-094) peak = 674.299988 pos = 44.4157,142.5101 diff = 221.500000'
});
data_saddle.push({
lat: 4.4416222221e+01,
lng: 1.4251988889e+02,
content:'Saddle = 452.799988 pos = 44.4162,142.5199 diff = 221.500000'
});
data_peak.push({
lat: 4.4444333332e+01,
lng: 1.4252244444e+02,
cert : false,
content:' Peak = 761.500000 pos = 44.4443,142.5224 diff = 194.299988'
});
data_saddle.push({
lat: 4.4448777776e+01,
lng: 1.4255966667e+02,
content:'Saddle = 567.200012 pos = 44.4488,142.5597 diff = 194.299988'
});
data_peak.push({
lat: 4.4472555554e+01,
lng: 1.4259333333e+02,
cert : true,
content:'Name = JA8/OH-037(JA8/OH-037) peak = 982.700012 pos = 44.4726,142.5933 diff = 224.000000'
});
data_saddle.push({
lat: 4.4455222221e+01,
lng: 1.4259322222e+02,
content:'Saddle = 758.700012 pos = 44.4552,142.5932 diff = 224.000000'
});
data_peak.push({
lat: 4.4619333333e+01,
lng: 1.4253555556e+02,
cert : true,
content:'Name = JA8/SY-005(JA8/SY-005) peak = 793.200012 pos = 44.6193,142.5356 diff = 184.700012'
});
data_saddle.push({
lat: 4.4601222222e+01,
lng: 1.4252155556e+02,
content:'Saddle = 608.500000 pos = 44.6012,142.5216 diff = 184.700012'
});
data_peak.push({
lat: 4.4554777777e+01,
lng: 1.4249055556e+02,
cert : true,
content:'Name = JA8/KK-055(JA8/KK-055) peak = 950.700012 pos = 44.5548,142.4906 diff = 268.299988'
});
data_saddle.push({
lat: 4.4585555555e+01,
lng: 1.4249277778e+02,
content:'Saddle = 682.400024 pos = 44.5856,142.4928 diff = 268.299988'
});
data_peak.push({
lat: 4.4611888889e+01,
lng: 1.4247300000e+02,
cert : true,
content:'Name = JA8/KK-059(JA8/KK-059) peak = 914.700012 pos = 44.6119,142.4730 diff = 186.400024'
});
data_saddle.push({
lat: 4.4618666667e+01,
lng: 1.4244500000e+02,
content:'Saddle = 728.299988 pos = 44.6187,142.4450 diff = 186.400024'
});
data_peak.push({
lat: 4.3787111104e+01,
lng: 1.4253577778e+02,
cert : false,
content:' Peak = 480.200012 pos = 43.7871,142.5358 diff = 177.700012'
});
data_saddle.push({
lat: 4.3774888882e+01,
lng: 1.4256600000e+02,
content:'Saddle = 302.500000 pos = 43.7749,142.5660 diff = 177.700012'
});
data_peak.push({
lat: 4.4291777775e+01,
lng: 1.4308244444e+02,
cert : true,
content:'Name = Utsudake(JA8/OH-054) peak = 816.099976 pos = 44.2918,143.0824 diff = 509.499969'
});
data_saddle.push({
lat: 4.4232666664e+01,
lng: 1.4297977778e+02,
content:'Saddle = 306.600006 pos = 44.2327,142.9798 diff = 509.499969'
});
data_peak.push({
lat: 4.4239666664e+01,
lng: 1.4311277778e+02,
cert : true,
content:'Name = JA8/OH-086(JA8/OH-086) peak = 561.000000 pos = 44.2397,143.1128 diff = 152.700012'
});
data_saddle.push({
lat: 4.4246555553e+01,
lng: 1.4311188889e+02,
content:'Saddle = 408.299988 pos = 44.2466,143.1119 diff = 152.700012'
});
data_peak.push({
lat: 4.4257444442e+01,
lng: 1.4306166667e+02,
cert : true,
content:'Name = JA8/OH-058(JA8/OH-058) peak = 764.700012 pos = 44.2574,143.0617 diff = 162.400024'
});
data_saddle.push({
lat: 4.4261666664e+01,
lng: 1.4307000000e+02,
content:'Saddle = 602.299988 pos = 44.2617,143.0700 diff = 162.400024'
});
data_peak.push({
lat: 4.3878333327e+01,
lng: 1.4371822222e+02,
cert : true,
content:'Name = Nikoroyama(JA8/OH-053) peak = 828.099976 pos = 43.8783,143.7182 diff = 508.999969'
});
data_saddle.push({
lat: 4.3827999994e+01,
lng: 1.4363844444e+02,
content:'Saddle = 319.100006 pos = 43.8280,143.6384 diff = 508.999969'
});
data_peak.push({
lat: 4.3949333328e+01,
lng: 1.4378877778e+02,
cert : false,
content:' Peak = 548.400024 pos = 43.9493,143.7888 diff = 155.000031'
});
data_saddle.push({
lat: 4.3952333328e+01,
lng: 1.4376233333e+02,
content:'Saddle = 393.399994 pos = 43.9523,143.7623 diff = 155.000031'
});
data_peak.push({
lat: 4.3908333328e+01,
lng: 1.4374166667e+02,
cert : true,
content:'Name = JA8/OH-068(JA8/OH-068) peak = 710.200012 pos = 43.9083,143.7417 diff = 246.700012'
});
data_saddle.push({
lat: 4.3894666661e+01,
lng: 1.4372677778e+02,
content:'Saddle = 463.500000 pos = 43.8947,143.7268 diff = 246.700012'
});
data_peak.push({
lat: 4.3932888883e+01,
lng: 1.4375011111e+02,
cert : true,
content:'Name = JA8/OH-070(JA8/OH-070) peak = 695.000000 pos = 43.9329,143.7501 diff = 190.500000'
});
data_saddle.push({
lat: 4.3926444439e+01,
lng: 1.4375566667e+02,
content:'Saddle = 504.500000 pos = 43.9264,143.7557 diff = 190.500000'
});
data_peak.push({
lat: 4.3386222212e+01,
lng: 1.4399988889e+02,
cert : false,
content:' Peak = 1251.900024 pos = 43.3862,143.9999 diff = 927.000000'
});
data_saddle.push({
lat: 4.3549111103e+01,
lng: 1.4384044444e+02,
content:'Saddle = 324.899994 pos = 43.5491,143.8404 diff = 927.000000'
});
data_peak.push({
lat: 4.3266666656e+01,
lng: 1.4374477778e+02,
cert : true,
content:'Name = JA8/TC-113(JA8/TC-113) peak = 480.200012 pos = 43.2667,143.7448 diff = 152.900024'
});
data_saddle.push({
lat: 4.3261111100e+01,
lng: 1.4376444444e+02,
content:'Saddle = 327.299988 pos = 43.2611,143.7644 diff = 152.900024'
});
data_peak.push({
lat: 4.3160555544e+01,
lng: 1.4398844444e+02,
cert : true,
content:'Name = JA8/KR-029(JA8/KR-029) peak = 566.099976 pos = 43.1606,143.9884 diff = 223.699982'
});
data_saddle.push({
lat: 4.3179444433e+01,
lng: 1.4391611111e+02,
content:'Saddle = 342.399994 pos = 43.1794,143.9161 diff = 223.699982'
});
data_peak.push({
lat: 4.3207555544e+01,
lng: 1.4373333333e+02,
cert : false,
content:' Peak = 547.000000 pos = 43.2076,143.7333 diff = 184.799988'
});
data_saddle.push({
lat: 4.3210333322e+01,
lng: 1.4376288889e+02,
content:'Saddle = 362.200012 pos = 43.2103,143.7629 diff = 184.799988'
});
data_peak.push({
lat: 4.3373666657e+01,
lng: 1.4375600000e+02,
cert : false,
content:' Peak = 553.099976 pos = 43.3737,143.7560 diff = 184.399963'
});
data_saddle.push({
lat: 4.3409111101e+01,
lng: 1.4380300000e+02,
content:'Saddle = 368.700012 pos = 43.4091,143.8030 diff = 184.399963'
});
data_peak.push({
lat: 4.3100111099e+01,
lng: 1.4380000000e+02,
cert : false,
content:' Peak = 532.599976 pos = 43.1001,143.8000 diff = 153.899963'
});
data_saddle.push({
lat: 4.3102999988e+01,
lng: 1.4378988889e+02,
content:'Saddle = 378.700012 pos = 43.1030,143.7899 diff = 153.899963'
});
data_peak.push({
lat: 4.3016333320e+01,
lng: 1.4372122222e+02,
cert : true,
content:'Name = JA8/KR-026(JA8/KR-026) peak = 611.700012 pos = 43.0163,143.7212 diff = 229.300018'
});
data_saddle.push({
lat: 4.3037444432e+01,
lng: 1.4371033333e+02,
content:'Saddle = 382.399994 pos = 43.0374,143.7103 diff = 229.300018'
});
data_peak.push({
lat: 4.3006222209e+01,
lng: 1.4375644444e+02,
cert : false,
content:' Peak = 543.500000 pos = 43.0062,143.7564 diff = 151.100006'
});
data_saddle.push({
lat: 4.3002222209e+01,
lng: 1.4375033333e+02,
content:'Saddle = 392.399994 pos = 43.0022,143.7503 diff = 151.100006'
});
data_peak.push({
lat: 4.2972444431e+01,
lng: 1.4372877778e+02,
cert : false,
content:' Peak = 565.700012 pos = 42.9724,143.7288 diff = 154.300018'
});
data_saddle.push({
lat: 4.3007555543e+01,
lng: 1.4370433333e+02,
content:'Saddle = 411.399994 pos = 43.0076,143.7043 diff = 154.300018'
});
data_peak.push({
lat: 4.3470555546e+01,
lng: 1.4381666667e+02,
cert : true,
content:'Name = JA8/TC-099(JA8/TC-099) peak = 641.400024 pos = 43.4706,143.8167 diff = 233.300018'
});
data_saddle.push({
lat: 4.3479222213e+01,
lng: 1.4386855556e+02,
content:'Saddle = 408.100006 pos = 43.4792,143.8686 diff = 233.300018'
});
data_peak.push({
lat: 4.3491555546e+01,
lng: 1.4382488889e+02,
cert : true,
content:'Name = JA8/TC-101(JA8/TC-101) peak = 612.500000 pos = 43.4916,143.8249 diff = 159.700012'
});
data_saddle.push({
lat: 4.3476555546e+01,
lng: 1.4383177778e+02,
content:'Saddle = 452.799988 pos = 43.4766,143.8318 diff = 159.700012'
});
data_peak.push({
lat: 4.3153666655e+01,
lng: 1.4380033333e+02,
cert : true,
content:'Name = JA8/KR-019(JA8/KR-019) peak = 702.299988 pos = 43.1537,143.8003 diff = 269.500000'
});
data_saddle.push({
lat: 4.3149444433e+01,
lng: 1.4378188889e+02,
content:'Saddle = 432.799988 pos = 43.1494,143.7819 diff = 269.500000'
});
data_peak.push({
lat: 4.3264444434e+01,
lng: 1.4390733333e+02,
cert : true,
content:'Name = JA8/KR-024(JA8/KR-024) peak = 633.200012 pos = 43.2644,143.9073 diff = 191.600006'
});
data_saddle.push({
lat: 4.3280333323e+01,
lng: 1.4390300000e+02,
content:'Saddle = 441.600006 pos = 43.2803,143.9030 diff = 191.600006'
});
data_peak.push({
lat: 4.3123444432e+01,
lng: 1.4380277778e+02,
cert : true,
content:'Name = JA8/KR-021(JA8/KR-021) peak = 681.099976 pos = 43.1234,143.8028 diff = 239.299988'
});
data_saddle.push({
lat: 4.3121222210e+01,
lng: 1.4378933333e+02,
content:'Saddle = 441.799988 pos = 43.1212,143.7893 diff = 239.299988'
});
data_peak.push({
lat: 4.3208555544e+01,
lng: 1.4379755556e+02,
cert : true,
content:'Name = Ukotakinupuri(JA8/KR-016) peak = 745.000000 pos = 43.2086,143.7976 diff = 302.899994'
});
data_saddle.push({
lat: 4.3286555545e+01,
lng: 1.4383977778e+02,
content:'Saddle = 442.100006 pos = 43.2866,143.8398 diff = 302.899994'
});
data_peak.push({
lat: 4.3246888878e+01,
lng: 1.4381144444e+02,
cert : true,
content:'Name = JA8/KR-025(JA8/KR-025) peak = 626.299988 pos = 43.2469,143.8114 diff = 163.699982'
});
data_saddle.push({
lat: 4.3220666655e+01,
lng: 1.4378933333e+02,
content:'Saddle = 462.600006 pos = 43.2207,143.7893 diff = 163.699982'
});
data_peak.push({
lat: 4.3087666654e+01,
lng: 1.4377122222e+02,
cert : true,
content:'Name = JA8/KR-018(JA8/KR-018) peak = 721.599976 pos = 43.0877,143.7712 diff = 249.699982'
});
data_saddle.push({
lat: 4.3144999988e+01,
lng: 1.4377077778e+02,
content:'Saddle = 471.899994 pos = 43.1450,143.7708 diff = 249.699982'
});
data_peak.push({
lat: 4.3063555543e+01,
lng: 1.4374366667e+02,
cert : true,
content:'Name = JA8/KR-022(JA8/KR-022) peak = 673.200012 pos = 43.0636,143.7437 diff = 160.299988'
});
data_saddle.push({
lat: 4.3088444432e+01,
lng: 1.4375522222e+02,
content:'Saddle = 512.900024 pos = 43.0884,143.7552 diff = 160.299988'
});
data_peak.push({
lat: 4.3178888877e+01,
lng: 1.4376055556e+02,
cert : false,
content:' Peak = 677.200012 pos = 43.1789,143.7606 diff = 156.299988'
});
data_saddle.push({
lat: 4.3182999988e+01,
lng: 1.4377411111e+02,
content:'Saddle = 520.900024 pos = 43.1830,143.7741 diff = 156.299988'
});
data_peak.push({
lat: 4.3305333323e+01,
lng: 1.4399444444e+02,
cert : false,
content:' Peak = 690.599976 pos = 43.3053,143.9944 diff = 223.999969'
});
data_saddle.push({
lat: 4.3330888879e+01,
lng: 1.4399977778e+02,
content:'Saddle = 466.600006 pos = 43.3309,143.9998 diff = 223.999969'
});
data_peak.push({
lat: 4.3324777767e+01,
lng: 1.4399477778e+02,
cert : false,
content:' Peak = 680.000000 pos = 43.3248,143.9948 diff = 202.799988'
});
data_saddle.push({
lat: 4.3314999990e+01,
lng: 1.4399988889e+02,
content:'Saddle = 477.200012 pos = 43.3150,143.9999 diff = 202.799988'
});
data_peak.push({
lat: 4.3265999989e+01,
lng: 1.4386455556e+02,
cert : true,
content:'Name = JA8/KR-023(JA8/KR-023) peak = 670.200012 pos = 43.2660,143.8646 diff = 187.300018'
});
data_saddle.push({
lat: 4.3282444434e+01,
lng: 1.4387011111e+02,
content:'Saddle = 482.899994 pos = 43.2824,143.8701 diff = 187.300018'
});
data_peak.push({
lat: 4.3333777767e+01,
lng: 1.4391766667e+02,
cert : true,
content:'Name = JA8/TC-092(JA8/TC-092) peak = 814.900024 pos = 43.3338,143.9177 diff = 257.500000'
});
data_saddle.push({
lat: 4.3348444434e+01,
lng: 1.4394477778e+02,
content:'Saddle = 557.400024 pos = 43.3484,143.9448 diff = 257.500000'
});
data_peak.push({
lat: 4.3502444435e+01,
lng: 1.4394055556e+02,
cert : true,
content:'Name = JA8/OH-065(JA8/OH-065) peak = 736.599976 pos = 43.5024,143.9406 diff = 161.199951'
});
data_saddle.push({
lat: 4.3496222213e+01,
lng: 1.4394166667e+02,
content:'Saddle = 575.400024 pos = 43.4962,143.9417 diff = 161.199951'
});
data_peak.push({
lat: 4.3485888880e+01,
lng: 1.4394977778e+02,
cert : true,
content:'Name = JA8/OH-046(JA8/OH-046) peak = 901.299988 pos = 43.4859,143.9498 diff = 307.000000'
});
data_saddle.push({
lat: 4.3449888879e+01,
lng: 1.4399988889e+02,
content:'Saddle = 594.299988 pos = 43.4499,143.9999 diff = 307.000000'
});
data_peak.push({
lat: 4.2180333314e+01,
lng: 1.4302266667e+02,
cert : true,
content:'Name = JA8/HD-097(JA8/HD-097) peak = 522.200012 pos = 42.1803,143.0227 diff = 193.700012'
});
data_saddle.push({
lat: 4.2176222203e+01,
lng: 1.4303011111e+02,
content:'Saddle = 328.500000 pos = 42.1762,143.0301 diff = 193.700012'
});
data_peak.push({
lat: 4.2306444426e+01,
lng: 1.4289933333e+02,
cert : false,
content:' Peak = 615.200012 pos = 42.3064,142.8993 diff = 284.400024'
});
data_saddle.push({
lat: 4.2326111093e+01,
lng: 1.4290533333e+02,
content:'Saddle = 330.799988 pos = 42.3261,142.9053 diff = 284.400024'
});
data_peak.push({
lat: 4.3213666655e+01,
lng: 1.4247044444e+02,
cert : true,
content:'Name = JA8/KK-120(JA8/KK-120) peak = 483.899994 pos = 43.2137,142.4704 diff = 152.299988'
});
data_saddle.push({
lat: 4.3233444433e+01,
lng: 1.4248422222e+02,
content:'Saddle = 331.600006 pos = 43.2334,142.4842 diff = 152.299988'
});
data_peak.push({
lat: 4.2783999985e+01,
lng: 1.4237744444e+02,
cert : true,
content:'Name = JA8/HD-095(JA8/HD-095) peak = 540.400024 pos = 42.7840,142.3774 diff = 208.700012'
});
data_saddle.push({
lat: 4.2802555541e+01,
lng: 1.4238444444e+02,
content:'Saddle = 331.700012 pos = 42.8026,142.3844 diff = 208.700012'
});
data_peak.push({
lat: 4.3674777770e+01,
lng: 1.4389833333e+02,
cert : true,
content:'Name = JA8/OH-090(JA8/OH-090) peak = 533.900024 pos = 43.6748,143.8983 diff = 201.100037'
});
data_saddle.push({
lat: 4.3668777770e+01,
lng: 1.4387944444e+02,
content:'Saddle = 332.799988 pos = 43.6688,143.8794 diff = 201.100037'
});
data_peak.push({
lat: 4.4117333329e+01,
lng: 1.4302422222e+02,
cert : true,
content:'Name = JA8/OH-092(JA8/OH-092) peak = 511.200012 pos = 44.1173,143.0242 diff = 174.900024'
});
data_saddle.push({
lat: 4.4115444440e+01,
lng: 1.4302933333e+02,
content:'Saddle = 336.299988 pos = 44.1154,143.0293 diff = 174.900024'
});
data_peak.push({
lat: 4.2256666648e+01,
lng: 1.4300266667e+02,
cert : true,
content:'Name = JA8/HD-090(JA8/HD-090) peak = 602.900024 pos = 42.2567,143.0027 diff = 261.000031'
});
data_saddle.push({
lat: 4.2270111092e+01,
lng: 1.4301322222e+02,
content:'Saddle = 341.899994 pos = 42.2701,143.0132 diff = 261.000031'
});
data_peak.push({
lat: 4.2874111097e+01,
lng: 1.4206444444e+02,
cert : true,
content:'Name = JA8/IR-019(JA8/IR-019) peak = 642.599976 pos = 42.8741,142.0644 diff = 300.699982'
});
data_saddle.push({
lat: 4.2884222208e+01,
lng: 1.4209533333e+02,
content:'Saddle = 341.899994 pos = 42.8842,142.0953 diff = 300.699982'
});
data_peak.push({
lat: 4.2340666648e+01,
lng: 1.4318855556e+02,
cert : true,
content:'Name = JA8/TC-109(JA8/TC-109) peak = 493.100006 pos = 42.3407,143.1886 diff = 151.100006'
});
data_saddle.push({
lat: 4.2338777759e+01,
lng: 1.4318355556e+02,
content:'Saddle = 342.000000 pos = 42.3388,143.1836 diff = 151.100006'
});
data_peak.push({
lat: 4.2319999982e+01,
lng: 1.4280955556e+02,
cert : true,
content:'Name = JA8/HD-099(JA8/HD-099) peak = 507.100006 pos = 42.3200,142.8096 diff = 164.700012'
});
data_saddle.push({
lat: 4.2324111093e+01,
lng: 1.4281566667e+02,
content:'Saddle = 342.399994 pos = 42.3241,142.8157 diff = 164.700012'
});
data_peak.push({
lat: 4.2280333315e+01,
lng: 1.4295644444e+02,
cert : true,
content:'Name = JA8/HD-096(JA8/HD-096) peak = 535.500000 pos = 42.2803,142.9564 diff = 192.200012'
});
data_saddle.push({
lat: 4.2289999981e+01,
lng: 1.4295933333e+02,
content:'Saddle = 343.299988 pos = 42.2900,142.9593 diff = 192.200012'
});
data_peak.push({
lat: 4.4146666663e+01,
lng: 1.4255155556e+02,
cert : true,
content:'Name = JA8/KK-118(JA8/KK-118) peak = 513.000000 pos = 44.1467,142.5516 diff = 160.100006'
});
data_saddle.push({
lat: 4.4151555552e+01,
lng: 1.4256111111e+02,
content:'Saddle = 352.899994 pos = 44.1516,142.5611 diff = 160.100006'
});
data_peak.push({
lat: 4.3647555548e+01,
lng: 1.4390488889e+02,
cert : true,
content:'Name = JA8/OH-082(JA8/OH-082) peak = 618.299988 pos = 43.6476,143.9049 diff = 260.500000'
});
data_saddle.push({
lat: 4.3656777770e+01,
lng: 1.4387311111e+02,
content:'Saddle = 357.799988 pos = 43.6568,143.8731 diff = 260.500000'
});
data_peak.push({
lat: 4.3608888881e+01,
lng: 1.4388722222e+02,
cert : true,
content:'Name = JA8/OH-084(JA8/OH-084) peak = 597.700012 pos = 43.6089,143.8872 diff = 238.600006'
});
data_saddle.push({
lat: 4.3616555547e+01,
lng: 1.4387066667e+02,
content:'Saddle = 359.100006 pos = 43.6166,143.8707 diff = 238.600006'
});
data_peak.push({
lat: 4.3670222215e+01,
lng: 1.4380677778e+02,
cert : false,
content:' Peak = 521.299988 pos = 43.6702,143.8068 diff = 153.599976'
});
data_saddle.push({
lat: 4.3669111103e+01,
lng: 1.4382266667e+02,
content:'Saddle = 367.700012 pos = 43.6691,143.8227 diff = 153.599976'
});
data_peak.push({
lat: 4.3896888883e+01,
lng: 1.4358711111e+02,
cert : true,
content:'Name = JA8/OH-069(JA8/OH-069) peak = 707.400024 pos = 43.8969,143.5871 diff = 339.500031'
});
data_saddle.push({
lat: 4.3814999994e+01,
lng: 1.4351333333e+02,
content:'Saddle = 367.899994 pos = 43.8150,143.5133 diff = 339.500031'
});
data_peak.push({
lat: 4.3850666660e+01,
lng: 1.4353411111e+02,
cert : true,
content:'Name = JA8/OH-087(JA8/OH-087) peak = 562.099976 pos = 43.8507,143.5341 diff = 164.799988'
});
data_saddle.push({
lat: 4.3840555549e+01,
lng: 1.4354644444e+02,
content:'Saddle = 397.299988 pos = 43.8406,143.5464 diff = 164.799988'
});
data_peak.push({
lat: 4.2914777764e+01,
lng: 1.4211044444e+02,
cert : true,
content:'Name = JA8/SC-054(JA8/SC-054) peak = 541.900024 pos = 42.9148,142.1104 diff = 171.000031'
});
data_saddle.push({
lat: 4.2918222209e+01,
lng: 1.4211855556e+02,
content:'Saddle = 370.899994 pos = 42.9182,142.1186 diff = 171.000031'
});
data_peak.push({
lat: 4.3265444434e+01,
lng: 1.4241655556e+02,
cert : true,
content:'Name = JA8/KK-105(JA8/KK-105) peak = 602.200012 pos = 43.2654,142.4166 diff = 226.600006'
});
data_saddle.push({
lat: 4.3285222212e+01,
lng: 1.4249222222e+02,
content:'Saddle = 375.600006 pos = 43.2852,142.4922 diff = 226.600006'
});
data_peak.push({
lat: 4.2995333320e+01,
lng: 1.4210200000e+02,
cert : false,
content:' Peak = 752.000000 pos = 42.9953,142.1020 diff = 374.600006'
});
data_saddle.push({
lat: 4.2957222209e+01,
lng: 1.4217433333e+02,
content:'Saddle = 377.399994 pos = 42.9572,142.1743 diff = 374.600006'
});
data_peak.push({
lat: 4.2907222208e+01,
lng: 1.4216144444e+02,
cert : false,
content:' Peak = 572.299988 pos = 42.9072,142.1614 diff = 150.199982'
});
data_saddle.push({
lat: 4.2959888876e+01,
lng: 1.4213077778e+02,
content:'Saddle = 422.100006 pos = 42.9599,142.1308 diff = 150.199982'
});
data_peak.push({
lat: 4.2579555539e+01,
lng: 1.4309255556e+02,
cert : true,
content:'Name = JA8/TC-107(JA8/TC-107) peak = 537.000000 pos = 42.5796,143.0926 diff = 158.899994'
});
data_saddle.push({
lat: 4.2577999984e+01,
lng: 1.4308200000e+02,
content:'Saddle = 378.100006 pos = 42.5780,143.0820 diff = 158.899994'
});
data_peak.push({
lat: 4.3861111105e+01,
lng: 1.4273511111e+02,
cert : true,
content:'Name = JA8/KK-107(JA8/KK-107) peak = 590.900024 pos = 43.8611,142.7351 diff = 210.100037'
});
data_saddle.push({
lat: 4.3856444438e+01,
lng: 1.4276255556e+02,
content:'Saddle = 380.799988 pos = 43.8564,142.7626 diff = 210.100037'
});
data_peak.push({
lat: 4.3169666655e+01,
lng: 1.4288477778e+02,
cert : true,
content:'Name = JA8/TC-106(JA8/TC-106) peak = 540.500000 pos = 43.1697,142.8848 diff = 157.399994'
});
data_saddle.push({
lat: 4.3181222211e+01,
lng: 1.4287533333e+02,
content:'Saddle = 383.100006 pos = 43.1812,142.8753 diff = 157.399994'
});
data_peak.push({
lat: 4.3573666658e+01,
lng: 1.4382233333e+02,
cert : true,
content:'Name = JA8/TC-103(JA8/TC-103) peak = 600.099976 pos = 43.5737,143.8223 diff = 216.799988'
});
data_saddle.push({
lat: 4.3586999992e+01,
lng: 1.4380111111e+02,
content:'Saddle = 383.299988 pos = 43.5870,143.8011 diff = 216.799988'
});
data_peak.push({
lat: 4.4149333330e+01,
lng: 1.4327022222e+02,
cert : true,
content:'Name = JA8/OH-078(JA8/OH-078) peak = 630.000000 pos = 44.1493,143.2702 diff = 246.600006'
});
data_saddle.push({
lat: 4.4127333329e+01,
lng: 1.4329400000e+02,
content:'Saddle = 383.399994 pos = 44.1273,143.2940 diff = 246.600006'
});
data_peak.push({
lat: 4.4128333329e+01,
lng: 1.4327211111e+02,
cert : true,
content:'Name = JA8/OH-085(JA8/OH-085) peak = 586.200012 pos = 44.1283,143.2721 diff = 197.100006'
});
data_saddle.push({
lat: 4.4137555552e+01,
lng: 1.4327311111e+02,
content:'Saddle = 389.100006 pos = 44.1376,143.2731 diff = 197.100006'
});
data_peak.push({
lat: 4.3720999993e+01,
lng: 1.4259888889e+02,
cert : true,
content:'Name = JA8/KK-111(JA8/KK-111) peak = 570.700012 pos = 43.7210,142.5989 diff = 185.000000'
});
data_saddle.push({
lat: 4.3719555548e+01,
lng: 1.4262300000e+02,
content:'Saddle = 385.700012 pos = 43.7196,142.6230 diff = 185.000000'
});
data_peak.push({
lat: 4.2751444429e+01,
lng: 1.4240111111e+02,
cert : true,
content:'Name = JA8/HD-094(JA8/HD-094) peak = 550.900024 pos = 42.7514,142.4011 diff = 164.500031'
});
data_saddle.push({
lat: 4.2740555540e+01,
lng: 1.4241388889e+02,
content:'Saddle = 386.399994 pos = 42.7406,142.4139 diff = 164.500031'
});
data_peak.push({
lat: 4.3035333321e+01,
lng: 1.4281388889e+02,
cert : false,
content:' Peak = 546.000000 pos = 43.0353,142.8139 diff = 158.100006'
});
data_saddle.push({
lat: 4.3030555543e+01,
lng: 1.4280622222e+02,
content:'Saddle = 387.899994 pos = 43.0306,142.8062 diff = 158.100006'
});
data_peak.push({
lat: 4.4129111107e+01,
lng: 1.4331166667e+02,
cert : true,
content:'Name = JA8/OH-089(JA8/OH-089) peak = 540.700012 pos = 44.1291,143.3117 diff = 151.300018'
});
data_saddle.push({
lat: 4.4127444440e+01,
lng: 1.4330355556e+02,
content:'Saddle = 389.399994 pos = 44.1274,143.3036 diff = 151.300018'
});
data_peak.push({
lat: 4.3643222214e+01,
lng: 1.4361677778e+02,
cert : true,
content:'Name = JA8/OH-074(JA8/OH-074) peak = 640.900024 pos = 43.6432,143.6168 diff = 246.500031'
});
data_saddle.push({
lat: 4.3616333325e+01,
lng: 1.4362366667e+02,
content:'Saddle = 394.399994 pos = 43.6163,143.6237 diff = 246.500031'
});
data_peak.push({
lat: 4.3644333325e+01,
lng: 1.4378455556e+02,
cert : true,
content:'Name = JA8/OH-083(JA8/OH-083) peak = 604.700012 pos = 43.6443,143.7846 diff = 163.300018'
});
data_saddle.push({
lat: 4.3628999992e+01,
lng: 1.4367044444e+02,
content:'Saddle = 441.399994 pos = 43.6290,143.6704 diff = 163.300018'
});
data_peak.push({
lat: 4.3436666657e+01,
lng: 1.4217400000e+02,
cert : true,
content:'Name = JA8/SC-051(JA8/SC-051) peak = 584.400024 pos = 43.4367,142.1740 diff = 182.100037'
});
data_saddle.push({
lat: 4.3439999991e+01,
lng: 1.4218644444e+02,
content:'Saddle = 402.299988 pos = 43.4400,142.1864 diff = 182.100037'
});
data_peak.push({
lat: 4.2270555537e+01,
lng: 1.4297433333e+02,
cert : true,
content:'Name = JA8/HD-086(JA8/HD-086) peak = 624.599976 pos = 42.2706,142.9743 diff = 221.899963'
});
data_saddle.push({
lat: 4.2279555537e+01,
lng: 1.4298444444e+02,
content:'Saddle = 402.700012 pos = 42.2796,142.9844 diff = 221.899963'
});
data_peak.push({
lat: 4.2163999980e+01,
lng: 1.4327955556e+02,
cert : true,
content:'Name = JA8/TC-102(JA8/TC-102) peak = 606.700012 pos = 42.1640,143.2796 diff = 203.600006'
});
data_saddle.push({
lat: 4.2168777758e+01,
lng: 1.4326588889e+02,
content:'Saddle = 403.100006 pos = 42.1688,143.2659 diff = 203.600006'
});
data_peak.push({
lat: 4.2357444426e+01,
lng: 1.4277844444e+02,
cert : true,
content:'Name = JA8/HD-093(JA8/HD-093) peak = 560.599976 pos = 42.3574,142.7784 diff = 155.899963'
});
data_saddle.push({
lat: 4.2364666649e+01,
lng: 1.4278344444e+02,
content:'Saddle = 404.700012 pos = 42.3647,142.7834 diff = 155.899963'
});
data_peak.push({
lat: 4.2340333315e+01,
lng: 1.4258444444e+02,
cert : true,
content:'Name = JA8/HD-075(JA8/HD-075) peak = 732.599976 pos = 42.3403,142.5844 diff = 310.399963'
});
data_saddle.push({
lat: 4.2383555538e+01,
lng: 1.4257600000e+02,
content:'Saddle = 422.200012 pos = 42.3836,142.5760 diff = 310.399963'
});
data_peak.push({
lat: 4.2382333315e+01,
lng: 1.4254833333e+02,
cert : true,
content:'Name = JA8/HD-077(JA8/HD-077) peak = 718.200012 pos = 42.3823,142.5483 diff = 224.700012'
});
data_saddle.push({
lat: 4.2369333315e+01,
lng: 1.4256811111e+02,
content:'Saddle = 493.500000 pos = 42.3693,142.5681 diff = 224.700012'
});
data_peak.push({
lat: 4.3398111101e+01,
lng: 1.4220500000e+02,
cert : true,
content:'Name = JA8/SC-034(JA8/SC-034) peak = 756.700012 pos = 43.3981,142.2050 diff = 325.800018'
});
data_saddle.push({
lat: 4.3401222212e+01,
lng: 1.4223277778e+02,
content:'Saddle = 430.899994 pos = 43.4012,142.2328 diff = 325.800018'
});
data_peak.push({
lat: 4.4069444440e+01,
lng: 1.4271811111e+02,
cert : false,
content:' Peak = 714.599976 pos = 44.0694,142.7181 diff = 281.699982'
});
data_saddle.push({
lat: 4.4040777773e+01,
lng: 1.4269911111e+02,
content:'Saddle = 432.899994 pos = 44.0408,142.6991 diff = 281.699982'
});
data_peak.push({
lat: 4.2413666649e+01,
lng: 1.4263766667e+02,
cert : true,
content:'Name = JA8/HD-045(JA8/HD-045) peak = 1026.900024 pos = 42.4137,142.6377 diff = 593.700012'
});
data_saddle.push({
lat: 4.2431666649e+01,
lng: 1.4269711111e+02,
content:'Saddle = 433.200012 pos = 42.4317,142.6971 diff = 593.700012'
});
data_peak.push({
lat: 4.2385222204e+01,
lng: 1.4264422222e+02,
cert : true,
content:'Name = JA8/HD-062(JA8/HD-062) peak = 877.299988 pos = 42.3852,142.6442 diff = 164.799988'
});
data_saddle.push({
lat: 4.2389777760e+01,
lng: 1.4264555556e+02,
content:'Saddle = 712.500000 pos = 42.3898,142.6456 diff = 164.799988'
});
data_peak.push({
lat: 4.3801666660e+01,
lng: 1.4352300000e+02,
cert : true,
content:'Name = JA8/OH-080(JA8/OH-080) peak = 621.299988 pos = 43.8017,143.5230 diff = 183.299988'
});
data_saddle.push({
lat: 4.3797888882e+01,
lng: 1.4351288889e+02,
content:'Saddle = 438.000000 pos = 43.7979,143.5129 diff = 183.299988'
});
data_peak.push({
lat: 4.2139666647e+01,
lng: 1.4303600000e+02,
cert : false,
content:' Peak = 956.799988 pos = 42.1397,143.0360 diff = 518.599976'
});
data_saddle.push({
lat: 4.2157111091e+01,
lng: 1.4304600000e+02,
content:'Saddle = 438.200012 pos = 42.1571,143.0460 diff = 518.599976'
});
data_peak.push({
lat: 4.2095666646e+01,
lng: 1.4306177778e+02,
cert : true,
content:'Name = JA8/HD-084(JA8/HD-084) peak = 684.700012 pos = 42.0957,143.0618 diff = 242.600006'
});
data_saddle.push({
lat: 4.2113777758e+01,
lng: 1.4307700000e+02,
content:'Saddle = 442.100006 pos = 42.1138,143.0770 diff = 242.600006'
});
data_peak.push({
lat: 4.4041444440e+01,
lng: 1.4256911111e+02,
cert : true,
content:'Name = JA8/KK-073(JA8/KK-073) peak = 836.700012 pos = 44.0414,142.5691 diff = 394.500000'
});
data_saddle.push({
lat: 4.4017999995e+01,
lng: 1.4262888889e+02,
content:'Saddle = 442.200012 pos = 44.0180,142.6289 diff = 394.500000'
});
data_peak.push({
lat: 4.4094111107e+01,
lng: 1.4257788889e+02,
cert : true,
content:'Name = JA8/KK-096(JA8/KK-096) peak = 643.900024 pos = 44.0941,142.5779 diff = 197.100037'
});
data_saddle.push({
lat: 4.4074444440e+01,
lng: 1.4257911111e+02,
content:'Saddle = 446.799988 pos = 44.0744,142.5791 diff = 197.100037'
});
data_peak.push({
lat: 4.3956111106e+01,
lng: 1.4254388889e+02,
cert : true,
content:'Name = JA8/KK-084(JA8/KK-084) peak = 754.400024 pos = 43.9561,142.5439 diff = 200.900024'
});
data_saddle.push({
lat: 4.3969666661e+01,
lng: 1.4252800000e+02,
content:'Saddle = 553.500000 pos = 43.9697,142.5280 diff = 200.900024'
});
data_peak.push({
lat: 4.3979999995e+01,
lng: 1.4254088889e+02,
cert : true,
content:'Name = JA8/KK-075(JA8/KK-075) peak = 819.799988 pos = 43.9800,142.5409 diff = 220.000000'
});
data_saddle.push({
lat: 4.3985888884e+01,
lng: 1.4253288889e+02,
content:'Saddle = 599.799988 pos = 43.9859,142.5329 diff = 220.000000'
});
data_peak.push({
lat: 4.3990444439e+01,
lng: 1.4251677778e+02,
cert : true,
content:'Name = JA8/KK-074(JA8/KK-074) peak = 827.700012 pos = 43.9904,142.5168 diff = 220.200012'
});
data_saddle.push({
lat: 4.4026444440e+01,
lng: 1.4253766667e+02,
content:'Saddle = 607.500000 pos = 44.0264,142.5377 diff = 220.200012'
});
data_peak.push({
lat: 4.4179111108e+01,
lng: 1.4293811111e+02,
cert : true,
content:'Name = JA8/OH-072(JA8/OH-072) peak = 661.299988 pos = 44.1791,142.9381 diff = 218.599976'
});
data_saddle.push({
lat: 4.4194666663e+01,
lng: 1.4291755556e+02,
content:'Saddle = 442.700012 pos = 44.1947,142.9176 diff = 218.599976'
});
data_peak.push({
lat: 4.3337888879e+01,
lng: 1.4215900000e+02,
cert : false,
content:' Peak = 604.099976 pos = 43.3379,142.1590 diff = 156.399963'
});
data_saddle.push({
lat: 4.3348111101e+01,
lng: 1.4216411111e+02,
content:'Saddle = 447.700012 pos = 43.3481,142.1641 diff = 156.399963'
});
data_peak.push({
lat: 4.4166555552e+01,
lng: 1.4263633333e+02,
cert : true,
content:'Name = JA8/KK-060(JA8/KK-060) peak = 912.500000 pos = 44.1666,142.6363 diff = 464.299988'
});
data_saddle.push({
lat: 4.4183333330e+01,
lng: 1.4266900000e+02,
content:'Saddle = 448.200012 pos = 44.1833,142.6690 diff = 464.299988'
});
data_peak.push({
lat: 4.4181777774e+01,
lng: 1.4253322222e+02,
cert : true,
content:'Name = JA8/KK-092(JA8/KK-092) peak = 702.599976 pos = 44.1818,142.5332 diff = 194.599976'
});
data_saddle.push({
lat: 4.4191999997e+01,
lng: 1.4254155556e+02,
content:'Saddle = 508.000000 pos = 44.1920,142.5416 diff = 194.599976'
});
data_peak.push({
lat: 4.4178222219e+01,
lng: 1.4257288889e+02,
cert : false,
content:' Peak = 789.900024 pos = 44.1782,142.5729 diff = 151.700012'
});
data_saddle.push({
lat: 4.4174555552e+01,
lng: 1.4259544444e+02,
content:'Saddle = 638.200012 pos = 44.1746,142.5954 diff = 151.700012'
});
data_peak.push({
lat: 4.2848777764e+01,
lng: 1.4222766667e+02,
cert : true,
content:'Name = JA8/IR-011(JA8/IR-011) peak = 790.500000 pos = 42.8488,142.2277 diff = 336.500000'
});
data_saddle.push({
lat: 4.2896111097e+01,
lng: 1.4222155556e+02,
content:'Saddle = 454.000000 pos = 42.8961,142.2216 diff = 336.500000'
});
data_peak.push({
lat: 4.2546333317e+01,
lng: 1.4304600000e+02,
cert : true,
content:'Name = JA8/TC-100(JA8/TC-100) peak = 619.500000 pos = 42.5463,143.0460 diff = 163.299988'
});
data_saddle.push({
lat: 4.2548111094e+01,
lng: 1.4303488889e+02,
content:'Saddle = 456.200012 pos = 42.5481,143.0349 diff = 163.299988'
});
data_peak.push({
lat: 4.4049444440e+01,
lng: 1.4321788889e+02,
cert : true,
content:'Name = JA8/OH-076(JA8/OH-076) peak = 632.900024 pos = 44.0494,143.2179 diff = 175.400024'
});
data_saddle.push({
lat: 4.4045222218e+01,
lng: 1.4321766667e+02,
content:'Saddle = 457.500000 pos = 44.0452,143.2177 diff = 175.400024'
});
data_peak.push({
lat: 4.2137777758e+01,
lng: 1.4321788889e+02,
cert : true,
content:'Name = JA8/HD-076(JA8/HD-076) peak = 720.599976 pos = 42.1378,143.2179 diff = 261.599976'
});
data_saddle.push({
lat: 4.2157555536e+01,
lng: 1.4320633333e+02,
content:'Saddle = 459.000000 pos = 42.1576,143.2063 diff = 261.599976'
});
data_peak.push({
lat: 4.4159777774e+01,
lng: 1.4297844444e+02,
cert : false,
content:' Peak = 630.200012 pos = 44.1598,142.9784 diff = 168.800018'
});
data_saddle.push({
lat: 4.4116555551e+01,
lng: 1.4296244444e+02,
content:'Saddle = 461.399994 pos = 44.1166,142.9624 diff = 168.800018'
});
data_peak.push({
lat: 4.3447999991e+01,
lng: 1.4202055556e+02,
cert : true,
content:'Name = JA8/SC-047(JA8/SC-047) peak = 621.799988 pos = 43.4480,142.0206 diff = 159.799988'
});
data_saddle.push({
lat: 4.3444111102e+01,
lng: 1.4202322222e+02,
content:'Saddle = 462.000000 pos = 43.4441,142.0232 diff = 159.799988'
});
data_peak.push({
lat: 4.3013444432e+01,
lng: 1.4216377778e+02,
cert : false,
content:' Peak = 613.000000 pos = 43.0134,142.1638 diff = 150.100006'
});
data_saddle.push({
lat: 4.3011777765e+01,
lng: 1.4217833333e+02,
content:'Saddle = 462.899994 pos = 43.0118,142.1783 diff = 150.100006'
});
data_peak.push({
lat: 4.2290444426e+01,
lng: 1.4287733333e+02,
cert : true,
content:'Name = JA8/HD-085(JA8/HD-085) peak = 673.099976 pos = 42.2904,142.8773 diff = 201.199982'
});
data_saddle.push({
lat: 4.2287555537e+01,
lng: 1.4287100000e+02,
content:'Saddle = 471.899994 pos = 42.2876,142.8710 diff = 201.199982'
});
data_peak.push({
lat: 4.2252888870e+01,
lng: 1.4288500000e+02,
cert : false,
content:' Peak = 623.000000 pos = 42.2529,142.8850 diff = 150.399994'
});
data_saddle.push({
lat: 4.2259444426e+01,
lng: 1.4287544444e+02,
content:'Saddle = 472.600006 pos = 42.2594,142.8754 diff = 150.399994'
});
data_peak.push({
lat: 4.3079111099e+01,
lng: 1.4204155556e+02,
cert : true,
content:'Name = JA8/SC-020(JA8/SC-020) peak = 871.799988 pos = 43.0791,142.0416 diff = 393.699982'
});
data_saddle.push({
lat: 4.3164666655e+01,
lng: 1.4207255556e+02,
content:'Saddle = 478.100006 pos = 43.1647,142.0726 diff = 393.699982'
});
data_peak.push({
lat: 4.3118666655e+01,
lng: 1.4207800000e+02,
cert : true,
content:'Name = JA8/SC-039(JA8/SC-039) peak = 723.900024 pos = 43.1187,142.0780 diff = 165.700012'
});
data_saddle.push({
lat: 4.3121888877e+01,
lng: 1.4205877778e+02,
content:'Saddle = 558.200012 pos = 43.1219,142.0588 diff = 165.700012'
});
data_peak.push({
lat: 4.3143555544e+01,
lng: 1.4204133333e+02,
cert : false,
content:' Peak = 835.599976 pos = 43.1436,142.0413 diff = 215.000000'
});
data_saddle.push({
lat: 4.3109222210e+01,
lng: 1.4204188889e+02,
content:'Saddle = 620.599976 pos = 43.1092,142.0419 diff = 215.000000'
});
data_peak.push({
lat: 4.3084888877e+01,
lng: 1.4207411111e+02,
cert : true,
content:'Name = JA8/SC-024(JA8/SC-024) peak = 840.799988 pos = 43.0849,142.0741 diff = 212.200012'
});
data_saddle.push({
lat: 4.3085444432e+01,
lng: 1.4205888889e+02,
content:'Saddle = 628.599976 pos = 43.0854,142.0589 diff = 212.200012'
});
data_peak.push({
lat: 4.3196333322e+01,
lng: 1.4252622222e+02,
cert : true,
content:'Name = JA8/KK-068(JA8/KK-068) peak = 852.200012 pos = 43.1963,142.5262 diff = 373.400024'
});
data_saddle.push({
lat: 4.3196777766e+01,
lng: 1.4258388889e+02,
content:'Saddle = 478.799988 pos = 43.1968,142.5839 diff = 373.400024'
});
data_peak.push({
lat: 4.3189777766e+01,
lng: 1.4255277778e+02,
cert : false,
content:' Peak = 790.799988 pos = 43.1898,142.5528 diff = 157.700012'
});
data_saddle.push({
lat: 4.3190444433e+01,
lng: 1.4254600000e+02,
content:'Saddle = 633.099976 pos = 43.1904,142.5460 diff = 157.700012'
});
data_peak.push({
lat: 4.2533222205e+01,
lng: 1.4273588889e+02,
cert : true,
content:'Name = JA8/HD-082(JA8/HD-082) peak = 686.099976 pos = 42.5332,142.7359 diff = 203.499969'
});
data_saddle.push({
lat: 4.2544222206e+01,
lng: 1.4274133333e+02,
content:'Saddle = 482.600006 pos = 42.5442,142.7413 diff = 203.499969'
});
data_peak.push({
lat: 4.3707222215e+01,
lng: 1.4352666667e+02,
cert : true,
content:'Name = JA8/OH-075(JA8/OH-075) peak = 641.799988 pos = 43.7072,143.5267 diff = 155.000000'
});
data_saddle.push({
lat: 4.3703111104e+01,
lng: 1.4350300000e+02,
content:'Saddle = 486.799988 pos = 43.7031,143.5030 diff = 155.000000'
});
data_peak.push({
lat: 4.4057111107e+01,
lng: 1.4299822222e+02,
cert : true,
content:'Name = JA8/OH-052(JA8/OH-052) peak = 830.700012 pos = 44.0571,142.9982 diff = 339.300018'
});
data_saddle.push({
lat: 4.4027555551e+01,
lng: 1.4301177778e+02,
content:'Saddle = 491.399994 pos = 44.0276,143.0118 diff = 339.300018'
});
data_peak.push({
lat: 4.2477666649e+01,
lng: 1.4250344444e+02,
cert : true,
content:'Name = JA8/HD-069(JA8/HD-069) peak = 804.299988 pos = 42.4777,142.5034 diff = 312.099976'
});
data_saddle.push({
lat: 4.2482777761e+01,
lng: 1.4252088889e+02,
content:'Saddle = 492.200012 pos = 42.4828,142.5209 diff = 312.099976'
});
data_peak.push({
lat: 4.2821555541e+01,
lng: 1.4228333333e+02,
cert : false,
content:' Peak = 645.799988 pos = 42.8216,142.2833 diff = 153.399994'
});
data_saddle.push({
lat: 4.2821999986e+01,
lng: 1.4229044444e+02,
content:'Saddle = 492.399994 pos = 42.8220,142.2904 diff = 153.399994'
});
data_peak.push({
lat: 4.2846999986e+01,
lng: 1.4231311111e+02,
cert : true,
content:'Name = Hattaomanaidake(JA8/HD-046) peak = 1021.099976 pos = 42.8470,142.3131 diff = 527.699951'
});
data_saddle.push({
lat: 4.2912666653e+01,
lng: 1.4244677778e+02,
content:'Saddle = 493.399994 pos = 42.9127,142.4468 diff = 527.699951'
});
data_peak.push({
lat: 4.2843222208e+01,
lng: 1.4240155556e+02,
cert : true,
content:'Name = JA8/HD-078(JA8/HD-078) peak = 714.700012 pos = 42.8432,142.4016 diff = 186.799988'
});
data_saddle.push({
lat: 4.2847333319e+01,
lng: 1.4239844444e+02,
content:'Saddle = 527.900024 pos = 42.8473,142.3984 diff = 186.799988'
});
data_peak.push({
lat: 4.2772777763e+01,
lng: 1.4231533333e+02,
cert : true,
content:'Name = JA8/HD-074(JA8/HD-074) peak = 740.700012 pos = 42.7728,142.3153 diff = 185.500000'
});
data_saddle.push({
lat: 4.2778777763e+01,
lng: 1.4230400000e+02,
content:'Saddle = 555.200012 pos = 42.7788,142.3040 diff = 185.500000'
});
data_peak.push({
lat: 4.2886777764e+01,
lng: 1.4237877778e+02,
cert : true,
content:'Name = JA8/KK-057(JA8/KK-057) peak = 934.700012 pos = 42.8868,142.3788 diff = 327.200012'
});
data_saddle.push({
lat: 4.2886222208e+01,
lng: 1.4234755556e+02,
content:'Saddle = 607.500000 pos = 42.8862,142.3476 diff = 327.200012'
});
data_peak.push({
lat: 4.2905777764e+01,
lng: 1.4238166667e+02,
cert : false,
content:' Peak = 790.900024 pos = 42.9058,142.3817 diff = 157.600037'
});
data_saddle.push({
lat: 4.2898555542e+01,
lng: 1.4238622222e+02,
content:'Saddle = 633.299988 pos = 42.8986,142.3862 diff = 157.600037'
});
data_peak.push({
lat: 4.2881111097e+01,
lng: 1.4231288889e+02,
cert : true,
content:'Name = JA8/IR-005(JA8/IR-005) peak = 1015.799988 pos = 42.8811,142.3129 diff = 213.000000'
});
data_saddle.push({
lat: 4.2861555541e+01,
lng: 1.4231522222e+02,
content:'Saddle = 802.799988 pos = 42.8616,142.3152 diff = 213.000000'
});
data_peak.push({
lat: 4.2464555538e+01,
lng: 1.4282377778e+02,
cert : true,
content:'Name = JA8/HD-073(JA8/HD-073) peak = 742.200012 pos = 42.4646,142.8238 diff = 240.600006'
});
data_saddle.push({
lat: 4.2468999983e+01,
lng: 1.4282744444e+02,
content:'Saddle = 501.600006 pos = 42.4690,142.8274 diff = 240.600006'
});
data_peak.push({
lat: 4.3401222212e+01,
lng: 1.4204988889e+02,
cert : true,
content:'Name = JA8/SC-011(JA8/SC-011) peak = 985.900024 pos = 43.4012,142.0499 diff = 484.000031'
});
data_saddle.push({
lat: 4.3288555545e+01,
lng: 1.4207422222e+02,
content:'Saddle = 501.899994 pos = 43.2886,142.0742 diff = 484.000031'
});
data_peak.push({
lat: 4.3324111101e+01,
lng: 1.4211877778e+02,
cert : true,
content:'Name = JA8/SC-038(JA8/SC-038) peak = 721.299988 pos = 43.3241,142.1188 diff = 199.299988'
});
data_saddle.push({
lat: 4.3327444434e+01,
lng: 1.4208711111e+02,
content:'Saddle = 522.000000 pos = 43.3274,142.0871 diff = 199.299988'
});
data_peak.push({
lat: 4.3330333323e+01,
lng: 1.4205855556e+02,
cert : true,
content:'Name = JA8/SC-025(JA8/SC-025) peak = 847.799988 pos = 43.3303,142.0586 diff = 305.399963'
});
data_saddle.push({
lat: 4.3344999990e+01,
lng: 1.4205377778e+02,
content:'Saddle = 542.400024 pos = 43.3450,142.0538 diff = 305.399963'
});
data_peak.push({
lat: 4.3355555545e+01,
lng: 1.4201866667e+02,
cert : true,
content:'Name = JA8/SC-031(JA8/SC-031) peak = 780.299988 pos = 43.3556,142.0187 diff = 198.000000'
});
data_saddle.push({
lat: 4.3356111101e+01,
lng: 1.4203377778e+02,
content:'Saddle = 582.299988 pos = 43.3561,142.0338 diff = 198.000000'
});
data_peak.push({
lat: 4.3449444435e+01,
lng: 1.4209744444e+02,
cert : false,
content:' Peak = 743.200012 pos = 43.4494,142.0974 diff = 155.100037'
});
data_saddle.push({
lat: 4.3440333324e+01,
lng: 1.4207788889e+02,
content:'Saddle = 588.099976 pos = 43.4403,142.0779 diff = 155.100037'
});
data_peak.push({
lat: 4.3363555545e+01,
lng: 1.4212822222e+02,
cert : true,
content:'Name = JA8/SC-030(JA8/SC-030) peak = 780.000000 pos = 43.3636,142.1282 diff = 157.400024'
});
data_saddle.push({
lat: 4.3379777768e+01,
lng: 1.4210066667e+02,
content:'Saddle = 622.599976 pos = 43.3798,142.1007 diff = 157.400024'
});
data_peak.push({
lat: 4.3404222212e+01,
lng: 1.4210422222e+02,
cert : true,
content:'Name = JA8/SC-022(JA8/SC-022) peak = 852.599976 pos = 43.4042,142.1042 diff = 215.199951'
});
data_saddle.push({
lat: 4.3398222212e+01,
lng: 1.4209355556e+02,
content:'Saddle = 637.400024 pos = 43.3982,142.0936 diff = 215.199951'
});
data_peak.push({
lat: 4.3358555545e+01,
lng: 1.4205988889e+02,
cert : true,
content:'Name = JA8/SC-027(JA8/SC-027) peak = 832.500000 pos = 43.3586,142.0599 diff = 163.900024'
});
data_saddle.push({
lat: 4.3375666657e+01,
lng: 1.4206055556e+02,
content:'Saddle = 668.599976 pos = 43.3757,142.0606 diff = 163.900024'
});
data_peak.push({
lat: 4.4192444441e+01,
lng: 1.4268088889e+02,
cert : true,
content:'Name = JA8/KK-091(JA8/KK-091) peak = 704.400024 pos = 44.1924,142.6809 diff = 196.900024'
});
data_saddle.push({
lat: 4.4186999996e+01,
lng: 1.4268700000e+02,
content:'Saddle = 507.500000 pos = 44.1870,142.6870 diff = 196.900024'
});
data_peak.push({
lat: 4.3925888883e+01,
lng: 1.4267388889e+02,
cert : true,
content:'Name = JA8/KK-076(JA8/KK-076) peak = 810.799988 pos = 43.9259,142.6739 diff = 302.899994'
});
data_saddle.push({
lat: 4.3922333328e+01,
lng: 1.4268933333e+02,
content:'Saddle = 507.899994 pos = 43.9223,142.6893 diff = 302.899994'
});
data_peak.push({
lat: 4.4215444441e+01,
lng: 1.4292277778e+02,
cert : true,
content:'Name = JA8/OH-071(JA8/OH-071) peak = 677.099976 pos = 44.2154,142.9228 diff = 163.500000'
});
data_saddle.push({
lat: 4.4219666663e+01,
lng: 1.4291577778e+02,
content:'Saddle = 513.599976 pos = 44.2197,142.9158 diff = 163.500000'
});
data_peak.push({
lat: 4.4101777774e+01,
lng: 1.4278400000e+02,
cert : true,
content:'Name = Nisamadake(JA8/KK-086) peak = 741.299988 pos = 44.1018,142.7840 diff = 227.700012'
});
data_saddle.push({
lat: 4.4100777774e+01,
lng: 1.4279666667e+02,
content:'Saddle = 513.599976 pos = 44.1008,142.7967 diff = 227.700012'
});
data_peak.push({
lat: 4.3158111099e+01,
lng: 1.4237800000e+02,
cert : true,
content:'Name = JA8/KK-081(JA8/KK-081) peak = 770.599976 pos = 43.1581,142.3780 diff = 253.299988'
});
data_saddle.push({
lat: 4.3166333322e+01,
lng: 1.4235966667e+02,
content:'Saddle = 517.299988 pos = 43.1663,142.3597 diff = 253.299988'
});
data_peak.push({
lat: 4.3153555544e+01,
lng: 1.4263822222e+02,
cert : true,
content:'Name = JA8/KK-069(JA8/KK-069) peak = 844.200012 pos = 43.1536,142.6382 diff = 326.600037'
});
data_saddle.push({
lat: 4.3180444433e+01,
lng: 1.4266266667e+02,
content:'Saddle = 517.599976 pos = 43.1804,142.6627 diff = 326.600037'
});
data_peak.push({
lat: 4.3235777767e+01,
lng: 1.4228344444e+02,
cert : true,
content:'Name = Ashibetsudake(JA8/KK-019) peak = 1722.800049 pos = 43.2358,142.2834 diff = 1204.900024'
});
data_saddle.push({
lat: 4.3091777766e+01,
lng: 1.4240066667e+02,
content:'Saddle = 517.900024 pos = 43.0918,142.4007 diff = 1204.900024'
});
data_peak.push({
lat: 4.3002999987e+01,
lng: 1.4237111111e+02,
cert : true,
content:'Name = JA8/KK-079(JA8/KK-079) peak = 783.299988 pos = 43.0030,142.3711 diff = 241.299988'
});
data_saddle.push({
lat: 4.3017777765e+01,
lng: 1.4235611111e+02,
content:'Saddle = 542.000000 pos = 43.0178,142.3561 diff = 241.299988'
});
data_peak.push({
lat: 4.2978888876e+01,
lng: 1.4227566667e+02,
cert : false,
content:' Peak = 850.900024 pos = 42.9789,142.2757 diff = 303.700012'
});
data_saddle.push({
lat: 4.3016333320e+01,
lng: 1.4230100000e+02,
content:'Saddle = 547.200012 pos = 43.0163,142.3010 diff = 303.700012'
});
data_peak.push({
lat: 4.2930333320e+01,
lng: 1.4225133333e+02,
cert : true,
content:'Name = JA8/IR-012(JA8/IR-012) peak = 760.299988 pos = 42.9303,142.2513 diff = 179.299988'
});
data_saddle.push({
lat: 4.2946222209e+01,
lng: 1.4226322222e+02,
content:'Saddle = 581.000000 pos = 42.9462,142.2632 diff = 179.299988'
});
data_peak.push({
lat: 4.3382555546e+01,
lng: 1.4228966667e+02,
cert : true,
content:'Name = JA8/SC-017(JA8/SC-017) peak = 903.200012 pos = 43.3826,142.2897 diff = 310.200012'
});
data_saddle.push({
lat: 4.3335555545e+01,
lng: 1.4226188889e+02,
content:'Saddle = 593.000000 pos = 43.3356,142.2619 diff = 310.200012'
});
data_peak.push({
lat: 4.3357555545e+01,
lng: 1.4227100000e+02,
cert : true,
content:'Name = JA8/SC-019(JA8/SC-019) peak = 872.500000 pos = 43.3576,142.2710 diff = 155.299988'
});
data_saddle.push({
lat: 4.3363888879e+01,
lng: 1.4228500000e+02,
content:'Saddle = 717.200012 pos = 43.3639,142.2850 diff = 155.299988'
});
data_peak.push({
lat: 4.3345999990e+01,
lng: 1.4218844444e+02,
cert : false,
content:' Peak = 811.599976 pos = 43.3460,142.1884 diff = 209.399963'
});
data_saddle.push({
lat: 4.3340111101e+01,
lng: 1.4221077778e+02,
content:'Saddle = 602.200012 pos = 43.3401,142.2108 diff = 209.399963'
});
data_peak.push({
lat: 4.3105888877e+01,
lng: 1.4232722222e+02,
cert : true,
content:'Name = JA8/KK-080(JA8/KK-080) peak = 780.200012 pos = 43.1059,142.3272 diff = 162.500000'
});
data_saddle.push({
lat: 4.3097666654e+01,
lng: 1.4231933333e+02,
content:'Saddle = 617.700012 pos = 43.0977,142.3193 diff = 162.500000'
});
data_peak.push({
lat: 4.3290111100e+01,
lng: 1.4216944444e+02,
cert : true,
content:'Name = JA8/SC-016(JA8/SC-016) peak = 924.099976 pos = 43.2901,142.1694 diff = 251.399963'
});
data_saddle.push({
lat: 4.3296777767e+01,
lng: 1.4222266667e+02,
content:'Saddle = 672.700012 pos = 43.2968,142.2227 diff = 251.399963'
});
data_peak.push({
lat: 4.3307777767e+01,
lng: 1.4220344444e+02,
cert : true,
content:'Name = JA8/SC-014(JA8/SC-014) peak = 922.900024 pos = 43.3078,142.2034 diff = 190.800049'
});
data_saddle.push({
lat: 4.3296444434e+01,
lng: 1.4218122222e+02,
content:'Saddle = 732.099976 pos = 43.2964,142.1812 diff = 190.800049'
});
data_peak.push({
lat: 4.3227111100e+01,
lng: 1.4215933333e+02,
cert : true,
content:'Name = Ikushyunbetsudake(JA8/SC-008) peak = 1067.400024 pos = 43.2271,142.1593 diff = 384.400024'
});
data_saddle.push({
lat: 4.3208888878e+01,
lng: 1.4220611111e+02,
content:'Saddle = 683.000000 pos = 43.2089,142.2061 diff = 384.400024'
});
data_peak.push({
lat: 4.3258444434e+01,
lng: 1.4217711111e+02,
cert : true,
content:'Name = JA8/SC-010(JA8/SC-010) peak = 1017.700012 pos = 43.2584,142.1771 diff = 315.400024'
});
data_saddle.push({
lat: 4.3262333322e+01,
lng: 1.4219788889e+02,
content:'Saddle = 702.299988 pos = 43.2623,142.1979 diff = 315.400024'
});
data_peak.push({
lat: 4.3097444432e+01,
lng: 1.4236466667e+02,
cert : true,
content:'Name = JA8/KK-061(JA8/KK-061) peak = 910.599976 pos = 43.0974,142.3647 diff = 198.799988'
});
data_saddle.push({
lat: 4.3077111099e+01,
lng: 1.4233677778e+02,
content:'Saddle = 711.799988 pos = 43.0771,142.3368 diff = 198.799988'
});
data_peak.push({
lat: 4.3089555543e+01,
lng: 1.4234722222e+02,
cert : true,
content:'Name = JA8/KK-064(JA8/KK-064) peak = 871.099976 pos = 43.0896,142.3472 diff = 158.000000'
});
data_saddle.push({
lat: 4.3098666654e+01,
lng: 1.4235466667e+02,
content:'Saddle = 713.099976 pos = 43.0987,142.3547 diff = 158.000000'
});
data_peak.push({
lat: 4.3141999988e+01,
lng: 1.4228755556e+02,
cert : true,
content:'Name = JA8/KK-037(JA8/KK-037) peak = 1207.400024 pos = 43.1420,142.2876 diff = 189.800049'
});
data_saddle.push({
lat: 4.3140888877e+01,
lng: 1.4227966667e+02,
content:'Saddle = 1017.599976 pos = 43.1409,142.2797 diff = 189.800049'
});
data_peak.push({
lat: 4.3099777766e+01,
lng: 1.4225100000e+02,
cert : true,
content:'Name = Yuubaridake(JA8/KK-021) peak = 1664.300049 pos = 43.0998,142.2510 diff = 611.000000'
});
data_saddle.push({
lat: 4.3175444433e+01,
lng: 1.4226700000e+02,
content:'Saddle = 1053.300049 pos = 43.1754,142.2670 diff = 611.000000'
});
data_peak.push({
lat: 4.3067777765e+01,
lng: 1.4226788889e+02,
cert : false,
content:' Peak = 1302.099976 pos = 43.0678,142.2679 diff = 163.699951'
});
data_saddle.push({
lat: 4.3085666654e+01,
lng: 1.4226100000e+02,
content:'Saddle = 1138.400024 pos = 43.0857,142.2610 diff = 163.699951'
});
data_peak.push({
lat: 4.3169666655e+01,
lng: 1.4225400000e+02,
cert : true,
content:'Name = JA8/SC-003(JA8/SC-003) peak = 1413.900024 pos = 43.1697,142.2540 diff = 213.200073'
});
data_saddle.push({
lat: 4.3159444433e+01,
lng: 1.4225622222e+02,
content:'Saddle = 1200.699951 pos = 43.1594,142.2562 diff = 213.200073'
});
data_peak.push({
lat: 4.3288888878e+01,
lng: 1.4226966667e+02,
cert : true,
content:'Name = JA8/SC-004(JA8/SC-004) peak = 1310.500000 pos = 43.2889,142.2697 diff = 227.500000'
});
data_saddle.push({
lat: 4.3284555545e+01,
lng: 1.4227622222e+02,
content:'Saddle = 1083.000000 pos = 43.2846,142.2762 diff = 227.500000'
});
data_peak.push({
lat: 4.3297111100e+01,
lng: 1.4229088889e+02,
cert : false,
content:' Peak = 1336.500000 pos = 43.2971,142.2909 diff = 202.800049'
});
data_saddle.push({
lat: 4.3290444434e+01,
lng: 1.4229677778e+02,
content:'Saddle = 1133.699951 pos = 43.2904,142.2968 diff = 202.800049'
});
data_peak.push({
lat: 4.3223999989e+01,
lng: 1.4224733333e+02,
cert : true,
content:'Name = JA8/SC-002(JA8/SC-002) peak = 1433.800049 pos = 43.2240,142.2473 diff = 191.600098'
});
data_saddle.push({
lat: 4.3221888878e+01,
lng: 1.4225211111e+02,
content:'Saddle = 1242.199951 pos = 43.2219,142.2521 diff = 191.600098'
});
data_peak.push({
lat: 4.3252444433e+01,
lng: 1.4225555556e+02,
cert : true,
content:'Name = JA8/SC-001(JA8/SC-001) peak = 1492.599976 pos = 43.2524,142.2556 diff = 225.199951'
});
data_saddle.push({
lat: 4.3253222211e+01,
lng: 1.4226900000e+02,
content:'Saddle = 1267.400024 pos = 43.2532,142.2690 diff = 225.199951'
});
data_peak.push({
lat: 4.3197777766e+01,
lng: 1.4228444444e+02,
cert : true,
content:'Name = JA8/KK-026(JA8/KK-026) peak = 1452.199951 pos = 43.1978,142.2844 diff = 169.599976'
});
data_saddle.push({
lat: 4.3202777766e+01,
lng: 1.4228266667e+02,
content:'Saddle = 1282.599976 pos = 43.2028,142.2827 diff = 169.599976'
});
data_peak.push({
lat: 4.3264666656e+01,
lng: 1.4282188889e+02,
cert : true,
content:'Name = JA8/TC-098(JA8/TC-098) peak = 707.599976 pos = 43.2647,142.8219 diff = 186.000000'
});
data_saddle.push({
lat: 4.3275666656e+01,
lng: 1.4281855556e+02,
content:'Saddle = 521.599976 pos = 43.2757,142.8186 diff = 186.000000'
});
data_peak.push({
lat: 4.4213666663e+01,
lng: 1.4269044444e+02,
cert : true,
content:'Name = JA8/KK-087(JA8/KK-087) peak = 730.799988 pos = 44.2137,142.6904 diff = 208.500000'
});
data_saddle.push({
lat: 4.4200666663e+01,
lng: 1.4270766667e+02,
content:'Saddle = 522.299988 pos = 44.2007,142.7077 diff = 208.500000'
});
data_peak.push({
lat: 4.2382999982e+01,
lng: 1.4278922222e+02,
cert : true,
content:'Name = JA8/HD-083(JA8/HD-083) peak = 685.400024 pos = 42.3830,142.7892 diff = 159.400024'
});
data_saddle.push({
lat: 4.2392888871e+01,
lng: 1.4278511111e+02,
content:'Saddle = 526.000000 pos = 42.3929,142.7851 diff = 159.400024'
});
data_peak.push({
lat: 4.4031111106e+01,
lng: 1.4322966667e+02,
cert : false,
content:' Peak = 821.200012 pos = 44.0311,143.2297 diff = 295.100037'
});
data_saddle.push({
lat: 4.4020444440e+01,
lng: 1.4321366667e+02,
content:'Saddle = 526.099976 pos = 44.0204,143.2137 diff = 295.100037'
});
data_peak.push({
lat: 4.2148888869e+01,
lng: 1.4311933333e+02,
cert : true,
content:'Name = JA8/HD-081(JA8/HD-081) peak = 692.200012 pos = 42.1489,143.1193 diff = 164.600037'
});
data_saddle.push({
lat: 4.2146333314e+01,
lng: 1.4313277778e+02,
content:'Saddle = 527.599976 pos = 42.1463,143.1328 diff = 164.600037'
});
data_peak.push({
lat: 4.2203999981e+01,
lng: 1.4309822222e+02,
cert : true,
content:'Name = JA8/HD-070(JA8/HD-070) peak = 785.200012 pos = 42.2040,143.0982 diff = 255.700012'
});
data_saddle.push({
lat: 4.2218888870e+01,
lng: 1.4310500000e+02,
content:'Saddle = 529.500000 pos = 42.2189,143.1050 diff = 255.700012'
});
data_peak.push({
lat: 4.4121444440e+01,
lng: 1.4277511111e+02,
cert : true,
content:'Name = JA8/KK-089(JA8/KK-089) peak = 723.900024 pos = 44.1214,142.7751 diff = 192.700012'
});
data_saddle.push({
lat: 4.4133111107e+01,
lng: 1.4279166667e+02,
content:'Saddle = 531.200012 pos = 44.1331,142.7917 diff = 192.700012'
});
data_peak.push({
lat: 4.2494555539e+01,
lng: 1.4261533333e+02,
cert : true,
content:'Name = JA8/HD-042(JA8/HD-042) peak = 1100.099976 pos = 42.4946,142.6153 diff = 559.000000'
});
data_saddle.push({
lat: 4.2508999983e+01,
lng: 1.4263511111e+02,
content:'Saddle = 541.099976 pos = 42.5090,142.6351 diff = 559.000000'
});
data_peak.push({
lat: 4.2448777760e+01,
lng: 1.4256955556e+02,
cert : false,
content:' Peak = 693.000000 pos = 42.4488,142.5696 diff = 150.599976'
});
data_saddle.push({
lat: 4.2451999983e+01,
lng: 1.4257533333e+02,
content:'Saddle = 542.400024 pos = 42.4520,142.5753 diff = 150.599976'
});
data_peak.push({
lat: 4.2461222205e+01,
lng: 1.4258866667e+02,
cert : true,
content:'Name = JA8/HD-072(JA8/HD-072) peak = 761.799988 pos = 42.4612,142.5887 diff = 179.099976'
});
data_saddle.push({
lat: 4.2464777760e+01,
lng: 1.4259522222e+02,
content:'Saddle = 582.700012 pos = 42.4648,142.5952 diff = 179.099976'
});
data_peak.push({
lat: 4.4155444441e+01,
lng: 1.4270377778e+02,
cert : false,
content:' Peak = 861.500000 pos = 44.1554,142.7038 diff = 320.200012'
});
data_saddle.push({
lat: 4.4181666663e+01,
lng: 1.4271100000e+02,
content:'Saddle = 541.299988 pos = 44.1817,142.7110 diff = 320.200012'
});
data_peak.push({
lat: 4.4262333330e+01,
lng: 1.4276544444e+02,
cert : true,
content:'Name = JA8/KK-063(JA8/KK-063) peak = 882.200012 pos = 44.2623,142.7654 diff = 339.500000'
});
data_saddle.push({
lat: 4.4230333330e+01,
lng: 1.4273777778e+02,
content:'Saddle = 542.700012 pos = 44.2303,142.7378 diff = 339.500000'
});
data_peak.push({
lat: 4.3600222214e+01,
lng: 1.4345555556e+02,
cert : true,
content:'Name = JA8/OH-044(JA8/OH-044) peak = 904.000000 pos = 43.6002,143.4556 diff = 355.799988'
});
data_saddle.push({
lat: 4.3594111103e+01,
lng: 1.4341544444e+02,
content:'Saddle = 548.200012 pos = 43.5941,143.4154 diff = 355.799988'
});
data_peak.push({
lat: 4.2342444426e+01,
lng: 1.4285811111e+02,
cert : true,
content:'Name = JA8/HD-065(JA8/HD-065) peak = 863.099976 pos = 42.3424,142.8581 diff = 311.299988'
});
data_saddle.push({
lat: 4.2358999982e+01,
lng: 1.4289133333e+02,
content:'Saddle = 551.799988 pos = 42.3590,142.8913 diff = 311.299988'
});
data_peak.push({
lat: 4.2354222204e+01,
lng: 1.4287422222e+02,
cert : true,
content:'Name = JA8/HD-068(JA8/HD-068) peak = 809.599976 pos = 42.3542,142.8742 diff = 236.899963'
});
data_saddle.push({
lat: 4.2348222204e+01,
lng: 1.4287200000e+02,
content:'Saddle = 572.700012 pos = 42.3482,142.8720 diff = 236.899963'
});
data_peak.push({
lat: 4.2323999982e+01,
lng: 1.4284388889e+02,
cert : false,
content:' Peak = 850.200012 pos = 42.3240,142.8439 diff = 167.500000'
});
data_saddle.push({
lat: 4.2333666648e+01,
lng: 1.4285022222e+02,
content:'Saddle = 682.700012 pos = 42.3337,142.8502 diff = 167.500000'
});
data_peak.push({
lat: 4.3979222217e+01,
lng: 1.4338288889e+02,
cert : true,
content:'Name = JA8/OH-067(JA8/OH-067) peak = 723.099976 pos = 43.9792,143.3829 diff = 171.199951'
});
data_saddle.push({
lat: 4.3942777772e+01,
lng: 1.4338655556e+02,
content:'Saddle = 551.900024 pos = 43.9428,143.3866 diff = 171.199951'
});
data_peak.push({
lat: 4.4195666663e+01,
lng: 1.4271688889e+02,
cert : false,
content:' Peak = 704.400024 pos = 44.1957,142.7169 diff = 152.100037'
});
data_saddle.push({
lat: 4.4188555552e+01,
lng: 1.4272533333e+02,
content:'Saddle = 552.299988 pos = 44.1886,142.7253 diff = 152.100037'
});
data_peak.push({
lat: 4.2375333315e+01,
lng: 1.4313277778e+02,
cert : true,
content:'Name = JA8/TC-088(JA8/TC-088) peak = 892.500000 pos = 42.3753,143.1328 diff = 339.700012'
});
data_saddle.push({
lat: 4.2371666649e+01,
lng: 1.4311088889e+02,
content:'Saddle = 552.799988 pos = 42.3717,143.1109 diff = 339.700012'
});
data_peak.push({
lat: 4.3242888878e+01,
lng: 1.4255233333e+02,
cert : true,
content:'Name = JA8/KK-070(JA8/KK-070) peak = 845.099976 pos = 43.2429,142.5523 diff = 289.699951'
});
data_saddle.push({
lat: 4.3273555545e+01,
lng: 1.4258444444e+02,
content:'Saddle = 555.400024 pos = 43.2736,142.5844 diff = 289.699951'
});
data_peak.push({
lat: 4.4027111106e+01,
lng: 1.4320155556e+02,
cert : true,
content:'Name = JA8/OH-066(JA8/OH-066) peak = 725.200012 pos = 44.0271,143.2016 diff = 165.700012'
});
data_saddle.push({
lat: 4.4021666662e+01,
lng: 1.4320022222e+02,
content:'Saddle = 559.500000 pos = 44.0217,143.2002 diff = 165.700012'
});
data_peak.push({
lat: 4.3885666661e+01,
lng: 1.4341277778e+02,
cert : true,
content:'Name = JA8/OH-061(JA8/OH-061) peak = 744.299988 pos = 43.8857,143.4128 diff = 181.700012'
});
data_saddle.push({
lat: 4.3882888883e+01,
lng: 1.4339566667e+02,
content:'Saddle = 562.599976 pos = 43.8829,143.3957 diff = 181.700012'
});
data_peak.push({
lat: 4.2300111093e+01,
lng: 1.4314877778e+02,
cert : false,
content:' Peak = 773.200012 pos = 42.3001,143.1488 diff = 207.200012'
});
data_saddle.push({
lat: 4.2295888870e+01,
lng: 1.4313988889e+02,
content:'Saddle = 566.000000 pos = 42.2959,143.1399 diff = 207.200012'
});
data_peak.push({
lat: 4.3927666661e+01,
lng: 1.4339888889e+02,
cert : true,
content:'Name = JA8/OH-045(JA8/OH-045) peak = 900.500000 pos = 43.9277,143.3989 diff = 333.000000'
});
data_saddle.push({
lat: 4.3886555550e+01,
lng: 1.4338533333e+02,
content:'Saddle = 567.500000 pos = 43.8866,143.3853 diff = 333.000000'
});
data_peak.push({
lat: 4.3924888883e+01,
lng: 1.4345433333e+02,
cert : true,
content:'Name = JA8/OH-064(JA8/OH-064) peak = 740.900024 pos = 43.9249,143.4543 diff = 157.900024'
});
data_saddle.push({
lat: 4.3921444439e+01,
lng: 1.4344622222e+02,
content:'Saddle = 583.000000 pos = 43.9214,143.4462 diff = 157.900024'
});
data_peak.push({
lat: 4.3891555550e+01,
lng: 1.4338800000e+02,
cert : false,
content:' Peak = 761.500000 pos = 43.8916,143.3880 diff = 150.799988'
});
data_saddle.push({
lat: 4.3894666661e+01,
lng: 1.4338822222e+02,
content:'Saddle = 610.700012 pos = 43.8947,143.3882 diff = 150.799988'
});
data_peak.push({
lat: 4.3078666654e+01,
lng: 1.4259600000e+02,
cert : true,
content:'Name = Tomamusan(JA8/KK-035) peak = 1238.099976 pos = 43.0787,142.5960 diff = 668.899963'
});
data_saddle.push({
lat: 4.3044111098e+01,
lng: 1.4266544444e+02,
content:'Saddle = 569.200012 pos = 43.0441,142.6654 diff = 668.899963'
});
data_peak.push({
lat: 4.3133222210e+01,
lng: 1.4252433333e+02,
cert : true,
content:'Name = Shamanshadake(JA8/KK-046) peak = 1060.599976 pos = 43.1332,142.5243 diff = 334.000000'
});
data_saddle.push({
lat: 4.3128888877e+01,
lng: 1.4254588889e+02,
content:'Saddle = 726.599976 pos = 43.1289,142.5459 diff = 334.000000'
});
data_peak.push({
lat: 4.3113555543e+01,
lng: 1.4256900000e+02,
cert : true,
content:'Name = JA8/KK-053(JA8/KK-053) peak = 981.500000 pos = 43.1136,142.5690 diff = 238.299988'
});
data_saddle.push({
lat: 4.3108666655e+01,
lng: 1.4258200000e+02,
content:'Saddle = 743.200012 pos = 43.1087,142.5820 diff = 238.299988'
});
data_peak.push({
lat: 4.3074333321e+01,
lng: 1.4263433333e+02,
cert : true,
content:'Name = JA8/KK-056(JA8/KK-056) peak = 951.299988 pos = 43.0743,142.6343 diff = 190.399963'
});
data_saddle.push({
lat: 4.3079666654e+01,
lng: 1.4262122222e+02,
content:'Saddle = 760.900024 pos = 43.0797,142.6212 diff = 190.399963'
});
data_peak.push({
lat: 4.3100444432e+01,
lng: 1.4261844444e+02,
cert : true,
content:'Name = JA8/KK-040(JA8/KK-040) peak = 1164.800049 pos = 43.1004,142.6184 diff = 187.800049'
});
data_saddle.push({
lat: 4.3102888877e+01,
lng: 1.4260288889e+02,
content:'Saddle = 977.000000 pos = 43.1029,142.6029 diff = 187.800049'
});
data_peak.push({
lat: 4.3253111100e+01,
lng: 1.4280877778e+02,
cert : true,
content:'Name = JA8/TC-093(JA8/TC-093) peak = 782.400024 pos = 43.2531,142.8088 diff = 203.700012'
});
data_saddle.push({
lat: 4.3264888878e+01,
lng: 1.4280344444e+02,
content:'Saddle = 578.700012 pos = 43.2649,142.8034 diff = 203.700012'
});
data_peak.push({
lat: 4.3862777772e+01,
lng: 1.4343733333e+02,
cert : false,
content:' Peak = 736.599976 pos = 43.8628,143.4373 diff = 153.699951'
});
data_saddle.push({
lat: 4.3856555549e+01,
lng: 1.4342711111e+02,
content:'Saddle = 582.900024 pos = 43.8566,143.4271 diff = 153.699951'
});
data_peak.push({
lat: 4.3241777767e+01,
lng: 1.4290711111e+02,
cert : true,
content:'Name = JA8/TC-096(JA8/TC-096) peak = 770.099976 pos = 43.2418,142.9071 diff = 186.799988'
});
data_saddle.push({
lat: 4.3274555545e+01,
lng: 1.4288366667e+02,
content:'Saddle = 583.299988 pos = 43.2746,142.8837 diff = 186.799988'
});
data_peak.push({
lat: 4.2183333314e+01,
lng: 1.4314866667e+02,
cert : true,
content:'Name = JA8/HD-067(JA8/HD-067) peak = 852.500000 pos = 42.1833,143.1487 diff = 261.200012'
});
data_saddle.push({
lat: 4.2183666647e+01,
lng: 1.4316155556e+02,
content:'Saddle = 591.299988 pos = 42.1837,143.1616 diff = 261.200012'
});
data_peak.push({
lat: 4.2924111098e+01,
lng: 1.4248655556e+02,
cert : true,
content:'Name = JA8/KK-083(JA8/KK-083) peak = 761.599976 pos = 42.9241,142.4866 diff = 169.399963'
});
data_saddle.push({
lat: 4.2916222209e+01,
lng: 1.4250800000e+02,
content:'Saddle = 592.200012 pos = 42.9162,142.5080 diff = 169.399963'
});
data_peak.push({
lat: 4.3588222214e+01,
lng: 1.4353344444e+02,
cert : true,
content:'Name = JA8/OH-050(JA8/OH-050) peak = 857.700012 pos = 43.5882,143.5334 diff = 258.900024'
});
data_saddle.push({
lat: 4.3558222214e+01,
lng: 1.4352277778e+02,
content:'Saddle = 598.799988 pos = 43.5582,143.5228 diff = 258.900024'
});
data_peak.push({
lat: 4.2390333315e+01,
lng: 1.4309888889e+02,
cert : true,
content:'Name = JA8/TC-095(JA8/TC-095) peak = 771.500000 pos = 42.3903,143.0989 diff = 170.700012'
});
data_saddle.push({
lat: 4.2389777760e+01,
lng: 1.4309044444e+02,
content:'Saddle = 600.799988 pos = 42.3898,143.0904 diff = 170.700012'
});
data_peak.push({
lat: 4.4228777775e+01,
lng: 1.4287622222e+02,
cert : true,
content:'Name = Wenshiridake(JA8/OH-021) peak = 1140.900024 pos = 44.2288,142.8762 diff = 539.400024'
});
data_saddle.push({
lat: 4.4138999996e+01,
lng: 1.4284100000e+02,
content:'Saddle = 601.500000 pos = 44.1390,142.8410 diff = 539.400024'
});
data_peak.push({
lat: 4.4137666663e+01,
lng: 1.4275122222e+02,
cert : true,
content:'Name = JA8/KK-050(JA8/KK-050) peak = 1000.000000 pos = 44.1377,142.7512 diff = 387.500000'
});
data_saddle.push({
lat: 4.4142555552e+01,
lng: 1.4280455556e+02,
content:'Saddle = 612.500000 pos = 44.1426,142.8046 diff = 387.500000'
});
data_peak.push({
lat: 4.4170222219e+01,
lng: 1.4278266667e+02,
cert : true,
content:'Name = JA8/KK-062(JA8/KK-062) peak = 897.599976 pos = 44.1702,142.7827 diff = 272.199951'
});
data_saddle.push({
lat: 4.4148444441e+01,
lng: 1.4276133333e+02,
content:'Saddle = 625.400024 pos = 44.1484,142.7613 diff = 272.199951'
});
data_peak.push({
lat: 4.4206888886e+01,
lng: 1.4276500000e+02,
cert : true,
content:'Name = JA8/KK-071(JA8/KK-071) peak = 840.400024 pos = 44.2069,142.7650 diff = 178.200012'
});
data_saddle.push({
lat: 4.4214555552e+01,
lng: 1.4275744444e+02,
content:'Saddle = 662.200012 pos = 44.2146,142.7574 diff = 178.200012'
});
data_peak.push({
lat: 4.4116555551e+01,
lng: 1.4273588889e+02,
cert : false,
content:' Peak = 822.000000 pos = 44.1166,142.7359 diff = 159.400024'
});
data_saddle.push({
lat: 4.4121777774e+01,
lng: 1.4273766667e+02,
content:'Saddle = 662.599976 pos = 44.1218,142.7377 diff = 159.400024'
});
data_peak.push({
lat: 4.4188111108e+01,
lng: 1.4289855556e+02,
cert : true,
content:'Name = JA8/OH-030(JA8/OH-030) peak = 1030.699951 pos = 44.1881,142.8986 diff = 199.399963'
});
data_saddle.push({
lat: 4.4184111108e+01,
lng: 1.4288411111e+02,
content:'Saddle = 831.299988 pos = 44.1841,142.8841 diff = 199.399963'
});
data_peak.push({
lat: 4.3889444439e+01,
lng: 1.4315555556e+02,
cert : true,
content:'Name = JA8/OH-059(JA8/OH-059) peak = 761.799988 pos = 43.8894,143.1556 diff = 156.299988'
});
data_saddle.push({
lat: 4.3897111105e+01,
lng: 1.4314455556e+02,
content:'Saddle = 605.500000 pos = 43.8971,143.1446 diff = 156.299988'
});
data_peak.push({
lat: 4.3440666657e+01,
lng: 1.4328244444e+02,
cert : false,
content:' Peak = 763.599976 pos = 43.4407,143.2824 diff = 155.500000'
});
data_saddle.push({
lat: 4.3442999991e+01,
lng: 1.4327822222e+02,
content:'Saddle = 608.099976 pos = 43.4430,143.2782 diff = 155.500000'
});
data_peak.push({
lat: 4.2182333314e+01,
lng: 1.4306033333e+02,
cert : true,
content:'Name = JA8/HD-071(JA8/HD-071) peak = 780.400024 pos = 42.1823,143.0603 diff = 170.300049'
});
data_saddle.push({
lat: 4.2206333314e+01,
lng: 1.4306411111e+02,
content:'Saddle = 610.099976 pos = 42.2063,143.0641 diff = 170.300049'
});
data_peak.push({
lat: 4.2076999980e+01,
lng: 1.4323288889e+02,
cert : true,
content:'Name = Toyonidake(JA8/HD-041) peak = 1104.300049 pos = 42.0770,143.2329 diff = 492.200073'
});
data_saddle.push({
lat: 4.2131222202e+01,
lng: 1.4318377778e+02,
content:'Saddle = 612.099976 pos = 42.1312,143.1838 diff = 492.200073'
});
data_peak.push({
lat: 4.2094777758e+01,
lng: 1.4315566667e+02,
cert : true,
content:'Name = JA8/HD-063(JA8/HD-063) peak = 872.000000 pos = 42.0948,143.1557 diff = 222.500000'
});
data_saddle.push({
lat: 4.2101222202e+01,
lng: 1.4316322222e+02,
content:'Saddle = 649.500000 pos = 42.1012,143.1632 diff = 222.500000'
});
data_peak.push({
lat: 4.2113333313e+01,
lng: 1.4317700000e+02,
cert : false,
content:' Peak = 1006.599976 pos = 42.1133,143.1770 diff = 299.500000'
});
data_saddle.push({
lat: 4.2095333313e+01,
lng: 1.4319777778e+02,
content:'Saddle = 707.099976 pos = 42.0953,143.1978 diff = 299.500000'
});
data_peak.push({
lat: 4.2570444428e+01,
lng: 1.4247277778e+02,
cert : false,
content:' Peak = 782.299988 pos = 42.5704,142.4728 diff = 160.000000'
});
data_saddle.push({
lat: 4.2584777761e+01,
lng: 1.4248611111e+02,
content:'Saddle = 622.299988 pos = 42.5848,142.4861 diff = 160.000000'
});
data_peak.push({
lat: 4.2704555540e+01,
lng: 1.4247544444e+02,
cert : true,
content:'Name = JA8/HD-058(JA8/HD-058) peak = 893.799988 pos = 42.7046,142.4754 diff = 271.200012'
});
data_saddle.push({
lat: 4.2701888874e+01,
lng: 1.4248988889e+02,
content:'Saddle = 622.599976 pos = 42.7019,142.4899 diff = 271.200012'
});
data_peak.push({
lat: 4.2692999985e+01,
lng: 1.4247166667e+02,
cert : false,
content:' Peak = 883.299988 pos = 42.6930,142.4717 diff = 201.700012'
});
data_saddle.push({
lat: 4.2698333318e+01,
lng: 1.4247800000e+02,
content:'Saddle = 681.599976 pos = 42.6983,142.4780 diff = 201.700012'
});
data_peak.push({
lat: 4.3729777771e+01,
lng: 1.4337177778e+02,
cert : false,
content:' Peak = 773.500000 pos = 43.7298,143.3718 diff = 150.299988'
});
data_saddle.push({
lat: 4.3734999993e+01,
lng: 1.4336322222e+02,
content:'Saddle = 623.200012 pos = 43.7350,143.3632 diff = 150.299988'
});
data_peak.push({
lat: 4.2643111095e+01,
lng: 1.4249000000e+02,
cert : true,
content:'Name = JA8/HD-034(JA8/HD-034) peak = 1316.099976 pos = 42.6431,142.4900 diff = 683.000000'
});
data_saddle.push({
lat: 4.2649555540e+01,
lng: 1.4254277778e+02,
content:'Saddle = 633.099976 pos = 42.6496,142.5428 diff = 683.000000'
});
data_peak.push({
lat: 4.2558222206e+01,
lng: 1.4251255556e+02,
cert : false,
content:' Peak = 952.299988 pos = 42.5582,142.5126 diff = 150.599976'
});
data_saddle.push({
lat: 4.2569999984e+01,
lng: 1.4251544444e+02,
content:'Saddle = 801.700012 pos = 42.5700,142.5154 diff = 150.599976'
});
data_peak.push({
lat: 4.3587555547e+01,
lng: 1.4335944444e+02,
cert : true,
content:'Name = JA8/OH-055(JA8/OH-055) peak = 811.799988 pos = 43.5876,143.3594 diff = 177.899963'
});
data_saddle.push({
lat: 4.3580555547e+01,
lng: 1.4334933333e+02,
content:'Saddle = 633.900024 pos = 43.5806,143.3493 diff = 177.899963'
});
data_peak.push({
lat: 4.2719444429e+01,
lng: 1.4268277778e+02,
cert : true,
content:'Name = Poroshiridake(JA8/HD-001) peak = 2050.800049 pos = 42.7194,142.6828 diff = 1407.300049'
});
data_saddle.push({
lat: 4.3135555544e+01,
lng: 1.4276477778e+02,
content:'Saddle = 643.500000 pos = 43.1356,142.7648 diff = 1407.300049'
});
data_peak.push({
lat: 4.2435888871e+01,
lng: 1.4279555556e+02,
cert : true,
content:'Name = JA8/HD-039(JA8/HD-039) peak = 1165.699951 pos = 42.4359,142.7956 diff = 519.499939'
});
data_saddle.push({
lat: 4.2451222205e+01,
lng: 1.4284855556e+02,
content:'Saddle = 646.200012 pos = 42.4512,142.8486 diff = 519.499939'
});
data_peak.push({
lat: 4.2444777760e+01,
lng: 1.4273244444e+02,
cert : true,
content:'Name = JA8/HD-064(JA8/HD-064) peak = 863.500000 pos = 42.4448,142.7324 diff = 181.500000'
});
data_saddle.push({
lat: 4.2423999982e+01,
lng: 1.4276544444e+02,
content:'Saddle = 682.000000 pos = 42.4240,142.7654 diff = 181.500000'
});
data_peak.push({
lat: 4.2576222206e+01,
lng: 1.4256533333e+02,
cert : true,
content:'Name = JA8/HD-050(JA8/HD-050) peak = 975.299988 pos = 42.5762,142.5653 diff = 312.799988'
});
data_saddle.push({
lat: 4.2601444428e+01,
lng: 1.4257677778e+02,
content:'Saddle = 662.500000 pos = 42.6014,142.5768 diff = 312.799988'
});
data_peak.push({
lat: 4.2488444427e+01,
lng: 1.4253733333e+02,
cert : true,
content:'Name = JA8/HD-060(JA8/HD-060) peak = 885.099976 pos = 42.4884,142.5373 diff = 208.299988'
});
data_saddle.push({
lat: 4.2505222205e+01,
lng: 1.4255233333e+02,
content:'Saddle = 676.799988 pos = 42.5052,142.5523 diff = 208.299988'
});
data_peak.push({
lat: 4.2534888872e+01,
lng: 1.4256066667e+02,
cert : true,
content:'Name = JA8/HD-059(JA8/HD-059) peak = 890.900024 pos = 42.5349,142.5607 diff = 168.100037'
});
data_saddle.push({
lat: 4.2549222206e+01,
lng: 1.4256133333e+02,
content:'Saddle = 722.799988 pos = 42.5492,142.5613 diff = 168.100037'
});
data_peak.push({
lat: 4.2226777759e+01,
lng: 1.4306466667e+02,
cert : true,
content:'Name = JA8/HD-054(JA8/HD-054) peak = 948.599976 pos = 42.2268,143.0647 diff = 281.599976'
});
data_saddle.push({
lat: 4.2242555536e+01,
lng: 1.4308255556e+02,
content:'Saddle = 667.000000 pos = 42.2426,143.0826 diff = 281.599976'
});
data_peak.push({
lat: 4.2489111094e+01,
lng: 1.4276766667e+02,
cert : true,
content:'Name = JA8/HD-057(JA8/HD-057) peak = 909.599976 pos = 42.4891,142.7677 diff = 240.899963'
});
data_saddle.push({
lat: 4.2500999983e+01,
lng: 1.4276666667e+02,
content:'Saddle = 668.700012 pos = 42.5010,142.7667 diff = 240.899963'
});
data_peak.push({
lat: 4.2420777760e+01,
lng: 1.4310200000e+02,
cert : false,
content:' Peak = 832.200012 pos = 42.4208,143.1020 diff = 161.200012'
});
data_saddle.push({
lat: 4.2422444427e+01,
lng: 1.4309544444e+02,
content:'Saddle = 671.000000 pos = 42.4224,143.0954 diff = 161.200012'
});
data_peak.push({
lat: 4.2989888876e+01,
lng: 1.4247466667e+02,
cert : false,
content:' Peak = 841.099976 pos = 42.9899,142.4747 diff = 168.500000'
});
data_saddle.push({
lat: 4.3003222209e+01,
lng: 1.4248766667e+02,
content:'Saddle = 672.599976 pos = 43.0032,142.4877 diff = 168.500000'
});
data_peak.push({
lat: 4.2346999982e+01,
lng: 1.4313077778e+02,
cert : true,
content:'Name = JA8/TC-091(JA8/TC-091) peak = 866.599976 pos = 42.3470,143.1308 diff = 193.699951'
});
data_saddle.push({
lat: 4.2346444426e+01,
lng: 1.4312377778e+02,
content:'Saddle = 672.900024 pos = 42.3464,143.1238 diff = 193.699951'
});
data_peak.push({
lat: 4.2662999984e+01,
lng: 1.4254700000e+02,
cert : true,
content:'Name = JA8/HD-066(JA8/HD-066) peak = 857.400024 pos = 42.6630,142.5470 diff = 174.500000'
});
data_saddle.push({
lat: 4.2676999984e+01,
lng: 1.4254600000e+02,
content:'Saddle = 682.900024 pos = 42.6770,142.5460 diff = 174.500000'
});
data_peak.push({
lat: 4.3046222210e+01,
lng: 1.4255400000e+02,
cert : true,
content:'Name = JA8/KK-065(JA8/KK-065) peak = 865.099976 pos = 43.0462,142.5540 diff = 182.199951'
});
data_saddle.push({
lat: 4.3047666654e+01,
lng: 1.4256122222e+02,
content:'Saddle = 682.900024 pos = 43.0477,142.5612 diff = 182.199951'
});
data_peak.push({
lat: 4.3080666654e+01,
lng: 1.4273388889e+02,
cert : true,
content:'Name = JA8/TC-070(JA8/TC-070) peak = 1070.199951 pos = 43.0807,142.7339 diff = 383.799927'
});
data_saddle.push({
lat: 4.3067777765e+01,
lng: 1.4273733333e+02,
content:'Saddle = 686.400024 pos = 43.0678,142.7373 diff = 383.799927'
});
data_peak.push({
lat: 4.3118111099e+01,
lng: 1.4273144444e+02,
cert : true,
content:'Name = JA8/KK-052(JA8/KK-052) peak = 983.500000 pos = 43.1181,142.7314 diff = 262.299988'
});
data_saddle.push({
lat: 4.3106666655e+01,
lng: 1.4274666667e+02,
content:'Saddle = 721.200012 pos = 43.1067,142.7467 diff = 262.299988'
});
data_peak.push({
lat: 4.2719888874e+01,
lng: 1.4252511111e+02,
cert : true,
content:'Name = JA8/HD-047(JA8/HD-047) peak = 1010.700012 pos = 42.7199,142.5251 diff = 319.799988'
});
data_saddle.push({
lat: 4.2715444429e+01,
lng: 1.4256566667e+02,
content:'Saddle = 690.900024 pos = 42.7154,142.5657 diff = 319.799988'
});
data_peak.push({
lat: 4.2693111096e+01,
lng: 1.4252066667e+02,
cert : true,
content:'Name = JA8/HD-055(JA8/HD-055) peak = 942.299988 pos = 42.6931,142.5207 diff = 182.200012'
});
data_saddle.push({
lat: 4.2697333318e+01,
lng: 1.4252366667e+02,
content:'Saddle = 760.099976 pos = 42.6973,142.5237 diff = 182.200012'
});
data_peak.push({
lat: 4.2706777762e+01,
lng: 1.4254677778e+02,
cert : true,
content:'Name = JA8/HD-049(JA8/HD-049) peak = 1002.299988 pos = 42.7068,142.5468 diff = 210.599976'
});
data_saddle.push({
lat: 4.2713111096e+01,
lng: 1.4253333333e+02,
content:'Saddle = 791.700012 pos = 42.7131,142.5333 diff = 210.599976'
});
data_peak.push({
lat: 4.2265777759e+01,
lng: 1.4317633333e+02,
cert : true,
content:'Name = JA8/TC-084(JA8/TC-084) peak = 966.799988 pos = 42.2658,143.1763 diff = 275.099976'
});
data_saddle.push({
lat: 4.2259999981e+01,
lng: 1.4316777778e+02,
content:'Saddle = 691.700012 pos = 42.2600,143.1678 diff = 275.099976'
});
data_peak.push({
lat: 4.2680333318e+01,
lng: 1.4292777778e+02,
cert : true,
content:'Name = JA8/TC-089(JA8/TC-089) peak = 881.500000 pos = 42.6803,142.9278 diff = 174.700012'
});
data_saddle.push({
lat: 4.2684555540e+01,
lng: 1.4292533333e+02,
content:'Saddle = 706.799988 pos = 42.6846,142.9253 diff = 174.700012'
});
data_peak.push({
lat: 4.3017666654e+01,
lng: 1.4260277778e+02,
cert : true,
content:'Name = JA8/KK-043(JA8/KK-043) peak = 1127.199951 pos = 43.0177,142.6028 diff = 419.099976'
});
data_saddle.push({
lat: 4.3011666654e+01,
lng: 1.4266077778e+02,
content:'Saddle = 708.099976 pos = 43.0117,142.6608 diff = 419.099976'
});
data_peak.push({
lat: 4.3010888876e+01,
lng: 1.4262844444e+02,
cert : true,
content:'Name = JA8/KK-044(JA8/KK-044) peak = 1105.599976 pos = 43.0109,142.6284 diff = 197.599976'
});
data_saddle.push({
lat: 4.3019555543e+01,
lng: 1.4262022222e+02,
content:'Saddle = 908.000000 pos = 43.0196,142.6202 diff = 197.599976'
});
data_peak.push({
lat: 4.3007555543e+01,
lng: 1.4257488889e+02,
cert : true,
content:'Name = JA8/KK-045(JA8/KK-045) peak = 1080.800049 pos = 43.0076,142.5749 diff = 167.800049'
});
data_saddle.push({
lat: 4.3007888876e+01,
lng: 1.4258555556e+02,
content:'Saddle = 913.000000 pos = 43.0079,142.5856 diff = 167.800049'
});
data_peak.push({
lat: 4.2423111093e+01,
lng: 1.4307644444e+02,
cert : false,
content:' Peak = 872.700012 pos = 42.4231,143.0764 diff = 152.799988'
});
data_saddle.push({
lat: 4.2427666649e+01,
lng: 1.4306233333e+02,
content:'Saddle = 719.900024 pos = 42.4277,143.0623 diff = 152.799988'
});
data_peak.push({
lat: 4.2800999985e+01,
lng: 1.4244822222e+02,
cert : true,
content:'Name = JA8/HD-051(JA8/HD-051) peak = 963.500000 pos = 42.8010,142.4482 diff = 239.200012'
});
data_saddle.push({
lat: 4.2806444430e+01,
lng: 1.4246100000e+02,
content:'Saddle = 724.299988 pos = 42.8064,142.4610 diff = 239.200012'
});
data_peak.push({
lat: 4.2167555536e+01,
lng: 1.4317300000e+02,
cert : true,
content:'Name = JA8/HD-056(JA8/HD-056) peak = 933.799988 pos = 42.1676,143.1730 diff = 206.500000'
});
data_saddle.push({
lat: 4.2174111092e+01,
lng: 1.4317444444e+02,
content:'Saddle = 727.299988 pos = 42.1741,143.1744 diff = 206.500000'
});
data_peak.push({
lat: 4.2321333315e+01,
lng: 1.4314311111e+02,
cert : true,
content:'Name = JA8/TC-086(JA8/TC-086) peak = 923.500000 pos = 42.3213,143.1431 diff = 196.000000'
});
data_saddle.push({
lat: 4.2322777759e+01,
lng: 1.4313155556e+02,
content:'Saddle = 727.500000 pos = 42.3228,143.1316 diff = 196.000000'
});
data_peak.push({
lat: 4.2519444428e+01,
lng: 1.4302944444e+02,
cert : false,
content:' Peak = 883.099976 pos = 42.5194,143.0294 diff = 151.099976'
});
data_saddle.push({
lat: 4.2521777761e+01,
lng: 1.4301622222e+02,
content:'Saddle = 732.000000 pos = 42.5218,143.0162 diff = 151.099976'
});
data_peak.push({
lat: 4.2421444427e+01,
lng: 1.4305566667e+02,
cert : true,
content:'Name = JA8/TC-087(JA8/TC-087) peak = 915.400024 pos = 42.4214,143.0557 diff = 172.900024'
});
data_saddle.push({
lat: 4.2418222205e+01,
lng: 1.4304388889e+02,
content:'Saddle = 742.500000 pos = 42.4182,143.0439 diff = 172.900024'
});
data_peak.push({
lat: 4.2465111094e+01,
lng: 1.4303800000e+02,
cert : true,
content:'Name = JA8/TC-071(JA8/TC-071) peak = 1064.400024 pos = 42.4651,143.0380 diff = 305.200012'
});
data_saddle.push({
lat: 4.2461555538e+01,
lng: 1.4302811111e+02,
content:'Saddle = 759.200012 pos = 42.4616,143.0281 diff = 305.200012'
});
data_peak.push({
lat: 4.2628999984e+01,
lng: 1.4258655556e+02,
cert : false,
content:' Peak = 941.099976 pos = 42.6290,142.5866 diff = 158.199951'
});
data_saddle.push({
lat: 4.2628333317e+01,
lng: 1.4259155556e+02,
content:'Saddle = 782.900024 pos = 42.6283,142.5916 diff = 158.199951'
});
data_peak.push({
lat: 4.3051999987e+01,
lng: 1.4274900000e+02,
cert : true,
content:'Name = JA8/TC-063(JA8/TC-063) peak = 1096.400024 pos = 43.0520,142.7490 diff = 310.800049'
});
data_saddle.push({
lat: 4.3030333321e+01,
lng: 1.4275055556e+02,
content:'Saddle = 785.599976 pos = 43.0303,142.7506 diff = 310.800049'
});
data_peak.push({
lat: 4.2782444430e+01,
lng: 1.4250722222e+02,
cert : true,
content:'Name = JA8/HD-033(JA8/HD-033) peak = 1348.599976 pos = 42.7824,142.5072 diff = 561.899963'
});
data_saddle.push({
lat: 4.2814888874e+01,
lng: 1.4255466667e+02,
content:'Saddle = 786.700012 pos = 42.8149,142.5547 diff = 561.899963'
});
data_peak.push({
lat: 4.2756888874e+01,
lng: 1.4245022222e+02,
cert : true,
content:'Name = JA8/HD-043(JA8/HD-043) peak = 1092.699951 pos = 42.7569,142.4502 diff = 229.299927'
});
data_saddle.push({
lat: 4.2763999985e+01,
lng: 1.4245600000e+02,
content:'Saddle = 863.400024 pos = 42.7640,142.4560 diff = 229.299927'
});
data_peak.push({
lat: 4.2772333319e+01,
lng: 1.4244711111e+02,
cert : false,
content:' Peak = 1055.900024 pos = 42.7723,142.4471 diff = 159.600037'
});
data_saddle.push({
lat: 4.2773222207e+01,
lng: 1.4245033333e+02,
content:'Saddle = 896.299988 pos = 42.7732,142.4503 diff = 159.600037'
});
data_peak.push({
lat: 4.2785999985e+01,
lng: 1.4253477778e+02,
cert : true,
content:'Name = JA8/HD-040(JA8/HD-040) peak = 1121.400024 pos = 42.7860,142.5348 diff = 207.500000'
});
data_saddle.push({
lat: 4.2787999985e+01,
lng: 1.4252844444e+02,
content:'Saddle = 913.900024 pos = 42.7880,142.5284 diff = 207.500000'
});
data_peak.push({
lat: 4.2655999984e+01,
lng: 1.4258200000e+02,
cert : true,
content:'Name = JA8/HD-052(JA8/HD-052) peak = 957.099976 pos = 42.6560,142.5820 diff = 166.199951'
});
data_saddle.push({
lat: 4.2660666651e+01,
lng: 1.4258744444e+02,
content:'Saddle = 790.900024 pos = 42.6607,142.5874 diff = 166.199951'
});
data_peak.push({
lat: 4.2551888872e+01,
lng: 1.4269577778e+02,
cert : true,
content:'Name = JA8/HD-026(JA8/HD-026) peak = 1431.699951 pos = 42.5519,142.6958 diff = 635.199951'
});
data_saddle.push({
lat: 4.2572666650e+01,
lng: 1.4271411111e+02,
content:'Saddle = 796.500000 pos = 42.5727,142.7141 diff = 635.199951'
});
data_peak.push({
lat: 4.2570222206e+01,
lng: 1.4266188889e+02,
cert : true,
content:'Name = JA8/HD-031(JA8/HD-031) peak = 1360.599976 pos = 42.5702,142.6619 diff = 228.299927'
});
data_saddle.push({
lat: 4.2567444428e+01,
lng: 1.4266933333e+02,
content:'Saddle = 1132.300049 pos = 42.5674,142.6693 diff = 228.299927'
});
data_peak.push({
lat: 4.2505888872e+01,
lng: 1.4299622222e+02,
cert : true,
content:'Name = JA8/TC-068(JA8/TC-068) peak = 1082.699951 pos = 42.5059,142.9962 diff = 270.599976'
});
data_saddle.push({
lat: 4.2484777761e+01,
lng: 1.4297566667e+02,
content:'Saddle = 812.099976 pos = 42.4848,142.9757 diff = 270.599976'
});
data_peak.push({
lat: 4.2467333316e+01,
lng: 1.4298000000e+02,
cert : false,
content:' Peak = 984.000000 pos = 42.4673,142.9800 diff = 161.500000'
});
data_saddle.push({
lat: 4.2464222205e+01,
lng: 1.4297277778e+02,
content:'Saddle = 822.500000 pos = 42.4642,142.9728 diff = 161.500000'
});
data_peak.push({
lat: 4.2394444427e+01,
lng: 1.4306988889e+02,
cert : true,
content:'Name = JA8/TC-079(JA8/TC-079) peak = 1006.200012 pos = 42.3944,143.0699 diff = 179.500000'
});
data_saddle.push({
lat: 4.2393555538e+01,
lng: 1.4306444444e+02,
content:'Saddle = 826.700012 pos = 42.3936,143.0644 diff = 179.500000'
});
data_peak.push({
lat: 4.2970444431e+01,
lng: 1.4259777778e+02,
cert : true,
content:'Name = JA8/KK-029(JA8/KK-029) peak = 1344.599976 pos = 42.9704,142.5978 diff = 512.299988'
});
data_saddle.push({
lat: 4.2985777765e+01,
lng: 1.4265211111e+02,
content:'Saddle = 832.299988 pos = 42.9858,142.6521 diff = 512.299988'
});
data_peak.push({
lat: 4.2941777764e+01,
lng: 1.4257088889e+02,
cert : true,
content:'Name = JA8/KK-038(JA8/KK-038) peak = 1191.400024 pos = 42.9418,142.5709 diff = 288.700012'
});
data_saddle.push({
lat: 4.2958555542e+01,
lng: 1.4258366667e+02,
content:'Saddle = 902.700012 pos = 42.9586,142.5837 diff = 288.700012'
});
data_peak.push({
lat: 4.2188888869e+01,
lng: 1.4320622222e+02,
cert : true,
content:'Name = JA8/TC-062(JA8/TC-062) peak = 1121.000000 pos = 42.1889,143.2062 diff = 277.900024'
});
data_saddle.push({
lat: 4.2195777758e+01,
lng: 1.4319444444e+02,
content:'Saddle = 843.099976 pos = 42.1958,143.1944 diff = 277.900024'
});
data_peak.push({
lat: 4.2181999980e+01,
lng: 1.4322900000e+02,
cert : false,
content:' Peak = 1061.300049 pos = 42.1820,143.2290 diff = 207.400024'
});
data_saddle.push({
lat: 4.2180666647e+01,
lng: 1.4321744444e+02,
content:'Saddle = 853.900024 pos = 42.1807,143.2174 diff = 207.400024'
});
data_peak.push({
lat: 4.2349444426e+01,
lng: 1.4310911111e+02,
cert : true,
content:'Name = JA8/TC-078(JA8/TC-078) peak = 1014.799988 pos = 42.3494,143.1091 diff = 168.099976'
});
data_saddle.push({
lat: 4.2342333315e+01,
lng: 1.4309888889e+02,
content:'Saddle = 846.700012 pos = 42.3423,143.0989 diff = 168.099976'
});
data_peak.push({
lat: 4.2650555540e+01,
lng: 1.4289888889e+02,
cert : true,
content:'Name = JA8/TC-075(JA8/TC-075) peak = 1038.400024 pos = 42.6506,142.8989 diff = 185.900024'
});
data_saddle.push({
lat: 4.2648777762e+01,
lng: 1.4288555556e+02,
content:'Saddle = 852.500000 pos = 42.6488,142.8856 diff = 185.900024'
});
data_peak.push({
lat: 4.2754333318e+01,
lng: 1.4289211111e+02,
cert : true,
content:'Name = JA8/TC-066(JA8/TC-066) peak = 1094.199951 pos = 42.7543,142.8921 diff = 190.499939'
});
data_saddle.push({
lat: 4.2756333318e+01,
lng: 1.4286533333e+02,
content:'Saddle = 903.700012 pos = 42.7563,142.8653 diff = 190.499939'
});
data_peak.push({
lat: 4.2792888874e+01,
lng: 1.4258155556e+02,
cert : true,
content:'Name = JA8/HD-044(JA8/HD-044) peak = 1081.500000 pos = 42.7929,142.5816 diff = 169.099976'
});
data_saddle.push({
lat: 4.2789111096e+01,
lng: 1.4258988889e+02,
content:'Saddle = 912.400024 pos = 42.7891,142.5899 diff = 169.099976'
});
data_peak.push({
lat: 4.2947999987e+01,
lng: 1.4263555556e+02,
cert : false,
content:' Peak = 1188.699951 pos = 42.9480,142.6356 diff = 271.599976'
});
data_saddle.push({
lat: 4.2939111098e+01,
lng: 1.4264722222e+02,
content:'Saddle = 917.099976 pos = 42.9391,142.6472 diff = 271.599976'
});
data_peak.push({
lat: 4.2848777764e+01,
lng: 1.4288500000e+02,
cert : false,
content:' Peak = 1201.599976 pos = 42.8488,142.8850 diff = 274.500000'
});
data_saddle.push({
lat: 4.2852222208e+01,
lng: 1.4284833333e+02,
content:'Saddle = 927.099976 pos = 42.8522,142.8483 diff = 274.500000'
});
data_peak.push({
lat: 4.2889333319e+01,
lng: 1.4261500000e+02,
cert : true,
content:'Name = JA8/HD-037(JA8/HD-037) peak = 1211.800049 pos = 42.8893,142.6150 diff = 250.900024'
});
data_saddle.push({
lat: 4.2888666653e+01,
lng: 1.4262355556e+02,
content:'Saddle = 960.900024 pos = 42.8887,142.6236 diff = 250.900024'
});
data_peak.push({
lat: 4.2231999981e+01,
lng: 1.4318155556e+02,
cert : false,
content:' Peak = 1230.500000 pos = 42.2320,143.1816 diff = 239.099976'
});
data_saddle.push({
lat: 4.2231999981e+01,
lng: 1.4315544444e+02,
content:'Saddle = 991.400024 pos = 42.2320,143.1554 diff = 239.099976'
});
data_peak.push({
lat: 4.2614888873e+01,
lng: 1.4290066667e+02,
cert : true,
content:'Name = JA8/TC-042(JA8/TC-042) peak = 1293.199951 pos = 42.6149,142.9007 diff = 271.099976'
});
data_saddle.push({
lat: 4.2629666651e+01,
lng: 1.4288055556e+02,
content:'Saddle = 1022.099976 pos = 42.6297,142.8806 diff = 271.099976'
});
data_peak.push({
lat: 4.2350444426e+01,
lng: 1.4307077778e+02,
cert : false,
content:' Peak = 1223.400024 pos = 42.3504,143.0708 diff = 200.500000'
});
data_saddle.push({
lat: 4.2344555537e+01,
lng: 1.4305444444e+02,
content:'Saddle = 1022.900024 pos = 42.3446,143.0544 diff = 200.500000'
});
data_peak.push({
lat: 4.2313777759e+01,
lng: 1.4299244444e+02,
cert : true,
content:'Name = JA8/HD-036(JA8/HD-036) peak = 1233.199951 pos = 42.3138,142.9924 diff = 201.500000'
});
data_saddle.push({
lat: 4.2314777759e+01,
lng: 1.4301877778e+02,
content:'Saddle = 1031.699951 pos = 42.3148,143.0188 diff = 201.500000'
});
data_peak.push({
lat: 4.2857333319e+01,
lng: 1.4260466667e+02,
cert : true,
content:'Name = JA8/HD-028(JA8/HD-028) peak = 1384.900024 pos = 42.8573,142.6047 diff = 312.599976'
});
data_saddle.push({
lat: 4.2851777764e+01,
lng: 1.4261311111e+02,
content:'Saddle = 1072.300049 pos = 42.8518,142.6131 diff = 312.599976'
});
data_peak.push({
lat: 4.2272555537e+01,
lng: 1.4311111111e+02,
cert : true,
content:'Name = Rakkodake(JA8/TC-032) peak = 1471.199951 pos = 42.2726,143.1111 diff = 398.500000'
});
data_saddle.push({
lat: 4.2286666648e+01,
lng: 1.4309677778e+02,
content:'Saddle = 1072.699951 pos = 42.2867,143.0968 diff = 398.500000'
});
data_peak.push({
lat: 4.2560444428e+01,
lng: 1.4292688889e+02,
cert : true,
content:'Name = JA8/TC-045(JA8/TC-045) peak = 1271.500000 pos = 42.5604,142.9269 diff = 198.500000'
});
data_saddle.push({
lat: 4.2568444428e+01,
lng: 1.4290188889e+02,
content:'Saddle = 1073.000000 pos = 42.5684,142.9019 diff = 198.500000'
});
data_peak.push({
lat: 4.2397111093e+01,
lng: 1.4303088889e+02,
cert : true,
content:'Name = JA8/TC-048(JA8/TC-048) peak = 1254.099976 pos = 42.3971,143.0309 diff = 161.799927'
});
data_saddle.push({
lat: 4.2391666649e+01,
lng: 1.4302155556e+02,
content:'Saddle = 1092.300049 pos = 42.3917,143.0216 diff = 161.799927'
});
data_peak.push({
lat: 4.3009888876e+01,
lng: 1.4272766667e+02,
cert : true,
content:'Name = JA8/HD-029(JA8/HD-029) peak = 1382.199951 pos = 43.0099,142.7277 diff = 276.899902'
});
data_saddle.push({
lat: 4.2971222209e+01,
lng: 1.4275222222e+02,
content:'Saddle = 1105.300049 pos = 42.9712,142.7522 diff = 276.899902'
});
data_peak.push({
lat: 4.3025111098e+01,
lng: 1.4270888889e+02,
cert : true,
content:'Name = JA8/KK-031(JA8/KK-031) peak = 1320.199951 pos = 43.0251,142.7089 diff = 209.399902'
});
data_saddle.push({
lat: 4.3019333320e+01,
lng: 1.4271688889e+02,
content:'Saddle = 1110.800049 pos = 43.0193,142.7169 diff = 209.399902'
});
data_peak.push({
lat: 4.2290888870e+01,
lng: 1.4307600000e+02,
cert : true,
content:'Name = JA8/HD-024(JA8/HD-024) peak = 1456.099976 pos = 42.2909,143.0760 diff = 343.599976'
});
data_saddle.push({
lat: 4.2348333315e+01,
lng: 1.4302266667e+02,
content:'Saddle = 1112.500000 pos = 42.3483,143.0227 diff = 343.599976'
});
data_peak.push({
lat: 4.2329222204e+01,
lng: 1.4304777778e+02,
cert : true,
content:'Name = JA8/TC-037(JA8/TC-037) peak = 1350.699951 pos = 42.3292,143.0478 diff = 192.599976'
});
data_saddle.push({
lat: 4.2324222204e+01,
lng: 1.4304888889e+02,
content:'Saddle = 1158.099976 pos = 42.3242,143.0489 diff = 192.599976'
});
data_peak.push({
lat: 4.2309333315e+01,
lng: 1.4305477778e+02,
cert : true,
content:'Name = JA8/HD-030(JA8/HD-030) peak = 1376.099976 pos = 42.3093,143.0548 diff = 183.199951'
});
data_saddle.push({
lat: 4.2298222204e+01,
lng: 1.4307488889e+02,
content:'Saddle = 1192.900024 pos = 42.2982,143.0749 diff = 183.199951'
});
data_peak.push({
lat: 4.2386222204e+01,
lng: 1.4293544444e+02,
cert : true,
content:'Name = JA8/HD-032(JA8/HD-032) peak = 1354.199951 pos = 42.3862,142.9354 diff = 241.099976'
});
data_saddle.push({
lat: 4.2392666649e+01,
lng: 1.4295122222e+02,
content:'Saddle = 1113.099976 pos = 42.3927,142.9512 diff = 241.099976'
});
data_peak.push({
lat: 4.2493888872e+01,
lng: 1.4283900000e+02,
cert : true,
content:'Name = JA8/HD-035(JA8/HD-035) peak = 1292.400024 pos = 42.4939,142.8390 diff = 164.000000'
});
data_saddle.push({
lat: 4.2491777761e+01,
lng: 1.4284977778e+02,
content:'Saddle = 1128.400024 pos = 42.4918,142.8498 diff = 164.000000'
});
data_peak.push({
lat: 4.2963999987e+01,
lng: 1.4274266667e+02,
cert : true,
content:'Name = JA8/HD-025(JA8/HD-025) peak = 1444.300049 pos = 42.9640,142.7427 diff = 283.900024'
});
data_saddle.push({
lat: 4.2956666653e+01,
lng: 1.4275488889e+02,
content:'Saddle = 1160.400024 pos = 42.9567,142.7549 diff = 283.900024'
});
data_peak.push({
lat: 4.2951999987e+01,
lng: 1.4271566667e+02,
cert : true,
content:'Name = JA8/HD-027(JA8/HD-027) peak = 1421.699951 pos = 42.9520,142.7157 diff = 175.199951'
});
data_saddle.push({
lat: 4.2955444431e+01,
lng: 1.4272077778e+02,
content:'Saddle = 1246.500000 pos = 42.9554,142.7208 diff = 175.199951'
});
data_peak.push({
lat: 4.2402333316e+01,
lng: 1.4296666667e+02,
cert : true,
content:'Name = Pirikanupuri(JA8/TC-022) peak = 1632.900024 pos = 42.4023,142.9667 diff = 470.200073'
});
data_saddle.push({
lat: 4.2455555538e+01,
lng: 1.4288777778e+02,
content:'Saddle = 1162.699951 pos = 42.4556,142.8878 diff = 470.200073'
});
data_peak.push({
lat: 4.2450222205e+01,
lng: 1.4289666667e+02,
cert : true,
content:'Name = JA8/TC-029(JA8/TC-029) peak = 1492.300049 pos = 42.4502,142.8967 diff = 279.800049'
});
data_saddle.push({
lat: 4.2441999983e+01,
lng: 1.4290111111e+02,
content:'Saddle = 1212.500000 pos = 42.4420,142.9011 diff = 279.800049'
});
data_peak.push({
lat: 4.2428555538e+01,
lng: 1.4290677778e+02,
cert : true,
content:'Name = Kamuidake(JA8/HD-017) peak = 1600.300049 pos = 42.4286,142.9068 diff = 296.800049'
});
data_saddle.push({
lat: 4.2431777760e+01,
lng: 1.4292833333e+02,
content:'Saddle = 1303.500000 pos = 42.4318,142.9283 diff = 296.800049'
});
data_peak.push({
lat: 4.2371555538e+01,
lng: 1.4299977778e+02,
cert : true,
content:'Name = JA8/HD-020(JA8/HD-020) peak = 1527.300049 pos = 42.3716,142.9998 diff = 205.400024'
});
data_saddle.push({
lat: 4.2392666649e+01,
lng: 1.4296988889e+02,
content:'Saddle = 1321.900024 pos = 42.3927,142.9699 diff = 205.400024'
});
data_peak.push({
lat: 4.2427444427e+01,
lng: 1.4294711111e+02,
cert : true,
content:'Name = JA8/HD-016(JA8/HD-016) peak = 1622.199951 pos = 42.4274,142.9471 diff = 209.299927'
});
data_saddle.push({
lat: 4.2412777760e+01,
lng: 1.4295366667e+02,
content:'Saddle = 1412.900024 pos = 42.4128,142.9537 diff = 209.299927'
});
data_peak.push({
lat: 4.2468111094e+01,
lng: 1.4288455556e+02,
cert : true,
content:'Name = Nakanodake(JA8/TC-027) peak = 1517.199951 pos = 42.4681,142.8846 diff = 345.099976'
});
data_saddle.push({
lat: 4.2480666650e+01,
lng: 1.4288922222e+02,
content:'Saddle = 1172.099976 pos = 42.4807,142.8892 diff = 345.099976'
});
data_peak.push({
lat: 4.2658222206e+01,
lng: 1.4286255556e+02,
cert : true,
content:'Name = JA8/TC-028(JA8/TC-028) peak = 1490.099976 pos = 42.6582,142.8626 diff = 293.299927'
});
data_saddle.push({
lat: 4.2669333318e+01,
lng: 1.4286566667e+02,
content:'Saddle = 1196.800049 pos = 42.6693,142.8657 diff = 293.299927'
});
data_peak.push({
lat: 4.2645333317e+01,
lng: 1.4266611111e+02,
cert : true,
content:'Name = JA8/HD-009(JA8/HD-009) peak = 1773.900024 pos = 42.6453,142.6661 diff = 566.500000'
});
data_saddle.push({
lat: 4.2659999984e+01,
lng: 1.4269233333e+02,
content:'Saddle = 1207.400024 pos = 42.6600,142.6923 diff = 566.500000'
});
data_peak.push({
lat: 4.2942555542e+01,
lng: 1.4275933333e+02,
cert : true,
content:'Name = JA8/HD-019(JA8/HD-019) peak = 1531.699951 pos = 42.9426,142.7593 diff = 313.500000'
});
data_saddle.push({
lat: 4.2928888875e+01,
lng: 1.4277466667e+02,
content:'Saddle = 1218.199951 pos = 42.9289,142.7747 diff = 313.500000'
});
data_peak.push({
lat: 4.2513777761e+01,
lng: 1.4293800000e+02,
cert : false,
content:' Peak = 1403.500000 pos = 42.5138,142.9380 diff = 173.199951'
});
data_saddle.push({
lat: 4.2509444428e+01,
lng: 1.4292744444e+02,
content:'Saddle = 1230.300049 pos = 42.5094,142.9274 diff = 173.199951'
});
data_peak.push({
lat: 4.2722333318e+01,
lng: 1.4261366667e+02,
cert : true,
content:'Name = JA8/HD-021(JA8/HD-021) peak = 1517.400024 pos = 42.7223,142.6137 diff = 277.300049'
});
data_saddle.push({
lat: 4.2727222207e+01,
lng: 1.4263688889e+02,
content:'Saddle = 1240.099976 pos = 42.7272,142.6369 diff = 277.300049'
});
data_peak.push({
lat: 4.2810888874e+01,
lng: 1.4263522222e+02,
cert : false,
content:' Peak = 1503.900024 pos = 42.8109,142.6352 diff = 247.000000'
});
data_saddle.push({
lat: 4.2816666652e+01,
lng: 1.4264077778e+02,
content:'Saddle = 1256.900024 pos = 42.8167,142.6408 diff = 247.000000'
});
data_peak.push({
lat: 4.2606222206e+01,
lng: 1.4283911111e+02,
cert : true,
content:'Name = JA8/TC-025(JA8/TC-025) peak = 1583.000000 pos = 42.6062,142.8391 diff = 296.000000'
});
data_saddle.push({
lat: 4.2596777762e+01,
lng: 1.4282977778e+02,
content:'Saddle = 1287.000000 pos = 42.5968,142.8298 diff = 296.000000'
});
data_peak.push({
lat: 4.2835555541e+01,
lng: 1.4262466667e+02,
cert : true,
content:'Name = JA8/HD-023(JA8/HD-023) peak = 1491.099976 pos = 42.8356,142.6247 diff = 198.599976'
});
data_saddle.push({
lat: 4.2824777763e+01,
lng: 1.4263977778e+02,
content:'Saddle = 1292.500000 pos = 42.8248,142.6398 diff = 198.599976'
});
data_peak.push({
lat: 4.2892111097e+01,
lng: 1.4267911111e+02,
cert : true,
content:'Name = JA8/HD-010(JA8/HD-010) peak = 1750.000000 pos = 42.8921,142.6791 diff = 431.900024'
});
data_saddle.push({
lat: 4.2884333319e+01,
lng: 1.4276577778e+02,
content:'Saddle = 1318.099976 pos = 42.8843,142.7658 diff = 431.900024'
});
data_peak.push({
lat: 4.2899555542e+01,
lng: 1.4274066667e+02,
cert : true,
content:'Name = JA8/HD-014(JA8/HD-014) peak = 1694.400024 pos = 42.8996,142.7407 diff = 156.800049'
});
data_saddle.push({
lat: 4.2895888875e+01,
lng: 1.4269655556e+02,
content:'Saddle = 1537.599976 pos = 42.8959,142.6966 diff = 156.800049'
});
data_peak.push({
lat: 4.2800888874e+01,
lng: 1.4277377778e+02,
cert : true,
content:'Name = JA8/TC-031(JA8/TC-031) peak = 1470.699951 pos = 42.8009,142.7738 diff = 150.399902'
});
data_saddle.push({
lat: 4.2791333319e+01,
lng: 1.4276188889e+02,
content:'Saddle = 1320.300049 pos = 42.7913,142.7619 diff = 150.399902'
});
data_peak.push({
lat: 4.2779111096e+01,
lng: 1.4261711111e+02,
cert : true,
content:'Name = JA8/HD-018(JA8/HD-018) peak = 1590.199951 pos = 42.7791,142.6171 diff = 237.299927'
});
data_saddle.push({
lat: 4.2772999985e+01,
lng: 1.4263411111e+02,
content:'Saddle = 1352.900024 pos = 42.7730,142.6341 diff = 237.299927'
});
data_peak.push({
lat: 4.2754888874e+01,
lng: 1.4264444444e+02,
cert : true,
content:'Name = JA8/HD-015(JA8/HD-015) peak = 1632.599976 pos = 42.7549,142.6444 diff = 241.500000'
});
data_saddle.push({
lat: 4.2751222207e+01,
lng: 1.4265988889e+02,
content:'Saddle = 1391.099976 pos = 42.7512,142.6599 diff = 241.500000'
});
data_peak.push({
lat: 4.2655999984e+01,
lng: 1.4282644444e+02,
cert : true,
content:'Name = JA8/TC-023(JA8/TC-023) peak = 1623.000000 pos = 42.6560,142.8264 diff = 219.900024'
});
data_saddle.push({
lat: 4.2663444429e+01,
lng: 1.4282477778e+02,
content:'Saddle = 1403.099976 pos = 42.6634,142.8248 diff = 219.900024'
});
data_peak.push({
lat: 4.2539444428e+01,
lng: 1.4280811111e+02,
cert : true,
content:'Name = Ippasankyuhou(JA8/HD-006) peak = 1840.900024 pos = 42.5394,142.8081 diff = 398.500000'
});
data_saddle.push({
lat: 4.2580222206e+01,
lng: 1.4281111111e+02,
content:'Saddle = 1442.400024 pos = 42.5802,142.8111 diff = 398.500000'
});
data_peak.push({
lat: 4.2499444427e+01,
lng: 1.4287100000e+02,
cert : true,
content:'Name = Petegaridake(JA8/TC-014) peak = 1733.900024 pos = 42.4994,142.8710 diff = 269.099976'
});
data_saddle.push({
lat: 4.2543999983e+01,
lng: 1.4285711111e+02,
content:'Saddle = 1464.800049 pos = 42.5440,142.8571 diff = 269.099976'
});
data_peak.push({
lat: 4.2520111094e+01,
lng: 1.4285666667e+02,
cert : true,
content:'Name = JA8/HD-011(JA8/HD-011) peak = 1726.000000 pos = 42.5201,142.8567 diff = 194.000000'
});
data_saddle.push({
lat: 4.2510111094e+01,
lng: 1.4285966667e+02,
content:'Saddle = 1532.000000 pos = 42.5101,142.8597 diff = 194.000000'
});
data_peak.push({
lat: 4.2570888872e+01,
lng: 1.4282488889e+02,
cert : false,
content:' Peak = 1720.500000 pos = 42.5709,142.8249 diff = 157.500000'
});
data_saddle.push({
lat: 4.2564111095e+01,
lng: 1.4282711111e+02,
content:'Saddle = 1563.000000 pos = 42.5641,142.8271 diff = 157.500000'
});
data_peak.push({
lat: 4.2825666652e+01,
lng: 1.4267533333e+02,
cert : true,
content:'Name = Chirorodake(JA8/HD-005) peak = 1878.900024 pos = 42.8257,142.6753 diff = 397.900024'
});
data_saddle.push({
lat: 4.2813555541e+01,
lng: 1.4272566667e+02,
content:'Saddle = 1481.000000 pos = 42.8136,142.7257 diff = 397.900024'
});
data_peak.push({
lat: 4.2868999986e+01,
lng: 1.4278533333e+02,
cert : true,
content:'Name = Memurodake(JA8/TC-013) peak = 1753.199951 pos = 42.8690,142.7853 diff = 265.299927'
});
data_saddle.push({
lat: 4.2858222208e+01,
lng: 1.4277933333e+02,
content:'Saddle = 1487.900024 pos = 42.8582,142.7793 diff = 265.299927'
});
data_peak.push({
lat: 4.2844444430e+01,
lng: 1.4274044444e+02,
cert : true,
content:'Name = JA8/HD-012(JA8/HD-012) peak = 1724.300049 pos = 42.8444,142.7404 diff = 213.000000'
});
data_saddle.push({
lat: 4.2838111097e+01,
lng: 1.4273488889e+02,
content:'Saddle = 1511.300049 pos = 42.8381,142.7349 diff = 213.000000'
});
data_peak.push({
lat: 4.2695555540e+01,
lng: 1.4285933333e+02,
cert : true,
content:'Name = Tokachiporoshiridake(JA8/TC-010) peak = 1841.300049 pos = 42.6956,142.8593 diff = 353.600098'
});
data_saddle.push({
lat: 4.2690666651e+01,
lng: 1.4282144444e+02,
content:'Saddle = 1487.699951 pos = 42.6907,142.8214 diff = 353.600098'
});
data_peak.push({
lat: 4.2625222206e+01,
lng: 1.4276633333e+02,
cert : false,
content:' Peak = 1975.800049 pos = 42.6252,142.7663 diff = 482.300049'
});
data_saddle.push({
lat: 4.2704999985e+01,
lng: 1.4275677778e+02,
content:'Saddle = 1493.500000 pos = 42.7050,142.7568 diff = 482.300049'
});
data_peak.push({
lat: 4.2596777762e+01,
lng: 1.4280044444e+02,
cert : true,
content:'Name = JA8/HD-007(JA8/HD-007) peak = 1824.500000 pos = 42.5968,142.8004 diff = 253.500000'
});
data_saddle.push({
lat: 4.2609555539e+01,
lng: 1.4279577778e+02,
content:'Saddle = 1571.000000 pos = 42.6096,142.7958 diff = 253.500000'
});
data_peak.push({
lat: 4.2666444429e+01,
lng: 1.4272044444e+02,
cert : true,
content:'Name = JA8/HD-008(JA8/HD-008) peak = 1802.500000 pos = 42.6664,142.7204 diff = 181.000000'
});
data_saddle.push({
lat: 4.2666555540e+01,
lng: 1.4273333333e+02,
content:'Saddle = 1621.500000 pos = 42.6666,142.7333 diff = 181.000000'
});
data_peak.push({
lat: 4.2689444429e+01,
lng: 1.4275777778e+02,
cert : true,
content:'Name = Esaomantottabetsudake(JA8/TC-006) peak = 1901.699951 pos = 42.6894,142.7578 diff = 229.099976'
});
data_saddle.push({
lat: 4.2670222207e+01,
lng: 1.4275388889e+02,
content:'Saddle = 1672.599976 pos = 42.6702,142.7539 diff = 229.099976'
});
data_peak.push({
lat: 4.2693777762e+01,
lng: 1.4279666667e+02,
cert : true,
content:'Name = Satsunaidake(JA8/TC-007) peak = 1890.400024 pos = 42.6938,142.7967 diff = 208.000000'
});
data_saddle.push({
lat: 4.2690444429e+01,
lng: 1.4278088889e+02,
content:'Saddle = 1682.400024 pos = 42.6904,142.7809 diff = 208.000000'
});
data_peak.push({
lat: 4.2620222206e+01,
lng: 1.4278111111e+02,
cert : false,
content:' Peak = 1852.000000 pos = 42.6202,142.7811 diff = 150.300049'
});
data_saddle.push({
lat: 4.2620777762e+01,
lng: 1.4277566667e+02,
content:'Saddle = 1701.699951 pos = 42.6208,142.7757 diff = 150.300049'
});
data_peak.push({
lat: 4.2644777762e+01,
lng: 1.4275500000e+02,
cert : true,
content:'Name = JA8/HD-004(JA8/HD-004) peak = 1914.599976 pos = 42.6448,142.7550 diff = 183.599976'
});
data_saddle.push({
lat: 4.2638777762e+01,
lng: 1.4276177778e+02,
content:'Saddle = 1731.000000 pos = 42.6388,142.7618 diff = 183.599976'
});
data_peak.push({
lat: 4.2639999984e+01,
lng: 1.4277077778e+02,
cert : true,
content:'Name = JA8/TC-005(JA8/TC-005) peak = 1902.099976 pos = 42.6400,142.7708 diff = 170.000000'
});
data_saddle.push({
lat: 4.2630888873e+01,
lng: 1.4276944444e+02,
content:'Saddle = 1732.099976 pos = 42.6309,142.7694 diff = 170.000000'
});
data_peak.push({
lat: 4.2775888874e+01,
lng: 1.4276555556e+02,
cert : false,
content:' Peak = 1790.800049 pos = 42.7759,142.7656 diff = 250.100098'
});
data_saddle.push({
lat: 4.2771222207e+01,
lng: 1.4274355556e+02,
content:'Saddle = 1540.699951 pos = 42.7712,142.7436 diff = 250.100098'
});
data_peak.push({
lat: 4.2763555541e+01,
lng: 1.4278233333e+02,
cert : true,
content:'Name = JA8/TC-015(JA8/TC-015) peak = 1730.400024 pos = 42.7636,142.7823 diff = 157.700073'
});
data_saddle.push({
lat: 4.2768888874e+01,
lng: 1.4277466667e+02,
content:'Saddle = 1572.699951 pos = 42.7689,142.7747 diff = 157.700073'
});
data_peak.push({
lat: 4.2791888874e+01,
lng: 1.4272155556e+02,
cert : true,
content:'Name = JA8/TC-016(JA8/TC-016) peak = 1711.099976 pos = 42.7919,142.7216 diff = 158.400024'
});
data_saddle.push({
lat: 4.2785333319e+01,
lng: 1.4271733333e+02,
content:'Saddle = 1552.699951 pos = 42.7853,142.7173 diff = 158.400024'
});
data_peak.push({
lat: 4.2772333319e+01,
lng: 1.4270644444e+02,
cert : true,
content:'Name = JA8/HD-003(JA8/HD-003) peak = 1964.400024 pos = 42.7723,142.7064 diff = 231.599976'
});
data_saddle.push({
lat: 4.2730888874e+01,
lng: 1.4269155556e+02,
content:'Saddle = 1732.800049 pos = 42.7309,142.6916 diff = 231.599976'
});
data_peak.push({
lat: 4.2738666652e+01,
lng: 1.4269500000e+02,
cert : true,
content:'Name = Tottabetsudake(JA8/TC-004) peak = 1956.900024 pos = 42.7387,142.6950 diff = 184.599976'
});
data_saddle.push({
lat: 4.2758444430e+01,
lng: 1.4269188889e+02,
content:'Saddle = 1772.300049 pos = 42.7584,142.6919 diff = 184.599976'
});
data_peak.push({
lat: 4.3874222216e+01,
lng: 1.4338011111e+02,
cert : true,
content:'Name = JA8/OH-051(JA8/OH-051) peak = 854.700012 pos = 43.8742,143.3801 diff = 203.200012'
});
data_saddle.push({
lat: 4.3862111105e+01,
lng: 1.4338455556e+02,
content:'Saddle = 651.500000 pos = 43.8621,143.3846 diff = 203.200012'
});
data_peak.push({
lat: 4.3421333324e+01,
lng: 1.4332944444e+02,
cert : true,
content:'Name = JA8/TC-090(JA8/TC-090) peak = 870.599976 pos = 43.4213,143.3294 diff = 218.199951'
});
data_saddle.push({
lat: 4.3427666657e+01,
lng: 1.4332644444e+02,
content:'Saddle = 652.400024 pos = 43.4277,143.3264 diff = 218.199951'
});
data_peak.push({
lat: 4.3479444435e+01,
lng: 1.4334511111e+02,
cert : true,
content:'Name = JA8/TC-083(JA8/TC-083) peak = 971.000000 pos = 43.4794,143.3451 diff = 309.900024'
});
data_saddle.push({
lat: 4.3496111102e+01,
lng: 1.4335411111e+02,
content:'Saddle = 661.099976 pos = 43.4961,143.3541 diff = 309.900024'
});
data_peak.push({
lat: 4.3693888881e+01,
lng: 1.4343633333e+02,
cert : true,
content:'Name = JA8/OH-039(JA8/OH-039) peak = 957.200012 pos = 43.6939,143.4363 diff = 285.000000'
});
data_saddle.push({
lat: 4.3661222215e+01,
lng: 1.4339411111e+02,
content:'Saddle = 672.200012 pos = 43.6612,143.3941 diff = 285.000000'
});
data_peak.push({
lat: 4.3770444438e+01,
lng: 1.4342600000e+02,
cert : true,
content:'Name = JA8/OH-049(JA8/OH-049) peak = 861.700012 pos = 43.7704,143.4260 diff = 163.600037'
});
data_saddle.push({
lat: 4.3782999993e+01,
lng: 1.4342366667e+02,
content:'Saddle = 698.099976 pos = 43.7830,143.4237 diff = 163.600037'
});
data_peak.push({
lat: 4.3441999991e+01,
lng: 1.4331377778e+02,
cert : true,
content:'Name = JA8/TC-065(JA8/TC-065) peak = 1091.000000 pos = 43.4420,143.3138 diff = 388.799988'
});
data_saddle.push({
lat: 4.3455222213e+01,
lng: 1.4331388889e+02,
content:'Saddle = 702.200012 pos = 43.4552,143.3139 diff = 388.799988'
});
data_peak.push({
lat: 4.4000111106e+01,
lng: 1.4295333333e+02,
cert : true,
content:'Name = JA8/OH-031(JA8/OH-031) peak = 1020.400024 pos = 44.0001,142.9533 diff = 313.600037'
});
data_saddle.push({
lat: 4.3994222217e+01,
lng: 1.4293344444e+02,
content:'Saddle = 706.799988 pos = 43.9942,142.9334 diff = 313.600037'
});
data_peak.push({
lat: 4.3447777768e+01,
lng: 1.4345622222e+02,
cert : true,
content:'Name = Kitoushiyama(JA8/TC-040) peak = 1312.199951 pos = 43.4478,143.4562 diff = 603.699951'
});
data_saddle.push({
lat: 4.3551333325e+01,
lng: 1.4334700000e+02,
content:'Saddle = 708.500000 pos = 43.5513,143.3470 diff = 603.699951'
});
data_peak.push({
lat: 4.3528222213e+01,
lng: 1.4335133333e+02,
cert : true,
content:'Name = JA8/TC-085(JA8/TC-085) peak = 926.500000 pos = 43.5282,143.3513 diff = 168.099976'
});
data_saddle.push({
lat: 4.3524222213e+01,
lng: 1.4335844444e+02,
content:'Saddle = 758.400024 pos = 43.5242,143.3584 diff = 168.099976'
});
data_peak.push({
lat: 4.3556111103e+01,
lng: 1.4343233333e+02,
cert : true,
content:'Name = JA8/OH-032(JA8/OH-032) peak = 1022.799988 pos = 43.5561,143.4323 diff = 170.599976'
});
data_saddle.push({
lat: 4.3552333325e+01,
lng: 1.4342355556e+02,
content:'Saddle = 852.200012 pos = 43.5523,143.4236 diff = 170.599976'
});
data_peak.push({
lat: 4.3547555547e+01,
lng: 1.4337255556e+02,
cert : false,
content:' Peak = 1120.199951 pos = 43.5476,143.3726 diff = 152.099976'
});
data_saddle.push({
lat: 4.3547111102e+01,
lng: 1.4338666667e+02,
content:'Saddle = 968.099976 pos = 43.5471,143.3867 diff = 152.099976'
});
data_peak.push({
lat: 4.3173444433e+01,
lng: 1.4278088889e+02,
cert : true,
content:'Name = Sahorodake(JA8/TC-072) peak = 1059.199951 pos = 43.1734,142.7809 diff = 345.799927'
});
data_saddle.push({
lat: 4.3245111100e+01,
lng: 1.4273711111e+02,
content:'Saddle = 713.400024 pos = 43.2451,142.7371 diff = 345.799927'
});
data_peak.push({
lat: 4.3668999992e+01,
lng: 1.4333788889e+02,
cert : false,
content:' Peak = 1111.000000 pos = 43.6690,143.3379 diff = 393.700012'
});
data_saddle.push({
lat: 4.3645333325e+01,
lng: 1.4331622222e+02,
content:'Saddle = 717.299988 pos = 43.6453,143.3162 diff = 393.700012'
});
data_peak.push({
lat: 4.3688555548e+01,
lng: 1.4335977778e+02,
cert : true,
content:'Name = JA8/OH-042(JA8/OH-042) peak = 940.500000 pos = 43.6886,143.3598 diff = 185.000000'
});
data_saddle.push({
lat: 4.3670444437e+01,
lng: 1.4335933333e+02,
content:'Saddle = 755.500000 pos = 43.6704,143.3593 diff = 185.000000'
});
data_peak.push({
lat: 4.3637333325e+01,
lng: 1.4333855556e+02,
cert : true,
content:'Name = JA8/OH-034(JA8/OH-034) peak = 1018.299988 pos = 43.6373,143.3386 diff = 167.099976'
});
data_saddle.push({
lat: 4.3663555548e+01,
lng: 1.4334333333e+02,
content:'Saddle = 851.200012 pos = 43.6636,143.3433 diff = 167.099976'
});
data_peak.push({
lat: 4.3327222212e+01,
lng: 1.4286877778e+02,
cert : true,
content:'Name = JA8/TC-081(JA8/TC-081) peak = 999.900024 pos = 43.3272,142.8688 diff = 269.600037'
});
data_saddle.push({
lat: 4.3318111101e+01,
lng: 1.4284866667e+02,
content:'Saddle = 730.299988 pos = 43.3181,142.8487 diff = 269.600037'
});
data_peak.push({
lat: 4.3334444434e+01,
lng: 1.4289188889e+02,
cert : false,
content:' Peak = 990.799988 pos = 43.3344,142.8919 diff = 258.799988'
});
data_saddle.push({
lat: 4.3328888879e+01,
lng: 1.4287877778e+02,
content:'Saddle = 732.000000 pos = 43.3289,142.8788 diff = 258.799988'
});
data_peak.push({
lat: 4.4031333329e+01,
lng: 1.4295055556e+02,
cert : true,
content:'Name = JA8/OH-040(JA8/OH-040) peak = 951.700012 pos = 44.0313,142.9506 diff = 208.200012'
});
data_saddle.push({
lat: 4.4039999995e+01,
lng: 1.4293688889e+02,
content:'Saddle = 743.500000 pos = 44.0400,142.9369 diff = 208.200012'
});
data_peak.push({
lat: 4.3847555549e+01,
lng: 1.4339311111e+02,
cert : true,
content:'Name = JA8/OH-041(JA8/OH-041) peak = 947.400024 pos = 43.8476,143.3931 diff = 195.400024'
});
data_saddle.push({
lat: 4.3834888883e+01,
lng: 1.4339877778e+02,
content:'Saddle = 752.000000 pos = 43.8349,143.3988 diff = 195.400024'
});
data_peak.push({
lat: 4.3438999991e+01,
lng: 1.4287755556e+02,
cert : false,
content:' Peak = 912.099976 pos = 43.4390,142.8776 diff = 156.000000'
});
data_saddle.push({
lat: 4.3442999991e+01,
lng: 1.4287355556e+02,
content:'Saddle = 756.099976 pos = 43.4430,142.8736 diff = 156.000000'
});
data_peak.push({
lat: 4.3798555549e+01,
lng: 1.4341711111e+02,
cert : true,
content:'Name = JA8/OH-043(JA8/OH-043) peak = 922.599976 pos = 43.7986,143.4171 diff = 159.899963'
});
data_saddle.push({
lat: 4.3796777771e+01,
lng: 1.4341077778e+02,
content:'Saddle = 762.700012 pos = 43.7968,143.4108 diff = 159.899963'
});
data_peak.push({
lat: 4.3819777771e+01,
lng: 1.4338800000e+02,
cert : true,
content:'Name = JA8/OH-038(JA8/OH-038) peak = 980.799988 pos = 43.8198,143.3880 diff = 203.099976'
});
data_saddle.push({
lat: 4.3811222216e+01,
lng: 1.4339000000e+02,
content:'Saddle = 777.700012 pos = 43.8112,143.3900 diff = 203.099976'
});
data_peak.push({
lat: 4.3897111105e+01,
lng: 1.4282655556e+02,
cert : true,
content:'Name = JA8/KK-047(JA8/KK-047) peak = 1024.300049 pos = 43.8971,142.8266 diff = 240.800049'
});
data_saddle.push({
lat: 4.3903333328e+01,
lng: 1.4281955556e+02,
content:'Saddle = 783.500000 pos = 43.9033,142.8196 diff = 240.800049'
});
data_peak.push({
lat: 4.3451999991e+01,
lng: 1.4325166667e+02,
cert : true,
content:'Name = JA8/TC-080(JA8/TC-080) peak = 1002.700012 pos = 43.4520,143.2517 diff = 200.299988'
});
data_saddle.push({
lat: 4.3456777768e+01,
lng: 1.4326000000e+02,
content:'Saddle = 802.400024 pos = 43.4568,143.2600 diff = 200.299988'
});
data_peak.push({
lat: 4.3821999994e+01,
lng: 1.4333788889e+02,
cert : true,
content:'Name = JA8/OH-028(JA8/OH-028) peak = 1057.500000 pos = 43.8220,143.3379 diff = 249.299988'
});
data_saddle.push({
lat: 4.3811999993e+01,
lng: 1.4334255556e+02,
content:'Saddle = 808.200012 pos = 43.8120,143.3426 diff = 249.299988'
});
data_peak.push({
lat: 4.3763999993e+01,
lng: 1.4332677778e+02,
cert : true,
content:'Name = JA8/OH-019(JA8/OH-019) peak = 1162.000000 pos = 43.7640,143.3268 diff = 353.400024'
});
data_saddle.push({
lat: 4.3744555549e+01,
lng: 1.4326555556e+02,
content:'Saddle = 808.599976 pos = 43.7446,143.2656 diff = 353.400024'
});
data_peak.push({
lat: 4.3788222216e+01,
lng: 1.4330600000e+02,
cert : true,
content:'Name = JA8/OH-025(JA8/OH-025) peak = 1071.599976 pos = 43.7882,143.3060 diff = 198.500000'
});
data_saddle.push({
lat: 4.3779777771e+01,
lng: 1.4330666667e+02,
content:'Saddle = 873.099976 pos = 43.7798,143.3067 diff = 198.500000'
});
data_peak.push({
lat: 4.3387222212e+01,
lng: 1.4283855556e+02,
cert : true,
content:'Name = JA8/TC-064(JA8/TC-064) peak = 1092.900024 pos = 43.3872,142.8386 diff = 266.100037'
});
data_saddle.push({
lat: 4.3369222212e+01,
lng: 1.4283022222e+02,
content:'Saddle = 826.799988 pos = 43.3692,142.8302 diff = 266.100037'
});
data_peak.push({
lat: 4.3964444439e+01,
lng: 1.4288800000e+02,
cert : true,
content:'Name = Teshiodake(JA8/OH-004) peak = 1556.699951 pos = 43.9644,142.8880 diff = 717.799927'
});
data_saddle.push({
lat: 4.3883222216e+01,
lng: 1.4302055556e+02,
content:'Saddle = 838.900024 pos = 43.8832,143.0206 diff = 717.799927'
});
data_peak.push({
lat: 4.3965444439e+01,
lng: 1.4301522222e+02,
cert : true,
content:'Name = JA8/OH-023(JA8/OH-023) peak = 1101.099976 pos = 43.9654,143.0152 diff = 239.299988'
});
data_saddle.push({
lat: 4.3954888884e+01,
lng: 1.4303188889e+02,
content:'Saddle = 861.799988 pos = 43.9549,143.0319 diff = 239.299988'
});
data_peak.push({
lat: 4.3990111106e+01,
lng: 1.4281333333e+02,
cert : true,
content:'Name = JA8/KK-048(JA8/KK-048) peak = 1021.299988 pos = 43.9901,142.8133 diff = 158.899963'
});
data_saddle.push({
lat: 4.3998333328e+01,
lng: 1.4282300000e+02,
content:'Saddle = 862.400024 pos = 43.9983,142.8230 diff = 158.899963'
});
data_peak.push({
lat: 4.3906888883e+01,
lng: 1.4304844444e+02,
cert : true,
content:'Name = Chitokaniushiyama(JA8/OH-006) peak = 1443.699951 pos = 43.9069,143.0484 diff = 572.599976'
});
data_saddle.push({
lat: 4.3935777772e+01,
lng: 1.4296088889e+02,
content:'Saddle = 871.099976 pos = 43.9358,142.9609 diff = 572.599976'
});
data_peak.push({
lat: 4.3918333328e+01,
lng: 1.4313755556e+02,
cert : true,
content:'Name = JA8/OH-018(JA8/OH-018) peak = 1181.199951 pos = 43.9183,143.1376 diff = 294.899963'
});
data_saddle.push({
lat: 4.3927222217e+01,
lng: 1.4313833333e+02,
content:'Saddle = 886.299988 pos = 43.9272,143.1383 diff = 294.899963'
});
data_peak.push({
lat: 4.4003333328e+01,
lng: 1.4312555556e+02,
cert : true,
content:'Name = JA8/OH-010(JA8/OH-010) peak = 1300.500000 pos = 44.0033,143.1256 diff = 288.500000'
});
data_saddle.push({
lat: 4.3980888884e+01,
lng: 1.4309411111e+02,
content:'Saddle = 1012.000000 pos = 43.9809,143.0941 diff = 288.500000'
});
data_peak.push({
lat: 4.3955111106e+01,
lng: 1.4310033333e+02,
cert : false,
content:' Peak = 1267.400024 pos = 43.9551,143.1003 diff = 179.700073'
});
data_saddle.push({
lat: 4.3936666661e+01,
lng: 1.4308055556e+02,
content:'Saddle = 1087.699951 pos = 43.9367,143.0806 diff = 179.700073'
});
data_peak.push({
lat: 4.4009666662e+01,
lng: 1.4277000000e+02,
cert : true,
content:'Name = JA8/KK-039(JA8/KK-039) peak = 1170.900024 pos = 44.0097,142.7700 diff = 287.100037'
});
data_saddle.push({
lat: 4.4005222217e+01,
lng: 1.4282611111e+02,
content:'Saddle = 883.799988 pos = 44.0052,142.8261 diff = 287.100037'
});
data_peak.push({
lat: 4.3929777772e+01,
lng: 1.4283022222e+02,
cert : true,
content:'Name = JA8/KK-036(JA8/KK-036) peak = 1215.500000 pos = 43.9298,142.8302 diff = 212.900024'
});
data_saddle.push({
lat: 4.3934999994e+01,
lng: 1.4283933333e+02,
content:'Saddle = 1002.599976 pos = 43.9350,142.8393 diff = 212.900024'
});
data_peak.push({
lat: 4.4040333329e+01,
lng: 1.4291733333e+02,
cert : true,
content:'Name = Shokotsudake(JA8/OH-008) peak = 1346.099976 pos = 44.0403,142.9173 diff = 295.000000'
});
data_saddle.push({
lat: 4.4034888884e+01,
lng: 1.4287311111e+02,
content:'Saddle = 1051.099976 pos = 44.0349,142.8731 diff = 295.000000'
});
data_peak.push({
lat: 4.4048555551e+01,
lng: 1.4287755556e+02,
cert : true,
content:'Name = JA8/KK-032(JA8/KK-032) peak = 1280.500000 pos = 44.0486,142.8776 diff = 186.400024'
});
data_saddle.push({
lat: 4.4040222218e+01,
lng: 1.4288488889e+02,
content:'Saddle = 1094.099976 pos = 44.0402,142.8849 diff = 186.400024'
});
data_peak.push({
lat: 4.3976555550e+01,
lng: 1.4288677778e+02,
cert : true,
content:'Name = JA8/KK-024(JA8/KK-024) peak = 1539.300049 pos = 43.9766,142.8868 diff = 188.400024'
});
data_saddle.push({
lat: 4.3971666661e+01,
lng: 1.4289066667e+02,
content:'Saddle = 1350.900024 pos = 43.9717,142.8907 diff = 188.400024'
});
data_peak.push({
lat: 4.3416444435e+01,
lng: 1.4323777778e+02,
cert : true,
content:'Name = JA8/TC-054(JA8/TC-054) peak = 1211.400024 pos = 43.4164,143.2378 diff = 370.500000'
});
data_saddle.push({
lat: 4.3454999991e+01,
lng: 1.4321466667e+02,
content:'Saddle = 840.900024 pos = 43.4550,143.2147 diff = 370.500000'
});
data_peak.push({
lat: 4.3387111101e+01,
lng: 1.4323677778e+02,
cert : true,
content:'Name = JA8/TC-069(JA8/TC-069) peak = 1071.500000 pos = 43.3871,143.2368 diff = 204.200012'
});
data_saddle.push({
lat: 4.3395666657e+01,
lng: 1.4324288889e+02,
content:'Saddle = 867.299988 pos = 43.3957,143.2429 diff = 204.200012'
});
data_peak.push({
lat: 4.3449222213e+01,
lng: 1.4321122222e+02,
cert : true,
content:'Name = JA8/TC-057(JA8/TC-057) peak = 1184.199951 pos = 43.4492,143.2112 diff = 302.299927'
});
data_saddle.push({
lat: 4.3427111102e+01,
lng: 1.4323488889e+02,
content:'Saddle = 881.900024 pos = 43.4271,143.2349 diff = 302.299927'
});
data_peak.push({
lat: 4.3455666657e+01,
lng: 1.4316666667e+02,
cert : true,
content:'Name = JA8/TC-076(JA8/TC-076) peak = 1023.500000 pos = 43.4557,143.1667 diff = 180.799988'
});
data_saddle.push({
lat: 4.3457111102e+01,
lng: 1.4318522222e+02,
content:'Saddle = 842.700012 pos = 43.4571,143.1852 diff = 180.799988'
});
data_peak.push({
lat: 4.3245777767e+01,
lng: 1.4310200000e+02,
cert : true,
content:'Name = Higashinupukaushinupuri(JA8/TC-049) peak = 1251.699951 pos = 43.2458,143.1020 diff = 399.199951'
});
data_saddle.push({
lat: 4.3268111100e+01,
lng: 1.4314466667e+02,
content:'Saddle = 852.500000 pos = 43.2681,143.1447 diff = 399.199951'
});
data_peak.push({
lat: 4.3255666656e+01,
lng: 1.4308244444e+02,
cert : false,
content:' Peak = 1250.599976 pos = 43.2557,143.0824 diff = 342.599976'
});
data_saddle.push({
lat: 4.3252999989e+01,
lng: 1.4309322222e+02,
content:'Saddle = 908.000000 pos = 43.2530,143.0932 diff = 342.599976'
});
data_peak.push({
lat: 4.3265999989e+01,
lng: 1.4312855556e+02,
cert : false,
content:' Peak = 1178.099976 pos = 43.2660,143.1286 diff = 229.599976'
});
data_saddle.push({
lat: 4.3261222211e+01,
lng: 1.4312100000e+02,
content:'Saddle = 948.500000 pos = 43.2612,143.1210 diff = 229.599976'
});
data_peak.push({
lat: 4.3258777767e+01,
lng: 1.4311511111e+02,
cert : true,
content:'Name = JA8/TC-056(JA8/TC-056) peak = 1190.699951 pos = 43.2588,143.1151 diff = 186.899963'
});
data_saddle.push({
lat: 4.3254555545e+01,
lng: 1.4309900000e+02,
content:'Saddle = 1003.799988 pos = 43.2546,143.0990 diff = 186.899963'
});
data_peak.push({
lat: 4.3347999990e+01,
lng: 1.4281822222e+02,
cert : false,
content:' Peak = 1018.900024 pos = 43.3480,142.8182 diff = 150.600037'
});
data_saddle.push({
lat: 4.3352666656e+01,
lng: 1.4276244444e+02,
content:'Saddle = 868.299988 pos = 43.3527,142.7624 diff = 150.600037'
});
data_peak.push({
lat: 4.3693666659e+01,
lng: 1.4329577778e+02,
cert : true,
content:'Name = Kitamifuji(JA8/OH-012) peak = 1293.300049 pos = 43.6937,143.2958 diff = 401.300049'
});
data_saddle.push({
lat: 4.3708666659e+01,
lng: 1.4327744444e+02,
content:'Saddle = 892.000000 pos = 43.7087,143.2774 diff = 401.300049'
});
data_peak.push({
lat: 4.3716888882e+01,
lng: 1.4328411111e+02,
cert : true,
content:'Name = JA8/OH-020(JA8/OH-020) peak = 1161.500000 pos = 43.7169,143.2841 diff = 243.299988'
});
data_saddle.push({
lat: 4.3701999993e+01,
lng: 1.4328988889e+02,
content:'Saddle = 918.200012 pos = 43.7020,143.2899 diff = 243.299988'
});
data_peak.push({
lat: 4.3402111101e+01,
lng: 1.4314688889e+02,
cert : true,
content:'Name = JA8/TC-074(JA8/TC-074) peak = 1055.800049 pos = 43.4021,143.1469 diff = 158.000061'
});
data_saddle.push({
lat: 4.3397888879e+01,
lng: 1.4314233333e+02,
content:'Saddle = 897.799988 pos = 43.3979,143.1423 diff = 158.000061'
});
data_peak.push({
lat: 4.3573111103e+01,
lng: 1.4325744444e+02,
cert : true,
content:'Name = JA8/OH-024(JA8/OH-024) peak = 1090.000000 pos = 43.5731,143.2574 diff = 172.599976'
});
data_saddle.push({
lat: 4.3568777769e+01,
lng: 1.4325488889e+02,
content:'Saddle = 917.400024 pos = 43.5688,143.2549 diff = 172.599976'
});
data_peak.push({
lat: 4.3448444435e+01,
lng: 1.4313100000e+02,
cert : true,
content:'Name = JA8/TC-059(JA8/TC-059) peak = 1162.199951 pos = 43.4484,143.1310 diff = 239.999939'
});
data_saddle.push({
lat: 4.3450666657e+01,
lng: 1.4311788889e+02,
content:'Saddle = 922.200012 pos = 43.4507,143.1179 diff = 239.999939'
});
data_peak.push({
lat: 4.3471666657e+01,
lng: 1.4317200000e+02,
cert : true,
content:'Name = JA8/TC-067(JA8/TC-067) peak = 1083.400024 pos = 43.4717,143.1720 diff = 160.100037'
});
data_saddle.push({
lat: 4.3475555546e+01,
lng: 1.4318055556e+02,
content:'Saddle = 923.299988 pos = 43.4756,143.1806 diff = 160.100037'
});
data_peak.push({
lat: 4.3296777767e+01,
lng: 1.4298488889e+02,
cert : true,
content:'Name = JA8/TC-041(JA8/TC-041) peak = 1310.800049 pos = 43.2968,142.9849 diff = 368.100037'
});
data_saddle.push({
lat: 4.3337333323e+01,
lng: 1.4301111111e+02,
content:'Saddle = 942.700012 pos = 43.3373,143.0111 diff = 368.100037'
});
data_peak.push({
lat: 4.3322111101e+01,
lng: 1.4300977778e+02,
cert : true,
content:'Name = JA8/TC-046(JA8/TC-046) peak = 1260.199951 pos = 43.3221,143.0098 diff = 217.099976'
});
data_saddle.push({
lat: 4.3315444434e+01,
lng: 1.4299133333e+02,
content:'Saddle = 1043.099976 pos = 43.3154,142.9913 diff = 217.099976'
});
data_peak.push({
lat: 4.3399888879e+01,
lng: 1.4290777778e+02,
cert : true,
content:'Name = JA8/TC-060(JA8/TC-060) peak = 1153.699951 pos = 43.3999,142.9078 diff = 191.799927'
});
data_saddle.push({
lat: 4.3405333324e+01,
lng: 1.4292000000e+02,
content:'Saddle = 961.900024 pos = 43.4053,142.9200 diff = 191.799927'
});
data_peak.push({
lat: 4.3519222213e+01,
lng: 1.4323322222e+02,
cert : true,
content:'Name = Nishikumaneshiridake(JA8/TC-021) peak = 1633.099976 pos = 43.5192,143.2332 diff = 660.599976'
});
data_saddle.push({
lat: 4.3581888881e+01,
lng: 1.4321011111e+02,
content:'Saddle = 972.500000 pos = 43.5819,143.2101 diff = 660.599976'
});
data_peak.push({
lat: 4.3562333325e+01,
lng: 1.4322588889e+02,
cert : true,
content:'Name = JA8/TC-038(JA8/TC-038) peak = 1353.800049 pos = 43.5623,143.2259 diff = 200.300049'
});
data_saddle.push({
lat: 4.3541333325e+01,
lng: 1.4323033333e+02,
content:'Saddle = 1153.500000 pos = 43.5413,143.2303 diff = 200.300049'
});
data_peak.push({
lat: 4.3492333324e+01,
lng: 1.4324488889e+02,
cert : true,
content:'Name = JA8/TC-026(JA8/TC-026) peak = 1557.900024 pos = 43.4923,143.2449 diff = 374.599976'
});
data_saddle.push({
lat: 4.3504777769e+01,
lng: 1.4323522222e+02,
content:'Saddle = 1183.300049 pos = 43.5048,143.2352 diff = 374.599976'
});
data_peak.push({
lat: 4.3527777769e+01,
lng: 1.4322522222e+02,
cert : true,
content:'Name = JA8/TC-024(JA8/TC-024) peak = 1601.000000 pos = 43.5278,143.2252 diff = 189.000000'
});
data_saddle.push({
lat: 4.3522555547e+01,
lng: 1.4323055556e+02,
content:'Saddle = 1412.000000 pos = 43.5226,143.2306 diff = 189.000000'
});
data_peak.push({
lat: 4.3722555548e+01,
lng: 1.4325744444e+02,
cert : false,
content:' Peak = 1251.099976 pos = 43.7226,143.2574 diff = 270.399963'
});
data_saddle.push({
lat: 4.3715777771e+01,
lng: 1.4325422222e+02,
content:'Saddle = 980.700012 pos = 43.7158,143.2542 diff = 270.399963'
});
data_peak.push({
lat: 4.3658999992e+01,
lng: 1.4308811111e+02,
cert : true,
content:'Name = JA8/KK-041(JA8/KK-041) peak = 1153.699951 pos = 43.6590,143.0881 diff = 162.699951'
});
data_saddle.push({
lat: 4.3664333326e+01,
lng: 1.4310477778e+02,
content:'Saddle = 991.000000 pos = 43.6643,143.1048 diff = 162.699951'
});
data_peak.push({
lat: 4.3603777770e+01,
lng: 1.4322311111e+02,
cert : true,
content:'Name = JA8/OH-017(JA8/OH-017) peak = 1232.099976 pos = 43.6038,143.2231 diff = 224.000000'
});
data_saddle.push({
lat: 4.3601555547e+01,
lng: 1.4320400000e+02,
content:'Saddle = 1008.099976 pos = 43.6016,143.2040 diff = 224.000000'
});
data_peak.push({
lat: 4.3390999990e+01,
lng: 1.4314200000e+02,
cert : false,
content:' Peak = 1167.800049 pos = 43.3910,143.1420 diff = 155.200073'
});
data_saddle.push({
lat: 4.3388222212e+01,
lng: 1.4313677778e+02,
content:'Saddle = 1012.599976 pos = 43.3882,143.1368 diff = 155.200073'
});
data_peak.push({
lat: 4.3684999992e+01,
lng: 1.4274022222e+02,
cert : false,
content:' Peak = 1247.000000 pos = 43.6850,142.7402 diff = 229.200012'
});
data_saddle.push({
lat: 4.3697111104e+01,
lng: 1.4277233333e+02,
content:'Saddle = 1017.799988 pos = 43.6971,142.7723 diff = 229.200012'
});
data_peak.push({
lat: 4.3299222212e+01,
lng: 1.4314833333e+02,
cert : true,
content:'Name = JA8/TC-039(JA8/TC-039) peak = 1336.599976 pos = 43.2992,143.1483 diff = 313.799988'
});
data_saddle.push({
lat: 4.3319222212e+01,
lng: 1.4317055556e+02,
content:'Saddle = 1022.799988 pos = 43.3192,143.1706 diff = 313.799988'
});
data_peak.push({
lat: 4.3779888882e+01,
lng: 1.4298522222e+02,
cert : true,
content:'Name = Niseikaushyuppeyama(JA8/KK-013) peak = 1880.599976 pos = 43.7799,142.9852 diff = 852.099976'
});
data_saddle.push({
lat: 4.3649333326e+01,
lng: 1.4316833333e+02,
content:'Saddle = 1028.500000 pos = 43.6493,143.1683 diff = 852.099976'
});
data_peak.push({
lat: 4.3821888882e+01,
lng: 1.4322066667e+02,
cert : true,
content:'Name = JA8/OH-016(JA8/OH-016) peak = 1232.400024 pos = 43.8219,143.2207 diff = 179.500000'
});
data_saddle.push({
lat: 4.3819999994e+01,
lng: 1.4321144444e+02,
content:'Saddle = 1052.900024 pos = 43.8200,143.2114 diff = 179.500000'
});
data_peak.push({
lat: 4.3684222215e+01,
lng: 1.4306622222e+02,
cert : true,
content:'Name = JA8/KK-033(JA8/KK-033) peak = 1252.300049 pos = 43.6842,143.0662 diff = 179.600098'
});
data_saddle.push({
lat: 4.3688777770e+01,
lng: 1.4309033333e+02,
content:'Saddle = 1072.699951 pos = 43.6888,143.0903 diff = 179.600098'
});
data_peak.push({
lat: 4.3823777771e+01,
lng: 1.4318244444e+02,
cert : true,
content:'Name = JA8/OH-011(JA8/OH-011) peak = 1291.199951 pos = 43.8238,143.1824 diff = 193.799927'
});
data_saddle.push({
lat: 4.3818111105e+01,
lng: 1.4320055556e+02,
content:'Saddle = 1097.400024 pos = 43.8181,143.2006 diff = 193.799927'
});
data_peak.push({
lat: 4.3732999993e+01,
lng: 1.4317644444e+02,
cert : true,
content:'Name = Muriidake(JA8/KK-014) peak = 1875.400024 pos = 43.7330,143.1764 diff = 612.900024'
});
data_saddle.push({
lat: 4.3745999993e+01,
lng: 1.4305844444e+02,
content:'Saddle = 1262.500000 pos = 43.7460,143.0584 diff = 612.900024'
});
data_peak.push({
lat: 4.3726777771e+01,
lng: 1.4305922222e+02,
cert : true,
content:'Name = JA8/KK-015(JA8/KK-015) peak = 1791.199951 pos = 43.7268,143.0592 diff = 448.599976'
});
data_saddle.push({
lat: 4.3742999993e+01,
lng: 1.4309433333e+02,
content:'Saddle = 1342.599976 pos = 43.7430,143.0943 diff = 448.599976'
});
data_peak.push({
lat: 4.3734333326e+01,
lng: 1.4311722222e+02,
cert : true,
content:'Name = JA8/KK-022(JA8/KK-022) peak = 1628.699951 pos = 43.7343,143.1172 diff = 167.099976'
});
data_saddle.push({
lat: 4.3746111104e+01,
lng: 1.4313155556e+02,
content:'Saddle = 1461.599976 pos = 43.7461,143.1316 diff = 167.099976'
});
data_peak.push({
lat: 4.3705777770e+01,
lng: 1.4316044444e+02,
cert : true,
content:'Name = Mukayama(JA8/KK-017) peak = 1752.599976 pos = 43.7058,143.1604 diff = 269.599976'
});
data_saddle.push({
lat: 4.3716777771e+01,
lng: 1.4316833333e+02,
content:'Saddle = 1483.000000 pos = 43.7168,143.1683 diff = 269.599976'
});
data_peak.push({
lat: 4.3761666660e+01,
lng: 1.4316044444e+02,
cert : true,
content:'Name = JA8/KK-016(JA8/KK-016) peak = 1758.599976 pos = 43.7617,143.1604 diff = 235.799927'
});
data_saddle.push({
lat: 4.3754444437e+01,
lng: 1.4316911111e+02,
content:'Saddle = 1522.800049 pos = 43.7544,143.1691 diff = 235.799927'
});
data_peak.push({
lat: 4.3812444438e+01,
lng: 1.4304655556e+02,
cert : true,
content:'Name = JA8/OH-002(JA8/OH-002) peak = 1633.500000 pos = 43.8124,143.0466 diff = 312.000000'
});
data_saddle.push({
lat: 4.3804999993e+01,
lng: 1.4302588889e+02,
content:'Saddle = 1321.500000 pos = 43.8050,143.0259 diff = 312.000000'
});
data_peak.push({
lat: 4.3646555548e+01,
lng: 1.4313144444e+02,
cert : false,
content:' Peak = 1188.699951 pos = 43.6466,143.1314 diff = 150.599976'
});
data_saddle.push({
lat: 4.3641111103e+01,
lng: 1.4314600000e+02,
content:'Saddle = 1038.099976 pos = 43.6411,143.1460 diff = 150.599976'
});
data_peak.push({
lat: 4.3317555545e+01,
lng: 1.4308866667e+02,
cert : false,
content:' Peak = 1420.000000 pos = 43.3176,143.0887 diff = 381.400024'
});
data_saddle.push({
lat: 4.3325444434e+01,
lng: 1.4310011111e+02,
content:'Saddle = 1038.599976 pos = 43.3254,143.1001 diff = 381.400024'
});
data_peak.push({
lat: 4.3277888878e+01,
lng: 1.4305911111e+02,
cert : true,
content:'Name = JA8/TC-044(JA8/TC-044) peak = 1283.699951 pos = 43.2779,143.0591 diff = 217.099976'
});
data_saddle.push({
lat: 4.3278333323e+01,
lng: 1.4306688889e+02,
content:'Saddle = 1066.599976 pos = 43.2783,143.0669 diff = 217.099976'
});
data_peak.push({
lat: 4.3293333323e+01,
lng: 1.4308555556e+02,
cert : true,
content:'Name = JA8/TC-034(JA8/TC-034) peak = 1413.099976 pos = 43.2933,143.0856 diff = 259.900024'
});
data_saddle.push({
lat: 4.3301333323e+01,
lng: 1.4308611111e+02,
content:'Saddle = 1153.199951 pos = 43.3013,143.0861 diff = 259.900024'
});
data_peak.push({
lat: 4.3278555545e+01,
lng: 1.4308222222e+02,
cert : true,
content:'Name = JA8/TC-035(JA8/TC-035) peak = 1362.099976 pos = 43.2786,143.0822 diff = 175.000000'
});
data_saddle.push({
lat: 4.3288222212e+01,
lng: 1.4308644444e+02,
content:'Saddle = 1187.099976 pos = 43.2882,143.0864 diff = 175.000000'
});
data_peak.push({
lat: 4.3436333324e+01,
lng: 1.4293088889e+02,
cert : true,
content:'Name = JA8/TC-051(JA8/TC-051) peak = 1241.699951 pos = 43.4363,142.9309 diff = 198.299927'
});
data_saddle.push({
lat: 4.3428666657e+01,
lng: 1.4293511111e+02,
content:'Saddle = 1043.400024 pos = 43.4287,142.9351 diff = 198.299927'
});
data_peak.push({
lat: 4.3619666659e+01,
lng: 1.4306988889e+02,
cert : false,
content:' Peak = 1212.900024 pos = 43.6197,143.0699 diff = 151.900024'
});
data_saddle.push({
lat: 4.3609666659e+01,
lng: 1.4309488889e+02,
content:'Saddle = 1061.000000 pos = 43.6097,143.0949 diff = 151.900024'
});
data_peak.push({
lat: 4.3423777768e+01,
lng: 1.4295111111e+02,
cert : false,
content:' Peak = 1264.000000 pos = 43.4238,142.9511 diff = 186.699951'
});
data_saddle.push({
lat: 4.3446555546e+01,
lng: 1.4298744444e+02,
content:'Saddle = 1077.300049 pos = 43.4466,142.9874 diff = 186.699951'
});
data_peak.push({
lat: 4.3329222212e+01,
lng: 1.4316866667e+02,
cert : true,
content:'Name = JA8/TC-052(JA8/TC-052) peak = 1242.699951 pos = 43.3292,143.1687 diff = 162.099976'
});
data_saddle.push({
lat: 4.3337999990e+01,
lng: 1.4316033333e+02,
content:'Saddle = 1080.599976 pos = 43.3380,143.1603 diff = 162.099976'
});
data_peak.push({
lat: 4.3339666656e+01,
lng: 1.4263222222e+02,
cert : true,
content:'Name = JA8/KK-025(JA8/KK-025) peak = 1455.099976 pos = 43.3397,142.6322 diff = 371.699951'
});
data_saddle.push({
lat: 4.3359999990e+01,
lng: 1.4265233333e+02,
content:'Saddle = 1083.400024 pos = 43.3600,142.6523 diff = 371.699951'
});
data_peak.push({
lat: 4.3350222212e+01,
lng: 1.4314555556e+02,
cert : true,
content:'Name = JA8/TC-043(JA8/TC-043) peak = 1293.199951 pos = 43.3502,143.1456 diff = 206.000000'
});
data_saddle.push({
lat: 4.3353444434e+01,
lng: 1.4313222222e+02,
content:'Saddle = 1087.199951 pos = 43.3534,143.1322 diff = 206.000000'
});
data_peak.push({
lat: 4.3472555546e+01,
lng: 1.4297666667e+02,
cert : true,
content:'Name = JA8/TC-036(JA8/TC-036) peak = 1354.500000 pos = 43.4726,142.9767 diff = 222.900024'
});
data_saddle.push({
lat: 4.3462333324e+01,
lng: 1.4299222222e+02,
content:'Saddle = 1131.599976 pos = 43.4623,142.9922 diff = 222.900024'
});
data_peak.push({
lat: 4.3389555546e+01,
lng: 1.4308200000e+02,
cert : true,
content:'Name = Upepesankeyama(JA8/TC-009) peak = 1847.199951 pos = 43.3896,143.0820 diff = 640.199951'
});
data_saddle.push({
lat: 4.3402444435e+01,
lng: 1.4303177778e+02,
content:'Saddle = 1207.000000 pos = 43.4024,143.0318 diff = 640.199951'
});
data_peak.push({
lat: 4.3398666657e+01,
lng: 1.4304544444e+02,
cert : true,
content:'Name = JA8/TC-020(JA8/TC-020) peak = 1665.099976 pos = 43.3987,143.0454 diff = 286.599976'
});
data_saddle.push({
lat: 4.3385111101e+01,
lng: 1.4305733333e+02,
content:'Saddle = 1378.500000 pos = 43.3851,143.0573 diff = 286.599976'
});
data_peak.push({
lat: 4.3612666659e+01,
lng: 1.4313011111e+02,
cert : true,
content:'Name = JA8/KK-028(JA8/KK-028) peak = 1413.599976 pos = 43.6127,143.1301 diff = 200.500000'
});
data_saddle.push({
lat: 4.3604999992e+01,
lng: 1.4313588889e+02,
content:'Saddle = 1213.099976 pos = 43.6050,143.1359 diff = 200.500000'
});
data_peak.push({
lat: 4.3595555547e+01,
lng: 1.4307311111e+02,
cert : true,
content:'Name = JA8/KK-027(JA8/KK-027) peak = 1433.599976 pos = 43.5956,143.0731 diff = 211.799927'
});
data_saddle.push({
lat: 4.3589777769e+01,
lng: 1.4308588889e+02,
content:'Saddle = 1221.800049 pos = 43.5898,143.0859 diff = 211.799927'
});
data_peak.push({
lat: 4.3360777768e+01,
lng: 1.4271944444e+02,
cert : true,
content:'Name = JA8/KK-020(JA8/KK-020) peak = 1661.400024 pos = 43.3608,142.7194 diff = 392.400024'
});
data_saddle.push({
lat: 4.3369333323e+01,
lng: 1.4271411111e+02,
content:'Saddle = 1269.000000 pos = 43.3693,142.7141 diff = 392.400024'
});
data_peak.push({
lat: 4.3416111101e+01,
lng: 1.4302900000e+02,
cert : false,
content:' Peak = 1691.599976 pos = 43.4161,143.0290 diff = 421.000000'
});
data_saddle.push({
lat: 4.3430333324e+01,
lng: 1.4302911111e+02,
content:'Saddle = 1270.599976 pos = 43.4303,143.0291 diff = 421.000000'
});
data_peak.push({
lat: 4.3455999991e+01,
lng: 1.4303211111e+02,
cert : true,
content:'Name = Nipesotsuyama(JA8/TC-002) peak = 2011.000000 pos = 43.4560,143.0321 diff = 723.199951'
});
data_saddle.push({
lat: 4.3533666658e+01,
lng: 1.4298644444e+02,
content:'Saddle = 1287.800049 pos = 43.5337,142.9864 diff = 723.199951'
});
data_peak.push({
lat: 4.3548777769e+01,
lng: 1.4302300000e+02,
cert : false,
content:' Peak = 1963.900024 pos = 43.5488,143.0230 diff = 651.599976'
});
data_saddle.push({
lat: 4.3486555546e+01,
lng: 1.4303377778e+02,
content:'Saddle = 1312.300049 pos = 43.4866,143.0338 diff = 651.599976'
});
data_peak.push({
lat: 4.3564555547e+01,
lng: 1.4307022222e+02,
cert : true,
content:'Name = JA8/KK-018(JA8/KK-018) peak = 1755.300049 pos = 43.5646,143.0702 diff = 224.000000'
});
data_saddle.push({
lat: 4.3560333325e+01,
lng: 1.4306888889e+02,
content:'Saddle = 1531.300049 pos = 43.5603,143.0689 diff = 224.000000'
});
data_peak.push({
lat: 4.3561777769e+01,
lng: 1.4303533333e+02,
cert : true,
content:'Name = Otofukeyama(JA8/KK-010) peak = 1930.800049 pos = 43.5618,143.0353 diff = 188.100098'
});
data_saddle.push({
lat: 4.3555888880e+01,
lng: 1.4303422222e+02,
content:'Saddle = 1742.699951 pos = 43.5559,143.0342 diff = 188.100098'
});
data_peak.push({
lat: 4.3470333324e+01,
lng: 1.4304444444e+02,
cert : true,
content:'Name = JA8/TC-008(JA8/TC-008) peak = 1884.699951 pos = 43.4703,143.0444 diff = 162.199951'
});
data_saddle.push({
lat: 4.3461555546e+01,
lng: 1.4303777778e+02,
content:'Saddle = 1722.500000 pos = 43.4616,143.0378 diff = 162.199951'
});
data_peak.push({
lat: 4.3381888879e+01,
lng: 1.4260577778e+02,
cert : true,
content:'Name = JA8/KK-023(JA8/KK-023) peak = 1624.500000 pos = 43.3819,142.6058 diff = 265.300049'
});
data_saddle.push({
lat: 4.3385888879e+01,
lng: 1.4261822222e+02,
content:'Saddle = 1359.199951 pos = 43.3859,142.6182 diff = 265.300049'
});
data_peak.push({
lat: 4.3417888879e+01,
lng: 1.4268622222e+02,
cert : true,
content:'Name = Tokachidake(JA8/KK-005) peak = 2076.399902 pos = 43.4179,142.6862 diff = 671.799927'
});
data_saddle.push({
lat: 4.3482111102e+01,
lng: 1.4276644444e+02,
content:'Saddle = 1404.599976 pos = 43.4821,142.7664 diff = 671.799927'
});
data_peak.push({
lat: 4.3470222213e+01,
lng: 1.4275155556e+02,
cert : true,
content:'Name = Oputateshikeyama(JA8/TC-003) peak = 2011.400024 pos = 43.4702,142.7516 diff = 357.200073'
});
data_saddle.push({
lat: 4.3452222213e+01,
lng: 1.4272300000e+02,
content:'Saddle = 1654.199951 pos = 43.4522,142.7230 diff = 357.200073'
});
data_peak.push({
lat: 4.3393777768e+01,
lng: 1.4263500000e+02,
cert : true,
content:'Name = Furanodake(JA8/KK-011) peak = 1911.099976 pos = 43.3938,142.6350 diff = 204.400024'
});
data_saddle.push({
lat: 4.3395111101e+01,
lng: 1.4264333333e+02,
content:'Saddle = 1706.699951 pos = 43.3951,142.6433 diff = 204.400024'
});
data_peak.push({
lat: 4.3452666657e+01,
lng: 1.4271355556e+02,
cert : true,
content:'Name = JA8/KK-012(JA8/KK-012) peak = 1887.800049 pos = 43.4527,142.7136 diff = 171.300049'
});
data_saddle.push({
lat: 4.3446999991e+01,
lng: 1.4271277778e+02,
content:'Saddle = 1716.500000 pos = 43.4470,142.7128 diff = 171.300049'
});
data_peak.push({
lat: 4.3439888879e+01,
lng: 1.4270633333e+02,
cert : true,
content:'Name = Bieidake(JA8/KK-006) peak = 2051.300049 pos = 43.4399,142.7063 diff = 264.600098'
});
data_saddle.push({
lat: 4.3428222213e+01,
lng: 1.4270277778e+02,
content:'Saddle = 1786.699951 pos = 43.4282,142.7028 diff = 264.600098'
});
data_peak.push({
lat: 4.3494222213e+01,
lng: 1.4277822222e+02,
cert : true,
content:'Name = JA8/TC-019(JA8/TC-019) peak = 1667.900024 pos = 43.4942,142.7782 diff = 184.099976'
});
data_saddle.push({
lat: 4.3500444435e+01,
lng: 1.4279644444e+02,
content:'Saddle = 1483.800049 pos = 43.5004,142.7964 diff = 184.099976'
});
data_peak.push({
lat: 4.3510222213e+01,
lng: 1.4281066667e+02,
cert : true,
content:'Name = JA8/TC-017(JA8/TC-017) peak = 1706.300049 pos = 43.5102,142.8107 diff = 197.700073'
});
data_saddle.push({
lat: 4.3516888880e+01,
lng: 1.4281488889e+02,
content:'Saddle = 1508.599976 pos = 43.5169,142.8149 diff = 197.700073'
});
data_peak.push({
lat: 4.3527111102e+01,
lng: 1.4284877778e+02,
cert : true,
content:'Name = Tomuraushiyama(JA8/TC-001) peak = 2140.500000 pos = 43.5271,142.8488 diff = 438.500000'
});
data_saddle.push({
lat: 4.3575999992e+01,
lng: 1.4289100000e+02,
content:'Saddle = 1702.000000 pos = 43.5760,142.8910 diff = 438.500000'
});
data_peak.push({
lat: 4.3565444436e+01,
lng: 1.4286133333e+02,
cert : true,
content:'Name = JA8/KK-009(JA8/KK-009) peak = 1952.500000 pos = 43.5654,142.8613 diff = 161.599976'
});
data_saddle.push({
lat: 4.3555222214e+01,
lng: 1.4285622222e+02,
content:'Saddle = 1790.900024 pos = 43.5552,142.8562 diff = 161.599976'
});
data_peak.push({
lat: 4.3591111103e+01,
lng: 1.4289444444e+02,
cert : true,
content:'Name = Chuubetsudake(JA8/KK-008) peak = 1962.300049 pos = 43.5911,142.8944 diff = 248.400024'
});
data_saddle.push({
lat: 4.3628666659e+01,
lng: 1.4290188889e+02,
content:'Saddle = 1713.900024 pos = 43.6287,142.9019 diff = 248.400024'
});
data_peak.push({
lat: 4.3698333326e+01,
lng: 1.4289700000e+02,
cert : true,
content:'Name = JA8/KK-004(JA8/KK-004) peak = 2124.300049 pos = 43.6983,142.8970 diff = 162.200073'
});
data_saddle.push({
lat: 4.3695999993e+01,
lng: 1.4289044444e+02,
content:'Saddle = 1962.099976 pos = 43.6960,142.8904 diff = 162.200073'
});
data_peak.push({
lat: 4.3692777770e+01,
lng: 1.4287977778e+02,
cert : true,
content:'Name = Taisetsuzan (Hokuchindake)(JA8/KK-002) peak = 2242.899902 pos = 43.6928,142.8798 diff = 201.099854'
});
data_saddle.push({
lat: 4.3681777770e+01,
lng: 1.4287400000e+02,
content:'Saddle = 2041.800049 pos = 43.6818,142.8740 diff = 201.099854'
});
data_peak.push({
lat: 4.3661222215e+01,
lng: 1.4290588889e+02,
cert : true,
content:'Name = Taisetsuzan (Hakuundake)(JA8/KK-003) peak = 2227.899902 pos = 43.6612,142.9059 diff = 169.500000'
});
data_saddle.push({
lat: 4.3673222215e+01,
lng: 1.4290088889e+02,
content:'Saddle = 2058.399902 pos = 43.6732,142.9009 diff = 169.500000'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:44.6667,
       south:42,
       east:144,
       west:142}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
