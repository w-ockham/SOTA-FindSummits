function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.3086000000e+01,
lng: 1.3124900000e+02,
cert : true,
content:'Name = Kujyuurenzan (Nakadake)(JA6/OT-001) peak = 1790.500000 pos = 33.0860,131.2490 diff = 1790.500000'
});
data_saddle.push({
lat: 3.3125777778e+01,
lng: 1.3013022222e+02,
content:'Saddle = 0.000000 pos = 33.1258,130.1302 diff = 1790.500000'
});
data_peak.push({
lat: 3.2158666667e+01,
lng: 1.3015755556e+02,
cert : true,
content:'Name = JA6/KG-101(JA6/KG-101) peak = 402.500000 pos = 32.1587,130.1576 diff = 402.500000'
});
data_saddle.push({
lat: 3.2089555556e+01,
lng: 1.3015744444e+02,
content:'Saddle = 0.000000 pos = 32.0896,130.1574 diff = 402.500000'
});
data_peak.push({
lat: 3.2116222223e+01,
lng: 1.3016266667e+02,
cert : false,
content:' Peak = 290.700012 pos = 32.1162,130.1627 diff = 192.300018'
});
data_saddle.push({
lat: 3.2129555556e+01,
lng: 1.3016622222e+02,
content:'Saddle = 98.400002 pos = 32.1296,130.1662 diff = 192.300018'
});
data_peak.push({
lat: 3.2267666667e+01,
lng: 1.3014022222e+02,
cert : false,
content:' Peak = 261.100006 pos = 32.2677,130.1402 diff = 261.100006'
});
data_saddle.push({
lat: 3.2262333334e+01,
lng: 1.3013677778e+02,
content:'Saddle = 0.000000 pos = 32.2623,130.1368 diff = 261.100006'
});
data_peak.push({
lat: 3.2276000001e+01,
lng: 1.3023633333e+02,
cert : true,
content:'Name = JA6/KG-105(JA6/KG-105) peak = 392.399994 pos = 32.2760,130.2363 diff = 392.399994'
});
data_saddle.push({
lat: 3.2250111112e+01,
lng: 1.3021488889e+02,
content:'Saddle = 0.000000 pos = 32.2501,130.2149 diff = 392.399994'
});
data_peak.push({
lat: 3.2351111112e+01,
lng: 1.3033233333e+02,
cert : false,
content:' Peak = 180.800003 pos = 32.3511,130.3323 diff = 180.800003'
});
data_saddle.push({
lat: 3.2339222223e+01,
lng: 1.3031055556e+02,
content:'Saddle = 0.000000 pos = 32.3392,130.3106 diff = 180.800003'
});
data_peak.push({
lat: 3.2364000001e+01,
lng: 1.3035044444e+02,
cert : false,
content:' Peak = 193.100006 pos = 32.3640,130.3504 diff = 193.100006'
});
data_saddle.push({
lat: 3.2360666667e+01,
lng: 1.3034955556e+02,
content:'Saddle = 0.000000 pos = 32.3607,130.3496 diff = 193.100006'
});
data_peak.push({
lat: 3.2375111112e+01,
lng: 1.3032166667e+02,
cert : false,
content:' Peak = 151.899994 pos = 32.3751,130.3217 diff = 151.899994'
});
data_saddle.push({
lat: 3.2370111112e+01,
lng: 1.3032333333e+02,
content:'Saddle = 0.000000 pos = 32.3701,130.3233 diff = 151.899994'
});
data_peak.push({
lat: 3.2386666667e+01,
lng: 1.3041866667e+02,
cert : false,
content:' Peak = 230.399994 pos = 32.3867,130.4187 diff = 230.399994'
});
data_saddle.push({
lat: 3.2367111112e+01,
lng: 1.3041955556e+02,
content:'Saddle = 0.000000 pos = 32.3671,130.4196 diff = 230.399994'
});
data_peak.push({
lat: 3.2374666667e+01,
lng: 1.3042244444e+02,
cert : false,
content:' Peak = 193.699997 pos = 32.3747,130.4224 diff = 172.699997'
});
data_saddle.push({
lat: 3.2380111112e+01,
lng: 1.3042322222e+02,
content:'Saddle = 21.000000 pos = 32.3801,130.4232 diff = 172.699997'
});
data_peak.push({
lat: 3.2326222223e+01,
lng: 1.3034855556e+02,
cert : true,
content:'Name = JA6/KM-069(JA6/KM-069) peak = 441.399994 pos = 32.3262,130.3486 diff = 441.399994'
});
data_saddle.push({
lat: 3.2303555556e+01,
lng: 1.3030233333e+02,
content:'Saddle = 0.000000 pos = 32.3036,130.3023 diff = 441.399994'
});
data_peak.push({
lat: 3.2436333334e+01,
lng: 1.3008388889e+02,
cert : true,
content:'Name = JA6/KM-056(JA6/KM-056) peak = 535.799988 pos = 32.4363,130.0839 diff = 535.799988'
});
data_saddle.push({
lat: 3.2188555556e+01,
lng: 1.3002288889e+02,
content:'Saddle = 0.000000 pos = 32.1886,130.0229 diff = 535.799988'
});
data_peak.push({
lat: 3.2293000001e+01,
lng: 1.3015433333e+02,
cert : false,
content:' Peak = 253.399994 pos = 32.2930,130.1543 diff = 246.000000'
});
data_saddle.push({
lat: 3.2295333334e+01,
lng: 1.3013666667e+02,
content:'Saddle = 7.400000 pos = 32.2953,130.1367 diff = 246.000000'
});
data_peak.push({
lat: 3.2213777778e+01,
lng: 1.3001988889e+02,
cert : false,
content:' Peak = 227.300003 pos = 32.2138,130.0199 diff = 200.400009'
});
data_saddle.push({
lat: 3.2220111112e+01,
lng: 1.3002400000e+02,
content:'Saddle = 26.900000 pos = 32.2201,130.0240 diff = 200.400009'
});
data_peak.push({
lat: 3.2341222223e+01,
lng: 1.3019100000e+02,
cert : true,
content:'Name = JA6/KM-086(JA6/KM-086) peak = 332.700012 pos = 32.3412,130.1910 diff = 294.000000'
});
data_saddle.push({
lat: 3.2350666667e+01,
lng: 1.3018344444e+02,
content:'Saddle = 38.700001 pos = 32.3507,130.1834 diff = 294.000000'
});
data_peak.push({
lat: 3.2376555556e+01,
lng: 1.3020711111e+02,
cert : false,
content:' Peak = 244.399994 pos = 32.3766,130.2071 diff = 167.699997'
});
data_saddle.push({
lat: 3.2362333334e+01,
lng: 1.3020466667e+02,
content:'Saddle = 76.699997 pos = 32.3623,130.2047 diff = 167.699997'
});
data_peak.push({
lat: 3.2285222223e+01,
lng: 1.3000877778e+02,
cert : false,
content:' Peak = 330.799988 pos = 32.2852,130.0088 diff = 291.299988'
});
data_saddle.push({
lat: 3.2255444445e+01,
lng: 1.3002511111e+02,
content:'Saddle = 39.500000 pos = 32.2554,130.0251 diff = 291.299988'
});
data_peak.push({
lat: 3.2266111112e+01,
lng: 1.3000000000e+02,
cert : false,
content:' Peak = 241.300003 pos = 32.2661,130.0000 diff = 187.600006'
});
data_saddle.push({
lat: 3.2272000001e+01,
lng: 1.3000022222e+02,
content:'Saddle = 53.700001 pos = 32.2720,130.0002 diff = 187.600006'
});
data_peak.push({
lat: 3.2326888890e+01,
lng: 1.3008577778e+02,
cert : false,
content:' Peak = 265.899994 pos = 32.3269,130.0858 diff = 199.000000'
});
data_saddle.push({
lat: 3.2323555556e+01,
lng: 1.3009822222e+02,
content:'Saddle = 66.900002 pos = 32.3236,130.0982 diff = 199.000000'
});
data_peak.push({
lat: 3.2234222223e+01,
lng: 1.3002777778e+02,
cert : true,
content:'Name = JA6/KM-075(JA6/KM-075) peak = 401.399994 pos = 32.2342,130.0278 diff = 303.500000'
});
data_saddle.push({
lat: 3.2257444445e+01,
lng: 1.3006944444e+02,
content:'Saddle = 97.900002 pos = 32.2574,130.0694 diff = 303.500000'
});
data_peak.push({
lat: 3.2259666667e+01,
lng: 1.3004200000e+02,
cert : true,
content:'Name = JA6/KM-084(JA6/KM-084) peak = 340.500000 pos = 32.2597,130.0420 diff = 222.000000'
});
data_saddle.push({
lat: 3.2243222223e+01,
lng: 1.3004255556e+02,
content:'Saddle = 118.500000 pos = 32.2432,130.0426 diff = 222.000000'
});
data_peak.push({
lat: 3.2265222223e+01,
lng: 1.3005266667e+02,
cert : false,
content:' Peak = 294.700012 pos = 32.2652,130.0527 diff = 152.300018'
});
data_saddle.push({
lat: 3.2261000001e+01,
lng: 1.3004822222e+02,
content:'Saddle = 142.399994 pos = 32.2610,130.0482 diff = 152.300018'
});
data_peak.push({
lat: 3.2244111112e+01,
lng: 1.3006811111e+02,
cert : false,
content:' Peak = 289.200012 pos = 32.2441,130.0681 diff = 167.100006'
});
data_saddle.push({
lat: 3.2229000001e+01,
lng: 1.3004211111e+02,
content:'Saddle = 122.099998 pos = 32.2290,130.0421 diff = 167.100006'
});
data_peak.push({
lat: 3.2374333334e+01,
lng: 1.3015311111e+02,
cert : true,
content:'Name = JA6/KM-087(JA6/KM-087) peak = 330.299988 pos = 32.3743,130.1531 diff = 215.999985'
});
data_saddle.push({
lat: 3.2358111112e+01,
lng: 1.3014888889e+02,
content:'Saddle = 114.300003 pos = 32.3581,130.1489 diff = 215.999985'
});
data_peak.push({
lat: 3.2296333334e+01,
lng: 1.3011666667e+02,
cert : true,
content:'Name = JA6/KM-070(JA6/KM-070) peak = 430.000000 pos = 32.2963,130.1167 diff = 312.899994'
});
data_saddle.push({
lat: 3.2349222223e+01,
lng: 1.3014077778e+02,
content:'Saddle = 117.099998 pos = 32.3492,130.1408 diff = 312.899994'
});
data_peak.push({
lat: 3.2266666667e+01,
lng: 1.3008855556e+02,
cert : true,
content:'Name = JA6/KM-074(JA6/KM-074) peak = 401.700012 pos = 32.2667,130.0886 diff = 238.700012'
});
data_saddle.push({
lat: 3.2273555556e+01,
lng: 1.3010122222e+02,
content:'Saddle = 163.000000 pos = 32.2736,130.1012 diff = 238.700012'
});
data_peak.push({
lat: 3.2447666667e+01,
lng: 1.3015988889e+02,
cert : true,
content:'Name = JA6/KM-081(JA6/KM-081) peak = 381.399994 pos = 32.4477,130.1599 diff = 219.599991'
});
data_saddle.push({
lat: 3.2434555556e+01,
lng: 1.3013255556e+02,
content:'Saddle = 161.800003 pos = 32.4346,130.1326 diff = 219.599991'
});
data_peak.push({
lat: 3.2373111112e+01,
lng: 1.3013933333e+02,
cert : true,
content:'Name = JA6/KM-083(JA6/KM-083) peak = 341.799988 pos = 32.3731,130.1393 diff = 171.699982'
});
data_saddle.push({
lat: 3.2361555556e+01,
lng: 1.3012922222e+02,
content:'Saddle = 170.100006 pos = 32.3616,130.1292 diff = 171.699982'
});
data_peak.push({
lat: 3.2356444445e+01,
lng: 1.3010922222e+02,
cert : true,
content:'Name = JA6/KM-063(JA6/KM-063) peak = 488.700012 pos = 32.3564,130.1092 diff = 292.000000'
});
data_saddle.push({
lat: 3.2378111112e+01,
lng: 1.3010333333e+02,
content:'Saddle = 196.699997 pos = 32.3781,130.1033 diff = 292.000000'
});
data_peak.push({
lat: 3.2342777778e+01,
lng: 1.3005144444e+02,
cert : false,
content:' Peak = 400.600006 pos = 32.3428,130.0514 diff = 177.600006'
});
data_saddle.push({
lat: 3.2349555556e+01,
lng: 1.3004366667e+02,
content:'Saddle = 223.000000 pos = 32.3496,130.0437 diff = 177.600006'
});
data_peak.push({
lat: 3.2360888890e+01,
lng: 1.3007188889e+02,
cert : false,
content:' Peak = 392.600006 pos = 32.3609,130.0719 diff = 164.300003'
});
data_saddle.push({
lat: 3.2369444445e+01,
lng: 1.3006400000e+02,
content:'Saddle = 228.300003 pos = 32.3694,130.0640 diff = 164.300003'
});
data_peak.push({
lat: 3.2421111112e+01,
lng: 1.3014477778e+02,
cert : false,
content:' Peak = 502.399994 pos = 32.4211,130.1448 diff = 264.200012'
});
data_saddle.push({
lat: 3.2412777778e+01,
lng: 1.3011922222e+02,
content:'Saddle = 238.199997 pos = 32.4128,130.1192 diff = 264.200012'
});
data_peak.push({
lat: 3.2399222223e+01,
lng: 1.3009377778e+02,
cert : true,
content:'Name = Kadoyama(JA6/KM-057) peak = 522.900024 pos = 32.3992,130.0938 diff = 229.500031'
});
data_saddle.push({
lat: 3.2424666667e+01,
lng: 1.3010066667e+02,
content:'Saddle = 293.399994 pos = 32.4247,130.1007 diff = 229.500031'
});
data_peak.push({
lat: 3.2399000001e+01,
lng: 1.3007377778e+02,
cert : false,
content:' Peak = 461.299988 pos = 32.3990,130.0738 diff = 164.199982'
});
data_saddle.push({
lat: 3.2397222223e+01,
lng: 1.3008244444e+02,
content:'Saddle = 297.100006 pos = 32.3972,130.0824 diff = 164.199982'
});
data_peak.push({
lat: 3.2376888890e+01,
lng: 1.3005400000e+02,
cert : false,
content:' Peak = 451.100006 pos = 32.3769,130.0540 diff = 153.600006'
});
data_saddle.push({
lat: 3.2382888890e+01,
lng: 1.3006888889e+02,
content:'Saddle = 297.500000 pos = 32.3829,130.0689 diff = 153.600006'
});
data_peak.push({
lat: 3.2384333334e+01,
lng: 1.3009233333e+02,
cert : true,
content:'Name = JA6/KM-065(JA6/KM-065) peak = 480.000000 pos = 32.3843,130.0923 diff = 178.200012'
});
data_saddle.push({
lat: 3.2393333334e+01,
lng: 1.3009511111e+02,
content:'Saddle = 301.799988 pos = 32.3933,130.0951 diff = 178.200012'
});
data_peak.push({
lat: 3.2565111112e+01,
lng: 1.3047822222e+02,
cert : false,
content:' Peak = 161.699997 pos = 32.5651,130.4782 diff = 161.699997'
});
data_saddle.push({
lat: 3.2539444445e+01,
lng: 1.3046422222e+02,
content:'Saddle = 0.000000 pos = 32.5394,130.4642 diff = 161.699997'
});
data_peak.push({
lat: 3.2610888889e+01,
lng: 1.3045277778e+02,
cert : false,
content:' Peak = 227.899994 pos = 32.6109,130.4528 diff = 227.899994'
});
data_saddle.push({
lat: 3.2545666667e+01,
lng: 1.3042277778e+02,
content:'Saddle = 0.000000 pos = 32.5457,130.4228 diff = 227.899994'
});
data_peak.push({
lat: 3.2622222223e+01,
lng: 1.3044100000e+02,
cert : false,
content:' Peak = 224.199997 pos = 32.6222,130.4410 diff = 207.099991'
});
data_saddle.push({
lat: 3.2614333334e+01,
lng: 1.3044388889e+02,
content:'Saddle = 17.100000 pos = 32.6143,130.4439 diff = 207.099991'
});
data_peak.push({
lat: 3.2427888890e+01,
lng: 1.3032688889e+02,
cert : true,
content:'Name = Kuradake(JA6/KM-044) peak = 681.500000 pos = 32.4279,130.3269 diff = 681.500000'
});
data_saddle.push({
lat: 3.2376888890e+01,
lng: 1.3035611111e+02,
content:'Saddle = 0.000000 pos = 32.3769,130.3561 diff = 681.500000'
});
data_peak.push({
lat: 3.2502888889e+01,
lng: 1.3041455556e+02,
cert : false,
content:' Peak = 232.300003 pos = 32.5029,130.4146 diff = 194.000000'
});
data_saddle.push({
lat: 3.2496333334e+01,
lng: 1.3041988889e+02,
content:'Saddle = 38.299999 pos = 32.4963,130.4199 diff = 194.000000'
});
data_peak.push({
lat: 3.2478888889e+01,
lng: 1.3040655556e+02,
cert : true,
content:'Name = JA6/KM-076(JA6/KM-076) peak = 397.899994 pos = 32.4789,130.4066 diff = 274.299988'
});
data_saddle.push({
lat: 3.2449222223e+01,
lng: 1.3039911111e+02,
content:'Saddle = 123.599998 pos = 32.4492,130.3991 diff = 274.299988'
});
data_peak.push({
lat: 3.2466000001e+01,
lng: 1.3042044444e+02,
cert : true,
content:'Name = JA6/KM-082(JA6/KM-082) peak = 370.700012 pos = 32.4660,130.4204 diff = 231.900009'
});
data_saddle.push({
lat: 3.2475000001e+01,
lng: 1.3041044444e+02,
content:'Saddle = 138.800003 pos = 32.4750,130.4104 diff = 231.900009'
});
data_peak.push({
lat: 3.2432000001e+01,
lng: 1.3038144444e+02,
cert : true,
content:'Name = JA6/KM-060(JA6/KM-060) peak = 500.600006 pos = 32.4320,130.3814 diff = 327.799988'
});
data_saddle.push({
lat: 3.2442444445e+01,
lng: 1.3037477778e+02,
content:'Saddle = 172.800003 pos = 32.4424,130.3748 diff = 327.799988'
});
data_peak.push({
lat: 3.2402222223e+01,
lng: 1.3037777778e+02,
cert : false,
content:' Peak = 476.299988 pos = 32.4022,130.3778 diff = 179.199982'
});
data_saddle.push({
lat: 3.2415111112e+01,
lng: 1.3037833333e+02,
content:'Saddle = 297.100006 pos = 32.4151,130.3783 diff = 179.199982'
});
data_peak.push({
lat: 3.2451000001e+01,
lng: 1.3027733333e+02,
cert : true,
content:'Name = JA6/KM-062(JA6/KM-062) peak = 495.000000 pos = 32.4510,130.2773 diff = 314.100006'
});
data_saddle.push({
lat: 3.2454555556e+01,
lng: 1.3030200000e+02,
content:'Saddle = 180.899994 pos = 32.4546,130.3020 diff = 314.100006'
});
data_peak.push({
lat: 3.2442555556e+01,
lng: 1.3037000000e+02,
cert : false,
content:' Peak = 333.000000 pos = 32.4426,130.3700 diff = 150.199997'
});
data_saddle.push({
lat: 3.2442666667e+01,
lng: 1.3035677778e+02,
content:'Saddle = 182.800003 pos = 32.4427,130.3568 diff = 150.199997'
});
data_peak.push({
lat: 3.2480777778e+01,
lng: 1.3034022222e+02,
cert : true,
content:'Name = JA6/KM-051(JA6/KM-051) peak = 590.000000 pos = 32.4808,130.3402 diff = 382.000000'
});
data_saddle.push({
lat: 3.2456444445e+01,
lng: 1.3033944444e+02,
content:'Saddle = 208.000000 pos = 32.4564,130.3394 diff = 382.000000'
});
data_peak.push({
lat: 3.2454888890e+01,
lng: 1.3031977778e+02,
cert : false,
content:' Peak = 440.899994 pos = 32.4549,130.3198 diff = 159.199982'
});
data_saddle.push({
lat: 3.2463888890e+01,
lng: 1.3033222222e+02,
content:'Saddle = 281.700012 pos = 32.4639,130.3322 diff = 159.199982'
});
data_peak.push({
lat: 3.2653555556e+01,
lng: 1.3057744444e+02,
cert : true,
content:'Name = JA6/KM-067(JA6/KM-067) peak = 477.000000 pos = 32.6536,130.5774 diff = 472.200012'
});
data_saddle.push({
lat: 3.2654111112e+01,
lng: 1.3066866667e+02,
content:'Saddle = 4.800000 pos = 32.6541,130.6687 diff = 472.200012'
});
data_peak.push({
lat: 3.2627777778e+01,
lng: 1.3046655556e+02,
cert : true,
content:'Name = JA6/KM-073(JA6/KM-073) peak = 401.000000 pos = 32.6278,130.4666 diff = 294.200012'
});
data_saddle.push({
lat: 3.2630222223e+01,
lng: 1.3048344444e+02,
content:'Saddle = 106.800003 pos = 32.6302,130.4834 diff = 294.200012'
});
data_peak.push({
lat: 3.3172111111e+01,
lng: 1.3007666667e+02,
cert : true,
content:'Name = JA6/SG-027(JA6/SG-027) peak = 371.100006 pos = 33.1721,130.0767 diff = 355.800018'
});
data_saddle.push({
lat: 3.3153000000e+01,
lng: 1.3006488889e+02,
content:'Saddle = 15.300000 pos = 33.1530,130.0649 diff = 355.800018'
});
data_peak.push({
lat: 3.3144000000e+01,
lng: 1.3008733333e+02,
cert : false,
content:' Peak = 340.200012 pos = 33.1440,130.0873 diff = 152.200012'
});
data_saddle.push({
lat: 3.3164111111e+01,
lng: 1.3007922222e+02,
content:'Saddle = 188.000000 pos = 33.1641,130.0792 diff = 152.200012'
});
data_peak.push({
lat: 3.2761333334e+01,
lng: 1.3029877778e+02,
cert : true,
content:'Name = Unzendake (Heiseishinzan)(JA6/NS-001) peak = 1482.199951 pos = 32.7613,130.2988 diff = 1465.000000'
});
data_saddle.push({
lat: 3.2838222223e+01,
lng: 1.3003366667e+02,
content:'Saddle = 17.200001 pos = 32.8382,130.0337 diff = 1465.000000'
});
data_peak.push({
lat: 3.2798666667e+01,
lng: 1.3001811111e+02,
cert : false,
content:' Peak = 295.200012 pos = 32.7987,130.0181 diff = 266.500000'
});
data_saddle.push({
lat: 3.2801111112e+01,
lng: 1.3013177778e+02,
content:'Saddle = 28.700001 pos = 32.8011,130.1318 diff = 266.500000'
});
data_peak.push({
lat: 3.2816111112e+01,
lng: 1.3010355556e+02,
cert : true,
content:'Name = JA6/NS-070(JA6/NS-070) peak = 281.000000 pos = 32.8161,130.1036 diff = 223.600006'
});
data_saddle.push({
lat: 3.2806111112e+01,
lng: 1.3008777778e+02,
content:'Saddle = 57.400002 pos = 32.8061,130.0878 diff = 223.600006'
});
data_peak.push({
lat: 3.2785444445e+01,
lng: 1.3000233333e+02,
cert : false,
content:' Peak = 293.000000 pos = 32.7854,130.0023 diff = 205.600006'
});
data_saddle.push({
lat: 3.2789000000e+01,
lng: 1.3000411111e+02,
content:'Saddle = 87.400002 pos = 32.7890,130.0041 diff = 205.600006'
});
data_peak.push({
lat: 3.2775888889e+01,
lng: 1.3000355556e+02,
cert : false,
content:' Peak = 278.299988 pos = 32.7759,130.0036 diff = 171.099991'
});
data_saddle.push({
lat: 3.2780777778e+01,
lng: 1.3000266667e+02,
content:'Saddle = 107.199997 pos = 32.7808,130.0027 diff = 171.099991'
});
data_peak.push({
lat: 3.2802222223e+01,
lng: 1.3000255556e+02,
cert : false,
content:' Peak = 293.899994 pos = 32.8022,130.0026 diff = 156.299988'
});
data_saddle.push({
lat: 3.2799777778e+01,
lng: 1.3001355556e+02,
content:'Saddle = 137.600006 pos = 32.7998,130.0136 diff = 156.299988'
});
data_peak.push({
lat: 3.2627222223e+01,
lng: 1.3017933333e+02,
cert : true,
content:'Name = JA6/NS-069(JA6/NS-069) peak = 292.899994 pos = 32.6272,130.1793 diff = 231.299988'
});
data_saddle.push({
lat: 3.2627444445e+01,
lng: 1.3019155556e+02,
content:'Saddle = 61.599998 pos = 32.6274,130.1916 diff = 231.299988'
});
data_peak.push({
lat: 3.2641222223e+01,
lng: 1.3020911111e+02,
cert : true,
content:'Name = JA6/NS-031(JA6/NS-031) peak = 403.299988 pos = 32.6412,130.2091 diff = 305.500000'
});
data_saddle.push({
lat: 3.2652888889e+01,
lng: 1.3019844444e+02,
content:'Saddle = 97.800003 pos = 32.6529,130.1984 diff = 305.500000'
});
data_peak.push({
lat: 3.2769777778e+01,
lng: 1.3019955556e+02,
cert : true,
content:'Name = JA6/NS-036(JA6/NS-036) peak = 391.799988 pos = 32.7698,130.1996 diff = 235.499985'
});
data_saddle.push({
lat: 3.2765444445e+01,
lng: 1.3021400000e+02,
content:'Saddle = 156.300003 pos = 32.7654,130.2140 diff = 235.499985'
});
data_peak.push({
lat: 3.2771777778e+01,
lng: 1.3033700000e+02,
cert : true,
content:'Name = JA6/NS-007(JA6/NS-007) peak = 817.900024 pos = 32.7718,130.3370 diff = 300.800049'
});
data_saddle.push({
lat: 3.2764666667e+01,
lng: 1.3033266667e+02,
content:'Saddle = 517.099976 pos = 32.7647,130.3327 diff = 300.800049'
});
data_peak.push({
lat: 3.2791111112e+01,
lng: 1.3025277778e+02,
cert : true,
content:'Name = JA6/NS-006(JA6/NS-006) peak = 864.500000 pos = 32.7911,130.2528 diff = 232.599976'
});
data_saddle.push({
lat: 3.2785222223e+01,
lng: 1.3027222222e+02,
content:'Saddle = 631.900024 pos = 32.7852,130.2722 diff = 232.599976'
});
data_peak.push({
lat: 3.2788111112e+01,
lng: 1.3027188889e+02,
cert : false,
content:' Peak = 820.700012 pos = 32.7881,130.2719 diff = 173.299988'
});
data_saddle.push({
lat: 3.2788000000e+01,
lng: 1.3026788889e+02,
content:'Saddle = 647.400024 pos = 32.7880,130.2679 diff = 173.299988'
});
data_peak.push({
lat: 3.2737222223e+01,
lng: 1.3025111111e+02,
cert : true,
content:'Name = JA6/NS-005(JA6/NS-005) peak = 878.400024 pos = 32.7372,130.2511 diff = 196.900024'
});
data_saddle.push({
lat: 3.2742333334e+01,
lng: 1.3025800000e+02,
content:'Saddle = 681.500000 pos = 32.7423,130.2580 diff = 196.900024'
});
data_peak.push({
lat: 3.2717777778e+01,
lng: 1.3026988889e+02,
cert : false,
content:' Peak = 880.500000 pos = 32.7178,130.2699 diff = 152.500000'
});
data_saddle.push({
lat: 3.2729222223e+01,
lng: 1.3026944444e+02,
content:'Saddle = 728.000000 pos = 32.7292,130.2694 diff = 152.500000'
});
data_peak.push({
lat: 3.2739222223e+01,
lng: 1.3027122222e+02,
cert : true,
content:'Name = JA6/NS-004(JA6/NS-004) peak = 971.299988 pos = 32.7392,130.2712 diff = 214.099976'
});
data_saddle.push({
lat: 3.2740888889e+01,
lng: 1.3027511111e+02,
content:'Saddle = 757.200012 pos = 32.7409,130.2751 diff = 214.099976'
});
data_peak.push({
lat: 3.2775444445e+01,
lng: 1.3026066667e+02,
cert : true,
content:'Name = JA6/NS-002(JA6/NS-002) peak = 1062.500000 pos = 32.7754,130.2607 diff = 200.400024'
});
data_saddle.push({
lat: 3.2764666667e+01,
lng: 1.3027277778e+02,
content:'Saddle = 862.099976 pos = 32.7647,130.2728 diff = 200.400024'
});
data_peak.push({
lat: 3.2987555556e+01,
lng: 1.3007622222e+02,
cert : true,
content:'Name = Taradake (Kyougadake)(JA6/SG-001) peak = 1074.300049 pos = 32.9876,130.0762 diff = 1054.000000'
});
data_saddle.push({
lat: 3.3158222223e+01,
lng: 1.3000000000e+02,
content:'Saddle = 20.299999 pos = 33.1582,130.0000 diff = 1054.000000'
});
data_peak.push({
lat: 3.3148666667e+01,
lng: 1.3001600000e+02,
cert : true,
content:'Name = JA6/SG-031(JA6/SG-031) peak = 332.000000 pos = 33.1487,130.0160 diff = 302.899994'
});
data_saddle.push({
lat: 3.3128555556e+01,
lng: 1.3000011111e+02,
content:'Saddle = 29.100000 pos = 33.1286,130.0001 diff = 302.899994'
});
data_peak.push({
lat: 3.2875333334e+01,
lng: 1.3000955556e+02,
cert : false,
content:' Peak = 245.199997 pos = 32.8753,130.0096 diff = 165.699997'
});
data_saddle.push({
lat: 3.2884111112e+01,
lng: 1.3001066667e+02,
content:'Saddle = 79.500000 pos = 32.8841,130.0107 diff = 165.699997'
});
data_peak.push({
lat: 3.3107333334e+01,
lng: 1.3003711111e+02,
cert : true,
content:'Name = JA6/SG-025(JA6/SG-025) peak = 402.100006 pos = 33.1073,130.0371 diff = 255.100006'
});
data_saddle.push({
lat: 3.3099888889e+01,
lng: 1.3003544444e+02,
content:'Saddle = 147.000000 pos = 33.0999,130.0354 diff = 255.100006'
});
data_peak.push({
lat: 3.3069333334e+01,
lng: 1.3004977778e+02,
cert : true,
content:'Name = JA6/SG-019(JA6/SG-019) peak = 501.200012 pos = 33.0693,130.0498 diff = 218.900024'
});
data_saddle.push({
lat: 3.3059000000e+01,
lng: 1.3004722222e+02,
content:'Saddle = 282.299988 pos = 33.0590,130.0472 diff = 218.900024'
});
data_peak.push({
lat: 3.3058444445e+01,
lng: 1.3008122222e+02,
cert : false,
content:' Peak = 500.000000 pos = 33.0584,130.0812 diff = 198.500000'
});
data_saddle.push({
lat: 3.3049111111e+01,
lng: 1.3008077778e+02,
content:'Saddle = 301.500000 pos = 33.0491,130.0808 diff = 198.500000'
});
data_peak.push({
lat: 3.2958111112e+01,
lng: 1.3007644444e+02,
cert : true,
content:'Name = Taradake (Gokaharadake)(JA6/NS-003) peak = 1055.900024 pos = 32.9581,130.0764 diff = 278.400024'
});
data_saddle.push({
lat: 3.2983111112e+01,
lng: 1.3008100000e+02,
content:'Saddle = 777.500000 pos = 32.9831,130.0810 diff = 278.400024'
});
data_peak.push({
lat: 3.2975555556e+01,
lng: 1.3009244444e+02,
cert : false,
content:' Peak = 993.599976 pos = 32.9756,130.0924 diff = 151.099976'
});
data_saddle.push({
lat: 3.2968333334e+01,
lng: 1.3007955556e+02,
content:'Saddle = 842.500000 pos = 32.9683,130.0796 diff = 151.099976'
});
data_peak.push({
lat: 3.3184000000e+01,
lng: 1.3001944444e+02,
cert : false,
content:' Peak = 202.300003 pos = 33.1840,130.0194 diff = 180.600006'
});
data_saddle.push({
lat: 3.3184333334e+01,
lng: 1.3000000000e+02,
content:'Saddle = 21.700001 pos = 33.1843,130.0000 diff = 180.600006'
});
data_peak.push({
lat: 3.2109777779e+01,
lng: 1.3022600000e+02,
cert : true,
content:'Name = JA6/KG-104(JA6/KG-104) peak = 393.399994 pos = 32.1098,130.2260 diff = 366.199982'
});
data_saddle.push({
lat: 3.2074111112e+01,
lng: 1.3024188889e+02,
content:'Saddle = 27.200001 pos = 32.0741,130.2419 diff = 366.199982'
});
data_peak.push({
lat: 3.2218000001e+01,
lng: 1.3043266667e+02,
cert : false,
content:' Peak = 232.399994 pos = 32.2180,130.4327 diff = 194.000000'
});
data_saddle.push({
lat: 3.2210222223e+01,
lng: 1.3042755556e+02,
content:'Saddle = 38.400002 pos = 32.2102,130.4276 diff = 194.000000'
});
data_peak.push({
lat: 3.2217555556e+01,
lng: 1.3041966667e+02,
cert : false,
content:' Peak = 212.300003 pos = 32.2176,130.4197 diff = 166.000000'
});
data_saddle.push({
lat: 3.2217444445e+01,
lng: 1.3042711111e+02,
content:'Saddle = 46.299999 pos = 32.2174,130.4271 diff = 166.000000'
});
data_peak.push({
lat: 3.3436444445e+01,
lng: 1.3036866667e+02,
cert : true,
content:'Name = Sefurisan(JA6/FO-001) peak = 1052.699951 pos = 33.4364,130.3687 diff = 1012.599976'
});
data_saddle.push({
lat: 3.3484111111e+01,
lng: 1.3052866667e+02,
content:'Saddle = 40.099998 pos = 33.4841,130.5287 diff = 1012.599976'
});
data_peak.push({
lat: 3.3274666667e+01,
lng: 1.3010066667e+02,
cert : false,
content:' Peak = 212.000000 pos = 33.2747,130.1007 diff = 153.600006'
});
data_saddle.push({
lat: 3.3285222223e+01,
lng: 1.3010633333e+02,
content:'Saddle = 58.400002 pos = 33.2852,130.1063 diff = 153.600006'
});
data_peak.push({
lat: 3.3428000000e+01,
lng: 1.3002488889e+02,
cert : false,
content:' Peak = 285.500000 pos = 33.4280,130.0249 diff = 216.800003'
});
data_saddle.push({
lat: 3.3423222222e+01,
lng: 1.3003433333e+02,
content:'Saddle = 68.699997 pos = 33.4232,130.0343 diff = 216.800003'
});
data_peak.push({
lat: 3.3258444445e+01,
lng: 1.3015622222e+02,
cert : true,
content:'Name = JA6/SG-029(JA6/SG-029) peak = 365.399994 pos = 33.2584,130.1562 diff = 277.700012'
});
data_saddle.push({
lat: 3.3239111111e+01,
lng: 1.3014866667e+02,
content:'Saddle = 87.699997 pos = 33.2391,130.1487 diff = 277.700012'
});
data_peak.push({
lat: 3.3204888889e+01,
lng: 1.3000077778e+02,
cert : true,
content:'Name = JA6/SG-032(JA6/SG-032) peak = 324.200012 pos = 33.2049,130.0008 diff = 235.000015'
});
data_saddle.push({
lat: 3.3239111111e+01,
lng: 1.3001100000e+02,
content:'Saddle = 89.199997 pos = 33.2391,130.0110 diff = 235.000015'
});
data_peak.push({
lat: 3.3220777778e+01,
lng: 1.3000277778e+02,
cert : false,
content:' Peak = 304.000000 pos = 33.2208,130.0028 diff = 155.699997'
});
data_saddle.push({
lat: 3.3215444445e+01,
lng: 1.3000511111e+02,
content:'Saddle = 148.300003 pos = 33.2154,130.0051 diff = 155.699997'
});
data_peak.push({
lat: 3.3282444445e+01,
lng: 1.3002722222e+02,
cert : true,
content:'Name = JA6/SG-011(JA6/SG-011) peak = 761.599976 pos = 33.2824,130.0272 diff = 663.699951'
});
data_saddle.push({
lat: 3.3304888889e+01,
lng: 1.3007688889e+02,
content:'Saddle = 97.900002 pos = 33.3049,130.0769 diff = 663.699951'
});
data_peak.push({
lat: 3.3235777778e+01,
lng: 1.3010677778e+02,
cert : true,
content:'Name = JA6/SG-021(JA6/SG-021) peak = 481.399994 pos = 33.2358,130.1068 diff = 349.700012'
});
data_saddle.push({
lat: 3.3242555556e+01,
lng: 1.3006633333e+02,
content:'Saddle = 131.699997 pos = 33.2426,130.0663 diff = 349.700012'
});
data_peak.push({
lat: 3.3250222223e+01,
lng: 1.3003988889e+02,
cert : true,
content:'Name = JA6/SG-023(JA6/SG-023) peak = 442.200012 pos = 33.2502,130.0399 diff = 243.400009'
});
data_saddle.push({
lat: 3.3257222223e+01,
lng: 1.3002511111e+02,
content:'Saddle = 198.800003 pos = 33.2572,130.0251 diff = 243.400009'
});
data_peak.push({
lat: 3.3289444445e+01,
lng: 1.3005111111e+02,
cert : true,
content:'Name = JA6/SG-012(JA6/SG-012) peak = 693.599976 pos = 33.2894,130.0511 diff = 177.299988'
});
data_saddle.push({
lat: 3.3281000000e+01,
lng: 1.3003944444e+02,
content:'Saddle = 516.299988 pos = 33.2810,130.0394 diff = 177.299988'
});
data_peak.push({
lat: 3.3512111111e+01,
lng: 1.3036444444e+02,
cert : true,
content:'Name = JA6/FO-027(JA6/FO-027) peak = 596.099976 pos = 33.5121,130.3644 diff = 398.499969'
});
data_saddle.push({
lat: 3.3487111111e+01,
lng: 1.3038144444e+02,
content:'Saddle = 197.600006 pos = 33.4871,130.3814 diff = 398.499969'
});
data_peak.push({
lat: 3.3548222222e+01,
lng: 1.3026855556e+02,
cert : false,
content:' Peak = 421.000000 pos = 33.5482,130.2686 diff = 173.100006'
});
data_saddle.push({
lat: 3.3530222222e+01,
lng: 1.3028822222e+02,
content:'Saddle = 247.899994 pos = 33.5302,130.2882 diff = 173.100006'
});
data_peak.push({
lat: 3.3540111111e+01,
lng: 1.3028700000e+02,
cert : false,
content:' Peak = 414.600006 pos = 33.5401,130.2870 diff = 150.800018'
});
data_saddle.push({
lat: 3.3541555556e+01,
lng: 1.3028100000e+02,
content:'Saddle = 263.799988 pos = 33.5416,130.2810 diff = 150.800018'
});
data_peak.push({
lat: 3.3346555556e+01,
lng: 1.3030300000e+02,
cert : true,
content:'Name = JA6/SG-018(JA6/SG-018) peak = 500.200012 pos = 33.3466,130.3030 diff = 198.500000'
});
data_saddle.push({
lat: 3.3353444445e+01,
lng: 1.3030655556e+02,
content:'Saddle = 301.700012 pos = 33.3534,130.3066 diff = 198.500000'
});
data_peak.push({
lat: 3.3522555556e+01,
lng: 1.3028688889e+02,
cert : false,
content:' Peak = 474.700012 pos = 33.5226,130.2869 diff = 156.500000'
});
data_saddle.push({
lat: 3.3509444445e+01,
lng: 1.3028922222e+02,
content:'Saddle = 318.200012 pos = 33.5094,130.2892 diff = 156.500000'
});
data_peak.push({
lat: 3.3360777778e+01,
lng: 1.3032677778e+02,
cert : false,
content:' Peak = 512.200012 pos = 33.3608,130.3268 diff = 164.400024'
});
data_saddle.push({
lat: 3.3373777778e+01,
lng: 1.3031744444e+02,
content:'Saddle = 347.799988 pos = 33.3738,130.3174 diff = 164.400024'
});
data_peak.push({
lat: 3.3472444445e+01,
lng: 1.3006800000e+02,
cert : true,
content:'Name = JA6/SG-015(JA6/SG-015) peak = 532.099976 pos = 33.4724,130.0680 diff = 178.799988'
});
data_saddle.push({
lat: 3.3470000000e+01,
lng: 1.3007688889e+02,
content:'Saddle = 353.299988 pos = 33.4700,130.0769 diff = 178.799988'
});
data_peak.push({
lat: 3.3384000000e+01,
lng: 1.3022244444e+02,
cert : false,
content:' Peak = 530.599976 pos = 33.3840,130.2224 diff = 171.599976'
});
data_saddle.push({
lat: 3.3393888889e+01,
lng: 1.3022966667e+02,
content:'Saddle = 359.000000 pos = 33.3939,130.2297 diff = 171.599976'
});
data_peak.push({
lat: 3.3400111111e+01,
lng: 1.3023855556e+02,
cert : true,
content:'Name = JA6/SG-014(JA6/SG-014) peak = 581.099976 pos = 33.4001,130.2386 diff = 173.199982'
});
data_saddle.push({
lat: 3.3405000000e+01,
lng: 1.3024933333e+02,
content:'Saddle = 407.899994 pos = 33.4050,130.2493 diff = 173.199982'
});
data_peak.push({
lat: 3.3338888889e+01,
lng: 1.3014288889e+02,
cert : true,
content:'Name = Tenzan(JA6/SG-002) peak = 1042.400024 pos = 33.3389,130.1429 diff = 596.300049'
});
data_saddle.push({
lat: 3.3443333334e+01,
lng: 1.3016933333e+02,
content:'Saddle = 446.100006 pos = 33.4433,130.1693 diff = 596.300049'
});
data_peak.push({
lat: 3.3360777778e+01,
lng: 1.3007488889e+02,
cert : true,
content:'Name = JA6/SG-007(JA6/SG-007) peak = 896.500000 pos = 33.3608,130.0749 diff = 279.700012'
});
data_saddle.push({
lat: 3.3397111111e+01,
lng: 1.3009555556e+02,
content:'Saddle = 616.799988 pos = 33.3971,130.0956 diff = 279.700012'
});
data_peak.push({
lat: 3.3375888889e+01,
lng: 1.3012277778e+02,
cert : true,
content:'Name = JA6/SG-005(JA6/SG-005) peak = 901.900024 pos = 33.3759,130.1228 diff = 273.500000'
});
data_saddle.push({
lat: 3.3366111111e+01,
lng: 1.3014366667e+02,
content:'Saddle = 628.400024 pos = 33.3661,130.1437 diff = 273.500000'
});
data_peak.push({
lat: 3.3373666667e+01,
lng: 1.3015944444e+02,
cert : false,
content:' Peak = 790.700012 pos = 33.3737,130.1594 diff = 151.900024'
});
data_saddle.push({
lat: 3.3375111111e+01,
lng: 1.3015055556e+02,
content:'Saddle = 638.799988 pos = 33.3751,130.1506 diff = 151.900024'
});
data_peak.push({
lat: 3.3342000000e+01,
lng: 1.3019466667e+02,
cert : false,
content:' Peak = 841.200012 pos = 33.3420,130.1947 diff = 159.000000'
});
data_saddle.push({
lat: 3.3339111111e+01,
lng: 1.3017688889e+02,
content:'Saddle = 682.200012 pos = 33.3391,130.1769 diff = 159.000000'
});
data_peak.push({
lat: 3.3416777778e+01,
lng: 1.3044600000e+02,
cert : true,
content:'Name = JA6/SG-008(JA6/SG-008) peak = 847.000000 pos = 33.4168,130.4460 diff = 349.799988'
});
data_saddle.push({
lat: 3.3400777778e+01,
lng: 1.3041744444e+02,
content:'Saddle = 497.200012 pos = 33.4008,130.4174 diff = 349.799988'
});
data_peak.push({
lat: 3.3495444445e+01,
lng: 1.3027188889e+02,
cert : true,
content:'Name = JA6/FO-011(JA6/FO-011) peak = 733.500000 pos = 33.4954,130.2719 diff = 194.400024'
});
data_saddle.push({
lat: 3.3487777778e+01,
lng: 1.3026555556e+02,
content:'Saddle = 539.099976 pos = 33.4878,130.2656 diff = 194.400024'
});
data_peak.push({
lat: 3.3470000000e+01,
lng: 1.3009922222e+02,
cert : true,
content:'Name = Ukidake(JA6/SG-009) peak = 801.799988 pos = 33.4700,130.0992 diff = 259.799988'
});
data_saddle.push({
lat: 3.3476000000e+01,
lng: 1.3010944444e+02,
content:'Saddle = 542.000000 pos = 33.4760,130.1094 diff = 259.799988'
});
data_peak.push({
lat: 3.3465444445e+01,
lng: 1.3017588889e+02,
cert : true,
content:'Name = JA6/SG-006(JA6/SG-006) peak = 900.400024 pos = 33.4654,130.1759 diff = 340.000000'
});
data_saddle.push({
lat: 3.3481000000e+01,
lng: 1.3020044444e+02,
content:'Saddle = 560.400024 pos = 33.4810,130.2004 diff = 340.000000'
});
data_peak.push({
lat: 3.3474888889e+01,
lng: 1.3011588889e+02,
cert : false,
content:' Peak = 745.000000 pos = 33.4749,130.1159 diff = 158.700012'
});
data_saddle.push({
lat: 3.3470444445e+01,
lng: 1.3013855556e+02,
content:'Saddle = 586.299988 pos = 33.4704,130.1386 diff = 158.700012'
});
data_peak.push({
lat: 3.3470444445e+01,
lng: 1.3024955556e+02,
cert : true,
content:'Name = JA6/SG-003(JA6/SG-003) peak = 982.099976 pos = 33.4704,130.2496 diff = 394.199951'
});
data_saddle.push({
lat: 3.3474555556e+01,
lng: 1.3028155556e+02,
content:'Saddle = 587.900024 pos = 33.4746,130.2816 diff = 394.199951'
});
data_peak.push({
lat: 3.3463555556e+01,
lng: 1.3030577778e+02,
cert : true,
content:'Name = JA6/SG-004(JA6/SG-004) peak = 965.299988 pos = 33.4636,130.3058 diff = 207.500000'
});
data_saddle.push({
lat: 3.3445111111e+01,
lng: 1.3033677778e+02,
content:'Saddle = 757.799988 pos = 33.4451,130.3368 diff = 207.500000'
});
data_peak.push({
lat: 3.2688111112e+01,
lng: 1.3070877778e+02,
cert : true,
content:'Name = JA6/KM-089(JA6/KM-089) peak = 313.399994 pos = 32.6881,130.7088 diff = 266.100006'
});
data_saddle.push({
lat: 3.2677333334e+01,
lng: 1.3072577778e+02,
content:'Saddle = 47.299999 pos = 32.6773,130.7258 diff = 266.100006'
});
data_peak.push({
lat: 3.3679777778e+01,
lng: 1.3046822222e+02,
cert : true,
content:'Name = JA6/FO-046(JA6/FO-046) peak = 366.399994 pos = 33.6798,130.4682 diff = 317.100006'
});
data_saddle.push({
lat: 3.3677000000e+01,
lng: 1.3048511111e+02,
content:'Saddle = 49.299999 pos = 33.6770,130.4851 diff = 317.100006'
});
data_peak.push({
lat: 3.3748000000e+01,
lng: 1.3068111111e+02,
cert : true,
content:'Name = JA6/FO-050(JA6/FO-050) peak = 336.899994 pos = 33.7480,130.6811 diff = 287.500000'
});
data_saddle.push({
lat: 3.3741000000e+01,
lng: 1.3066433333e+02,
content:'Saddle = 49.400002 pos = 33.7410,130.6643 diff = 287.500000'
});
data_peak.push({
lat: 3.3721000000e+01,
lng: 1.3091377778e+02,
cert : false,
content:' Peak = 231.100006 pos = 33.7210,130.9138 diff = 177.500000'
});
data_saddle.push({
lat: 3.3720777778e+01,
lng: 1.3090822222e+02,
content:'Saddle = 53.599998 pos = 33.7208,130.9082 diff = 177.500000'
});
data_peak.push({
lat: 3.3810555556e+01,
lng: 1.3086733333e+02,
cert : false,
content:' Peak = 221.600006 pos = 33.8106,130.8673 diff = 162.900009'
});
data_saddle.push({
lat: 3.3802111111e+01,
lng: 1.3087377778e+02,
content:'Saddle = 58.700001 pos = 33.8021,130.8738 diff = 162.900009'
});
data_peak.push({
lat: 3.3560333334e+01,
lng: 1.3049633333e+02,
cert : false,
content:' Peak = 234.699997 pos = 33.5603,130.4963 diff = 172.500000'
});
data_saddle.push({
lat: 3.3557666667e+01,
lng: 1.3050333333e+02,
content:'Saddle = 62.200001 pos = 33.5577,130.5033 diff = 172.500000'
});
data_peak.push({
lat: 3.2984666667e+01,
lng: 1.3052733333e+02,
cert : true,
content:'Name = Tsutsugatake(JA6/KM-061) peak = 501.100006 pos = 32.9847,130.5273 diff = 435.200012'
});
data_saddle.push({
lat: 3.3009000000e+01,
lng: 1.3053722222e+02,
content:'Saddle = 65.900002 pos = 33.0090,130.5372 diff = 435.200012'
});
data_peak.push({
lat: 3.2274333334e+01,
lng: 1.3050744444e+02,
cert : false,
content:' Peak = 227.800003 pos = 32.2743,130.5074 diff = 160.100006'
});
data_saddle.push({
lat: 3.2264777778e+01,
lng: 1.3052477778e+02,
content:'Saddle = 67.699997 pos = 32.2648,130.5248 diff = 160.100006'
});
data_peak.push({
lat: 3.2844444445e+01,
lng: 1.3062222222e+02,
cert : true,
content:'Name = JA6/KM-043(JA6/KM-043) peak = 683.700012 pos = 32.8444,130.6222 diff = 613.299988'
});
data_saddle.push({
lat: 3.2897111112e+01,
lng: 1.3070911111e+02,
content:'Saddle = 70.400002 pos = 32.8971,130.7091 diff = 613.299988'
});
data_peak.push({
lat: 3.2945555556e+01,
lng: 1.3063722222e+02,
cert : true,
content:'Name = JA6/KM-078(JA6/KM-078) peak = 386.700012 pos = 32.9456,130.6372 diff = 305.900024'
});
data_saddle.push({
lat: 3.2881888889e+01,
lng: 1.3067688889e+02,
content:'Saddle = 80.800003 pos = 32.8819,130.6769 diff = 305.900024'
});
data_peak.push({
lat: 3.2975444445e+01,
lng: 1.3066566667e+02,
cert : true,
content:'Name = JA6/KM-090(JA6/KM-090) peak = 311.299988 pos = 32.9754,130.6657 diff = 225.899994'
});
data_saddle.push({
lat: 3.2950666667e+01,
lng: 1.3067366667e+02,
content:'Saddle = 85.400002 pos = 32.9507,130.6737 diff = 225.899994'
});
data_peak.push({
lat: 3.2935000000e+01,
lng: 1.3061644444e+02,
cert : true,
content:'Name = JA6/KM-080(JA6/KM-080) peak = 382.600006 pos = 32.9350,130.6164 diff = 191.200012'
});
data_saddle.push({
lat: 3.2938000000e+01,
lng: 1.3062344444e+02,
content:'Saddle = 191.399994 pos = 32.9380,130.6234 diff = 191.200012'
});
data_peak.push({
lat: 3.2788777778e+01,
lng: 1.3063022222e+02,
cert : true,
content:'Name = JA6/KM-092(JA6/KM-092) peak = 272.600006 pos = 32.7888,130.6302 diff = 169.500000'
});
data_saddle.push({
lat: 3.2795222223e+01,
lng: 1.3062755556e+02,
content:'Saddle = 103.099998 pos = 32.7952,130.6276 diff = 169.500000'
});
data_peak.push({
lat: 3.2814000000e+01,
lng: 1.3063888889e+02,
cert : true,
content:'Name = Kinbouzan(JA6/KM-045) peak = 663.900024 pos = 32.8140,130.6389 diff = 385.300018'
});
data_saddle.push({
lat: 3.2818555556e+01,
lng: 1.3065566667e+02,
content:'Saddle = 278.600006 pos = 32.8186,130.6557 diff = 385.300018'
});
data_peak.push({
lat: 3.2854888889e+01,
lng: 1.3063144444e+02,
cert : false,
content:' Peak = 681.000000 pos = 32.8549,130.6314 diff = 170.000000'
});
data_saddle.push({
lat: 3.2852444445e+01,
lng: 1.3062544444e+02,
content:'Saddle = 511.000000 pos = 32.8524,130.6254 diff = 170.000000'
});
data_peak.push({
lat: 3.2287000001e+01,
lng: 1.3048722222e+02,
cert : false,
content:' Peak = 232.899994 pos = 32.2870,130.4872 diff = 161.899994'
});
data_saddle.push({
lat: 3.2279777778e+01,
lng: 1.3048866667e+02,
content:'Saddle = 71.000000 pos = 32.2798,130.4887 diff = 161.899994'
});
data_peak.push({
lat: 3.2651222223e+01,
lng: 1.3077433333e+02,
cert : false,
content:' Peak = 273.500000 pos = 32.6512,130.7743 diff = 199.899994'
});
data_saddle.push({
lat: 3.2653444445e+01,
lng: 1.3079511111e+02,
content:'Saddle = 73.599998 pos = 32.6534,130.7951 diff = 199.899994'
});
data_peak.push({
lat: 3.3692111111e+01,
lng: 1.3066311111e+02,
cert : false,
content:' Peak = 267.600006 pos = 33.6921,130.6631 diff = 190.900009'
});
data_saddle.push({
lat: 3.3690111111e+01,
lng: 1.3065722222e+02,
content:'Saddle = 76.699997 pos = 33.6901,130.6572 diff = 190.900009'
});
data_peak.push({
lat: 3.3594555556e+01,
lng: 1.3077588889e+02,
cert : true,
content:'Name = JA6/FO-041(JA6/FO-041) peak = 421.700012 pos = 33.5946,130.7759 diff = 344.800018'
});
data_saddle.push({
lat: 3.3574111111e+01,
lng: 1.3077722222e+02,
content:'Saddle = 76.900002 pos = 33.5741,130.7772 diff = 344.800018'
});
data_peak.push({
lat: 3.3630666667e+01,
lng: 1.3075177778e+02,
cert : true,
content:'Name = JA6/FO-049(JA6/FO-049) peak = 357.899994 pos = 33.6307,130.7518 diff = 200.699997'
});
data_saddle.push({
lat: 3.3619666667e+01,
lng: 1.3075955556e+02,
content:'Saddle = 157.199997 pos = 33.6197,130.7596 diff = 200.699997'
});
data_peak.push({
lat: 3.3849111111e+01,
lng: 1.3057066667e+02,
cert : true,
content:'Name = JA6/FO-034(JA6/FO-034) peak = 495.899994 pos = 33.8491,130.5707 diff = 418.399994'
});
data_saddle.push({
lat: 3.3800888889e+01,
lng: 1.3063400000e+02,
content:'Saddle = 77.500000 pos = 33.8009,130.6340 diff = 418.399994'
});
data_peak.push({
lat: 3.3819444445e+01,
lng: 1.3062488889e+02,
cert : false,
content:' Peak = 266.500000 pos = 33.8194,130.6249 diff = 188.899994'
});
data_saddle.push({
lat: 3.3823000000e+01,
lng: 1.3060722222e+02,
content:'Saddle = 77.599998 pos = 33.8230,130.6072 diff = 188.899994'
});
data_peak.push({
lat: 3.3869555556e+01,
lng: 1.3055300000e+02,
cert : true,
content:'Name = JA6/FO-036(JA6/FO-036) peak = 470.299988 pos = 33.8696,130.5530 diff = 362.299988'
});
data_saddle.push({
lat: 3.3861000000e+01,
lng: 1.3056666667e+02,
content:'Saddle = 108.000000 pos = 33.8610,130.5667 diff = 362.299988'
});
data_peak.push({
lat: 3.3818555556e+01,
lng: 1.3059111111e+02,
cert : true,
content:'Name = JA6/FO-045(JA6/FO-045) peak = 361.799988 pos = 33.8186,130.5911 diff = 204.699982'
});
data_saddle.push({
lat: 3.3841222222e+01,
lng: 1.3058111111e+02,
content:'Saddle = 157.100006 pos = 33.8412,130.5811 diff = 204.699982'
});
data_peak.push({
lat: 3.3053666667e+01,
lng: 1.3061033333e+02,
cert : false,
content:' Peak = 243.100006 pos = 33.0537,130.6103 diff = 165.500000'
});
data_saddle.push({
lat: 3.3067888889e+01,
lng: 1.3060533333e+02,
content:'Saddle = 77.599998 pos = 33.0679,130.6053 diff = 165.500000'
});
data_peak.push({
lat: 3.1867666668e+01,
lng: 1.3041066667e+02,
cert : false,
content:' Peak = 240.100006 pos = 31.8677,130.4107 diff = 162.400009'
});
data_saddle.push({
lat: 3.1876444445e+01,
lng: 1.3040333333e+02,
content:'Saddle = 77.699997 pos = 31.8764,130.4033 diff = 162.400009'
});
data_peak.push({
lat: 3.3027111112e+01,
lng: 1.3050433333e+02,
cert : false,
content:' Peak = 383.399994 pos = 33.0271,130.5043 diff = 305.099976'
});
data_saddle.push({
lat: 3.3078666667e+01,
lng: 1.3054144444e+02,
content:'Saddle = 78.300003 pos = 33.0787,130.5414 diff = 305.099976'
});
data_peak.push({
lat: 3.3083222223e+01,
lng: 1.3052233333e+02,
cert : false,
content:' Peak = 273.399994 pos = 33.0832,130.5223 diff = 156.099991'
});
data_saddle.push({
lat: 3.3075333334e+01,
lng: 1.3051855556e+02,
content:'Saddle = 117.300003 pos = 33.0753,130.5186 diff = 156.099991'
});
data_peak.push({
lat: 3.1830666668e+01,
lng: 1.3034666667e+02,
cert : true,
content:'Name = JA6/KG-123(JA6/KG-123) peak = 310.299988 pos = 31.8307,130.3467 diff = 231.499985'
});
data_saddle.push({
lat: 3.1819555556e+01,
lng: 1.3035388889e+02,
content:'Saddle = 78.800003 pos = 31.8196,130.3539 diff = 231.499985'
});
data_peak.push({
lat: 3.3781222222e+01,
lng: 1.3062211111e+02,
cert : true,
content:'Name = JA6/FO-052(JA6/FO-052) peak = 320.899994 pos = 33.7812,130.6221 diff = 239.799988'
});
data_saddle.push({
lat: 3.3763888889e+01,
lng: 1.3059344444e+02,
content:'Saddle = 81.099998 pos = 33.7639,130.5934 diff = 239.799988'
});
data_peak.push({
lat: 3.3758444445e+01,
lng: 1.3060688889e+02,
cert : false,
content:' Peak = 296.700012 pos = 33.7584,130.6069 diff = 160.200012'
});
data_saddle.push({
lat: 3.3777333333e+01,
lng: 1.3061177778e+02,
content:'Saddle = 136.500000 pos = 33.7773,130.6118 diff = 160.200012'
});
data_peak.push({
lat: 3.3121555556e+01,
lng: 1.3175544444e+02,
cert : false,
content:' Peak = 340.299988 pos = 33.1216,131.7554 diff = 257.399994'
});
data_saddle.push({
lat: 3.3133666667e+01,
lng: 1.3172166667e+02,
content:'Saddle = 82.900002 pos = 33.1337,131.7217 diff = 257.399994'
});
data_peak.push({
lat: 3.1612000001e+01,
lng: 1.3035000000e+02,
cert : false,
content:' Peak = 241.300003 pos = 31.6120,130.3500 diff = 154.500000'
});
data_saddle.push({
lat: 3.1620666668e+01,
lng: 1.3036077778e+02,
content:'Saddle = 86.800003 pos = 31.6207,130.3608 diff = 154.500000'
});
data_peak.push({
lat: 3.3776333333e+01,
lng: 1.3053933333e+02,
cert : false,
content:' Peak = 270.500000 pos = 33.7763,130.5393 diff = 182.899994'
});
data_saddle.push({
lat: 3.3769111111e+01,
lng: 1.3053988889e+02,
content:'Saddle = 87.599998 pos = 33.7691,130.5399 diff = 182.899994'
});
data_peak.push({
lat: 3.2442111112e+01,
lng: 1.3061933333e+02,
cert : true,
content:'Name = JA6/KM-058(JA6/KM-058) peak = 510.600006 pos = 32.4421,130.6193 diff = 422.900024'
});
data_saddle.push({
lat: 3.2403444445e+01,
lng: 1.3060300000e+02,
content:'Saddle = 87.699997 pos = 32.4034,130.6030 diff = 422.900024'
});
data_peak.push({
lat: 3.2409111112e+01,
lng: 1.3061055556e+02,
cert : false,
content:' Peak = 291.399994 pos = 32.4091,130.6106 diff = 172.799988'
});
data_saddle.push({
lat: 3.2410444445e+01,
lng: 1.3060466667e+02,
content:'Saddle = 118.599998 pos = 32.4104,130.6047 diff = 172.799988'
});
data_peak.push({
lat: 3.2467000001e+01,
lng: 1.3061911111e+02,
cert : false,
content:' Peak = 361.100006 pos = 32.4670,130.6191 diff = 168.300003'
});
data_saddle.push({
lat: 3.2457444445e+01,
lng: 1.3060866667e+02,
content:'Saddle = 192.800003 pos = 32.4574,130.6087 diff = 168.300003'
});
data_peak.push({
lat: 3.1776777779e+01,
lng: 1.3024177778e+02,
cert : true,
content:'Name = JA6/KG-061(JA6/KG-061) peak = 527.099976 pos = 31.7768,130.2418 diff = 439.199982'
});
data_saddle.push({
lat: 3.1753111112e+01,
lng: 1.3029677778e+02,
content:'Saddle = 87.900002 pos = 31.7531,130.2968 diff = 439.199982'
});
data_peak.push({
lat: 3.1404555557e+01,
lng: 1.3015822222e+02,
cert : true,
content:'Name = Nomadake(JA6/KG-047) peak = 591.000000 pos = 31.4046,130.1582 diff = 502.700012'
});
data_saddle.push({
lat: 3.1347666668e+01,
lng: 1.3027611111e+02,
content:'Saddle = 88.300003 pos = 31.3477,130.2761 diff = 502.700012'
});
data_peak.push({
lat: 3.1380333334e+01,
lng: 1.3026722222e+02,
cert : true,
content:'Name = JA6/KG-069(JA6/KG-069) peak = 513.099976 pos = 31.3803,130.2672 diff = 420.699982'
});
data_saddle.push({
lat: 3.1378222223e+01,
lng: 1.3017111111e+02,
content:'Saddle = 92.400002 pos = 31.3782,130.1711 diff = 420.699982'
});
data_peak.push({
lat: 3.1351444446e+01,
lng: 1.3021955556e+02,
cert : false,
content:' Peak = 386.399994 pos = 31.3514,130.2196 diff = 267.899994'
});
data_saddle.push({
lat: 3.1333444446e+01,
lng: 1.3023188889e+02,
content:'Saddle = 118.500000 pos = 31.3334,130.2319 diff = 267.899994'
});
data_peak.push({
lat: 3.1380111112e+01,
lng: 1.3018311111e+02,
cert : false,
content:' Peak = 360.200012 pos = 31.3801,130.1831 diff = 192.400009'
});
data_saddle.push({
lat: 3.1374111112e+01,
lng: 1.3019211111e+02,
content:'Saddle = 167.800003 pos = 31.3741,130.1921 diff = 192.400009'
});
data_peak.push({
lat: 3.1336444446e+01,
lng: 1.3024122222e+02,
cert : false,
content:' Peak = 390.100006 pos = 31.3364,130.2412 diff = 221.800003'
});
data_saddle.push({
lat: 3.1354777779e+01,
lng: 1.3026200000e+02,
content:'Saddle = 168.300003 pos = 31.3548,130.2620 diff = 221.800003'
});
data_peak.push({
lat: 3.3742333333e+01,
lng: 1.3080388889e+02,
cert : true,
content:'Name = Fukuchiyama(JA6/FO-006) peak = 901.200012 pos = 33.7423,130.8039 diff = 812.700012'
});
data_saddle.push({
lat: 3.3613444445e+01,
lng: 1.3087544444e+02,
content:'Saddle = 88.500000 pos = 33.6134,130.8754 diff = 812.700012'
});
data_peak.push({
lat: 3.3667444445e+01,
lng: 1.3090788889e+02,
cert : false,
content:' Peak = 352.600006 pos = 33.6674,130.9079 diff = 151.200012'
});
data_saddle.push({
lat: 3.3665555556e+01,
lng: 1.3090366667e+02,
content:'Saddle = 201.399994 pos = 33.6656,130.9037 diff = 151.200012'
});
data_peak.push({
lat: 3.3762666667e+01,
lng: 1.3084655556e+02,
cert : true,
content:'Name = JA6/FO-043(JA6/FO-043) peak = 394.299988 pos = 33.7627,130.8466 diff = 186.399994'
});
data_saddle.push({
lat: 3.3741777778e+01,
lng: 1.3084833333e+02,
content:'Saddle = 207.899994 pos = 33.7418,130.8483 diff = 186.399994'
});
data_peak.push({
lat: 3.3768444445e+01,
lng: 1.3095266667e+02,
cert : false,
content:' Peak = 415.000000 pos = 33.7684,130.9527 diff = 193.000000'
});
data_saddle.push({
lat: 3.3770888889e+01,
lng: 1.3094677778e+02,
content:'Saddle = 222.000000 pos = 33.7709,130.9468 diff = 193.000000'
});
data_peak.push({
lat: 3.3780555556e+01,
lng: 1.3090933333e+02,
cert : false,
content:' Peak = 711.400024 pos = 33.7806,130.9093 diff = 489.200012'
});
data_saddle.push({
lat: 3.3736111111e+01,
lng: 1.3085811111e+02,
content:'Saddle = 222.199997 pos = 33.7361,130.8581 diff = 489.200012'
});
data_peak.push({
lat: 3.3658111111e+01,
lng: 1.3088122222e+02,
cert : true,
content:'Name = JA6/FO-029(JA6/FO-029) peak = 571.900024 pos = 33.6581,130.8812 diff = 324.300018'
});
data_saddle.push({
lat: 3.3702555556e+01,
lng: 1.3087600000e+02,
content:'Saddle = 247.600006 pos = 33.7026,130.8760 diff = 324.300018'
});
data_peak.push({
lat: 3.3736888889e+01,
lng: 1.3086688889e+02,
cert : true,
content:'Name = JA6/FO-019(JA6/FO-019) peak = 680.700012 pos = 33.7369,130.8669 diff = 303.200012'
});
data_saddle.push({
lat: 3.3762111111e+01,
lng: 1.3089122222e+02,
content:'Saddle = 377.500000 pos = 33.7621,130.8912 diff = 303.200012'
});
data_peak.push({
lat: 3.3752666667e+01,
lng: 1.3088188889e+02,
cert : true,
content:'Name = JA6/FO-030(JA6/FO-030) peak = 540.700012 pos = 33.7527,130.8819 diff = 152.100006'
});
data_saddle.push({
lat: 3.3748555556e+01,
lng: 1.3087711111e+02,
content:'Saddle = 388.600006 pos = 33.7486,130.8771 diff = 152.100006'
});
data_peak.push({
lat: 3.3692222222e+01,
lng: 1.3084444444e+02,
cert : true,
content:'Name = JA6/FO-032(JA6/FO-032) peak = 511.600006 pos = 33.6922,130.8444 diff = 243.300018'
});
data_saddle.push({
lat: 3.3692666667e+01,
lng: 1.3083922222e+02,
content:'Saddle = 268.299988 pos = 33.6927,130.8392 diff = 243.300018'
});
data_peak.push({
lat: 3.3846555556e+01,
lng: 1.3079644444e+02,
cert : true,
content:'Name = JA6/FO-024(JA6/FO-024) peak = 623.099976 pos = 33.8466,130.7964 diff = 324.099976'
});
data_saddle.push({
lat: 3.3830888889e+01,
lng: 1.3078100000e+02,
content:'Saddle = 299.000000 pos = 33.8309,130.7810 diff = 324.099976'
});
data_peak.push({
lat: 3.3791555556e+01,
lng: 1.3082877778e+02,
cert : false,
content:' Peak = 500.799988 pos = 33.7916,130.8288 diff = 172.299988'
});
data_saddle.push({
lat: 3.3794666667e+01,
lng: 1.3081911111e+02,
content:'Saddle = 328.500000 pos = 33.7947,130.8191 diff = 172.299988'
});
data_peak.push({
lat: 3.3786000000e+01,
lng: 1.3078077778e+02,
cert : true,
content:'Name = JA6/FO-028(JA6/FO-028) peak = 573.599976 pos = 33.7860,130.7808 diff = 182.699982'
});
data_saddle.push({
lat: 3.3779333333e+01,
lng: 1.3079144444e+02,
content:'Saddle = 390.899994 pos = 33.7793,130.7914 diff = 182.699982'
});
data_peak.push({
lat: 3.2608000001e+01,
lng: 1.3073100000e+02,
cert : false,
content:' Peak = 280.799988 pos = 32.6080,130.7310 diff = 191.899994'
});
data_saddle.push({
lat: 3.2612333334e+01,
lng: 1.3075155556e+02,
content:'Saddle = 88.900002 pos = 32.6123,130.7516 diff = 191.899994'
});
data_peak.push({
lat: 3.1339777779e+01,
lng: 1.3030244444e+02,
cert : true,
content:'Name = JA6/KG-078(JA6/KG-078) peak = 474.500000 pos = 31.3398,130.3024 diff = 379.600006'
});
data_saddle.push({
lat: 3.1333444446e+01,
lng: 1.3033711111e+02,
content:'Saddle = 94.900002 pos = 31.3334,130.3371 diff = 379.600006'
});
data_peak.push({
lat: 3.3175000000e+01,
lng: 1.3175011111e+02,
cert : false,
content:' Peak = 524.000000 pos = 33.1750,131.7501 diff = 427.100006'
});
data_saddle.push({
lat: 3.3126333334e+01,
lng: 1.3170900000e+02,
content:'Saddle = 96.900002 pos = 33.1263,131.7090 diff = 427.100006'
});
data_peak.push({
lat: 3.3160666667e+01,
lng: 1.3171022222e+02,
cert : false,
content:' Peak = 463.200012 pos = 33.1607,131.7102 diff = 180.200012'
});
data_saddle.push({
lat: 3.3168333334e+01,
lng: 1.3172811111e+02,
content:'Saddle = 283.000000 pos = 33.1683,131.7281 diff = 180.200012'
});
data_peak.push({
lat: 3.3206666667e+01,
lng: 1.3183400000e+02,
cert : true,
content:'Name = JA6/OT-085(JA6/OT-085) peak = 480.500000 pos = 33.2067,131.8340 diff = 193.500000'
});
data_saddle.push({
lat: 3.3199666667e+01,
lng: 1.3181444444e+02,
content:'Saddle = 287.000000 pos = 33.1997,131.8144 diff = 193.500000'
});
data_peak.push({
lat: 3.1989444445e+01,
lng: 1.3022688889e+02,
cert : true,
content:'Name = JA6/KG-120(JA6/KG-120) peak = 320.799988 pos = 31.9894,130.2269 diff = 223.499985'
});
data_saddle.push({
lat: 3.1986777779e+01,
lng: 1.3023655556e+02,
content:'Saddle = 97.300003 pos = 31.9868,130.2366 diff = 223.499985'
});
data_peak.push({
lat: 3.3551777778e+01,
lng: 1.3069377778e+02,
cert : true,
content:'Name = JA6/FO-053(JA6/FO-053) peak = 310.100006 pos = 33.5518,130.6938 diff = 212.000000'
});
data_saddle.push({
lat: 3.3541222222e+01,
lng: 1.3068555556e+02,
content:'Saddle = 98.099998 pos = 33.5412,130.6856 diff = 212.000000'
});
data_peak.push({
lat: 3.3072666667e+01,
lng: 1.3168600000e+02,
cert : true,
content:'Name = JA6/OT-098(JA6/OT-098) peak = 331.899994 pos = 33.0727,131.6860 diff = 233.500000'
});
data_saddle.push({
lat: 3.3067555556e+01,
lng: 1.3171188889e+02,
content:'Saddle = 98.400002 pos = 33.0676,131.7119 diff = 233.500000'
});
data_peak.push({
lat: 3.3087333334e+01,
lng: 1.3167888889e+02,
cert : false,
content:' Peak = 281.799988 pos = 33.0873,131.6789 diff = 154.099991'
});
data_saddle.push({
lat: 3.3083666667e+01,
lng: 1.3168522222e+02,
content:'Saddle = 127.699997 pos = 33.0837,131.6852 diff = 154.099991'
});
data_peak.push({
lat: 3.3082777778e+01,
lng: 1.3171533333e+02,
cert : false,
content:' Peak = 313.700012 pos = 33.0828,131.7153 diff = 182.900009'
});
data_saddle.push({
lat: 3.3078555556e+01,
lng: 1.3170755556e+02,
content:'Saddle = 130.800003 pos = 33.0786,131.7076 diff = 182.900009'
});
data_peak.push({
lat: 3.1787111112e+01,
lng: 1.3035377778e+02,
cert : true,
content:'Name = JA6/KG-117(JA6/KG-117) peak = 340.000000 pos = 31.7871,130.3538 diff = 237.399994'
});
data_saddle.push({
lat: 3.1776222223e+01,
lng: 1.3037611111e+02,
content:'Saddle = 102.599998 pos = 31.7762,130.3761 diff = 237.399994'
});
data_peak.push({
lat: 3.1905333334e+01,
lng: 1.3029100000e+02,
cert : false,
content:' Peak = 263.100006 pos = 31.9053,130.2910 diff = 156.600006'
});
data_saddle.push({
lat: 3.1914333334e+01,
lng: 1.3028000000e+02,
content:'Saddle = 106.500000 pos = 31.9143,130.2800 diff = 156.600006'
});
data_peak.push({
lat: 3.3051111111e+01,
lng: 1.3058344444e+02,
cert : false,
content:' Peak = 316.600006 pos = 33.0511,130.5834 diff = 208.600006'
});
data_saddle.push({
lat: 3.3066444445e+01,
lng: 1.3057433333e+02,
content:'Saddle = 108.000000 pos = 33.0664,130.5743 diff = 208.600006'
});
data_peak.push({
lat: 3.1431666668e+01,
lng: 1.3035711111e+02,
cert : true,
content:'Name = JA6/KG-130(JA6/KG-130) peak = 286.899994 pos = 31.4317,130.3571 diff = 176.399994'
});
data_saddle.push({
lat: 3.1438000001e+01,
lng: 1.3036888889e+02,
content:'Saddle = 110.500000 pos = 31.4380,130.3689 diff = 176.399994'
});
data_peak.push({
lat: 3.1333777779e+01,
lng: 1.3037700000e+02,
cert : false,
content:' Peak = 353.799988 pos = 31.3338,130.3770 diff = 239.499985'
});
data_saddle.push({
lat: 3.1333444446e+01,
lng: 1.3039333333e+02,
content:'Saddle = 114.300003 pos = 31.3334,130.3933 diff = 239.499985'
});
data_peak.push({
lat: 3.3538222222e+01,
lng: 1.3051411111e+02,
cert : true,
content:'Name = JA6/FO-042(JA6/FO-042) peak = 403.500000 pos = 33.5382,130.5141 diff = 286.299988'
});
data_saddle.push({
lat: 3.3549000000e+01,
lng: 1.3054055556e+02,
content:'Saddle = 117.199997 pos = 33.5490,130.5406 diff = 286.299988'
});
data_peak.push({
lat: 3.3702000000e+01,
lng: 1.3063644444e+02,
cert : false,
content:' Peak = 280.399994 pos = 33.7020,130.6364 diff = 162.500000'
});
data_saddle.push({
lat: 3.3698222222e+01,
lng: 1.3062411111e+02,
content:'Saddle = 117.900002 pos = 33.6982,130.6241 diff = 162.500000'
});
data_peak.push({
lat: 3.3031111111e+01,
lng: 1.3164755556e+02,
cert : false,
content:' Peak = 290.899994 pos = 33.0311,131.6476 diff = 168.599991'
});
data_saddle.push({
lat: 3.3032222223e+01,
lng: 1.3166855556e+02,
content:'Saddle = 122.300003 pos = 33.0322,131.6686 diff = 168.599991'
});
data_peak.push({
lat: 3.1871666668e+01,
lng: 1.3046366667e+02,
cert : true,
content:'Name = JA6/KG-107(JA6/KG-107) peak = 383.399994 pos = 31.8717,130.4637 diff = 256.599976'
});
data_saddle.push({
lat: 3.1876333334e+01,
lng: 1.3051366667e+02,
content:'Saddle = 126.800003 pos = 31.8763,130.5137 diff = 256.599976'
});
data_peak.push({
lat: 3.3055777778e+01,
lng: 1.3197833333e+02,
cert : true,
content:'Name = JA6/OT-097(JA6/OT-097) peak = 341.399994 pos = 33.0558,131.9783 diff = 214.399994'
});
data_saddle.push({
lat: 3.3063222223e+01,
lng: 1.3193100000e+02,
content:'Saddle = 127.000000 pos = 33.0632,131.9310 diff = 214.399994'
});
data_peak.push({
lat: 3.3487777778e+01,
lng: 1.3126688889e+02,
cert : false,
content:' Peak = 300.700012 pos = 33.4878,131.2669 diff = 163.100006'
});
data_saddle.push({
lat: 3.3480444445e+01,
lng: 1.3125522222e+02,
content:'Saddle = 137.600006 pos = 33.4804,131.2552 diff = 163.100006'
});
data_peak.push({
lat: 3.2364111112e+01,
lng: 1.3062766667e+02,
cert : true,
content:'Name = JA6/KM-048(JA6/KM-048) peak = 623.000000 pos = 32.3641,130.6277 diff = 484.600006'
});
data_saddle.push({
lat: 3.2293222223e+01,
lng: 1.3056544444e+02,
content:'Saddle = 138.399994 pos = 32.2932,130.5654 diff = 484.600006'
});
data_peak.push({
lat: 3.2387777778e+01,
lng: 1.3053055556e+02,
cert : false,
content:' Peak = 331.299988 pos = 32.3878,130.5306 diff = 184.299988'
});
data_saddle.push({
lat: 3.2378666667e+01,
lng: 1.3052855556e+02,
content:'Saddle = 147.000000 pos = 32.3787,130.5286 diff = 184.299988'
});
data_peak.push({
lat: 3.2313111112e+01,
lng: 1.3059777778e+02,
cert : true,
content:'Name = JA6/KM-064(JA6/KM-064) peak = 484.799988 pos = 32.3131,130.5978 diff = 316.000000'
});
data_saddle.push({
lat: 3.2306222223e+01,
lng: 1.3053788889e+02,
content:'Saddle = 168.800003 pos = 32.3062,130.5379 diff = 316.000000'
});
data_peak.push({
lat: 3.2345000001e+01,
lng: 1.3054877778e+02,
cert : true,
content:'Name = JA6/KM-052(JA6/KM-052) peak = 565.500000 pos = 32.3450,130.5488 diff = 298.700012'
});
data_saddle.push({
lat: 3.2363888890e+01,
lng: 1.3054011111e+02,
content:'Saddle = 266.799988 pos = 32.3639,130.5401 diff = 298.700012'
});
data_peak.push({
lat: 3.3434666667e+01,
lng: 1.3068566667e+02,
cert : false,
content:' Peak = 313.200012 pos = 33.4347,130.6857 diff = 174.400009'
});
data_saddle.push({
lat: 3.3436333334e+01,
lng: 1.3071944444e+02,
content:'Saddle = 138.800003 pos = 33.4363,130.7194 diff = 174.400009'
});
data_peak.push({
lat: 3.3449888889e+01,
lng: 1.3140433333e+02,
cert : false,
content:' Peak = 301.799988 pos = 33.4499,131.4043 diff = 160.699982'
});
data_saddle.push({
lat: 3.3441333334e+01,
lng: 1.3141033333e+02,
content:'Saddle = 141.100006 pos = 33.4413,131.4103 diff = 160.699982'
});
data_peak.push({
lat: 3.2287000001e+01,
lng: 1.3056744444e+02,
cert : true,
content:'Name = JA6/KM-091(JA6/KM-091) peak = 310.700012 pos = 32.2870,130.5674 diff = 162.400009'
});
data_saddle.push({
lat: 3.2275888890e+01,
lng: 1.3056744444e+02,
content:'Saddle = 148.300003 pos = 32.2759,130.5674 diff = 162.400009'
});
data_peak.push({
lat: 3.3492888889e+01,
lng: 1.3056844444e+02,
cert : true,
content:'Name = JA6/FO-051(JA6/FO-051) peak = 338.500000 pos = 33.4929,130.5684 diff = 189.899994'
});
data_saddle.push({
lat: 3.3502888889e+01,
lng: 1.3057311111e+02,
content:'Saddle = 148.600006 pos = 33.5029,130.5731 diff = 189.899994'
});
data_peak.push({
lat: 3.3583111111e+01,
lng: 1.3160155556e+02,
cert : true,
content:'Name = Futagosan(JA6/OT-046) peak = 720.099976 pos = 33.5831,131.6016 diff = 571.299988'
});
data_saddle.push({
lat: 3.3489666667e+01,
lng: 1.3146211111e+02,
content:'Saddle = 148.800003 pos = 33.4897,131.4621 diff = 571.299988'
});
data_peak.push({
lat: 3.3503555556e+01,
lng: 1.3147488889e+02,
cert : true,
content:'Name = JA6/OT-068(JA6/OT-068) peak = 592.299988 pos = 33.5036,131.4749 diff = 355.099976'
});
data_saddle.push({
lat: 3.3499000000e+01,
lng: 1.3158377778e+02,
content:'Saddle = 237.199997 pos = 33.4990,131.5838 diff = 355.099976'
});
data_peak.push({
lat: 3.3477111111e+01,
lng: 1.3153544444e+02,
cert : false,
content:' Peak = 541.599976 pos = 33.4771,131.5354 diff = 302.599976'
});
data_saddle.push({
lat: 3.3485333334e+01,
lng: 1.3150233333e+02,
content:'Saddle = 239.000000 pos = 33.4853,131.5023 diff = 302.599976'
});
data_peak.push({
lat: 3.3513444445e+01,
lng: 1.3145433333e+02,
cert : true,
content:'Name = JA6/OT-081(JA6/OT-081) peak = 542.000000 pos = 33.5134,131.4543 diff = 219.500000'
});
data_saddle.push({
lat: 3.3508333334e+01,
lng: 1.3146255556e+02,
content:'Saddle = 322.500000 pos = 33.5083,131.4626 diff = 219.500000'
});
data_peak.push({
lat: 3.3516222222e+01,
lng: 1.3148922222e+02,
cert : false,
content:' Peak = 570.700012 pos = 33.5162,131.4892 diff = 168.800018'
});
data_saddle.push({
lat: 3.3509444445e+01,
lng: 1.3147911111e+02,
content:'Saddle = 401.899994 pos = 33.5094,131.4791 diff = 168.800018'
});
data_peak.push({
lat: 3.3606444445e+01,
lng: 1.3151666667e+02,
cert : true,
content:'Name = JA6/OT-089(JA6/OT-089) peak = 457.500000 pos = 33.6064,131.5167 diff = 196.399994'
});
data_saddle.push({
lat: 3.3607111111e+01,
lng: 1.3153111111e+02,
content:'Saddle = 261.100006 pos = 33.6071,131.5311 diff = 196.399994'
});
data_peak.push({
lat: 3.3599111111e+01,
lng: 1.3154522222e+02,
cert : true,
content:'Name = JA6/OT-070(JA6/OT-070) peak = 587.000000 pos = 33.5991,131.5452 diff = 299.799988'
});
data_saddle.push({
lat: 3.3599333333e+01,
lng: 1.3156511111e+02,
content:'Saddle = 287.200012 pos = 33.5993,131.5651 diff = 299.799988'
});
data_peak.push({
lat: 3.3603111111e+01,
lng: 1.3155322222e+02,
cert : false,
content:' Peak = 570.200012 pos = 33.6031,131.5532 diff = 163.400024'
});
data_saddle.push({
lat: 3.3600888889e+01,
lng: 1.3155111111e+02,
content:'Saddle = 406.799988 pos = 33.6009,131.5511 diff = 163.400024'
});
data_peak.push({
lat: 3.3567333334e+01,
lng: 1.3155311111e+02,
cert : true,
content:'Name = JA6/OT-079(JA6/OT-079) peak = 542.500000 pos = 33.5673,131.5531 diff = 211.100006'
});
data_saddle.push({
lat: 3.3570222222e+01,
lng: 1.3156122222e+02,
content:'Saddle = 331.399994 pos = 33.5702,131.5612 diff = 211.100006'
});
data_peak.push({
lat: 3.3597000000e+01,
lng: 1.3162277778e+02,
cert : false,
content:' Peak = 535.400024 pos = 33.5970,131.6228 diff = 197.500031'
});
data_saddle.push({
lat: 3.3597888889e+01,
lng: 1.3161533333e+02,
content:'Saddle = 337.899994 pos = 33.5979,131.6153 diff = 197.500031'
});
data_peak.push({
lat: 3.3612888889e+01,
lng: 1.3157822222e+02,
cert : true,
content:'Name = JA6/OT-083(JA6/OT-083) peak = 513.799988 pos = 33.6129,131.5782 diff = 173.299988'
});
data_saddle.push({
lat: 3.3606333333e+01,
lng: 1.3157411111e+02,
content:'Saddle = 340.500000 pos = 33.6063,131.5741 diff = 173.299988'
});
data_peak.push({
lat: 3.3592555556e+01,
lng: 1.3157033333e+02,
cert : false,
content:' Peak = 530.500000 pos = 33.5926,131.5703 diff = 168.600006'
});
data_saddle.push({
lat: 3.3588444445e+01,
lng: 1.3157811111e+02,
content:'Saddle = 361.899994 pos = 33.5884,131.5781 diff = 168.600006'
});
data_peak.push({
lat: 3.3614000000e+01,
lng: 1.3159711111e+02,
cert : true,
content:'Name = JA6/OT-066(JA6/OT-066) peak = 605.200012 pos = 33.6140,131.5971 diff = 233.200012'
});
data_saddle.push({
lat: 3.3603666667e+01,
lng: 1.3159922222e+02,
content:'Saddle = 372.000000 pos = 33.6037,131.5992 diff = 233.200012'
});
data_peak.push({
lat: 3.3599000000e+01,
lng: 1.3160533333e+02,
cert : true,
content:'Name = JA6/OT-063(JA6/OT-063) peak = 616.200012 pos = 33.5990,131.6053 diff = 237.900024'
});
data_saddle.push({
lat: 3.3594222222e+01,
lng: 1.3159988889e+02,
content:'Saddle = 378.299988 pos = 33.5942,131.5999 diff = 237.900024'
});
data_peak.push({
lat: 3.3579222222e+01,
lng: 1.3162922222e+02,
cert : false,
content:' Peak = 561.000000 pos = 33.5792,131.6292 diff = 169.000000'
});
data_saddle.push({
lat: 3.3580222222e+01,
lng: 1.3162244444e+02,
content:'Saddle = 392.000000 pos = 33.5802,131.6224 diff = 169.000000'
});
data_peak.push({
lat: 3.3580444445e+01,
lng: 1.3161588889e+02,
cert : false,
content:' Peak = 571.400024 pos = 33.5804,131.6159 diff = 165.000031'
});
data_saddle.push({
lat: 3.3577333334e+01,
lng: 1.3161222222e+02,
content:'Saddle = 406.399994 pos = 33.5773,131.6122 diff = 165.000031'
});
data_peak.push({
lat: 3.1598222223e+01,
lng: 1.3038111111e+02,
cert : true,
content:'Name = JA6/KG-124(JA6/KG-124) peak = 310.600006 pos = 31.5982,130.3811 diff = 159.900009'
});
data_saddle.push({
lat: 3.1602555557e+01,
lng: 1.3039333333e+02,
content:'Saddle = 150.699997 pos = 31.6026,130.3933 diff = 159.900009'
});
data_peak.push({
lat: 3.2764666667e+01,
lng: 1.3083288889e+02,
cert : false,
content:' Peak = 309.799988 pos = 32.7647,130.8329 diff = 157.799988'
});
data_saddle.push({
lat: 3.2767333334e+01,
lng: 1.3083944444e+02,
content:'Saddle = 152.000000 pos = 32.7673,130.8394 diff = 157.799988'
});
data_peak.push({
lat: 3.3053888889e+01,
lng: 1.3070622222e+02,
cert : true,
content:'Name = JA6/KM-071(JA6/KM-071) peak = 414.299988 pos = 33.0539,130.7062 diff = 257.599976'
});
data_saddle.push({
lat: 3.3055666667e+01,
lng: 1.3071766667e+02,
content:'Saddle = 156.699997 pos = 33.0557,130.7177 diff = 257.599976'
});
data_peak.push({
lat: 3.1467777779e+01,
lng: 1.3038288889e+02,
cert : true,
content:'Name = Kinpouzan(JA6/KG-039) peak = 632.099976 pos = 31.4678,130.3829 diff = 472.499969'
});
data_saddle.push({
lat: 3.1685666668e+01,
lng: 1.3045966667e+02,
content:'Saddle = 159.600006 pos = 31.6857,130.4597 diff = 472.499969'
});
data_peak.push({
lat: 3.1384111112e+01,
lng: 1.3050633333e+02,
cert : true,
content:'Name = JA6/KG-043(JA6/KG-043) peak = 604.599976 pos = 31.3841,130.5063 diff = 359.899963'
});
data_saddle.push({
lat: 3.1476555557e+01,
lng: 1.3039466667e+02,
content:'Saddle = 244.699997 pos = 31.4766,130.3947 diff = 359.899963'
});
data_peak.push({
lat: 3.1333444446e+01,
lng: 1.3051755556e+02,
cert : false,
content:' Peak = 425.899994 pos = 31.3334,130.5176 diff = 167.100006'
});
data_saddle.push({
lat: 3.1333444446e+01,
lng: 1.3050888889e+02,
content:'Saddle = 258.799988 pos = 31.3334,130.5089 diff = 167.100006'
});
data_peak.push({
lat: 3.1470555557e+01,
lng: 1.3042933333e+02,
cert : true,
content:'Name = JA6/KG-059(JA6/KG-059) peak = 531.500000 pos = 31.4706,130.4293 diff = 250.000000'
});
data_saddle.push({
lat: 3.1480333334e+01,
lng: 1.3047855556e+02,
content:'Saddle = 281.500000 pos = 31.4803,130.4786 diff = 250.000000'
});
data_peak.push({
lat: 3.1504222223e+01,
lng: 1.3046677778e+02,
cert : false,
content:' Peak = 483.799988 pos = 31.5042,130.4668 diff = 170.399994'
});
data_saddle.push({
lat: 3.1499555557e+01,
lng: 1.3042777778e+02,
content:'Saddle = 313.399994 pos = 31.4996,130.4278 diff = 170.399994'
});
data_peak.push({
lat: 3.1455222223e+01,
lng: 1.3046377778e+02,
cert : false,
content:' Peak = 588.000000 pos = 31.4552,130.4638 diff = 242.899994'
});
data_saddle.push({
lat: 3.1405111112e+01,
lng: 1.3050288889e+02,
content:'Saddle = 345.100006 pos = 31.4051,130.5029 diff = 242.899994'
});
data_peak.push({
lat: 3.1425888890e+01,
lng: 1.3047755556e+02,
cert : true,
content:'Name = JA6/KG-049(JA6/KG-049) peak = 584.500000 pos = 31.4259,130.4776 diff = 222.500000'
});
data_saddle.push({
lat: 3.1464111112e+01,
lng: 1.3048000000e+02,
content:'Saddle = 362.000000 pos = 31.4641,130.4800 diff = 222.500000'
});
data_peak.push({
lat: 3.1559444445e+01,
lng: 1.3106388889e+02,
cert : false,
content:' Peak = 420.000000 pos = 31.5594,131.0639 diff = 259.000000'
});
data_saddle.push({
lat: 3.1572222223e+01,
lng: 1.3107222222e+02,
content:'Saddle = 161.000000 pos = 31.5722,131.0722 diff = 259.000000'
});
data_peak.push({
lat: 3.2628666667e+01,
lng: 1.3083833333e+02,
cert : true,
content:'Name = JA6/KM-077(JA6/KM-077) peak = 390.000000 pos = 32.6287,130.8383 diff = 228.000000'
});
data_saddle.push({
lat: 3.2629333334e+01,
lng: 1.3085977778e+02,
content:'Saddle = 162.000000 pos = 32.6293,130.8598 diff = 228.000000'
});
data_peak.push({
lat: 3.2642666667e+01,
lng: 1.3085177778e+02,
cert : false,
content:' Peak = 371.200012 pos = 32.6427,130.8518 diff = 158.400009'
});
data_saddle.push({
lat: 3.2632222223e+01,
lng: 1.3084000000e+02,
content:'Saddle = 212.800003 pos = 32.6322,130.8400 diff = 158.400009'
});
data_peak.push({
lat: 3.1904666668e+01,
lng: 1.3027677778e+02,
cert : true,
content:'Name = JA6/KG-110(JA6/KG-110) peak = 364.799988 pos = 31.9047,130.2768 diff = 198.099991'
});
data_saddle.push({
lat: 3.1911444445e+01,
lng: 1.3027188889e+02,
content:'Saddle = 166.699997 pos = 31.9114,130.2719 diff = 198.099991'
});
data_peak.push({
lat: 3.1739222223e+01,
lng: 1.3029488889e+02,
cert : true,
content:'Name = JA6/KG-115(JA6/KG-115) peak = 346.799988 pos = 31.7392,130.2949 diff = 174.799988'
});
data_saddle.push({
lat: 3.1747111112e+01,
lng: 1.3031233333e+02,
content:'Saddle = 172.000000 pos = 31.7471,130.3123 diff = 174.799988'
});
data_peak.push({
lat: 3.2469111112e+01,
lng: 1.3154655556e+02,
cert : false,
content:' Peak = 350.899994 pos = 32.4691,131.5466 diff = 178.299988'
});
data_saddle.push({
lat: 3.2469888890e+01,
lng: 1.3153600000e+02,
content:'Saddle = 172.600006 pos = 32.4699,131.5360 diff = 178.299988'
});
data_peak.push({
lat: 3.1568333334e+01,
lng: 1.3127633333e+02,
cert : true,
content:'Name = JA6/MZ-115(JA6/MZ-115) peak = 483.600006 pos = 31.5683,131.2763 diff = 308.500000'
});
data_saddle.push({
lat: 3.1575888890e+01,
lng: 1.3126877778e+02,
content:'Saddle = 175.100006 pos = 31.5759,131.2688 diff = 308.500000'
});
data_peak.push({
lat: 3.2597333334e+01,
lng: 1.3155055556e+02,
cert : true,
content:'Name = JA6/MZ-116(JA6/MZ-116) peak = 470.799988 pos = 32.5973,131.5506 diff = 294.699982'
});
data_saddle.push({
lat: 3.2610000001e+01,
lng: 1.3154500000e+02,
content:'Saddle = 176.100006 pos = 32.6100,131.5450 diff = 294.699982'
});
data_peak.push({
lat: 3.1910444445e+01,
lng: 1.3111477778e+02,
cert : true,
content:'Name = JA6/MZ-124(JA6/MZ-124) peak = 374.100006 pos = 31.9104,131.1148 diff = 197.100006'
});
data_saddle.push({
lat: 3.1923000001e+01,
lng: 1.3110244444e+02,
content:'Saddle = 177.000000 pos = 31.9230,131.1024 diff = 197.100006'
});
data_peak.push({
lat: 3.3081555556e+01,
lng: 1.3065033333e+02,
cert : true,
content:'Name = JA6/KM-072(JA6/KM-072) peak = 407.600006 pos = 33.0816,130.6503 diff = 230.000000'
});
data_saddle.push({
lat: 3.3105555556e+01,
lng: 1.3066511111e+02,
content:'Saddle = 177.600006 pos = 33.1056,130.6651 diff = 230.000000'
});
data_peak.push({
lat: 3.3065333334e+01,
lng: 1.3068366667e+02,
cert : false,
content:' Peak = 354.399994 pos = 33.0653,130.6837 diff = 152.099991'
});
data_saddle.push({
lat: 3.3074000000e+01,
lng: 1.3066455556e+02,
content:'Saddle = 202.300003 pos = 33.0740,130.6646 diff = 152.099991'
});
data_peak.push({
lat: 3.3102555556e+01,
lng: 1.3067355556e+02,
cert : false,
content:' Peak = 397.600006 pos = 33.1026,130.6736 diff = 156.000000'
});
data_saddle.push({
lat: 3.3093111111e+01,
lng: 1.3065633333e+02,
content:'Saddle = 241.600006 pos = 33.0931,130.6563 diff = 156.000000'
});
data_peak.push({
lat: 3.3483222222e+01,
lng: 1.3140877778e+02,
cert : true,
content:'Name = JA6/OT-054(JA6/OT-054) peak = 652.900024 pos = 33.4832,131.4088 diff = 475.200012'
});
data_saddle.push({
lat: 3.3453333334e+01,
lng: 1.3144500000e+02,
content:'Saddle = 177.699997 pos = 33.4533,131.4450 diff = 475.200012'
});
data_peak.push({
lat: 3.3472222222e+01,
lng: 1.3137344444e+02,
cert : true,
content:'Name = JA6/OT-078(JA6/OT-078) peak = 542.000000 pos = 33.4722,131.3734 diff = 314.200012'
});
data_saddle.push({
lat: 3.3476222222e+01,
lng: 1.3138477778e+02,
content:'Saddle = 227.800003 pos = 33.4762,131.3848 diff = 314.200012'
});
data_peak.push({
lat: 3.3461777778e+01,
lng: 1.3139766667e+02,
cert : true,
content:'Name = JA6/OT-087(JA6/OT-087) peak = 474.100006 pos = 33.4618,131.3977 diff = 242.000000'
});
data_saddle.push({
lat: 3.3467777778e+01,
lng: 1.3140644444e+02,
content:'Saddle = 232.100006 pos = 33.4678,131.4064 diff = 242.000000'
});
data_peak.push({
lat: 3.1768888890e+01,
lng: 1.3126944444e+02,
cert : true,
content:'Name = Wanitsukayama(JA6/MZ-036) peak = 1117.400024 pos = 31.7689,131.2694 diff = 933.300049'
});
data_saddle.push({
lat: 3.1642777779e+01,
lng: 1.3100966667e+02,
content:'Saddle = 184.100006 pos = 31.6428,131.0097 diff = 933.300049'
});
data_peak.push({
lat: 3.1896666668e+01,
lng: 1.3127455556e+02,
cert : true,
content:'Name = JA6/MZ-120(JA6/MZ-120) peak = 453.700012 pos = 31.8967,131.2746 diff = 266.400024'
});
data_saddle.push({
lat: 3.1859444445e+01,
lng: 1.3127911111e+02,
content:'Saddle = 187.300003 pos = 31.8594,131.2791 diff = 266.400024'
});
data_peak.push({
lat: 3.1832111112e+01,
lng: 1.3114811111e+02,
cert : false,
content:' Peak = 373.500000 pos = 31.8321,131.1481 diff = 170.600006'
});
data_saddle.push({
lat: 3.1818222223e+01,
lng: 1.3116311111e+02,
content:'Saddle = 202.899994 pos = 31.8182,131.1631 diff = 170.600006'
});
data_peak.push({
lat: 3.1906888890e+01,
lng: 1.3115000000e+02,
cert : false,
content:' Peak = 363.899994 pos = 31.9069,131.1500 diff = 155.899994'
});
data_saddle.push({
lat: 3.1903111112e+01,
lng: 1.3116188889e+02,
content:'Saddle = 208.000000 pos = 31.9031,131.1619 diff = 155.899994'
});
data_peak.push({
lat: 3.1892444445e+01,
lng: 1.3117455556e+02,
cert : false,
content:' Peak = 372.899994 pos = 31.8924,131.1746 diff = 164.799988'
});
data_saddle.push({
lat: 3.1886111112e+01,
lng: 1.3116911111e+02,
content:'Saddle = 208.100006 pos = 31.8861,131.1691 diff = 164.799988'
});
data_peak.push({
lat: 3.1590888890e+01,
lng: 1.3108255556e+02,
cert : true,
content:'Name = JA6/KG-066(JA6/KG-066) peak = 523.099976 pos = 31.5909,131.0826 diff = 270.399963'
});
data_saddle.push({
lat: 3.1594666668e+01,
lng: 1.3109344444e+02,
content:'Saddle = 252.699997 pos = 31.5947,131.0934 diff = 270.399963'
});
data_peak.push({
lat: 3.1585111112e+01,
lng: 1.3111544444e+02,
cert : false,
content:' Peak = 450.899994 pos = 31.5851,131.1154 diff = 196.500000'
});
data_saddle.push({
lat: 3.1624111112e+01,
lng: 1.3112411111e+02,
content:'Saddle = 254.399994 pos = 31.6241,131.1241 diff = 196.500000'
});
data_peak.push({
lat: 3.1550333334e+01,
lng: 1.3117144444e+02,
cert : true,
content:'Name = JA6/KG-094(JA6/KG-094) peak = 422.600006 pos = 31.5503,131.1714 diff = 165.399994'
});
data_saddle.push({
lat: 3.1571444445e+01,
lng: 1.3116433333e+02,
content:'Saddle = 257.200012 pos = 31.5714,131.1643 diff = 165.399994'
});
data_peak.push({
lat: 3.1580444445e+01,
lng: 1.3115411111e+02,
cert : true,
content:'Name = JA6/KG-060(JA6/KG-060) peak = 533.500000 pos = 31.5804,131.1541 diff = 241.000000'
});
data_saddle.push({
lat: 3.1596666668e+01,
lng: 1.3116433333e+02,
content:'Saddle = 292.500000 pos = 31.5967,131.1643 diff = 241.000000'
});
data_peak.push({
lat: 3.1851111112e+01,
lng: 1.3121033333e+02,
cert : true,
content:'Name = JA6/MZ-107(JA6/MZ-107) peak = 563.900024 pos = 31.8511,131.2103 diff = 256.200012'
});
data_saddle.push({
lat: 3.1801555556e+01,
lng: 1.3120788889e+02,
content:'Saddle = 307.700012 pos = 31.8016,131.2079 diff = 256.200012'
});
data_peak.push({
lat: 3.1798222223e+01,
lng: 1.3137577778e+02,
cert : true,
content:'Name = JA6/MZ-112(JA6/MZ-112) peak = 507.299988 pos = 31.7982,131.3758 diff = 194.299988'
});
data_saddle.push({
lat: 3.1787555556e+01,
lng: 1.3136955556e+02,
content:'Saddle = 313.000000 pos = 31.7876,131.3696 diff = 194.299988'
});
data_peak.push({
lat: 3.1752333334e+01,
lng: 1.3139588889e+02,
cert : true,
content:'Name = JA6/MZ-084(JA6/MZ-084) peak = 732.099976 pos = 31.7523,131.3959 diff = 384.899963'
});
data_saddle.push({
lat: 3.1759000001e+01,
lng: 1.3136188889e+02,
content:'Saddle = 347.200012 pos = 31.7590,131.3619 diff = 384.899963'
});
data_peak.push({
lat: 3.1749777779e+01,
lng: 1.3136366667e+02,
cert : false,
content:' Peak = 586.000000 pos = 31.7498,131.3637 diff = 178.899994'
});
data_saddle.push({
lat: 3.1755888890e+01,
lng: 1.3138288889e+02,
content:'Saddle = 407.100006 pos = 31.7559,131.3829 diff = 178.899994'
});
data_peak.push({
lat: 3.1669666668e+01,
lng: 1.3133888889e+02,
cert : true,
content:'Name = JA6/MZ-103(JA6/MZ-103) peak = 612.000000 pos = 31.6697,131.3389 diff = 259.500000'
});
data_saddle.push({
lat: 3.1670888890e+01,
lng: 1.3131911111e+02,
content:'Saddle = 352.500000 pos = 31.6709,131.3191 diff = 259.500000'
});
data_peak.push({
lat: 3.1633000001e+01,
lng: 1.3109200000e+02,
cert : false,
content:' Peak = 520.099976 pos = 31.6330,131.0920 diff = 162.499969'
});
data_saddle.push({
lat: 3.1651777779e+01,
lng: 1.3109288889e+02,
content:'Saddle = 357.600006 pos = 31.6518,131.0929 diff = 162.499969'
});
data_peak.push({
lat: 3.1810000001e+01,
lng: 1.3133477778e+02,
cert : true,
content:'Name = JA6/MZ-102(JA6/MZ-102) peak = 610.599976 pos = 31.8100,131.3348 diff = 233.399963'
});
data_saddle.push({
lat: 3.1804555556e+01,
lng: 1.3132888889e+02,
content:'Saddle = 377.200012 pos = 31.8046,131.3289 diff = 233.399963'
});
data_peak.push({
lat: 3.1612777779e+01,
lng: 1.3125800000e+02,
cert : true,
content:'Name = JA6/MZ-080(JA6/MZ-080) peak = 783.099976 pos = 31.6128,131.2580 diff = 405.299988'
});
data_saddle.push({
lat: 3.1626555557e+01,
lng: 1.3123322222e+02,
content:'Saddle = 377.799988 pos = 31.6266,131.2332 diff = 405.299988'
});
data_peak.push({
lat: 3.1802666668e+01,
lng: 1.3131833333e+02,
cert : true,
content:'Name = JA6/MZ-093(JA6/MZ-093) peak = 678.400024 pos = 31.8027,131.3183 diff = 231.400024'
});
data_saddle.push({
lat: 3.1790111112e+01,
lng: 1.3131922222e+02,
content:'Saddle = 447.000000 pos = 31.7901,131.3192 diff = 231.400024'
});
data_peak.push({
lat: 3.1786888890e+01,
lng: 1.3133677778e+02,
cert : true,
content:'Name = JA6/MZ-100(JA6/MZ-100) peak = 636.400024 pos = 31.7869,131.3368 diff = 188.600037'
});
data_saddle.push({
lat: 3.1781222223e+01,
lng: 1.3132900000e+02,
content:'Saddle = 447.799988 pos = 31.7812,131.3290 diff = 188.600037'
});
data_peak.push({
lat: 3.1672444445e+01,
lng: 1.3121066667e+02,
cert : false,
content:' Peak = 791.400024 pos = 31.6724,131.2107 diff = 313.600037'
});
data_saddle.push({
lat: 3.1683222223e+01,
lng: 1.3120622222e+02,
content:'Saddle = 477.799988 pos = 31.6832,131.2062 diff = 313.600037'
});
data_peak.push({
lat: 3.1630000001e+01,
lng: 1.3117966667e+02,
cert : true,
content:'Name = JA6/MZ-091(JA6/MZ-091) peak = 701.099976 pos = 31.6300,131.1797 diff = 209.299988'
});
data_saddle.push({
lat: 3.1645555556e+01,
lng: 1.3117000000e+02,
content:'Saddle = 491.799988 pos = 31.6456,131.1700 diff = 209.299988'
});
data_peak.push({
lat: 3.1644777779e+01,
lng: 1.3119377778e+02,
cert : true,
content:'Name = JA6/MZ-081(JA6/MZ-081) peak = 764.299988 pos = 31.6448,131.1938 diff = 201.200012'
});
data_saddle.push({
lat: 3.1655888890e+01,
lng: 1.3118011111e+02,
content:'Saddle = 563.099976 pos = 31.6559,131.1801 diff = 201.200012'
});
data_peak.push({
lat: 3.1625888890e+01,
lng: 1.3121611111e+02,
cert : false,
content:' Peak = 744.400024 pos = 31.6259,131.2161 diff = 161.600037'
});
data_saddle.push({
lat: 3.1635000001e+01,
lng: 1.3120966667e+02,
content:'Saddle = 582.799988 pos = 31.6350,131.2097 diff = 161.600037'
});
data_peak.push({
lat: 3.1620555557e+01,
lng: 1.3120833333e+02,
cert : false,
content:' Peak = 740.599976 pos = 31.6206,131.2083 diff = 157.799988'
});
data_saddle.push({
lat: 3.1624444445e+01,
lng: 1.3121066667e+02,
content:'Saddle = 582.799988 pos = 31.6244,131.2107 diff = 157.799988'
});
data_peak.push({
lat: 3.1722000001e+01,
lng: 1.3128222222e+02,
cert : true,
content:'Name = JA6/MZ-079(JA6/MZ-079) peak = 793.200012 pos = 31.7220,131.2822 diff = 221.799988'
});
data_saddle.push({
lat: 3.1757444445e+01,
lng: 1.3130888889e+02,
content:'Saddle = 571.400024 pos = 31.7574,131.3089 diff = 221.799988'
});
data_peak.push({
lat: 3.1781444445e+01,
lng: 1.3130644444e+02,
cert : true,
content:'Name = JA6/MZ-072(JA6/MZ-072) peak = 833.799988 pos = 31.7814,131.3064 diff = 241.899963'
});
data_saddle.push({
lat: 3.1767222223e+01,
lng: 1.3129955556e+02,
content:'Saddle = 591.900024 pos = 31.7672,131.2996 diff = 241.899963'
});
data_peak.push({
lat: 3.1685333334e+01,
lng: 1.3127600000e+02,
cert : false,
content:' Peak = 987.700012 pos = 31.6853,131.2760 diff = 368.400024'
});
data_saddle.push({
lat: 3.1682555556e+01,
lng: 1.3123555556e+02,
content:'Saddle = 619.299988 pos = 31.6826,131.2356 diff = 368.400024'
});
data_peak.push({
lat: 3.1715111112e+01,
lng: 1.3121044444e+02,
cert : false,
content:' Peak = 951.700012 pos = 31.7151,131.2104 diff = 288.700012'
});
data_saddle.push({
lat: 3.1725222223e+01,
lng: 1.3123488889e+02,
content:'Saddle = 663.000000 pos = 31.7252,131.2349 diff = 288.700012'
});
data_peak.push({
lat: 3.1669333334e+01,
lng: 1.3115866667e+02,
cert : true,
content:'Name = JA6/MZ-058(JA6/MZ-058) peak = 917.099976 pos = 31.6693,131.1587 diff = 235.099976'
});
data_saddle.push({
lat: 3.1676777779e+01,
lng: 1.3116444444e+02,
content:'Saddle = 682.000000 pos = 31.6768,131.1644 diff = 235.099976'
});
data_peak.push({
lat: 3.1728777779e+01,
lng: 1.3123833333e+02,
cert : true,
content:'Name = JA6/MZ-070(JA6/MZ-070) peak = 845.700012 pos = 31.7288,131.2383 diff = 178.400024'
});
data_saddle.push({
lat: 3.1738000001e+01,
lng: 1.3126100000e+02,
content:'Saddle = 667.299988 pos = 31.7380,131.2610 diff = 178.400024'
});
data_peak.push({
lat: 3.1779444445e+01,
lng: 1.3122733333e+02,
cert : false,
content:' Peak = 910.599976 pos = 31.7794,131.2273 diff = 177.299988'
});
data_saddle.push({
lat: 3.1770333334e+01,
lng: 1.3123366667e+02,
content:'Saddle = 733.299988 pos = 31.7703,131.2337 diff = 177.299988'
});
data_peak.push({
lat: 3.1749222223e+01,
lng: 1.3033177778e+02,
cert : true,
content:'Name = Kanmuridake (Nishidake)(JA6/KG-068) peak = 512.900024 pos = 31.7492,130.3318 diff = 326.500031'
});
data_saddle.push({
lat: 3.1734111112e+01,
lng: 1.3041388889e+02,
content:'Saddle = 186.399994 pos = 31.7341,130.4139 diff = 326.500031'
});
data_peak.push({
lat: 3.1732222223e+01,
lng: 1.3035744444e+02,
cert : true,
content:'Name = JA6/KG-092(JA6/KG-092) peak = 430.299988 pos = 31.7322,130.3574 diff = 199.999985'
});
data_saddle.push({
lat: 3.1745666668e+01,
lng: 1.3038800000e+02,
content:'Saddle = 230.300003 pos = 31.7457,130.3880 diff = 199.999985'
});
data_peak.push({
lat: 3.3158222223e+01,
lng: 1.3059133333e+02,
cert : false,
content:' Peak = 461.500000 pos = 33.1582,130.5913 diff = 274.799988'
});
data_saddle.push({
lat: 3.3113111111e+01,
lng: 1.3065388889e+02,
content:'Saddle = 186.699997 pos = 33.1131,130.6539 diff = 274.799988'
});
data_peak.push({
lat: 3.3469444445e+01,
lng: 1.3148011111e+02,
cert : true,
content:'Name = JA6/OT-095(JA6/OT-095) peak = 364.000000 pos = 33.4694,131.4801 diff = 175.800003'
});
data_saddle.push({
lat: 3.3462111111e+01,
lng: 1.3147044444e+02,
content:'Saddle = 188.199997 pos = 33.4621,131.4704 diff = 175.800003'
});
data_peak.push({
lat: 3.1734555556e+01,
lng: 1.3044833333e+02,
cert : true,
content:'Name = Yaeyama(JA6/KG-032) peak = 676.400024 pos = 31.7346,130.4483 diff = 481.000031'
});
data_saddle.push({
lat: 3.1766444445e+01,
lng: 1.3049222222e+02,
content:'Saddle = 195.399994 pos = 31.7664,130.4922 diff = 481.000031'
});
data_peak.push({
lat: 3.1737000001e+01,
lng: 1.3053155556e+02,
cert : true,
content:'Name = JA6/KG-111(JA6/KG-111) peak = 360.600006 pos = 31.7370,130.5316 diff = 162.500000'
});
data_saddle.push({
lat: 3.1739888890e+01,
lng: 1.3052488889e+02,
content:'Saddle = 198.100006 pos = 31.7399,130.5249 diff = 162.500000'
});
data_peak.push({
lat: 3.1701222223e+01,
lng: 1.3038166667e+02,
cert : false,
content:' Peak = 371.600006 pos = 31.7012,130.3817 diff = 163.500000'
});
data_saddle.push({
lat: 3.1714444445e+01,
lng: 1.3039533333e+02,
content:'Saddle = 208.100006 pos = 31.7144,130.3953 diff = 163.500000'
});
data_peak.push({
lat: 3.1745777779e+01,
lng: 1.3051377778e+02,
cert : true,
content:'Name = JA6/KG-088(JA6/KG-088) peak = 434.299988 pos = 31.7458,130.5138 diff = 212.099991'
});
data_saddle.push({
lat: 3.1742333334e+01,
lng: 1.3051077778e+02,
content:'Saddle = 222.199997 pos = 31.7423,130.5108 diff = 212.099991'
});
data_peak.push({
lat: 3.1697333334e+01,
lng: 1.3058288889e+02,
cert : false,
content:' Peak = 580.900024 pos = 31.6973,130.5829 diff = 356.100037'
});
data_saddle.push({
lat: 3.1687222223e+01,
lng: 1.3056177778e+02,
content:'Saddle = 224.800003 pos = 31.6872,130.5618 diff = 356.100037'
});
data_peak.push({
lat: 3.1690333334e+01,
lng: 1.3052100000e+02,
cert : true,
content:'Name = JA6/KG-074(JA6/KG-074) peak = 484.399994 pos = 31.6903,130.5210 diff = 241.599991'
});
data_saddle.push({
lat: 3.1700777779e+01,
lng: 1.3052266667e+02,
content:'Saddle = 242.800003 pos = 31.7008,130.5227 diff = 241.599991'
});
data_peak.push({
lat: 3.1699333334e+01,
lng: 1.3042033333e+02,
cert : true,
content:'Name = JA6/KG-065(JA6/KG-065) peak = 522.500000 pos = 31.6993,130.4203 diff = 255.399994'
});
data_saddle.push({
lat: 3.1716111112e+01,
lng: 1.3042688889e+02,
content:'Saddle = 267.100006 pos = 31.7161,130.4269 diff = 255.399994'
});
data_peak.push({
lat: 3.1720111112e+01,
lng: 1.3051166667e+02,
cert : false,
content:' Peak = 542.500000 pos = 31.7201,130.5117 diff = 234.100006'
});
data_saddle.push({
lat: 3.1724777779e+01,
lng: 1.3049444444e+02,
content:'Saddle = 308.399994 pos = 31.7248,130.4944 diff = 234.100006'
});
data_peak.push({
lat: 3.1749111112e+01,
lng: 1.3048744444e+02,
cert : true,
content:'Name = JA6/KG-055(JA6/KG-055) peak = 543.000000 pos = 31.7491,130.4874 diff = 200.500000'
});
data_saddle.push({
lat: 3.1742111112e+01,
lng: 1.3048066667e+02,
content:'Saddle = 342.500000 pos = 31.7421,130.4807 diff = 200.500000'
});
data_peak.push({
lat: 3.1916666668e+01,
lng: 1.3105733333e+02,
cert : true,
content:'Name = JA6/MZ-125(JA6/MZ-125) peak = 374.200012 pos = 31.9167,131.0573 diff = 178.700012'
});
data_saddle.push({
lat: 3.1931111112e+01,
lng: 1.3103300000e+02,
content:'Saddle = 195.500000 pos = 31.9311,131.0330 diff = 178.700012'
});
data_peak.push({
lat: 3.3549666667e+01,
lng: 1.3066577778e+02,
cert : true,
content:'Name = JA6/FO-044(JA6/FO-044) peak = 376.899994 pos = 33.5497,130.6658 diff = 178.899994'
});
data_saddle.push({
lat: 3.3540444445e+01,
lng: 1.3065900000e+02,
content:'Saddle = 198.000000 pos = 33.5404,130.6590 diff = 178.899994'
});
data_peak.push({
lat: 3.3492777778e+01,
lng: 1.3129211111e+02,
cert : false,
content:' Peak = 403.299988 pos = 33.4928,131.2921 diff = 205.299988'
});
data_saddle.push({
lat: 3.3489666667e+01,
lng: 1.3129411111e+02,
content:'Saddle = 198.000000 pos = 33.4897,131.2941 diff = 205.299988'
});
data_peak.push({
lat: 3.1866000001e+01,
lng: 1.3100022222e+02,
cert : false,
content:' Peak = 450.399994 pos = 31.8660,131.0002 diff = 251.399994'
});
data_saddle.push({
lat: 3.1838444445e+01,
lng: 1.3100011111e+02,
content:'Saddle = 199.000000 pos = 31.8384,131.0001 diff = 251.399994'
});
data_peak.push({
lat: 3.1870111112e+01,
lng: 1.3102311111e+02,
cert : false,
content:' Peak = 430.799988 pos = 31.8701,131.0231 diff = 183.999985'
});
data_saddle.push({
lat: 3.1873444445e+01,
lng: 1.3100011111e+02,
content:'Saddle = 246.800003 pos = 31.8734,131.0001 diff = 183.999985'
});
data_peak.push({
lat: 3.3450888889e+01,
lng: 1.3147088889e+02,
cert : true,
content:'Name = Oomuresan(JA6/OT-091) peak = 417.100006 pos = 33.4509,131.4709 diff = 216.300003'
});
data_saddle.push({
lat: 3.3441111111e+01,
lng: 1.3145255556e+02,
content:'Saddle = 200.800003 pos = 33.4411,131.4526 diff = 216.300003'
});
data_peak.push({
lat: 3.2356111112e+01,
lng: 1.3154188889e+02,
cert : false,
content:' Peak = 364.200012 pos = 32.3561,131.5419 diff = 162.700012'
});
data_saddle.push({
lat: 3.2358222223e+01,
lng: 1.3153911111e+02,
content:'Saddle = 201.500000 pos = 32.3582,131.5391 diff = 162.700012'
});
data_peak.push({
lat: 3.1822555556e+01,
lng: 1.3046111111e+02,
cert : true,
content:'Name = JA6/KG-070(JA6/KG-070) peak = 504.000000 pos = 31.8226,130.4611 diff = 302.500000'
});
data_saddle.push({
lat: 3.1823888890e+01,
lng: 1.3049477778e+02,
content:'Saddle = 201.500000 pos = 31.8239,130.4948 diff = 302.500000'
});
data_peak.push({
lat: 3.1837000001e+01,
lng: 1.3049555556e+02,
cert : true,
content:'Name = JA6/KG-087(JA6/KG-087) peak = 441.600006 pos = 31.8370,130.4956 diff = 239.700012'
});
data_saddle.push({
lat: 3.1826666668e+01,
lng: 1.3048922222e+02,
content:'Saddle = 201.899994 pos = 31.8267,130.4892 diff = 239.700012'
});
data_peak.push({
lat: 3.2183666667e+01,
lng: 1.3143788889e+02,
cert : false,
content:' Peak = 372.700012 pos = 32.1837,131.4379 diff = 162.400009'
});
data_saddle.push({
lat: 3.2190111112e+01,
lng: 1.3143344444e+02,
content:'Saddle = 210.300003 pos = 32.1901,131.4334 diff = 162.400009'
});
data_peak.push({
lat: 3.3686666667e+01,
lng: 1.3064211111e+02,
cert : true,
content:'Name = JA6/FO-040(JA6/FO-040) peak = 421.600006 pos = 33.6867,130.6421 diff = 209.000000'
});
data_saddle.push({
lat: 3.3669777778e+01,
lng: 1.3063344444e+02,
content:'Saddle = 212.600006 pos = 33.6698,130.6334 diff = 209.000000'
});
data_peak.push({
lat: 3.2601555556e+01,
lng: 1.3162633333e+02,
cert : false,
content:' Peak = 406.000000 pos = 32.6016,131.6263 diff = 192.600006'
});
data_saddle.push({
lat: 3.2599333334e+01,
lng: 1.3161966667e+02,
content:'Saddle = 213.399994 pos = 32.5993,131.6197 diff = 192.600006'
});
data_peak.push({
lat: 3.2444111112e+01,
lng: 1.3153466667e+02,
cert : true,
content:'Name = JA6/MZ-114(JA6/MZ-114) peak = 491.899994 pos = 32.4441,131.5347 diff = 277.000000'
});
data_saddle.push({
lat: 3.2447444445e+01,
lng: 1.3152188889e+02,
content:'Saddle = 214.899994 pos = 32.4474,131.5219 diff = 277.000000'
});
data_peak.push({
lat: 3.2828222223e+01,
lng: 1.3160644444e+02,
cert : false,
content:' Peak = 371.899994 pos = 32.8282,131.6064 diff = 156.799988'
});
data_saddle.push({
lat: 3.2838555556e+01,
lng: 1.3159500000e+02,
content:'Saddle = 215.100006 pos = 32.8386,131.5950 diff = 156.799988'
});
data_peak.push({
lat: 3.3310000000e+01,
lng: 1.3086233333e+02,
cert : false,
content:' Peak = 404.100006 pos = 33.3100,130.8623 diff = 186.300003'
});
data_saddle.push({
lat: 3.3303555556e+01,
lng: 1.3086244444e+02,
content:'Saddle = 217.800003 pos = 33.3036,130.8624 diff = 186.300003'
});
data_peak.push({
lat: 3.3673333333e+01,
lng: 1.3061855556e+02,
cert : true,
content:'Name = JA6/FO-039(JA6/FO-039) peak = 442.200012 pos = 33.6733,130.6186 diff = 221.500015'
});
data_saddle.push({
lat: 3.3642222222e+01,
lng: 1.3062411111e+02,
content:'Saddle = 220.699997 pos = 33.6422,130.6241 diff = 221.500015'
});
data_peak.push({
lat: 3.3006777778e+01,
lng: 1.3153911111e+02,
cert : true,
content:'Name = JA6/OT-090(JA6/OT-090) peak = 423.899994 pos = 33.0068,131.5391 diff = 201.699997'
});
data_saddle.push({
lat: 3.3040333334e+01,
lng: 1.3150500000e+02,
content:'Saddle = 222.199997 pos = 33.0403,131.5050 diff = 201.699997'
});
data_peak.push({
lat: 3.2700666667e+01,
lng: 1.3175755556e+02,
cert : true,
content:'Name = JA6/MZ-098(JA6/MZ-098) peak = 644.200012 pos = 32.7007,131.7576 diff = 415.800018'
});
data_saddle.push({
lat: 3.2735777778e+01,
lng: 1.3183066667e+02,
content:'Saddle = 228.399994 pos = 32.7358,131.8307 diff = 415.800018'
});
data_peak.push({
lat: 3.2736444445e+01,
lng: 1.3177900000e+02,
cert : true,
content:'Name = JA6/MZ-101(JA6/MZ-101) peak = 621.799988 pos = 32.7364,131.7790 diff = 228.899994'
});
data_saddle.push({
lat: 3.2715444445e+01,
lng: 1.3178166667e+02,
content:'Saddle = 392.899994 pos = 32.7154,131.7817 diff = 228.899994'
});
data_peak.push({
lat: 3.3362555556e+01,
lng: 1.3086166667e+02,
cert : true,
content:'Name = JA6/OT-084(JA6/OT-084) peak = 510.000000 pos = 33.3626,130.8617 diff = 281.100006'
});
data_saddle.push({
lat: 3.3405333334e+01,
lng: 1.3084900000e+02,
content:'Saddle = 228.899994 pos = 33.4053,130.8490 diff = 281.100006'
});
data_peak.push({
lat: 3.2825222223e+01,
lng: 1.3179777778e+02,
cert : true,
content:'Name = JA6/MZ-095(JA6/MZ-095) peak = 661.700012 pos = 32.8252,131.7978 diff = 431.200012'
});
data_saddle.push({
lat: 3.2846444445e+01,
lng: 1.3172144444e+02,
content:'Saddle = 230.500000 pos = 32.8464,131.7214 diff = 431.200012'
});
data_peak.push({
lat: 3.2915444445e+01,
lng: 1.3184477778e+02,
cert : false,
content:' Peak = 420.399994 pos = 32.9154,131.8448 diff = 180.199997'
});
data_saddle.push({
lat: 3.2900222223e+01,
lng: 1.3182666667e+02,
content:'Saddle = 240.199997 pos = 32.9002,131.8267 diff = 180.199997'
});
data_peak.push({
lat: 3.2777000000e+01,
lng: 1.3176755556e+02,
cert : false,
content:' Peak = 402.200012 pos = 32.7770,131.7676 diff = 150.100006'
});
data_saddle.push({
lat: 3.2784222223e+01,
lng: 1.3176888889e+02,
content:'Saddle = 252.100006 pos = 32.7842,131.7689 diff = 150.100006'
});
data_peak.push({
lat: 3.2759444445e+01,
lng: 1.3182977778e+02,
cert : true,
content:'Name = JA6/MZ-110(JA6/MZ-110) peak = 536.200012 pos = 32.7594,131.8298 diff = 253.500000'
});
data_saddle.push({
lat: 3.2780888889e+01,
lng: 1.3184677778e+02,
content:'Saddle = 282.700012 pos = 32.7809,131.8468 diff = 253.500000'
});
data_peak.push({
lat: 3.2766555556e+01,
lng: 1.3171155556e+02,
cert : true,
content:'Name = JA6/MZ-108(JA6/MZ-108) peak = 547.400024 pos = 32.7666,131.7116 diff = 255.200012'
});
data_saddle.push({
lat: 3.2783444445e+01,
lng: 1.3171577778e+02,
content:'Saddle = 292.200012 pos = 32.7834,131.7158 diff = 255.200012'
});
data_peak.push({
lat: 3.2857888889e+01,
lng: 1.3192244444e+02,
cert : true,
content:'Name = JA6/OT-069(JA6/OT-069) peak = 588.299988 pos = 32.8579,131.9224 diff = 247.099976'
});
data_saddle.push({
lat: 3.2830888889e+01,
lng: 1.3191700000e+02,
content:'Saddle = 341.200012 pos = 32.8309,131.9170 diff = 247.099976'
});
data_peak.push({
lat: 3.2904333334e+01,
lng: 1.3196333333e+02,
cert : true,
content:'Name = JA6/OT-071(JA6/OT-071) peak = 580.900024 pos = 32.9043,131.9633 diff = 178.500031'
});
data_saddle.push({
lat: 3.2883333334e+01,
lng: 1.3194711111e+02,
content:'Saddle = 402.399994 pos = 32.8833,131.9471 diff = 178.500031'
});
data_peak.push({
lat: 3.2823333334e+01,
lng: 1.3185533333e+02,
cert : true,
content:'Name = JA6/MZ-096(JA6/MZ-096) peak = 658.700012 pos = 32.8233,131.8553 diff = 195.400024'
});
data_saddle.push({
lat: 3.2825000000e+01,
lng: 1.3182800000e+02,
content:'Saddle = 463.299988 pos = 32.8250,131.8280 diff = 195.400024'
});
data_peak.push({
lat: 3.2372555556e+01,
lng: 1.3147577778e+02,
cert : true,
content:'Name = JA6/MZ-123(JA6/MZ-123) peak = 416.399994 pos = 32.3726,131.4758 diff = 183.099991'
});
data_saddle.push({
lat: 3.2384666667e+01,
lng: 1.3146344444e+02,
content:'Saddle = 233.300003 pos = 32.3847,131.4634 diff = 183.099991'
});
data_peak.push({
lat: 3.1776666668e+01,
lng: 1.3051366667e+02,
cert : true,
content:'Name = JA6/KG-095(JA6/KG-095) peak = 421.200012 pos = 31.7767,130.5137 diff = 184.500015'
});
data_saddle.push({
lat: 3.1779000001e+01,
lng: 1.3051122222e+02,
content:'Saddle = 236.699997 pos = 31.7790,130.5112 diff = 184.500015'
});
data_peak.push({
lat: 3.1874888890e+01,
lng: 1.3060600000e+02,
cert : true,
content:'Name = JA6/KG-028(JA6/KG-028) peak = 702.099976 pos = 31.8749,130.6060 diff = 464.499969'
});
data_saddle.push({
lat: 3.1925555556e+01,
lng: 1.3072577778e+02,
content:'Saddle = 237.600006 pos = 31.9256,130.7258 diff = 464.499969'
});
data_peak.push({
lat: 3.1766222223e+01,
lng: 1.3050877778e+02,
cert : true,
content:'Name = JA6/KG-079(JA6/KG-079) peak = 474.200012 pos = 31.7662,130.5088 diff = 236.400009'
});
data_saddle.push({
lat: 3.1807333334e+01,
lng: 1.3050977778e+02,
content:'Saddle = 237.800003 pos = 31.8073,130.5098 diff = 236.400009'
});
data_peak.push({
lat: 3.1788111112e+01,
lng: 1.3051200000e+02,
cert : false,
content:' Peak = 401.899994 pos = 31.7881,130.5120 diff = 150.299988'
});
data_saddle.push({
lat: 3.1789444445e+01,
lng: 1.3050811111e+02,
content:'Saddle = 251.600006 pos = 31.7894,130.5081 diff = 150.299988'
});
data_peak.push({
lat: 3.1785111112e+01,
lng: 1.3049211111e+02,
cert : false,
content:' Peak = 423.500000 pos = 31.7851,130.4921 diff = 161.200012'
});
data_saddle.push({
lat: 3.1784666668e+01,
lng: 1.3049633333e+02,
content:'Saddle = 262.299988 pos = 31.7847,130.4963 diff = 161.200012'
});
data_peak.push({
lat: 3.1794000001e+01,
lng: 1.3050766667e+02,
cert : false,
content:' Peak = 453.700012 pos = 31.7940,130.5077 diff = 151.000000'
});
data_saddle.push({
lat: 3.1779000001e+01,
lng: 1.3050288889e+02,
content:'Saddle = 302.700012 pos = 31.7790,130.5029 diff = 151.000000'
});
data_peak.push({
lat: 3.1989000001e+01,
lng: 1.3054177778e+02,
cert : true,
content:'Name = JA6/KG-089(JA6/KG-089) peak = 436.299988 pos = 31.9890,130.5418 diff = 187.999985'
});
data_saddle.push({
lat: 3.1962222223e+01,
lng: 1.3055233333e+02,
content:'Saddle = 248.300003 pos = 31.9622,130.5523 diff = 187.999985'
});
data_peak.push({
lat: 3.1808888890e+01,
lng: 1.3051466667e+02,
cert : false,
content:' Peak = 421.500000 pos = 31.8089,130.5147 diff = 164.700012'
});
data_saddle.push({
lat: 3.1818333334e+01,
lng: 1.3051144444e+02,
content:'Saddle = 256.799988 pos = 31.8183,130.5114 diff = 164.700012'
});
data_peak.push({
lat: 3.1833888890e+01,
lng: 1.3053511111e+02,
cert : false,
content:' Peak = 515.099976 pos = 31.8339,130.5351 diff = 217.099976'
});
data_saddle.push({
lat: 3.1847111112e+01,
lng: 1.3054333333e+02,
content:'Saddle = 298.000000 pos = 31.8471,130.5433 diff = 217.099976'
});
data_peak.push({
lat: 3.1927888890e+01,
lng: 1.3063677778e+02,
cert : true,
content:'Name = JA6/KG-037(JA6/KG-037) peak = 647.900024 pos = 31.9279,130.6368 diff = 300.400024'
});
data_saddle.push({
lat: 3.1898111112e+01,
lng: 1.3062755556e+02,
content:'Saddle = 347.500000 pos = 31.8981,130.6276 diff = 300.400024'
});
data_peak.push({
lat: 3.1909888890e+01,
lng: 1.3060622222e+02,
cert : true,
content:'Name = Chayagaoka(JA6/KG-054) peak = 564.000000 pos = 31.9099,130.6062 diff = 186.799988'
});
data_saddle.push({
lat: 3.1887222223e+01,
lng: 1.3062188889e+02,
content:'Saddle = 377.200012 pos = 31.8872,130.6219 diff = 186.799988'
});
data_peak.push({
lat: 3.1902555556e+01,
lng: 1.3058233333e+02,
cert : false,
content:' Peak = 650.700012 pos = 31.9026,130.5823 diff = 217.900024'
});
data_saddle.push({
lat: 3.1898444445e+01,
lng: 1.3058233333e+02,
content:'Saddle = 432.799988 pos = 31.8984,130.5823 diff = 217.900024'
});
data_peak.push({
lat: 3.1856666668e+01,
lng: 1.3057488889e+02,
cert : false,
content:' Peak = 665.299988 pos = 31.8567,130.5749 diff = 187.599976'
});
data_saddle.push({
lat: 3.1872222223e+01,
lng: 1.3057566667e+02,
content:'Saddle = 477.700012 pos = 31.8722,130.5757 diff = 187.599976'
});
data_peak.push({
lat: 3.1846444445e+01,
lng: 1.3063466667e+02,
cert : true,
content:'Name = JA6/KG-031(JA6/KG-031) peak = 681.099976 pos = 31.8464,130.6347 diff = 168.399963'
});
data_saddle.push({
lat: 3.1866888890e+01,
lng: 1.3061700000e+02,
content:'Saddle = 512.700012 pos = 31.8669,130.6170 diff = 168.399963'
});
data_peak.push({
lat: 3.2451000001e+01,
lng: 1.3150055556e+02,
cert : false,
content:' Peak = 722.900024 pos = 32.4510,131.5006 diff = 485.300018'
});
data_saddle.push({
lat: 3.2477222223e+01,
lng: 1.3143400000e+02,
content:'Saddle = 237.600006 pos = 32.4772,131.4340 diff = 485.300018'
});
data_peak.push({
lat: 3.2483555556e+01,
lng: 1.3148711111e+02,
cert : true,
content:'Name = JA6/MZ-119(JA6/MZ-119) peak = 463.700012 pos = 32.4836,131.4871 diff = 161.800018'
});
data_saddle.push({
lat: 3.2478000001e+01,
lng: 1.3148366667e+02,
content:'Saddle = 301.899994 pos = 32.4780,131.4837 diff = 161.800018'
});
data_peak.push({
lat: 3.2492222223e+01,
lng: 1.3152988889e+02,
cert : true,
content:'Name = JA6/MZ-097(JA6/MZ-097) peak = 652.299988 pos = 32.4922,131.5299 diff = 246.799988'
});
data_saddle.push({
lat: 3.2487222223e+01,
lng: 1.3150955556e+02,
content:'Saddle = 405.500000 pos = 32.4872,131.5096 diff = 246.799988'
});
data_peak.push({
lat: 3.2487777778e+01,
lng: 1.3150388889e+02,
cert : true,
content:'Name = JA6/MZ-104(JA6/MZ-104) peak = 590.200012 pos = 32.4878,131.5039 diff = 157.200012'
});
data_saddle.push({
lat: 3.2484888889e+01,
lng: 1.3151011111e+02,
content:'Saddle = 433.000000 pos = 32.4849,131.5101 diff = 157.200012'
});
data_peak.push({
lat: 3.2584888889e+01,
lng: 1.3077766667e+02,
cert : true,
content:'Name = JA6/KM-053(JA6/KM-053) peak = 562.500000 pos = 32.5849,130.7777 diff = 324.700012'
});
data_saddle.push({
lat: 3.2575333334e+01,
lng: 1.3079822222e+02,
content:'Saddle = 237.800003 pos = 32.5753,130.7982 diff = 324.700012'
});
data_peak.push({
lat: 3.2563000001e+01,
lng: 1.3075188889e+02,
cert : false,
content:' Peak = 477.100006 pos = 32.5630,130.7519 diff = 181.399994'
});
data_saddle.push({
lat: 3.2573000001e+01,
lng: 1.3075844444e+02,
content:'Saddle = 295.700012 pos = 32.5730,130.7584 diff = 181.399994'
});
data_peak.push({
lat: 3.2785666667e+01,
lng: 1.3162966667e+02,
cert : true,
content:'Name = JA6/OT-042(JA6/OT-042) peak = 742.700012 pos = 32.7857,131.6297 diff = 504.600006'
});
data_saddle.push({
lat: 3.2868000000e+01,
lng: 1.3171000000e+02,
content:'Saddle = 238.100006 pos = 32.8680,131.7100 diff = 504.600006'
});
data_peak.push({
lat: 3.2768333334e+01,
lng: 1.3167066667e+02,
cert : true,
content:'Name = JA6/MZ-085(JA6/MZ-085) peak = 730.900024 pos = 32.7683,131.6707 diff = 229.300018'
});
data_saddle.push({
lat: 3.2784111112e+01,
lng: 1.3164933333e+02,
content:'Saddle = 501.600006 pos = 32.7841,131.6493 diff = 229.300018'
});
data_peak.push({
lat: 3.3496111111e+01,
lng: 1.3122666667e+02,
cert : true,
content:'Name = JA6/OT-052(JA6/OT-052) peak = 652.900024 pos = 33.4961,131.2267 diff = 405.400024'
});
data_saddle.push({
lat: 3.3476333334e+01,
lng: 1.3124066667e+02,
content:'Saddle = 247.500000 pos = 33.4763,131.2407 diff = 405.400024'
});
data_peak.push({
lat: 3.2673222223e+01,
lng: 1.3084722222e+02,
cert : true,
content:'Name = JA6/KM-068(JA6/KM-068) peak = 461.200012 pos = 32.6732,130.8472 diff = 212.100006'
});
data_saddle.push({
lat: 3.2679444445e+01,
lng: 1.3084866667e+02,
content:'Saddle = 249.100006 pos = 32.6794,130.8487 diff = 212.100006'
});
data_peak.push({
lat: 3.2527666667e+01,
lng: 1.3068644444e+02,
cert : true,
content:'Name = JA6/KM-055(JA6/KM-055) peak = 541.299988 pos = 32.5277,130.6864 diff = 283.599976'
});
data_saddle.push({
lat: 3.2520555556e+01,
lng: 1.3068755556e+02,
content:'Saddle = 257.700012 pos = 32.5206,130.6876 diff = 283.599976'
});
data_peak.push({
lat: 3.3409666667e+01,
lng: 1.3075944444e+02,
cert : true,
content:'Name = JA6/FO-037(JA6/FO-037) peak = 461.000000 pos = 33.4097,130.7594 diff = 198.200012'
});
data_saddle.push({
lat: 3.3393000000e+01,
lng: 1.3078055556e+02,
content:'Saddle = 262.799988 pos = 33.3930,130.7806 diff = 198.200012'
});
data_peak.push({
lat: 3.3472444445e+01,
lng: 1.3129233333e+02,
cert : true,
content:'Name = JA6/OT-073(JA6/OT-073) peak = 573.700012 pos = 33.4724,131.2923 diff = 306.700012'
});
data_saddle.push({
lat: 3.3450777778e+01,
lng: 1.3129733333e+02,
content:'Saddle = 267.000000 pos = 33.4508,131.2973 diff = 306.700012'
});
data_peak.push({
lat: 3.3484555556e+01,
lng: 1.3130122222e+02,
cert : true,
content:'Name = JA6/OT-080(JA6/OT-080) peak = 537.900024 pos = 33.4846,131.3012 diff = 261.700012'
});
data_saddle.push({
lat: 3.3477555556e+01,
lng: 1.3129966667e+02,
content:'Saddle = 276.200012 pos = 33.4776,131.2997 diff = 261.700012'
});
data_peak.push({
lat: 3.3481666667e+01,
lng: 1.3132233333e+02,
cert : false,
content:' Peak = 443.600006 pos = 33.4817,131.3223 diff = 164.899994'
});
data_saddle.push({
lat: 3.3482888889e+01,
lng: 1.3131777778e+02,
content:'Saddle = 278.700012 pos = 33.4829,131.3178 diff = 164.899994'
});
data_peak.push({
lat: 3.3476000000e+01,
lng: 1.3127811111e+02,
cert : false,
content:' Peak = 477.500000 pos = 33.4760,131.2781 diff = 168.799988'
});
data_saddle.push({
lat: 3.3473222222e+01,
lng: 1.3128211111e+02,
content:'Saddle = 308.700012 pos = 33.4732,131.2821 diff = 168.799988'
});
data_peak.push({
lat: 3.3051888889e+01,
lng: 1.3180522222e+02,
cert : true,
content:'Name = JA6/OT-047(JA6/OT-047) peak = 714.200012 pos = 33.0519,131.8052 diff = 446.100006'
});
data_saddle.push({
lat: 3.3000111112e+01,
lng: 1.3177622222e+02,
content:'Saddle = 268.100006 pos = 33.0001,131.7762 diff = 446.100006'
});
data_peak.push({
lat: 3.3010111112e+01,
lng: 1.3176455556e+02,
cert : true,
content:'Name = JA6/OT-075(JA6/OT-075) peak = 563.900024 pos = 33.0101,131.7646 diff = 290.300018'
});
data_saddle.push({
lat: 3.3016111112e+01,
lng: 1.3178433333e+02,
content:'Saddle = 273.600006 pos = 33.0161,131.7843 diff = 290.300018'
});
data_peak.push({
lat: 3.3041666667e+01,
lng: 1.3188955556e+02,
cert : true,
content:'Name = JA6/OT-057(JA6/OT-057) peak = 636.400024 pos = 33.0417,131.8896 diff = 245.600037'
});
data_saddle.push({
lat: 3.3041555556e+01,
lng: 1.3187333333e+02,
content:'Saddle = 390.799988 pos = 33.0416,131.8733 diff = 245.600037'
});
data_peak.push({
lat: 3.3065000000e+01,
lng: 1.3178355556e+02,
cert : true,
content:'Name = JA6/OT-062(JA6/OT-062) peak = 611.799988 pos = 33.0650,131.7836 diff = 205.399994'
});
data_saddle.push({
lat: 3.3057555556e+01,
lng: 1.3179000000e+02,
content:'Saddle = 406.399994 pos = 33.0576,131.7900 diff = 205.399994'
});
data_peak.push({
lat: 3.3011888889e+01,
lng: 1.3184055556e+02,
cert : true,
content:'Name = JA6/OT-056(JA6/OT-056) peak = 640.599976 pos = 33.0119,131.8406 diff = 212.699982'
});
data_saddle.push({
lat: 3.3043666667e+01,
lng: 1.3183244444e+02,
content:'Saddle = 427.899994 pos = 33.0437,131.8324 diff = 212.699982'
});
data_peak.push({
lat: 3.1891888890e+01,
lng: 1.3036500000e+02,
cert : false,
content:' Peak = 431.399994 pos = 31.8919,130.3650 diff = 161.899994'
});
data_saddle.push({
lat: 3.1914666668e+01,
lng: 1.3037344444e+02,
content:'Saddle = 269.500000 pos = 31.9147,130.3734 diff = 161.899994'
});
data_peak.push({
lat: 3.3477111111e+01,
lng: 1.3120577778e+02,
cert : true,
content:'Name = JA6/OT-086(JA6/OT-086) peak = 481.899994 pos = 33.4771,131.2058 diff = 208.699982'
});
data_saddle.push({
lat: 3.3471888889e+01,
lng: 1.3120833333e+02,
content:'Saddle = 273.200012 pos = 33.4719,131.2083 diff = 208.699982'
});
data_peak.push({
lat: 3.3171333334e+01,
lng: 1.3067988889e+02,
cert : true,
content:'Name = JA6/KM-050(JA6/KM-050) peak = 594.000000 pos = 33.1713,130.6799 diff = 317.399994'
});
data_saddle.push({
lat: 3.3163333334e+01,
lng: 1.3069011111e+02,
content:'Saddle = 276.600006 pos = 33.1633,130.6901 diff = 317.399994'
});
data_peak.push({
lat: 3.3471888889e+01,
lng: 1.3123133333e+02,
cert : false,
content:' Peak = 430.799988 pos = 33.4719,131.2313 diff = 153.000000'
});
data_saddle.push({
lat: 3.3462555556e+01,
lng: 1.3124333333e+02,
content:'Saddle = 277.799988 pos = 33.4626,131.2433 diff = 153.000000'
});
data_peak.push({
lat: 3.2740000001e+01,
lng: 1.3082755556e+02,
cert : false,
content:' Peak = 433.899994 pos = 32.7400,130.8276 diff = 155.899994'
});
data_saddle.push({
lat: 3.2750111112e+01,
lng: 1.3084600000e+02,
content:'Saddle = 278.000000 pos = 32.7501,130.8460 diff = 155.899994'
});
data_peak.push({
lat: 3.2936000000e+01,
lng: 1.3175888889e+02,
cert : false,
content:' Peak = 604.799988 pos = 32.9360,131.7589 diff = 322.000000'
});
data_saddle.push({
lat: 3.2882333334e+01,
lng: 1.3169144444e+02,
content:'Saddle = 282.799988 pos = 32.8823,131.6914 diff = 322.000000'
});
data_peak.push({
lat: 3.3660444445e+01,
lng: 1.3058144444e+02,
cert : true,
content:'Name = JA6/FO-018(JA6/FO-018) peak = 681.500000 pos = 33.6604,130.5814 diff = 394.600006'
});
data_saddle.push({
lat: 3.3623555556e+01,
lng: 1.3059055556e+02,
content:'Saddle = 286.899994 pos = 33.6236,130.5906 diff = 394.600006'
});
data_peak.push({
lat: 3.3720333333e+01,
lng: 1.3055922222e+02,
cert : true,
content:'Name = JA6/FO-021(JA6/FO-021) peak = 642.099976 pos = 33.7203,130.5592 diff = 274.199982'
});
data_saddle.push({
lat: 3.3675000000e+01,
lng: 1.3054400000e+02,
content:'Saddle = 367.899994 pos = 33.6750,130.5440 diff = 274.199982'
});
data_peak.push({
lat: 3.3674222222e+01,
lng: 1.3056455556e+02,
cert : true,
content:'Name = JA6/FO-023(JA6/FO-023) peak = 623.299988 pos = 33.6742,130.5646 diff = 164.899994'
});
data_saddle.push({
lat: 3.3663111111e+01,
lng: 1.3057044444e+02,
content:'Saddle = 458.399994 pos = 33.6631,130.5704 diff = 164.899994'
});
data_peak.push({
lat: 3.3555666667e+01,
lng: 1.3058377778e+02,
cert : true,
content:'Name = Sangunzan(JA6/FO-004) peak = 930.200012 pos = 33.5557,130.5838 diff = 642.099976'
});
data_saddle.push({
lat: 3.3510222222e+01,
lng: 1.3062055556e+02,
content:'Saddle = 288.100006 pos = 33.5102,130.6206 diff = 642.099976'
});
data_peak.push({
lat: 3.3615555556e+01,
lng: 1.3061244444e+02,
cert : true,
content:'Name = JA6/FO-025(JA6/FO-025) peak = 611.500000 pos = 33.6156,130.6124 diff = 302.399994'
});
data_saddle.push({
lat: 3.3596777778e+01,
lng: 1.3058100000e+02,
content:'Saddle = 309.100006 pos = 33.5968,130.5810 diff = 302.399994'
});
data_peak.push({
lat: 3.3545222222e+01,
lng: 1.3062388889e+02,
cert : false,
content:' Peak = 482.500000 pos = 33.5452,130.6239 diff = 150.500000'
});
data_saddle.push({
lat: 3.3538444445e+01,
lng: 1.3061800000e+02,
content:'Saddle = 332.000000 pos = 33.5384,130.6180 diff = 150.500000'
});
data_peak.push({
lat: 3.3519555556e+01,
lng: 1.3060866667e+02,
cert : true,
content:'Name = JA6/FO-020(JA6/FO-020) peak = 651.400024 pos = 33.5196,130.6087 diff = 304.100037'
});
data_saddle.push({
lat: 3.3537666667e+01,
lng: 1.3059866667e+02,
content:'Saddle = 347.299988 pos = 33.5377,130.5987 diff = 304.100037'
});
data_peak.push({
lat: 3.3597888889e+01,
lng: 1.3054455556e+02,
cert : false,
content:' Peak = 680.700012 pos = 33.5979,130.5446 diff = 183.000000'
});
data_saddle.push({
lat: 3.3596000000e+01,
lng: 1.3056033333e+02,
content:'Saddle = 497.700012 pos = 33.5960,130.5603 diff = 183.000000'
});
data_peak.push({
lat: 3.2299333334e+01,
lng: 1.3142655556e+02,
cert : true,
content:'Name = Osuzuyama(JA6/MZ-019) peak = 1404.500000 pos = 32.2993,131.4266 diff = 1115.699951'
});
data_saddle.push({
lat: 3.2341555556e+01,
lng: 1.3141544444e+02,
content:'Saddle = 288.799988 pos = 32.3416,131.4154 diff = 1115.699951'
});
data_peak.push({
lat: 3.2199777778e+01,
lng: 1.3142433333e+02,
cert : false,
content:' Peak = 464.399994 pos = 32.1998,131.4243 diff = 172.100006'
});
data_saddle.push({
lat: 3.2210111112e+01,
lng: 1.3142911111e+02,
content:'Saddle = 292.299988 pos = 32.2101,131.4291 diff = 172.100006'
});
data_peak.push({
lat: 3.2295888890e+01,
lng: 1.3149711111e+02,
cert : true,
content:'Name = Hatakurayama(JA6/MZ-069) peak = 847.599976 pos = 32.2959,131.4971 diff = 155.799988'
});
data_saddle.push({
lat: 3.2298333334e+01,
lng: 1.3148633333e+02,
content:'Saddle = 691.799988 pos = 32.2983,131.4863 diff = 155.799988'
});
data_peak.push({
lat: 3.2237555556e+01,
lng: 1.3144300000e+02,
cert : true,
content:'Name = JA6/MZ-066(JA6/MZ-066) peak = 896.200012 pos = 32.2376,131.4430 diff = 169.700012'
});
data_saddle.push({
lat: 3.2242555556e+01,
lng: 1.3143833333e+02,
content:'Saddle = 726.500000 pos = 32.2426,131.4383 diff = 169.700012'
});
data_peak.push({
lat: 3.2295666667e+01,
lng: 1.3138377778e+02,
cert : false,
content:' Peak = 904.400024 pos = 32.2957,131.3838 diff = 153.200012'
});
data_saddle.push({
lat: 3.2294666667e+01,
lng: 1.3139244444e+02,
content:'Saddle = 751.200012 pos = 32.2947,131.3924 diff = 153.200012'
});
data_peak.push({
lat: 3.2309666667e+01,
lng: 1.3148388889e+02,
cert : false,
content:' Peak = 931.900024 pos = 32.3097,131.4839 diff = 156.100037'
});
data_saddle.push({
lat: 3.2315000001e+01,
lng: 1.3147688889e+02,
content:'Saddle = 775.799988 pos = 32.3150,131.4769 diff = 156.100037'
});
data_peak.push({
lat: 3.3093555556e+01,
lng: 1.3072888889e+02,
cert : true,
content:'Name = JA6/KM-047(JA6/KM-047) peak = 643.299988 pos = 33.0936,130.7289 diff = 346.799988'
});
data_saddle.push({
lat: 3.3087555556e+01,
lng: 1.3074622222e+02,
content:'Saddle = 296.500000 pos = 33.0876,130.7462 diff = 346.799988'
});
data_peak.push({
lat: 3.3493111111e+01,
lng: 1.3061033333e+02,
cert : true,
content:'Name = JA6/FO-035(JA6/FO-035) peak = 495.299988 pos = 33.4931,130.6103 diff = 198.000000'
});
data_saddle.push({
lat: 3.3500111111e+01,
lng: 1.3061444444e+02,
content:'Saddle = 297.299988 pos = 33.5001,130.6144 diff = 198.000000'
});
data_peak.push({
lat: 3.2946666667e+01,
lng: 1.3140933333e+02,
cert : false,
content:' Peak = 451.000000 pos = 32.9467,131.4093 diff = 150.100006'
});
data_saddle.push({
lat: 3.2939666667e+01,
lng: 1.3138422222e+02,
content:'Saddle = 300.899994 pos = 32.9397,131.3842 diff = 150.100006'
});
data_peak.push({
lat: 3.3455111111e+01,
lng: 1.3114188889e+02,
cert : true,
content:'Name = JA6/OT-076(JA6/OT-076) peak = 553.799988 pos = 33.4551,131.1419 diff = 247.299988'
});
data_saddle.push({
lat: 3.3446333334e+01,
lng: 1.3115411111e+02,
content:'Saddle = 306.500000 pos = 33.4463,131.1541 diff = 247.299988'
});
data_peak.push({
lat: 3.1934111112e+01,
lng: 1.3086177778e+02,
cert : true,
content:'Name = Kirishimayama (Karakunidake)(JA6/KG-003) peak = 1700.000000 pos = 31.9341,130.8618 diff = 1388.900024'
});
data_saddle.push({
lat: 3.2014555556e+01,
lng: 1.3090477778e+02,
content:'Saddle = 311.100006 pos = 32.0146,130.9048 diff = 1388.900024'
});
data_peak.push({
lat: 3.1485888890e+01,
lng: 1.3081900000e+02,
cert : true,
content:'Name = Takakumayama (Oonogaradake)(JA6/KG-006) peak = 1232.199951 pos = 31.4859,130.8190 diff = 870.499939'
});
data_saddle.push({
lat: 3.1833888890e+01,
lng: 1.3087488889e+02,
content:'Saddle = 361.700012 pos = 31.8339,130.8749 diff = 870.499939'
});
data_peak.push({
lat: 3.1828777779e+01,
lng: 1.3088755556e+02,
cert : false,
content:' Peak = 574.000000 pos = 31.8288,130.8876 diff = 206.600006'
});
data_saddle.push({
lat: 3.1779888890e+01,
lng: 1.3089222222e+02,
content:'Saddle = 367.399994 pos = 31.7799,130.8922 diff = 206.600006'
});
data_peak.push({
lat: 3.1728222223e+01,
lng: 1.3090111111e+02,
cert : false,
content:' Peak = 604.500000 pos = 31.7282,130.9011 diff = 221.899994'
});
data_saddle.push({
lat: 3.1669111112e+01,
lng: 1.3084388889e+02,
content:'Saddle = 382.600006 pos = 31.6691,130.8439 diff = 221.899994'
});
data_peak.push({
lat: 3.1767222223e+01,
lng: 1.3087800000e+02,
cert : false,
content:' Peak = 570.299988 pos = 31.7672,130.8780 diff = 158.199982'
});
data_saddle.push({
lat: 3.1743888890e+01,
lng: 1.3086722222e+02,
content:'Saddle = 412.100006 pos = 31.7439,130.8672 diff = 158.199982'
});
data_peak.push({
lat: 3.1546111112e+01,
lng: 1.3078755556e+02,
cert : true,
content:'Name = JA6/KG-020(JA6/KG-020) peak = 881.900024 pos = 31.5461,130.7876 diff = 350.300049'
});
data_saddle.push({
lat: 3.1524666668e+01,
lng: 1.3077111111e+02,
content:'Saddle = 531.599976 pos = 31.5247,130.7711 diff = 350.300049'
});
data_peak.push({
lat: 3.1506555557e+01,
lng: 1.3079811111e+02,
cert : true,
content:'Name = JA6/KG-021(JA6/KG-021) peak = 881.000000 pos = 31.5066,130.7981 diff = 173.400024'
});
data_saddle.push({
lat: 3.1500777779e+01,
lng: 1.3080622222e+02,
content:'Saddle = 707.599976 pos = 31.5008,130.8062 diff = 173.400024'
});
data_peak.push({
lat: 3.1461888890e+01,
lng: 1.3079466667e+02,
cert : false,
content:' Peak = 1101.500000 pos = 31.4619,130.7947 diff = 163.299988'
});
data_saddle.push({
lat: 3.1464222223e+01,
lng: 1.3080011111e+02,
content:'Saddle = 938.200012 pos = 31.4642,130.8001 diff = 163.299988'
});
data_peak.push({
lat: 3.1460333334e+01,
lng: 1.3082055556e+02,
cert : false,
content:' Peak = 1181.000000 pos = 31.4603,130.8206 diff = 178.500000'
});
data_saddle.push({
lat: 3.1464444445e+01,
lng: 1.3081477778e+02,
content:'Saddle = 1002.500000 pos = 31.4644,130.8148 diff = 178.500000'
});
data_peak.push({
lat: 3.1981666667e+01,
lng: 1.3079622222e+02,
cert : true,
content:'Name = JA6/MZ-071(JA6/MZ-071) peak = 846.200012 pos = 31.9817,130.7962 diff = 206.799988'
});
data_saddle.push({
lat: 3.1974333334e+01,
lng: 1.3079522222e+02,
content:'Saddle = 639.400024 pos = 31.9743,130.7952 diff = 206.799988'
});
data_peak.push({
lat: 3.1954666667e+01,
lng: 1.3079166667e+02,
cert : true,
content:'Name = JA6/KG-009(JA6/KG-009) peak = 1101.599976 pos = 31.9547,130.7917 diff = 159.299988'
});
data_saddle.push({
lat: 3.1947777779e+01,
lng: 1.3080777778e+02,
content:'Saddle = 942.299988 pos = 31.9478,130.8078 diff = 159.299988'
});
data_peak.push({
lat: 3.1950777779e+01,
lng: 1.3090844444e+02,
cert : false,
content:' Peak = 1340.800049 pos = 31.9508,130.9084 diff = 188.600098'
});
data_saddle.push({
lat: 3.1945444445e+01,
lng: 1.3090777778e+02,
content:'Saddle = 1152.199951 pos = 31.9454,130.9078 diff = 188.600098'
});
data_peak.push({
lat: 3.3252000000e+01,
lng: 1.3152400000e+02,
cert : true,
content:'Name = JA6/OT-059(JA6/OT-059) peak = 627.700012 pos = 33.2520,131.5240 diff = 315.600006'
});
data_saddle.push({
lat: 3.3252111111e+01,
lng: 1.3151066667e+02,
content:'Saddle = 312.100006 pos = 33.2521,131.5107 diff = 315.600006'
});
data_peak.push({
lat: 3.3546666667e+01,
lng: 1.3088677778e+02,
cert : false,
content:' Peak = 512.000000 pos = 33.5467,130.8868 diff = 194.899994'
});
data_saddle.push({
lat: 3.3541777778e+01,
lng: 1.3088488889e+02,
content:'Saddle = 317.100006 pos = 33.5418,130.8849 diff = 194.899994'
});
data_peak.push({
lat: 3.2664111112e+01,
lng: 1.3087611111e+02,
cert : true,
content:'Name = JA6/KM-039(JA6/KM-039) peak = 751.799988 pos = 32.6641,130.8761 diff = 424.399994'
});
data_saddle.push({
lat: 3.2686777778e+01,
lng: 1.3086855556e+02,
content:'Saddle = 327.399994 pos = 32.6868,130.8686 diff = 424.399994'
});
data_peak.push({
lat: 3.3451666667e+01,
lng: 1.3116555556e+02,
cert : true,
content:'Name = JA6/OT-058(JA6/OT-058) peak = 630.299988 pos = 33.4517,131.1656 diff = 293.399994'
});
data_saddle.push({
lat: 3.3437555556e+01,
lng: 1.3116333333e+02,
content:'Saddle = 336.899994 pos = 33.4376,131.1633 diff = 293.399994'
});
data_peak.push({
lat: 3.3389555556e+01,
lng: 1.3149588889e+02,
cert : true,
content:'Name = JA6/OT-060(JA6/OT-060) peak = 622.599976 pos = 33.3896,131.4959 diff = 285.099976'
});
data_saddle.push({
lat: 3.3373888889e+01,
lng: 1.3145866667e+02,
content:'Saddle = 337.500000 pos = 33.3739,131.4587 diff = 285.099976'
});
data_peak.push({
lat: 3.2123000001e+01,
lng: 1.3040066667e+02,
cert : true,
content:'Name = Yahazudake(JA6/KG-030) peak = 684.400024 pos = 32.1230,130.4007 diff = 346.100037'
});
data_saddle.push({
lat: 3.2117888890e+01,
lng: 1.3041600000e+02,
content:'Saddle = 338.299988 pos = 32.1179,130.4160 diff = 346.100037'
});
data_peak.push({
lat: 3.3462111111e+01,
lng: 1.3121077778e+02,
cert : true,
content:'Name = JA6/OT-074(JA6/OT-074) peak = 570.299988 pos = 33.4621,131.2108 diff = 222.799988'
});
data_saddle.push({
lat: 3.3448777778e+01,
lng: 1.3122766667e+02,
content:'Saddle = 347.500000 pos = 33.4488,131.2277 diff = 222.799988'
});
data_peak.push({
lat: 3.3464555556e+01,
lng: 1.3119788889e+02,
cert : false,
content:' Peak = 521.299988 pos = 33.4646,131.1979 diff = 159.399994'
});
data_saddle.push({
lat: 3.3462444445e+01,
lng: 1.3120277778e+02,
content:'Saddle = 361.899994 pos = 33.4624,131.2028 diff = 159.399994'
});
data_peak.push({
lat: 3.2181666667e+01,
lng: 1.3049444444e+02,
cert : false,
content:' Peak = 543.500000 pos = 32.1817,130.4944 diff = 172.000000'
});
data_saddle.push({
lat: 3.2188777779e+01,
lng: 1.3050622222e+02,
content:'Saddle = 371.500000 pos = 32.1888,130.5062 diff = 172.000000'
});
data_peak.push({
lat: 3.3472666667e+01,
lng: 1.3111500000e+02,
cert : false,
content:' Peak = 530.099976 pos = 33.4727,131.1150 diff = 157.699982'
});
data_saddle.push({
lat: 3.3480666667e+01,
lng: 1.3111233333e+02,
content:'Saddle = 372.399994 pos = 33.4807,131.1123 diff = 157.699982'
});
data_peak.push({
lat: 3.2205888890e+01,
lng: 1.3133422222e+02,
cert : true,
content:'Name = JA6/MZ-109(JA6/MZ-109) peak = 540.599976 pos = 32.2059,131.3342 diff = 167.899963'
});
data_saddle.push({
lat: 3.2227000001e+01,
lng: 1.3133888889e+02,
content:'Saddle = 372.700012 pos = 32.2270,131.3389 diff = 167.899963'
});
data_peak.push({
lat: 3.2533222223e+01,
lng: 1.3144488889e+02,
cert : false,
content:' Peak = 537.099976 pos = 32.5332,131.4449 diff = 155.999969'
});
data_saddle.push({
lat: 3.2538888889e+01,
lng: 1.3144866667e+02,
content:'Saddle = 381.100006 pos = 32.5389,131.4487 diff = 155.999969'
});
data_peak.push({
lat: 3.1980888890e+01,
lng: 1.3036755556e+02,
cert : true,
content:'Name = Shibisan (Jyougusan)(JA6/KG-010) peak = 1066.300049 pos = 31.9809,130.3676 diff = 677.900024'
});
data_saddle.push({
lat: 3.2011333334e+01,
lng: 1.3044066667e+02,
content:'Saddle = 388.399994 pos = 32.0113,130.4407 diff = 677.900024'
});
data_peak.push({
lat: 3.2031000001e+01,
lng: 1.3039800000e+02,
cert : false,
content:' Peak = 552.200012 pos = 32.0310,130.3980 diff = 150.300018'
});
data_saddle.push({
lat: 3.2013666667e+01,
lng: 1.3040900000e+02,
content:'Saddle = 401.899994 pos = 32.0137,130.4090 diff = 150.300018'
});
data_peak.push({
lat: 3.1967444445e+01,
lng: 1.3026788889e+02,
cert : true,
content:'Name = JA6/KG-046(JA6/KG-046) peak = 603.500000 pos = 31.9674,130.2679 diff = 190.399994'
});
data_saddle.push({
lat: 3.1955000001e+01,
lng: 1.3028400000e+02,
content:'Saddle = 413.100006 pos = 31.9550,130.2840 diff = 190.399994'
});
data_peak.push({
lat: 3.1944888890e+01,
lng: 1.3034211111e+02,
cert : false,
content:' Peak = 682.400024 pos = 31.9449,130.3421 diff = 150.300049'
});
data_saddle.push({
lat: 3.1954333334e+01,
lng: 1.3034488889e+02,
content:'Saddle = 532.099976 pos = 31.9543,130.3449 diff = 150.300049'
});
data_peak.push({
lat: 3.3430333334e+01,
lng: 1.3113188889e+02,
cert : true,
content:'Name = JA6/OT-050(JA6/OT-050) peak = 664.000000 pos = 33.4303,131.1319 diff = 275.500000'
});
data_saddle.push({
lat: 3.3389555556e+01,
lng: 1.3113055556e+02,
content:'Saddle = 388.500000 pos = 33.3896,131.1306 diff = 275.500000'
});
data_peak.push({
lat: 3.3415555556e+01,
lng: 1.3087000000e+02,
cert : false,
content:' Peak = 542.299988 pos = 33.4156,130.8700 diff = 150.299988'
});
data_saddle.push({
lat: 3.3419555556e+01,
lng: 1.3086922222e+02,
content:'Saddle = 392.000000 pos = 33.4196,130.8692 diff = 150.299988'
});
data_peak.push({
lat: 3.3090888889e+01,
lng: 1.3158400000e+02,
cert : false,
content:' Peak = 543.900024 pos = 33.0909,131.5840 diff = 151.400024'
});
data_saddle.push({
lat: 3.3100888889e+01,
lng: 1.3157933333e+02,
content:'Saddle = 392.500000 pos = 33.1009,131.5793 diff = 151.400024'
});
data_peak.push({
lat: 3.3157444445e+01,
lng: 1.3157522222e+02,
cert : true,
content:'Name = JA6/OT-065(JA6/OT-065) peak = 611.200012 pos = 33.1574,131.5752 diff = 214.600006'
});
data_saddle.push({
lat: 3.3142555556e+01,
lng: 1.3158255556e+02,
content:'Saddle = 396.600006 pos = 33.1426,131.5826 diff = 214.600006'
});
data_peak.push({
lat: 3.3284777778e+01,
lng: 1.3083322222e+02,
cert : false,
content:' Peak = 614.000000 pos = 33.2848,130.8332 diff = 217.000000'
});
data_saddle.push({
lat: 3.3284777778e+01,
lng: 1.3085244444e+02,
content:'Saddle = 397.000000 pos = 33.2848,130.8524 diff = 217.000000'
});
data_peak.push({
lat: 3.2375000001e+01,
lng: 1.3139866667e+02,
cert : true,
content:'Name = JA6/MZ-068(JA6/MZ-068) peak = 860.799988 pos = 32.3750,131.3987 diff = 463.399994'
});
data_saddle.push({
lat: 3.2399111112e+01,
lng: 1.3139400000e+02,
content:'Saddle = 397.399994 pos = 32.3991,131.3940 diff = 463.399994'
});
data_peak.push({
lat: 3.2398666667e+01,
lng: 1.3145177778e+02,
cert : true,
content:'Name = JA6/MZ-075(JA6/MZ-075) peak = 821.799988 pos = 32.3987,131.4518 diff = 214.899963'
});
data_saddle.push({
lat: 3.2389555556e+01,
lng: 1.3140866667e+02,
content:'Saddle = 606.900024 pos = 32.3896,131.4087 diff = 214.899963'
});
data_peak.push({
lat: 3.3154777778e+01,
lng: 1.3147577778e+02,
cert : true,
content:'Name = JA6/OT-072(JA6/OT-072) peak = 571.799988 pos = 33.1548,131.4758 diff = 164.899994'
});
data_saddle.push({
lat: 3.3151222223e+01,
lng: 1.3147833333e+02,
content:'Saddle = 406.899994 pos = 33.1512,131.4783 diff = 164.899994'
});
data_peak.push({
lat: 3.3454888889e+01,
lng: 1.3076322222e+02,
cert : true,
content:'Name = JA6/FO-016(JA6/FO-016) peak = 693.400024 pos = 33.4549,130.7632 diff = 286.400024'
});
data_saddle.push({
lat: 3.3456444445e+01,
lng: 1.3079500000e+02,
content:'Saddle = 407.000000 pos = 33.4564,130.7950 diff = 286.400024'
});
data_peak.push({
lat: 3.2071555556e+01,
lng: 1.3049033333e+02,
cert : true,
content:'Name = JA6/KG-053(JA6/KG-053) peak = 570.799988 pos = 32.0716,130.4903 diff = 162.399994'
});
data_saddle.push({
lat: 3.2057666667e+01,
lng: 1.3049400000e+02,
content:'Saddle = 408.399994 pos = 32.0577,130.4940 diff = 162.399994'
});
data_peak.push({
lat: 3.3476333334e+01,
lng: 1.3092588889e+02,
cert : true,
content:'Name = Hikosan(JA6/OT-016) peak = 1193.400024 pos = 33.4763,130.9259 diff = 784.400024'
});
data_saddle.push({
lat: 3.3380777778e+01,
lng: 1.3099377778e+02,
content:'Saddle = 409.000000 pos = 33.3808,130.9938 diff = 784.400024'
});
data_peak.push({
lat: 3.3491444445e+01,
lng: 1.3108988889e+02,
cert : true,
content:'Name = JA6/OT-044(JA6/OT-044) peak = 731.400024 pos = 33.4914,131.0899 diff = 289.900024'
});
data_saddle.push({
lat: 3.3496888889e+01,
lng: 1.3108611111e+02,
content:'Saddle = 441.500000 pos = 33.4969,131.0861 diff = 289.900024'
});
data_peak.push({
lat: 3.3435555556e+01,
lng: 1.3080244444e+02,
cert : true,
content:'Name = JA6/FO-022(JA6/FO-022) peak = 640.799988 pos = 33.4356,130.8024 diff = 170.000000'
});
data_saddle.push({
lat: 3.3432000000e+01,
lng: 1.3080255556e+02,
content:'Saddle = 470.799988 pos = 33.4320,130.8026 diff = 170.000000'
});
data_peak.push({
lat: 3.3457333334e+01,
lng: 1.3081788889e+02,
cert : true,
content:'Name = JA6/FO-010(JA6/FO-010) peak = 742.299988 pos = 33.4573,130.8179 diff = 266.399994'
});
data_saddle.push({
lat: 3.3465444445e+01,
lng: 1.3083022222e+02,
content:'Saddle = 475.899994 pos = 33.4654,130.8302 diff = 266.399994'
});
data_peak.push({
lat: 3.3419000000e+01,
lng: 1.3080977778e+02,
cert : true,
content:'Name = JA6/FO-012(JA6/FO-012) peak = 714.000000 pos = 33.4190,130.8098 diff = 186.200012'
});
data_saddle.push({
lat: 3.3417666667e+01,
lng: 1.3083477778e+02,
content:'Saddle = 527.799988 pos = 33.4177,130.8348 diff = 186.200012'
});
data_peak.push({
lat: 3.3440222222e+01,
lng: 1.3082788889e+02,
cert : false,
content:' Peak = 732.599976 pos = 33.4402,130.8279 diff = 151.000000'
});
data_saddle.push({
lat: 3.3449222222e+01,
lng: 1.3082788889e+02,
content:'Saddle = 581.599976 pos = 33.4492,130.8279 diff = 151.000000'
});
data_peak.push({
lat: 3.3486555556e+01,
lng: 1.3076777778e+02,
cert : true,
content:'Name = Umamiyama(JA6/FO-002) peak = 976.400024 pos = 33.4866,130.7678 diff = 499.100037'
});
data_saddle.push({
lat: 3.3469222222e+01,
lng: 1.3083255556e+02,
content:'Saddle = 477.299988 pos = 33.4692,130.8326 diff = 499.100037'
});
data_peak.push({
lat: 3.3513222222e+01,
lng: 1.3081088889e+02,
cert : true,
content:'Name = JA6/FO-015(JA6/FO-015) peak = 711.599976 pos = 33.5132,130.8109 diff = 214.099976'
});
data_saddle.push({
lat: 3.3479333334e+01,
lng: 1.3080933333e+02,
content:'Saddle = 497.500000 pos = 33.4793,130.8093 diff = 214.099976'
});
data_peak.push({
lat: 3.3487444445e+01,
lng: 1.3083377778e+02,
cert : true,
content:'Name = JA6/FO-014(JA6/FO-014) peak = 710.700012 pos = 33.4874,130.8338 diff = 183.500000'
});
data_saddle.push({
lat: 3.3494777778e+01,
lng: 1.3081477778e+02,
content:'Saddle = 527.200012 pos = 33.4948,130.8148 diff = 183.500000'
});
data_peak.push({
lat: 3.3487888889e+01,
lng: 1.3074033333e+02,
cert : true,
content:'Name = JA6/FO-005(JA6/FO-005) peak = 925.400024 pos = 33.4879,130.7403 diff = 243.500000'
});
data_saddle.push({
lat: 3.3487777778e+01,
lng: 1.3075522222e+02,
content:'Saddle = 681.900024 pos = 33.4878,130.7552 diff = 243.500000'
});
data_peak.push({
lat: 3.3564777778e+01,
lng: 1.3091444444e+02,
cert : true,
content:'Name = JA6/FO-017(JA6/FO-017) peak = 693.200012 pos = 33.5648,130.9144 diff = 215.300018'
});
data_saddle.push({
lat: 3.3539888889e+01,
lng: 1.3092811111e+02,
content:'Saddle = 477.899994 pos = 33.5399,130.9281 diff = 215.300018'
});
data_peak.push({
lat: 3.3414555556e+01,
lng: 1.3092200000e+02,
cert : true,
content:'Name = JA6/OT-055(JA6/OT-055) peak = 645.299988 pos = 33.4146,130.9220 diff = 166.699982'
});
data_saddle.push({
lat: 3.3424333334e+01,
lng: 1.3091277778e+02,
content:'Saddle = 478.600006 pos = 33.4243,130.9128 diff = 166.699982'
});
data_peak.push({
lat: 3.3391000000e+01,
lng: 1.3092122222e+02,
cert : false,
content:' Peak = 643.099976 pos = 33.3910,130.9212 diff = 150.999969'
});
data_saddle.push({
lat: 3.3394888889e+01,
lng: 1.3092266667e+02,
content:'Saddle = 492.100006 pos = 33.3949,130.9227 diff = 150.999969'
});
data_peak.push({
lat: 3.3502333334e+01,
lng: 1.3112988889e+02,
cert : true,
content:'Name = JA6/OT-051(JA6/OT-051) peak = 661.700012 pos = 33.5023,131.1299 diff = 178.700012'
});
data_saddle.push({
lat: 3.3504777778e+01,
lng: 1.3109877778e+02,
content:'Saddle = 483.000000 pos = 33.5048,131.0988 diff = 178.700012'
});
data_peak.push({
lat: 3.3430000000e+01,
lng: 1.3085911111e+02,
cert : false,
content:' Peak = 727.500000 pos = 33.4300,130.8591 diff = 165.299988'
});
data_saddle.push({
lat: 3.3434111111e+01,
lng: 1.3085944444e+02,
content:'Saddle = 562.200012 pos = 33.4341,130.8594 diff = 165.299988'
});
data_peak.push({
lat: 3.3442555556e+01,
lng: 1.3105133333e+02,
cert : false,
content:' Peak = 750.500000 pos = 33.4426,131.0513 diff = 172.299988'
});
data_saddle.push({
lat: 3.3448000000e+01,
lng: 1.3105166667e+02,
content:'Saddle = 578.200012 pos = 33.4480,131.0517 diff = 172.299988'
});
data_peak.push({
lat: 3.3450444445e+01,
lng: 1.3086077778e+02,
cert : false,
content:' Peak = 823.799988 pos = 33.4504,130.8608 diff = 184.599976'
});
data_saddle.push({
lat: 3.3450666667e+01,
lng: 1.3086744444e+02,
content:'Saddle = 639.200012 pos = 33.4507,130.8674 diff = 184.599976'
});
data_peak.push({
lat: 3.3508333334e+01,
lng: 1.3106800000e+02,
cert : false,
content:' Peak = 802.000000 pos = 33.5083,131.0680 diff = 150.400024'
});
data_saddle.push({
lat: 3.3509666667e+01,
lng: 1.3106222222e+02,
content:'Saddle = 651.599976 pos = 33.5097,131.0622 diff = 150.400024'
});
data_peak.push({
lat: 3.3460111111e+01,
lng: 1.3105455556e+02,
cert : true,
content:'Name = JA6/OT-030(JA6/OT-030) peak = 875.900024 pos = 33.4601,131.0546 diff = 214.200012'
});
data_saddle.push({
lat: 3.3457222222e+01,
lng: 1.3105200000e+02,
content:'Saddle = 661.700012 pos = 33.4572,131.0520 diff = 214.200012'
});
data_peak.push({
lat: 3.3461222222e+01,
lng: 1.3101955556e+02,
cert : true,
content:'Name = JA6/OT-025(JA6/OT-025) peak = 990.400024 pos = 33.4612,131.0196 diff = 328.400024'
});
data_saddle.push({
lat: 3.3493888889e+01,
lng: 1.3100733333e+02,
content:'Saddle = 662.000000 pos = 33.4939,131.0073 diff = 328.400024'
});
data_peak.push({
lat: 3.3480111111e+01,
lng: 1.3097677778e+02,
cert : false,
content:' Peak = 932.900024 pos = 33.4801,130.9768 diff = 234.700012'
});
data_saddle.push({
lat: 3.3484888889e+01,
lng: 1.3097333333e+02,
content:'Saddle = 698.200012 pos = 33.4849,130.9733 diff = 234.700012'
});
data_peak.push({
lat: 3.3417444445e+01,
lng: 1.3097177778e+02,
cert : true,
content:'Name = JA6/OT-028(JA6/OT-028) peak = 911.500000 pos = 33.4174,130.9718 diff = 198.400024'
});
data_saddle.push({
lat: 3.3430555556e+01,
lng: 1.3095766667e+02,
content:'Saddle = 713.099976 pos = 33.4306,130.9577 diff = 198.400024'
});
data_peak.push({
lat: 3.3512333334e+01,
lng: 1.3100177778e+02,
cert : true,
content:'Name = Inugatake(JA6/OT-021) peak = 1130.099976 pos = 33.5123,131.0018 diff = 403.000000'
});
data_saddle.push({
lat: 3.3496222222e+01,
lng: 1.3096222222e+02,
content:'Saddle = 727.099976 pos = 33.4962,130.9622 diff = 403.000000'
});
data_peak.push({
lat: 3.2116555556e+01,
lng: 1.3129388889e+02,
cert : false,
content:' Peak = 574.799988 pos = 32.1166,131.2939 diff = 161.899994'
});
data_saddle.push({
lat: 3.2126777779e+01,
lng: 1.3128544444e+02,
content:'Saddle = 412.899994 pos = 32.1268,131.2854 diff = 161.899994'
});
data_peak.push({
lat: 3.2892888889e+01,
lng: 1.3152255556e+02,
cert : true,
content:'Name = JA6/OT-064(JA6/OT-064) peak = 612.099976 pos = 32.8929,131.5226 diff = 199.099976'
});
data_saddle.push({
lat: 3.2890888889e+01,
lng: 1.3150077778e+02,
content:'Saddle = 413.000000 pos = 32.8909,131.5008 diff = 199.099976'
});
data_peak.push({
lat: 3.2335000001e+01,
lng: 1.3137777778e+02,
cert : true,
content:'Name = JA6/MZ-082(JA6/MZ-082) peak = 756.400024 pos = 32.3350,131.3778 diff = 343.200012'
});
data_saddle.push({
lat: 3.2346111112e+01,
lng: 1.3137544444e+02,
content:'Saddle = 413.200012 pos = 32.3461,131.3754 diff = 343.200012'
});
data_peak.push({
lat: 3.2206000001e+01,
lng: 1.3048244444e+02,
cert : true,
content:'Name = JA6/KM-049(JA6/KM-049) peak = 608.000000 pos = 32.2060,130.4824 diff = 194.500000'
});
data_saddle.push({
lat: 3.2203333334e+01,
lng: 1.3050822222e+02,
content:'Saddle = 413.500000 pos = 32.2033,130.5082 diff = 194.500000'
});
data_peak.push({
lat: 3.2985444445e+01,
lng: 1.3180022222e+02,
cert : true,
content:'Name = JA6/OT-053(JA6/OT-053) peak = 653.299988 pos = 32.9854,131.8002 diff = 233.099976'
});
data_saddle.push({
lat: 3.2968888889e+01,
lng: 1.3171255556e+02,
content:'Saddle = 420.200012 pos = 32.9689,131.7126 diff = 233.099976'
});
data_peak.push({
lat: 3.2043666667e+01,
lng: 1.3045933333e+02,
cert : false,
content:' Peak = 590.000000 pos = 32.0437,130.4593 diff = 168.899994'
});
data_saddle.push({
lat: 3.2053777779e+01,
lng: 1.3049800000e+02,
content:'Saddle = 421.100006 pos = 32.0538,130.4980 diff = 168.899994'
});
data_peak.push({
lat: 3.2356666667e+01,
lng: 1.3137055556e+02,
cert : false,
content:' Peak = 753.799988 pos = 32.3567,131.3706 diff = 331.899994'
});
data_saddle.push({
lat: 3.2372666667e+01,
lng: 1.3134288889e+02,
content:'Saddle = 421.899994 pos = 32.3727,131.3429 diff = 331.899994'
});
data_peak.push({
lat: 3.3145444445e+01,
lng: 1.3159000000e+02,
cert : false,
content:' Peak = 600.799988 pos = 33.1454,131.5900 diff = 172.000000'
});
data_saddle.push({
lat: 3.3129888889e+01,
lng: 1.3157311111e+02,
content:'Saddle = 428.799988 pos = 33.1299,131.5731 diff = 172.000000'
});
data_peak.push({
lat: 3.2368000001e+01,
lng: 1.3133366667e+02,
cert : false,
content:' Peak = 590.400024 pos = 32.3680,131.3337 diff = 158.200012'
});
data_saddle.push({
lat: 3.2377333334e+01,
lng: 1.3131233333e+02,
content:'Saddle = 432.200012 pos = 32.3773,131.3123 diff = 158.200012'
});
data_peak.push({
lat: 3.2113777779e+01,
lng: 1.3042888889e+02,
cert : true,
content:'Name = JA6/KG-034(JA6/KG-034) peak = 663.000000 pos = 32.1138,130.4289 diff = 228.500000'
});
data_saddle.push({
lat: 3.2114777779e+01,
lng: 1.3045233333e+02,
content:'Saddle = 434.500000 pos = 32.1148,130.4523 diff = 228.500000'
});
data_peak.push({
lat: 3.3434555556e+01,
lng: 1.3125277778e+02,
cert : true,
content:'Name = Kanaraseyama(JA6/OT-038) peak = 754.200012 pos = 33.4346,131.2528 diff = 318.300018'
});
data_saddle.push({
lat: 3.3386111111e+01,
lng: 1.3122244444e+02,
content:'Saddle = 435.899994 pos = 33.3861,131.2224 diff = 318.300018'
});
data_peak.push({
lat: 3.2953111112e+01,
lng: 1.3164566667e+02,
cert : true,
content:'Name = Haidatesan(JA6/OT-039) peak = 753.099976 pos = 32.9531,131.6457 diff = 311.099976'
});
data_saddle.push({
lat: 3.2876777778e+01,
lng: 1.3154955556e+02,
content:'Saddle = 442.000000 pos = 32.8768,131.5496 diff = 311.099976'
});
data_peak.push({
lat: 3.2951444445e+01,
lng: 1.3168077778e+02,
cert : false,
content:' Peak = 621.200012 pos = 32.9514,131.6808 diff = 159.000000'
});
data_saddle.push({
lat: 3.2955000000e+01,
lng: 1.3166488889e+02,
content:'Saddle = 462.200012 pos = 32.9550,131.6649 diff = 159.000000'
});
data_peak.push({
lat: 3.2889000000e+01,
lng: 1.3166244444e+02,
cert : true,
content:'Name = JA6/OT-040(JA6/OT-040) peak = 751.400024 pos = 32.8890,131.6624 diff = 283.100037'
});
data_saddle.push({
lat: 3.2924444445e+01,
lng: 1.3161611111e+02,
content:'Saddle = 468.299988 pos = 32.9244,131.6161 diff = 283.100037'
});
data_peak.push({
lat: 3.2877000000e+01,
lng: 1.3159155556e+02,
cert : false,
content:' Peak = 714.099976 pos = 32.8770,131.5916 diff = 236.499969'
});
data_saddle.push({
lat: 3.2903666667e+01,
lng: 1.3162322222e+02,
content:'Saddle = 477.600006 pos = 32.9037,131.6232 diff = 236.499969'
});
data_peak.push({
lat: 3.2867555556e+01,
lng: 1.3157588889e+02,
cert : false,
content:' Peak = 681.299988 pos = 32.8676,131.5759 diff = 177.899994'
});
data_saddle.push({
lat: 3.2872000000e+01,
lng: 1.3157666667e+02,
content:'Saddle = 503.399994 pos = 32.8720,131.5767 diff = 177.899994'
});
data_peak.push({
lat: 3.2913333334e+01,
lng: 1.3161177778e+02,
cert : false,
content:' Peak = 662.799988 pos = 32.9133,131.6118 diff = 150.899994'
});
data_saddle.push({
lat: 3.2898333334e+01,
lng: 1.3160666667e+02,
content:'Saddle = 511.899994 pos = 32.8983,131.6067 diff = 150.899994'
});
data_peak.push({
lat: 3.2037000001e+01,
lng: 1.3111011111e+02,
cert : true,
content:'Name = JA6/MZ-056(JA6/MZ-056) peak = 924.200012 pos = 32.0370,131.1101 diff = 472.900024'
});
data_saddle.push({
lat: 3.2092666667e+01,
lng: 1.3102211111e+02,
content:'Saddle = 451.299988 pos = 32.0927,131.0221 diff = 472.900024'
});
data_peak.push({
lat: 3.2065444445e+01,
lng: 1.3104477778e+02,
cert : true,
content:'Name = JA6/MZ-076(JA6/MZ-076) peak = 811.599976 pos = 32.0654,131.0448 diff = 218.599976'
});
data_saddle.push({
lat: 3.2057333334e+01,
lng: 1.3106288889e+02,
content:'Saddle = 593.000000 pos = 32.0573,131.0629 diff = 218.599976'
});
data_peak.push({
lat: 3.2020111112e+01,
lng: 1.3071744444e+02,
cert : true,
content:'Name = JA6/KG-042(JA6/KG-042) peak = 613.099976 pos = 32.0201,130.7174 diff = 160.499969'
});
data_saddle.push({
lat: 3.2056666667e+01,
lng: 1.3072044444e+02,
content:'Saddle = 452.600006 pos = 32.0567,130.7204 diff = 160.499969'
});
data_peak.push({
lat: 3.3300777778e+01,
lng: 1.3111844444e+02,
cert : true,
content:'Name = JA6/OT-061(JA6/OT-061) peak = 620.799988 pos = 33.3008,131.1184 diff = 168.199982'
});
data_saddle.push({
lat: 3.3316222222e+01,
lng: 1.3111000000e+02,
content:'Saddle = 452.600006 pos = 33.3162,131.1100 diff = 168.199982'
});
data_peak.push({
lat: 3.2656777778e+01,
lng: 1.3165877778e+02,
cert : false,
content:' Peak = 721.200012 pos = 32.6568,131.6588 diff = 268.100006'
});
data_saddle.push({
lat: 3.2690444445e+01,
lng: 1.3164411111e+02,
content:'Saddle = 453.100006 pos = 32.6904,131.6441 diff = 268.100006'
});
data_peak.push({
lat: 3.2657555556e+01,
lng: 1.3093933333e+02,
cert : true,
content:'Name = JA6/KM-046(JA6/KM-046) peak = 660.700012 pos = 32.6576,130.9393 diff = 205.700012'
});
data_saddle.push({
lat: 3.2661777778e+01,
lng: 1.3095311111e+02,
content:'Saddle = 455.000000 pos = 32.6618,130.9531 diff = 205.700012'
});
data_peak.push({
lat: 3.2792222223e+01,
lng: 1.3159233333e+02,
cert : false,
content:' Peak = 641.299988 pos = 32.7922,131.5923 diff = 184.500000'
});
data_saddle.push({
lat: 3.2796666667e+01,
lng: 1.3157811111e+02,
content:'Saddle = 456.799988 pos = 32.7967,131.5781 diff = 184.500000'
});
data_peak.push({
lat: 3.2359555556e+01,
lng: 1.3132177778e+02,
cert : true,
content:'Name = JA6/MZ-094(JA6/MZ-094) peak = 670.599976 pos = 32.3596,131.3218 diff = 208.599976'
});
data_saddle.push({
lat: 3.2367777778e+01,
lng: 1.3131188889e+02,
content:'Saddle = 462.000000 pos = 32.3678,131.3119 diff = 208.599976'
});
data_peak.push({
lat: 3.2237222223e+01,
lng: 1.3131988889e+02,
cert : true,
content:'Name = JA6/MZ-099(JA6/MZ-099) peak = 642.599976 pos = 32.2372,131.3199 diff = 179.299988'
});
data_saddle.push({
lat: 3.2249888890e+01,
lng: 1.3131477778e+02,
content:'Saddle = 463.299988 pos = 32.2499,131.3148 diff = 179.299988'
});
data_peak.push({
lat: 3.2412333334e+01,
lng: 1.3140788889e+02,
cert : true,
content:'Name = JA6/MZ-088(JA6/MZ-088) peak = 710.500000 pos = 32.4123,131.4079 diff = 243.200012'
});
data_saddle.push({
lat: 3.2409444445e+01,
lng: 1.3139900000e+02,
content:'Saddle = 467.299988 pos = 32.4094,131.3990 diff = 243.200012'
});
data_peak.push({
lat: 3.3332111111e+01,
lng: 1.3109777778e+02,
cert : true,
content:'Name = JA6/OT-043(JA6/OT-043) peak = 745.000000 pos = 33.3321,131.0978 diff = 270.299988'
});
data_saddle.push({
lat: 3.3337777778e+01,
lng: 1.3115511111e+02,
content:'Saddle = 474.700012 pos = 33.3378,131.1551 diff = 270.299988'
});
data_peak.push({
lat: 3.3277333334e+01,
lng: 1.3106655556e+02,
cert : true,
content:'Name = JA6/OT-049(JA6/OT-049) peak = 674.200012 pos = 33.2773,131.0666 diff = 185.900024'
});
data_saddle.push({
lat: 3.3293333334e+01,
lng: 1.3106600000e+02,
content:'Saddle = 488.299988 pos = 33.2933,131.0660 diff = 185.900024'
});
data_peak.push({
lat: 3.3361333334e+01,
lng: 1.3105844444e+02,
cert : false,
content:' Peak = 713.799988 pos = 33.3613,131.0584 diff = 202.500000'
});
data_saddle.push({
lat: 3.3348222222e+01,
lng: 1.3106888889e+02,
content:'Saddle = 511.299988 pos = 33.3482,131.0689 diff = 202.500000'
});
data_peak.push({
lat: 3.2135777779e+01,
lng: 1.3046355556e+02,
cert : true,
content:'Name = JA6/KM-041(JA6/KM-041) peak = 734.099976 pos = 32.1358,130.4636 diff = 253.199982'
});
data_saddle.push({
lat: 3.2142222223e+01,
lng: 1.3054066667e+02,
content:'Saddle = 480.899994 pos = 32.1422,130.5407 diff = 253.199982'
});
data_peak.push({
lat: 3.3146111111e+01,
lng: 1.3081522222e+02,
cert : false,
content:' Peak = 641.099976 pos = 33.1461,130.8152 diff = 159.799988'
});
data_saddle.push({
lat: 3.3139666667e+01,
lng: 1.3082300000e+02,
content:'Saddle = 481.299988 pos = 33.1397,130.8230 diff = 159.799988'
});
data_peak.push({
lat: 3.2076222223e+01,
lng: 1.3123611111e+02,
cert : true,
content:'Name = JA6/MZ-089(JA6/MZ-089) peak = 710.799988 pos = 32.0762,131.2361 diff = 220.299988'
});
data_saddle.push({
lat: 3.2095777779e+01,
lng: 1.3122733333e+02,
content:'Saddle = 490.500000 pos = 32.0958,131.2273 diff = 220.299988'
});
data_peak.push({
lat: 3.2100000001e+01,
lng: 1.3105688889e+02,
cert : true,
content:'Name = JA6/MZ-092(JA6/MZ-092) peak = 674.299988 pos = 32.1000,131.0569 diff = 172.099976'
});
data_saddle.push({
lat: 3.2108333334e+01,
lng: 1.3106166667e+02,
content:'Saddle = 502.200012 pos = 32.1083,131.0617 diff = 172.099976'
});
data_peak.push({
lat: 3.2278333334e+01,
lng: 1.3063677778e+02,
cert : true,
content:'Name = JA6/KM-042(JA6/KM-042) peak = 700.900024 pos = 32.2783,130.6368 diff = 192.800018'
});
data_saddle.push({
lat: 3.2283333334e+01,
lng: 1.3062200000e+02,
content:'Saddle = 508.100006 pos = 32.2833,130.6220 diff = 192.800018'
});
data_peak.push({
lat: 3.2751666667e+01,
lng: 1.3128800000e+02,
cert : false,
content:' Peak = 671.000000 pos = 32.7517,131.2880 diff = 150.400024'
});
data_saddle.push({
lat: 3.2760666667e+01,
lng: 1.3129022222e+02,
content:'Saddle = 520.599976 pos = 32.7607,131.2902 diff = 150.400024'
});
data_peak.push({
lat: 3.2068444445e+01,
lng: 1.3086788889e+02,
cert : true,
content:'Name = JA6/MZ-090(JA6/MZ-090) peak = 704.000000 pos = 32.0684,130.8679 diff = 182.000000'
});
data_saddle.push({
lat: 3.2077222223e+01,
lng: 1.3085455556e+02,
content:'Saddle = 522.000000 pos = 32.0772,130.8546 diff = 182.000000'
});
data_peak.push({
lat: 3.3141222223e+01,
lng: 1.3156033333e+02,
cert : true,
content:'Name = JA6/OT-041(JA6/OT-041) peak = 750.599976 pos = 33.1412,131.5603 diff = 228.299988'
});
data_saddle.push({
lat: 3.3125111111e+01,
lng: 1.3155733333e+02,
content:'Saddle = 522.299988 pos = 33.1251,131.5573 diff = 228.299988'
});
data_peak.push({
lat: 3.3303000000e+01,
lng: 1.3072277778e+02,
cert : true,
content:'Name = Takatoriyama(JA6/FO-009) peak = 802.799988 pos = 33.3030,130.7228 diff = 271.399963'
});
data_saddle.push({
lat: 3.3280000000e+01,
lng: 1.3074588889e+02,
content:'Saddle = 531.400024 pos = 33.2800,130.7459 diff = 271.399963'
});
data_peak.push({
lat: 3.2657888889e+01,
lng: 1.3141944444e+02,
cert : true,
content:'Name = JA6/MZ-077(JA6/MZ-077) peak = 811.500000 pos = 32.6579,131.4194 diff = 279.200012'
});
data_saddle.push({
lat: 3.2663444445e+01,
lng: 1.3142277778e+02,
content:'Saddle = 532.299988 pos = 32.6634,131.4228 diff = 279.200012'
});
data_peak.push({
lat: 3.3140111111e+01,
lng: 1.3100144444e+02,
cert : true,
content:'Name = JA6/KM-040(JA6/KM-040) peak = 746.200012 pos = 33.1401,131.0014 diff = 207.700012'
});
data_saddle.push({
lat: 3.3120666667e+01,
lng: 1.3101711111e+02,
content:'Saddle = 538.500000 pos = 33.1207,131.0171 diff = 207.700012'
});
data_peak.push({
lat: 3.3153000000e+01,
lng: 1.3140966667e+02,
cert : false,
content:' Peak = 765.700012 pos = 33.1530,131.4097 diff = 217.799988'
});
data_saddle.push({
lat: 3.3135444445e+01,
lng: 1.3139155556e+02,
content:'Saddle = 547.900024 pos = 33.1354,131.3916 diff = 217.799988'
});
data_peak.push({
lat: 3.2626000001e+01,
lng: 1.3157222222e+02,
cert : true,
content:'Name = Mukabakiyama(JA6/MZ-074) peak = 833.900024 pos = 32.6260,131.5722 diff = 285.700012'
});
data_saddle.push({
lat: 3.2657555556e+01,
lng: 1.3158377778e+02,
content:'Saddle = 548.200012 pos = 32.6576,131.5838 diff = 285.700012'
});
data_peak.push({
lat: 3.2629555556e+01,
lng: 1.3158800000e+02,
cert : false,
content:' Peak = 806.500000 pos = 32.6296,131.5880 diff = 165.799988'
});
data_saddle.push({
lat: 3.2633666667e+01,
lng: 1.3158400000e+02,
content:'Saddle = 640.700012 pos = 32.6337,131.5840 diff = 165.799988'
});
data_peak.push({
lat: 3.2692555556e+01,
lng: 1.3091922222e+02,
cert : true,
content:'Name = JA6/KM-038(JA6/KM-038) peak = 810.799988 pos = 32.6926,130.9192 diff = 262.299988'
});
data_saddle.push({
lat: 3.2717555556e+01,
lng: 1.3096633333e+02,
content:'Saddle = 548.500000 pos = 32.7176,130.9663 diff = 262.299988'
});
data_peak.push({
lat: 3.3157000000e+01,
lng: 1.3077066667e+02,
cert : true,
content:'Name = JA6/FO-007(JA6/FO-007) peak = 840.700012 pos = 33.1570,130.7707 diff = 282.400024'
});
data_saddle.push({
lat: 3.3134666667e+01,
lng: 1.3076966667e+02,
content:'Saddle = 558.299988 pos = 33.1347,130.7697 diff = 282.400024'
});
data_peak.push({
lat: 3.2154888890e+01,
lng: 1.3058255556e+02,
cert : true,
content:'Name = JA6/KG-022(JA6/KG-022) peak = 842.799988 pos = 32.1549,130.5826 diff = 280.799988'
});
data_saddle.push({
lat: 3.2173666667e+01,
lng: 1.3059366667e+02,
content:'Saddle = 562.000000 pos = 32.1737,130.5937 diff = 280.799988'
});
data_peak.push({
lat: 3.3071222223e+01,
lng: 1.3147033333e+02,
cert : true,
content:'Name = JA6/OT-031(JA6/OT-031) peak = 854.000000 pos = 33.0712,131.4703 diff = 287.599976'
});
data_saddle.push({
lat: 3.3068000000e+01,
lng: 1.3142555556e+02,
content:'Saddle = 566.400024 pos = 33.0680,131.4256 diff = 287.599976'
});
data_peak.push({
lat: 3.3107666667e+01,
lng: 1.3153022222e+02,
cert : false,
content:' Peak = 794.500000 pos = 33.1077,131.5302 diff = 216.900024'
});
data_saddle.push({
lat: 3.3102666667e+01,
lng: 1.3151955556e+02,
content:'Saddle = 577.599976 pos = 33.1027,131.5196 diff = 216.900024'
});
data_peak.push({
lat: 3.2550000001e+01,
lng: 1.3079100000e+02,
cert : false,
content:' Peak = 870.799988 pos = 32.5500,130.7910 diff = 303.399963'
});
data_saddle.push({
lat: 3.2543222223e+01,
lng: 1.3078844444e+02,
content:'Saddle = 567.400024 pos = 32.5432,130.7884 diff = 303.399963'
});
data_peak.push({
lat: 3.2547222223e+01,
lng: 1.3101833333e+02,
cert : true,
content:'Name = Kunimidake(JA6/MZ-001) peak = 1737.199951 pos = 32.5472,131.0183 diff = 1166.199951'
});
data_saddle.push({
lat: 3.2698555556e+01,
lng: 1.3113633333e+02,
content:'Saddle = 571.000000 pos = 32.6986,131.1363 diff = 1166.199951'
});
data_peak.push({
lat: 3.2420888890e+01,
lng: 1.3139133333e+02,
cert : true,
content:'Name = JA6/MZ-065(JA6/MZ-065) peak = 898.099976 pos = 32.4209,131.3913 diff = 291.000000'
});
data_saddle.push({
lat: 3.2429444445e+01,
lng: 1.3138222222e+02,
content:'Saddle = 607.099976 pos = 32.4294,131.3822 diff = 291.000000'
});
data_peak.push({
lat: 3.2264888890e+01,
lng: 1.3135800000e+02,
cert : true,
content:'Name = JA6/MZ-043(JA6/MZ-043) peak = 1021.400024 pos = 32.2649,131.3580 diff = 385.100037'
});
data_saddle.push({
lat: 3.2279000001e+01,
lng: 1.3133877778e+02,
content:'Saddle = 636.299988 pos = 32.2790,131.3388 diff = 385.100037'
});
data_peak.push({
lat: 3.2236222223e+01,
lng: 1.3137533333e+02,
cert : false,
content:' Peak = 821.799988 pos = 32.2362,131.3753 diff = 153.399963'
});
data_saddle.push({
lat: 3.2240555556e+01,
lng: 1.3137500000e+02,
content:'Saddle = 668.400024 pos = 32.2406,131.3750 diff = 153.399963'
});
data_peak.push({
lat: 3.2241444445e+01,
lng: 1.3135988889e+02,
cert : true,
content:'Name = JA6/MZ-045(JA6/MZ-045) peak = 1003.700012 pos = 32.2414,131.3599 diff = 195.900024'
});
data_saddle.push({
lat: 3.2249333334e+01,
lng: 1.3135644444e+02,
content:'Saddle = 807.799988 pos = 32.2493,131.3564 diff = 195.900024'
});
data_peak.push({
lat: 3.2150000001e+01,
lng: 1.3062066667e+02,
cert : true,
content:'Name = JA6/KG-011(JA6/KG-011) peak = 1002.400024 pos = 32.1500,130.6207 diff = 360.500000'
});
data_saddle.push({
lat: 3.2085666667e+01,
lng: 1.3075077778e+02,
content:'Saddle = 641.900024 pos = 32.0857,130.7508 diff = 360.500000'
});
data_peak.push({
lat: 3.2110222223e+01,
lng: 1.3075566667e+02,
cert : false,
content:' Peak = 842.000000 pos = 32.1102,130.7557 diff = 173.900024'
});
data_saddle.push({
lat: 3.2087222223e+01,
lng: 1.3074844444e+02,
content:'Saddle = 668.099976 pos = 32.0872,130.7484 diff = 173.900024'
});
data_peak.push({
lat: 3.2187888890e+01,
lng: 1.3061411111e+02,
cert : true,
content:'Name = Kunimiyama(JA6/KM-029) peak = 968.700012 pos = 32.1879,130.6141 diff = 295.600037'
});
data_saddle.push({
lat: 3.2171222223e+01,
lng: 1.3061666667e+02,
content:'Saddle = 673.099976 pos = 32.1712,130.6167 diff = 295.600037'
});
data_peak.push({
lat: 3.2197222223e+01,
lng: 1.3055533333e+02,
cert : true,
content:'Name = JA6/KM-032(JA6/KM-032) peak = 903.299988 pos = 32.1972,130.5553 diff = 205.599976'
});
data_saddle.push({
lat: 3.2186777779e+01,
lng: 1.3059666667e+02,
content:'Saddle = 697.700012 pos = 32.1868,130.5967 diff = 205.599976'
});
data_peak.push({
lat: 3.2109333334e+01,
lng: 1.3067688889e+02,
cert : false,
content:' Peak = 901.299988 pos = 32.1093,130.6769 diff = 165.500000'
});
data_saddle.push({
lat: 3.2121000001e+01,
lng: 1.3067388889e+02,
content:'Saddle = 735.799988 pos = 32.1210,130.6739 diff = 165.500000'
});
data_peak.push({
lat: 3.2111444445e+01,
lng: 1.3096588889e+02,
cert : true,
content:'Name = JA6/MZ-062(JA6/MZ-062) peak = 902.299988 pos = 32.1114,130.9659 diff = 254.799988'
});
data_saddle.push({
lat: 3.2118777779e+01,
lng: 1.3094288889e+02,
content:'Saddle = 647.500000 pos = 32.1188,130.9429 diff = 254.799988'
});
data_peak.push({
lat: 3.2472444445e+01,
lng: 1.3134644444e+02,
cert : true,
content:'Name = JA6/MZ-067(JA6/MZ-067) peak = 873.799988 pos = 32.4724,131.3464 diff = 224.700012'
});
data_saddle.push({
lat: 3.2468777778e+01,
lng: 1.3132000000e+02,
content:'Saddle = 649.099976 pos = 32.4688,131.3200 diff = 224.700012'
});
data_peak.push({
lat: 3.2605444445e+01,
lng: 1.3090177778e+02,
cert : false,
content:' Peak = 837.599976 pos = 32.6054,130.9018 diff = 174.099976'
});
data_saddle.push({
lat: 3.2601888889e+01,
lng: 1.3090300000e+02,
content:'Saddle = 663.500000 pos = 32.6019,130.9030 diff = 174.099976'
});
data_peak.push({
lat: 3.2150444445e+01,
lng: 1.3094333333e+02,
cert : true,
content:'Name = Shiragadake(JA6/KM-004) peak = 1416.400024 pos = 32.1504,130.9433 diff = 747.800049'
});
data_saddle.push({
lat: 3.2263444445e+01,
lng: 1.3104466667e+02,
content:'Saddle = 668.599976 pos = 32.2634,131.0447 diff = 747.800049'
});
data_peak.push({
lat: 3.2163222223e+01,
lng: 1.3125644444e+02,
cert : true,
content:'Name = JA6/MZ-042(JA6/MZ-042) peak = 1031.400024 pos = 32.1632,131.2564 diff = 359.100037'
});
data_saddle.push({
lat: 3.2172000001e+01,
lng: 1.3121566667e+02,
content:'Saddle = 672.299988 pos = 32.1720,131.2157 diff = 359.100037'
});
data_peak.push({
lat: 3.2075888890e+01,
lng: 1.3115488889e+02,
cert : true,
content:'Name = JA6/MZ-037(JA6/MZ-037) peak = 1107.000000 pos = 32.0759,131.1549 diff = 424.700012'
});
data_saddle.push({
lat: 3.2173666667e+01,
lng: 1.3101033333e+02,
content:'Saddle = 682.299988 pos = 32.1737,131.0103 diff = 424.700012'
});
data_peak.push({
lat: 3.2083444445e+01,
lng: 1.3110833333e+02,
cert : true,
content:'Name = JA6/MZ-053(JA6/MZ-053) peak = 953.400024 pos = 32.0834,131.1083 diff = 220.800049'
});
data_saddle.push({
lat: 3.2093666667e+01,
lng: 1.3112977778e+02,
content:'Saddle = 732.599976 pos = 32.0937,131.1298 diff = 220.800049'
});
data_peak.push({
lat: 3.2163333334e+01,
lng: 1.3104911111e+02,
cert : true,
content:'Name = JA6/KM-031(JA6/KM-031) peak = 908.700012 pos = 32.1633,131.0491 diff = 166.799988'
});
data_saddle.push({
lat: 3.2146333334e+01,
lng: 1.3105455556e+02,
content:'Saddle = 741.900024 pos = 32.1463,131.0546 diff = 166.799988'
});
data_peak.push({
lat: 3.2111777779e+01,
lng: 1.3111300000e+02,
cert : true,
content:'Name = JA6/MZ-055(JA6/MZ-055) peak = 931.400024 pos = 32.1118,131.1130 diff = 185.800049'
});
data_saddle.push({
lat: 3.2098888890e+01,
lng: 1.3108922222e+02,
content:'Saddle = 745.599976 pos = 32.0989,131.0892 diff = 185.800049'
});
data_peak.push({
lat: 3.2119888890e+01,
lng: 1.3124933333e+02,
cert : true,
content:'Name = JA6/MZ-050(JA6/MZ-050) peak = 954.500000 pos = 32.1199,131.2493 diff = 251.900024'
});
data_saddle.push({
lat: 3.2134777779e+01,
lng: 1.3123200000e+02,
content:'Saddle = 702.599976 pos = 32.1348,131.2320 diff = 251.900024'
});
data_peak.push({
lat: 3.2131777779e+01,
lng: 1.3098922222e+02,
cert : true,
content:'Name = JA6/MZ-048(JA6/MZ-048) peak = 974.599976 pos = 32.1318,130.9892 diff = 261.199951'
});
data_saddle.push({
lat: 3.2146333334e+01,
lng: 1.3099311111e+02,
content:'Saddle = 713.400024 pos = 32.1463,130.9931 diff = 261.199951'
});
data_peak.push({
lat: 3.2133666667e+01,
lng: 1.3119244444e+02,
cert : true,
content:'Name = JA6/MZ-031(JA6/MZ-031) peak = 1220.699951 pos = 32.1337,131.1924 diff = 503.799927'
});
data_saddle.push({
lat: 3.2201333334e+01,
lng: 1.3097877778e+02,
content:'Saddle = 716.900024 pos = 32.2013,130.9788 diff = 503.799927'
});
data_peak.push({
lat: 3.2098000001e+01,
lng: 1.3125455556e+02,
cert : true,
content:'Name = JA6/MZ-057(JA6/MZ-057) peak = 922.500000 pos = 32.0980,131.2546 diff = 199.500000'
});
data_saddle.push({
lat: 3.2105666667e+01,
lng: 1.3123355556e+02,
content:'Saddle = 723.000000 pos = 32.1057,131.2336 diff = 199.500000'
});
data_peak.push({
lat: 3.2074333334e+01,
lng: 1.3121033333e+02,
cert : true,
content:'Name = JA6/MZ-061(JA6/MZ-061) peak = 913.900024 pos = 32.0743,131.2103 diff = 180.500000'
});
data_saddle.push({
lat: 3.2082222223e+01,
lng: 1.3120555556e+02,
content:'Saddle = 733.400024 pos = 32.0822,131.2056 diff = 180.500000'
});
data_peak.push({
lat: 3.2246111112e+01,
lng: 1.3105577778e+02,
cert : true,
content:'Name = JA6/KM-015(JA6/KM-015) peak = 1164.400024 pos = 32.2461,131.0558 diff = 398.900024'
});
data_saddle.push({
lat: 3.2202222223e+01,
lng: 1.3110722222e+02,
content:'Saddle = 765.500000 pos = 32.2022,131.1072 diff = 398.900024'
});
data_peak.push({
lat: 3.2212333334e+01,
lng: 1.3098400000e+02,
cert : false,
content:' Peak = 1013.099976 pos = 32.2123,130.9840 diff = 240.500000'
});
data_saddle.push({
lat: 3.2216777778e+01,
lng: 1.3098944444e+02,
content:'Saddle = 772.599976 pos = 32.2168,130.9894 diff = 240.500000'
});
data_peak.push({
lat: 3.2168555556e+01,
lng: 1.3110488889e+02,
cert : false,
content:' Peak = 1014.000000 pos = 32.1686,131.1049 diff = 226.400024'
});
data_saddle.push({
lat: 3.2217000001e+01,
lng: 1.3107844444e+02,
content:'Saddle = 787.599976 pos = 32.2170,131.0784 diff = 226.400024'
});
data_peak.push({
lat: 3.2209666667e+01,
lng: 1.3105388889e+02,
cert : false,
content:' Peak = 962.700012 pos = 32.2097,131.0539 diff = 170.299988'
});
data_saddle.push({
lat: 3.2217555556e+01,
lng: 1.3105011111e+02,
content:'Saddle = 792.400024 pos = 32.2176,131.0501 diff = 170.299988'
});
data_peak.push({
lat: 3.2229555556e+01,
lng: 1.3101311111e+02,
cert : true,
content:'Name = JA6/KM-019(JA6/KM-019) peak = 1104.800049 pos = 32.2296,131.0131 diff = 312.400024'
});
data_saddle.push({
lat: 3.2238000001e+01,
lng: 1.3101700000e+02,
content:'Saddle = 792.400024 pos = 32.2380,131.0170 diff = 312.400024'
});
data_peak.push({
lat: 3.2242000001e+01,
lng: 1.3102344444e+02,
cert : false,
content:' Peak = 1102.900024 pos = 32.2420,131.0234 diff = 195.400024'
});
data_saddle.push({
lat: 3.2239666667e+01,
lng: 1.3103888889e+02,
content:'Saddle = 907.500000 pos = 32.2397,131.0389 diff = 195.400024'
});
data_peak.push({
lat: 3.2173555556e+01,
lng: 1.3116877778e+02,
cert : true,
content:'Name = JA6/MZ-041(JA6/MZ-041) peak = 1055.000000 pos = 32.1736,131.1688 diff = 171.299988'
});
data_saddle.push({
lat: 3.2183555556e+01,
lng: 1.3115966667e+02,
content:'Saddle = 883.700012 pos = 32.1836,131.1597 diff = 171.299988'
});
data_peak.push({
lat: 3.2115000001e+01,
lng: 1.3116044444e+02,
cert : false,
content:' Peak = 1044.599976 pos = 32.1150,131.1604 diff = 157.199951'
});
data_saddle.push({
lat: 3.2120444445e+01,
lng: 1.3115922222e+02,
content:'Saddle = 887.400024 pos = 32.1204,131.1592 diff = 157.199951'
});
data_peak.push({
lat: 3.2165777779e+01,
lng: 1.3114144444e+02,
cert : true,
content:'Name = JA6/MZ-034(JA6/MZ-034) peak = 1146.000000 pos = 32.1658,131.1414 diff = 183.400024'
});
data_saddle.push({
lat: 3.2158888890e+01,
lng: 1.3115533333e+02,
content:'Saddle = 962.599976 pos = 32.1589,131.1553 diff = 183.400024'
});
data_peak.push({
lat: 3.2121555556e+01,
lng: 1.3088200000e+02,
cert : false,
content:' Peak = 962.500000 pos = 32.1216,130.8820 diff = 210.799988'
});
data_saddle.push({
lat: 3.2132333334e+01,
lng: 1.3086911111e+02,
content:'Saddle = 751.700012 pos = 32.1323,130.8691 diff = 210.799988'
});
data_peak.push({
lat: 3.2119666667e+01,
lng: 1.3090355556e+02,
cert : true,
content:'Name = JA6/MZ-054(JA6/MZ-054) peak = 940.799988 pos = 32.1197,130.9036 diff = 182.399963'
});
data_saddle.push({
lat: 3.2118222223e+01,
lng: 1.3089166667e+02,
content:'Saddle = 758.400024 pos = 32.1182,130.8917 diff = 182.399963'
});
data_peak.push({
lat: 3.2203333334e+01,
lng: 1.3099900000e+02,
cert : false,
content:' Peak = 953.099976 pos = 32.2033,130.9990 diff = 182.500000'
});
data_saddle.push({
lat: 3.2195666667e+01,
lng: 1.3099211111e+02,
content:'Saddle = 770.599976 pos = 32.1957,130.9921 diff = 182.500000'
});
data_peak.push({
lat: 3.2147333334e+01,
lng: 1.3088744444e+02,
cert : true,
content:'Name = JA6/KM-017(JA6/KM-017) peak = 1118.500000 pos = 32.1473,130.8874 diff = 211.299988'
});
data_saddle.push({
lat: 3.2164888890e+01,
lng: 1.3090455556e+02,
content:'Saddle = 907.200012 pos = 32.1649,130.9046 diff = 211.299988'
});
data_peak.push({
lat: 3.2155444445e+01,
lng: 1.3097822222e+02,
cert : true,
content:'Name = JA6/KM-014(JA6/KM-014) peak = 1182.000000 pos = 32.1554,130.9782 diff = 219.299988'
});
data_saddle.push({
lat: 3.2158222223e+01,
lng: 1.3097233333e+02,
content:'Saddle = 962.700012 pos = 32.1582,130.9723 diff = 219.299988'
});
data_peak.push({
lat: 3.2320777778e+01,
lng: 1.3066933333e+02,
cert : true,
content:'Name = JA6/KM-030(JA6/KM-030) peak = 927.200012 pos = 32.3208,130.6693 diff = 257.299988'
});
data_saddle.push({
lat: 3.2327888890e+01,
lng: 1.3066988889e+02,
content:'Saddle = 669.900024 pos = 32.3279,130.6699 diff = 257.299988'
});
data_peak.push({
lat: 3.2306888890e+01,
lng: 1.3067655556e+02,
cert : true,
content:'Name = JA6/KM-033(JA6/KM-033) peak = 893.299988 pos = 32.3069,130.6766 diff = 215.599976'
});
data_saddle.push({
lat: 3.2311777778e+01,
lng: 1.3067155556e+02,
content:'Saddle = 677.700012 pos = 32.3118,130.6716 diff = 215.599976'
});
data_peak.push({
lat: 3.2506222223e+01,
lng: 1.3140044444e+02,
cert : true,
content:'Name = JA6/MZ-073(JA6/MZ-073) peak = 831.799988 pos = 32.5062,131.4004 diff = 159.299988'
});
data_saddle.push({
lat: 3.2522777778e+01,
lng: 1.3139677778e+02,
content:'Saddle = 672.500000 pos = 32.5228,131.3968 diff = 159.299988'
});
data_peak.push({
lat: 3.2705222223e+01,
lng: 1.3122444444e+02,
cert : true,
content:'Name = JA6/MZ-047(JA6/MZ-047) peak = 980.599976 pos = 32.7052,131.2244 diff = 301.199951'
});
data_saddle.push({
lat: 3.2695444445e+01,
lng: 1.3122388889e+02,
content:'Saddle = 679.400024 pos = 32.6954,131.2239 diff = 301.199951'
});
data_peak.push({
lat: 3.2330888890e+01,
lng: 1.3134622222e+02,
cert : true,
content:'Name = JA6/MZ-060(JA6/MZ-060) peak = 910.099976 pos = 32.3309,131.3462 diff = 228.500000'
});
data_saddle.push({
lat: 3.2321888890e+01,
lng: 1.3131488889e+02,
content:'Saddle = 681.599976 pos = 32.3219,131.3149 diff = 228.500000'
});
data_peak.push({
lat: 3.2267000001e+01,
lng: 1.3105411111e+02,
cert : true,
content:'Name = JA6/MZ-064(JA6/MZ-064) peak = 899.200012 pos = 32.2670,131.0541 diff = 202.700012'
});
data_saddle.push({
lat: 3.2277333334e+01,
lng: 1.3105188889e+02,
content:'Saddle = 696.500000 pos = 32.2773,131.0519 diff = 202.700012'
});
data_peak.push({
lat: 3.2371444445e+01,
lng: 1.3077766667e+02,
cert : true,
content:'Name = Nokeeboshiyama(JA6/KM-009) peak = 1301.199951 pos = 32.3714,130.7777 diff = 597.399963'
});
data_saddle.push({
lat: 3.2452333334e+01,
lng: 1.3073055556e+02,
content:'Saddle = 703.799988 pos = 32.4523,130.7306 diff = 597.399963'
});
data_peak.push({
lat: 3.2325333334e+01,
lng: 1.3071566667e+02,
cert : false,
content:' Peak = 1020.400024 pos = 32.3253,130.7157 diff = 237.900024'
});
data_saddle.push({
lat: 3.2330111112e+01,
lng: 1.3070188889e+02,
content:'Saddle = 782.500000 pos = 32.3301,130.7019 diff = 237.900024'
});
data_peak.push({
lat: 3.2370222223e+01,
lng: 1.3071122222e+02,
cert : true,
content:'Name = JA6/KM-022(JA6/KM-022) peak = 1033.800049 pos = 32.3702,130.7112 diff = 236.600037'
});
data_saddle.push({
lat: 3.2383333334e+01,
lng: 1.3071977778e+02,
content:'Saddle = 797.200012 pos = 32.3833,130.7198 diff = 236.600037'
});
data_peak.push({
lat: 3.2345444445e+01,
lng: 1.3069811111e+02,
cert : true,
content:'Name = JA6/KM-027(JA6/KM-027) peak = 984.000000 pos = 32.3454,130.6981 diff = 172.000000'
});
data_saddle.push({
lat: 3.2356111112e+01,
lng: 1.3070077778e+02,
content:'Saddle = 812.000000 pos = 32.3561,130.7008 diff = 172.000000'
});
data_peak.push({
lat: 3.2425222223e+01,
lng: 1.3076733333e+02,
cert : true,
content:'Name = JA6/KM-026(JA6/KM-026) peak = 991.400024 pos = 32.4252,130.7673 diff = 178.900024'
});
data_saddle.push({
lat: 3.2413777778e+01,
lng: 1.3074344444e+02,
content:'Saddle = 812.500000 pos = 32.4138,130.7434 diff = 178.900024'
});
data_peak.push({
lat: 3.2387000001e+01,
lng: 1.3074055556e+02,
cert : false,
content:' Peak = 1154.699951 pos = 32.3870,130.7406 diff = 166.099976'
});
data_saddle.push({
lat: 3.2383777778e+01,
lng: 1.3077222222e+02,
content:'Saddle = 988.599976 pos = 32.3838,130.7722 diff = 166.099976'
});
data_peak.push({
lat: 3.2291111112e+01,
lng: 1.3128622222e+02,
cert : false,
content:' Peak = 1152.199951 pos = 32.2911,131.2862 diff = 428.399963'
});
data_saddle.push({
lat: 3.2328888890e+01,
lng: 1.3124800000e+02,
content:'Saddle = 723.799988 pos = 32.3289,131.2480 diff = 428.399963'
});
data_peak.push({
lat: 3.2291000001e+01,
lng: 1.3125200000e+02,
cert : false,
content:' Peak = 990.200012 pos = 32.2910,131.2520 diff = 166.900024'
});
data_saddle.push({
lat: 3.2304555556e+01,
lng: 1.3125611111e+02,
content:'Saddle = 823.299988 pos = 32.3046,131.2561 diff = 166.900024'
});
data_peak.push({
lat: 3.2299777778e+01,
lng: 1.3130044444e+02,
cert : false,
content:' Peak = 1045.400024 pos = 32.2998,131.3004 diff = 152.600037'
});
data_saddle.push({
lat: 3.2302444445e+01,
lng: 1.3129422222e+02,
content:'Saddle = 892.799988 pos = 32.3024,131.2942 diff = 152.600037'
});
data_peak.push({
lat: 3.2645000001e+01,
lng: 1.3133877778e+02,
cert : true,
content:'Name = JA6/MZ-063(JA6/MZ-063) peak = 900.500000 pos = 32.6450,131.3388 diff = 169.000000'
});
data_saddle.push({
lat: 3.2636000001e+01,
lng: 1.3131788889e+02,
content:'Saddle = 731.500000 pos = 32.6360,131.3179 diff = 169.000000'
});
data_peak.push({
lat: 3.2243222223e+01,
lng: 1.3123400000e+02,
cert : true,
content:'Name = JA6/MZ-052(JA6/MZ-052) peak = 951.000000 pos = 32.2432,131.2340 diff = 192.700012'
});
data_saddle.push({
lat: 3.2253111112e+01,
lng: 1.3122766667e+02,
content:'Saddle = 758.299988 pos = 32.2531,131.2277 diff = 192.700012'
});
data_peak.push({
lat: 3.2468666667e+01,
lng: 1.3075155556e+02,
cert : true,
content:'Name = JA6/KM-028(JA6/KM-028) peak = 972.799988 pos = 32.4687,130.7516 diff = 195.599976'
});
data_saddle.push({
lat: 3.2478888889e+01,
lng: 1.3076022222e+02,
content:'Saddle = 777.200012 pos = 32.4789,130.7602 diff = 195.599976'
});
data_peak.push({
lat: 3.2685111112e+01,
lng: 1.3122611111e+02,
cert : false,
content:' Peak = 947.099976 pos = 32.6851,131.2261 diff = 150.599976'
});
data_saddle.push({
lat: 3.2678777778e+01,
lng: 1.3123577778e+02,
content:'Saddle = 796.500000 pos = 32.6788,131.2358 diff = 150.599976'
});
data_peak.push({
lat: 3.2429555556e+01,
lng: 1.3134155556e+02,
cert : true,
content:'Name = JA6/MZ-038(JA6/MZ-038) peak = 1103.000000 pos = 32.4296,131.3416 diff = 300.700012'
});
data_saddle.push({
lat: 3.2446555556e+01,
lng: 1.3131800000e+02,
content:'Saddle = 802.299988 pos = 32.4466,131.3180 diff = 300.700012'
});
data_peak.push({
lat: 3.2564333334e+01,
lng: 1.3137366667e+02,
cert : false,
content:' Peak = 1101.199951 pos = 32.5643,131.3737 diff = 244.299927'
});
data_saddle.push({
lat: 3.2617333334e+01,
lng: 1.3132333333e+02,
content:'Saddle = 856.900024 pos = 32.6173,131.3233 diff = 244.299927'
});
data_peak.push({
lat: 3.2612333334e+01,
lng: 1.3134733333e+02,
cert : false,
content:' Peak = 1023.700012 pos = 32.6123,131.3473 diff = 154.600037'
});
data_saddle.push({
lat: 3.2588111112e+01,
lng: 1.3136233333e+02,
content:'Saddle = 869.099976 pos = 32.5881,131.3623 diff = 154.600037'
});
data_peak.push({
lat: 3.2275111112e+01,
lng: 1.3122655556e+02,
cert : true,
content:'Name = JA6/MZ-035(JA6/MZ-035) peak = 1123.500000 pos = 32.2751,131.2266 diff = 254.700012'
});
data_saddle.push({
lat: 3.2285777778e+01,
lng: 1.3121255556e+02,
content:'Saddle = 868.799988 pos = 32.2858,131.2126 diff = 254.700012'
});
data_peak.push({
lat: 3.2253333334e+01,
lng: 1.3118177778e+02,
cert : true,
content:'Name = JA6/MZ-032(JA6/MZ-032) peak = 1188.500000 pos = 32.2533,131.1818 diff = 286.799988'
});
data_saddle.push({
lat: 3.2273000001e+01,
lng: 1.3117466667e+02,
content:'Saddle = 901.700012 pos = 32.2730,131.1747 diff = 286.799988'
});
data_peak.push({
lat: 3.2327777778e+01,
lng: 1.3121600000e+02,
cert : false,
content:' Peak = 1090.099976 pos = 32.3278,131.2160 diff = 178.599976'
});
data_saddle.push({
lat: 3.2334888890e+01,
lng: 1.3120622222e+02,
content:'Saddle = 911.500000 pos = 32.3349,131.2062 diff = 178.599976'
});
data_peak.push({
lat: 3.2677000001e+01,
lng: 1.3125288889e+02,
cert : false,
content:' Peak = 1081.199951 pos = 32.6770,131.2529 diff = 153.699951'
});
data_saddle.push({
lat: 3.2671777778e+01,
lng: 1.3125655556e+02,
content:'Saddle = 927.500000 pos = 32.6718,131.2566 diff = 153.699951'
});
data_peak.push({
lat: 3.2311777778e+01,
lng: 1.3110100000e+02,
cert : true,
content:'Name = Ichifusayama(JA6/MZ-002) peak = 1720.599976 pos = 32.3118,131.1010 diff = 775.399963'
});
data_saddle.push({
lat: 3.2345666667e+01,
lng: 1.3108888889e+02,
content:'Saddle = 945.200012 pos = 32.3457,131.0889 diff = 775.399963'
});
data_peak.push({
lat: 3.2280888890e+01,
lng: 1.3107000000e+02,
cert : false,
content:' Peak = 1105.599976 pos = 32.2809,131.0700 diff = 155.000000'
});
data_saddle.push({
lat: 3.2286888890e+01,
lng: 1.3108188889e+02,
content:'Saddle = 950.599976 pos = 32.2869,131.0819 diff = 155.000000'
});
data_peak.push({
lat: 3.2435333334e+01,
lng: 1.3081877778e+02,
cert : false,
content:' Peak = 1270.199951 pos = 32.4353,130.8188 diff = 317.999939'
});
data_saddle.push({
lat: 3.2518555556e+01,
lng: 1.3084477778e+02,
content:'Saddle = 952.200012 pos = 32.5186,130.8448 diff = 317.999939'
});
data_peak.push({
lat: 3.2494111112e+01,
lng: 1.3080811111e+02,
cert : true,
content:'Name = JA6/KM-016(JA6/KM-016) peak = 1147.699951 pos = 32.4941,130.8081 diff = 181.799927'
});
data_saddle.push({
lat: 3.2471111112e+01,
lng: 1.3081222222e+02,
content:'Saddle = 965.900024 pos = 32.4711,130.8122 diff = 181.799927'
});
data_peak.push({
lat: 3.2454888890e+01,
lng: 1.3081933333e+02,
cert : true,
content:'Name = JA6/KM-011(JA6/KM-011) peak = 1243.699951 pos = 32.4549,130.8193 diff = 170.599976'
});
data_saddle.push({
lat: 3.2440555556e+01,
lng: 1.3081600000e+02,
content:'Saddle = 1073.099976 pos = 32.4406,130.8160 diff = 170.599976'
});
data_peak.push({
lat: 3.2635222223e+01,
lng: 1.3128655556e+02,
cert : true,
content:'Name = Morotsukayama(JA6/MZ-024) peak = 1343.800049 pos = 32.6352,131.2866 diff = 336.200073'
});
data_saddle.push({
lat: 3.2631888889e+01,
lng: 1.3125711111e+02,
content:'Saddle = 1007.599976 pos = 32.6319,131.2571 diff = 336.200073'
});
data_peak.push({
lat: 3.2506111112e+01,
lng: 1.3088188889e+02,
cert : false,
content:' Peak = 1282.599976 pos = 32.5061,130.8819 diff = 269.899963'
});
data_saddle.push({
lat: 3.2532444445e+01,
lng: 1.3087366667e+02,
content:'Saddle = 1012.700012 pos = 32.5324,130.8737 diff = 269.899963'
});
data_peak.push({
lat: 3.2637444445e+01,
lng: 1.3118422222e+02,
cert : true,
content:'Name = JA6/MZ-027(JA6/MZ-027) peak = 1305.500000 pos = 32.6374,131.1842 diff = 284.000000'
});
data_saddle.push({
lat: 3.2629666667e+01,
lng: 1.3118677778e+02,
content:'Saddle = 1021.500000 pos = 32.6297,131.1868 diff = 284.000000'
});
data_peak.push({
lat: 3.2366666667e+01,
lng: 1.3091488889e+02,
cert : true,
content:'Name = JA6/KM-013(JA6/KM-013) peak = 1221.500000 pos = 32.3667,130.9149 diff = 188.900024'
});
data_saddle.push({
lat: 3.2354222223e+01,
lng: 1.3093977778e+02,
content:'Saddle = 1032.599976 pos = 32.3542,130.9398 diff = 188.900024'
});
data_peak.push({
lat: 3.2300333334e+01,
lng: 1.3116766667e+02,
cert : true,
content:'Name = Ishidouyama(JA6/MZ-013) peak = 1545.699951 pos = 32.3003,131.1677 diff = 510.000000'
});
data_saddle.push({
lat: 3.2401222223e+01,
lng: 1.3112777778e+02,
content:'Saddle = 1035.699951 pos = 32.4012,131.1278 diff = 510.000000'
});
data_peak.push({
lat: 3.2374666667e+01,
lng: 1.3119533333e+02,
cert : true,
content:'Name = JA6/MZ-015(JA6/MZ-015) peak = 1476.900024 pos = 32.3747,131.1953 diff = 418.200073'
});
data_saddle.push({
lat: 3.2350777778e+01,
lng: 1.3120211111e+02,
content:'Saddle = 1058.699951 pos = 32.3508,131.2021 diff = 418.200073'
});
data_peak.push({
lat: 3.2362000001e+01,
lng: 1.3116277778e+02,
cert : true,
content:'Name = JA6/MZ-028(JA6/MZ-028) peak = 1302.300049 pos = 32.3620,131.1628 diff = 213.600098'
});
data_saddle.push({
lat: 3.2380555556e+01,
lng: 1.3117388889e+02,
content:'Saddle = 1088.699951 pos = 32.3806,131.1739 diff = 213.600098'
});
data_peak.push({
lat: 3.2444555556e+01,
lng: 1.3124555556e+02,
cert : true,
content:'Name = JA6/MZ-021(JA6/MZ-021) peak = 1365.699951 pos = 32.4446,131.2456 diff = 263.000000'
});
data_saddle.push({
lat: 3.2437666667e+01,
lng: 1.3122722222e+02,
content:'Saddle = 1102.699951 pos = 32.4377,131.2272 diff = 263.000000'
});
data_peak.push({
lat: 3.2423000001e+01,
lng: 1.3118888889e+02,
cert : true,
content:'Name = JA6/MZ-017(JA6/MZ-017) peak = 1430.599976 pos = 32.4230,131.1889 diff = 293.099976'
});
data_saddle.push({
lat: 3.2399888890e+01,
lng: 1.3118822222e+02,
content:'Saddle = 1137.500000 pos = 32.3999,131.1882 diff = 293.099976'
});
data_peak.push({
lat: 3.2411222223e+01,
lng: 1.3114833333e+02,
cert : true,
content:'Name = JA6/MZ-023(JA6/MZ-023) peak = 1358.099976 pos = 32.4112,131.1483 diff = 194.299927'
});
data_saddle.push({
lat: 3.2412444445e+01,
lng: 1.3116844444e+02,
content:'Saddle = 1163.800049 pos = 32.4124,131.1684 diff = 194.299927'
});
data_peak.push({
lat: 3.2340888890e+01,
lng: 1.3119000000e+02,
cert : false,
content:' Peak = 1366.199951 pos = 32.3409,131.1900 diff = 159.299927'
});
data_saddle.push({
lat: 3.2328333334e+01,
lng: 1.3118255556e+02,
content:'Saddle = 1206.900024 pos = 32.3283,131.1826 diff = 159.299927'
});
data_peak.push({
lat: 3.2614555556e+01,
lng: 1.3125266667e+02,
cert : false,
content:' Peak = 1314.800049 pos = 32.6146,131.2527 diff = 278.800049'
});
data_saddle.push({
lat: 3.2594222223e+01,
lng: 1.3123544444e+02,
content:'Saddle = 1036.000000 pos = 32.5942,131.2354 diff = 278.800049'
});
data_peak.push({
lat: 3.2449222223e+01,
lng: 1.3109188889e+02,
cert : true,
content:'Name = JA6/MZ-025(JA6/MZ-025) peak = 1324.800049 pos = 32.4492,131.0919 diff = 282.000000'
});
data_saddle.push({
lat: 3.2437000001e+01,
lng: 1.3108411111e+02,
content:'Saddle = 1042.800049 pos = 32.4370,131.0841 diff = 282.000000'
});
data_peak.push({
lat: 3.2531333334e+01,
lng: 1.3092333333e+02,
cert : false,
content:' Peak = 1398.300049 pos = 32.5313,130.9233 diff = 327.200073'
});
data_saddle.push({
lat: 3.2568444445e+01,
lng: 1.3090911111e+02,
content:'Saddle = 1071.099976 pos = 32.5684,130.9091 diff = 327.200073'
});
data_peak.push({
lat: 3.2370444445e+01,
lng: 1.3107600000e+02,
cert : true,
content:'Name = Eshiroyama (Tsunodake)(JA6/MZ-009) peak = 1605.400024 pos = 32.3704,131.0760 diff = 527.900024'
});
data_saddle.push({
lat: 3.2408555556e+01,
lng: 1.3105266667e+02,
content:'Saddle = 1077.500000 pos = 32.4086,131.0527 diff = 527.900024'
});
data_peak.push({
lat: 3.2642555556e+01,
lng: 1.3111577778e+02,
cert : false,
content:' Peak = 1282.699951 pos = 32.6426,131.1158 diff = 175.399902'
});
data_saddle.push({
lat: 3.2621333334e+01,
lng: 1.3111611111e+02,
content:'Saddle = 1107.300049 pos = 32.6213,131.1161 diff = 175.399902'
});
data_peak.push({
lat: 3.2562000001e+01,
lng: 1.3121900000e+02,
cert : true,
content:'Name = JA6/MZ-016(JA6/MZ-016) peak = 1455.500000 pos = 32.5620,131.2190 diff = 332.500000'
});
data_saddle.push({
lat: 3.2582222223e+01,
lng: 1.3120722222e+02,
content:'Saddle = 1123.000000 pos = 32.5822,131.2072 diff = 332.500000'
});
data_peak.push({
lat: 3.2602666667e+01,
lng: 1.3118844444e+02,
cert : false,
content:' Peak = 1364.000000 pos = 32.6027,131.1884 diff = 231.300049'
});
data_saddle.push({
lat: 3.2564111112e+01,
lng: 1.3114822222e+02,
content:'Saddle = 1132.699951 pos = 32.5641,131.1482 diff = 231.300049'
});
data_peak.push({
lat: 3.2603444445e+01,
lng: 1.3096766667e+02,
cert : true,
content:'Name = JA6/KM-006(JA6/KM-006) peak = 1347.900024 pos = 32.6034,130.9677 diff = 210.900024'
});
data_saddle.push({
lat: 3.2594888889e+01,
lng: 1.3095833333e+02,
content:'Saddle = 1137.000000 pos = 32.5949,130.9583 diff = 210.900024'
});
data_peak.push({
lat: 3.2563777778e+01,
lng: 1.3092566667e+02,
cert : false,
content:' Peak = 1371.099976 pos = 32.5638,130.9257 diff = 159.199951'
});
data_saddle.push({
lat: 3.2573777778e+01,
lng: 1.3092466667e+02,
content:'Saddle = 1211.900024 pos = 32.5738,130.9247 diff = 159.199951'
});
data_peak.push({
lat: 3.2605444445e+01,
lng: 1.3112066667e+02,
cert : false,
content:' Peak = 1542.099976 pos = 32.6054,131.1207 diff = 154.199951'
});
data_saddle.push({
lat: 3.2595111112e+01,
lng: 1.3111500000e+02,
content:'Saddle = 1387.900024 pos = 32.5951,131.1150 diff = 154.199951'
});
data_peak.push({
lat: 3.2517000001e+01,
lng: 1.3112744444e+02,
cert : true,
content:'Name = JA6/MZ-005(JA6/MZ-005) peak = 1661.400024 pos = 32.5170,131.1274 diff = 263.900024'
});
data_saddle.push({
lat: 3.2535222223e+01,
lng: 1.3110855556e+02,
content:'Saddle = 1397.500000 pos = 32.5352,131.1086 diff = 263.900024'
});
data_peak.push({
lat: 3.2579666667e+01,
lng: 1.3110477778e+02,
cert : true,
content:'Name = Mukouzakayama(JA6/MZ-004) peak = 1684.400024 pos = 32.5797,131.1048 diff = 272.500000'
});
data_saddle.push({
lat: 3.2581444445e+01,
lng: 1.3108155556e+02,
content:'Saddle = 1411.900024 pos = 32.5814,131.0816 diff = 272.500000'
});
data_peak.push({
lat: 3.2473333334e+01,
lng: 1.3094677778e+02,
cert : true,
content:'Name = Kamifukuneyama(JA6/KM-001) peak = 1640.000000 pos = 32.4733,130.9468 diff = 209.599976'
});
data_saddle.push({
lat: 3.2456444445e+01,
lng: 1.3100322222e+02,
content:'Saddle = 1430.400024 pos = 32.4564,131.0032 diff = 209.599976'
});
data_peak.push({
lat: 3.2462666667e+01,
lng: 1.3101377778e+02,
cert : true,
content:'Name = JA6/MZ-008(JA6/MZ-008) peak = 1637.900024 pos = 32.4627,131.0138 diff = 166.200073'
});
data_saddle.push({
lat: 3.2492111112e+01,
lng: 1.3100711111e+02,
content:'Saddle = 1471.699951 pos = 32.4921,131.0071 diff = 166.200073'
});
data_peak.push({
lat: 3.3023222223e+01,
lng: 1.3138055556e+02,
cert : false,
content:' Peak = 730.299988 pos = 33.0232,131.3806 diff = 157.200012'
});
data_saddle.push({
lat: 3.3029666667e+01,
lng: 1.3137866667e+02,
content:'Saddle = 573.099976 pos = 33.0297,131.3787 diff = 157.200012'
});
data_peak.push({
lat: 3.3104888889e+01,
lng: 1.3103577778e+02,
cert : false,
content:' Peak = 738.799988 pos = 33.1049,131.0358 diff = 157.000000'
});
data_saddle.push({
lat: 3.3100444445e+01,
lng: 1.3103555556e+02,
content:'Saddle = 581.799988 pos = 33.1004,131.0356 diff = 157.000000'
});
data_peak.push({
lat: 3.3196333334e+01,
lng: 1.3078744444e+02,
cert : true,
content:'Name = JA6/FO-003(JA6/FO-003) peak = 942.500000 pos = 33.1963,130.7874 diff = 344.599976'
});
data_saddle.push({
lat: 3.3197333334e+01,
lng: 1.3080688889e+02,
content:'Saddle = 597.900024 pos = 33.1973,130.8069 diff = 344.599976'
});
data_peak.push({
lat: 3.3039000000e+01,
lng: 1.3139388889e+02,
cert : true,
content:'Name = JA6/OT-036(JA6/OT-036) peak = 767.299988 pos = 33.0390,131.3939 diff = 159.799988'
});
data_saddle.push({
lat: 3.3038333334e+01,
lng: 1.3136066667e+02,
content:'Saddle = 607.500000 pos = 33.0383,131.3607 diff = 159.799988'
});
data_peak.push({
lat: 3.3104555556e+01,
lng: 1.3101677778e+02,
cert : true,
content:'Name = JA6/KM-037(JA6/KM-037) peak = 833.299988 pos = 33.1046,131.0168 diff = 224.700012'
});
data_saddle.push({
lat: 3.3074888889e+01,
lng: 1.3101700000e+02,
content:'Saddle = 608.599976 pos = 33.0749,131.0170 diff = 224.700012'
});
data_peak.push({
lat: 3.3281666667e+01,
lng: 1.3119077778e+02,
cert : true,
content:'Name = JA6/OT-034(JA6/OT-034) peak = 814.799988 pos = 33.2817,131.1908 diff = 181.599976'
});
data_saddle.push({
lat: 3.3301222223e+01,
lng: 1.3119055556e+02,
content:'Saddle = 633.200012 pos = 33.3012,131.1906 diff = 181.599976'
});
data_peak.push({
lat: 3.3327222222e+01,
lng: 1.3138211111e+02,
cert : true,
content:'Name = JA6/OT-033(JA6/OT-033) peak = 830.500000 pos = 33.3272,131.3821 diff = 191.400024'
});
data_saddle.push({
lat: 3.3320777778e+01,
lng: 1.3138544444e+02,
content:'Saddle = 639.099976 pos = 33.3208,131.3854 diff = 191.400024'
});
data_peak.push({
lat: 3.3244111111e+01,
lng: 1.3120466667e+02,
cert : true,
content:'Name = JA6/OT-032(JA6/OT-032) peak = 850.299988 pos = 33.2441,131.2047 diff = 198.399963'
});
data_saddle.push({
lat: 3.3255111111e+01,
lng: 1.3121733333e+02,
content:'Saddle = 651.900024 pos = 33.2551,131.2173 diff = 198.399963'
});
data_peak.push({
lat: 3.2898666667e+01,
lng: 1.3097755556e+02,
cert : true,
content:'Name = JA6/KM-035(JA6/KM-035) peak = 860.500000 pos = 32.8987,130.9776 diff = 203.700012'
});
data_saddle.push({
lat: 3.2911777778e+01,
lng: 1.3096811111e+02,
content:'Saddle = 656.799988 pos = 32.9118,130.9681 diff = 203.700012'
});
data_peak.push({
lat: 3.3323888889e+01,
lng: 1.3122566667e+02,
cert : true,
content:'Name = JA6/OT-029(JA6/OT-029) peak = 890.700012 pos = 33.3239,131.2257 diff = 233.000000'
});
data_saddle.push({
lat: 3.3312555556e+01,
lng: 1.3126677778e+02,
content:'Saddle = 657.700012 pos = 33.3126,131.2668 diff = 233.000000'
});
data_peak.push({
lat: 3.2736000001e+01,
lng: 1.3133166667e+02,
cert : false,
content:' Peak = 823.599976 pos = 32.7360,131.3317 diff = 152.799988'
});
data_saddle.push({
lat: 3.2753777778e+01,
lng: 1.3133388889e+02,
content:'Saddle = 670.799988 pos = 32.7538,131.3339 diff = 152.799988'
});
data_peak.push({
lat: 3.3282444445e+01,
lng: 1.3139022222e+02,
cert : true,
content:'Name = Yufudake (Bungofuji)(JA6/OT-006) peak = 1582.000000 pos = 33.2824,131.3902 diff = 905.200012'
});
data_saddle.push({
lat: 3.3303222223e+01,
lng: 1.3133400000e+02,
content:'Saddle = 676.799988 pos = 33.3032,131.3340 diff = 905.200012'
});
data_peak.push({
lat: 3.3309444445e+01,
lng: 1.3135266667e+02,
cert : true,
content:'Name = JA6/OT-022(JA6/OT-022) peak = 1072.300049 pos = 33.3094,131.3527 diff = 336.300049'
});
data_saddle.push({
lat: 3.3296000000e+01,
lng: 1.3136644444e+02,
content:'Saddle = 736.000000 pos = 33.2960,131.3664 diff = 336.300049'
});
data_peak.push({
lat: 3.3290333334e+01,
lng: 1.3136622222e+02,
cert : false,
content:' Peak = 923.500000 pos = 33.2903,131.3662 diff = 183.900024'
});
data_saddle.push({
lat: 3.3290666667e+01,
lng: 1.3137122222e+02,
content:'Saddle = 739.599976 pos = 33.2907,131.3712 diff = 183.900024'
});
data_peak.push({
lat: 3.3228888889e+01,
lng: 1.3137400000e+02,
cert : false,
content:' Peak = 1165.099976 pos = 33.2289,131.3740 diff = 388.500000'
});
data_saddle.push({
lat: 3.3264888889e+01,
lng: 1.3139488889e+02,
content:'Saddle = 776.599976 pos = 33.2649,131.3949 diff = 388.500000'
});
data_peak.push({
lat: 3.3228111111e+01,
lng: 1.3139622222e+02,
cert : false,
content:' Peak = 1105.400024 pos = 33.2281,131.3962 diff = 158.100037'
});
data_saddle.push({
lat: 3.3230666667e+01,
lng: 1.3139122222e+02,
content:'Saddle = 947.299988 pos = 33.2307,131.3912 diff = 158.100037'
});
data_peak.push({
lat: 3.3243222223e+01,
lng: 1.3137822222e+02,
cert : true,
content:'Name = JA6/OT-018(JA6/OT-018) peak = 1162.000000 pos = 33.2432,131.3782 diff = 154.500000'
});
data_saddle.push({
lat: 3.3239888889e+01,
lng: 1.3137877778e+02,
content:'Saddle = 1007.500000 pos = 33.2399,131.3788 diff = 154.500000'
});
data_peak.push({
lat: 3.3286666667e+01,
lng: 1.3142977778e+02,
cert : true,
content:'Name = Tsurumidake(JA6/OT-009) peak = 1371.500000 pos = 33.2867,131.4298 diff = 555.400024'
});
data_saddle.push({
lat: 3.3285555556e+01,
lng: 1.3141100000e+02,
content:'Saddle = 816.099976 pos = 33.2856,131.4110 diff = 555.400024'
});
data_peak.push({
lat: 3.3300222223e+01,
lng: 1.3142033333e+02,
cert : false,
content:' Peak = 1274.699951 pos = 33.3002,131.4203 diff = 155.799927'
});
data_saddle.push({
lat: 3.3297777778e+01,
lng: 1.3141933333e+02,
content:'Saddle = 1118.900024 pos = 33.2978,131.4193 diff = 155.799927'
});
data_peak.push({
lat: 3.3231333334e+01,
lng: 1.3113066667e+02,
cert : false,
content:' Peak = 1140.099976 pos = 33.2313,131.1307 diff = 462.199951'
});
data_saddle.push({
lat: 3.3178111111e+01,
lng: 1.3111688889e+02,
content:'Saddle = 677.900024 pos = 33.1781,131.1169 diff = 462.199951'
});
data_peak.push({
lat: 3.3194888889e+01,
lng: 1.3106388889e+02,
cert : false,
content:' Peak = 942.000000 pos = 33.1949,131.0639 diff = 174.200012'
});
data_saddle.push({
lat: 3.3195888889e+01,
lng: 1.3109800000e+02,
content:'Saddle = 767.799988 pos = 33.1959,131.0980 diff = 174.200012'
});
data_peak.push({
lat: 3.3187555556e+01,
lng: 1.3088900000e+02,
cert : true,
content:'Name = Shakadake(JA6/OT-014) peak = 1230.599976 pos = 33.1876,130.8890 diff = 552.599976'
});
data_saddle.push({
lat: 3.3065222223e+01,
lng: 1.3090622222e+02,
content:'Saddle = 678.000000 pos = 33.0652,130.9062 diff = 552.599976'
});
data_peak.push({
lat: 3.3097000000e+01,
lng: 1.3090833333e+02,
cert : true,
content:'Name = Shyutendoujiyama(JA6/OT-017) peak = 1180.300049 pos = 33.0970,130.9083 diff = 497.900024'
});
data_saddle.push({
lat: 3.3090888889e+01,
lng: 1.3086833333e+02,
content:'Saddle = 682.400024 pos = 33.0909,130.8683 diff = 497.900024'
});
data_peak.push({
lat: 3.3070333334e+01,
lng: 1.3083466667e+02,
cert : true,
content:'Name = JA6/KM-021(JA6/KM-021) peak = 1051.199951 pos = 33.0703,130.8347 diff = 304.399963'
});
data_saddle.push({
lat: 3.3137333334e+01,
lng: 1.3086888889e+02,
content:'Saddle = 746.799988 pos = 33.1373,130.8689 diff = 304.399963'
});
data_peak.push({
lat: 3.3105444445e+01,
lng: 1.3081744444e+02,
cert : true,
content:'Name = Kunimiyama(JA6/KM-023) peak = 1016.000000 pos = 33.1054,130.8174 diff = 262.000000'
});
data_saddle.push({
lat: 3.3085555556e+01,
lng: 1.3084077778e+02,
content:'Saddle = 754.000000 pos = 33.0856,130.8408 diff = 262.000000'
});
data_peak.push({
lat: 3.3172333334e+01,
lng: 1.3092788889e+02,
cert : true,
content:'Name = JA6/OT-019(JA6/OT-019) peak = 1150.099976 pos = 33.1723,130.9279 diff = 236.500000'
});
data_saddle.push({
lat: 3.3181777778e+01,
lng: 1.3092266667e+02,
content:'Saddle = 913.599976 pos = 33.1818,130.9227 diff = 236.500000'
});
data_peak.push({
lat: 3.3336333334e+01,
lng: 1.3129344444e+02,
cert : true,
content:'Name = JA6/OT-027(JA6/OT-027) peak = 920.599976 pos = 33.3363,131.2934 diff = 229.299988'
});
data_saddle.push({
lat: 3.3319888889e+01,
lng: 1.3132211111e+02,
content:'Saddle = 691.299988 pos = 33.3199,131.3221 diff = 229.299988'
});
data_peak.push({
lat: 3.3287555556e+01,
lng: 1.3131700000e+02,
cert : true,
content:'Name = JA6/OT-013(JA6/OT-013) peak = 1234.000000 pos = 33.2876,131.3170 diff = 524.900024'
});
data_saddle.push({
lat: 3.3249666667e+01,
lng: 1.3129466667e+02,
content:'Saddle = 709.099976 pos = 33.2497,131.2947 diff = 524.900024'
});
data_peak.push({
lat: 3.3261777778e+01,
lng: 1.3123588889e+02,
cert : true,
content:'Name = JA6/OT-024(JA6/OT-024) peak = 1034.500000 pos = 33.2618,131.2359 diff = 253.299988'
});
data_saddle.push({
lat: 3.3275333334e+01,
lng: 1.3127711111e+02,
content:'Saddle = 781.200012 pos = 33.2753,131.2771 diff = 253.299988'
});
data_peak.push({
lat: 3.2696222223e+01,
lng: 1.3138800000e+02,
cert : false,
content:' Peak = 951.299988 pos = 32.6962,131.3880 diff = 238.000000'
});
data_saddle.push({
lat: 3.2704666667e+01,
lng: 1.3138500000e+02,
content:'Saddle = 713.299988 pos = 32.7047,131.3850 diff = 238.000000'
});
data_peak.push({
lat: 3.2828111112e+01,
lng: 1.3134700000e+02,
cert : true,
content:'Name = Sobosan(JA6/OT-003) peak = 1754.800049 pos = 32.8281,131.3470 diff = 990.600037'
});
data_saddle.push({
lat: 3.2991666667e+01,
lng: 1.3114200000e+02,
content:'Saddle = 764.200012 pos = 32.9917,131.1420 diff = 990.600037'
});
data_peak.push({
lat: 3.2651888889e+01,
lng: 1.3147422222e+02,
cert : false,
content:' Peak = 950.799988 pos = 32.6519,131.4742 diff = 163.700012'
});
data_saddle.push({
lat: 3.2665333334e+01,
lng: 1.3148455556e+02,
content:'Saddle = 787.099976 pos = 32.6653,131.4846 diff = 163.700012'
});
data_peak.push({
lat: 3.2884333334e+01,
lng: 1.3110388889e+02,
cert : true,
content:'Name = Asosan (Takadake)(JA6/KM-002) peak = 1591.400024 pos = 32.8843,131.1039 diff = 793.400024'
});
data_saddle.push({
lat: 3.2845888889e+01,
lng: 1.3123255556e+02,
content:'Saddle = 798.000000 pos = 32.8459,131.2326 diff = 793.400024'
});
data_peak.push({
lat: 3.2788777778e+01,
lng: 1.3100500000e+02,
cert : true,
content:'Name = JA6/KM-012(JA6/KM-012) peak = 1235.300049 pos = 32.7888,131.0050 diff = 397.000061'
});
data_saddle.push({
lat: 3.2804111112e+01,
lng: 1.3114033333e+02,
content:'Saddle = 838.299988 pos = 32.8041,131.1403 diff = 397.000061'
});
data_peak.push({
lat: 3.2838000000e+01,
lng: 1.3097022222e+02,
cert : true,
content:'Name = JA6/KM-020(JA6/KM-020) peak = 1101.300049 pos = 32.8380,130.9702 diff = 203.300049'
});
data_saddle.push({
lat: 3.2831666667e+01,
lng: 1.3097444444e+02,
content:'Saddle = 898.000000 pos = 32.8317,130.9744 diff = 203.300049'
});
data_peak.push({
lat: 3.2883555556e+01,
lng: 1.3114433333e+02,
cert : true,
content:'Name = Asosan (Nekodake)(JA6/KM-003) peak = 1432.699951 pos = 32.8836,131.1443 diff = 452.999939'
});
data_saddle.push({
lat: 3.2886000000e+01,
lng: 1.3113033333e+02,
content:'Saddle = 979.700012 pos = 32.8860,131.1303 diff = 452.999939'
});
data_peak.push({
lat: 3.2873777778e+01,
lng: 1.3105811111e+02,
cert : false,
content:' Peak = 1334.300049 pos = 32.8738,131.0581 diff = 228.600098'
});
data_saddle.push({
lat: 3.2885000000e+01,
lng: 1.3106766667e+02,
content:'Saddle = 1105.699951 pos = 32.8850,131.0677 diff = 228.600098'
});
data_peak.push({
lat: 3.2892666667e+01,
lng: 1.3105766667e+02,
cert : true,
content:'Name = Asosan (Kishimadake)(JA6/KM-008) peak = 1324.300049 pos = 32.8927,131.0577 diff = 192.100098'
});
data_saddle.push({
lat: 3.2878888889e+01,
lng: 1.3105111111e+02,
content:'Saddle = 1132.199951 pos = 32.8789,131.0511 diff = 192.100098'
});
data_peak.push({
lat: 3.2804666667e+01,
lng: 1.3125533333e+02,
cert : true,
content:'Name = JA6/MZ-040(JA6/MZ-040) peak = 1086.699951 pos = 32.8047,131.2553 diff = 234.199951'
});
data_saddle.push({
lat: 3.2803444445e+01,
lng: 1.3126633333e+02,
content:'Saddle = 852.500000 pos = 32.8034,131.2663 diff = 234.199951'
});
data_peak.push({
lat: 3.2737777778e+01,
lng: 1.3151322222e+02,
cert : true,
content:'Name = Ookueyama(JA6/MZ-006) peak = 1643.400024 pos = 32.7378,131.5132 diff = 761.900024'
});
data_saddle.push({
lat: 3.2815555556e+01,
lng: 1.3149766667e+02,
content:'Saddle = 881.500000 pos = 32.8156,131.4977 diff = 761.900024'
});
data_peak.push({
lat: 3.2702666667e+01,
lng: 1.3152844444e+02,
cert : true,
content:'Name = JA6/MZ-014(JA6/MZ-014) peak = 1490.699951 pos = 32.7027,131.5284 diff = 437.799927'
});
data_saddle.push({
lat: 3.2722444445e+01,
lng: 1.3152100000e+02,
content:'Saddle = 1052.900024 pos = 32.7224,131.5210 diff = 437.799927'
});
data_peak.push({
lat: 3.2695222223e+01,
lng: 1.3155622222e+02,
cert : false,
content:' Peak = 1242.300049 pos = 32.6952,131.5562 diff = 180.100098'
});
data_saddle.push({
lat: 3.2700555556e+01,
lng: 1.3154077778e+02,
content:'Saddle = 1062.199951 pos = 32.7006,131.5408 diff = 180.100098'
});
data_peak.push({
lat: 3.2795000000e+01,
lng: 1.3151522222e+02,
cert : true,
content:'Name = JA6/OT-011(JA6/OT-011) peak = 1296.199951 pos = 32.7950,131.5152 diff = 154.500000'
});
data_saddle.push({
lat: 3.2786777778e+01,
lng: 1.3150966667e+02,
content:'Saddle = 1141.699951 pos = 32.7868,131.5097 diff = 154.500000'
});
data_peak.push({
lat: 3.2754111112e+01,
lng: 1.3156855556e+02,
cert : true,
content:'Name = JA6/MZ-018(JA6/MZ-018) peak = 1406.500000 pos = 32.7541,131.5686 diff = 238.400024'
});
data_saddle.push({
lat: 3.2756666667e+01,
lng: 1.3155155556e+02,
content:'Saddle = 1168.099976 pos = 32.7567,131.5516 diff = 238.400024'
});
data_peak.push({
lat: 3.2708888889e+01,
lng: 1.3144488889e+02,
cert : true,
content:'Name = JA6/MZ-020(JA6/MZ-020) peak = 1394.900024 pos = 32.7089,131.4449 diff = 222.800049'
});
data_saddle.push({
lat: 3.2718888889e+01,
lng: 1.3144455556e+02,
content:'Saddle = 1172.099976 pos = 32.7189,131.4446 diff = 222.800049'
});
data_peak.push({
lat: 3.2758888889e+01,
lng: 1.3153655556e+02,
cert : false,
content:' Peak = 1400.599976 pos = 32.7589,131.5366 diff = 193.000000'
});
data_saddle.push({
lat: 3.2762111112e+01,
lng: 1.3153322222e+02,
content:'Saddle = 1207.599976 pos = 32.7621,131.5332 diff = 193.000000'
});
data_peak.push({
lat: 3.2739888889e+01,
lng: 1.3146266667e+02,
cert : true,
content:'Name = JA6/MZ-010(JA6/MZ-010) peak = 1580.199951 pos = 32.7399,131.4627 diff = 248.799927'
});
data_saddle.push({
lat: 3.2749222223e+01,
lng: 1.3146555556e+02,
content:'Saddle = 1331.400024 pos = 32.7492,131.4656 diff = 248.799927'
});
data_peak.push({
lat: 3.2764666667e+01,
lng: 1.3148322222e+02,
cert : true,
content:'Name = JA6/MZ-012(JA6/MZ-012) peak = 1570.400024 pos = 32.7647,131.4832 diff = 218.200073'
});
data_saddle.push({
lat: 3.2746000001e+01,
lng: 1.3149688889e+02,
content:'Saddle = 1352.199951 pos = 32.7460,131.4969 diff = 218.200073'
});
data_peak.push({
lat: 3.2754333334e+01,
lng: 1.3140166667e+02,
cert : true,
content:'Name = JA6/MZ-029(JA6/MZ-029) peak = 1261.300049 pos = 32.7543,131.4017 diff = 258.400024'
});
data_saddle.push({
lat: 3.2787666667e+01,
lng: 1.3141522222e+02,
content:'Saddle = 1002.900024 pos = 32.7877,131.4152 diff = 258.400024'
});
data_peak.push({
lat: 3.2811777778e+01,
lng: 1.3142111111e+02,
cert : true,
content:'Name = JA6/MZ-007(JA6/MZ-007) peak = 1643.199951 pos = 32.8118,131.4211 diff = 482.500000'
});
data_saddle.push({
lat: 3.2810222223e+01,
lng: 1.3138666667e+02,
content:'Saddle = 1160.699951 pos = 32.8102,131.3867 diff = 482.500000'
});
data_peak.push({
lat: 3.2839000000e+01,
lng: 1.3147577778e+02,
cert : true,
content:'Name = Katamukiyama(JA6/OT-004) peak = 1603.099976 pos = 32.8390,131.4758 diff = 340.199951'
});
data_saddle.push({
lat: 3.2830111112e+01,
lng: 1.3145677778e+02,
content:'Saddle = 1262.900024 pos = 32.8301,131.4568 diff = 340.199951'
});
data_peak.push({
lat: 3.2847888889e+01,
lng: 1.3138722222e+02,
cert : false,
content:' Peak = 1450.400024 pos = 32.8479,131.3872 diff = 168.800049'
});
data_saddle.push({
lat: 3.2845222223e+01,
lng: 1.3138333333e+02,
content:'Saddle = 1281.599976 pos = 32.8452,131.3833 diff = 168.800049'
});
data_peak.push({
lat: 3.2810666667e+01,
lng: 1.3134800000e+02,
cert : true,
content:'Name = JA6/MZ-003(JA6/MZ-003) peak = 1705.400024 pos = 32.8107,131.3480 diff = 182.700073'
});
data_saddle.push({
lat: 3.2819000000e+01,
lng: 1.3134966667e+02,
content:'Saddle = 1522.699951 pos = 32.8190,131.3497 diff = 182.700073'
});
data_peak.push({
lat: 3.2953444445e+01,
lng: 1.3093388889e+02,
cert : true,
content:'Name = JA6/KM-018(JA6/KM-018) peak = 1115.000000 pos = 32.9534,130.9339 diff = 331.799988'
});
data_saddle.push({
lat: 3.3039333334e+01,
lng: 1.3116600000e+02,
content:'Saddle = 783.200012 pos = 33.0393,131.1660 diff = 331.799988'
});
data_peak.push({
lat: 3.3052333334e+01,
lng: 1.3093722222e+02,
cert : true,
content:'Name = JA6/KM-025(JA6/KM-025) peak = 1015.299988 pos = 33.0523,130.9372 diff = 193.899963'
});
data_saddle.push({
lat: 3.3032444445e+01,
lng: 1.3098422222e+02,
content:'Saddle = 821.400024 pos = 33.0324,130.9842 diff = 193.899963'
});
data_peak.push({
lat: 3.3163111111e+01,
lng: 1.3135744444e+02,
cert : true,
content:'Name = JA6/OT-026(JA6/OT-026) peak = 956.700012 pos = 33.1631,131.3574 diff = 167.700012'
});
data_saddle.push({
lat: 3.3167555556e+01,
lng: 1.3135222222e+02,
content:'Saddle = 789.000000 pos = 33.1676,131.3522 diff = 167.700012'
});
data_peak.push({
lat: 3.3223777778e+01,
lng: 1.3129011111e+02,
cert : true,
content:'Name = JA6/OT-023(JA6/OT-023) peak = 1037.199951 pos = 33.2238,131.2901 diff = 164.299927'
});
data_saddle.push({
lat: 3.3207888889e+01,
lng: 1.3128444444e+02,
content:'Saddle = 872.900024 pos = 33.2079,131.2844 diff = 164.299927'
});
data_peak.push({
lat: 3.3142777778e+01,
lng: 1.3129477778e+02,
cert : false,
content:' Peak = 1310.500000 pos = 33.1428,131.2948 diff = 352.099976'
});
data_saddle.push({
lat: 3.3135555556e+01,
lng: 1.3128266667e+02,
content:'Saddle = 958.400024 pos = 33.1356,131.2827 diff = 352.099976'
});
data_peak.push({
lat: 3.3182000000e+01,
lng: 1.3125788889e+02,
cert : true,
content:'Name = JA6/OT-012(JA6/OT-012) peak = 1287.800049 pos = 33.1820,131.2579 diff = 256.300049'
});
data_saddle.push({
lat: 3.3177222223e+01,
lng: 1.3126766667e+02,
content:'Saddle = 1031.500000 pos = 33.1772,131.2677 diff = 256.300049'
});
data_peak.push({
lat: 3.3174333334e+01,
lng: 1.3128000000e+02,
cert : true,
content:'Name = JA6/OT-015(JA6/OT-015) peak = 1205.199951 pos = 33.1743,131.2800 diff = 167.199951'
});
data_saddle.push({
lat: 3.3162222223e+01,
lng: 1.3128811111e+02,
content:'Saddle = 1038.000000 pos = 33.1622,131.2881 diff = 167.199951'
});
data_peak.push({
lat: 3.3139777778e+01,
lng: 1.3116433333e+02,
cert : true,
content:'Name = Waitazan(JA6/OT-008) peak = 1497.599976 pos = 33.1398,131.1643 diff = 344.000000'
});
data_saddle.push({
lat: 3.3100777778e+01,
lng: 1.3117677778e+02,
content:'Saddle = 1153.599976 pos = 33.1008,131.1768 diff = 344.000000'
});
data_peak.push({
lat: 3.3106000000e+01,
lng: 1.3129288889e+02,
cert : true,
content:'Name = Kujyuurenzan (Kurodake)(JA6/OT-005) peak = 1586.699951 pos = 33.1060,131.2929 diff = 319.199951'
});
data_saddle.push({
lat: 3.3105777778e+01,
lng: 1.3128788889e+02,
content:'Saddle = 1267.500000 pos = 33.1058,131.2879 diff = 319.199951'
});
data_peak.push({
lat: 3.3106444445e+01,
lng: 1.3120711111e+02,
cert : true,
content:'Name = JA6/OT-007(JA6/OT-007) peak = 1501.699951 pos = 33.1064,131.2071 diff = 168.799927'
});
data_saddle.push({
lat: 3.3096444445e+01,
lng: 1.3120844444e+02,
content:'Saddle = 1332.900024 pos = 33.0964,131.2084 diff = 168.799927'
});
data_peak.push({
lat: 3.3095111111e+01,
lng: 1.3128066667e+02,
cert : false,
content:' Peak = 1784.000000 pos = 33.0951,131.2807 diff = 415.800049'
});
data_saddle.push({
lat: 3.3089333334e+01,
lng: 1.3126077778e+02,
content:'Saddle = 1368.199951 pos = 33.0893,131.2608 diff = 415.800049'
});
data_peak.push({
lat: 3.3112333334e+01,
lng: 1.3127277778e+02,
cert : false,
content:' Peak = 1642.000000 pos = 33.1123,131.2728 diff = 179.900024'
});
data_saddle.push({
lat: 3.3107666667e+01,
lng: 1.3127388889e+02,
content:'Saddle = 1462.099976 pos = 33.1077,131.2739 diff = 179.900024'
});
data_peak.push({
lat: 3.3104000000e+01,
lng: 1.3124644444e+02,
cert : false,
content:' Peak = 1743.900024 pos = 33.1040,131.2464 diff = 236.500000'
});
data_saddle.push({
lat: 3.3097222223e+01,
lng: 1.3124222222e+02,
content:'Saddle = 1507.400024 pos = 33.0972,131.2422 diff = 236.500000'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:34,
       south:31.3333,
       east:132,
       west:130}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
