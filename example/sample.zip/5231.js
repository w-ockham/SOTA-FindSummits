function map_canvas() {
 var data_peak = new Array();
 var data_saddle = new Array();
 var polylines = new Array();
data_peak.push({
lat: 3.4595444445e+01,
lng: 1.3212966667e+02,
cert : true,
content:'Name = Osorakanzan(JA/HS-001) peak = 1344.199951 pos = 34.5954,132.1297 diff = 1344.199951'
});
data_saddle.push({
lat: 3.4364555556e+01,
lng: 1.3251644444e+02,
content:'Saddle = 0.000000 pos = 34.3646,132.5164 diff = 1344.199951'
});
data_peak.push({
lat: 3.4102333334e+01,
lng: 1.3247122222e+02,
cert : true,
content:'Name = JA/HS-173(JA/HS-173) peak = 492.200012 pos = 34.1023,132.4712 diff = 492.200012'
});
data_saddle.push({
lat: 3.4083333334e+01,
lng: 1.3255677778e+02,
content:'Saddle = 0.000000 pos = 34.0833,132.5568 diff = 492.200012'
});
data_peak.push({
lat: 3.4175222223e+01,
lng: 1.3251222222e+02,
cert : true,
content:'Name = JA/HS-215(JA/HS-215) peak = 342.700012 pos = 34.1752,132.5122 diff = 313.100006'
});
data_saddle.push({
lat: 3.4151666667e+01,
lng: 1.3251555556e+02,
content:'Saddle = 29.600000 pos = 34.1517,132.5156 diff = 313.100006'
});
data_peak.push({
lat: 3.4102444445e+01,
lng: 1.3255988889e+02,
cert : false,
content:' Peak = 270.799988 pos = 34.1024,132.5599 diff = 233.999985'
});
data_saddle.push({
lat: 3.4102222223e+01,
lng: 1.3254033333e+02,
content:'Saddle = 36.799999 pos = 34.1022,132.5403 diff = 233.999985'
});
data_peak.push({
lat: 3.4116444445e+01,
lng: 1.3251844444e+02,
cert : true,
content:'Name = JA/HS-184(JA/HS-184) peak = 462.799988 pos = 34.1164,132.5184 diff = 315.399994'
});
data_saddle.push({
lat: 3.4116333334e+01,
lng: 1.3250622222e+02,
content:'Saddle = 147.399994 pos = 34.1163,132.5062 diff = 315.399994'
});
data_peak.push({
lat: 3.4160777778e+01,
lng: 1.3282111111e+02,
cert : false,
content:' Peak = 334.200012 pos = 34.1608,132.8211 diff = 334.200012'
});
data_saddle.push({
lat: 3.4150888889e+01,
lng: 1.3282011111e+02,
content:'Saddle = 0.000000 pos = 34.1509,132.8201 diff = 334.200012'
});
data_peak.push({
lat: 3.4166666667e+01,
lng: 1.3284300000e+02,
cert : false,
content:' Peak = 267.100006 pos = 34.1667,132.8430 diff = 193.500000'
});
data_saddle.push({
lat: 3.4166666667e+01,
lng: 1.3283744444e+02,
content:'Saddle = 73.599998 pos = 34.1667,132.8374 diff = 193.500000'
});
data_peak.push({
lat: 3.4193111112e+01,
lng: 1.3230833333e+02,
cert : true,
content:'Name = JA/HS-229(JA/HS-229) peak = 202.500000 pos = 34.1931,132.3083 diff = 202.500000'
});
data_saddle.push({
lat: 3.4184333334e+01,
lng: 1.3230544444e+02,
content:'Saddle = 0.000000 pos = 34.1843,132.3054 diff = 202.500000'
});
data_peak.push({
lat: 3.4182666667e+01,
lng: 1.3266333333e+02,
cert : true,
content:'Name = JA/HS-224(JA/HS-224) peak = 274.299988 pos = 34.1827,132.6633 diff = 274.299988'
});
data_saddle.push({
lat: 3.4169444445e+01,
lng: 1.3266288889e+02,
content:'Saddle = 0.000000 pos = 34.1694,132.6629 diff = 274.299988'
});
data_peak.push({
lat: 3.4166666667e+01,
lng: 1.3278244444e+02,
cert : false,
content:' Peak = 302.200012 pos = 34.1667,132.7824 diff = 302.200012'
});
data_saddle.push({
lat: 3.4160777778e+01,
lng: 1.3278200000e+02,
content:'Saddle = 0.000000 pos = 34.1608,132.7820 diff = 302.200012'
});
data_peak.push({
lat: 3.4181555556e+01,
lng: 1.3272800000e+02,
cert : true,
content:'Name = JA/HS-186(JA/HS-186) peak = 453.000000 pos = 34.1816,132.7280 diff = 453.000000'
});
data_saddle.push({
lat: 3.4157777778e+01,
lng: 1.3273900000e+02,
content:'Saddle = 0.000000 pos = 34.1578,132.7390 diff = 453.000000'
});
data_peak.push({
lat: 3.4171222223e+01,
lng: 1.3274944444e+02,
cert : false,
content:' Peak = 220.699997 pos = 34.1712,132.7494 diff = 192.300003'
});
data_saddle.push({
lat: 3.4176111112e+01,
lng: 1.3274733333e+02,
content:'Saddle = 28.400000 pos = 34.1761,132.7473 diff = 192.300003'
});
data_peak.push({
lat: 3.4193444445e+01,
lng: 1.3270911111e+02,
cert : true,
content:'Name = JA/HS-202(JA/HS-202) peak = 420.600006 pos = 34.1934,132.7091 diff = 311.299988'
});
data_saddle.push({
lat: 3.4183777778e+01,
lng: 1.3271755556e+02,
content:'Saddle = 109.300003 pos = 34.1838,132.7176 diff = 311.299988'
});
data_peak.push({
lat: 3.4156222223e+01,
lng: 1.3239600000e+02,
cert : true,
content:'Name = JA/HS-183(JA/HS-183) peak = 460.799988 pos = 34.1562,132.3960 diff = 460.799988'
});
data_saddle.push({
lat: 3.4146333334e+01,
lng: 1.3239766667e+02,
content:'Saddle = 0.000000 pos = 34.1463,132.3977 diff = 460.799988'
});
data_peak.push({
lat: 3.4335222223e+01,
lng: 1.3248255556e+02,
cert : true,
content:'Name = JA/HS-234(JA/HS-234) peak = 155.699997 pos = 34.3352,132.4826 diff = 155.699997'
});
data_saddle.push({
lat: 3.4330222223e+01,
lng: 1.3248077778e+02,
content:'Saddle = 0.000000 pos = 34.3302,132.4808 diff = 155.699997'
});
data_peak.push({
lat: 3.4319222223e+01,
lng: 1.3243977778e+02,
cert : false,
content:' Peak = 277.200012 pos = 34.3192,132.4398 diff = 277.200012'
});
data_saddle.push({
lat: 3.4296777778e+01,
lng: 1.3244266667e+02,
content:'Saddle = 0.000000 pos = 34.2968,132.4427 diff = 277.200012'
});
data_peak.push({
lat: 3.4301555556e+01,
lng: 1.3243200000e+02,
cert : true,
content:'Name = JA/HS-230(JA/HS-230) peak = 200.300003 pos = 34.3016,132.4320 diff = 158.899994'
});
data_saddle.push({
lat: 3.4308666667e+01,
lng: 1.3243611111e+02,
content:'Saddle = 41.400002 pos = 34.3087,132.4361 diff = 158.899994'
});
data_peak.push({
lat: 3.4279555556e+01,
lng: 1.3231944444e+02,
cert : true,
content:'Name = Misen(JA/HS-160) peak = 532.400024 pos = 34.2796,132.3194 diff = 532.400024'
});
data_saddle.push({
lat: 3.4231444445e+01,
lng: 1.3227455556e+02,
content:'Saddle = 0.000000 pos = 34.2314,132.2746 diff = 532.400024'
});
data_peak.push({
lat: 3.4252333334e+01,
lng: 1.3228911111e+02,
cert : false,
content:' Peak = 466.100006 pos = 34.2523,132.2891 diff = 228.500000'
});
data_saddle.push({
lat: 3.4258222223e+01,
lng: 1.3229633333e+02,
content:'Saddle = 237.600006 pos = 34.2582,132.2963 diff = 228.500000'
});
data_peak.push({
lat: 3.4271666667e+01,
lng: 1.3231122222e+02,
cert : true,
content:'Name = JA/HS-170(JA/HS-170) peak = 501.399994 pos = 34.2717,132.3112 diff = 170.299988'
});
data_saddle.push({
lat: 3.4276000000e+01,
lng: 1.3231588889e+02,
content:'Saddle = 331.100006 pos = 34.2760,132.3159 diff = 170.299988'
});
data_peak.push({
lat: 3.4216222223e+01,
lng: 1.3241766667e+02,
cert : true,
content:'Name = JA/HS-157(JA/HS-157) peak = 541.500000 pos = 34.2162,132.4177 diff = 541.500000'
});
data_saddle.push({
lat: 3.4128555556e+01,
lng: 1.3242977778e+02,
content:'Saddle = 0.000000 pos = 34.1286,132.4298 diff = 541.500000'
});
data_peak.push({
lat: 3.4259444445e+01,
lng: 1.3247466667e+02,
cert : false,
content:' Peak = 393.600006 pos = 34.2594,132.4747 diff = 388.000000'
});
data_saddle.push({
lat: 3.4201444445e+01,
lng: 1.3247322222e+02,
content:'Saddle = 5.600000 pos = 34.2014,132.4732 diff = 388.000000'
});
data_peak.push({
lat: 3.4251444445e+01,
lng: 1.3244111111e+02,
cert : true,
content:'Name = JA/HS-225(JA/HS-225) peak = 262.000000 pos = 34.2514,132.4411 diff = 245.199997'
});
data_saddle.push({
lat: 3.4261555556e+01,
lng: 1.3244644444e+02,
content:'Saddle = 16.799999 pos = 34.2616,132.4464 diff = 245.199997'
});
data_peak.push({
lat: 3.4209666667e+01,
lng: 1.3248344444e+02,
cert : false,
content:' Peak = 203.600006 pos = 34.2097,132.4834 diff = 156.800003'
});
data_saddle.push({
lat: 3.4248333334e+01,
lng: 1.3248400000e+02,
content:'Saddle = 46.799999 pos = 34.2483,132.4840 diff = 156.800003'
});
data_peak.push({
lat: 3.4151111112e+01,
lng: 1.3246844444e+02,
cert : true,
content:'Name = JA/HS-196(JA/HS-196) peak = 437.299988 pos = 34.1511,132.4684 diff = 421.199982'
});
data_saddle.push({
lat: 3.4211111112e+01,
lng: 1.3244155556e+02,
content:'Saddle = 16.100000 pos = 34.2111,132.4416 diff = 421.199982'
});
data_peak.push({
lat: 3.4207000000e+01,
lng: 1.3245366667e+02,
cert : true,
content:'Name = JA/HS-221(JA/HS-221) peak = 281.100006 pos = 34.2070,132.4537 diff = 254.400009'
});
data_saddle.push({
lat: 3.4178777778e+01,
lng: 1.3246588889e+02,
content:'Saddle = 26.700001 pos = 34.1788,132.4659 diff = 254.400009'
});
data_peak.push({
lat: 3.4241111112e+01,
lng: 1.3240033333e+02,
cert : false,
content:' Peak = 402.100006 pos = 34.2411,132.4003 diff = 168.500000'
});
data_saddle.push({
lat: 3.4230777778e+01,
lng: 1.3240055556e+02,
content:'Saddle = 233.600006 pos = 34.2308,132.4006 diff = 168.500000'
});
data_peak.push({
lat: 3.4367222223e+01,
lng: 1.3249055556e+02,
cert : false,
content:' Peak = 220.399994 pos = 34.3672,132.4906 diff = 216.399994'
});
data_saddle.push({
lat: 3.4371555556e+01,
lng: 1.3250144444e+02,
content:'Saddle = 4.000000 pos = 34.3716,132.5014 diff = 216.399994'
});
data_peak.push({
lat: 3.4265333334e+01,
lng: 1.3274322222e+02,
cert : true,
content:'Name = JA/HS-213(JA/HS-213) peak = 361.600006 pos = 34.2653,132.7432 diff = 304.300018'
});
data_saddle.push({
lat: 3.4245777778e+01,
lng: 1.3271611111e+02,
content:'Saddle = 57.299999 pos = 34.2458,132.7161 diff = 304.300018'
});
data_peak.push({
lat: 3.4422777778e+01,
lng: 1.3248544444e+02,
cert : false,
content:' Peak = 260.399994 pos = 34.4228,132.4854 diff = 202.599991'
});
data_saddle.push({
lat: 3.4423222223e+01,
lng: 1.3249444444e+02,
content:'Saddle = 57.799999 pos = 34.4232,132.4944 diff = 202.599991'
});
data_peak.push({
lat: 3.4215000000e+01,
lng: 1.3264577778e+02,
cert : true,
content:'Name = JA/HS-214(JA/HS-214) peak = 357.299988 pos = 34.2150,132.6458 diff = 295.799988'
});
data_saddle.push({
lat: 3.4223000000e+01,
lng: 1.3264644444e+02,
content:'Saddle = 61.500000 pos = 34.2230,132.6464 diff = 295.799988'
});
data_peak.push({
lat: 3.4010888889e+01,
lng: 1.3219666667e+02,
cert : true,
content:'Name = Zenitsuboyama(JA/YG-082) peak = 540.000000 pos = 34.0109,132.1967 diff = 470.799988'
});
data_saddle.push({
lat: 3.4000111112e+01,
lng: 1.3215422222e+02,
content:'Saddle = 69.199997 pos = 34.0001,132.1542 diff = 470.799988'
});
data_peak.push({
lat: 3.4000444445e+01,
lng: 1.3216466667e+02,
cert : false,
content:' Peak = 271.399994 pos = 34.0004,132.1647 diff = 164.500000'
});
data_saddle.push({
lat: 3.4000111112e+01,
lng: 1.3217566667e+02,
content:'Saddle = 106.900002 pos = 34.0001,132.1757 diff = 164.500000'
});
data_peak.push({
lat: 3.4227333334e+01,
lng: 1.3257622222e+02,
cert : true,
content:'Name = JA/HS-172(JA/HS-172) peak = 495.700012 pos = 34.2273,132.5762 diff = 418.600006'
});
data_saddle.push({
lat: 3.4252555556e+01,
lng: 1.3258955556e+02,
content:'Saddle = 77.099998 pos = 34.2526,132.5896 diff = 418.600006'
});
data_peak.push({
lat: 3.4027333334e+01,
lng: 1.3202222222e+02,
cert : false,
content:' Peak = 382.100006 pos = 34.0273,132.0222 diff = 288.100006'
});
data_saddle.push({
lat: 3.4029111112e+01,
lng: 1.3210700000e+02,
content:'Saddle = 94.000000 pos = 34.0291,132.1070 diff = 288.100006'
});
data_peak.push({
lat: 3.4009222223e+01,
lng: 1.3211988889e+02,
cert : false,
content:' Peak = 323.100006 pos = 34.0092,132.1199 diff = 157.100006'
});
data_saddle.push({
lat: 3.4019000000e+01,
lng: 1.3208433333e+02,
content:'Saddle = 166.000000 pos = 34.0190,132.0843 diff = 157.100006'
});
data_peak.push({
lat: 3.4061444445e+01,
lng: 1.3202700000e+02,
cert : false,
content:' Peak = 364.399994 pos = 34.0614,132.0270 diff = 197.899994'
});
data_saddle.push({
lat: 3.4041777778e+01,
lng: 1.3204266667e+02,
content:'Saddle = 166.500000 pos = 34.0418,132.0427 diff = 197.899994'
});
data_peak.push({
lat: 3.4038333334e+01,
lng: 1.3205888889e+02,
cert : true,
content:'Name = JA/YG-141(JA/YG-141) peak = 360.000000 pos = 34.0383,132.0589 diff = 190.300003'
});
data_saddle.push({
lat: 3.4022444445e+01,
lng: 1.3206322222e+02,
content:'Saddle = 169.699997 pos = 34.0224,132.0632 diff = 190.300003'
});
data_peak.push({
lat: 3.4025444445e+01,
lng: 1.3207533333e+02,
cert : false,
content:' Peak = 329.899994 pos = 34.0254,132.0753 diff = 151.099991'
});
data_saddle.push({
lat: 3.4030333334e+01,
lng: 1.3206588889e+02,
content:'Saddle = 178.800003 pos = 34.0303,132.0659 diff = 151.099991'
});
data_peak.push({
lat: 3.4354444445e+01,
lng: 1.3299600000e+02,
cert : false,
content:' Peak = 348.000000 pos = 34.3544,132.9960 diff = 250.300003'
});
data_saddle.push({
lat: 3.4353222223e+01,
lng: 1.3298066667e+02,
content:'Saddle = 97.699997 pos = 34.3532,132.9807 diff = 250.300003'
});
data_peak.push({
lat: 3.4065444445e+01,
lng: 1.3167688889e+02,
cert : false,
content:' Peak = 260.899994 pos = 34.0654,131.6769 diff = 162.599991'
});
data_saddle.push({
lat: 3.4066666667e+01,
lng: 1.3166366667e+02,
content:'Saddle = 98.300003 pos = 34.0667,131.6637 diff = 162.599991'
});
data_peak.push({
lat: 3.4218888889e+01,
lng: 1.3220733333e+02,
cert : false,
content:' Peak = 250.600006 pos = 34.2189,132.2073 diff = 152.100006'
});
data_saddle.push({
lat: 3.4233222223e+01,
lng: 1.3220222222e+02,
content:'Saddle = 98.500000 pos = 34.2332,132.2022 diff = 152.100006'
});
data_peak.push({
lat: 3.4161333334e+01,
lng: 1.3216655556e+02,
cert : true,
content:'Name = JA/YG-159(JA/YG-159) peak = 300.299988 pos = 34.1613,132.1666 diff = 201.499985'
});
data_saddle.push({
lat: 3.4147444445e+01,
lng: 1.3216755556e+02,
content:'Saddle = 98.800003 pos = 34.1474,132.1676 diff = 201.499985'
});
data_peak.push({
lat: 3.4183555556e+01,
lng: 1.3103055556e+02,
cert : true,
content:'Name = JA/YG-025(JA/YG-025) peak = 712.799988 pos = 34.1836,131.0306 diff = 608.700012'
});
data_saddle.push({
lat: 3.4213666667e+01,
lng: 1.3106411111e+02,
content:'Saddle = 104.099998 pos = 34.2137,131.0641 diff = 608.700012'
});
data_peak.push({
lat: 3.4221777778e+01,
lng: 1.3100188889e+02,
cert : false,
content:' Peak = 380.200012 pos = 34.2218,131.0019 diff = 218.800018'
});
data_saddle.push({
lat: 3.4199222223e+01,
lng: 1.3100011111e+02,
content:'Saddle = 161.399994 pos = 34.1992,131.0001 diff = 218.800018'
});
data_peak.push({
lat: 3.4234222223e+01,
lng: 1.3100300000e+02,
cert : false,
content:' Peak = 362.100006 pos = 34.2342,131.0030 diff = 183.500000'
});
data_saddle.push({
lat: 3.4225777778e+01,
lng: 1.3100022222e+02,
content:'Saddle = 178.600006 pos = 34.2258,131.0002 diff = 183.500000'
});
data_peak.push({
lat: 3.4302555556e+01,
lng: 1.3276466667e+02,
cert : true,
content:'Name = JA/HS-211(JA/HS-211) peak = 384.700012 pos = 34.3026,132.7647 diff = 275.600006'
});
data_saddle.push({
lat: 3.4303666667e+01,
lng: 1.3275088889e+02,
content:'Saddle = 109.099998 pos = 34.3037,132.7509 diff = 275.600006'
});
data_peak.push({
lat: 3.4291555556e+01,
lng: 1.3274344444e+02,
cert : true,
content:'Name = JA/HS-219(JA/HS-219) peak = 301.700012 pos = 34.2916,132.7434 diff = 173.600006'
});
data_saddle.push({
lat: 3.4297222223e+01,
lng: 1.3275333333e+02,
content:'Saddle = 128.100006 pos = 34.2972,132.7533 diff = 173.600006'
});
data_peak.push({
lat: 3.4454111111e+01,
lng: 1.3243366667e+02,
cert : true,
content:'Name = JA/HS-175(JA/HS-175) peak = 487.700012 pos = 34.4541,132.4337 diff = 376.500000'
});
data_saddle.push({
lat: 3.4433111111e+01,
lng: 1.3239866667e+02,
content:'Saddle = 111.199997 pos = 34.4331,132.3987 diff = 376.500000'
});
data_peak.push({
lat: 3.4086111112e+01,
lng: 1.3114466667e+02,
cert : true,
content:'Name = JA/YG-150(JA/YG-150) peak = 322.600006 pos = 34.0861,131.1447 diff = 205.700012'
});
data_saddle.push({
lat: 3.4086777778e+01,
lng: 1.3112288889e+02,
content:'Saddle = 116.900002 pos = 34.0868,131.1229 diff = 205.700012'
});
data_peak.push({
lat: 3.4059444445e+01,
lng: 1.3200066667e+02,
cert : true,
content:'Name = JA/YG-153(JA/YG-153) peak = 317.000000 pos = 34.0594,132.0007 diff = 197.699997'
});
data_saddle.push({
lat: 3.4064444445e+01,
lng: 1.3199744444e+02,
content:'Saddle = 119.300003 pos = 34.0644,131.9974 diff = 197.699997'
});
data_peak.push({
lat: 3.4180666667e+01,
lng: 1.3212888889e+02,
cert : true,
content:'Name = JA/YG-151(JA/YG-151) peak = 322.500000 pos = 34.1807,132.1289 diff = 195.199997'
});
data_saddle.push({
lat: 3.4183666667e+01,
lng: 1.3214322222e+02,
content:'Saddle = 127.300003 pos = 34.1837,132.1432 diff = 195.199997'
});
data_peak.push({
lat: 3.4100222223e+01,
lng: 1.3111011111e+02,
cert : true,
content:'Name = JA/YG-156(JA/YG-156) peak = 313.799988 pos = 34.1002,131.1101 diff = 185.699982'
});
data_saddle.push({
lat: 3.4118555556e+01,
lng: 1.3110288889e+02,
content:'Saddle = 128.100006 pos = 34.1186,131.1029 diff = 185.699982'
});
data_peak.push({
lat: 3.4108333334e+01,
lng: 1.3134355556e+02,
cert : true,
content:'Name = JA/YG-125(JA/YG-125) peak = 393.100006 pos = 34.1083,131.3436 diff = 264.400024'
});
data_saddle.push({
lat: 3.4153222223e+01,
lng: 1.3137000000e+02,
content:'Saddle = 128.699997 pos = 34.1532,131.3700 diff = 264.400024'
});
data_peak.push({
lat: 3.4147111112e+01,
lng: 1.3136844444e+02,
cert : false,
content:' Peak = 320.799988 pos = 34.1471,131.3684 diff = 167.199982'
});
data_saddle.push({
lat: 3.4127000000e+01,
lng: 1.3135855556e+02,
content:'Saddle = 153.600006 pos = 34.1270,131.3586 diff = 167.199982'
});
data_peak.push({
lat: 3.4106000000e+01,
lng: 1.3137166667e+02,
cert : false,
content:' Peak = 391.399994 pos = 34.1060,131.3717 diff = 157.000000'
});
data_saddle.push({
lat: 3.4112555556e+01,
lng: 1.3135900000e+02,
content:'Saddle = 234.399994 pos = 34.1126,131.3590 diff = 157.000000'
});
data_peak.push({
lat: 3.4521222223e+01,
lng: 1.3247888889e+02,
cert : true,
content:'Name = JA/HS-180(JA/HS-180) peak = 470.500000 pos = 34.5212,132.4789 diff = 341.799988'
});
data_saddle.push({
lat: 3.4535333334e+01,
lng: 1.3247500000e+02,
content:'Saddle = 128.699997 pos = 34.5353,132.4750 diff = 341.799988'
});
data_peak.push({
lat: 3.4065222223e+01,
lng: 1.3151211111e+02,
cert : true,
content:'Name = JA/YG-136(JA/YG-136) peak = 368.799988 pos = 34.0652,131.5121 diff = 236.199982'
});
data_saddle.push({
lat: 3.4073000000e+01,
lng: 1.3151577778e+02,
content:'Saddle = 132.600006 pos = 34.0730,131.5158 diff = 236.199982'
});
data_peak.push({
lat: 3.4352444445e+01,
lng: 1.3296866667e+02,
cert : true,
content:'Name = JA/HS-212(JA/HS-212) peak = 381.399994 pos = 34.3524,132.9687 diff = 245.799988'
});
data_saddle.push({
lat: 3.4360444445e+01,
lng: 1.3294544444e+02,
content:'Saddle = 135.600006 pos = 34.3604,132.9454 diff = 245.799988'
});
data_peak.push({
lat: 3.4463000000e+01,
lng: 1.3254711111e+02,
cert : true,
content:'Name = JA/HS-204(JA/HS-204) peak = 412.100006 pos = 34.4630,132.5471 diff = 275.500000'
});
data_saddle.push({
lat: 3.4462111111e+01,
lng: 1.3253933333e+02,
content:'Saddle = 136.600006 pos = 34.4621,132.5393 diff = 275.500000'
});
data_peak.push({
lat: 3.4158666667e+01,
lng: 1.3128277778e+02,
cert : false,
content:' Peak = 458.000000 pos = 34.1587,131.2828 diff = 320.700012'
});
data_saddle.push({
lat: 3.4179222223e+01,
lng: 1.3126900000e+02,
content:'Saddle = 137.300003 pos = 34.1792,131.2690 diff = 320.700012'
});
data_peak.push({
lat: 3.4149666667e+01,
lng: 1.3121644444e+02,
cert : true,
content:'Name = JA/YG-100(JA/YG-100) peak = 454.899994 pos = 34.1497,131.2164 diff = 217.500000'
});
data_saddle.push({
lat: 3.4146888889e+01,
lng: 1.3123288889e+02,
content:'Saddle = 237.399994 pos = 34.1469,131.2329 diff = 217.500000'
});
data_peak.push({
lat: 3.4136777778e+01,
lng: 1.3123744444e+02,
cert : true,
content:'Name = JA/YG-105(JA/YG-105) peak = 440.200012 pos = 34.1368,131.2374 diff = 158.100006'
});
data_saddle.push({
lat: 3.4143444445e+01,
lng: 1.3125000000e+02,
content:'Saddle = 282.100006 pos = 34.1434,131.2500 diff = 158.100006'
});
data_peak.push({
lat: 3.4206444445e+01,
lng: 1.3153377778e+02,
cert : true,
content:'Name = JA/YG-142(JA/YG-142) peak = 358.500000 pos = 34.2064,131.5338 diff = 220.800003'
});
data_saddle.push({
lat: 3.4213666667e+01,
lng: 1.3153322222e+02,
content:'Saddle = 137.699997 pos = 34.2137,131.5332 diff = 220.800003'
});
data_peak.push({
lat: 3.4376444445e+01,
lng: 1.3291044444e+02,
cert : false,
content:' Peak = 402.700012 pos = 34.3764,132.9104 diff = 264.400024'
});
data_saddle.push({
lat: 3.4395111111e+01,
lng: 1.3290977778e+02,
content:'Saddle = 138.300003 pos = 34.3951,132.9098 diff = 264.400024'
});
data_peak.push({
lat: 3.4382888889e+01,
lng: 1.3254200000e+02,
cert : false,
content:' Peak = 344.500000 pos = 34.3829,132.5420 diff = 201.800003'
});
data_saddle.push({
lat: 3.4385444445e+01,
lng: 1.3253688889e+02,
content:'Saddle = 142.699997 pos = 34.3854,132.5369 diff = 201.800003'
});
data_peak.push({
lat: 3.4141777778e+01,
lng: 1.3109188889e+02,
cert : true,
content:'Name = JA/YG-129(JA/YG-129) peak = 391.200012 pos = 34.1418,131.0919 diff = 243.500015'
});
data_saddle.push({
lat: 3.4147777778e+01,
lng: 1.3110688889e+02,
content:'Saddle = 147.699997 pos = 34.1478,131.1069 diff = 243.500015'
});
data_peak.push({
lat: 3.4154000000e+01,
lng: 1.3106622222e+02,
cert : false,
content:' Peak = 381.500000 pos = 34.1540,131.0662 diff = 163.199997'
});
data_saddle.push({
lat: 3.4147666667e+01,
lng: 1.3107655556e+02,
content:'Saddle = 218.300003 pos = 34.1477,131.0766 diff = 163.199997'
});
data_peak.push({
lat: 3.4227000000e+01,
lng: 1.3125111111e+02,
cert : true,
content:'Name = JA/YG-103(JA/YG-103) peak = 445.799988 pos = 34.2270,131.2511 diff = 296.399994'
});
data_saddle.push({
lat: 3.4250000000e+01,
lng: 1.3121644444e+02,
content:'Saddle = 149.399994 pos = 34.2500,131.2164 diff = 296.399994'
});
data_peak.push({
lat: 3.4236222223e+01,
lng: 1.3122700000e+02,
cert : false,
content:' Peak = 409.100006 pos = 34.2362,131.2270 diff = 162.700012'
});
data_saddle.push({
lat: 3.4221333334e+01,
lng: 1.3123566667e+02,
content:'Saddle = 246.399994 pos = 34.2213,131.2357 diff = 162.700012'
});
data_peak.push({
lat: 3.4134777778e+01,
lng: 1.3210522222e+02,
cert : false,
content:' Peak = 315.700012 pos = 34.1348,132.1052 diff = 156.900009'
});
data_saddle.push({
lat: 3.4129777778e+01,
lng: 1.3211211111e+02,
content:'Saddle = 158.800003 pos = 34.1298,132.1121 diff = 156.900009'
});
data_peak.push({
lat: 3.4406444445e+01,
lng: 1.3293300000e+02,
cert : false,
content:' Peak = 326.299988 pos = 34.4064,132.9330 diff = 162.899994'
});
data_saddle.push({
lat: 3.4404111111e+01,
lng: 1.3291833333e+02,
content:'Saddle = 163.399994 pos = 34.4041,132.9183 diff = 162.899994'
});
data_peak.push({
lat: 3.4095444445e+01,
lng: 1.3153322222e+02,
cert : true,
content:'Name = JA/YG-124(JA/YG-124) peak = 392.600006 pos = 34.0954,131.5332 diff = 224.800003'
});
data_saddle.push({
lat: 3.4095444445e+01,
lng: 1.3154300000e+02,
content:'Saddle = 167.800003 pos = 34.0954,131.5430 diff = 224.800003'
});
data_peak.push({
lat: 3.4075555556e+01,
lng: 1.3215377778e+02,
cert : true,
content:'Name = JA/YG-039(JA/YG-039) peak = 644.400024 pos = 34.0756,132.1538 diff = 476.600037'
});
data_saddle.push({
lat: 3.4115555556e+01,
lng: 1.3210366667e+02,
content:'Saddle = 167.800003 pos = 34.1156,132.1037 diff = 476.600037'
});
data_peak.push({
lat: 3.4138333334e+01,
lng: 1.3213133333e+02,
cert : true,
content:'Name = JA/YG-109(JA/YG-109) peak = 431.899994 pos = 34.1383,132.1313 diff = 233.899994'
});
data_saddle.push({
lat: 3.4115333334e+01,
lng: 1.3211844444e+02,
content:'Saddle = 198.000000 pos = 34.1153,132.1184 diff = 233.899994'
});
data_peak.push({
lat: 3.4162111112e+01,
lng: 1.3212511111e+02,
cert : true,
content:'Name = JA/YG-113(JA/YG-113) peak = 426.600006 pos = 34.1621,132.1251 diff = 183.300003'
});
data_saddle.push({
lat: 3.4147888889e+01,
lng: 1.3213200000e+02,
content:'Saddle = 243.300003 pos = 34.1479,132.1320 diff = 183.300003'
});
data_peak.push({
lat: 3.4050777778e+01,
lng: 1.3212333333e+02,
cert : false,
content:' Peak = 561.700012 pos = 34.0508,132.1233 diff = 333.500000'
});
data_saddle.push({
lat: 3.4041111112e+01,
lng: 1.3214411111e+02,
content:'Saddle = 228.199997 pos = 34.0411,132.1441 diff = 333.500000'
});
data_peak.push({
lat: 3.4041777778e+01,
lng: 1.3215544444e+02,
cert : true,
content:'Name = JA/YG-114(JA/YG-114) peak = 426.399994 pos = 34.0418,132.1554 diff = 169.799988'
});
data_saddle.push({
lat: 3.4044444445e+01,
lng: 1.3217444444e+02,
content:'Saddle = 256.600006 pos = 34.0444,132.1744 diff = 169.799988'
});
data_peak.push({
lat: 3.4105555556e+01,
lng: 1.3212911111e+02,
cert : true,
content:'Name = JA/YG-087(JA/YG-087) peak = 523.900024 pos = 34.1056,132.1291 diff = 175.900024'
});
data_saddle.push({
lat: 3.4093000000e+01,
lng: 1.3213488889e+02,
content:'Saddle = 348.000000 pos = 34.0930,132.1349 diff = 175.900024'
});
data_peak.push({
lat: 3.4447111111e+01,
lng: 1.3252044444e+02,
cert : true,
content:'Name = JA/HS-179(JA/HS-179) peak = 482.200012 pos = 34.4471,132.5204 diff = 313.800018'
});
data_saddle.push({
lat: 3.4439555556e+01,
lng: 1.3253088889e+02,
content:'Saddle = 168.399994 pos = 34.4396,132.5309 diff = 313.800018'
});
data_peak.push({
lat: 3.4433222223e+01,
lng: 1.3250544444e+02,
cert : false,
content:' Peak = 373.399994 pos = 34.4332,132.5054 diff = 151.399994'
});
data_saddle.push({
lat: 3.4434222223e+01,
lng: 1.3251100000e+02,
content:'Saddle = 222.000000 pos = 34.4342,132.5110 diff = 151.399994'
});
data_peak.push({
lat: 3.4197000000e+01,
lng: 1.3211100000e+02,
cert : false,
content:' Peak = 521.400024 pos = 34.1970,132.1110 diff = 350.000031'
});
data_saddle.push({
lat: 3.4225333334e+01,
lng: 1.3210500000e+02,
content:'Saddle = 171.399994 pos = 34.2253,132.1050 diff = 350.000031'
});
data_peak.push({
lat: 3.4525666667e+01,
lng: 1.3252122222e+02,
cert : false,
content:' Peak = 338.000000 pos = 34.5257,132.5212 diff = 164.899994'
});
data_saddle.push({
lat: 3.4525888889e+01,
lng: 1.3252622222e+02,
content:'Saddle = 173.100006 pos = 34.5259,132.5262 diff = 164.899994'
});
data_peak.push({
lat: 3.4083222223e+01,
lng: 1.3174533333e+02,
cert : false,
content:' Peak = 363.000000 pos = 34.0832,131.7453 diff = 185.000000'
});
data_saddle.push({
lat: 3.4090777778e+01,
lng: 1.3174244444e+02,
content:'Saddle = 178.000000 pos = 34.0908,131.7424 diff = 185.000000'
});
data_peak.push({
lat: 3.4353888889e+01,
lng: 1.3288811111e+02,
cert : true,
content:'Name = JA/HS-188(JA/HS-188) peak = 453.600006 pos = 34.3539,132.8881 diff = 261.000000'
});
data_saddle.push({
lat: 3.4360555556e+01,
lng: 1.3287877778e+02,
content:'Saddle = 192.600006 pos = 34.3606,132.8788 diff = 261.000000'
});
data_peak.push({
lat: 3.4086666667e+01,
lng: 1.3159600000e+02,
cert : true,
content:'Name = JA/YG-098(JA/YG-098) peak = 460.799988 pos = 34.0867,131.5960 diff = 263.899994'
});
data_saddle.push({
lat: 3.4085888889e+01,
lng: 1.3160577778e+02,
content:'Saddle = 196.899994 pos = 34.0859,131.6058 diff = 263.899994'
});
data_peak.push({
lat: 3.4150111112e+01,
lng: 1.3112866667e+02,
cert : false,
content:' Peak = 381.399994 pos = 34.1501,131.1287 diff = 184.299988'
});
data_saddle.push({
lat: 3.4182111112e+01,
lng: 1.3115011111e+02,
content:'Saddle = 197.100006 pos = 34.1821,131.1501 diff = 184.299988'
});
data_peak.push({
lat: 3.4530666667e+01,
lng: 1.3245544444e+02,
cert : true,
content:'Name = JA/HS-163(JA/HS-163) peak = 524.099976 pos = 34.5307,132.4554 diff = 326.999969'
});
data_saddle.push({
lat: 3.4543000000e+01,
lng: 1.3245711111e+02,
content:'Saddle = 197.100006 pos = 34.5430,132.4571 diff = 326.999969'
});
data_peak.push({
lat: 3.4541888889e+01,
lng: 1.3243966667e+02,
cert : true,
content:'Name = JA/HS-199(JA/HS-199) peak = 432.200012 pos = 34.5419,132.4397 diff = 203.800018'
});
data_saddle.push({
lat: 3.4539333334e+01,
lng: 1.3244777778e+02,
content:'Saddle = 228.399994 pos = 34.5393,132.4478 diff = 203.800018'
});
data_peak.push({
lat: 3.4515444445e+01,
lng: 1.3241222222e+02,
cert : true,
content:'Name = JA/HS-200(JA/HS-200) peak = 425.100006 pos = 34.5154,132.4122 diff = 227.100006'
});
data_saddle.push({
lat: 3.4510888889e+01,
lng: 1.3241633333e+02,
content:'Saddle = 198.000000 pos = 34.5109,132.4163 diff = 227.100006'
});
data_peak.push({
lat: 3.4262444445e+01,
lng: 1.3266622222e+02,
cert : true,
content:'Name = Norosan (Zendanayama)(JA/HS-060) peak = 838.799988 pos = 34.2624,132.6662 diff = 632.299988'
});
data_saddle.push({
lat: 3.4307666667e+01,
lng: 1.3269711111e+02,
content:'Saddle = 206.500000 pos = 34.3077,132.6971 diff = 632.299988'
});
data_peak.push({
lat: 3.4266111112e+01,
lng: 1.3136377778e+02,
cert : true,
content:'Name = JA/YG-102(JA/YG-102) peak = 442.600006 pos = 34.2661,131.3638 diff = 232.800003'
});
data_saddle.push({
lat: 3.4282000000e+01,
lng: 1.3136277778e+02,
content:'Saddle = 209.800003 pos = 34.2820,131.3628 diff = 232.800003'
});
data_peak.push({
lat: 3.5081222222e+01,
lng: 1.3296833333e+02,
cert : true,
content:'Name = Sarumasayama(JA/HS-006) peak = 1264.400024 pos = 35.0812,132.9683 diff = 1050.200073'
});
data_saddle.push({
lat: 3.4622000000e+01,
lng: 1.3272155556e+02,
content:'Saddle = 214.199997 pos = 34.6220,132.7216 diff = 1050.200073'
});
data_peak.push({
lat: 3.5059555556e+01,
lng: 1.3254400000e+02,
cert : true,
content:'Name = JA/SN-110(JA/SN-110) peak = 436.899994 pos = 35.0596,132.5440 diff = 220.199997'
});
data_saddle.push({
lat: 3.5067777778e+01,
lng: 1.3252055556e+02,
content:'Saddle = 216.699997 pos = 35.0678,132.5206 diff = 220.199997'
});
data_peak.push({
lat: 3.5053111111e+01,
lng: 1.3253644444e+02,
cert : false,
content:' Peak = 420.700012 pos = 35.0531,132.5364 diff = 172.800018'
});
data_saddle.push({
lat: 3.5057000000e+01,
lng: 1.3253911111e+02,
content:'Saddle = 247.899994 pos = 35.0570,132.5391 diff = 172.800018'
});
data_peak.push({
lat: 3.5063777778e+01,
lng: 1.3257288889e+02,
cert : false,
content:' Peak = 420.299988 pos = 35.0638,132.5729 diff = 166.999985'
});
data_saddle.push({
lat: 3.5064555556e+01,
lng: 1.3256588889e+02,
content:'Saddle = 253.300003 pos = 35.0646,132.5659 diff = 166.999985'
});
data_peak.push({
lat: 3.4279888889e+01,
lng: 1.3253055556e+02,
cert : false,
content:' Peak = 410.000000 pos = 34.2799,132.5306 diff = 192.899994'
});
data_saddle.push({
lat: 3.4293555556e+01,
lng: 1.3254366667e+02,
content:'Saddle = 217.100006 pos = 34.2936,132.5437 diff = 192.899994'
});
data_peak.push({
lat: 3.4265555556e+01,
lng: 1.3254688889e+02,
cert : false,
content:' Peak = 403.500000 pos = 34.2656,132.5469 diff = 186.000000'
});
data_saddle.push({
lat: 3.4273111112e+01,
lng: 1.3255044444e+02,
content:'Saddle = 217.500000 pos = 34.2731,132.5504 diff = 186.000000'
});
data_peak.push({
lat: 3.4373666667e+01,
lng: 1.3278600000e+02,
cert : true,
content:'Name = JA/HS-156(JA/HS-156) peak = 543.799988 pos = 34.3737,132.7860 diff = 326.699982'
});
data_saddle.push({
lat: 3.4438777778e+01,
lng: 1.3276233333e+02,
content:'Saddle = 217.100006 pos = 34.4388,132.7623 diff = 326.699982'
});
data_peak.push({
lat: 3.4312222223e+01,
lng: 1.3271000000e+02,
cert : false,
content:' Peak = 431.000000 pos = 34.3122,132.7100 diff = 212.399994'
});
data_saddle.push({
lat: 3.4316111111e+01,
lng: 1.3271611111e+02,
content:'Saddle = 218.600006 pos = 34.3161,132.7161 diff = 212.399994'
});
data_peak.push({
lat: 3.4460000000e+01,
lng: 1.3287433333e+02,
cert : true,
content:'Name = JA/HS-166(JA/HS-166) peak = 521.900024 pos = 34.4600,132.8743 diff = 276.100037'
});
data_saddle.push({
lat: 3.4420888889e+01,
lng: 1.3284877778e+02,
content:'Saddle = 245.800003 pos = 34.4209,132.8488 diff = 276.100037'
});
data_peak.push({
lat: 3.4427333334e+01,
lng: 1.3278455556e+02,
cert : false,
content:' Peak = 523.099976 pos = 34.4273,132.7846 diff = 255.099976'
});
data_saddle.push({
lat: 3.4400222223e+01,
lng: 1.3280155556e+02,
content:'Saddle = 268.000000 pos = 34.4002,132.8016 diff = 255.099976'
});
data_peak.push({
lat: 3.4351333334e+01,
lng: 1.3287066667e+02,
cert : false,
content:' Peak = 480.399994 pos = 34.3513,132.8707 diff = 166.899994'
});
data_saddle.push({
lat: 3.4351333334e+01,
lng: 1.3285700000e+02,
content:'Saddle = 313.500000 pos = 34.3513,132.8570 diff = 166.899994'
});
data_peak.push({
lat: 3.4326333334e+01,
lng: 1.3273766667e+02,
cert : false,
content:' Peak = 510.000000 pos = 34.3263,132.7377 diff = 153.200012'
});
data_saddle.push({
lat: 3.4338888889e+01,
lng: 1.3274288889e+02,
content:'Saddle = 356.799988 pos = 34.3389,132.7429 diff = 153.200012'
});
data_peak.push({
lat: 3.4344666667e+01,
lng: 1.3276166667e+02,
cert : false,
content:' Peak = 542.799988 pos = 34.3447,132.7617 diff = 155.599976'
});
data_saddle.push({
lat: 3.4350444445e+01,
lng: 1.3276600000e+02,
content:'Saddle = 387.200012 pos = 34.3504,132.7660 diff = 155.599976'
});
data_peak.push({
lat: 3.5282222222e+01,
lng: 1.3299744444e+02,
cert : false,
content:' Peak = 564.799988 pos = 35.2822,132.9974 diff = 341.799988'
});
data_saddle.push({
lat: 3.5204000000e+01,
lng: 1.3299988889e+02,
content:'Saddle = 223.000000 pos = 35.2040,132.9999 diff = 341.799988'
});
data_peak.push({
lat: 3.5249000000e+01,
lng: 1.3299955556e+02,
cert : false,
content:' Peak = 552.500000 pos = 35.2490,132.9996 diff = 327.299988'
});
data_saddle.push({
lat: 3.5266555556e+01,
lng: 1.3299977778e+02,
content:'Saddle = 225.199997 pos = 35.2666,132.9998 diff = 327.299988'
});
data_peak.push({
lat: 3.4566000000e+01,
lng: 1.3274600000e+02,
cert : true,
content:'Name = Takanosuzan(JA/HS-045) peak = 921.299988 pos = 34.5660,132.7460 diff = 698.199951'
});
data_saddle.push({
lat: 3.4876333333e+01,
lng: 1.3299988889e+02,
content:'Saddle = 223.100006 pos = 34.8763,132.9999 diff = 698.199951'
});
data_peak.push({
lat: 3.4824222222e+01,
lng: 1.3289733333e+02,
cert : true,
content:'Name = JA/HS-182(JA/HS-182) peak = 460.899994 pos = 34.8242,132.8973 diff = 235.000000'
});
data_saddle.push({
lat: 3.4715333334e+01,
lng: 1.3299988889e+02,
content:'Saddle = 225.899994 pos = 34.7153,132.9999 diff = 235.000000'
});
data_peak.push({
lat: 3.4735000000e+01,
lng: 1.3299655556e+02,
cert : false,
content:' Peak = 391.899994 pos = 34.7350,132.9966 diff = 160.099991'
});
data_saddle.push({
lat: 3.4810777778e+01,
lng: 1.3299877778e+02,
content:'Saddle = 231.800003 pos = 34.8108,132.9988 diff = 160.099991'
});
data_peak.push({
lat: 3.4805666667e+01,
lng: 1.3296455556e+02,
cert : false,
content:' Peak = 404.200012 pos = 34.8057,132.9646 diff = 158.900009'
});
data_saddle.push({
lat: 3.4852111111e+01,
lng: 1.3299988889e+02,
content:'Saddle = 245.300003 pos = 34.8521,132.9999 diff = 158.900009'
});
data_peak.push({
lat: 3.4866333333e+01,
lng: 1.3294033333e+02,
cert : false,
content:' Peak = 444.100006 pos = 34.8663,132.9403 diff = 167.500000'
});
data_saddle.push({
lat: 3.4833555556e+01,
lng: 1.3292511111e+02,
content:'Saddle = 276.600006 pos = 34.8336,132.9251 diff = 167.500000'
});
data_peak.push({
lat: 3.4311222223e+01,
lng: 1.3263622222e+02,
cert : true,
content:'Name = JA/HS-203(JA/HS-203) peak = 422.100006 pos = 34.3112,132.6362 diff = 194.100006'
});
data_saddle.push({
lat: 3.4318000000e+01,
lng: 1.3262800000e+02,
content:'Saddle = 228.000000 pos = 34.3180,132.6280 diff = 194.100006'
});
data_peak.push({
lat: 3.4391555556e+01,
lng: 1.3259844444e+02,
cert : true,
content:'Name = JA/HS-102(JA/HS-102) peak = 711.299988 pos = 34.3916,132.5984 diff = 483.199982'
});
data_saddle.push({
lat: 3.4344111111e+01,
lng: 1.3258822222e+02,
content:'Saddle = 228.100006 pos = 34.3441,132.5882 diff = 483.199982'
});
data_peak.push({
lat: 3.4319111111e+01,
lng: 1.3253966667e+02,
cert : true,
content:'Name = JA/HS-141(JA/HS-141) peak = 592.200012 pos = 34.3191,132.5397 diff = 323.700012'
});
data_saddle.push({
lat: 3.4328777778e+01,
lng: 1.3255366667e+02,
content:'Saddle = 268.500000 pos = 34.3288,132.5537 diff = 323.700012'
});
data_peak.push({
lat: 3.4324777778e+01,
lng: 1.3255588889e+02,
cert : false,
content:' Peak = 431.899994 pos = 34.3248,132.5559 diff = 153.500000'
});
data_saddle.push({
lat: 3.4321444445e+01,
lng: 1.3255066667e+02,
content:'Saddle = 278.399994 pos = 34.3214,132.5507 diff = 153.500000'
});
data_peak.push({
lat: 3.4270111112e+01,
lng: 1.3259333333e+02,
cert : true,
content:'Name = JA/HS-091(JA/HS-091) peak = 735.700012 pos = 34.2701,132.5933 diff = 476.800018'
});
data_saddle.push({
lat: 3.4444666667e+01,
lng: 1.3268588889e+02,
content:'Saddle = 258.899994 pos = 34.4447,132.6859 diff = 476.800018'
});
data_peak.push({
lat: 3.4315888889e+01,
lng: 1.3258066667e+02,
cert : false,
content:' Peak = 451.000000 pos = 34.3159,132.5807 diff = 162.600006'
});
data_saddle.push({
lat: 3.4290444445e+01,
lng: 1.3258655556e+02,
content:'Saddle = 288.399994 pos = 34.2904,132.5866 diff = 162.600006'
});
data_peak.push({
lat: 3.4351888889e+01,
lng: 1.3264122222e+02,
cert : true,
content:'Name = JA/HS-098(JA/HS-098) peak = 718.599976 pos = 34.3519,132.6412 diff = 421.199982'
});
data_saddle.push({
lat: 3.4297000000e+01,
lng: 1.3259677778e+02,
content:'Saddle = 297.399994 pos = 34.2970,132.5968 diff = 421.199982'
});
data_peak.push({
lat: 3.4310111111e+01,
lng: 1.3259088889e+02,
cert : false,
content:' Peak = 472.799988 pos = 34.3101,132.5909 diff = 154.399994'
});
data_saddle.push({
lat: 3.4306444445e+01,
lng: 1.3259888889e+02,
content:'Saddle = 318.399994 pos = 34.3064,132.5989 diff = 154.399994'
});
data_peak.push({
lat: 3.4413777778e+01,
lng: 1.3264666667e+02,
cert : true,
content:'Name = JA/HS-119(JA/HS-119) peak = 660.099976 pos = 34.4138,132.6467 diff = 332.299988'
});
data_saddle.push({
lat: 3.4387888889e+01,
lng: 1.3264544444e+02,
content:'Saddle = 327.799988 pos = 34.3879,132.6454 diff = 332.299988'
});
data_peak.push({
lat: 3.4398777778e+01,
lng: 1.3265533333e+02,
cert : false,
content:' Peak = 487.100006 pos = 34.3988,132.6553 diff = 155.500000'
});
data_saddle.push({
lat: 3.4397444445e+01,
lng: 1.3264333333e+02,
content:'Saddle = 331.600006 pos = 34.3974,132.6433 diff = 155.500000'
});
data_peak.push({
lat: 3.4328444445e+01,
lng: 1.3261333333e+02,
cert : false,
content:' Peak = 562.500000 pos = 34.3284,132.6133 diff = 205.000000'
});
data_saddle.push({
lat: 3.4347777778e+01,
lng: 1.3261544444e+02,
content:'Saddle = 357.500000 pos = 34.3478,132.6154 diff = 205.000000'
});
data_peak.push({
lat: 3.4491000000e+01,
lng: 1.3261211111e+02,
cert : true,
content:'Name = JA/HS-083(JA/HS-083) peak = 760.900024 pos = 34.4910,132.6121 diff = 500.300018'
});
data_saddle.push({
lat: 3.4459555556e+01,
lng: 1.3265100000e+02,
content:'Saddle = 260.600006 pos = 34.4596,132.6510 diff = 500.300018'
});
data_peak.push({
lat: 3.4448333334e+01,
lng: 1.3261244444e+02,
cert : true,
content:'Name = JA/HS-167(JA/HS-167) peak = 512.700012 pos = 34.4483,132.6124 diff = 203.600006'
});
data_saddle.push({
lat: 3.4454222223e+01,
lng: 1.3261066667e+02,
content:'Saddle = 309.100006 pos = 34.4542,132.6107 diff = 203.600006'
});
data_peak.push({
lat: 3.4422888889e+01,
lng: 1.3254777778e+02,
cert : true,
content:'Name = Gosasouzan(JA/HS-114) peak = 680.200012 pos = 34.4229,132.5478 diff = 302.100006'
});
data_saddle.push({
lat: 3.4477666667e+01,
lng: 1.3260577778e+02,
content:'Saddle = 378.100006 pos = 34.4777,132.6058 diff = 302.100006'
});
data_peak.push({
lat: 3.4456000000e+01,
lng: 1.3259844444e+02,
cert : true,
content:'Name = JA/HS-135(JA/HS-135) peak = 612.400024 pos = 34.4560,132.5984 diff = 190.600037'
});
data_saddle.push({
lat: 3.4443111111e+01,
lng: 1.3257800000e+02,
content:'Saddle = 421.799988 pos = 34.4431,132.5780 diff = 190.600037'
});
data_peak.push({
lat: 3.4507111111e+01,
lng: 1.3263355556e+02,
cert : false,
content:' Peak = 734.000000 pos = 34.5071,132.6336 diff = 171.599976'
});
data_saddle.push({
lat: 3.4502000000e+01,
lng: 1.3263011111e+02,
content:'Saddle = 562.400024 pos = 34.5020,132.6301 diff = 171.599976'
});
data_peak.push({
lat: 3.4693777778e+01,
lng: 1.3299988889e+02,
cert : false,
content:' Peak = 490.600006 pos = 34.6938,132.9999 diff = 226.000000'
});
data_saddle.push({
lat: 3.4684000000e+01,
lng: 1.3299988889e+02,
content:'Saddle = 264.600006 pos = 34.6840,132.9999 diff = 226.000000'
});
data_peak.push({
lat: 3.4488888889e+01,
lng: 1.3266400000e+02,
cert : true,
content:'Name = JA/HS-178(JA/HS-178) peak = 483.100006 pos = 34.4889,132.6640 diff = 214.800018'
});
data_saddle.push({
lat: 3.4466000000e+01,
lng: 1.3266900000e+02,
content:'Saddle = 268.299988 pos = 34.4660,132.6690 diff = 214.800018'
});
data_peak.push({
lat: 3.4681000000e+01,
lng: 1.3299988889e+02,
cert : false,
content:' Peak = 481.100006 pos = 34.6810,132.9999 diff = 192.399994'
});
data_saddle.push({
lat: 3.4675666667e+01,
lng: 1.3299988889e+02,
content:'Saddle = 288.700012 pos = 34.6757,132.9999 diff = 192.399994'
});
data_peak.push({
lat: 3.4719888889e+01,
lng: 1.3286944444e+02,
cert : false,
content:' Peak = 522.400024 pos = 34.7199,132.8694 diff = 214.100037'
});
data_saddle.push({
lat: 3.4691777778e+01,
lng: 1.3284733333e+02,
content:'Saddle = 308.299988 pos = 34.6918,132.8473 diff = 214.100037'
});
data_peak.push({
lat: 3.4487333334e+01,
lng: 1.3288444444e+02,
cert : true,
content:'Name = JA/HS-147(JA/HS-147) peak = 572.900024 pos = 34.4873,132.8844 diff = 253.900024'
});
data_saddle.push({
lat: 3.4502000000e+01,
lng: 1.3285366667e+02,
content:'Saddle = 319.000000 pos = 34.5020,132.8537 diff = 253.900024'
});
data_peak.push({
lat: 3.4670333334e+01,
lng: 1.3299422222e+02,
cert : false,
content:' Peak = 493.100006 pos = 34.6703,132.9942 diff = 166.500000'
});
data_saddle.push({
lat: 3.4654666667e+01,
lng: 1.3299988889e+02,
content:'Saddle = 326.600006 pos = 34.6547,132.9999 diff = 166.500000'
});
data_peak.push({
lat: 3.4574888889e+01,
lng: 1.3268855556e+02,
cert : true,
content:'Name = JA/HS-150(JA/HS-150) peak = 561.200012 pos = 34.5749,132.6886 diff = 232.800018'
});
data_saddle.push({
lat: 3.4565888889e+01,
lng: 1.3269022222e+02,
content:'Saddle = 328.399994 pos = 34.5659,132.6902 diff = 232.800018'
});
data_peak.push({
lat: 3.4493888889e+01,
lng: 1.3292255556e+02,
cert : true,
content:'Name = JA/HS-162(JA/HS-162) peak = 524.900024 pos = 34.4939,132.9226 diff = 191.600037'
});
data_saddle.push({
lat: 3.4484111111e+01,
lng: 1.3297544444e+02,
content:'Saddle = 333.299988 pos = 34.4841,132.9754 diff = 191.600037'
});
data_peak.push({
lat: 3.4457222223e+01,
lng: 1.3274177778e+02,
cert : true,
content:'Name = JA/HS-146(JA/HS-146) peak = 572.099976 pos = 34.4572,132.7418 diff = 222.399963'
});
data_saddle.push({
lat: 3.4479888889e+01,
lng: 1.3273977778e+02,
content:'Saddle = 349.700012 pos = 34.4799,132.7398 diff = 222.399963'
});
data_peak.push({
lat: 3.4474111111e+01,
lng: 1.3277266667e+02,
cert : true,
content:'Name = JA/HS-161(JA/HS-161) peak = 530.000000 pos = 34.4741,132.7727 diff = 175.000000'
});
data_saddle.push({
lat: 3.4473555556e+01,
lng: 1.3276455556e+02,
content:'Saddle = 355.000000 pos = 34.4736,132.7646 diff = 175.000000'
});
data_peak.push({
lat: 3.4480333334e+01,
lng: 1.3284500000e+02,
cert : false,
content:' Peak = 517.799988 pos = 34.4803,132.8450 diff = 150.299988'
});
data_saddle.push({
lat: 3.4484666667e+01,
lng: 1.3281188889e+02,
content:'Saddle = 367.500000 pos = 34.4847,132.8119 diff = 150.299988'
});
data_peak.push({
lat: 3.4699666667e+01,
lng: 1.3293211111e+02,
cert : true,
content:'Name = JA/HS-125(JA/HS-125) peak = 640.599976 pos = 34.6997,132.9321 diff = 281.499969'
});
data_saddle.push({
lat: 3.4662222222e+01,
lng: 1.3290233333e+02,
content:'Saddle = 359.100006 pos = 34.6622,132.9023 diff = 281.499969'
});
data_peak.push({
lat: 3.4674000000e+01,
lng: 1.3291366667e+02,
cert : false,
content:' Peak = 591.400024 pos = 34.6740,132.9137 diff = 170.700012'
});
data_saddle.push({
lat: 3.4677333334e+01,
lng: 1.3290622222e+02,
content:'Saddle = 420.700012 pos = 34.6773,132.9062 diff = 170.700012'
});
data_peak.push({
lat: 3.4695666667e+01,
lng: 1.3288377778e+02,
cert : true,
content:'Name = JA/HS-143(JA/HS-143) peak = 581.799988 pos = 34.6957,132.8838 diff = 151.000000'
});
data_saddle.push({
lat: 3.4686444445e+01,
lng: 1.3291811111e+02,
content:'Saddle = 430.799988 pos = 34.6864,132.9181 diff = 151.000000'
});
data_peak.push({
lat: 3.4552666667e+01,
lng: 1.3299266667e+02,
cert : true,
content:'Name = JA/HS-148(JA/HS-148) peak = 570.900024 pos = 34.5527,132.9927 diff = 193.000031'
});
data_saddle.push({
lat: 3.4568666667e+01,
lng: 1.3296733333e+02,
content:'Saddle = 377.899994 pos = 34.5687,132.9673 diff = 193.000031'
});
data_peak.push({
lat: 3.4548666667e+01,
lng: 1.3282566667e+02,
cert : true,
content:'Name = JA/HS-084(JA/HS-084) peak = 755.500000 pos = 34.5487,132.8257 diff = 370.399994'
});
data_saddle.push({
lat: 3.4557555556e+01,
lng: 1.3279588889e+02,
content:'Saddle = 385.100006 pos = 34.5576,132.7959 diff = 370.399994'
});
data_peak.push({
lat: 3.4517000000e+01,
lng: 1.3287066667e+02,
cert : false,
content:' Peak = 619.599976 pos = 34.5170,132.8707 diff = 201.999969'
});
data_saddle.push({
lat: 3.4536666667e+01,
lng: 1.3282088889e+02,
content:'Saddle = 417.600006 pos = 34.5367,132.8209 diff = 201.999969'
});
data_peak.push({
lat: 3.4647777778e+01,
lng: 1.3292622222e+02,
cert : false,
content:' Peak = 560.200012 pos = 34.6478,132.9262 diff = 154.500000'
});
data_saddle.push({
lat: 3.4591111111e+01,
lng: 1.3295933333e+02,
content:'Saddle = 405.700012 pos = 34.5911,132.9593 diff = 154.500000'
});
data_peak.push({
lat: 3.4639000000e+01,
lng: 1.3278066667e+02,
cert : true,
content:'Name = JA/HS-072(JA/HS-072) peak = 800.000000 pos = 34.6390,132.7807 diff = 391.600006'
});
data_saddle.push({
lat: 3.4581888889e+01,
lng: 1.3279388889e+02,
content:'Saddle = 408.399994 pos = 34.5819,132.7939 diff = 391.600006'
});
data_peak.push({
lat: 3.4585333334e+01,
lng: 1.3285777778e+02,
cert : true,
content:'Name = JA/HS-085(JA/HS-085) peak = 757.299988 pos = 34.5853,132.8578 diff = 334.000000'
});
data_saddle.push({
lat: 3.4602000000e+01,
lng: 1.3282122222e+02,
content:'Saddle = 423.299988 pos = 34.6020,132.8212 diff = 334.000000'
});
data_peak.push({
lat: 3.4579333334e+01,
lng: 1.3287777778e+02,
cert : true,
content:'Name = JA/HS-115(JA/HS-115) peak = 664.700012 pos = 34.5793,132.8778 diff = 156.700012'
});
data_saddle.push({
lat: 3.4576222222e+01,
lng: 1.3287355556e+02,
content:'Saddle = 508.000000 pos = 34.5762,132.8736 diff = 156.700012'
});
data_peak.push({
lat: 3.4474000000e+01,
lng: 1.3271066667e+02,
cert : true,
content:'Name = JA/HS-130(JA/HS-130) peak = 631.500000 pos = 34.4740,132.7107 diff = 214.100006'
});
data_saddle.push({
lat: 3.4482111111e+01,
lng: 1.3270433333e+02,
content:'Saddle = 417.399994 pos = 34.4821,132.7043 diff = 214.100006'
});
data_peak.push({
lat: 3.4508888889e+01,
lng: 1.3271844444e+02,
cert : true,
content:'Name = JA/HS-094(JA/HS-094) peak = 730.900024 pos = 34.5089,132.7184 diff = 263.400024'
});
data_saddle.push({
lat: 3.4512666667e+01,
lng: 1.3270488889e+02,
content:'Saddle = 467.500000 pos = 34.5127,132.7049 diff = 263.400024'
});
data_peak.push({
lat: 3.4523555556e+01,
lng: 1.3268522222e+02,
cert : true,
content:'Name = JA/HS-090(JA/HS-090) peak = 740.500000 pos = 34.5236,132.6852 diff = 195.299988'
});
data_saddle.push({
lat: 3.4553666667e+01,
lng: 1.3271311111e+02,
content:'Saddle = 545.200012 pos = 34.5537,132.7131 diff = 195.299988'
});
data_peak.push({
lat: 3.4566666667e+01,
lng: 1.3278444444e+02,
cert : true,
content:'Name = JA/HS-092(JA/HS-092) peak = 733.099976 pos = 34.5667,132.7844 diff = 170.899963'
});
data_saddle.push({
lat: 3.4560888889e+01,
lng: 1.3277644444e+02,
content:'Saddle = 562.200012 pos = 34.5609,132.7764 diff = 170.899963'
});
data_peak.push({
lat: 3.4574444445e+01,
lng: 1.3275833333e+02,
cert : false,
content:' Peak = 891.299988 pos = 34.5744,132.7583 diff = 164.899963'
});
data_saddle.push({
lat: 3.4572000000e+01,
lng: 1.3274988889e+02,
content:'Saddle = 726.400024 pos = 34.5720,132.7499 diff = 164.899963'
});
data_peak.push({
lat: 3.4975777778e+01,
lng: 1.3245211111e+02,
cert : true,
content:'Name = JA/SN-118(JA/SN-118) peak = 402.700012 pos = 34.9758,132.4521 diff = 179.400009'
});
data_saddle.push({
lat: 3.4979777778e+01,
lng: 1.3241844444e+02,
content:'Saddle = 223.300003 pos = 34.9798,132.4184 diff = 179.400009'
});
data_peak.push({
lat: 3.5063888889e+01,
lng: 1.3242855556e+02,
cert : true,
content:'Name = Ooetakayama(JA/SN-030) peak = 802.500000 pos = 35.0639,132.4286 diff = 576.200012'
});
data_saddle.push({
lat: 3.5103555556e+01,
lng: 1.3252422222e+02,
content:'Saddle = 226.300003 pos = 35.1036,132.5242 diff = 576.200012'
});
data_peak.push({
lat: 3.4988333333e+01,
lng: 1.3237433333e+02,
cert : false,
content:' Peak = 441.600006 pos = 34.9883,132.3743 diff = 172.200012'
});
data_saddle.push({
lat: 3.4994777778e+01,
lng: 1.3237477778e+02,
content:'Saddle = 269.399994 pos = 34.9948,132.3748 diff = 172.200012'
});
data_peak.push({
lat: 3.5033333333e+01,
lng: 1.3236977778e+02,
cert : false,
content:' Peak = 444.000000 pos = 35.0333,132.3698 diff = 167.600006'
});
data_saddle.push({
lat: 3.5035000000e+01,
lng: 1.3238133333e+02,
content:'Saddle = 276.399994 pos = 35.0350,132.3813 diff = 167.600006'
});
data_peak.push({
lat: 3.4964555556e+01,
lng: 1.3241644444e+02,
cert : true,
content:'Name = JA/SN-089(JA/SN-089) peak = 521.900024 pos = 34.9646,132.4164 diff = 245.000031'
});
data_saddle.push({
lat: 3.4997555556e+01,
lng: 1.3239988889e+02,
content:'Saddle = 276.899994 pos = 34.9976,132.3999 diff = 245.000031'
});
data_peak.push({
lat: 3.4980666667e+01,
lng: 1.3240644444e+02,
cert : true,
content:'Name = JA/SN-098(JA/SN-098) peak = 480.000000 pos = 34.9807,132.4064 diff = 189.700012'
});
data_saddle.push({
lat: 3.4981666667e+01,
lng: 1.3240122222e+02,
content:'Saddle = 290.299988 pos = 34.9817,132.4012 diff = 189.700012'
});
data_peak.push({
lat: 3.4977333333e+01,
lng: 1.3238722222e+02,
cert : false,
content:' Peak = 492.100006 pos = 34.9773,132.3872 diff = 178.800018'
});
data_saddle.push({
lat: 3.4971444445e+01,
lng: 1.3239277778e+02,
content:'Saddle = 313.299988 pos = 34.9714,132.3928 diff = 178.800018'
});
data_peak.push({
lat: 3.5007666667e+01,
lng: 1.3236844444e+02,
cert : true,
content:'Name = JA/SN-068(JA/SN-068) peak = 592.099976 pos = 35.0077,132.3684 diff = 313.699982'
});
data_saddle.push({
lat: 3.5032000000e+01,
lng: 1.3240244444e+02,
content:'Saddle = 278.399994 pos = 35.0320,132.4024 diff = 313.699982'
});
data_peak.push({
lat: 3.4992777778e+01,
lng: 1.3233511111e+02,
cert : true,
content:'Name = JA/SN-087(JA/SN-087) peak = 525.700012 pos = 34.9928,132.3351 diff = 198.000000'
});
data_saddle.push({
lat: 3.5000222222e+01,
lng: 1.3234888889e+02,
content:'Saddle = 327.700012 pos = 35.0002,132.3489 diff = 198.000000'
});
data_peak.push({
lat: 3.5066555556e+01,
lng: 1.3237433333e+02,
cert : false,
content:' Peak = 444.700012 pos = 35.0666,132.3743 diff = 160.600006'
});
data_saddle.push({
lat: 3.5070666667e+01,
lng: 1.3238244444e+02,
content:'Saddle = 284.100006 pos = 35.0707,132.3824 diff = 160.600006'
});
data_peak.push({
lat: 3.5067555556e+01,
lng: 1.3239122222e+02,
cert : true,
content:'Name = JA/SN-070(JA/SN-070) peak = 583.400024 pos = 35.0676,132.3912 diff = 239.400024'
});
data_saddle.push({
lat: 3.5067666667e+01,
lng: 1.3239944444e+02,
content:'Saddle = 344.000000 pos = 35.0677,132.3994 diff = 239.400024'
});
data_peak.push({
lat: 3.5079555556e+01,
lng: 1.3239100000e+02,
cert : false,
content:' Peak = 546.400024 pos = 35.0796,132.3910 diff = 175.900024'
});
data_saddle.push({
lat: 3.5072777778e+01,
lng: 1.3239133333e+02,
content:'Saddle = 370.500000 pos = 35.0728,132.3913 diff = 175.900024'
});
data_peak.push({
lat: 3.5096222222e+01,
lng: 1.3243766667e+02,
cert : false,
content:' Peak = 536.200012 pos = 35.0962,132.4377 diff = 165.100006'
});
data_saddle.push({
lat: 3.5091444445e+01,
lng: 1.3243166667e+02,
content:'Saddle = 371.100006 pos = 35.0914,132.4317 diff = 165.100006'
});
data_peak.push({
lat: 3.5085000000e+01,
lng: 1.3241677778e+02,
cert : true,
content:'Name = JA/SN-059(JA/SN-059) peak = 633.299988 pos = 35.0850,132.4168 diff = 206.299988'
});
data_saddle.push({
lat: 3.5078777778e+01,
lng: 1.3242155556e+02,
content:'Saddle = 427.000000 pos = 35.0788,132.4216 diff = 206.299988'
});
data_peak.push({
lat: 3.5068222222e+01,
lng: 1.3240744444e+02,
cert : false,
content:' Peak = 634.200012 pos = 35.0682,132.4074 diff = 182.500000'
});
data_saddle.push({
lat: 3.5067666667e+01,
lng: 1.3241255556e+02,
content:'Saddle = 451.700012 pos = 35.0677,132.4126 diff = 182.500000'
});
data_peak.push({
lat: 3.5068444445e+01,
lng: 1.3242155556e+02,
cert : false,
content:' Peak = 721.000000 pos = 35.0684,132.4216 diff = 159.299988'
});
data_saddle.push({
lat: 3.5065222222e+01,
lng: 1.3242366667e+02,
content:'Saddle = 561.700012 pos = 35.0652,132.4237 diff = 159.299988'
});
data_peak.push({
lat: 3.4835222222e+01,
lng: 1.3281355556e+02,
cert : true,
content:'Name = JA/HS-197(JA/HS-197) peak = 433.899994 pos = 34.8352,132.8136 diff = 201.899994'
});
data_saddle.push({
lat: 3.4853777778e+01,
lng: 1.3284900000e+02,
content:'Saddle = 232.000000 pos = 34.8538,132.8490 diff = 201.899994'
});
data_peak.push({
lat: 3.4871444445e+01,
lng: 1.3292333333e+02,
cert : false,
content:' Peak = 455.700012 pos = 34.8714,132.9233 diff = 172.000000'
});
data_saddle.push({
lat: 3.4881444445e+01,
lng: 1.3292566667e+02,
content:'Saddle = 283.700012 pos = 34.8814,132.9257 diff = 172.000000'
});
data_peak.push({
lat: 3.4884888889e+01,
lng: 1.3272377778e+02,
cert : true,
content:'Name = JA/HS-168(JA/HS-168) peak = 510.799988 pos = 34.8849,132.7238 diff = 193.299988'
});
data_saddle.push({
lat: 3.4907666667e+01,
lng: 1.3272711111e+02,
content:'Saddle = 317.500000 pos = 34.9077,132.7271 diff = 193.299988'
});
data_peak.push({
lat: 3.4889444445e+01,
lng: 1.3286155556e+02,
cert : true,
content:'Name = JA/HS-169(JA/HS-169) peak = 506.399994 pos = 34.8894,132.8616 diff = 188.500000'
});
data_saddle.push({
lat: 3.4906666667e+01,
lng: 1.3287611111e+02,
content:'Saddle = 317.899994 pos = 34.9067,132.8761 diff = 188.500000'
});
data_peak.push({
lat: 3.5249777778e+01,
lng: 1.3273200000e+02,
cert : true,
content:'Name = JA/SN-088(JA/SN-088) peak = 524.799988 pos = 35.2498,132.7320 diff = 196.199982'
});
data_saddle.push({
lat: 3.5251333333e+01,
lng: 1.3274333333e+02,
content:'Saddle = 328.600006 pos = 35.2513,132.7433 diff = 196.199982'
});
data_peak.push({
lat: 3.5234111111e+01,
lng: 1.3269833333e+02,
cert : false,
content:' Peak = 488.000000 pos = 35.2341,132.6983 diff = 156.600006'
});
data_saddle.push({
lat: 3.5223333333e+01,
lng: 1.3269455556e+02,
content:'Saddle = 331.399994 pos = 35.2233,132.6946 diff = 156.600006'
});
data_peak.push({
lat: 3.4899555556e+01,
lng: 1.3298766667e+02,
cert : false,
content:' Peak = 502.000000 pos = 34.8996,132.9877 diff = 170.600006'
});
data_saddle.push({
lat: 3.4909111111e+01,
lng: 1.3299988889e+02,
content:'Saddle = 331.399994 pos = 34.9091,132.9999 diff = 170.600006'
});
data_peak.push({
lat: 3.4998222222e+01,
lng: 1.3263400000e+02,
cert : true,
content:'Name = JA/SN-081(JA/SN-081) peak = 554.099976 pos = 34.9982,132.6340 diff = 213.299988'
});
data_saddle.push({
lat: 3.5001666667e+01,
lng: 1.3264266667e+02,
content:'Saddle = 340.799988 pos = 35.0017,132.6427 diff = 213.299988'
});
data_peak.push({
lat: 3.5260555556e+01,
lng: 1.3275388889e+02,
cert : true,
content:'Name = JA/SN-077(JA/SN-077) peak = 573.799988 pos = 35.2606,132.7539 diff = 216.399994'
});
data_saddle.push({
lat: 3.5259666667e+01,
lng: 1.3277200000e+02,
content:'Saddle = 357.399994 pos = 35.2597,132.7720 diff = 216.399994'
});
data_peak.push({
lat: 3.5037888889e+01,
lng: 1.3263733333e+02,
cert : false,
content:' Peak = 548.299988 pos = 35.0379,132.6373 diff = 171.199982'
});
data_saddle.push({
lat: 3.5041555556e+01,
lng: 1.3265066667e+02,
content:'Saddle = 377.100006 pos = 35.0416,132.6507 diff = 171.199982'
});
data_peak.push({
lat: 3.5243777778e+01,
lng: 1.3278455556e+02,
cert : true,
content:'Name = JA/SN-076(JA/SN-076) peak = 568.299988 pos = 35.2438,132.7846 diff = 181.500000'
});
data_saddle.push({
lat: 3.5220111111e+01,
lng: 1.3275822222e+02,
content:'Saddle = 386.799988 pos = 35.2201,132.7582 diff = 181.500000'
});
data_peak.push({
lat: 3.5166555556e+01,
lng: 1.3294444444e+02,
cert : false,
content:' Peak = 551.099976 pos = 35.1666,132.9444 diff = 155.099976'
});
data_saddle.push({
lat: 3.5146111111e+01,
lng: 1.3293200000e+02,
content:'Saddle = 396.000000 pos = 35.1461,132.9320 diff = 155.099976'
});
data_peak.push({
lat: 3.4878555556e+01,
lng: 1.3276177778e+02,
cert : true,
content:'Name = JA/HS-134(JA/HS-134) peak = 613.099976 pos = 34.8786,132.7618 diff = 205.999969'
});
data_saddle.push({
lat: 3.4885333333e+01,
lng: 1.3276366667e+02,
content:'Saddle = 407.100006 pos = 34.8853,132.7637 diff = 205.999969'
});
data_peak.push({
lat: 3.4842222222e+01,
lng: 1.3275566667e+02,
cert : false,
content:' Peak = 612.000000 pos = 34.8422,132.7557 diff = 165.100006'
});
data_saddle.push({
lat: 3.4867666667e+01,
lng: 1.3274288889e+02,
content:'Saddle = 446.899994 pos = 34.8677,132.7429 diff = 165.100006'
});
data_peak.push({
lat: 3.5176333333e+01,
lng: 1.3284944444e+02,
cert : true,
content:'Name = JA/SN-053(JA/SN-053) peak = 662.799988 pos = 35.1763,132.8494 diff = 255.099976'
});
data_saddle.push({
lat: 3.5157666667e+01,
lng: 1.3287666667e+02,
content:'Saddle = 407.700012 pos = 35.1577,132.8767 diff = 255.099976'
});
data_peak.push({
lat: 3.5148444444e+01,
lng: 1.3291777778e+02,
cert : false,
content:' Peak = 572.500000 pos = 35.1484,132.9178 diff = 164.299988'
});
data_saddle.push({
lat: 3.5144000000e+01,
lng: 1.3291622222e+02,
content:'Saddle = 408.200012 pos = 35.1440,132.9162 diff = 164.299988'
});
data_peak.push({
lat: 3.4938444445e+01,
lng: 1.3298700000e+02,
cert : false,
content:' Peak = 674.900024 pos = 34.9384,132.9870 diff = 265.000031'
});
data_saddle.push({
lat: 3.4957666667e+01,
lng: 1.3299988889e+02,
content:'Saddle = 409.899994 pos = 34.9577,132.9999 diff = 265.000031'
});
data_peak.push({
lat: 3.4891111111e+01,
lng: 1.3276488889e+02,
cert : false,
content:' Peak = 561.900024 pos = 34.8911,132.7649 diff = 150.900024'
});
data_saddle.push({
lat: 3.4899222222e+01,
lng: 1.3276488889e+02,
content:'Saddle = 411.000000 pos = 34.8992,132.7649 diff = 150.900024'
});
data_peak.push({
lat: 3.5140555556e+01,
lng: 1.3262144444e+02,
cert : true,
content:'Name = Sanbesan (Osanbesan)(JA/SN-004) peak = 1124.500000 pos = 35.1406,132.6214 diff = 708.200012'
});
data_saddle.push({
lat: 3.5076888889e+01,
lng: 1.3267333333e+02,
content:'Saddle = 416.299988 pos = 35.0769,132.6733 diff = 708.200012'
});
data_peak.push({
lat: 3.4964777778e+01,
lng: 1.3299988889e+02,
cert : false,
content:' Peak = 614.000000 pos = 34.9648,132.9999 diff = 193.500000'
});
data_saddle.push({
lat: 3.4973777778e+01,
lng: 1.3299988889e+02,
content:'Saddle = 420.500000 pos = 34.9738,132.9999 diff = 193.500000'
});
data_peak.push({
lat: 3.5072666667e+01,
lng: 1.3268688889e+02,
cert : true,
content:'Name = JA/SN-050(JA/SN-050) peak = 681.099976 pos = 35.0727,132.6869 diff = 257.799988'
});
data_saddle.push({
lat: 3.5054222222e+01,
lng: 1.3271800000e+02,
content:'Saddle = 423.299988 pos = 35.0542,132.7180 diff = 257.799988'
});
data_peak.push({
lat: 3.5025666667e+01,
lng: 1.3268777778e+02,
cert : true,
content:'Name = JA/SN-038(JA/SN-038) peak = 741.299988 pos = 35.0257,132.6878 diff = 298.299988'
});
data_saddle.push({
lat: 3.5008666667e+01,
lng: 1.3270700000e+02,
content:'Saddle = 443.000000 pos = 35.0087,132.7070 diff = 298.299988'
});
data_peak.push({
lat: 3.4982222222e+01,
lng: 1.3299833333e+02,
cert : false,
content:' Peak = 614.400024 pos = 34.9822,132.9983 diff = 167.800018'
});
data_saddle.push({
lat: 3.4990222222e+01,
lng: 1.3299988889e+02,
content:'Saddle = 446.600006 pos = 34.9902,132.9999 diff = 167.800018'
});
data_peak.push({
lat: 3.5147222222e+01,
lng: 1.3274211111e+02,
cert : true,
content:'Name = JA/SN-061(JA/SN-061) peak = 622.099976 pos = 35.1472,132.7421 diff = 169.799988'
});
data_saddle.push({
lat: 3.5146666667e+01,
lng: 1.3275000000e+02,
content:'Saddle = 452.299988 pos = 35.1467,132.7500 diff = 169.799988'
});
data_peak.push({
lat: 3.5161444444e+01,
lng: 1.3271000000e+02,
cert : true,
content:'Name = JA/SN-055(JA/SN-055) peak = 657.000000 pos = 35.1614,132.7100 diff = 200.100006'
});
data_saddle.push({
lat: 3.5138777778e+01,
lng: 1.3272033333e+02,
content:'Saddle = 456.899994 pos = 35.1388,132.7203 diff = 200.100006'
});
data_peak.push({
lat: 3.5128222222e+01,
lng: 1.3272366667e+02,
cert : true,
content:'Name = JA/SN-041(JA/SN-041) peak = 721.700012 pos = 35.1282,132.7237 diff = 255.400024'
});
data_saddle.push({
lat: 3.5121888889e+01,
lng: 1.3274544444e+02,
content:'Saddle = 466.299988 pos = 35.1219,132.7454 diff = 255.400024'
});
data_peak.push({
lat: 3.4994888889e+01,
lng: 1.3269311111e+02,
cert : false,
content:' Peak = 685.700012 pos = 34.9949,132.6931 diff = 197.100006'
});
data_saddle.push({
lat: 3.4988666667e+01,
lng: 1.3270566667e+02,
content:'Saddle = 488.600006 pos = 34.9887,132.7057 diff = 197.100006'
});
data_peak.push({
lat: 3.5182777778e+01,
lng: 1.3274955556e+02,
cert : true,
content:'Name = JA/SN-040(JA/SN-040) peak = 725.099976 pos = 35.1828,132.7496 diff = 228.899963'
});
data_saddle.push({
lat: 3.5163333333e+01,
lng: 1.3277277778e+02,
content:'Saddle = 496.200012 pos = 35.1633,132.7728 diff = 228.899963'
});
data_peak.push({
lat: 3.5187666667e+01,
lng: 1.3278388889e+02,
cert : true,
content:'Name = JA/SN-048(JA/SN-048) peak = 710.500000 pos = 35.1877,132.7839 diff = 213.700012'
});
data_saddle.push({
lat: 3.5180555556e+01,
lng: 1.3277711111e+02,
content:'Saddle = 496.799988 pos = 35.1806,132.7771 diff = 213.700012'
});
data_peak.push({
lat: 3.5005777778e+01,
lng: 1.3299988889e+02,
cert : false,
content:' Peak = 763.500000 pos = 35.0058,132.9999 diff = 265.299988'
});
data_saddle.push({
lat: 3.5032888889e+01,
lng: 1.3299988889e+02,
content:'Saddle = 498.200012 pos = 35.0329,132.9999 diff = 265.299988'
});
data_peak.push({
lat: 3.4913222222e+01,
lng: 1.3282477778e+02,
cert : false,
content:' Peak = 706.400024 pos = 34.9132,132.8248 diff = 198.600037'
});
data_saddle.push({
lat: 3.4918666667e+01,
lng: 1.3281777778e+02,
content:'Saddle = 507.799988 pos = 34.9187,132.8178 diff = 198.600037'
});
data_peak.push({
lat: 3.4928111111e+01,
lng: 1.3285711111e+02,
cert : true,
content:'Name = JA/HS-093(JA/HS-093) peak = 732.500000 pos = 34.9281,132.8571 diff = 223.200012'
});
data_saddle.push({
lat: 3.4942888889e+01,
lng: 1.3285111111e+02,
content:'Saddle = 509.299988 pos = 34.9429,132.8511 diff = 223.200012'
});
data_peak.push({
lat: 3.5137111111e+01,
lng: 1.3275788889e+02,
cert : true,
content:'Name = JA/SN-042(JA/SN-042) peak = 720.700012 pos = 35.1371,132.7579 diff = 192.600037'
});
data_saddle.push({
lat: 3.5123444444e+01,
lng: 1.3276600000e+02,
content:'Saddle = 528.099976 pos = 35.1234,132.7660 diff = 192.600037'
});
data_peak.push({
lat: 3.4940777778e+01,
lng: 1.3289055556e+02,
cert : true,
content:'Name = JA/HS-080(JA/HS-080) peak = 773.000000 pos = 34.9408,132.8906 diff = 220.500000'
});
data_saddle.push({
lat: 3.4952111111e+01,
lng: 1.3288866667e+02,
content:'Saddle = 552.500000 pos = 34.9521,132.8887 diff = 220.500000'
});
data_peak.push({
lat: 3.5124333333e+01,
lng: 1.3278733333e+02,
cert : true,
content:'Name = JA/SN-035(JA/SN-035) peak = 781.799988 pos = 35.1243,132.7873 diff = 204.899963'
});
data_saddle.push({
lat: 3.5119000000e+01,
lng: 1.3278544444e+02,
content:'Saddle = 576.900024 pos = 35.1190,132.7854 diff = 204.899963'
});
data_peak.push({
lat: 3.4956777778e+01,
lng: 1.3297300000e+02,
cert : true,
content:'Name = JA/HS-079(JA/HS-079) peak = 772.200012 pos = 34.9568,132.9730 diff = 194.400024'
});
data_saddle.push({
lat: 3.4980333333e+01,
lng: 1.3295788889e+02,
content:'Saddle = 577.799988 pos = 34.9803,132.9579 diff = 194.400024'
});
data_peak.push({
lat: 3.4948111111e+01,
lng: 1.3272044444e+02,
cert : true,
content:'Name = JA/HS-062(JA/HS-062) peak = 830.099976 pos = 34.9481,132.7204 diff = 233.599976'
});
data_saddle.push({
lat: 3.4958111111e+01,
lng: 1.3273533333e+02,
content:'Saddle = 596.500000 pos = 34.9581,132.7353 diff = 233.599976'
});
data_peak.push({
lat: 3.4937666667e+01,
lng: 1.3293811111e+02,
cert : false,
content:' Peak = 783.500000 pos = 34.9377,132.9381 diff = 186.599976'
});
data_saddle.push({
lat: 3.4960555556e+01,
lng: 1.3292477778e+02,
content:'Saddle = 596.900024 pos = 34.9606,132.9248 diff = 186.599976'
});
data_peak.push({
lat: 3.5110111111e+01,
lng: 1.3277666667e+02,
cert : false,
content:' Peak = 784.700012 pos = 35.1101,132.7767 diff = 186.900024'
});
data_saddle.push({
lat: 3.5105666667e+01,
lng: 1.3279800000e+02,
content:'Saddle = 597.799988 pos = 35.1057,132.7980 diff = 186.900024'
});
data_peak.push({
lat: 3.5132666667e+01,
lng: 1.3280944444e+02,
cert : true,
content:'Name = JA/SN-026(JA/SN-026) peak = 842.599976 pos = 35.1327,132.8094 diff = 244.199951'
});
data_saddle.push({
lat: 3.5116111111e+01,
lng: 1.3281000000e+02,
content:'Saddle = 598.400024 pos = 35.1161,132.8100 diff = 244.199951'
});
data_peak.push({
lat: 3.4982111111e+01,
lng: 1.3292288889e+02,
cert : true,
content:'Name = JA/HS-029(JA/HS-029) peak = 1015.400024 pos = 34.9821,132.9229 diff = 387.800049'
});
data_saddle.push({
lat: 3.5036333333e+01,
lng: 1.3298188889e+02,
content:'Saddle = 627.599976 pos = 35.0363,132.9819 diff = 387.800049'
});
data_peak.push({
lat: 3.5004222222e+01,
lng: 1.3283811111e+02,
cert : false,
content:' Peak = 939.200012 pos = 35.0042,132.8381 diff = 300.700012'
});
data_saddle.push({
lat: 3.4992111111e+01,
lng: 1.3287011111e+02,
content:'Saddle = 638.500000 pos = 34.9921,132.8701 diff = 300.700012'
});
data_peak.push({
lat: 3.4961333333e+01,
lng: 1.3288211111e+02,
cert : false,
content:' Peak = 843.200012 pos = 34.9613,132.8821 diff = 171.799988'
});
data_saddle.push({
lat: 3.4968222222e+01,
lng: 1.3288444444e+02,
content:'Saddle = 671.400024 pos = 34.9682,132.8844 diff = 171.799988'
});
data_peak.push({
lat: 3.4961333333e+01,
lng: 1.3290522222e+02,
cert : false,
content:' Peak = 842.700012 pos = 34.9613,132.9052 diff = 154.000000'
});
data_saddle.push({
lat: 3.4964444445e+01,
lng: 1.3290422222e+02,
content:'Saddle = 688.700012 pos = 34.9644,132.9042 diff = 154.000000'
});
data_peak.push({
lat: 3.5001555556e+01,
lng: 1.3288111111e+02,
cert : false,
content:' Peak = 863.200012 pos = 35.0016,132.8811 diff = 152.400024'
});
data_saddle.push({
lat: 3.4996555556e+01,
lng: 1.3288788889e+02,
content:'Saddle = 710.799988 pos = 34.9966,132.8879 diff = 152.400024'
});
data_peak.push({
lat: 3.5008666667e+01,
lng: 1.3293455556e+02,
cert : false,
content:' Peak = 1002.299988 pos = 35.0087,132.9346 diff = 153.799988'
});
data_saddle.push({
lat: 3.4991111111e+01,
lng: 1.3292522222e+02,
content:'Saddle = 848.500000 pos = 34.9911,132.9252 diff = 153.799988'
});
data_peak.push({
lat: 3.5104777778e+01,
lng: 1.3281355556e+02,
cert : true,
content:'Name = JA/SN-018(JA/SN-018) peak = 955.400024 pos = 35.1048,132.8136 diff = 323.600037'
});
data_saddle.push({
lat: 3.5103555556e+01,
lng: 1.3282622222e+02,
content:'Saddle = 631.799988 pos = 35.1036,132.8262 diff = 323.600037'
});
data_peak.push({
lat: 3.5087555556e+01,
lng: 1.3285444444e+02,
cert : true,
content:'Name = Ooyorogiyama(JA/HS-010) peak = 1217.699951 pos = 35.0876,132.8544 diff = 579.099976'
});
data_saddle.push({
lat: 3.5087666667e+01,
lng: 1.3290744444e+02,
content:'Saddle = 638.599976 pos = 35.0877,132.9074 diff = 579.099976'
});
data_peak.push({
lat: 3.4912555556e+01,
lng: 1.3279788889e+02,
cert : true,
content:'Name = JA/HS-057(JA/HS-057) peak = 840.700012 pos = 34.9126,132.7979 diff = 201.400024'
});
data_saddle.push({
lat: 3.4957000000e+01,
lng: 1.3278722222e+02,
content:'Saddle = 639.299988 pos = 34.9570,132.7872 diff = 201.400024'
});
data_peak.push({
lat: 3.4939555556e+01,
lng: 1.3279344444e+02,
cert : true,
content:'Name = JA/HS-065(JA/HS-065) peak = 818.099976 pos = 34.9396,132.7934 diff = 157.500000'
});
data_saddle.push({
lat: 3.4918000000e+01,
lng: 1.3279888889e+02,
content:'Saddle = 660.599976 pos = 34.9180,132.7989 diff = 157.500000'
});
data_peak.push({
lat: 3.4993111111e+01,
lng: 1.3276322222e+02,
cert : false,
content:' Peak = 853.900024 pos = 34.9931,132.7632 diff = 187.200012'
});
data_saddle.push({
lat: 3.5002555556e+01,
lng: 1.3278111111e+02,
content:'Saddle = 666.700012 pos = 35.0026,132.7811 diff = 187.200012'
});
data_peak.push({
lat: 3.5022444445e+01,
lng: 1.3280044444e+02,
cert : true,
content:'Name = JA/HS-048(JA/HS-048) peak = 903.799988 pos = 35.0224,132.8004 diff = 211.599976'
});
data_saddle.push({
lat: 3.5031666667e+01,
lng: 1.3281077778e+02,
content:'Saddle = 692.200012 pos = 35.0317,132.8108 diff = 211.599976'
});
data_peak.push({
lat: 3.5048222222e+01,
lng: 1.3278244444e+02,
cert : true,
content:'Name = Kotobikisan (Misen)(JA/SN-013) peak = 1012.700012 pos = 35.0482,132.7824 diff = 181.000000'
});
data_saddle.push({
lat: 3.5056000000e+01,
lng: 1.3281055556e+02,
content:'Saddle = 831.700012 pos = 35.0560,132.8106 diff = 181.000000'
});
data_peak.push({
lat: 3.5047000000e+01,
lng: 1.3283544444e+02,
cert : true,
content:'Name = JA/HS-025(JA/HS-025) peak = 1042.099976 pos = 35.0470,132.8354 diff = 209.399963'
});
data_saddle.push({
lat: 3.5057111111e+01,
lng: 1.3283133333e+02,
content:'Saddle = 832.700012 pos = 35.0571,132.8313 diff = 209.399963'
});
data_peak.push({
lat: 3.5060444445e+01,
lng: 1.3299555556e+02,
cert : true,
content:'Name = JA/HS-028(JA/HS-028) peak = 1021.299988 pos = 35.0604,132.9956 diff = 249.899963'
});
data_saddle.push({
lat: 3.5080222222e+01,
lng: 1.3299988889e+02,
content:'Saddle = 771.400024 pos = 35.0802,132.9999 diff = 249.899963'
});
data_peak.push({
lat: 3.5095333333e+01,
lng: 1.3298122222e+02,
cert : false,
content:' Peak = 1181.800049 pos = 35.0953,132.9812 diff = 160.100037'
});
data_saddle.push({
lat: 3.5084777778e+01,
lng: 1.3297555556e+02,
content:'Saddle = 1021.700012 pos = 35.0848,132.9756 diff = 160.100037'
});
data_peak.push({
lat: 3.4921000000e+01,
lng: 1.3219700000e+02,
cert : true,
content:'Name = JA/SN-115(JA/SN-115) peak = 416.500000 pos = 34.9210,132.1970 diff = 199.600006'
});
data_saddle.push({
lat: 3.4911444445e+01,
lng: 1.3220522222e+02,
content:'Saddle = 216.899994 pos = 34.9114,132.2052 diff = 199.600006'
});
data_peak.push({
lat: 3.4115111112e+01,
lng: 1.3209288889e+02,
cert : true,
content:'Name = JA/YG-119(JA/YG-119) peak = 401.200012 pos = 34.1151,132.0929 diff = 183.700012'
});
data_saddle.push({
lat: 3.4124333334e+01,
lng: 1.3209233333e+02,
content:'Saddle = 217.500000 pos = 34.1243,132.0923 diff = 183.700012'
});
data_peak.push({
lat: 3.4073444445e+01,
lng: 1.3163033333e+02,
cert : true,
content:'Name = Oohirayama(JA/YG-043) peak = 631.099976 pos = 34.0734,131.6303 diff = 413.599976'
});
data_saddle.push({
lat: 3.4115444445e+01,
lng: 1.3169766667e+02,
content:'Saddle = 217.500000 pos = 34.1154,131.6977 diff = 413.599976'
});
data_peak.push({
lat: 3.4135888889e+01,
lng: 1.3165211111e+02,
cert : false,
content:' Peak = 490.100006 pos = 34.1359,131.6521 diff = 157.600006'
});
data_saddle.push({
lat: 3.4116222223e+01,
lng: 1.3164488889e+02,
content:'Saddle = 332.500000 pos = 34.1162,131.6449 diff = 157.600006'
});
data_peak.push({
lat: 3.4493000000e+01,
lng: 1.3248700000e+02,
cert : true,
content:'Name = JA/HS-142(JA/HS-142) peak = 585.599976 pos = 34.4930,132.4870 diff = 367.999969'
});
data_saddle.push({
lat: 3.4495888889e+01,
lng: 1.3244211111e+02,
content:'Saddle = 217.600006 pos = 34.4959,132.4421 diff = 367.999969'
});
data_peak.push({
lat: 3.4498111111e+01,
lng: 1.3245277778e+02,
cert : false,
content:' Peak = 450.500000 pos = 34.4981,132.4528 diff = 224.300003'
});
data_saddle.push({
lat: 3.4489888889e+01,
lng: 1.3245933333e+02,
content:'Saddle = 226.199997 pos = 34.4899,132.4593 diff = 224.300003'
});
data_peak.push({
lat: 3.4504777778e+01,
lng: 1.3246377778e+02,
cert : false,
content:' Peak = 421.200012 pos = 34.5048,132.4638 diff = 173.900009'
});
data_saddle.push({
lat: 3.4502666667e+01,
lng: 1.3245988889e+02,
content:'Saddle = 247.300003 pos = 34.5027,132.4599 diff = 173.900009'
});
data_peak.push({
lat: 3.4493777778e+01,
lng: 1.3242322222e+02,
cert : true,
content:'Name = JA/HS-129(JA/HS-129) peak = 631.000000 pos = 34.4938,132.4232 diff = 413.399994'
});
data_saddle.push({
lat: 3.4490333334e+01,
lng: 1.3239777778e+02,
content:'Saddle = 217.600006 pos = 34.4903,132.3978 diff = 413.399994'
});
data_peak.push({
lat: 3.4514222223e+01,
lng: 1.3244600000e+02,
cert : true,
content:'Name = JA/HS-176(JA/HS-176) peak = 487.000000 pos = 34.5142,132.4460 diff = 256.299988'
});
data_saddle.push({
lat: 3.4508333334e+01,
lng: 1.3243800000e+02,
content:'Saddle = 230.699997 pos = 34.5083,132.4380 diff = 256.299988'
});
data_peak.push({
lat: 3.4878777778e+01,
lng: 1.3213755556e+02,
cert : true,
content:'Name = JA/SN-114(JA/SN-114) peak = 413.799988 pos = 34.8788,132.1376 diff = 196.099991'
});
data_saddle.push({
lat: 3.4871111111e+01,
lng: 1.3215588889e+02,
content:'Saddle = 217.699997 pos = 34.8711,132.1559 diff = 196.099991'
});
data_peak.push({
lat: 3.4214555556e+01,
lng: 1.3115522222e+02,
cert : false,
content:' Peak = 397.700012 pos = 34.2146,131.1552 diff = 179.600006'
});
data_saddle.push({
lat: 3.4240777778e+01,
lng: 1.3116722222e+02,
content:'Saddle = 218.100006 pos = 34.2408,131.1672 diff = 179.600006'
});
data_peak.push({
lat: 3.4546777778e+01,
lng: 1.3165600000e+02,
cert : true,
content:'Name = JA/YG-112(JA/YG-112) peak = 423.899994 pos = 34.5468,131.6560 diff = 201.899994'
});
data_saddle.push({
lat: 3.4550333334e+01,
lng: 1.3164311111e+02,
content:'Saddle = 222.000000 pos = 34.5503,131.6431 diff = 201.899994'
});
data_peak.push({
lat: 3.4960000000e+01,
lng: 1.3227733333e+02,
cert : true,
content:'Name = JA/SN-094(JA/SN-094) peak = 505.000000 pos = 34.9600,132.2773 diff = 280.600006'
});
data_saddle.push({
lat: 3.4904555556e+01,
lng: 1.3223211111e+02,
content:'Saddle = 224.399994 pos = 34.9046,132.2321 diff = 280.600006'
});
data_peak.push({
lat: 3.4919444445e+01,
lng: 1.3225088889e+02,
cert : true,
content:'Name = JA/SN-099(JA/SN-099) peak = 470.299988 pos = 34.9194,132.2509 diff = 213.399994'
});
data_saddle.push({
lat: 3.4935111111e+01,
lng: 1.3225266667e+02,
content:'Saddle = 256.899994 pos = 34.9351,132.2527 diff = 213.399994'
});
data_peak.push({
lat: 3.4984111111e+01,
lng: 1.3223733333e+02,
cert : true,
content:'Name = JA/SN-102(JA/SN-102) peak = 470.000000 pos = 34.9841,132.2373 diff = 212.299988'
});
data_saddle.push({
lat: 3.4969111111e+01,
lng: 1.3225200000e+02,
content:'Saddle = 257.700012 pos = 34.9691,132.2520 diff = 212.299988'
});
data_peak.push({
lat: 3.4951111111e+01,
lng: 1.3228600000e+02,
cert : false,
content:' Peak = 500.299988 pos = 34.9511,132.2860 diff = 152.099976'
});
data_saddle.push({
lat: 3.4953666667e+01,
lng: 1.3228066667e+02,
content:'Saddle = 348.200012 pos = 34.9537,132.2807 diff = 152.099976'
});
data_peak.push({
lat: 3.4311000000e+01,
lng: 1.3104288889e+02,
cert : true,
content:'Name = Tenjyougadake(JA/YG-030) peak = 690.500000 pos = 34.3110,131.0429 diff = 462.399994'
});
data_saddle.push({
lat: 3.4313444445e+01,
lng: 1.3114900000e+02,
content:'Saddle = 228.100006 pos = 34.3134,131.1490 diff = 462.399994'
});
data_peak.push({
lat: 3.4341333334e+01,
lng: 1.3114344444e+02,
cert : true,
content:'Name = JA/YG-090(JA/YG-090) peak = 520.000000 pos = 34.3413,131.1434 diff = 261.799988'
});
data_saddle.push({
lat: 3.4308777778e+01,
lng: 1.3107311111e+02,
content:'Saddle = 258.200012 pos = 34.3088,131.0731 diff = 261.799988'
});
data_peak.push({
lat: 3.4292000000e+01,
lng: 1.3106733333e+02,
cert : true,
content:'Name = JA/YG-034(JA/YG-034) peak = 670.900024 pos = 34.2920,131.0673 diff = 267.000031'
});
data_saddle.push({
lat: 3.4305777778e+01,
lng: 1.3105300000e+02,
content:'Saddle = 403.899994 pos = 34.3058,131.0530 diff = 267.000031'
});
data_peak.push({
lat: 3.4253333334e+01,
lng: 1.3135833333e+02,
cert : true,
content:'Name = JA/YG-080(JA/YG-080) peak = 542.299988 pos = 34.2533,131.3583 diff = 309.500000'
});
data_saddle.push({
lat: 3.4254888889e+01,
lng: 1.3134777778e+02,
content:'Saddle = 232.800003 pos = 34.2549,131.3478 diff = 309.500000'
});
data_peak.push({
lat: 3.4368666667e+01,
lng: 1.3152066667e+02,
cert : false,
content:' Peak = 394.200012 pos = 34.3687,131.5207 diff = 157.500015'
});
data_saddle.push({
lat: 3.4380000000e+01,
lng: 1.3151933333e+02,
content:'Saddle = 236.699997 pos = 34.3800,131.5193 diff = 157.500015'
});
data_peak.push({
lat: 3.4580333334e+01,
lng: 1.3232955556e+02,
cert : true,
content:'Name = JA/HS-192(JA/HS-192) peak = 441.700012 pos = 34.5803,132.3296 diff = 202.800018'
});
data_saddle.push({
lat: 3.4581333334e+01,
lng: 1.3233366667e+02,
content:'Saddle = 238.899994 pos = 34.5813,132.3337 diff = 202.800018'
});
data_peak.push({
lat: 3.4167444445e+01,
lng: 1.3204588889e+02,
cert : false,
content:' Peak = 420.799988 pos = 34.1674,132.0459 diff = 179.499985'
});
data_saddle.push({
lat: 3.4159111112e+01,
lng: 1.3205866667e+02,
content:'Saddle = 241.300003 pos = 34.1591,132.0587 diff = 179.499985'
});
data_peak.push({
lat: 3.4233000000e+01,
lng: 1.3128066667e+02,
cert : true,
content:'Name = Ryūgobō(JA/YG-115) peak = 424.700012 pos = 34.2330,131.2807 diff = 182.700012'
});
data_saddle.push({
lat: 3.4247777778e+01,
lng: 1.3129322222e+02,
content:'Saddle = 242.000000 pos = 34.2478,131.2932 diff = 182.700012'
});
data_peak.push({
lat: 3.4348000000e+01,
lng: 1.3136322222e+02,
cert : true,
content:'Name = JA/YG-088(JA/YG-088) peak = 522.500000 pos = 34.3480,131.3632 diff = 280.000000'
});
data_saddle.push({
lat: 3.4328777778e+01,
lng: 1.3134566667e+02,
content:'Saddle = 242.500000 pos = 34.3288,131.3457 diff = 280.000000'
});
data_peak.push({
lat: 3.4370222223e+01,
lng: 1.3131955556e+02,
cert : true,
content:'Name = JA/YG-089(JA/YG-089) peak = 520.500000 pos = 34.3702,131.3196 diff = 261.500000'
});
data_saddle.push({
lat: 3.4362333334e+01,
lng: 1.3132455556e+02,
content:'Saddle = 259.000000 pos = 34.3623,131.3246 diff = 261.500000'
});
data_peak.push({
lat: 3.4379111111e+01,
lng: 1.3133000000e+02,
cert : false,
content:' Peak = 466.899994 pos = 34.3791,131.3300 diff = 169.699982'
});
data_saddle.push({
lat: 3.4376444445e+01,
lng: 1.3132600000e+02,
content:'Saddle = 297.200012 pos = 34.3764,131.3260 diff = 169.699982'
});
data_peak.push({
lat: 3.4360777778e+01,
lng: 1.3133588889e+02,
cert : false,
content:' Peak = 455.700012 pos = 34.3608,131.3359 diff = 176.300018'
});
data_saddle.push({
lat: 3.4355888889e+01,
lng: 1.3134400000e+02,
content:'Saddle = 279.399994 pos = 34.3559,131.3440 diff = 176.300018'
});
data_peak.push({
lat: 3.4339000000e+01,
lng: 1.3134311111e+02,
cert : false,
content:' Peak = 512.599976 pos = 34.3390,131.3431 diff = 170.899963'
});
data_saddle.push({
lat: 3.4345666667e+01,
lng: 1.3134577778e+02,
content:'Saddle = 341.700012 pos = 34.3457,131.3458 diff = 170.899963'
});
data_peak.push({
lat: 3.4850777778e+01,
lng: 1.3269377778e+02,
cert : true,
content:'Name = JA/SN-107(JA/SN-107) peak = 447.100006 pos = 34.8508,132.6938 diff = 200.600006'
});
data_saddle.push({
lat: 3.4851333333e+01,
lng: 1.3267933333e+02,
content:'Saddle = 246.500000 pos = 34.8513,132.6793 diff = 200.600006'
});
data_peak.push({
lat: 3.4265000000e+01,
lng: 1.3130555556e+02,
cert : false,
content:' Peak = 407.100006 pos = 34.2650,131.3056 diff = 159.100006'
});
data_saddle.push({
lat: 3.4274444445e+01,
lng: 1.3130611111e+02,
content:'Saddle = 248.000000 pos = 34.2744,131.3061 diff = 159.100006'
});
data_peak.push({
lat: 3.4305444445e+01,
lng: 1.3130277778e+02,
cert : true,
content:'Name = Katsuragisan(JA/YG-028) peak = 701.500000 pos = 34.3054,131.3028 diff = 453.100006'
});
data_saddle.push({
lat: 3.4297888889e+01,
lng: 1.3137600000e+02,
content:'Saddle = 248.399994 pos = 34.2979,131.3760 diff = 453.100006'
});
data_peak.push({
lat: 3.4305777778e+01,
lng: 1.3134377778e+02,
cert : true,
content:'Name = JA/YG-050(JA/YG-050) peak = 614.000000 pos = 34.3058,131.3438 diff = 356.200012'
});
data_saddle.push({
lat: 3.4304888889e+01,
lng: 1.3132900000e+02,
content:'Saddle = 257.799988 pos = 34.3049,131.3290 diff = 356.200012'
});
data_peak.push({
lat: 3.4233111112e+01,
lng: 1.3117900000e+02,
cert : true,
content:'Name = JA/YG-064(JA/YG-064) peak = 580.200012 pos = 34.2331,131.1790 diff = 312.600006'
});
data_saddle.push({
lat: 3.4255444445e+01,
lng: 1.3118488889e+02,
content:'Saddle = 267.600006 pos = 34.2554,131.1849 diff = 312.600006'
});
data_peak.push({
lat: 3.4208000000e+01,
lng: 1.3118711111e+02,
cert : false,
content:' Peak = 472.200012 pos = 34.2080,131.1871 diff = 184.800018'
});
data_saddle.push({
lat: 3.4224222223e+01,
lng: 1.3118877778e+02,
content:'Saddle = 287.399994 pos = 34.2242,131.1888 diff = 184.800018'
});
data_peak.push({
lat: 3.4283888889e+01,
lng: 1.3122100000e+02,
cert : true,
content:'Name = Hanaoyama(JA/YG-035) peak = 666.799988 pos = 34.2839,131.2210 diff = 388.099976'
});
data_saddle.push({
lat: 3.4330000000e+01,
lng: 1.3128933333e+02,
content:'Saddle = 278.700012 pos = 34.3300,131.2893 diff = 388.099976'
});
data_peak.push({
lat: 3.4295777778e+01,
lng: 1.3117755556e+02,
cert : true,
content:'Name = JA/YG-051(JA/YG-051) peak = 613.400024 pos = 34.2958,131.1776 diff = 324.000031'
});
data_saddle.push({
lat: 3.4284444445e+01,
lng: 1.3119500000e+02,
content:'Saddle = 289.399994 pos = 34.2844,131.1950 diff = 324.000031'
});
data_peak.push({
lat: 3.4269555556e+01,
lng: 1.3115088889e+02,
cert : false,
content:' Peak = 585.900024 pos = 34.2696,131.1509 diff = 159.100037'
});
data_saddle.push({
lat: 3.4288222223e+01,
lng: 1.3116555556e+02,
content:'Saddle = 426.799988 pos = 34.2882,131.1656 diff = 159.100037'
});
data_peak.push({
lat: 3.4336777778e+01,
lng: 1.3128388889e+02,
cert : true,
content:'Name = JA/YG-072(JA/YG-072) peak = 560.099976 pos = 34.3368,131.2839 diff = 198.599976'
});
data_saddle.push({
lat: 3.4331333334e+01,
lng: 1.3127500000e+02,
content:'Saddle = 361.500000 pos = 34.3313,131.2750 diff = 198.599976'
});
data_peak.push({
lat: 3.4316666667e+01,
lng: 1.3125266667e+02,
cert : true,
content:'Name = JA/YG-054(JA/YG-054) peak = 612.200012 pos = 34.3167,131.2527 diff = 243.000000'
});
data_saddle.push({
lat: 3.4297222223e+01,
lng: 1.3123888889e+02,
content:'Saddle = 369.200012 pos = 34.2972,131.2389 diff = 243.000000'
});
data_peak.push({
lat: 3.4326111111e+01,
lng: 1.3126200000e+02,
cert : false,
content:' Peak = 601.599976 pos = 34.3261,131.2620 diff = 158.099976'
});
data_saddle.push({
lat: 3.4322777778e+01,
lng: 1.3126166667e+02,
content:'Saddle = 443.500000 pos = 34.3228,131.2617 diff = 158.099976'
});
data_peak.push({
lat: 3.4290555556e+01,
lng: 1.3126900000e+02,
cert : false,
content:' Peak = 543.500000 pos = 34.2906,131.2690 diff = 181.500000'
});
data_saddle.push({
lat: 3.4303333334e+01,
lng: 1.3128033333e+02,
content:'Saddle = 362.000000 pos = 34.3033,131.2803 diff = 181.500000'
});
data_peak.push({
lat: 3.4170333334e+01,
lng: 1.3159377778e+02,
cert : true,
content:'Name = JA/YG-046(JA/YG-046) peak = 620.500000 pos = 34.1703,131.5938 diff = 371.799988'
});
data_saddle.push({
lat: 3.4210555556e+01,
lng: 1.3158622222e+02,
content:'Saddle = 248.699997 pos = 34.2106,131.5862 diff = 371.799988'
});
data_peak.push({
lat: 3.4203444445e+01,
lng: 1.3163300000e+02,
cert : true,
content:'Name = JA/YG-078(JA/YG-078) peak = 544.099976 pos = 34.2034,131.6330 diff = 276.199982'
});
data_saddle.push({
lat: 3.4179777778e+01,
lng: 1.3159522222e+02,
content:'Saddle = 267.899994 pos = 34.1798,131.5952 diff = 276.199982'
});
data_peak.push({
lat: 3.4196000000e+01,
lng: 1.3160600000e+02,
cert : true,
content:'Name = JA/YG-081(JA/YG-081) peak = 540.599976 pos = 34.1960,131.6060 diff = 238.599976'
});
data_saddle.push({
lat: 3.4194888889e+01,
lng: 1.3161822222e+02,
content:'Saddle = 302.000000 pos = 34.1949,131.6182 diff = 238.599976'
});
data_peak.push({
lat: 3.4168222223e+01,
lng: 1.3156000000e+02,
cert : true,
content:'Name = JA/YG-073(JA/YG-073) peak = 556.400024 pos = 34.1682,131.5600 diff = 257.700012'
});
data_saddle.push({
lat: 3.4152111112e+01,
lng: 1.3158577778e+02,
content:'Saddle = 298.700012 pos = 34.1521,131.5858 diff = 257.700012'
});
data_peak.push({
lat: 3.4219333334e+01,
lng: 1.3159966667e+02,
cert : true,
content:'Name = JA/YG-108(JA/YG-108) peak = 433.500000 pos = 34.2193,131.5997 diff = 180.899994'
});
data_saddle.push({
lat: 3.4244000000e+01,
lng: 1.3161077778e+02,
content:'Saddle = 252.600006 pos = 34.2440,131.6108 diff = 180.899994'
});
data_peak.push({
lat: 3.4236555556e+01,
lng: 1.3193833333e+02,
cert : true,
content:'Name = JA/YG-060(JA/YG-060) peak = 594.000000 pos = 34.2366,131.9383 diff = 337.399994'
});
data_saddle.push({
lat: 3.4213666667e+01,
lng: 1.3194277778e+02,
content:'Saddle = 256.600006 pos = 34.2137,131.9428 diff = 337.399994'
});
data_peak.push({
lat: 3.4257444445e+01,
lng: 1.3196588889e+02,
cert : false,
content:' Peak = 482.600006 pos = 34.2574,131.9659 diff = 185.200012'
});
data_saddle.push({
lat: 3.4229111112e+01,
lng: 1.3196088889e+02,
content:'Saddle = 297.399994 pos = 34.2291,131.9609 diff = 185.200012'
});
data_peak.push({
lat: 3.4229888889e+01,
lng: 1.3194911111e+02,
cert : true,
content:'Name = JA/YG-066(JA/YG-066) peak = 573.000000 pos = 34.2299,131.9491 diff = 185.799988'
});
data_saddle.push({
lat: 3.4234333334e+01,
lng: 1.3194533333e+02,
content:'Saddle = 387.200012 pos = 34.2343,131.9453 diff = 185.799988'
});
data_peak.push({
lat: 3.4219000000e+01,
lng: 1.3192055556e+02,
cert : false,
content:' Peak = 578.200012 pos = 34.2190,131.9206 diff = 175.700012'
});
data_saddle.push({
lat: 3.4226333334e+01,
lng: 1.3192833333e+02,
content:'Saddle = 402.500000 pos = 34.2263,131.9283 diff = 175.700012'
});
data_peak.push({
lat: 3.4542333334e+01,
lng: 1.3249122222e+02,
cert : true,
content:'Name = JA/HS-171(JA/HS-171) peak = 501.200012 pos = 34.5423,132.4912 diff = 244.300018'
});
data_saddle.push({
lat: 3.4552111111e+01,
lng: 1.3249333333e+02,
content:'Saddle = 256.899994 pos = 34.5521,132.4933 diff = 244.300018'
});
data_peak.push({
lat: 3.4551888889e+01,
lng: 1.3185533333e+02,
cert : false,
content:' Peak = 415.200012 pos = 34.5519,131.8553 diff = 157.900024'
});
data_saddle.push({
lat: 3.4553222223e+01,
lng: 1.3185211111e+02,
content:'Saddle = 257.299988 pos = 34.5532,131.8521 diff = 157.900024'
});
data_peak.push({
lat: 3.4287111111e+01,
lng: 1.3224355556e+02,
cert : true,
content:'Name = JA/HS-139(JA/HS-139) peak = 595.799988 pos = 34.2871,132.2436 diff = 337.899994'
});
data_saddle.push({
lat: 3.4300666667e+01,
lng: 1.3223355556e+02,
content:'Saddle = 257.899994 pos = 34.3007,132.2336 diff = 337.899994'
});
data_peak.push({
lat: 3.4411000000e+01,
lng: 1.3153288889e+02,
cert : true,
content:'Name = JA/YG-063(JA/YG-063) peak = 580.000000 pos = 34.4110,131.5329 diff = 322.000000'
});
data_saddle.push({
lat: 3.4440000000e+01,
lng: 1.3156777778e+02,
content:'Saddle = 258.000000 pos = 34.4400,131.5678 diff = 322.000000'
});
data_peak.push({
lat: 3.4399444445e+01,
lng: 1.3144488889e+02,
cert : true,
content:'Name = JA/YG-104(JA/YG-104) peak = 444.600006 pos = 34.3994,131.4449 diff = 186.600006'
});
data_saddle.push({
lat: 3.4405777778e+01,
lng: 1.3144877778e+02,
content:'Saddle = 258.000000 pos = 34.4058,131.4488 diff = 186.600006'
});
data_peak.push({
lat: 3.4371555556e+01,
lng: 1.3155455556e+02,
cert : false,
content:' Peak = 435.299988 pos = 34.3716,131.5546 diff = 177.000000'
});
data_saddle.push({
lat: 3.4388888889e+01,
lng: 1.3154844444e+02,
content:'Saddle = 258.299988 pos = 34.3889,131.5484 diff = 177.000000'
});
data_peak.push({
lat: 3.4379000000e+01,
lng: 1.3147888889e+02,
cert : true,
content:'Name = JA/YG-101(JA/YG-101) peak = 452.700012 pos = 34.3790,131.4789 diff = 188.400024'
});
data_saddle.push({
lat: 3.4410000000e+01,
lng: 1.3148122222e+02,
content:'Saddle = 264.299988 pos = 34.4100,131.4812 diff = 188.400024'
});
data_peak.push({
lat: 3.4403333334e+01,
lng: 1.3145855556e+02,
cert : true,
content:'Name = JA/YG-075(JA/YG-075) peak = 550.599976 pos = 34.4033,131.4586 diff = 231.599976'
});
data_saddle.push({
lat: 3.4414888889e+01,
lng: 1.3148188889e+02,
content:'Saddle = 319.000000 pos = 34.4149,131.4819 diff = 231.599976'
});
data_peak.push({
lat: 3.4103333334e+01,
lng: 1.3201688889e+02,
cert : true,
content:'Name = JA/YG-110(JA/YG-110) peak = 430.899994 pos = 34.1033,132.0169 diff = 172.699982'
});
data_saddle.push({
lat: 3.4108888889e+01,
lng: 1.3200477778e+02,
content:'Saddle = 258.200012 pos = 34.1089,132.0048 diff = 172.699982'
});
data_peak.push({
lat: 3.4497000000e+01,
lng: 1.3179877778e+02,
cert : true,
content:'Name = JA/SN-103(JA/SN-103) peak = 464.200012 pos = 34.4970,131.7988 diff = 205.900024'
});
data_saddle.push({
lat: 3.4507666667e+01,
lng: 1.3176766667e+02,
content:'Saddle = 258.299988 pos = 34.5077,131.7677 diff = 205.900024'
});
data_peak.push({
lat: 3.4952222222e+01,
lng: 1.3235866667e+02,
cert : true,
content:'Name = JA/SN-111(JA/SN-111) peak = 431.500000 pos = 34.9522,132.3587 diff = 169.200012'
});
data_saddle.push({
lat: 3.4949888889e+01,
lng: 1.3236666667e+02,
content:'Saddle = 262.299988 pos = 34.9499,132.3667 diff = 169.200012'
});
data_peak.push({
lat: 3.4878222222e+01,
lng: 1.3264044444e+02,
cert : true,
content:'Name = JA/SN-095(JA/SN-095) peak = 496.899994 pos = 34.8782,132.6404 diff = 230.100006'
});
data_saddle.push({
lat: 3.4888444445e+01,
lng: 1.3261811111e+02,
content:'Saddle = 266.799988 pos = 34.8884,132.6181 diff = 230.100006'
});
data_peak.push({
lat: 3.4227333334e+01,
lng: 1.3168388889e+02,
cert : false,
content:' Peak = 419.100006 pos = 34.2273,131.6839 diff = 151.700012'
});
data_saddle.push({
lat: 3.4226666667e+01,
lng: 1.3169411111e+02,
content:'Saddle = 267.399994 pos = 34.2267,131.6941 diff = 151.700012'
});
data_peak.push({
lat: 3.4521333334e+01,
lng: 1.3257544444e+02,
cert : true,
content:'Name = Shirakiyama(JA/HS-052) peak = 888.200012 pos = 34.5213,132.5754 diff = 618.700012'
});
data_saddle.push({
lat: 3.4593000000e+01,
lng: 1.3258555556e+02,
content:'Saddle = 269.500000 pos = 34.5930,132.5856 diff = 618.700012'
});
data_peak.push({
lat: 3.4599111111e+01,
lng: 1.3266577778e+02,
cert : false,
content:' Peak = 620.099976 pos = 34.5991,132.6658 diff = 252.099976'
});
data_saddle.push({
lat: 3.4564666667e+01,
lng: 1.3258677778e+02,
content:'Saddle = 368.000000 pos = 34.5647,132.5868 diff = 252.099976'
});
data_peak.push({
lat: 3.4583333334e+01,
lng: 1.3259277778e+02,
cert : true,
content:'Name = JA/HS-149(JA/HS-149) peak = 563.799988 pos = 34.5833,132.5928 diff = 167.699982'
});
data_saddle.push({
lat: 3.4584777778e+01,
lng: 1.3260211111e+02,
content:'Saddle = 396.100006 pos = 34.5848,132.6021 diff = 167.699982'
});
data_peak.push({
lat: 3.4566555556e+01,
lng: 1.3263411111e+02,
cert : true,
content:'Name = JA/HS-131(JA/HS-131) peak = 628.299988 pos = 34.5666,132.6341 diff = 187.599976'
});
data_saddle.push({
lat: 3.4559000000e+01,
lng: 1.3262488889e+02,
content:'Saddle = 440.700012 pos = 34.5590,132.6249 diff = 187.599976'
});
data_peak.push({
lat: 3.4837777778e+01,
lng: 1.3208166667e+02,
cert : true,
content:'Name = JA/SN-092(JA/SN-092) peak = 513.500000 pos = 34.8378,132.0817 diff = 241.000000'
});
data_saddle.push({
lat: 3.4837333333e+01,
lng: 1.3210722222e+02,
content:'Saddle = 272.500000 pos = 34.8373,132.1072 diff = 241.000000'
});
data_peak.push({
lat: 3.4517444445e+01,
lng: 1.3173322222e+02,
cert : true,
content:'Name = JA/SN-074(JA/SN-074) peak = 572.599976 pos = 34.5174,131.7332 diff = 298.499969'
});
data_saddle.push({
lat: 3.4524666667e+01,
lng: 1.3169611111e+02,
content:'Saddle = 274.100006 pos = 34.5247,131.6961 diff = 298.499969'
});
data_peak.push({
lat: 3.4536888889e+01,
lng: 1.3170100000e+02,
cert : true,
content:'Name = JA/YG-079(JA/YG-079) peak = 541.200012 pos = 34.5369,131.7010 diff = 242.900024'
});
data_saddle.push({
lat: 3.4556000000e+01,
lng: 1.3170411111e+02,
content:'Saddle = 298.299988 pos = 34.5560,131.7041 diff = 242.900024'
});
data_peak.push({
lat: 3.4565333334e+01,
lng: 1.3170377778e+02,
cert : true,
content:'Name = JA/SN-097(JA/SN-097) peak = 482.700012 pos = 34.5653,131.7038 diff = 165.600006'
});
data_saddle.push({
lat: 3.4563222222e+01,
lng: 1.3170800000e+02,
content:'Saddle = 317.100006 pos = 34.5632,131.7080 diff = 165.600006'
});
data_peak.push({
lat: 3.4529000000e+01,
lng: 1.3175788889e+02,
cert : true,
content:'Name = JA/SN-079(JA/SN-079) peak = 561.099976 pos = 34.5290,131.7579 diff = 212.999969'
});
data_saddle.push({
lat: 3.4529555556e+01,
lng: 1.3174822222e+02,
content:'Saddle = 348.100006 pos = 34.5296,131.7482 diff = 212.999969'
});
data_peak.push({
lat: 3.4563222222e+01,
lng: 1.3173233333e+02,
cert : true,
content:'Name = JA/SN-080(JA/SN-080) peak = 554.500000 pos = 34.5632,131.7323 diff = 200.799988'
});
data_saddle.push({
lat: 3.4544222223e+01,
lng: 1.3173500000e+02,
content:'Saddle = 353.700012 pos = 34.5442,131.7350 diff = 200.799988'
});
data_peak.push({
lat: 3.4794333334e+01,
lng: 1.3282044444e+02,
cert : true,
content:'Name = JA/HS-174(JA/HS-174) peak = 490.500000 pos = 34.7943,132.8204 diff = 215.700012'
});
data_saddle.push({
lat: 3.4743222222e+01,
lng: 1.3269966667e+02,
content:'Saddle = 274.799988 pos = 34.7432,132.6997 diff = 215.700012'
});
data_peak.push({
lat: 3.4193333334e+01,
lng: 1.3144933333e+02,
cert : false,
content:' Peak = 435.100006 pos = 34.1933,131.4493 diff = 159.200012'
});
data_saddle.push({
lat: 3.4204777778e+01,
lng: 1.3145566667e+02,
content:'Saddle = 275.899994 pos = 34.2048,131.4557 diff = 159.200012'
});
data_peak.push({
lat: 3.4873888889e+01,
lng: 1.3228766667e+02,
cert : true,
content:'Name = JA/SN-104(JA/SN-104) peak = 461.399994 pos = 34.8739,132.2877 diff = 183.899994'
});
data_saddle.push({
lat: 3.4867222222e+01,
lng: 1.3229188889e+02,
content:'Saddle = 277.500000 pos = 34.8672,132.2919 diff = 183.899994'
});
data_peak.push({
lat: 3.4324888889e+01,
lng: 1.3149400000e+02,
cert : false,
content:' Peak = 448.899994 pos = 34.3249,131.4940 diff = 165.699982'
});
data_saddle.push({
lat: 3.4319111111e+01,
lng: 1.3148133333e+02,
content:'Saddle = 283.200012 pos = 34.3191,131.4813 diff = 165.699982'
});
data_peak.push({
lat: 3.4101555556e+01,
lng: 1.3175833333e+02,
cert : false,
content:' Peak = 502.799988 pos = 34.1016,131.7583 diff = 219.099976'
});
data_saddle.push({
lat: 3.4103222223e+01,
lng: 1.3175066667e+02,
content:'Saddle = 283.700012 pos = 34.1032,131.7507 diff = 219.099976'
});
data_peak.push({
lat: 3.4845444445e+01,
lng: 1.3266544444e+02,
cert : false,
content:' Peak = 440.899994 pos = 34.8454,132.6654 diff = 153.399994'
});
data_saddle.push({
lat: 3.4845444445e+01,
lng: 1.3266100000e+02,
content:'Saddle = 287.500000 pos = 34.8454,132.6610 diff = 153.399994'
});
data_peak.push({
lat: 3.4136222223e+01,
lng: 1.3202244444e+02,
cert : true,
content:'Name = JA/YG-026(JA/YG-026) peak = 707.400024 pos = 34.1362,132.0224 diff = 419.500031'
});
data_saddle.push({
lat: 3.4136777778e+01,
lng: 1.3197933333e+02,
content:'Saddle = 287.899994 pos = 34.1368,131.9793 diff = 419.500031'
});
data_peak.push({
lat: 3.4119888889e+01,
lng: 1.3206766667e+02,
cert : true,
content:'Name = JA/YG-067(JA/YG-067) peak = 575.200012 pos = 34.1199,132.0677 diff = 248.200012'
});
data_saddle.push({
lat: 3.4132111112e+01,
lng: 1.3205666667e+02,
content:'Saddle = 327.000000 pos = 34.1321,132.0567 diff = 248.200012'
});
data_peak.push({
lat: 3.4201444445e+01,
lng: 1.3201811111e+02,
cert : false,
content:' Peak = 494.799988 pos = 34.2014,132.0181 diff = 153.500000'
});
data_saddle.push({
lat: 3.4190000000e+01,
lng: 1.3201611111e+02,
content:'Saddle = 341.299988 pos = 34.1900,132.0161 diff = 153.500000'
});
data_peak.push({
lat: 3.4916444445e+01,
lng: 1.3230655556e+02,
cert : true,
content:'Name = JA/SN-105(JA/SN-105) peak = 453.100006 pos = 34.9164,132.3066 diff = 165.000000'
});
data_saddle.push({
lat: 3.4910444445e+01,
lng: 1.3231111111e+02,
content:'Saddle = 288.100006 pos = 34.9104,132.3111 diff = 165.000000'
});
data_peak.push({
lat: 3.4587666667e+01,
lng: 1.3188577778e+02,
cert : true,
content:'Name = JA/SN-069(JA/SN-069) peak = 584.799988 pos = 34.5877,131.8858 diff = 287.399994'
});
data_saddle.push({
lat: 3.4569777778e+01,
lng: 1.3187455556e+02,
content:'Saddle = 297.399994 pos = 34.5698,131.8746 diff = 287.399994'
});
data_peak.push({
lat: 3.4563000000e+01,
lng: 1.3185555556e+02,
cert : false,
content:' Peak = 466.700012 pos = 34.5630,131.8556 diff = 150.100006'
});
data_saddle.push({
lat: 3.4574111111e+01,
lng: 1.3186277778e+02,
content:'Saddle = 316.600006 pos = 34.5741,131.8628 diff = 150.100006'
});
data_peak.push({
lat: 3.4797222222e+01,
lng: 1.3272722222e+02,
cert : true,
content:'Name = JA/HS-177(JA/HS-177) peak = 486.100006 pos = 34.7972,132.7272 diff = 187.300018'
});
data_saddle.push({
lat: 3.4784111111e+01,
lng: 1.3271344444e+02,
content:'Saddle = 298.799988 pos = 34.7841,132.7134 diff = 187.300018'
});
data_peak.push({
lat: 3.4282444445e+01,
lng: 1.3220722222e+02,
cert : false,
content:' Peak = 647.700012 pos = 34.2824,132.2072 diff = 344.800018'
});
data_saddle.push({
lat: 3.4310888889e+01,
lng: 1.3222022222e+02,
content:'Saddle = 302.899994 pos = 34.3109,132.2202 diff = 344.800018'
});
data_peak.push({
lat: 3.4309666667e+01,
lng: 1.3220888889e+02,
cert : true,
content:'Name = JA/HS-154(JA/HS-154) peak = 554.599976 pos = 34.3097,132.2089 diff = 212.099976'
});
data_saddle.push({
lat: 3.4300111111e+01,
lng: 1.3220655556e+02,
content:'Saddle = 342.500000 pos = 34.3001,132.2066 diff = 212.099976'
});
data_peak.push({
lat: 3.4264000000e+01,
lng: 1.3216544444e+02,
cert : false,
content:' Peak = 607.599976 pos = 34.2640,132.1654 diff = 151.299988'
});
data_saddle.push({
lat: 3.4284444445e+01,
lng: 1.3219811111e+02,
content:'Saddle = 456.299988 pos = 34.2844,132.1981 diff = 151.299988'
});
data_peak.push({
lat: 3.4317111111e+01,
lng: 1.3214800000e+02,
cert : true,
content:'Name = Mikuradake(JA/HS-106) peak = 701.400024 pos = 34.3171,132.1480 diff = 396.400024'
});
data_saddle.push({
lat: 3.4364666667e+01,
lng: 1.3219266667e+02,
content:'Saddle = 305.000000 pos = 34.3647,132.1927 diff = 396.400024'
});
data_peak.push({
lat: 3.4331111111e+01,
lng: 1.3220433333e+02,
cert : false,
content:' Peak = 470.799988 pos = 34.3311,132.2043 diff = 162.899994'
});
data_saddle.push({
lat: 3.4340000000e+01,
lng: 1.3220522222e+02,
content:'Saddle = 307.899994 pos = 34.3400,132.2052 diff = 162.899994'
});
data_peak.push({
lat: 3.4348333334e+01,
lng: 1.3218600000e+02,
cert : true,
content:'Name = JA/HS-113(JA/HS-113) peak = 682.900024 pos = 34.3483,132.1860 diff = 240.700012'
});
data_saddle.push({
lat: 3.4329222223e+01,
lng: 1.3216088889e+02,
content:'Saddle = 442.200012 pos = 34.3292,132.1609 diff = 240.700012'
});
data_peak.push({
lat: 3.5021888889e+01,
lng: 1.3257100000e+02,
cert : true,
content:'Name = JA/SN-086(JA/SN-086) peak = 526.400024 pos = 35.0219,132.5710 diff = 219.000031'
});
data_saddle.push({
lat: 3.5018888889e+01,
lng: 1.3257933333e+02,
content:'Saddle = 307.399994 pos = 35.0189,132.5793 diff = 219.000031'
});
data_peak.push({
lat: 3.4821777778e+01,
lng: 1.3200688889e+02,
cert : true,
content:'Name = JA/SN-064(JA/SN-064) peak = 598.500000 pos = 34.8218,132.0069 diff = 290.299988'
});
data_saddle.push({
lat: 3.4811111111e+01,
lng: 1.3204588889e+02,
content:'Saddle = 308.200012 pos = 34.8111,132.0459 diff = 290.299988'
});
data_peak.push({
lat: 3.4948555556e+01,
lng: 1.3262711111e+02,
cert : false,
content:' Peak = 491.799988 pos = 34.9486,132.6271 diff = 179.500000'
});
data_saddle.push({
lat: 3.4960555556e+01,
lng: 1.3259266667e+02,
content:'Saddle = 312.299988 pos = 34.9606,132.5927 diff = 179.500000'
});
data_peak.push({
lat: 3.4356000000e+01,
lng: 1.3160477778e+02,
cert : true,
content:'Name = JA/YG-024(JA/YG-024) peak = 714.599976 pos = 34.3560,131.6048 diff = 396.399963'
});
data_saddle.push({
lat: 3.4371111111e+01,
lng: 1.3162111111e+02,
content:'Saddle = 318.200012 pos = 34.3711,131.6211 diff = 396.399963'
});
data_peak.push({
lat: 3.4317111111e+01,
lng: 1.3158155556e+02,
cert : true,
content:'Name = JA/YG-092(JA/YG-092) peak = 513.599976 pos = 34.3171,131.5816 diff = 191.399963'
});
data_saddle.push({
lat: 3.4322555556e+01,
lng: 1.3158077778e+02,
content:'Saddle = 322.200012 pos = 34.3226,131.5808 diff = 191.399963'
});
data_peak.push({
lat: 3.4332777778e+01,
lng: 1.3158522222e+02,
cert : false,
content:' Peak = 580.299988 pos = 34.3328,131.5852 diff = 158.599976'
});
data_saddle.push({
lat: 3.4341000000e+01,
lng: 1.3159322222e+02,
content:'Saddle = 421.700012 pos = 34.3410,131.5932 diff = 158.599976'
});
data_peak.push({
lat: 3.4367555556e+01,
lng: 1.3190344444e+02,
cert : false,
content:' Peak = 488.500000 pos = 34.3676,131.9034 diff = 161.700012'
});
data_saddle.push({
lat: 3.4379444445e+01,
lng: 1.3191266667e+02,
content:'Saddle = 326.799988 pos = 34.3794,131.9127 diff = 161.700012'
});
data_peak.push({
lat: 3.4087111112e+01,
lng: 1.3196955556e+02,
cert : true,
content:'Name = Eboshidake(JA/YG-029) peak = 695.900024 pos = 34.0871,131.9696 diff = 368.600037'
});
data_saddle.push({
lat: 3.4106333334e+01,
lng: 1.3191322222e+02,
content:'Saddle = 327.299988 pos = 34.1063,131.9132 diff = 368.600037'
});
data_peak.push({
lat: 3.4199111112e+01,
lng: 1.3195877778e+02,
cert : true,
content:'Name = JA/YG-069(JA/YG-069) peak = 564.099976 pos = 34.1991,131.9588 diff = 221.499969'
});
data_saddle.push({
lat: 3.4195888889e+01,
lng: 1.3192922222e+02,
content:'Saddle = 342.600006 pos = 34.1959,131.9292 diff = 221.499969'
});
data_peak.push({
lat: 3.4581555556e+01,
lng: 1.3162411111e+02,
cert : true,
content:'Name = JA/YG-085(JA/YG-085) peak = 526.099976 pos = 34.5816,131.6241 diff = 198.099976'
});
data_saddle.push({
lat: 3.4583000000e+01,
lng: 1.3160577778e+02,
content:'Saddle = 328.000000 pos = 34.5830,131.6058 diff = 198.099976'
});
data_peak.push({
lat: 3.4917555556e+01,
lng: 1.3250177778e+02,
cert : true,
content:'Name = Kanzan(JA/SN-025) peak = 862.400024 pos = 34.9176,132.5018 diff = 534.200012'
});
data_saddle.push({
lat: 3.4889555556e+01,
lng: 1.3253433333e+02,
content:'Saddle = 328.200012 pos = 34.8896,132.5343 diff = 534.200012'
});
data_peak.push({
lat: 3.4996444445e+01,
lng: 1.3255111111e+02,
cert : true,
content:'Name = JA/SN-058(JA/SN-058) peak = 631.599976 pos = 34.9964,132.5511 diff = 283.799988'
});
data_saddle.push({
lat: 3.4971222222e+01,
lng: 1.3256288889e+02,
content:'Saddle = 347.799988 pos = 34.9712,132.5629 diff = 283.799988'
});
data_peak.push({
lat: 3.4983444445e+01,
lng: 1.3257188889e+02,
cert : true,
content:'Name = JA/SN-078(JA/SN-078) peak = 563.500000 pos = 34.9834,132.5719 diff = 195.899994'
});
data_saddle.push({
lat: 3.4984555556e+01,
lng: 1.3256477778e+02,
content:'Saddle = 367.600006 pos = 34.9846,132.5648 diff = 195.899994'
});
data_peak.push({
lat: 3.5015000000e+01,
lng: 1.3260133333e+02,
cert : true,
content:'Name = JA/SN-060(JA/SN-060) peak = 627.299988 pos = 35.0150,132.6013 diff = 258.299988'
});
data_saddle.push({
lat: 3.4998888889e+01,
lng: 1.3256700000e+02,
content:'Saddle = 369.000000 pos = 34.9989,132.5670 diff = 258.299988'
});
data_peak.push({
lat: 3.4919444445e+01,
lng: 1.3258288889e+02,
cert : true,
content:'Name = JA/SN-057(JA/SN-057) peak = 643.900024 pos = 34.9194,132.5829 diff = 285.800018'
});
data_saddle.push({
lat: 3.4926777778e+01,
lng: 1.3255333333e+02,
content:'Saddle = 358.100006 pos = 34.9268,132.5533 diff = 285.800018'
});
data_peak.push({
lat: 3.4932222222e+01,
lng: 1.3256000000e+02,
cert : false,
content:' Peak = 540.500000 pos = 34.9322,132.5600 diff = 152.200012'
});
data_saddle.push({
lat: 3.4923555556e+01,
lng: 1.3255855556e+02,
content:'Saddle = 388.299988 pos = 34.9236,132.5586 diff = 152.200012'
});
data_peak.push({
lat: 3.4966222222e+01,
lng: 1.3257733333e+02,
cert : true,
content:'Name = Karataniyama(JA/SN-056) peak = 654.700012 pos = 34.9662,132.5773 diff = 287.200012'
});
data_saddle.push({
lat: 3.4953333333e+01,
lng: 1.3255011111e+02,
content:'Saddle = 367.500000 pos = 34.9533,132.5501 diff = 287.200012'
});
data_peak.push({
lat: 3.4956222222e+01,
lng: 1.3252000000e+02,
cert : true,
content:'Name = JA/SN-044(JA/SN-044) peak = 714.000000 pos = 34.9562,132.5200 diff = 216.100006'
});
data_saddle.push({
lat: 3.4937777778e+01,
lng: 1.3250744444e+02,
content:'Saddle = 497.899994 pos = 34.9378,132.5074 diff = 216.100006'
});
data_peak.push({
lat: 3.4259777778e+01,
lng: 1.3140922222e+02,
cert : true,
content:'Name = JA/YG-014(JA/YG-014) peak = 788.599976 pos = 34.2598,131.4092 diff = 459.599976'
});
data_saddle.push({
lat: 3.4325777778e+01,
lng: 1.3167988889e+02,
content:'Saddle = 329.000000 pos = 34.3258,131.6799 diff = 459.599976'
});
data_peak.push({
lat: 3.4179888889e+01,
lng: 1.3138477778e+02,
cert : false,
content:' Peak = 546.900024 pos = 34.1799,131.3848 diff = 189.100037'
});
data_saddle.push({
lat: 3.4194555556e+01,
lng: 1.3140377778e+02,
content:'Saddle = 357.799988 pos = 34.1946,131.4038 diff = 189.100037'
});
data_peak.push({
lat: 3.4328111111e+01,
lng: 1.3153055556e+02,
cert : true,
content:'Name = JA/YG-057(JA/YG-057) peak = 602.099976 pos = 34.3281,131.5306 diff = 242.999969'
});
data_saddle.push({
lat: 3.4309222223e+01,
lng: 1.3152166667e+02,
content:'Saddle = 359.100006 pos = 34.3092,131.5217 diff = 242.999969'
});
data_peak.push({
lat: 3.4348666667e+01,
lng: 1.3152622222e+02,
cert : true,
content:'Name = JA/YG-058(JA/YG-058) peak = 600.200012 pos = 34.3487,131.5262 diff = 182.300018'
});
data_saddle.push({
lat: 3.4333333334e+01,
lng: 1.3152477778e+02,
content:'Saddle = 417.899994 pos = 34.3333,131.5248 diff = 182.300018'
});
data_peak.push({
lat: 3.4310555556e+01,
lng: 1.3146511111e+02,
cert : true,
content:'Name = JA/YG-074(JA/YG-074) peak = 554.900024 pos = 34.3106,131.4651 diff = 186.100037'
});
data_saddle.push({
lat: 3.4288555556e+01,
lng: 1.3141733333e+02,
content:'Saddle = 368.799988 pos = 34.2886,131.4173 diff = 186.100037'
});
data_peak.push({
lat: 3.4287222223e+01,
lng: 1.3159744444e+02,
cert : true,
content:'Name = JA/YG-015(JA/YG-015) peak = 762.000000 pos = 34.2872,131.5974 diff = 391.200012'
});
data_saddle.push({
lat: 3.4254222223e+01,
lng: 1.3152644444e+02,
content:'Saddle = 370.799988 pos = 34.2542,131.5264 diff = 391.200012'
});
data_peak.push({
lat: 3.4238333334e+01,
lng: 1.3152611111e+02,
cert : false,
content:' Peak = 541.700012 pos = 34.2383,131.5261 diff = 164.400024'
});
data_saddle.push({
lat: 3.4248777778e+01,
lng: 1.3153222222e+02,
content:'Saddle = 377.299988 pos = 34.2488,131.5322 diff = 164.400024'
});
data_peak.push({
lat: 3.4256111112e+01,
lng: 1.3156833333e+02,
cert : true,
content:'Name = JA/YG-059(JA/YG-059) peak = 592.099976 pos = 34.2561,131.5683 diff = 214.599976'
});
data_saddle.push({
lat: 3.4261888889e+01,
lng: 1.3157855556e+02,
content:'Saddle = 377.500000 pos = 34.2619,131.5786 diff = 214.599976'
});
data_peak.push({
lat: 3.4262555556e+01,
lng: 1.3155011111e+02,
cert : true,
content:'Name = JA/YG-062(JA/YG-062) peak = 588.700012 pos = 34.2626,131.5501 diff = 171.500000'
});
data_saddle.push({
lat: 3.4241888889e+01,
lng: 1.3155311111e+02,
content:'Saddle = 417.200012 pos = 34.2419,131.5531 diff = 171.500000'
});
data_peak.push({
lat: 3.4310111111e+01,
lng: 1.3165877778e+02,
cert : false,
content:' Peak = 732.400024 pos = 34.3101,131.6588 diff = 240.100037'
});
data_saddle.push({
lat: 3.4306111111e+01,
lng: 1.3161944444e+02,
content:'Saddle = 492.299988 pos = 34.3061,131.6194 diff = 240.100037'
});
data_peak.push({
lat: 3.4314888889e+01,
lng: 1.3164688889e+02,
cert : false,
content:' Peak = 728.000000 pos = 34.3149,131.6469 diff = 153.299988'
});
data_saddle.push({
lat: 3.4312555556e+01,
lng: 1.3165411111e+02,
content:'Saddle = 574.700012 pos = 34.3126,131.6541 diff = 153.299988'
});
data_peak.push({
lat: 3.4278555556e+01,
lng: 1.3161311111e+02,
cert : false,
content:' Peak = 691.200012 pos = 34.2786,131.6131 diff = 163.799988'
});
data_saddle.push({
lat: 3.4287555556e+01,
lng: 1.3160944444e+02,
content:'Saddle = 527.400024 pos = 34.2876,131.6094 diff = 163.799988'
});
data_peak.push({
lat: 3.4254888889e+01,
lng: 1.3150755556e+02,
cert : true,
content:'Name = JA/YG-032(JA/YG-032) peak = 687.700012 pos = 34.2549,131.5076 diff = 299.300018'
});
data_saddle.push({
lat: 3.4242777778e+01,
lng: 1.3149366667e+02,
content:'Saddle = 388.399994 pos = 34.2428,131.4937 diff = 299.300018'
});
data_peak.push({
lat: 3.4301444445e+01,
lng: 1.3155544444e+02,
cert : true,
content:'Name = JA/YG-047(JA/YG-047) peak = 621.099976 pos = 34.3014,131.5554 diff = 184.099976'
});
data_saddle.push({
lat: 3.4298000000e+01,
lng: 1.3153211111e+02,
content:'Saddle = 437.000000 pos = 34.2980,131.5321 diff = 184.099976'
});
data_peak.push({
lat: 3.4246777778e+01,
lng: 1.3145033333e+02,
cert : true,
content:'Name = JA/YG-018(JA/YG-018) peak = 745.299988 pos = 34.2468,131.4503 diff = 309.099976'
});
data_saddle.push({
lat: 3.4239333334e+01,
lng: 1.3140211111e+02,
content:'Saddle = 436.200012 pos = 34.2393,131.4021 diff = 309.099976'
});
data_peak.push({
lat: 3.4230888889e+01,
lng: 1.3138566667e+02,
cert : true,
content:'Name = JA/YG-038(JA/YG-038) peak = 652.799988 pos = 34.2309,131.3857 diff = 204.299988'
});
data_saddle.push({
lat: 3.4215555556e+01,
lng: 1.3140011111e+02,
content:'Saddle = 448.500000 pos = 34.2156,131.4001 diff = 204.299988'
});
data_peak.push({
lat: 3.4210888889e+01,
lng: 1.3140933333e+02,
cert : false,
content:' Peak = 741.500000 pos = 34.2109,131.4093 diff = 204.500000'
});
data_saddle.push({
lat: 3.4219111112e+01,
lng: 1.3143044444e+02,
content:'Saddle = 537.000000 pos = 34.2191,131.4304 diff = 204.500000'
});
data_peak.push({
lat: 3.4222000000e+01,
lng: 1.3144277778e+02,
cert : true,
content:'Name = Higashihōbenzan(JA/YG-020) peak = 733.700012 pos = 34.2220,131.4428 diff = 187.700012'
});
data_saddle.push({
lat: 3.4236444445e+01,
lng: 1.3145522222e+02,
content:'Saddle = 546.000000 pos = 34.2364,131.4552 diff = 187.700012'
});
data_peak.push({
lat: 3.4359555556e+01,
lng: 1.3156466667e+02,
cert : false,
content:' Peak = 481.600006 pos = 34.3596,131.5647 diff = 151.500000'
});
data_saddle.push({
lat: 3.4380000000e+01,
lng: 1.3158755556e+02,
content:'Saddle = 330.100006 pos = 34.3800,131.5876 diff = 151.500000'
});
data_peak.push({
lat: 3.4342666667e+01,
lng: 1.3223777778e+02,
cert : true,
content:'Name = JA/HS-108(JA/HS-108) peak = 697.599976 pos = 34.3427,132.2378 diff = 359.499969'
});
data_saddle.push({
lat: 3.4355666667e+01,
lng: 1.3225444444e+02,
content:'Saddle = 338.100006 pos = 34.3557,132.2544 diff = 359.499969'
});
data_peak.push({
lat: 3.4659333334e+01,
lng: 1.3256277778e+02,
cert : false,
content:' Peak = 540.700012 pos = 34.6593,132.5628 diff = 202.000000'
});
data_saddle.push({
lat: 3.4647666667e+01,
lng: 1.3256022222e+02,
content:'Saddle = 338.700012 pos = 34.6477,132.5602 diff = 202.000000'
});
data_peak.push({
lat: 3.4505444445e+01,
lng: 1.3153011111e+02,
cert : true,
content:'Name = JA/YG-068(JA/YG-068) peak = 563.000000 pos = 34.5054,131.5301 diff = 220.500000'
});
data_saddle.push({
lat: 3.4510444445e+01,
lng: 1.3153477778e+02,
content:'Saddle = 342.500000 pos = 34.5104,131.5348 diff = 220.500000'
});
data_peak.push({
lat: 3.4878222222e+01,
lng: 1.3247322222e+02,
cert : false,
content:' Peak = 523.299988 pos = 34.8782,132.4732 diff = 176.599976'
});
data_saddle.push({
lat: 3.4871444445e+01,
lng: 1.3247044444e+02,
content:'Saddle = 346.700012 pos = 34.8714,132.4704 diff = 176.599976'
});
data_peak.push({
lat: 3.4622555556e+01,
lng: 1.3188977778e+02,
cert : true,
content:'Name = JA/SN-083(JA/SN-083) peak = 542.200012 pos = 34.6226,131.8898 diff = 195.000000'
});
data_saddle.push({
lat: 3.4624000000e+01,
lng: 1.3190455556e+02,
content:'Saddle = 347.200012 pos = 34.6240,131.9046 diff = 195.000000'
});
data_peak.push({
lat: 3.4145333334e+01,
lng: 1.3186100000e+02,
cert : false,
content:' Peak = 612.700012 pos = 34.1453,131.8610 diff = 265.400024'
});
data_saddle.push({
lat: 3.4118000000e+01,
lng: 1.3182755556e+02,
content:'Saddle = 347.299988 pos = 34.1180,131.8276 diff = 265.400024'
});
data_peak.push({
lat: 3.4088444445e+01,
lng: 1.3185277778e+02,
cert : true,
content:'Name = JA/YG-071(JA/YG-071) peak = 560.700012 pos = 34.0884,131.8528 diff = 208.500000'
});
data_saddle.push({
lat: 3.4120444445e+01,
lng: 1.3185111111e+02,
content:'Saddle = 352.200012 pos = 34.1204,131.8511 diff = 208.500000'
});
data_peak.push({
lat: 3.4700222222e+01,
lng: 1.3268244444e+02,
cert : true,
content:'Name = JA/HS-155(JA/HS-155) peak = 555.200012 pos = 34.7002,132.6824 diff = 207.700012'
});
data_saddle.push({
lat: 3.4706888889e+01,
lng: 1.3265800000e+02,
content:'Saddle = 347.500000 pos = 34.7069,132.6580 diff = 207.700012'
});
data_peak.push({
lat: 3.4514222223e+01,
lng: 1.3154666667e+02,
cert : true,
content:'Name = JA/YG-065(JA/YG-065) peak = 571.099976 pos = 34.5142,131.5467 diff = 222.899963'
});
data_saddle.push({
lat: 3.4522555556e+01,
lng: 1.3154333333e+02,
content:'Saddle = 348.200012 pos = 34.5226,131.5433 diff = 222.899963'
});
data_peak.push({
lat: 3.4555333334e+01,
lng: 1.3246277778e+02,
cert : false,
content:' Peak = 503.200012 pos = 34.5553,132.4628 diff = 154.900024'
});
data_saddle.push({
lat: 3.4561555556e+01,
lng: 1.3246500000e+02,
content:'Saddle = 348.299988 pos = 34.5616,132.4650 diff = 154.900024'
});
data_peak.push({
lat: 3.4866000000e+01,
lng: 1.3251800000e+02,
cert : false,
content:' Peak = 530.299988 pos = 34.8660,132.5180 diff = 173.000000'
});
data_saddle.push({
lat: 3.4858888889e+01,
lng: 1.3251755556e+02,
content:'Saddle = 357.299988 pos = 34.8589,132.5176 diff = 173.000000'
});
data_peak.push({
lat: 3.4880444445e+01,
lng: 1.3254588889e+02,
cert : true,
content:'Name = JA/SN-091(JA/SN-091) peak = 523.599976 pos = 34.8804,132.5459 diff = 156.999969'
});
data_saddle.push({
lat: 3.4872000000e+01,
lng: 1.3252877778e+02,
content:'Saddle = 366.600006 pos = 34.8720,132.5288 diff = 156.999969'
});
data_peak.push({
lat: 3.4927222222e+01,
lng: 1.3235877778e+02,
cert : true,
content:'Name = JA/SN-067(JA/SN-067) peak = 590.900024 pos = 34.9272,132.3588 diff = 233.600037'
});
data_saddle.push({
lat: 3.4923666667e+01,
lng: 1.3239344444e+02,
content:'Saddle = 357.299988 pos = 34.9237,132.3934 diff = 233.600037'
});
data_peak.push({
lat: 3.4935666667e+01,
lng: 1.3238488889e+02,
cert : true,
content:'Name = JA/SN-071(JA/SN-071) peak = 580.200012 pos = 34.9357,132.3849 diff = 222.600006'
});
data_saddle.push({
lat: 3.4935333333e+01,
lng: 1.3237955556e+02,
content:'Saddle = 357.600006 pos = 34.9353,132.3796 diff = 222.600006'
});
data_peak.push({
lat: 3.4438444445e+01,
lng: 1.3169522222e+02,
cert : true,
content:'Name = Tokusagamine(JA/SN-015) peak = 987.799988 pos = 34.4384,131.6952 diff = 630.099976'
});
data_saddle.push({
lat: 3.4436000000e+01,
lng: 1.3176588889e+02,
content:'Saddle = 357.700012 pos = 34.4360,131.7659 diff = 630.099976'
});
data_peak.push({
lat: 3.4434777778e+01,
lng: 1.3175844444e+02,
cert : false,
content:' Peak = 640.099976 pos = 34.4348,131.7584 diff = 240.499969'
});
data_saddle.push({
lat: 3.4429555556e+01,
lng: 1.3173700000e+02,
content:'Saddle = 399.600006 pos = 34.4296,131.7370 diff = 240.499969'
});
data_peak.push({
lat: 3.4435444445e+01,
lng: 1.3174522222e+02,
cert : false,
content:' Peak = 635.299988 pos = 34.4354,131.7452 diff = 156.399994'
});
data_saddle.push({
lat: 3.4436555556e+01,
lng: 1.3174933333e+02,
content:'Saddle = 478.899994 pos = 34.4366,131.7493 diff = 156.399994'
});
data_peak.push({
lat: 3.4565666667e+01,
lng: 1.3159500000e+02,
cert : false,
content:' Peak = 590.200012 pos = 34.5657,131.5950 diff = 182.800018'
});
data_saddle.push({
lat: 3.4557555556e+01,
lng: 1.3158911111e+02,
content:'Saddle = 407.399994 pos = 34.5576,131.5891 diff = 182.800018'
});
data_peak.push({
lat: 3.4518888889e+01,
lng: 1.3158500000e+02,
cert : false,
content:' Peak = 590.799988 pos = 34.5189,131.5850 diff = 174.299988'
});
data_saddle.push({
lat: 3.4512000000e+01,
lng: 1.3158200000e+02,
content:'Saddle = 416.500000 pos = 34.5120,131.5820 diff = 174.299988'
});
data_peak.push({
lat: 3.4528777778e+01,
lng: 1.3159211111e+02,
cert : true,
content:'Name = JA/YG-056(JA/YG-056) peak = 600.099976 pos = 34.5288,131.5921 diff = 181.299988'
});
data_saddle.push({
lat: 3.4528555556e+01,
lng: 1.3160944444e+02,
content:'Saddle = 418.799988 pos = 34.5286,131.6094 diff = 181.299988'
});
data_peak.push({
lat: 3.4453555556e+01,
lng: 1.3173511111e+02,
cert : true,
content:'Name = JA/SN-063(JA/SN-063) peak = 603.400024 pos = 34.4536,131.7351 diff = 177.300018'
});
data_saddle.push({
lat: 3.4458111111e+01,
lng: 1.3172766667e+02,
content:'Saddle = 426.100006 pos = 34.4581,131.7277 diff = 177.300018'
});
data_peak.push({
lat: 3.4479333334e+01,
lng: 1.3156600000e+02,
cert : true,
content:'Name = JA/YG-045(JA/YG-045) peak = 625.700012 pos = 34.4793,131.5660 diff = 199.200012'
});
data_saddle.push({
lat: 3.4502333334e+01,
lng: 1.3161822222e+02,
content:'Saddle = 426.500000 pos = 34.5023,131.6182 diff = 199.200012'
});
data_peak.push({
lat: 3.4372666667e+01,
lng: 1.3164211111e+02,
cert : true,
content:'Name = JA/YG-010(JA/YG-010) peak = 834.200012 pos = 34.3727,131.6421 diff = 407.300018'
});
data_saddle.push({
lat: 3.4425111111e+01,
lng: 1.3165422222e+02,
content:'Saddle = 426.899994 pos = 34.4251,131.6542 diff = 407.300018'
});
data_peak.push({
lat: 3.4406777778e+01,
lng: 1.3166022222e+02,
cert : true,
content:'Name = JA/YG-023(JA/YG-023) peak = 713.900024 pos = 34.4068,131.6602 diff = 226.100037'
});
data_saddle.push({
lat: 3.4394333334e+01,
lng: 1.3164433333e+02,
content:'Saddle = 487.799988 pos = 34.3943,131.6443 diff = 226.100037'
});
data_peak.push({
lat: 3.4425111111e+01,
lng: 1.3172477778e+02,
cert : false,
content:' Peak = 583.400024 pos = 34.4251,131.7248 diff = 155.600037'
});
data_saddle.push({
lat: 3.4429222223e+01,
lng: 1.3171877778e+02,
content:'Saddle = 427.799988 pos = 34.4292,131.7188 diff = 155.600037'
});
data_peak.push({
lat: 3.4425000000e+01,
lng: 1.3161311111e+02,
cert : false,
content:' Peak = 703.200012 pos = 34.4250,131.6131 diff = 256.200012'
});
data_saddle.push({
lat: 3.4471333334e+01,
lng: 1.3169988889e+02,
content:'Saddle = 447.000000 pos = 34.4713,131.6999 diff = 256.200012'
});
data_peak.push({
lat: 3.4504000000e+01,
lng: 1.3165633333e+02,
cert : true,
content:'Name = JA/YG-037(JA/YG-037) peak = 652.799988 pos = 34.5040,131.6563 diff = 200.099976'
});
data_saddle.push({
lat: 3.4482888889e+01,
lng: 1.3164933333e+02,
content:'Saddle = 452.700012 pos = 34.4829,131.6493 diff = 200.099976'
});
data_peak.push({
lat: 3.4510777778e+01,
lng: 1.3162566667e+02,
cert : false,
content:' Peak = 645.500000 pos = 34.5108,131.6257 diff = 179.700012'
});
data_saddle.push({
lat: 3.4507000000e+01,
lng: 1.3163155556e+02,
content:'Saddle = 465.799988 pos = 34.5070,131.6316 diff = 179.700012'
});
data_peak.push({
lat: 3.4524777778e+01,
lng: 1.3161711111e+02,
cert : true,
content:'Name = JA/YG-040(JA/YG-040) peak = 640.400024 pos = 34.5248,131.6171 diff = 167.100037'
});
data_saddle.push({
lat: 3.4516111111e+01,
lng: 1.3161944444e+02,
content:'Saddle = 473.299988 pos = 34.5161,131.6194 diff = 167.100037'
});
data_peak.push({
lat: 3.4484111111e+01,
lng: 1.3168133333e+02,
cert : false,
content:' Peak = 624.799988 pos = 34.4841,131.6813 diff = 151.899994'
});
data_saddle.push({
lat: 3.4490111111e+01,
lng: 1.3168222222e+02,
content:'Saddle = 472.899994 pos = 34.4901,131.6822 diff = 151.899994'
});
data_peak.push({
lat: 3.4271222223e+01,
lng: 1.3205844444e+02,
cert : true,
content:'Name = JA/YG-076(JA/YG-076) peak = 542.599976 pos = 34.2712,132.0584 diff = 184.299988'
});
data_saddle.push({
lat: 3.4276222223e+01,
lng: 1.3205311111e+02,
content:'Saddle = 358.299988 pos = 34.2762,132.0531 diff = 184.299988'
});
data_peak.push({
lat: 3.4245888889e+01,
lng: 1.3204655556e+02,
cert : false,
content:' Peak = 530.700012 pos = 34.2459,132.0466 diff = 153.600006'
});
data_saddle.push({
lat: 3.4257888889e+01,
lng: 1.3204977778e+02,
content:'Saddle = 377.100006 pos = 34.2579,132.0498 diff = 153.600006'
});
data_peak.push({
lat: 3.4831000000e+01,
lng: 1.3214711111e+02,
cert : true,
content:'Name = JA/SN-051(JA/SN-051) peak = 665.500000 pos = 34.8310,132.1471 diff = 298.799988'
});
data_saddle.push({
lat: 3.4821777778e+01,
lng: 1.3215511111e+02,
content:'Saddle = 366.700012 pos = 34.8218,132.1551 diff = 298.799988'
});
data_peak.push({
lat: 3.4611666667e+01,
lng: 1.3191433333e+02,
cert : true,
content:'Name = JA/SN-082(JA/SN-082) peak = 553.000000 pos = 34.6117,131.9143 diff = 185.600006'
});
data_saddle.push({
lat: 3.4613333334e+01,
lng: 1.3192288889e+02,
content:'Saddle = 367.399994 pos = 34.6133,131.9229 diff = 185.600006'
});
data_peak.push({
lat: 3.4907000000e+01,
lng: 1.3241366667e+02,
cert : true,
content:'Name = JA/SN-028(JA/SN-028) peak = 824.500000 pos = 34.9070,132.4137 diff = 455.600006'
});
data_saddle.push({
lat: 3.4877222222e+01,
lng: 1.3239977778e+02,
content:'Saddle = 368.899994 pos = 34.8772,132.3998 diff = 455.600006'
});
data_peak.push({
lat: 3.4903000000e+01,
lng: 1.3235455556e+02,
cert : true,
content:'Name = JA/SN-046(JA/SN-046) peak = 715.000000 pos = 34.9030,132.3546 diff = 307.700012'
});
data_saddle.push({
lat: 3.4903111111e+01,
lng: 1.3237411111e+02,
content:'Saddle = 407.299988 pos = 34.9031,132.3741 diff = 307.700012'
});
data_peak.push({
lat: 3.4928888889e+01,
lng: 1.3245888889e+02,
cert : false,
content:' Peak = 590.700012 pos = 34.9289,132.4589 diff = 163.600006'
});
data_saddle.push({
lat: 3.4929555556e+01,
lng: 1.3245400000e+02,
content:'Saddle = 427.100006 pos = 34.9296,132.4540 diff = 163.600006'
});
data_peak.push({
lat: 3.4918555556e+01,
lng: 1.3243044444e+02,
cert : false,
content:' Peak = 793.099976 pos = 34.9186,132.4304 diff = 276.299988'
});
data_saddle.push({
lat: 3.4914000000e+01,
lng: 1.3242088889e+02,
content:'Saddle = 516.799988 pos = 34.9140,132.4209 diff = 276.299988'
});
data_peak.push({
lat: 3.4725333334e+01,
lng: 1.3254166667e+02,
cert : true,
content:'Name = JA/HS-121(JA/HS-121) peak = 653.000000 pos = 34.7253,132.5417 diff = 282.100006'
});
data_saddle.push({
lat: 3.4724666667e+01,
lng: 1.3252033333e+02,
content:'Saddle = 370.899994 pos = 34.7247,132.5203 diff = 282.100006'
});
data_peak.push({
lat: 3.4475888889e+01,
lng: 1.3230744444e+02,
cert : true,
content:'Name = JA/HS-035(JA/HS-035) peak = 977.200012 pos = 34.4759,132.3074 diff = 603.700012'
});
data_saddle.push({
lat: 3.4451222223e+01,
lng: 1.3228866667e+02,
content:'Saddle = 373.500000 pos = 34.4512,132.2887 diff = 603.700012'
});
data_peak.push({
lat: 3.4468555556e+01,
lng: 1.3236433333e+02,
cert : true,
content:'Name = JA/HS-126(JA/HS-126) peak = 641.099976 pos = 34.4686,132.3643 diff = 255.299988'
});
data_saddle.push({
lat: 3.4458777778e+01,
lng: 1.3235066667e+02,
content:'Saddle = 385.799988 pos = 34.4588,132.3507 diff = 255.299988'
});
data_peak.push({
lat: 3.4439555556e+01,
lng: 1.3233622222e+02,
cert : true,
content:'Name = Madogayama(JA/HS-101) peak = 710.700012 pos = 34.4396,132.3362 diff = 313.500000'
});
data_saddle.push({
lat: 3.4447222223e+01,
lng: 1.3232255556e+02,
content:'Saddle = 397.200012 pos = 34.4472,132.3226 diff = 313.500000'
});
data_peak.push({
lat: 3.4528444445e+01,
lng: 1.3236922222e+02,
cert : false,
content:' Peak = 663.799988 pos = 34.5284,132.3692 diff = 166.399994'
});
data_saddle.push({
lat: 3.4532777778e+01,
lng: 1.3235500000e+02,
content:'Saddle = 497.399994 pos = 34.5328,132.3550 diff = 166.399994'
});
data_peak.push({
lat: 3.4505000000e+01,
lng: 1.3234177778e+02,
cert : true,
content:'Name = JA/HS-100(JA/HS-100) peak = 711.400024 pos = 34.5050,132.3418 diff = 198.700012'
});
data_saddle.push({
lat: 3.4494000000e+01,
lng: 1.3233677778e+02,
content:'Saddle = 512.700012 pos = 34.4940,132.3368 diff = 198.700012'
});
data_peak.push({
lat: 3.4501888889e+01,
lng: 1.3232566667e+02,
cert : true,
content:'Name = JA/HS-109(JA/HS-109) peak = 693.000000 pos = 34.5019,132.3257 diff = 159.500000'
});
data_saddle.push({
lat: 3.4498222223e+01,
lng: 1.3232800000e+02,
content:'Saddle = 533.500000 pos = 34.4982,132.3280 diff = 159.500000'
});
data_peak.push({
lat: 3.4458111111e+01,
lng: 1.3231033333e+02,
cert : false,
content:' Peak = 862.799988 pos = 34.4581,132.3103 diff = 190.399963'
});
data_saddle.push({
lat: 3.4466888889e+01,
lng: 1.3231400000e+02,
content:'Saddle = 672.400024 pos = 34.4669,132.3140 diff = 190.399963'
});
data_peak.push({
lat: 3.4570333334e+01,
lng: 1.3242322222e+02,
cert : true,
content:'Name = JA/HS-112(JA/HS-112) peak = 686.000000 pos = 34.5703,132.4232 diff = 309.299988'
});
data_saddle.push({
lat: 3.4605444445e+01,
lng: 1.3244800000e+02,
content:'Saddle = 376.700012 pos = 34.6054,132.4480 diff = 309.299988'
});
data_peak.push({
lat: 3.4547555556e+01,
lng: 1.3241800000e+02,
cert : false,
content:' Peak = 571.599976 pos = 34.5476,132.4180 diff = 159.399963'
});
data_saddle.push({
lat: 3.4549888889e+01,
lng: 1.3242477778e+02,
content:'Saddle = 412.200012 pos = 34.5499,132.4248 diff = 159.399963'
});
data_peak.push({
lat: 3.4672333334e+01,
lng: 1.3265455556e+02,
cert : false,
content:' Peak = 528.299988 pos = 34.6723,132.6546 diff = 150.500000'
});
data_saddle.push({
lat: 3.4673444445e+01,
lng: 1.3261755556e+02,
content:'Saddle = 377.799988 pos = 34.6734,132.6176 diff = 150.500000'
});
data_peak.push({
lat: 3.4582222222e+01,
lng: 1.3239644444e+02,
cert : true,
content:'Name = JA/HS-110(JA/HS-110) peak = 691.200012 pos = 34.5822,132.3964 diff = 313.200012'
});
data_saddle.push({
lat: 3.4617555556e+01,
lng: 1.3244355556e+02,
content:'Saddle = 378.000000 pos = 34.6176,132.4436 diff = 313.200012'
});
data_peak.push({
lat: 3.4353555556e+01,
lng: 1.3177788889e+02,
cert : true,
content:'Name = Ototomiyama(JA/SN-006) peak = 1084.699951 pos = 34.3536,131.7779 diff = 705.999939'
});
data_saddle.push({
lat: 3.4325777778e+01,
lng: 1.3194044444e+02,
content:'Saddle = 378.700012 pos = 34.3258,131.9404 diff = 705.999939'
});
data_peak.push({
lat: 3.4155000000e+01,
lng: 1.3180811111e+02,
cert : false,
content:' Peak = 646.900024 pos = 34.1550,131.8081 diff = 265.500031'
});
data_saddle.push({
lat: 3.4220222223e+01,
lng: 1.3179544444e+02,
content:'Saddle = 381.399994 pos = 34.2202,131.7954 diff = 265.500031'
});
data_peak.push({
lat: 3.4163222223e+01,
lng: 1.3183155556e+02,
cert : false,
content:' Peak = 593.299988 pos = 34.1632,131.8316 diff = 205.899994'
});
data_saddle.push({
lat: 3.4174555556e+01,
lng: 1.3183844444e+02,
content:'Saddle = 387.399994 pos = 34.1746,131.8384 diff = 205.899994'
});
data_peak.push({
lat: 3.4164777778e+01,
lng: 1.3187766667e+02,
cert : true,
content:'Name = JA/YG-055(JA/YG-055) peak = 604.000000 pos = 34.1648,131.8777 diff = 215.100006'
});
data_saddle.push({
lat: 3.4173222223e+01,
lng: 1.3186488889e+02,
content:'Saddle = 388.899994 pos = 34.1732,131.8649 diff = 215.100006'
});
data_peak.push({
lat: 3.4189333334e+01,
lng: 1.3175822222e+02,
cert : false,
content:' Peak = 628.799988 pos = 34.1893,131.7582 diff = 221.099976'
});
data_saddle.push({
lat: 3.4193333334e+01,
lng: 1.3176222222e+02,
content:'Saddle = 407.700012 pos = 34.1933,131.7622 diff = 221.099976'
});
data_peak.push({
lat: 3.4198555556e+01,
lng: 1.3170544444e+02,
cert : false,
content:' Peak = 572.599976 pos = 34.1986,131.7054 diff = 164.699982'
});
data_saddle.push({
lat: 3.4200333334e+01,
lng: 1.3171066667e+02,
content:'Saddle = 407.899994 pos = 34.2003,131.7107 diff = 164.699982'
});
data_peak.push({
lat: 3.4173666667e+01,
lng: 1.3185233333e+02,
cert : true,
content:'Name = JA/YG-036(JA/YG-036) peak = 661.299988 pos = 34.1737,131.8523 diff = 203.299988'
});
data_saddle.push({
lat: 3.4182111112e+01,
lng: 1.3184722222e+02,
content:'Saddle = 458.000000 pos = 34.1821,131.8472 diff = 203.299988'
});
data_peak.push({
lat: 3.4191888889e+01,
lng: 1.3184177778e+02,
cert : true,
content:'Name = JA/YG-013(JA/YG-013) peak = 788.200012 pos = 34.1919,131.8418 diff = 291.600006'
});
data_saddle.push({
lat: 3.4216888889e+01,
lng: 1.3184833333e+02,
content:'Saddle = 496.600006 pos = 34.2169,131.8483 diff = 291.600006'
});
data_peak.push({
lat: 3.4261777778e+01,
lng: 1.3171077778e+02,
cert : true,
content:'Name = JA/YG-017(JA/YG-017) peak = 753.700012 pos = 34.2618,131.7108 diff = 256.000000'
});
data_saddle.push({
lat: 3.4268555556e+01,
lng: 1.3173833333e+02,
content:'Saddle = 497.700012 pos = 34.2686,131.7383 diff = 256.000000'
});
data_peak.push({
lat: 3.4210444445e+01,
lng: 1.3186711111e+02,
cert : true,
content:'Name = JA/YG-033(JA/YG-033) peak = 677.799988 pos = 34.2104,131.8671 diff = 164.599976'
});
data_saddle.push({
lat: 3.4231111112e+01,
lng: 1.3186022222e+02,
content:'Saddle = 513.200012 pos = 34.2311,131.8602 diff = 164.599976'
});
data_peak.push({
lat: 3.4273444445e+01,
lng: 1.3174244444e+02,
cert : true,
content:'Name = JA/YG-022(JA/YG-022) peak = 730.200012 pos = 34.2734,131.7424 diff = 212.799988'
});
data_saddle.push({
lat: 3.4269444445e+01,
lng: 1.3174755556e+02,
content:'Saddle = 517.400024 pos = 34.2694,131.7476 diff = 212.799988'
});
data_peak.push({
lat: 3.4356555556e+01,
lng: 1.3170111111e+02,
cert : true,
content:'Name = JA/YG-011(JA/YG-011) peak = 815.599976 pos = 34.3566,131.7011 diff = 294.399963'
});
data_saddle.push({
lat: 3.4362000000e+01,
lng: 1.3172288889e+02,
content:'Saddle = 521.200012 pos = 34.3620,131.7229 diff = 294.399963'
});
data_peak.push({
lat: 3.4462222223e+01,
lng: 1.3179800000e+02,
cert : true,
content:'Name = Aonoyama(JA/SN-022) peak = 907.099976 pos = 34.4622,131.7980 diff = 350.199951'
});
data_saddle.push({
lat: 3.4461777778e+01,
lng: 1.3180522222e+02,
content:'Saddle = 556.900024 pos = 34.4618,131.8052 diff = 350.199951'
});
data_peak.push({
lat: 3.4475666667e+01,
lng: 1.3183988889e+02,
cert : true,
content:'Name = JA/SN-034(JA/SN-034) peak = 797.500000 pos = 34.4757,131.8399 diff = 224.700012'
});
data_saddle.push({
lat: 3.4456222223e+01,
lng: 1.3182177778e+02,
content:'Saddle = 572.799988 pos = 34.4562,131.8218 diff = 224.700012'
});
data_peak.push({
lat: 3.4329777778e+01,
lng: 1.3174400000e+02,
cert : true,
content:'Name = JA/YG-006(JA/YG-006) peak = 935.900024 pos = 34.3298,131.7440 diff = 349.300049'
});
data_saddle.push({
lat: 3.4330000000e+01,
lng: 1.3175511111e+02,
content:'Saddle = 586.599976 pos = 34.3300,131.7551 diff = 349.300049'
});
data_peak.push({
lat: 3.4245111112e+01,
lng: 1.3174533333e+02,
cert : true,
content:'Name = JA/YG-007(JA/YG-007) peak = 922.799988 pos = 34.2451,131.7453 diff = 324.299988'
});
data_saddle.push({
lat: 3.4277666667e+01,
lng: 1.3175577778e+02,
content:'Saddle = 598.500000 pos = 34.2777,131.7558 diff = 324.299988'
});
data_peak.push({
lat: 3.4270666667e+01,
lng: 1.3176555556e+02,
cert : true,
content:'Name = JA/YG-009(JA/YG-009) peak = 841.099976 pos = 34.2707,131.7656 diff = 194.000000'
});
data_saddle.push({
lat: 3.4268666667e+01,
lng: 1.3175477778e+02,
content:'Saddle = 647.099976 pos = 34.2687,131.7548 diff = 194.000000'
});
data_peak.push({
lat: 3.4299222223e+01,
lng: 1.3175011111e+02,
cert : true,
content:'Name = JA/YG-008(JA/YG-008) peak = 889.400024 pos = 34.2992,131.7501 diff = 186.400024'
});
data_saddle.push({
lat: 3.4308777778e+01,
lng: 1.3174688889e+02,
content:'Saddle = 703.000000 pos = 34.3088,131.7469 diff = 186.400024'
});
data_peak.push({
lat: 3.4243555556e+01,
lng: 1.3185988889e+02,
cert : true,
content:'Name = JA/YG-012(JA/YG-012) peak = 796.700012 pos = 34.2436,131.8599 diff = 196.900024'
});
data_saddle.push({
lat: 3.4248888889e+01,
lng: 1.3187000000e+02,
content:'Saddle = 599.799988 pos = 34.2489,131.8700 diff = 196.900024'
});
data_peak.push({
lat: 3.4386333334e+01,
lng: 1.3180033333e+02,
cert : false,
content:' Peak = 793.099976 pos = 34.3863,131.8003 diff = 155.099976'
});
data_saddle.push({
lat: 3.4388111111e+01,
lng: 1.3179577778e+02,
content:'Saddle = 638.000000 pos = 34.3881,131.7958 diff = 155.099976'
});
data_peak.push({
lat: 3.4400000000e+01,
lng: 1.3178466667e+02,
cert : true,
content:'Name = Takadakeyama(JA/SN-011) peak = 1040.400024 pos = 34.4000,131.7847 diff = 382.500000'
});
data_saddle.push({
lat: 3.4367222223e+01,
lng: 1.3176744444e+02,
content:'Saddle = 657.900024 pos = 34.3672,131.7674 diff = 382.500000'
});
data_peak.push({
lat: 3.4376666667e+01,
lng: 1.3183911111e+02,
cert : true,
content:'Name = Suzunoootaniyama(JA/SN-012) peak = 1033.800049 pos = 34.3767,131.8391 diff = 325.100037'
});
data_saddle.push({
lat: 3.4331444445e+01,
lng: 1.3182644444e+02,
content:'Saddle = 708.700012 pos = 34.3314,131.8264 diff = 325.100037'
});
data_peak.push({
lat: 3.4371111111e+01,
lng: 1.3186066667e+02,
cert : true,
content:'Name = JA/SN-023(JA/SN-023) peak = 890.799988 pos = 34.3711,131.8607 diff = 178.599976'
});
data_saddle.push({
lat: 3.4373444445e+01,
lng: 1.3185288889e+02,
content:'Saddle = 712.200012 pos = 34.3734,131.8529 diff = 178.599976'
});
data_peak.push({
lat: 3.4318444445e+01,
lng: 1.3189955556e+02,
cert : true,
content:'Name = Heikegadake(JA/YG-003) peak = 1065.599976 pos = 34.3184,131.8996 diff = 348.000000'
});
data_saddle.push({
lat: 3.4315444445e+01,
lng: 1.3180333333e+02,
content:'Saddle = 717.599976 pos = 34.3154,131.8033 diff = 348.000000'
});
data_peak.push({
lat: 3.4309888889e+01,
lng: 1.3183755556e+02,
cert : false,
content:' Peak = 988.200012 pos = 34.3099,131.8376 diff = 230.500000'
});
data_saddle.push({
lat: 3.4305888889e+01,
lng: 1.3186211111e+02,
content:'Saddle = 757.700012 pos = 34.3059,131.8621 diff = 230.500000'
});
data_peak.push({
lat: 3.4275333334e+01,
lng: 1.3187755556e+02,
cert : true,
content:'Name = JA/YG-005(JA/YG-005) peak = 1014.700012 pos = 34.2753,131.8776 diff = 221.900024'
});
data_saddle.push({
lat: 3.4289222223e+01,
lng: 1.3188155556e+02,
content:'Saddle = 792.799988 pos = 34.2892,131.8816 diff = 221.900024'
});
data_peak.push({
lat: 3.4366555556e+01,
lng: 1.3180011111e+02,
cert : false,
content:' Peak = 940.200012 pos = 34.3666,131.8001 diff = 189.299988'
});
data_saddle.push({
lat: 3.4362555556e+01,
lng: 1.3179488889e+02,
content:'Saddle = 750.900024 pos = 34.3626,131.7949 diff = 189.299988'
});
data_peak.push({
lat: 3.4790888889e+01,
lng: 1.3265566667e+02,
cert : true,
content:'Name = JA/HS-151(JA/HS-151) peak = 561.900024 pos = 34.7909,132.6557 diff = 173.600037'
});
data_saddle.push({
lat: 3.4784111111e+01,
lng: 1.3264222222e+02,
content:'Saddle = 388.299988 pos = 34.7841,132.6422 diff = 173.600037'
});
data_peak.push({
lat: 3.4342666667e+01,
lng: 1.3197911111e+02,
cert : true,
content:'Name = JA/YG-004(JA/YG-004) peak = 1021.599976 pos = 34.3427,131.9791 diff = 633.199951'
});
data_saddle.push({
lat: 3.4372444445e+01,
lng: 1.3200233333e+02,
content:'Saddle = 388.399994 pos = 34.3724,132.0023 diff = 633.199951'
});
data_peak.push({
lat: 3.4373777778e+01,
lng: 1.3201200000e+02,
cert : false,
content:' Peak = 555.500000 pos = 34.3738,132.0120 diff = 157.700012'
});
data_saddle.push({
lat: 3.4366333334e+01,
lng: 1.3200800000e+02,
content:'Saddle = 397.799988 pos = 34.3663,132.0080 diff = 157.700012'
});
data_peak.push({
lat: 3.4749444445e+01,
lng: 1.3263666667e+02,
cert : true,
content:'Name = JA/HS-140(JA/HS-140) peak = 594.400024 pos = 34.7494,132.6367 diff = 187.400024'
});
data_saddle.push({
lat: 3.4744777778e+01,
lng: 1.3261155556e+02,
content:'Saddle = 407.000000 pos = 34.7448,132.6116 diff = 187.400024'
});
data_peak.push({
lat: 3.4796777778e+01,
lng: 1.3208122222e+02,
cert : true,
content:'Name = JA/SN-047(JA/SN-047) peak = 713.200012 pos = 34.7968,132.0812 diff = 296.400024'
});
data_saddle.push({
lat: 3.4804222222e+01,
lng: 1.3211677778e+02,
content:'Saddle = 416.799988 pos = 34.8042,132.1168 diff = 296.400024'
});
data_peak.push({
lat: 3.4578333334e+01,
lng: 1.3249511111e+02,
cert : true,
content:'Name = JA/HS-054(JA/HS-054) peak = 859.099976 pos = 34.5783,132.4951 diff = 430.899963'
});
data_saddle.push({
lat: 3.4602666667e+01,
lng: 1.3249511111e+02,
content:'Saddle = 428.200012 pos = 34.6027,132.4951 diff = 430.899963'
});
data_peak.push({
lat: 3.4623555556e+01,
lng: 1.3257511111e+02,
cert : true,
content:'Name = JA/HS-089(JA/HS-089) peak = 739.200012 pos = 34.6236,132.5751 diff = 271.200012'
});
data_saddle.push({
lat: 3.4611666667e+01,
lng: 1.3255944444e+02,
content:'Saddle = 468.000000 pos = 34.6117,132.5594 diff = 271.200012'
});
data_peak.push({
lat: 3.4581888889e+01,
lng: 1.3253744444e+02,
cert : true,
content:'Name = JA/HS-076(JA/HS-076) peak = 788.299988 pos = 34.5819,132.5374 diff = 180.700012'
});
data_saddle.push({
lat: 3.4594555556e+01,
lng: 1.3253055556e+02,
content:'Saddle = 607.599976 pos = 34.5946,132.5306 diff = 180.700012'
});
data_peak.push({
lat: 3.4618444445e+01,
lng: 1.3251911111e+02,
cert : false,
content:' Peak = 815.799988 pos = 34.6184,132.5191 diff = 174.200012'
});
data_saddle.push({
lat: 3.4590444445e+01,
lng: 1.3249611111e+02,
content:'Saddle = 641.599976 pos = 34.5904,132.4961 diff = 174.200012'
});
data_peak.push({
lat: 3.4631888889e+01,
lng: 1.3196377778e+02,
cert : false,
content:' Peak = 742.599976 pos = 34.6319,131.9638 diff = 314.199982'
});
data_saddle.push({
lat: 3.4630000000e+01,
lng: 1.3198322222e+02,
content:'Saddle = 428.399994 pos = 34.6300,131.9832 diff = 314.199982'
});
data_peak.push({
lat: 3.4848333333e+01,
lng: 1.3258155556e+02,
cert : true,
content:'Name = JA/SN-052(JA/SN-052) peak = 664.000000 pos = 34.8483,132.5816 diff = 227.799988'
});
data_saddle.push({
lat: 3.4830777778e+01,
lng: 1.3256922222e+02,
content:'Saddle = 436.200012 pos = 34.8308,132.5692 diff = 227.799988'
});
data_peak.push({
lat: 3.4692777778e+01,
lng: 1.3260888889e+02,
cert : true,
content:'Name = JA/HS-104(JA/HS-104) peak = 706.700012 pos = 34.6928,132.6089 diff = 269.600006'
});
data_saddle.push({
lat: 3.4691000000e+01,
lng: 1.3258844444e+02,
content:'Saddle = 437.100006 pos = 34.6910,132.5884 diff = 269.600006'
});
data_peak.push({
lat: 3.4372000000e+01,
lng: 1.3227511111e+02,
cert : false,
content:' Peak = 730.900024 pos = 34.3720,132.2751 diff = 293.000031'
});
data_saddle.push({
lat: 3.4407666667e+01,
lng: 1.3227822222e+02,
content:'Saddle = 437.899994 pos = 34.4077,132.2782 diff = 293.000031'
});
data_peak.push({
lat: 3.4863555556e+01,
lng: 1.3233866667e+02,
cert : false,
content:' Peak = 620.299988 pos = 34.8636,132.3387 diff = 177.199982'
});
data_saddle.push({
lat: 3.4860777778e+01,
lng: 1.3234344444e+02,
content:'Saddle = 443.100006 pos = 34.8608,132.3434 diff = 177.199982'
});
data_peak.push({
lat: 3.4866000000e+01,
lng: 1.3250044444e+02,
cert : false,
content:' Peak = 621.000000 pos = 34.8660,132.5004 diff = 174.799988'
});
data_saddle.push({
lat: 3.4859777778e+01,
lng: 1.3246133333e+02,
content:'Saddle = 446.200012 pos = 34.8598,132.4613 diff = 174.799988'
});
data_peak.push({
lat: 3.4832222222e+01,
lng: 1.3219088889e+02,
cert : true,
content:'Name = Kanagiyama(JA/SN-043) peak = 719.200012 pos = 34.8322,132.1909 diff = 271.100006'
});
data_saddle.push({
lat: 3.4826222222e+01,
lng: 1.3221611111e+02,
content:'Saddle = 448.100006 pos = 34.8262,132.2161 diff = 271.100006'
});
data_peak.push({
lat: 3.4819666667e+01,
lng: 1.3217122222e+02,
cert : false,
content:' Peak = 623.299988 pos = 34.8197,132.1712 diff = 161.199982'
});
data_saddle.push({
lat: 3.4824333334e+01,
lng: 1.3218011111e+02,
content:'Saddle = 462.100006 pos = 34.8243,132.1801 diff = 161.199982'
});
data_peak.push({
lat: 3.4414888889e+01,
lng: 1.3226933333e+02,
cert : true,
content:'Name = JA/HS-124(JA/HS-124) peak = 645.500000 pos = 34.4149,132.2693 diff = 187.600006'
});
data_saddle.push({
lat: 3.4415777778e+01,
lng: 1.3226066667e+02,
content:'Saddle = 457.899994 pos = 34.4158,132.2607 diff = 187.600006'
});
data_peak.push({
lat: 3.4834666667e+01,
lng: 1.3227644444e+02,
cert : true,
content:'Name = JA/SN-049(JA/SN-049) peak = 704.500000 pos = 34.8347,132.2764 diff = 228.100006'
});
data_saddle.push({
lat: 3.4833000000e+01,
lng: 1.3225855556e+02,
content:'Saddle = 476.399994 pos = 34.8330,132.2586 diff = 228.100006'
});
data_peak.push({
lat: 3.4755777778e+01,
lng: 1.3251877778e+02,
cert : true,
content:'Name = JA/HS-120(JA/HS-120) peak = 654.700012 pos = 34.7558,132.5188 diff = 177.900024'
});
data_saddle.push({
lat: 3.4765666667e+01,
lng: 1.3252777778e+02,
content:'Saddle = 476.799988 pos = 34.7657,132.5278 diff = 177.900024'
});
data_peak.push({
lat: 3.4721555556e+01,
lng: 1.3259322222e+02,
cert : true,
content:'Name = JA/HS-099(JA/HS-099) peak = 715.200012 pos = 34.7216,132.5932 diff = 236.700012'
});
data_saddle.push({
lat: 3.4745333334e+01,
lng: 1.3258033333e+02,
content:'Saddle = 478.500000 pos = 34.7453,132.5803 diff = 236.700012'
});
data_peak.push({
lat: 3.4746111111e+01,
lng: 1.3259022222e+02,
cert : false,
content:' Peak = 632.900024 pos = 34.7461,132.5902 diff = 150.200012'
});
data_saddle.push({
lat: 3.4728777778e+01,
lng: 1.3258944444e+02,
content:'Saddle = 482.700012 pos = 34.7288,132.5894 diff = 150.200012'
});
data_peak.push({
lat: 3.4317222223e+01,
lng: 1.3210344444e+02,
cert : true,
content:'Name = JA/YG-016(JA/YG-016) peak = 751.099976 pos = 34.3172,132.1034 diff = 272.099976'
});
data_saddle.push({
lat: 3.4323222223e+01,
lng: 1.3209366667e+02,
content:'Saddle = 479.000000 pos = 34.3232,132.0937 diff = 272.099976'
});
data_peak.push({
lat: 3.4735333334e+01,
lng: 1.3248688889e+02,
cert : true,
content:'Name = JA/HS-105(JA/HS-105) peak = 705.200012 pos = 34.7353,132.4869 diff = 217.200012'
});
data_saddle.push({
lat: 3.4738222222e+01,
lng: 1.3247211111e+02,
content:'Saddle = 488.000000 pos = 34.7382,132.4721 diff = 217.200012'
});
data_peak.push({
lat: 3.4862444445e+01,
lng: 1.3241066667e+02,
cert : true,
content:'Name = JA/SN-024(JA/SN-024) peak = 886.799988 pos = 34.8624,132.4107 diff = 398.599976'
});
data_saddle.push({
lat: 3.4832111111e+01,
lng: 1.3244155556e+02,
content:'Saddle = 488.200012 pos = 34.8321,132.4416 diff = 398.599976'
});
data_peak.push({
lat: 3.4839888889e+01,
lng: 1.3241466667e+02,
cert : false,
content:' Peak = 693.500000 pos = 34.8399,132.4147 diff = 150.900024'
});
data_saddle.push({
lat: 3.4846444445e+01,
lng: 1.3242122222e+02,
content:'Saddle = 542.599976 pos = 34.8464,132.4212 diff = 150.900024'
});
data_peak.push({
lat: 3.4861000000e+01,
lng: 1.3237355556e+02,
cert : false,
content:' Peak = 804.000000 pos = 34.8610,132.3736 diff = 242.299988'
});
data_saddle.push({
lat: 3.4860111111e+01,
lng: 1.3238755556e+02,
content:'Saddle = 561.700012 pos = 34.8601,132.3876 diff = 242.299988'
});
data_peak.push({
lat: 3.4576111111e+01,
lng: 1.3230966667e+02,
cert : true,
content:'Name = JA/HS-097(JA/HS-097) peak = 721.099976 pos = 34.5761,132.3097 diff = 227.999969'
});
data_saddle.push({
lat: 3.4562333334e+01,
lng: 1.3228166667e+02,
content:'Saddle = 493.100006 pos = 34.5623,132.2817 diff = 227.999969'
});
data_peak.push({
lat: 3.4613666667e+01,
lng: 1.3248377778e+02,
cert : true,
content:'Name = JA/HS-053(JA/HS-053) peak = 869.099976 pos = 34.6137,132.4838 diff = 366.599976'
});
data_saddle.push({
lat: 3.4628222222e+01,
lng: 1.3248544444e+02,
content:'Saddle = 502.500000 pos = 34.6282,132.4854 diff = 366.599976'
});
data_peak.push({
lat: 3.4859444445e+01,
lng: 1.3223755556e+02,
cert : false,
content:' Peak = 663.599976 pos = 34.8594,132.2376 diff = 150.899963'
});
data_saddle.push({
lat: 3.4846444445e+01,
lng: 1.3224400000e+02,
content:'Saddle = 512.700012 pos = 34.8464,132.2440 diff = 150.899963'
});
data_peak.push({
lat: 3.4665333334e+01,
lng: 1.3243266667e+02,
cert : true,
content:'Name = Ryūzuyama(JA/HS-043) peak = 922.000000 pos = 34.6653,132.4327 diff = 409.000000'
});
data_saddle.push({
lat: 3.4691444445e+01,
lng: 1.3242266667e+02,
content:'Saddle = 513.000000 pos = 34.6914,132.4227 diff = 409.000000'
});
data_peak.push({
lat: 3.4692333334e+01,
lng: 1.3243777778e+02,
cert : true,
content:'Name = JA/HS-058(JA/HS-058) peak = 842.400024 pos = 34.6923,132.4378 diff = 281.800049'
});
data_saddle.push({
lat: 3.4664555556e+01,
lng: 1.3246433333e+02,
content:'Saddle = 560.599976 pos = 34.6646,132.4643 diff = 281.800049'
});
data_peak.push({
lat: 3.4652444445e+01,
lng: 1.3249077778e+02,
cert : true,
content:'Name = JA/HS-073(JA/HS-073) peak = 794.299988 pos = 34.6524,132.4908 diff = 186.500000'
});
data_saddle.push({
lat: 3.4656777778e+01,
lng: 1.3248244444e+02,
content:'Saddle = 607.799988 pos = 34.6568,132.4824 diff = 186.500000'
});
data_peak.push({
lat: 3.4670555556e+01,
lng: 1.3247077778e+02,
cert : true,
content:'Name = JA/HS-059(JA/HS-059) peak = 841.900024 pos = 34.6706,132.4708 diff = 204.500000'
});
data_saddle.push({
lat: 3.4675444445e+01,
lng: 1.3246944444e+02,
content:'Saddle = 637.400024 pos = 34.6754,132.4694 diff = 204.500000'
});
data_peak.push({
lat: 3.4660888889e+01,
lng: 1.3245466667e+02,
cert : true,
content:'Name = JA/HS-064(JA/HS-064) peak = 820.599976 pos = 34.6609,132.4547 diff = 253.000000'
});
data_saddle.push({
lat: 3.4666555556e+01,
lng: 1.3244844444e+02,
content:'Saddle = 567.599976 pos = 34.6666,132.4484 diff = 253.000000'
});
data_peak.push({
lat: 3.4791444445e+01,
lng: 1.3253755556e+02,
cert : false,
content:' Peak = 891.099976 pos = 34.7914,132.5376 diff = 374.399963'
});
data_saddle.push({
lat: 3.4797222222e+01,
lng: 1.3248500000e+02,
content:'Saddle = 516.700012 pos = 34.7972,132.4850 diff = 374.399963'
});
data_peak.push({
lat: 3.4806000000e+01,
lng: 1.3261455556e+02,
cert : true,
content:'Name = JA/HS-075(JA/HS-075) peak = 791.099976 pos = 34.8060,132.6146 diff = 228.500000'
});
data_saddle.push({
lat: 3.4799666667e+01,
lng: 1.3257922222e+02,
content:'Saddle = 562.599976 pos = 34.7997,132.5792 diff = 228.500000'
});
data_peak.push({
lat: 3.4796111111e+01,
lng: 1.3250488889e+02,
cert : true,
content:'Name = JA/HS-069(JA/HS-069) peak = 812.200012 pos = 34.7961,132.5049 diff = 170.200012'
});
data_saddle.push({
lat: 3.4800555556e+01,
lng: 1.3252488889e+02,
content:'Saddle = 642.000000 pos = 34.8006,132.5249 diff = 170.200012'
});
data_peak.push({
lat: 3.4745777778e+01,
lng: 1.3246733333e+02,
cert : true,
content:'Name = JA/HS-086(JA/HS-086) peak = 752.200012 pos = 34.7458,132.4673 diff = 235.100037'
});
data_saddle.push({
lat: 3.4732333334e+01,
lng: 1.3243211111e+02,
content:'Saddle = 517.099976 pos = 34.7323,132.4321 diff = 235.100037'
});
data_peak.push({
lat: 3.4400777778e+01,
lng: 1.3203955556e+02,
cert : false,
content:' Peak = 703.900024 pos = 34.4008,132.0396 diff = 171.400024'
});
data_saddle.push({
lat: 3.4398000000e+01,
lng: 1.3204511111e+02,
content:'Saddle = 532.500000 pos = 34.3980,132.0451 diff = 171.400024'
});
data_peak.push({
lat: 3.4612222222e+01,
lng: 1.3237177778e+02,
cert : true,
content:'Name = JA/HS-078(JA/HS-078) peak = 777.700012 pos = 34.6122,132.3718 diff = 221.100037'
});
data_saddle.push({
lat: 3.4627666667e+01,
lng: 1.3236500000e+02,
content:'Saddle = 556.599976 pos = 34.6277,132.3650 diff = 221.100037'
});
data_peak.push({
lat: 3.4605000000e+01,
lng: 1.3235088889e+02,
cert : false,
content:' Peak = 774.000000 pos = 34.6050,132.3509 diff = 172.799988'
});
data_saddle.push({
lat: 3.4614333334e+01,
lng: 1.3236611111e+02,
content:'Saddle = 601.200012 pos = 34.6143,132.3661 diff = 172.799988'
});
data_peak.push({
lat: 3.4540555556e+01,
lng: 1.3228133333e+02,
cert : true,
content:'Name = JA/HS-036(JA/HS-036) peak = 971.900024 pos = 34.5406,132.2813 diff = 414.000000'
});
data_saddle.push({
lat: 3.4510444445e+01,
lng: 1.3223111111e+02,
content:'Saddle = 557.900024 pos = 34.5104,132.2311 diff = 414.000000'
});
data_peak.push({
lat: 3.4500555556e+01,
lng: 1.3226766667e+02,
cert : false,
content:' Peak = 782.400024 pos = 34.5006,132.2677 diff = 159.000000'
});
data_saddle.push({
lat: 3.4515888889e+01,
lng: 1.3226555556e+02,
content:'Saddle = 623.400024 pos = 34.5159,132.2656 diff = 159.000000'
});
data_peak.push({
lat: 3.4508000000e+01,
lng: 1.3224077778e+02,
cert : true,
content:'Name = JA/HS-047(JA/HS-047) peak = 904.200012 pos = 34.5080,132.2408 diff = 171.500000'
});
data_saddle.push({
lat: 3.4531777778e+01,
lng: 1.3225444444e+02,
content:'Saddle = 732.700012 pos = 34.5318,132.2544 diff = 171.500000'
});
data_peak.push({
lat: 3.4793555556e+01,
lng: 1.3245644444e+02,
cert : true,
content:'Name = JA/HS-063(JA/HS-063) peak = 825.500000 pos = 34.7936,132.4564 diff = 267.000000'
});
data_saddle.push({
lat: 3.4812666667e+01,
lng: 1.3243388889e+02,
content:'Saddle = 558.500000 pos = 34.8127,132.4339 diff = 267.000000'
});
data_peak.push({
lat: 3.4582000000e+01,
lng: 1.3195200000e+02,
cert : false,
content:' Peak = 721.200012 pos = 34.5820,131.9520 diff = 158.000000'
});
data_saddle.push({
lat: 3.4570777778e+01,
lng: 1.3196166667e+02,
content:'Saddle = 563.200012 pos = 34.5708,131.9617 diff = 158.000000'
});
data_peak.push({
lat: 3.4423555556e+01,
lng: 1.3190566667e+02,
cert : false,
content:' Peak = 725.400024 pos = 34.4236,131.9057 diff = 156.900024'
});
data_saddle.push({
lat: 3.4427888889e+01,
lng: 1.3191344444e+02,
content:'Saddle = 568.500000 pos = 34.4279,131.9134 diff = 156.900024'
});
data_peak.push({
lat: 3.4551222223e+01,
lng: 1.3191000000e+02,
cert : true,
content:'Name = JA/SN-033(JA/SN-033) peak = 799.500000 pos = 34.5512,131.9100 diff = 220.799988'
});
data_saddle.push({
lat: 3.4517111111e+01,
lng: 1.3191577778e+02,
content:'Saddle = 578.700012 pos = 34.5171,131.9158 diff = 220.799988'
});
data_peak.push({
lat: 3.4627444445e+01,
lng: 1.3228955556e+02,
cert : false,
content:' Peak = 750.900024 pos = 34.6274,132.2896 diff = 163.500000'
});
data_saddle.push({
lat: 3.4629555556e+01,
lng: 1.3228377778e+02,
content:'Saddle = 587.400024 pos = 34.6296,132.2838 diff = 163.500000'
});
data_peak.push({
lat: 3.4595333334e+01,
lng: 1.3226677778e+02,
cert : true,
content:'Name = JA/HS-067(JA/HS-067) peak = 813.200012 pos = 34.5953,132.2668 diff = 225.799988'
});
data_saddle.push({
lat: 3.4618111111e+01,
lng: 1.3227388889e+02,
content:'Saddle = 587.400024 pos = 34.6181,132.2739 diff = 225.799988'
});
data_peak.push({
lat: 3.4408111111e+01,
lng: 1.3216588889e+02,
cert : true,
content:'Name = JA/HS-074(JA/HS-074) peak = 791.500000 pos = 34.4081,132.1659 diff = 190.000000'
});
data_saddle.push({
lat: 3.4415333334e+01,
lng: 1.3216788889e+02,
content:'Saddle = 601.500000 pos = 34.4153,132.1679 diff = 190.000000'
});
data_peak.push({
lat: 3.4512333334e+01,
lng: 1.3192111111e+02,
cert : false,
content:' Peak = 762.599976 pos = 34.5123,131.9211 diff = 159.799988'
});
data_saddle.push({
lat: 3.4511444445e+01,
lng: 1.3192766667e+02,
content:'Saddle = 602.799988 pos = 34.5114,131.9277 diff = 159.799988'
});
data_peak.push({
lat: 3.4470111111e+01,
lng: 1.3190766667e+02,
cert : true,
content:'Name = JA/SN-029(JA/SN-029) peak = 824.700012 pos = 34.4701,131.9077 diff = 209.299988'
});
data_saddle.push({
lat: 3.4472111111e+01,
lng: 1.3192122222e+02,
content:'Saddle = 615.400024 pos = 34.4721,131.9212 diff = 209.299988'
});
data_peak.push({
lat: 3.4622333334e+01,
lng: 1.3205466667e+02,
cert : true,
content:'Name = Kasugayama(JA/SN-016) peak = 988.700012 pos = 34.6223,132.0547 diff = 350.900024'
});
data_saddle.push({
lat: 3.4660888889e+01,
lng: 1.3207033333e+02,
content:'Saddle = 637.799988 pos = 34.6609,132.0703 diff = 350.900024'
});
data_peak.push({
lat: 3.4610555556e+01,
lng: 1.3199788889e+02,
cert : false,
content:' Peak = 812.900024 pos = 34.6106,131.9979 diff = 155.800049'
});
data_saddle.push({
lat: 3.4629555556e+01,
lng: 1.3204366667e+02,
content:'Saddle = 657.099976 pos = 34.6296,132.0437 diff = 155.800049'
});
data_peak.push({
lat: 3.4691444445e+01,
lng: 1.3240422222e+02,
cert : true,
content:'Name = JA/HS-038(JA/HS-038) peak = 952.900024 pos = 34.6914,132.4042 diff = 304.800049'
});
data_saddle.push({
lat: 3.4701111111e+01,
lng: 1.3239933333e+02,
content:'Saddle = 648.099976 pos = 34.7011,132.3993 diff = 304.800049'
});
data_peak.push({
lat: 3.4626222222e+01,
lng: 1.3225000000e+02,
cert : true,
content:'Name = JA/HS-030(JA/HS-030) peak = 1013.599976 pos = 34.6262,132.2500 diff = 346.500000'
});
data_saddle.push({
lat: 3.4643666667e+01,
lng: 1.3223911111e+02,
content:'Saddle = 667.099976 pos = 34.6437,132.2391 diff = 346.500000'
});
data_peak.push({
lat: 3.4554555556e+01,
lng: 1.3198511111e+02,
cert : false,
content:' Peak = 845.799988 pos = 34.5546,131.9851 diff = 167.799988'
});
data_saddle.push({
lat: 3.4552333334e+01,
lng: 1.3197100000e+02,
content:'Saddle = 678.000000 pos = 34.5523,131.9710 diff = 167.799988'
});
data_peak.push({
lat: 3.4794777778e+01,
lng: 1.3238300000e+02,
cert : false,
content:' Peak = 1216.400024 pos = 34.7948,132.3830 diff = 538.000000'
});
data_saddle.push({
lat: 3.4782333334e+01,
lng: 1.3228266667e+02,
content:'Saddle = 678.400024 pos = 34.7823,132.2827 diff = 538.000000'
});
data_peak.push({
lat: 3.4681777778e+01,
lng: 1.3235344444e+02,
cert : true,
content:'Name = JA/HS-044(JA/HS-044) peak = 922.200012 pos = 34.6818,132.3534 diff = 215.400024'
});
data_saddle.push({
lat: 3.4697000000e+01,
lng: 1.3235844444e+02,
content:'Saddle = 706.799988 pos = 34.6970,132.3584 diff = 215.400024'
});
data_peak.push({
lat: 3.4724777778e+01,
lng: 1.3236344444e+02,
cert : true,
content:'Name = JA/HS-050(JA/HS-050) peak = 891.200012 pos = 34.7248,132.3634 diff = 183.600037'
});
data_saddle.push({
lat: 3.4732555556e+01,
lng: 1.3237644444e+02,
content:'Saddle = 707.599976 pos = 34.7326,132.3764 diff = 183.600037'
});
data_peak.push({
lat: 3.4720666667e+01,
lng: 1.3240555556e+02,
cert : true,
content:'Name = JA/HS-033(JA/HS-033) peak = 1001.500000 pos = 34.7207,132.4056 diff = 256.700012'
});
data_saddle.push({
lat: 3.4761000000e+01,
lng: 1.3237988889e+02,
content:'Saddle = 744.799988 pos = 34.7610,132.3799 diff = 256.700012'
});
data_peak.push({
lat: 3.4749888889e+01,
lng: 1.3239977778e+02,
cert : true,
content:'Name = JA/HS-037(JA/HS-037) peak = 965.500000 pos = 34.7499,132.3998 diff = 168.500000'
});
data_saddle.push({
lat: 3.4735777778e+01,
lng: 1.3240133333e+02,
content:'Saddle = 797.000000 pos = 34.7358,132.4013 diff = 168.500000'
});
data_peak.push({
lat: 3.4761333334e+01,
lng: 1.3229488889e+02,
cert : false,
content:' Peak = 910.799988 pos = 34.7613,132.2949 diff = 163.000000'
});
data_saddle.push({
lat: 3.4758666667e+01,
lng: 1.3229955556e+02,
content:'Saddle = 747.799988 pos = 34.7587,132.2996 diff = 163.000000'
});
data_peak.push({
lat: 3.4777111111e+01,
lng: 1.3229866667e+02,
cert : true,
content:'Name = JA/HS-032(JA/HS-032) peak = 1001.799988 pos = 34.7771,132.2987 diff = 203.599976'
});
data_saddle.push({
lat: 3.4793666667e+01,
lng: 1.3232333333e+02,
content:'Saddle = 798.200012 pos = 34.7937,132.3233 diff = 203.599976'
});
data_peak.push({
lat: 3.4734333334e+01,
lng: 1.3225722222e+02,
cert : true,
content:'Name = JA/HS-056(JA/HS-056) peak = 840.500000 pos = 34.7343,132.2572 diff = 161.599976'
});
data_saddle.push({
lat: 3.4745000000e+01,
lng: 1.3225255556e+02,
content:'Saddle = 678.900024 pos = 34.7450,132.2526 diff = 161.599976'
});
data_peak.push({
lat: 3.4532777778e+01,
lng: 1.3217600000e+02,
cert : true,
content:'Name = JA/HS-016(JA/HS-016) peak = 1132.599976 pos = 34.5328,132.1760 diff = 445.599976'
});
data_saddle.push({
lat: 3.4497888889e+01,
lng: 1.3216433333e+02,
content:'Saddle = 687.000000 pos = 34.4979,132.1643 diff = 445.599976'
});
data_peak.push({
lat: 3.4415777778e+01,
lng: 1.3221688889e+02,
cert : true,
content:'Name = Oomineyama(JA/HS-024) peak = 1048.000000 pos = 34.4158,132.2169 diff = 354.700012'
});
data_saddle.push({
lat: 3.4423777778e+01,
lng: 1.3219144444e+02,
content:'Saddle = 693.299988 pos = 34.4238,132.1914 diff = 354.700012'
});
data_peak.push({
lat: 3.4456777778e+01,
lng: 1.3225455556e+02,
cert : true,
content:'Name = JA/HS-046(JA/HS-046) peak = 906.500000 pos = 34.4568,132.2546 diff = 188.900024'
});
data_saddle.push({
lat: 3.4431555556e+01,
lng: 1.3223322222e+02,
content:'Saddle = 717.599976 pos = 34.4316,132.2332 diff = 188.900024'
});
data_peak.push({
lat: 3.4764333334e+01,
lng: 1.3222622222e+02,
cert : true,
content:'Name = JA/HS-034(JA/HS-034) peak = 995.000000 pos = 34.7643,132.2262 diff = 288.099976'
});
data_saddle.push({
lat: 3.4748000000e+01,
lng: 1.3221977778e+02,
content:'Saddle = 706.900024 pos = 34.7480,132.2198 diff = 288.099976'
});
data_peak.push({
lat: 3.4802111111e+01,
lng: 1.3223866667e+02,
cert : true,
content:'Name = Ungetsuyama(JA/SN-021) peak = 910.799988 pos = 34.8021,132.2387 diff = 202.500000'
});
data_saddle.push({
lat: 3.4790111111e+01,
lng: 1.3224277778e+02,
content:'Saddle = 708.299988 pos = 34.7901,132.2428 diff = 202.500000'
});
data_peak.push({
lat: 3.4441444445e+01,
lng: 1.3200822222e+02,
cert : false,
content:' Peak = 943.200012 pos = 34.4414,132.0082 diff = 204.000000'
});
data_saddle.push({
lat: 3.4443777778e+01,
lng: 1.3200477778e+02,
content:'Saddle = 739.200012 pos = 34.4438,132.0048 diff = 204.000000'
});
data_peak.push({
lat: 3.4696888889e+01,
lng: 1.3209600000e+02,
cert : true,
content:'Name = JA/SN-020(JA/SN-020) peak = 920.900024 pos = 34.6969,132.0960 diff = 158.900024'
});
data_saddle.push({
lat: 3.4700777778e+01,
lng: 1.3209666667e+02,
content:'Saddle = 762.000000 pos = 34.7008,132.0967 diff = 158.900024'
});
data_peak.push({
lat: 3.4477222223e+01,
lng: 1.3196711111e+02,
cert : true,
content:'Name = Azoujiyama(JA/SN-001) peak = 1262.300049 pos = 34.4772,131.9671 diff = 495.000061'
});
data_saddle.push({
lat: 3.4459222223e+01,
lng: 1.3199133333e+02,
content:'Saddle = 767.299988 pos = 34.4592,131.9913 diff = 495.000061'
});
data_peak.push({
lat: 3.4514111111e+01,
lng: 1.3198211111e+02,
cert : false,
content:' Peak = 1033.500000 pos = 34.5141,131.9821 diff = 166.200012'
});
data_saddle.push({
lat: 3.4510555556e+01,
lng: 1.3197544444e+02,
content:'Saddle = 867.299988 pos = 34.5106,131.9754 diff = 166.200012'
});
data_peak.push({
lat: 3.4515777778e+01,
lng: 1.3195800000e+02,
cert : true,
content:'Name = JA/SN-008(JA/SN-008) peak = 1071.699951 pos = 34.5158,131.9580 diff = 181.099976'
});
data_saddle.push({
lat: 3.4510555556e+01,
lng: 1.3196177778e+02,
content:'Saddle = 890.599976 pos = 34.5106,131.9618 diff = 181.099976'
});
data_peak.push({
lat: 3.4690111111e+01,
lng: 1.3219666667e+02,
cert : true,
content:'Name = Garyuuzan(JA/HS-009) peak = 1221.400024 pos = 34.6901,132.1967 diff = 453.000000'
});
data_saddle.push({
lat: 3.4690000000e+01,
lng: 1.3216000000e+02,
content:'Saddle = 768.400024 pos = 34.6900,132.1600 diff = 453.000000'
});
data_peak.push({
lat: 3.4650000000e+01,
lng: 1.3220677778e+02,
cert : true,
content:'Name = Shinnyuuzan(JA/HS-014) peak = 1152.099976 pos = 34.6500,132.2068 diff = 365.699951'
});
data_saddle.push({
lat: 3.4666333334e+01,
lng: 1.3220144444e+02,
content:'Saddle = 786.400024 pos = 34.6663,132.2014 diff = 365.699951'
});
data_peak.push({
lat: 3.4628222222e+01,
lng: 1.3220766667e+02,
cert : true,
content:'Name = JA/HS-023(JA/HS-023) peak = 1067.400024 pos = 34.6282,132.2077 diff = 259.700012'
});
data_saddle.push({
lat: 3.4639666667e+01,
lng: 1.3221066667e+02,
content:'Saddle = 807.700012 pos = 34.6397,132.2107 diff = 259.700012'
});
data_peak.push({
lat: 3.4711444445e+01,
lng: 1.3211644444e+02,
cert : true,
content:'Name = JA/SN-009(JA/SN-009) peak = 1062.099976 pos = 34.7114,132.1164 diff = 265.399963'
});
data_saddle.push({
lat: 3.4714222222e+01,
lng: 1.3216488889e+02,
content:'Saddle = 796.700012 pos = 34.7142,132.1649 diff = 265.399963'
});
data_peak.push({
lat: 3.4674888889e+01,
lng: 1.3212366667e+02,
cert : true,
content:'Name = JA/SN-014(JA/SN-014) peak = 1010.900024 pos = 34.6749,132.1237 diff = 212.500000'
});
data_saddle.push({
lat: 3.4711111111e+01,
lng: 1.3212888889e+02,
content:'Saddle = 798.400024 pos = 34.7111,132.1289 diff = 212.500000'
});
data_peak.push({
lat: 3.4747666667e+01,
lng: 1.3220111111e+02,
cert : true,
content:'Name = Oosayama(JA/HS-022) peak = 1066.599976 pos = 34.7477,132.2011 diff = 196.899963'
});
data_saddle.push({
lat: 3.4722000000e+01,
lng: 1.3220777778e+02,
content:'Saddle = 869.700012 pos = 34.7220,132.2078 diff = 196.899963'
});
data_peak.push({
lat: 3.4355666667e+01,
lng: 1.3206722222e+02,
cert : true,
content:'Name = Rakanzan(JA/YG-002) peak = 1107.900024 pos = 34.3557,132.0672 diff = 332.900024'
});
data_saddle.push({
lat: 3.4403000000e+01,
lng: 1.3207411111e+02,
content:'Saddle = 775.000000 pos = 34.4030,132.0741 diff = 332.900024'
});
data_peak.push({
lat: 3.4437666667e+01,
lng: 1.3217277778e+02,
cert : true,
content:'Name = JA/HS-039(JA/HS-039) peak = 947.700012 pos = 34.4377,132.1728 diff = 167.299988'
});
data_saddle.push({
lat: 3.4445888889e+01,
lng: 1.3216544444e+02,
content:'Saddle = 780.400024 pos = 34.4459,132.1654 diff = 167.299988'
});
data_peak.push({
lat: 3.4496777778e+01,
lng: 1.3218333333e+02,
cert : true,
content:'Name = JA/HS-020(JA/HS-020) peak = 1072.099976 pos = 34.4968,132.1833 diff = 290.899963'
});
data_saddle.push({
lat: 3.4430333334e+01,
lng: 1.3208833333e+02,
content:'Saddle = 781.200012 pos = 34.4303,132.0883 diff = 290.899963'
});
data_peak.push({
lat: 3.4443333334e+01,
lng: 1.3210966667e+02,
cert : false,
content:' Peak = 943.400024 pos = 34.4433,132.1097 diff = 152.800049'
});
data_saddle.push({
lat: 3.4435444445e+01,
lng: 1.3211211111e+02,
content:'Saddle = 790.599976 pos = 34.4354,132.1121 diff = 152.800049'
});
data_peak.push({
lat: 3.4476777778e+01,
lng: 1.3221333333e+02,
cert : true,
content:'Name = JA/HS-031(JA/HS-031) peak = 1004.000000 pos = 34.4768,132.2133 diff = 205.200012'
});
data_saddle.push({
lat: 3.4489444445e+01,
lng: 1.3220422222e+02,
content:'Saddle = 798.799988 pos = 34.4894,132.2042 diff = 205.200012'
});
data_peak.push({
lat: 3.4440444445e+01,
lng: 1.3214533333e+02,
cert : true,
content:'Name = JA/HS-021(JA/HS-021) peak = 1070.699951 pos = 34.4404,132.1453 diff = 219.599976'
});
data_saddle.push({
lat: 3.4473222223e+01,
lng: 1.3216455556e+02,
content:'Saddle = 851.099976 pos = 34.4732,132.1646 diff = 219.599976'
});
data_peak.push({
lat: 3.4409888889e+01,
lng: 1.3207144444e+02,
cert : true,
content:'Name = Onigajōyama(JA/HS-027) peak = 1030.599976 pos = 34.4099,132.0714 diff = 237.899963'
});
data_saddle.push({
lat: 3.4437111111e+01,
lng: 1.3207655556e+02,
content:'Saddle = 792.700012 pos = 34.4371,132.0766 diff = 237.899963'
});
data_peak.push({
lat: 3.4424333334e+01,
lng: 1.3197100000e+02,
cert : true,
content:'Name = JA/SN-005(JA/SN-005) peak = 1106.900024 pos = 34.4243,131.9710 diff = 295.500000'
});
data_saddle.push({
lat: 3.4463333334e+01,
lng: 1.3201277778e+02,
content:'Saddle = 811.400024 pos = 34.4633,132.0128 diff = 295.500000'
});
data_peak.push({
lat: 3.4418111111e+01,
lng: 1.3200888889e+02,
cert : false,
content:' Peak = 1164.199951 pos = 34.4181,132.0089 diff = 347.699951'
});
data_saddle.push({
lat: 3.4429333334e+01,
lng: 1.3201988889e+02,
content:'Saddle = 816.500000 pos = 34.4293,132.0199 diff = 347.699951'
});
data_peak.push({
lat: 3.4497111111e+01,
lng: 1.3212544444e+02,
cert : false,
content:' Peak = 1081.300049 pos = 34.4971,132.1254 diff = 217.900024'
});
data_saddle.push({
lat: 3.4499888889e+01,
lng: 1.3211811111e+02,
content:'Saddle = 863.400024 pos = 34.4999,132.1181 diff = 217.900024'
});
data_peak.push({
lat: 3.4639555556e+01,
lng: 1.3214600000e+02,
cert : true,
content:'Name = JA/HS-017(JA/HS-017) peak = 1112.099976 pos = 34.6396,132.1460 diff = 200.399963'
});
data_saddle.push({
lat: 3.4641888889e+01,
lng: 1.3212788889e+02,
content:'Saddle = 911.700012 pos = 34.6419,132.1279 diff = 200.399963'
});
data_peak.push({
lat: 3.4468777778e+01,
lng: 1.3207600000e+02,
cert : true,
content:'Name = Kanmuriyama(JA/HS-002) peak = 1337.900024 pos = 34.4688,132.0760 diff = 384.500000'
});
data_saddle.push({
lat: 3.4499555556e+01,
lng: 1.3204444444e+02,
content:'Saddle = 953.400024 pos = 34.4996,132.0444 diff = 384.500000'
});
data_peak.push({
lat: 3.4515666667e+01,
lng: 1.3202833333e+02,
cert : true,
content:'Name = JA/SN-003(JA/SN-003) peak = 1180.199951 pos = 34.5157,132.0283 diff = 213.299927'
});
data_saddle.push({
lat: 3.4532444445e+01,
lng: 1.3206311111e+02,
content:'Saddle = 966.900024 pos = 34.5324,132.0631 diff = 213.299927'
});
data_peak.push({
lat: 3.4565000000e+01,
lng: 1.3214211111e+02,
cert : true,
content:'Name = Jippouzan(JA/HS-003) peak = 1327.400024 pos = 34.5650,132.1421 diff = 329.800049'
});
data_saddle.push({
lat: 3.4573666667e+01,
lng: 1.3213388889e+02,
content:'Saddle = 997.599976 pos = 34.5737,132.1339 diff = 329.800049'
});
data_peak.push({
lat: 3.4619222222e+01,
lng: 1.3212311111e+02,
cert : true,
content:'Name = JA/HS-013(JA/HS-013) peak = 1188.599976 pos = 34.6192,132.1231 diff = 188.799988'
});
data_saddle.push({
lat: 3.4601888889e+01,
lng: 1.3211855556e+02,
content:'Saddle = 999.799988 pos = 34.6019,132.1186 diff = 188.799988'
});
data_peak.push({
lat: 3.4589888889e+01,
lng: 1.3209144444e+02,
cert : true,
content:'Name = JA/SN-002(JA/SN-002) peak = 1186.099976 pos = 34.5899,132.0914 diff = 183.500000'
});
data_saddle.push({
lat: 3.4598555556e+01,
lng: 1.3209611111e+02,
content:'Saddle = 1002.599976 pos = 34.5986,132.0961 diff = 183.500000'
});
var latlng = new google.maps.LatLng(data_peak[0].lat, data_peak[0].lng);
var opts = {
  zoom: 13,
  center: latlng,
  mapTypeId: google.maps.MapTypeId.TERRAIN
};
var map = new google.maps.Map(document.getElementById("map"), opts);
var markers_peak = new Array();
var markers_saddle = new Array();
for (i = 0; i < data_peak.length; i++) {
  if(data_peak[i].cert) {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        icon : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        map: map
    });} else {
    markers_peak[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
        map: map
    });}
    markerInfo(markers_peak[i], data_peak[i].content);
}
for (i = 0; i < data_saddle.length; i++) {
    markers_saddle[i] = new google.maps.Marker({
        position: new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng),
        opacity: 0.2,
        map: map
    });
    markerInfo(markers_saddle[i], data_saddle[i].content);
}
for (i = 0; i < data_peak.length; i++) {
polylines[i] = new google.maps.Polyline({
   map: map,
	strokeColor:"#00007f",
    strokeOpacity:0.7,
	strokeWeight:2,
    path: [
	    new google.maps.LatLng(data_peak[i].lat, data_peak[i].lng),
	    new google.maps.LatLng(data_saddle[i].lat, data_saddle[i].lng)
	    ]
});
region_rect = new google.maps.Rectangle({
   map: map,
	strokeColor:"#00007f",
   strokeOpacity:1.0,
	strokeWeight:8,
   fillColor: '000000',
   fillOpacity: 0,
    bounds: {
       north:35.3333,
       south:34,
       east:133,
       west:131}});
};
}
function markerInfo(marker, name) {
google.maps.event.addListener(marker, 'click', function (event) {
   new google.maps.InfoWindow({
        content: name
    }).open(marker.getMap(), marker);
});
}
google.maps.event.addDomListener(window, 'load', map_canvas);
